# Hướng dẫn build MangaLocal bản NPU (QNN) — chỉ cần điện thoại, không cần PC

> Tài liệu này tổng hợp toàn bộ 3 việc: đăng ký tài khoản Qualcomm, build APK bản có bật NPU,
> và convert model sang định dạng QNN. Toàn bộ làm được từ điện thoại. Đọc kỹ phần **Giới hạn
> thật** ở mỗi phần trước khi bắt đầu — có những chỗ tôi chưa tự kiểm chứng được 100%.

---

## Trước khi bắt đầu — 3 việc này khác nhau, không phải làm tuần tự bắt buộc

| Việc | Cần tài khoản Qualcomm? | Bắt buộc phải làm? |
|---|---|---|
| Build APK bản THƯỜNG (CPU/OpenCL) | Không | Đây là mặc định, không cần đọc tài liệu này |
| Build APK bản CÓ bật NPU (`enable_qnn=true`) | **Có** | Chỉ cần nếu muốn máy tự nhận diện NPU lúc chạy — vẫn chạy CPU/OpenCL bình thường nếu chưa có model convert QNN |
| Convert model SD1.5 augmented sang QNN | **Có** | Chỉ cần nếu muốn model CUSTOM của MangaLocal (đã ghép IP-Adapter/ControlNet/Regional Prompting) thật sự chạy trên NPU — không có thì NPU trong app không có model để chạy |

**Nếu chỉ muốn app chạy nhanh hơn mà không quan tâm NPU cụ thể**: bỏ qua toàn bộ tài liệu này,
dùng bản APK mặc định (CPU/OpenCL) — đã đủ tính năng, không thiếu gì, chỉ chậm hơn NPU.

---

## Phần 1 — Đăng ký tài khoản Qualcomm

1. Vào `id.qualcomm.com/registration` bằng trình duyệt điện thoại.
2. Đăng ký bằng email — **miễn phí, không cần thẻ tín dụng, không cần hồ sơ doanh nghiệp**.
3. Xác nhận email, đăng nhập lại.

**So sánh nhanh với MediaTek** (phòng khi bạn định hỏi tiếp): NeuroPilot SDK của MediaTek yêu cầu
tài khoản "Direct Customer" (quan hệ mua bán/hợp đồng thật với MediaTek) — cá nhân/hobbyist
thường KHÔNG vào được. Qualcomm dễ hơn nhiều với người dùng cá nhân.

**Giới hạn thật**: tôi chưa tự đăng ký thử (không có domain Qualcomm trong danh sách tôi truy
cập được) — phần "điền email, xác nhận" là tra được qua tài liệu công khai, nhưng có thể có thêm
bước duyệt thủ công/license agreement khi tải SDK thật mà tôi chưa đo được mất bao lâu.

---

## Phần 2 — Build APK bản có bật NPU

### Chuẩn bị

1. Tải QNN SDK (`.zip`, ~2GB) từ `qpm.qualcomm.com` hoặc link "Qualcomm AI Runtime Community"
   (`softwarecenter.qualcomm.com`) — cần đăng nhập tài khoản vừa tạo ở Phần 1.
2. Cài app **Termux** (từ F-Droid, miễn phí) — dùng để chạy 1 lệnh duy nhất, mô phỏng Linux ngay
   trên điện thoại, không cần PC thật.
3. Trong Termux, chạy:
   ```
   base64 -w0 duong_dan_toi_file_sdk.zip > qnn_sdk_base64.txt
   ```

### Các bước

1. Vào repo trên GitHub (trình duyệt điện thoại) → **Settings → Secrets and variables → Actions
   → New repository secret**.
2. Đặt tên `QNN_SDK_BASE64`, dán nội dung file `qnn_sdk_base64.txt` vào.
3. Vào tab **Actions → build.yml → Run workflow**, đặt:
   - `enable_qnn` = `true`
   - `qnn_mode` = `online` (mặc định — model tự biên dịch sang QNN lúc chạy trên máy; nếu bạn đã
     convert model sẵn ở Phần 3 thì có thể dùng `offline` để nhanh hơn lúc chạy)
   - `qnn_hexagon_arch` = đúng số ứng với chip Snapdragon máy bạn (xem mô tả input trong workflow)
4. Bấm **Run**, đợi vài chục phút, tải APK ở mục **Artifacts** của lần chạy đó.

### Vì sao bước này cần SDK dù chỉ là "build APK"?

Không chỉ để biên dịch code — quá trình build còn **copy nguyên file thư viện chạy thật**
(`libQnnHtpV75Stub.so`, `libQnnHtpV75Skel.so`...) từ SDK **nhét thẳng vào APK** để máy chạy được
lúc runtime. Không có SDK = không có các file `.so` này = không đóng gói được.

### Giới hạn thật

Tôi chưa tự chạy `build.yml` với `enable_qnn=true` (không có QNN SDK thật trong sandbox) — các
bước trên dựa đúng vào cấu trúc `build.yml` đã đọc trong code, không phải suy đoán, nhưng chưa
có xác nhận chạy thật thành công lần nào.

---

## Phần 3 — Convert model sang định dạng QNN

### Vì sao cần bước riêng này

Build APK ở Phần 2 chỉ cho máy **khả năng** chạy NPU — cần model đã convert sang định dạng QNN
thì NPU mới có gì để chạy. Model SD1.5 augmented của MangaLocal (đã ghép IP-Adapter + ControlNet
+ Regional Prompting) là model **custom**, không có bản convert sẵn nào trên cộng đồng (các
model chia sẻ sẵn trên HuggingFace như `xororz/sd-qnn` chỉ là SD1.5 gốc, không áp dụng được).

### Việc này cần máy RAM cao — không chạy được trên điện thoại trực tiếp

Convert cần khoảng **20-64GB RAM** (con số tra được, có thể là ước lượng cao cho trường hợp nặng
nhất, chưa kiểm chứng chính xác cho riêng UNet augmented SD1.5 của MangaLocal). Điện thoại không
đủ RAM này — cần chạy trên máy ảo cloud.

### Lựa chọn hạ tầng chạy — theo thứ tự nên thử

1. **Kaggle Notebook** (khuyến nghị thử trước) — miễn phí, không cần thẻ, **29-30GB RAM**, chạy
   nền được (đóng tab vẫn chạy tiếp — quan trọng vì convert có thể mất nhiều phút/giờ).
2. Nếu Kaggle không đủ RAM (báo lỗi bị `Killed`/OOM) — thuê VPS/cloud instance 32-64GB RAM vài
   giờ, SSH bằng app trên điện thoại (Termius, JuiceSSH...) — tốn phí nhưng linh hoạt hơn.

### Cách làm — dùng file `mangalocal_qnn_convert.ipynb` đính kèm

1. Tải file `mangalocal_qnn_convert.ipynb` (gửi kèm cùng tài liệu này) về điện thoại.
2. Vào `kaggle.com` (trình duyệt điện thoại) → đăng nhập bằng Google → **Create → New Notebook**
   → **File → Import Notebook** → chọn file `.ipynb` vừa tải.
3. Vào tab **Data** của notebook → **Upload** → tải lên:
   - File `.zip` QNN SDK đã tải ở Phần 2 (đặt tên dataset ví dụ `qnn-sdk`)
   - File `unet_ipa_controlnet.onnx` (lấy từ artifact `prepare_models.yml`, thư mục
     `./exported_augmented/` — xem `TECHNICAL_STATUS.md` mục 65 nếu chưa chạy workflow này)
4. **Settings → Accelerator → None** (không cần GPU, việc này ăn RAM chứ không ăn GPU),
   **Settings → Internet → On**.
5. **Run All**, đọc kết quả từng bước.

### Notebook có gì

- Tự dò cấu trúc SDK thật (không đoán đường dẫn cố định).
- Tự đọc input shape thật từ file `.onnx` (không đoán bừa số chiều).
- Soi đồ thị TRƯỚC khi convert — cảnh báo sớm nếu model có phép toán đã biết hay gây rắc rối
  với QNN (`Where`, `If`, `Loop`, `NonZero`...).
- Khi lỗi: trích đúng dòng log chứa từ khoá lỗi, tự tra ngược node/op bị nhắc trong log về đúng
  vị trí trong đồ thị model của bạn, tách riêng lỗi hết RAM với lỗi cú pháp/op thật.
- Tách 2 giai đoạn: convert FP32 trước (nhanh, test xem đồ thị convert được không), rồi mới tới
  quantize INT8 (bắt buộc cho NPU thật, cần dữ liệu mẫu).

### Giới hạn thật — đọc kỹ trước khi chạy

1. **Cú pháp lệnh convert đã tra chéo được từ 6 nguồn độc lập** (GitHub chính chủ Qualcomm
   `quic/qidk`, `docs.qualcomm.com`, tài liệu Thundercomm, 1 gist thực chiến, tài liệu Đại học
   Jena, docs ONNX Runtime) — đáng tin, nhưng **UNet augmented của MangaLocal chưa từng được thử
   convert thật** — đồ thị phức tạp hơn nhiều so với các ví dụ đơn giản trong 6 nguồn đó, có khả
   năng thật gặp lỗi "unsupported op" mà chỉ chạy thử mới biết.
2. **Dữ liệu quantize trong notebook là NGẪU NHIÊN** — chỉ để test cú pháp có chạy được không.
   TUYỆT ĐỐI không dùng model quantize từ dữ liệu ngẫu nhiên này để chạy thật — ảnh sẽ nhiễu/sai
   hoàn toàn. Cần thay bằng dữ liệu mẫu thật (vài chục input đã chạy qua UNet 1 lần, lưu lại)
   trước khi dùng model thật.
3. **29-30GB RAM của Kaggle có thể không đủ** — nếu convert bị "Killed", đó là hết RAM, không
   phải lỗi model, chuyển sang thuê VPS RAM cao hơn.
4. Nếu convert bị lỗi "unsupported op" thật — cần sửa lại `tools/export_ipa_controlnet_regional_unet.py`
   (thay op không hỗ trợ bằng op tương đương lúc export ONNX) — đây là việc code thật, tôi chưa
   viết sẵn hướng sửa cụ thể vì phụ thuộc đúng op nào lỗi (chưa biết trước khi chạy thử thật).

---

## Nếu gặp bế tắc ở bất kỳ bước nào

Quay lại hỏi trực tiếp, mô tả đúng lỗi/log gặp phải — nhiều bước ở trên (đặc biệt Phần 3) là lần
đầu tiên được thử nghiệm thật với model của MangaLocal, khả năng cao sẽ cần điều chỉnh dựa trên
kết quả thật thay vì đúng ngay từ lần chạy đầu.
