# Changelog — Smooth Timestep Decay (IP-Adapter) + Kiến trúc biểu cảm nhân vật

**LƯU Ý (đã đồng bộ)**: Toàn bộ nội dung file này giờ đã được viết chính
thức vào `TECHNICAL_STATUS.md` (mục 97 — Smooth Timestep Decay + phát
hiện phụ `dynamo=False`, mục 98 — kiến trúc biểu cảm + audit lệch pha),
đúng quy tắc đồng bộ tài liệu↔code mà chính dự án đặt ra (mục 58: "viết
code trỏ mục N → phải viết mục N trong CÙNG lượt"). File này (changelog
rời, tạo trước khi phát hiện quy tắc mục 58 áp dụng cho cả các đợt làm
việc sau) giữ lại làm bản ghi song song/lịch sử thao tác chi tiết hơn (có
thứ tự "lần làm đầu bị thay thế" rõ hơn bản tóm tắt trong TECHNICAL_STATUS.md),
nhưng **TECHNICAL_STATUS.md mới là nguồn sự thật chính thức** — nếu 2 file
lệch nhau ở đâu đó, tin theo TECHNICAL_STATUS.md.

So với `mangalocal4_FINAL.zip` gốc. CHƯA BUILD-TEST (như mọi thay đổi khác
trong dự án — xem hoàn_thiện_sd1_5.txt Phần 2). Đọc kỹ GIỚI HẠN THẬT của
từng phần trước khi tin đây là "đã xong".

**CẬP NHẬT (lượt 2):** phần 1 dưới đây đã được LÀM LẠI cho đúng — bản đầu
tiên dùng cách xấp xỉ (scale input embeds), bản này scale ĐÚNG output
attention thật (đúng ý nghĩa `set_ip_adapter_scale()`), có kiểm chứng bằng
thực nghiệm thật (không chỉ suy luận). Xem mục 1 và mục 5 (mới) bên dưới.

## 1. Smooth Timestep Decay cho IP-Adapter — BẢN THẬT (scale output attention)

Trả lời câu hỏi "sao không viết lại attention processor" — đã làm thật:

1. Cài `diffusers` qua pip trong sandbox, **trích xuất source code thật**
   của `IPAdapterAttnProcessor2_0` (bản 0.39.0 — bản mới nhất tại thời
   điểm viết, và cũng là bản CI sẽ cài vì script không ghim version) —
   không đoán, không nhớ lại từ training data.
2. `tools/ip_adapter_decay.py` (file MỚI): copy gần như nguyên văn logic
   `__call__` thật của processor gốc (giữ nguyên multi-token, multi-adapter,
   mask downsample...), CHỈ đổi đúng 2 chỗ nhân `scale` cuối cùng để nhân
   thêm 1 tensor runtime chia sẻ (`IpDecayState.value`) thay vì chỉ dùng
   hằng số Python tĩnh. Tái sử dụng NGUYÊN `to_k_ip`/`to_v_ip` đã train sẵn
   (gán tham chiếu, không copy trọng số).
3. **Kiểm chứng bằng thực nghiệm thật**, không chỉ suy luận trên giấy: cài
   torch 2.13 + onnxruntime trong sandbox, dựng 1 model đồ chơi mô phỏng
   đúng cơ chế "container chia sẻ, gán giá trị ngay trước khi gọi module
   con", export ONNX thật, chạy `onnxruntime` với 2 giá trị `ip_decay_floor`
   khác nhau (1.0 vs 0.3) → **kết quả số học khác nhau rõ rệt**, xác nhận
   cơ chế hoạt động đúng như thiết kế, không bị đóng băng thành hằng số.
4. `export_ipa_controlnet_unet.py` / `export_ipa_controlnet_depth_unet.py`:
   sau `pipe.load_ip_adapter()`, gọi `wrap_unet_ip_adapter_processors()` để
   thay mọi processor gốc bằng bản đã bọc — có kiểm tra chặt: nếu 0
   processor được bọc (ví dụ do CI cài bản diffusers khác đã đổi cấu trúc
   nội bộ), script **dừng lỗi rõ ràng** thay vì âm thầm export model sai.

**GIỚI HẠN THẬT còn lại (đọc trước khi tin 100%):**
- Đã xác nhận khớp diffusers 0.39.0 cài trong sandbox lúc viết. Script
  không ghim version diffusers cụ thể — nếu CI cài bản diffusers MỚI HƠN
  đã đổi cấu trúc `IPAdapterAttnProcessor2_0`, script sẽ BÁO LỖI rõ ràng
  (không âm thầm sai) nhờ kiểm tra `n_wrapped == 0` — nhưng vẫn cần sửa lại
  `ip_adapter_decay.py` bằng đúng quy trình đã dùng (pip install diffusers,
  đọc source thật) nếu gặp lỗi này.
- CHƯA build-test thật (thiếu GPU/model thật trong sandbox) — chỉ xác nhận
  được: source khớp đúng bản cài, cú pháp hợp lệ (`py_compile`), VÀ cơ chế
  runtime-tensor sống sót qua `torch.onnx.export` bằng thực nghiệm đồ chơi
  (không phải bằng chính UNet thật — UNet thật lớn hơn nhiều, có thể có
  chi tiết khác biệt chưa lường hết, dù cơ chế lõi đã kiểm chứng đúng).
- Nhánh `ip_adapter_masks` (mask N-nhân-vật) trong `ip_adapter_decay.py`
  CŨNG đã nhân decay vào, nhưng `export_ipa_controlnet_mask_unet.py` CHƯA
  được nối dùng module này (việc riêng, chưa làm).

Files đổi (Python):
- `tools/ip_adapter_decay.py` — **MỚI**, module dùng chung.
- `tools/export_ipa_controlnet_unet.py` — bỏ cách scale-input cũ, dùng
  `wrap_unet_ip_adapter_processors()`; `AugmentedUNet` nhận thêm
  `decay_state`, gán `decay_state.value` ngay trước khi gọi `self.unet(...)`.
- `tools/export_ipa_controlnet_depth_unet.py` — tương tự cho bản
  pose+depth+IP-Adapter.

Files đổi (Kotlin/C++ — KHÔNG đổi so với lượt 1, chỉ sửa lại comment cho
đúng "scale output thật" thay vì "xấp xỉ scale-input"):
- `app/src/main/jni/ip_adapter.cpp` — `setIpAdapterDecay()`, feed input
  tuỳ chọn `ip_decay_floor`/`ip_decay_start_timestep`, JNI
  `sdTxt2ImgWithReferenceAndPose` nhận thêm 2 tham số cuối.
- `NativeBridge.kt`, `ImagePipeline.kt`, `Models.kt` (2 field mới trong
  `GenerationSettings`, default 1.0/999.0 = tắt hẳn, tương thích ngược).
- `MangaPipeline.kt` — nối vào cả 3 call site của `generatePanel()`.
- `SettingsScreen.kt` — 2 Slider mới.

## 2. Kiến trúc phân loại biểu cảm nhân vật (LLM parse) — KHÔNG ĐỔI so với lượt 1

Dùng đúng khuôn mẫu `action_category` đã có. `Scene.expression` (10
category đóng) + `LLMParser.EXPRESSION_TAGS` tra tag cụ thể (2 biến thể
tag-based/natural-language theo `PromptStyle`, mục 93) thay vì để LLM tự
bịa. Nối với mục 1: khi `ipDecayFloor < 1.0`, `buildPrompt()` nhận cờ
`ipAdapterDecayActive=true` → nhấn mạnh cụm biểu cảm hơn để tận dụng đúng
khoảng trống mà decay tạo ra ở cuối các step.

Files: `Models.kt` (`Scene.expression`), `LLMParser.kt` (schema JSON,
parse, `promptTemplate()`), `MangaPipeline.kt` (gọi `buildPrompt()` với cờ
mới).

## 3. Sửa nhỏ khác

- `MangaPipeline.kt`: sửa 1 comment sai lệch ở nhánh Quality Gate 1-nhân-
  vật (comment cũ nói chỉ áp dụng 1 nhánh, code thật đã bọc cả 3 nhánh từ
  mục 83 — chỉ là tài liệu sai trong code, không phải bug chức năng).

## 4. Đối chiếu lại với trạng thái thật của source

Trước khi làm việc này, đã giải nén `mangalocal4_FINAL.zip` lần đầu (lượt
trước chỉ đọc TECHNICAL_STATUS.md/txt). Hầu hết mục "UI còn thiếu" trong
`hoàn_thiện_sd1_5.txt` bản trước ĐÃ CÓ SẴN trong code thật — danh sách đó
dựa trên tài liệu có thể lỗi thời so với code, không phải trạng thái thật.

## 5. Phát hiện phụ QUAN TRỌNG (lượt 2) — ảnh hưởng TOÀN BỘ pipeline export, không riêng decay

Trong lúc kiểm chứng thực nghiệm mục 1, phát hiện: **torch ≥2.9 đổi
exporter mặc định của `torch.onnx.export()` sang đường `dynamo`** (cần
package `onnxscript`, hành vi trace khác hẳn đường TorchScript-trace cũ mà
toàn bộ cơ chế runtime-scalar của dự án đang dựa vào — pose_scale,
depth_scale, depth_active_min_timestep, ip_decay_floor...). Đã tự cài
torch 2.13 (bản mới nhất hiện có qua pip, đại diện cho những gì CI sẽ cài
vì KHÔNG script export nào trong dự án ghim version torch cụ thể) và xác
nhận: gọi `torch.onnx.export()` KHÔNG truyền `dynamo=False` sẽ **lỗi ngay**
(`ModuleNotFoundError: No module named 'onnxscript'`) nếu môi trường CI
không có sẵn package đó — tức là TOÀN BỘ 7 script export (không chỉ 2
script IP-Adapter) có nguy cơ lỗi ngay từ bước export cơ bản nhất, hoàn
toàn không liên quan gì đến decay hay bất kỳ tính năng nào khác.

**Đã vá TẤT CẢ 15 lệnh gọi `torch.onnx.export()` trong dự án** (đếm và xác
nhận khớp bằng script, không phải vá tay từng chỗ dễ sót) — thêm
`dynamo=False` tường minh vào mọi lệnh gọi, kèm comment giải thích lý do +
tham chiếu đến chỗ đã kiểm chứng thực nghiệm:
- `tools/export_esrgan.py` (1 chỗ)
- `tools/export_ipa_controlnet_depth_unet.py` (1 chỗ)
- `tools/export_ipa_controlnet_mask_unet.py` (1 chỗ)
- `tools/export_ipa_controlnet_regional_unet.py` (1 chỗ)
- `tools/export_ipa_controlnet_unet.py` (2 chỗ)
- `tools/export_sd15_base.py` (4 chỗ)
- `tools/export_sdxl_base.py` (5 chỗ)

Đã xác nhận: mọi file `py_compile` sạch, số `dynamo=False,` khớp CHÍNH XÁC
số lệnh gọi `torch.onnx.export(` trong từng file (không thừa, không thiếu).

**GIỚI HẠN THẬT của phát hiện này:** chỉ xác nhận được bằng cách gọi
`torch.onnx.export()` KHÔNG truyền `dynamo=False` sẽ lỗi trong môi trường
sandbox này (torch 2.13, không có `onnxscript`). CHƯA xác nhận được CI
thật của dự án (GitHub Actions, `prepare_models.yml`) sẽ cài đúng torch
version nào tại thời điểm chạy — nếu pip cài torch <2.9, `dynamo=False`
vẫn hợp lệ (tham số này tồn tại từ trước, chỉ đổi giá trị MẶC ĐỊNH ở 2.9),
nên việc ghim rõ là AN TOÀN trong mọi trường hợp, không có rủi ro ngược.

## 6. Mở rộng taxonomy biểu cảm (lượt 3) — trả lời "danh sách này có phổ quát không"

Không có taxonomy cảm xúc/hành động nào "đầy đủ tuyệt đối" — đây là giới
hạn thật của lĩnh vực (tâm lý học cảm xúc còn tranh cãi giữa mô hình rời
rạc và mô hình liên tục valence-arousal), không phải thiếu sót có thể vá
hết. Đã làm 2 việc cụ thể thay vì chỉ nói suông:

1. **Đối chiếu với chuẩn học thuật thật** (Ekman 6 cảm xúc cơ bản + neutral,
   dùng làm cơ sở cho FER2013/RAF-DB/AffectNet) → phát hiện `EXPRESSION_TAGS`
   THIẾU `disgust` và `contempt` (contempt là lớp thứ 8 của chuẩn AffectNet)
   — đã bổ sung, giờ 6 category đầu khớp đúng 6 cảm xúc Ekman + neutral +
   contempt = phủ đúng chuẩn AffectNet 8-lớp. 4 category còn lại (crying,
   smirk, determined, blush) KHÔNG thuộc chuẩn học thuật nào — ghi rõ trong
   comment là chọn theo QUY ƯỚC THỂ LOẠI manga, không phải phổ quát.
2. **Ghi rõ trong code (không giấu) hệ quả thật của việc dùng enum đóng**:
   vì "expression" là 1 JSON enum, LLM BỊ ÉP chọn category GẦN NHẤT ngay
   cả khi cảm xúc thật (vd ghen tuông, hoài niệm) không khớp hoàn hảo —
   đây là đánh đổi có chủ đích (gần đúng vẫn hơn không có gì), không phải
   claim đã bao phủ mọi sắc thái cảm xúc con người.

`action_category` (embrace/combat/kiss/run/neutral, có từ trước lượt này)
KHÔNG được mở rộng theo hướng "phổ quát hành động" — không có chuẩn học
thuật tương đương Ekman cho hành động (Kinetics/UCF101 có hàng trăm lớp
nhưng cho nhận diện video, không liên quan). Mục tiêu của field này vốn
hẹp hơn nhiều: chỉ hành động cần `tryAutoFixInteractions()` xử lý đặc biệt
— phạm vi đó đã đúng, không cần/không nên mở rộng.

Files đổi: `LLMParser.kt` — `EXPRESSION_TAGS` (12 mục, +disgust +contempt),
schema JSON, hướng dẫn phân loại (thêm ví dụ + câu dặn rõ "không đầy đủ,
chọn gần nhất").

## Việc còn lại thật sự (ưu tiên như hoàn_thiện_sd1_5.txt)

1. BUILD CI THẬT vẫn là bước bắt buộc trước mọi thứ khác.
2. Nếu build pass: export lại `unet_ipa_controlnet.mnn` để có input mới.
3. Test A/B thật: so sánh ảnh cùng seed với `ipDecayFloor=1.0` (tắt) vs
   `ipDecayFloor=0.4-0.6` (bật) — phép đo duy nhất xác nhận được mức ảnh
   hưởng thật trên ảnh, dù cơ chế bên dưới giờ đã đúng về mặt toán học.
4. Nối decay cho model mask N-nhân-vật nếu muốn dùng cả 2 tính năng cùng
   lúc — chưa làm.
5. Nếu lúc chạy `prepare_models.yml` thật mà `wrap_unet_ip_adapter_processors()`
   báo lỗi "0 processor được bọc" — đây là dấu hiệu diffusers đã đổi cấu
   trúc, cần tra lại `ip_adapter_decay.py` bằng đúng quy trình đã dùng để
   viết nó (pip install diffusers, đọc source thật của bản đang cài).

