# MangaLocal v3 — Full Edition

Chuyển truyện chữ → truyện tranh hoàn toàn local trên Android.
Quản lý nhiều truyện, nhiều nhân vật, review trước upscale, hội thoại tự động/thủ công, kiểm soát nhiệt độ.

## Tính năng v3

- **Multi-story** — quản lý nhiều truyện độc lập, mỗi truyện có nhân vật riêng
- **Character roles** — Chính (anchor vĩnh viễn) / Phụ (tạm) / Một lần (không lưu)
- **Auto character detection** — LLM tự nhận diện nhân vật mới khi sinh chương
- **StoryDiffusion Consistent Self-Attention** — nhất quán mặt+trang phục+vóc dáng, không cần LoRA
- **Gallery Review** — duyệt/sửa/tạo lại từng panel trước khi upscale
- **Upscale 4 mức** — None / 2× / 4× / 4× Sharpen
- **Bubble hội thoại kép** — Tự động (YOLOv8n detect vị trí) + Thủ công (kéo thả)
- **Thermal control** — tự dừng khi quá nhiệt, rung báo động, tự resume
- **Chạy nền** — Foreground Service, tắt màn hình vẫn chạy
- **100% offline** — không filter, không restrict

## Build APK (chỉ dùng điện thoại, qua GitHub Actions)

1. github.com → New repository → Public
2. Upload toàn bộ source này (giải nén trước nếu là zip)
3. Tab Actions → tự chạy → ~30-35 phút
4. Download APK từ Artifacts → cài trên Zenfone 8

## Setup model

Đặt vào `/sdcard/MangaLocal/`:

```
models/
  ├── *.gguf            (LLM - Qwen2.5-3B khuyến nghị)
  └── *.safetensors     (SD 1.5 checkpoint bất kỳ)

loras/
  └── *.safetensors     (LoRA nhân vật, tùy chọn)

esrgan/
  ├── realesrgan-x4plus.param
  └── realesrgan-x4plus.bin

yolo/ (tùy chọn — cho auto bubble)
  ├── yolov8n.param
  └── yolov8n.bin
```

## Pipeline đầy đủ

```
1. Viết/dán truyện chữ vào Story
2. LLM chia scene + tự nhận diện nhân vật mới
3. SD sinh panel 512px (StoryDiffusion giữ nhất quán)
   → Thermal monitor theo dõi liên tục, tự dừng nếu quá nóng
4. GALLERY REVIEW — duyệt từng panel, sửa prompt, tạo lại nếu cần
5. Upscale panel đã duyệt (chọn độ phân giải)
6. [Tùy chọn] Auto bubble bằng YOLOv8n
   hoặc thủ công kéo thả bubble trên canvas
7. Xuất PDF + CBZ
```

## Hiệu năng ước tính (Zenfone 8 SD888)

| Tác vụ | Thời gian |
|---|---|
| LLM parse + character detect | ~8-12s |
| Mỗi panel SD | ~35-55s |
| Upscale 4× | ~12-18s |
| Auto bubble (YOLOv8n) | ~3-5s/panel |
| 6 panel hoàn chỉnh | ~10-14 phút |

## Lưu ý nhiệt độ

App đọc nhiệt độ trực tiếp từ kernel thermal_zone, không cần root.
Mặc định dừng ở 42°C, tự tiếp tục khi xuống 39°C.
Khuyến nghị bật chế độ máy bay khi generate để tránh nhiễu nhiệt từ mạng.
