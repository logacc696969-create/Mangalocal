package com.mangalocal.pipeline

import com.mangalocal.model.ExternalLlmConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Gọi LLM NGOÀI qua API chuẩn OpenAI-compatible (POST {baseUrl}/chat/completions)
 * — dùng được với OpenAI thật, OpenRouter, Groq, Together, hay server tự
 * host tương thích chuẩn này (LM Studio, Ollama qua lớp tương thích OpenAI,
 * text-generation-webui...). Đây là lựa chọn THAY THẾ cho LLM chạy local
 * trên máy (.gguf qua llama.cpp) — hữu ích khi máy yếu (không đủ RAM/NPU
 * chạy model local tốt) hoặc muốn dùng model mạnh hơn hẳn.
 *
 * LƯU Ý BẢO MẬT — khác hẳn RemoteGenerationClient (ảnh, tự host + mã hoá
 * hybrid RSA/AES riêng của app): đây là API THẬT của bên thứ 3, chỉ có TLS
 * chuẩn bảo vệ, KHÔNG có lớp mã hoá thêm nào của app. Toàn bộ văn bản kịch
 * bản gửi đi sẽ được xử lý bởi hạ tầng của nhà cung cấp API đó, theo đúng
 * chính sách riêng tư/lưu trữ của HỌ — không phải "app tự host" như Remote
 * GPU ảnh. Cân nhắc trước khi gửi nội dung thực sự riêng tư qua đây.
 */
class ExternalLlmClient(private val config: ExternalLlmConfig) {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(config.timeoutSeconds.toLong(), TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun generate(prompt: String, maxTokens: Int, temperature: Float): String =
        withContext(Dispatchers.IO) {
            if (config.baseUrl.isBlank()) throw RuntimeException("Chưa nhập Base URL cho LLM ngoài (Cài đặt > LLM ngoài).")
            if (config.modelName.isBlank()) throw RuntimeException("Chưa nhập tên model cho LLM ngoài (Cài đặt > LLM ngoài).")

            val url = config.baseUrl.trimEnd('/') + "/chat/completions"
            val body = JSONObject().apply {
                put("model", config.modelName)
                put("temperature", temperature.toDouble())
                put("max_tokens", maxTokens)
                put("messages", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", prompt)
                    })
                })
            }
            val reqBody = body.toString().toRequestBody("application/json".toMediaType())
            val reqBuilder = Request.Builder().url(url).post(reqBody)
            if (config.apiKey.isNotBlank()) reqBuilder.addHeader("Authorization", "Bearer ${config.apiKey}")

            client.newCall(reqBuilder.build()).execute().use { resp ->
                val respText = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw RuntimeException("LLM API lỗi HTTP ${resp.code}: ${respText.take(300)}")
                }
                try {
                    val json = JSONObject(respText)
                    json.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content")
                } catch (e: Exception) {
                    throw RuntimeException("Không đọc được phản hồi API (định dạng lạ, kiểm tra lại Base URL/model): ${respText.take(300)}")
                }
            }
        }

    /** Kiểm tra kết nối nhanh cho nút "Kiểm tra kết nối" ở Settings — ném exception kèm lý do nếu lỗi. */
    suspend fun testConnection(): String = generate("Reply with exactly the single word: OK", 10, 0f)
}
