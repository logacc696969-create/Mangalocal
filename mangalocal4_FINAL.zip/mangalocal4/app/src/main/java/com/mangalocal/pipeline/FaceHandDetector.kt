package com.mangalocal.pipeline

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Dò vùng mặt + tay để auto-inpaint (ADetailer-style, mục 16/17
 * TECHNICAL_STATUS.md).
 *
 * ĐÃ ĐỔI (mục 19/20 TECHNICAL_STATUS.md — "dùng YOLO xuyên suốt, giảm công
 * code kỹ thuật autodetect khác"): TRƯỚC dùng MediaPipe Face Detector +
 * Hand Landmarker (2 model riêng). GIỜ tái dùng NGAY khung xương
 * YOLOv8-pose (PoseExtractor, mục 19) đã detect sẵn — vùng mặt suy ra từ
 * mũi/mắt/tai, vùng tay suy ra từ khớp cổ tay + khuỷu tay (đo độ dài cẳng
 * tay để ước lượng kích thước bàn tay). KHÔNG CẦN THÊM MODEL YOLO NÀO
 * KHÁC — dùng lại đúng 1 lần detect YOLOv8-pose đã chạy, giảm hẳn 1 lượt
 * inference riêng cho face/hand so với trước (vừa nhanh hơn, vừa đỡ code).
 *
 * ĐÁNH ĐỔI CẦN BIẾT (thành thật, không giấu): model face/hand CHUYÊN BIỆT
 * (MediaPipe BlazeFace, hoặc YOLO-face/YOLO-hand cộng đồng train riêng) cho
 * box CHÍNH XÁC hơn — họ được train ĐỂ tìm đúng ranh giới mặt/tay thật. Suy
 * từ keypoint pose chỉ là ƯỚC LƯỢNG hình học (box vuông quanh 1 điểm, kích
 * thước theo tỷ lệ cơ thể) — có thể lệch tâm hoặc sai kích thước với tư thế
 * lạ (tay giơ cao, nghiêng mạnh...). Đánh đổi được chấp nhận vì: (1) mask
 * inpaint vốn đã có padding rộng, lệch nhẹ vẫn che được vùng lỗi; (2) tái
 * dùng detect đã chạy sẵn cho pose, không tốn thêm resource/model riêng —
 * đúng tiêu chí "hiệu suất cao, dùng nhiều nơi, không code lại" đã thống
 * nhất từ mục 17. CHƯA build-test để biết độ lệch thực tế bao nhiêu.
 */
class FaceHandDetector(private val poseExtractor: PoseExtractor) {

    fun isReady() = poseExtractor.isReady()

    // Padding thêm quanh box ước lượng — rộng hơn hẳn bản MediaPipe cũ
    // (25%) vì đây là suy luận hình học thô, cần biên độ rộng hơn để không
    // cắt hụt vùng lỗi thật.
    private val facePaddingRatio = 0.6f
    private val handPaddingRatio = 0.5f

    fun detectRegions(bitmap: Bitmap): List<Rect> {
        if (!isReady()) return emptyList()
        val w = bitmap.width; val h = bitmap.height
        val people = poseExtractor.extractFromImage(bitmap) ?: return emptyList()
        val regions = mutableListOf<Rect>()

        people.forEach { person ->
            // Vùng mặt: bounding box quanh mũi(0)/mắt(14,15)/tai(16,17) —
            // bán kính tham chiếu = khoảng cách vai (2-5), tỷ lệ kinh
            // nghiệm ~0.5x bề rộng vai cho 1 khuôn mặt người thường.
            val faceIdx = listOf(0, 14, 15, 16, 17)
            val faceVisible = faceIdx.mapNotNull { person.getOrNull(it) }.filter { it.visible }
            val rightSh = person.getOrNull(2); val leftSh = person.getOrNull(5)
            if (faceVisible.isNotEmpty() && rightSh?.visible == true && leftSh?.visible == true) {
                val cx = faceVisible.map { it.x }.average().toFloat()
                val cy = faceVisible.map { it.y }.average().toFloat()
                val shoulderWidth = sqrt((rightSh.x-leftSh.x)*(rightSh.x-leftSh.x) + (rightSh.y-leftSh.y)*(rightSh.y-leftSh.y))
                val faceRadius = shoulderWidth * 0.55f * (1 + facePaddingRatio)
                regions += normalizedBoxToRect(cx - faceRadius, cy - faceRadius, cx + faceRadius, cy + faceRadius, w, h)
            }

            // Vùng tay: quanh cổ tay (4=right_wrist, 7=left_wrist), kích
            // thước = độ dài cẳng tay (khuỷu(3/6)->cổ tay(4/7)) * hệ số —
            // bàn tay thường ~0.5-0.6x độ dài cẳng tay.
            listOf(Pair(3, 4), Pair(6, 7)).forEach { (elbowIdx, wristIdx) ->
                val elbow = person.getOrNull(elbowIdx); val wrist = person.getOrNull(wristIdx)
                if (elbow?.visible == true && wrist?.visible == true) {
                    val forearmLen = sqrt((elbow.x-wrist.x)*(elbow.x-wrist.x) + (elbow.y-wrist.y)*(elbow.y-wrist.y))
                    val handRadius = forearmLen * 0.55f * (1 + handPaddingRatio)
                    regions += normalizedBoxToRect(
                        wrist.x - handRadius, wrist.y - handRadius,
                        wrist.x + handRadius, wrist.y + handRadius, w, h
                    )
                }
            }
        }
        return regions
    }

    private fun normalizedBoxToRect(nx1: Float, ny1: Float, nx2: Float, ny2: Float, w: Int, h: Int): Rect {
        return Rect(
            (nx1 * w).toInt().coerceIn(0, w), (ny1 * h).toInt().coerceIn(0, h),
            (nx2 * w).toInt().coerceIn(0, w), (ny2 * h).toInt().coerceIn(0, h)
        )
    }

    fun close() { /* dùng chung poseExtractor, KHÔNG tự close() ở đây — MangaPipeline sở hữu vòng đời poseExtractor */ }
}
