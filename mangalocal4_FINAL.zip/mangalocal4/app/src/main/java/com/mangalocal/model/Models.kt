package com.mangalocal.model

import java.io.File

// ── Nhân vật ──────────────────────────────────────────────────────────────
enum class CharacterRole { MAIN, SUPPORTING, ONETIME }

// Tỷ lệ xương THẬT theo TỪNG NHÂN VẬT (mục 31 TECHNICAL_STATUS.md) — thay
// AgeCategory chung chung (mục 30, đã lùi thành PRESET tham khảo, không
// còn là nguồn dữ liệu chính). User chỉ ra đúng: cùng tuổi có thể cao/thấp/
// dậy thì sớm-muộn khác nhau — nên tỷ lệ phải gán được RIÊNG từng nhân
// vật, không chỉ chọn 1 trong 3 nhóm tuổi cứng.
//
// Đơn vị: hệ số NHÂN so với tỷ lệ chuẩn (1.0 = trung bình người lớn dùng
// làm mốc). Ví dụ đùi ngắn hơn trung bình 20% -> upperLegRatio = 0.8.
// 5 đoạn xương chính đủ cho FK retargeting 2D (mục 32) — KHÔNG chia nhỏ
// hơn (vd đốt ngón tay) vì OpenPose-18 không có đủ khớp để phân biệt.
data class BoneProportions(
    val torsoRatio: Float = 1.0f,      // neck -> hip-center (trục thân)
    val upperArmRatio: Float = 1.0f,   // shoulder -> elbow
    val forearmRatio: Float = 1.0f,    // elbow -> wrist
    val upperLegRatio: Float = 1.0f,   // hip -> knee
    val lowerLegRatio: Float = 1.0f,   // knee -> ankle
    val headSizeRatio: Float = 1.0f    // xấp xỉ qua khoảng cách mắt-mũi (KHÔNG chính xác tuyệt đối — xem mục 30 giới hạn OpenPose-18 không có điểm đỉnh đầu)
) {
    companion object {
        // Preset tham khảo NHANH (mục 30), KHÔNG PHẢI số liệu y văn đã kiểm
        // chứng riêng — chỉ là điểm khởi đầu hợp lý để user tự tinh chỉnh
        // tiếp bằng slider trong UI, không nên tin tuyệt đối.
        fun presetChild() = BoneProportions(torsoRatio = 0.85f, upperArmRatio = 0.8f, forearmRatio = 0.8f,
            upperLegRatio = 0.75f, lowerLegRatio = 0.75f, headSizeRatio = 1.3f)
        fun presetTeen() = BoneProportions(torsoRatio = 0.93f, upperArmRatio = 0.9f, forearmRatio = 0.9f,
            upperLegRatio = 0.88f, lowerLegRatio = 0.88f, headSizeRatio = 1.1f)
        fun presetAdult() = BoneProportions() // 1.0 mọi mặt = mốc chuẩn
    }
}

// 3 phương pháp nhất quán nhân vật (mục 12/13 TECHNICAL_STATUS.md) + NONE
// (chỉ mô tả bằng chữ, không neo gì — dùng cho vai phụ/qua đường không cần
// đầu tư). Độ nhất quán ước lượng CỘNG ĐỒNG SD nói chung (CHƯA đo trên
// chính pipeline này — xem ghi chú tại nơi hiển thị cho user):
// LORA ~90-100% > IP_ADAPTER ~80-90% > TEXTUAL_INVERSION ~40-65% > NONE (0%,
// chỉ dựa mô tả chữ + seed cố định).
enum class ConsistencyMethod { LORA, IP_ADAPTER, TEXTUAL_INVERSION, NONE }

data class Character(
    val id: String,
    val name: String,
    val anchorPrompt: String,
    val negativePrompt: String = "bad anatomy, deformed, ugly, blurry",
    val seed: Long,
    val role: CharacterRole = CharacterRole.MAIN,
    val loraPath: String? = null,
    val loraWeight: Float = 0.75f,
    val anchorImagePath: String? = null,   // ảnh gốc nhân vật, dùng làm reference thật cho IP-Adapter
    // Textual Inversion (mục 12 TECHNICAL_STATUS.md) — phương pháp thứ 3,
    // độc lập với loraPath/anchorImagePath, có thể dùng CÙNG LÚC với 1
    // trong 2 cái kia hoặc đứng riêng. embeddingTrigger = tên file (không
    // đuôi) trong StoryManager.embeddingsDir — chính là từ cần gõ trong
    // prompt để kích hoạt (xem StoryManager.setCharacterEmbedding).
    val embeddingPath: String? = null,
    val embeddingTrigger: String? = null,
    // Tỷ lệ xương THẬT của nhân vật này (mục 31 TECHNICAL_STATUS.md — thay
    // AgeCategory chung chung bằng số đo RIÊNG từng nhân vật, vì user chỉ
    // ra đúng: cùng tuổi vẫn có thể cao/thấp/dậy thì sớm-muộn khác nhau,
    // "profile theo nhóm tuổi" không đủ chính xác). Đơn vị: TỶ LỆ so với
    // 1 đơn vị tham chiếu cố định (khoảng cách vai-hông = 1.0), không phải
    // cm thật — vì ControlNet-Pose làm việc trên toạ độ ảnh 0..1, không
    // cần biết chiều cao thật bằng cm.
    val boneProportions: BoneProportions = BoneProportions()
)

// ── Truyện ────────────────────────────────────────────────────────────────
data class Story(
    val id: String,
    val title: String,
    val description: String = "",
    val style: ImageStyle = ImageStyle.REALISTIC,
    val characters: List<Character> = emptyList(),
    val chapterIds: List<String> = emptyList(),
    // Quy tắc bối cảnh chung (tiếng Việt tự nhiên, user tự viết) — LLM dùng
    // làm ngữ cảnh nền khi dịch mô tả cảnh sang prompt SD1.5, áp dụng cho
    // CẢ 3 giai đoạn (txt2img/upscale-redraw/inpaint), xem PromptStage.
    val worldRules: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

// 3 giai đoạn cần dịch prompt khác nhau (mục 24 TECHNICAL_STATUS.md) — mỗi
// giai đoạn cần trọng tâm khác nhau khi LLM dịch mô tả tự nhiên sang tag
// SD1.5: TXT2IMG cần mô tả ĐẦY ĐỦ cảnh; UPSCALE_REDRAW chỉ cần tag về CHẤT
// LƯỢNG BỀ MẶT (không mô tả lại toàn cảnh — ảnh đã có bố cục, chỉ cần làm
// nét/sửa texture); INPAINT chỉ cần mô tả HÀNH ĐỘNG/VÙNG cụ thể đang sửa,
// không nhắc lại toàn bộ scene (theo đúng nguyên tắc "prompt tập trung vào
// hành động" đã thống nhất).
enum class PromptStage { TXT2IMG, UPSCALE_REDRAW, INPAINT }

// ── Model file ────────────────────────────────────────────────────────────
data class ModelInfo(
    val path: String,
    val name: String,
    val type: ModelType,
    val sizeBytes: Long
) {
    val displaySize: String get() {
        val gb = sizeBytes / 1_073_741_824.0
        val mb = sizeBytes / 1_048_576.0
        return if (gb >= 1.0) "%.1fGB".format(gb) else "%.0fMB".format(mb)
    }
}
enum class ModelType { SD15, LLM, LORA, ESRGAN, YOLO }

// ── Local/Remote GPU routing (tính năng mới) ───────────────────────────────
// Cho phép sinh ảnh chạy trên GPU thuê ngoài (Colab miễn phí / RunPod-Vast.ai
// trả phí) thay vì bắt buộc chạy local trên điện thoại. QUAN TRỌNG — đã bàn
// kỹ với user: KHÔNG có cách nào đảm bảo tuyệt đối "chủ GPU không soi được"
// với GPU thuê thông thường — chủ hạ tầng (hypervisor) luôn có khả năng đọc
// VRAM/RAM của VM đang chạy, mã hoá ngay sau khi sinh không chặn được việc
// này (không phải vấn đề tốc độ/thời gian). Chỉ Confidential Computing (TEE
// phần cứng, vd NVIDIA H100/H200 chế độ CC) mới thật sự chặn được cả chủ
// hạ tầng — 2 tier dưới đây phản ánh đúng 2 mức thật, KHÔNG quảng cáo quá.
enum class RemoteSecurityTier {
    // TLS trên đường truyền + không lưu log/file phía server + xoá ngay sau
    // khi trả kết quả (ephemeral). CHỈ chống được: người đứng giữa mạng,
    // và (nếu server thật sự tuân thủ code đã viết) chống rò rỉ qua log/đĩa.
    // KHÔNG chống được: chính chủ hạ tầng (Google/chủ máy RunPod) nếu họ cố
    // tình soi VM đang chạy. Phù hợp: Colab miễn phí, GPU rental thường.
    TLS_EPHEMERAL,
    // GPU hỗ trợ Confidential Computing (TEE) thật + attestation xác minh
    // trước khi gửi dữ liệu. Chống được cả chủ hạ tầng. Chỉ khả dụng ở 1 số
    // nhà cung cấp đặc thù (vd Azure Confidential VM với H100 CC), CHƯA
    // triển khai thật trong bản này — cờ có sẵn để bật khi có provider phù hợp.
    CONFIDENTIAL_COMPUTING
}

enum class GenerationBackend { LOCAL, REMOTE }

// Chế độ chọn backend cho TỪNG panel:
// MANUAL: người dùng tự chọn qua PanelOverrideSettings.backendOverride
//         (hoặc mặc định GenerationSettings.defaultBackend nếu panel không
//         override riêng).
// AUTO:   LLM (MNN-LLM local, cùng model đang dùng để parse kịch bản) tự
//         quyết định LOCAL hay REMOTE cho từng panel, dựa theo
//         GenerationSettings.autoRoutingPolicyPrompt do NGƯỜI DÙNG tự viết
//         (vd "cảnh nhạy cảm/riêng tư thì local, còn lại remote cho nhanh").
//         Xem BackendRouter.kt. Quyết định LUÔN có thể bị override tay qua
//         backendOverride của panel đó (override tay ưu tiên tuyệt đối hơn AUTO).
enum class RoutingMode { MANUAL, AUTO }

// Quy tắc khai báo TRƯỚC cho chế độ MANUAL (mục "phân chia thủ công theo
// nhân vật/từ khoá", KHÔNG áp dụng cho AUTO — AUTO chỉ dùng LLM đọc
// autoRoutingPolicyPrompt, xem AutoBackendRouter, không hardcode theo
// nhân vật/scene ở tầng Kotlin để giữ đúng yêu cầu "quy tắc do người dùng
// nêu trong prompt, không hardcode"). Ở MANUAL thì NGƯỢC LẠI — đây chính là
// nơi user khai báo cứng theo ý mình (vd "nhân vật Lan luôn local"), xử lý
// bằng code Kotlin thuần (deterministic), không qua LLM — vì MANUAL nghĩa
// là user muốn chắc chắn 100%, không phụ thuộc LLM có hiểu đúng ý hay không.
enum class RoutingMatchType { CHARACTER, KEYWORD }

data class ManualRoutingRule(
    val id: String = java.util.UUID.randomUUID().toString(),
    val matchType: RoutingMatchType = RoutingMatchType.CHARACTER,
    // CHARACTER: khớp khi tên này có trong panel.scene.characters (so khớp
    // không phân biệt hoa/thường). KEYWORD: khớp khi cụm này xuất hiện
    // (contains, không phân biệt hoa/thường) trong description/action/setting
    // của scene — dùng cho quy tắc không gắn với 1 nhân vật cụ thể (vd "cảnh
    // trong nhà tắm luôn local").
    val value: String,
    val backend: GenerationBackend
)
// Thứ tự trong list QUYẾT ĐỊNH ưu tiên khi 1 panel khớp ≥2 rule mâu thuẫn
// nhau (vd panel có cả nhân vật "luôn local" VÀ khớp từ khoá "luôn remote")
// — rule đứng TRƯỚC trong list thắng. Xem ManualBackendRouter.decide().

// Cấu hình endpoint remote — 1 cấu hình DÙNG CHUNG cho cả Story (không phải
// riêng từng panel, vì đổi server giữa chừng 1 chapter không hợp lý — nếu
// cần nhiều server khác nhau, đổi ở SettingsScreen rồi chạy lại panel cần đổi).
data class RemoteEndpointConfig(
    val enabled: Boolean = false,
    val baseUrl: String = "",           // vd "https://xxxx.ngrok-free.app" (Colab+tunnel) hoặc IP:port (RunPod)
    val authToken: String = "",         // Bearer token — do user tự đặt khi chạy remote_server/app.py, KHÔNG hardcode
    val securityTier: RemoteSecurityTier = RemoteSecurityTier.TLS_EPHEMERAL,
    val timeoutSeconds: Int = 180,      // Colab free có thể chậm lúc cold-start model — timeout dài hơn HTTP thường
    // Ghim public key/cert của server (certificate pinning) — RỖNG = không
    // ghim (chỉ dựa vào CA hệ thống, chấp nhận được cho Colab/ngrok vì domain
    // đổi mỗi lần chạy lại). Điền vào nếu dùng server cố định (RunPod/VPS
    // riêng) để chống MITM kể cả khi 1 CA nào đó trong hệ thống bị xâm phạm.
    val pinnedCertSha256: String = ""
)

// ── Cài đặt ───────────────────────────────────────────────────────────────
data class GenerationSettings(
    // sdModelPath/loraPath/loraWeight: CÒN GIỮ để SettingsScreen.kt (UI)
    // chưa cần sửa ngay, nhưng KHÔNG còn được ImagePipeline.loadSD() dùng
    // nữa — xem sdModelDir/sdModelId bên dưới. Cần cập nhật SettingsScreen.kt
    // để người dùng chọn đúng "thư mục model" + "id trong model_manifest.json"
    // thay vì 1 file .safetensors/.gguf đơn lẻ (bản MNN cần nhiều file:
    // clip/unet/vae_decoder/vae_encoder/tokenizer trong cùng 1 thư mục).
    @Deprecated("Dùng sdModelDir + sdModelId") val sdModelPath: String = "",
    val llmModelPath: String = "",
    @Deprecated("LoRA giờ merge sẵn lúc convert .mnn (offline), không nạp runtime nữa — xem NOTICE_local-dream.md") val loraPath: String = "",
    @Deprecated("Không dùng ở engine mới") val loraWeight: Float = 0.75f,
    // ── Engine mới (MNN, xem model_manifest.json trong assets) ──────────
    val sdModelDir: String = "",   // thư mục chứa toàn bộ file model (clip/unet/vae...)
    val sdModelId: String = "sd15_manga_base", // phải khớp "id" trong model_manifest.json
    val useOpenCL: Boolean = true, // GPU Adreno; false = ép CPU (chẩn đoán lỗi)
    val imageStyle: ImageStyle = ImageStyle.REALISTIC,
    val panelCount: Int = 6,
    val width: Int = 512,
    val height: Int = 512,
    val steps: Int = 20,
    val cfgScale: Float = 7f,
    val upscaleOption: UpscaleOption = UpscaleOption.X4,
    val nThreads: Int = 4,
    val useVulkan: Boolean = true,
    val useStoryDiffusion: Boolean = true,
    val consistencyStrength: Float = 0.8f,
    val slidingWindowSize: Int = 3,
    // Nhiệt độ
    val thermalThreshold: Int = 42,       // °C dừng lại
    val thermalResumeOffset: Int = 3,     // resume khi xuống threshold - offset
    val autoResume: Boolean = true,
    // Auto-fix mặt/tay (mục 17 TECHNICAL_STATUS.md, ADetailer-style) — dùng
    // MediaPipe FaceDetector+HandLandmarker (ĐÃ có sẵn cho pose, tái dùng,
    // không thêm dependency mới) để tự dò vùng mặt/tay rồi inpaint lại qua
    // sdImg2Img() vừa nối dây (mục 16). Mặc định TẮT vì CHƯA build-test lần
    // nào, và tốn thêm thời gian sinh (1 lượt img2img nữa/panel có phát
    // hiện được vùng). Không bắt được lỗi "dính người" tổng quát — CHỈ mặt/
    // tay (xem giới hạn đã bàn với user).
    val autoFixFacesHands: Boolean = false,
    val autoFixDenoiseStrength: Float = 0.45f,
    // Ultrafix (Hires-fix kiểu Ultimate SD Upscale — mục 16/20
    // TECHNICAL_STATUS.md): vẽ lại NHẸ toàn ảnh SAU khi ESRGAN phóng to,
    // trước auto-fix mặt/tay. Mặc định TẮT (chưa build-test, tốn thêm thời
    // gian đáng kể mỗi panel — chạy full tiled img2img ở độ phân giải cao).
    val useUltrafixRedraw: Boolean = false,
    val ultrafixDenoiseStrength: Float = 0.4f, // "thông số vàng" 0.35-0.45 theo khuyến nghị cộng đồng

    // ── Local/Remote GPU routing (xem RemoteEndpointConfig/BackendRouter.kt) ──
    val routingMode: RoutingMode = RoutingMode.MANUAL,
    val defaultBackend: GenerationBackend = GenerationBackend.LOCAL, // dùng khi panel không override riêng VÀ routingMode=MANUAL
    val remoteEndpoint: RemoteEndpointConfig = RemoteEndpointConfig(),
    // Chỉ dùng khi routingMode=AUTO — hướng dẫn tự nhiên (tiếng Việt) cho LLM
    // quyết định panel nào local/remote. RỖNG = AutoBackendRouter dùng quy tắc
    // an toàn mặc định (fail-safe LOCAL, xem BackendRouter.kt), không tự bịa
    // tiêu chí khi user chưa nói rõ muốn gì.
    val autoRoutingPolicyPrompt: String = "",
    // Quy tắc khai báo trước cho MANUAL (xem ManualRoutingRule ở trên) — CHỈ
    // dùng khi routingMode=MANUAL, không ảnh hưởng AUTO.
    val manualRoutingRules: List<ManualRoutingRule> = emptyList()
)

enum class UpscaleOption(val label: String, val factor: Int, val sharpen: Boolean) {
    NONE("Không upscale", 1, false),
    X2("2× · 1024px", 2, false),
    X4("4× · 2048px", 4, false),
    X4_SHARP("4× · 2048px · Nét hơn", 4, true)
}

enum class ImageStyle(val label: String, val emoji: String, val stylePrompt: String, val negPrompt: String) {
    REALISTIC("Siêu thực", "📷",
        "RAW photo, 8k uhd, dslr, soft lighting, high quality, film grain, photorealistic, sharp focus",
        "cartoon, anime, illustration, 3d render, cgi, lowres, bad quality, watermark, blurry, deformed"),
    ANIME("Anime / Moe", "✨",
        "masterpiece, best quality, ultra-detailed, illustration, vibrant colors, sharp lines, anime style",
        "lowres, bad anatomy, bad hands, text, error, worst quality, jpeg artifacts, watermark, blurry, 3d"),
    MANHWA("Manhwa / Webtoon", "📱",
        "manhwa style, webtoon, clean lineart, flat colors, high contrast, korean comic, professional",
        "blurry, lowres, bad anatomy, photorealistic, 3d render, rough sketch"),
    MANGA("Manga", "📖",
        "manga style, black and white, high contrast, detailed lineart, japanese comic, professional manga",
        "colored, blurry, lowres, bad anatomy, photorealistic"),
    COMIC("Comic / Western", "💥",
        "comic book style, bold lines, vibrant colors, american comic, professional illustration, dynamic",
        "blurry, lowres, bad anatomy, photorealistic, 3d render"),
    CINEMATIC("Điện ảnh", "🎬",
        "cinematic lighting, epic composition, dramatic shadows, movie still, 35mm film, anamorphic lens",
        "cartoon, anime, illustration, amateur, blurry, lowres")
}

// ── Scene & Panel ─────────────────────────────────────────────────────────
data class Scene(
    val index: Int,
    val description: String,
    val characters: List<String>,
    val mood: String,
    val cameraAngle: String,
    val action: String = "",
    val setting: String = "",
    val dialogue: List<DialogueLine> = emptyList()
)

data class DialogueLine(
    val characterName: String,
    val text: String,
    val type: BubbleType = BubbleType.SPEECH
)

// Kết quả LLMParser.buildPrompt() cho 1 panel — mở rộng từ Pair<String,String>
// cũ (positive, negative) để LLM tự chọn thêm pose template THẬT trong
// pose_library.json của user (mục 6 TECHNICAL_STATUS.md — "LLM orchestration").
// poseTemplate = null nghĩa là LLM không thấy template nào hợp, hoặc thư viện
// đang rỗng — MangaPipeline sẽ tự rơi về fallback theo heuristic đơn giản.
data class PromptResult(
    val positive: String,
    val negative: String,
    val poseTemplate: String?,
    val poseAngle: String = "any"
)

// ── Bubble hội thoại ──────────────────────────────────────────────────────
enum class BubbleType { SPEECH, THOUGHT, NARRATION, SHOUT }

data class Bubble(
    val id: String,
    val characterName: String,
    val text: String,
    val type: BubbleType = BubbleType.SPEECH,
    // Vị trí trên ảnh (normalized 0.0-1.0)
    val xNorm: Float = 0.1f,
    val yNorm: Float = 0.05f,
    val widthNorm: Float = 0.4f,
    val isAutoPlaced: Boolean = false  // true = YOLOv8 đặt, false = người dùng đặt
)

// ── Panel ─────────────────────────────────────────────────────────────────
enum class PanelStatus { PENDING, GENERATING, DONE, FAILED, APPROVED, REJECTED }
enum class PanelReviewAction { APPROVE, REJECT, REGENERATE, EDIT_PROMPT }

// ── Setting riêng cho 1 ảnh (tầng "riêng", ưu tiên hơn GenerationSettings
// tầng "chung" khi field khác null). KHÔNG có field LoRA/model — theo
// quyết định đã chốt: LoRA merge chết vào .mnn, không bật/tắt per-ảnh
// được, chỉ chọn được NHÂN VẬT (qua đó gián tiếp chọn model đã convert
// sẵn cho nhân vật đó, xem MangaPipeline.resolveModelIdForCharacter()).
data class PanelOverrideSettings(
    val promptOverride: String? = null,      // sửa tay prompt SD nếu không ưng ý bản LLM tạo
    // Mô tả tự nhiên tiếng Việt cho RIÊNG panel này (mục 24
    // TECHNICAL_STATUS.md) — nếu set, LLM dịch câu này sang tag SD1.5 thay
    // vì dùng mô tả tự động từ parseStory(). Khác promptOverride: đây là
    // NGÔN NGỮ TỰ NHIÊN cần LLM dịch, không phải tag SD1.5 gõ tay trực
    // tiếp. Nếu CẢ HAI đều set, promptOverride (tag SD1.5 tay) ưu tiên hơn
    // — dịch tự nhiên chỉ có tác dụng khi promptOverride để trống.
    val naturalDescriptionOverride: String? = null,
    val negativePrompt: String? = null,
    val characterOverride: String? = null,   // tên nhân vật, override tự-nhận-diện từ LLMParser
    val poseTemplate: String? = null,        // tên template trong pose_library.json
    val poseAngle: String? = null,           // "front"/"side_left"/"side_right"/"any"
    val width: Int? = null,
    val height: Int? = null,
    val steps: Int? = null,
    val cfgScale: Float? = null,
    val seed: Long? = null,
    // null = dùng quyết định của routingMode (MANUAL: defaultBackend; AUTO:
    // LLM tự quyết). Set giá trị cụ thể = ép cứng panel này, LUÔN ưu tiên
    // tuyệt đối hơn AUTO — kể cả AUTO đã quyết định khác, override tay này
    // vẫn thắng (xem BackendRouter.resolve()).
    val backendOverride: GenerationBackend? = null
)

data class Panel(
    val index: Int,
    val scene: Scene,
    val prompt: String,
    val negativePrompt: String,
    // Gợi ý của LLM (mục 6 TECHNICAL_STATUS.md: "LLM orchestration") — LLM tự
    // chọn tên template khớp nhất trong pose_library.json THẬT của user (không
    // đoán mù tên cố định như trước), null = không tìm thấy template nào hợp/
    // thư viện rỗng. Đây là gợi ý, override tầng riêng vẫn ưu tiên hơn.
    val suggestedPoseTemplate: String? = null,
    val suggestedPoseAngle: String = "any",
    // Xung đột IP-Adapter THẬT của panel này (đếm bằng Kotlin, xem
    // StoryManager.detectIpAdapterConflicts) — khác cảnh báo cũ "≥2 nhân
    // vật" chung chung: chỉ true khi ≥2 người trong panel THỰC SỰ dùng
    // IP-Adapter (anchorImagePath) và chưa có model ghép cặp che được.
    val ipAdapterConflictNames: List<String> = emptyList(),
    // Đánh dấu panel này ĐÃ qua auto-fix (Ultrafix và/hoặc auto-fix mặt/tay)
    // ở bước upscale — để Gallery cuối (PostProcessingScreen, mục 22
    // TECHNICAL_STATUS.md) biết panel nào cần user kiểm tra kỹ hơn, thay vì
    // im lặng không báo gì (theo đúng yêu cầu "trong tự động nếu có lỗi thì
    // báo cho người dùng").
    val autoFixApplied: Boolean = false,
    val imagePath: String? = null,           // 512px raw
    val upscaledPath: String? = null,        // sau upscale
    val bubbles: List<Bubble> = emptyList(), // hội thoại
    val status: PanelStatus = PanelStatus.PENDING,
    val generationTimeMs: Long = 0,
    val userNote: String = "",               // ghi chú của người dùng khi edit
    val overrideSettings: PanelOverrideSettings? = null,  // setting riêng ảnh này, null = dùng hết tầng chung
    // Backend THẬT ĐÃ DÙNG để sinh panel này (null = chưa sinh lần nào).
    // Lưu lại kể cả khi routingMode=AUTO đổi policy sau đó — Gallery cần biết
    // ảnh NÀY đã sinh ở đâu (local hay remote) để user quyết định có tin
    // tưởng/regenerate hay không, không suy ngược từ setting hiện tại (có
    // thể đã đổi từ lúc sinh ảnh này).
    val resolvedBackend: GenerationBackend? = null,
    val routingReason: String = ""           // lý do BackendRouter chọn (hiện cho user thấy, đặc biệt quan trọng ở AUTO)
)

// ── Chapter ───────────────────────────────────────────────────────────────
data class Chapter(
    val id: String,
    val storyId: String,
    val title: String,
    val chapterNumber: Int,
    val storyText: String,
    val style: ImageStyle,
    val panels: List<Panel>,
    val pdfPath: String? = null,
    val cbzPath: String? = null,
    val status: ChapterStatus = ChapterStatus.DRAFT,
    val createdAt: Long = System.currentTimeMillis()
) {
    val doneCount get() = panels.count { it.status == PanelStatus.DONE || it.status == PanelStatus.APPROVED }
    val approvedCount get() = panels.count { it.status == PanelStatus.APPROVED }
    val allApproved get() = panels.isNotEmpty() && panels.all { it.status == PanelStatus.APPROVED }
}

enum class ChapterStatus { DRAFT, GENERATING, REVIEW, UPSCALING, DONE }

// ── Pipeline state ────────────────────────────────────────────────────────
data class PipelineState(
    val stage: PipelineStage = PipelineStage.IDLE,
    val currentPanel: Int = 0,
    val totalPanels: Int = 0,
    val currentStep: Int = 0,
    val totalSteps: Int = 20,
    val log: List<LogEntry> = emptyList(),
    val error: String? = null,
    val startTimeMs: Long = 0L,
    val isPaused: Boolean = false,
    val pauseReason: PauseReason? = null,
    val currentTempC: Int = 0
) {
    val elapsedMs get() = if (startTimeMs == 0L) 0L else System.currentTimeMillis() - startTimeMs
    val progressFraction get() = if (totalPanels == 0) 0f else currentPanel.toFloat() / totalPanels
}

enum class PipelineStage {
    IDLE, LLM_PARSING, PROMPT_BUILDING,
    SD_GENERATING, REVIEW,
    UPSCALING, BUBBLE_AUTO,
    LAYOUT_EXPORT, DONE, ERROR
}

enum class PauseReason { THERMAL, USER }

data class LogEntry(val time: String, val message: String, val level: LogLevel = LogLevel.INFO)
enum class LogLevel { INFO, OK, WARN, ERROR }

// ── Thermal state ─────────────────────────────────────────────────────────
data class ThermalState(
    val currentTempC: Int = 0,
    val thresholdC: Int = 42,
    val isOverheating: Boolean = false,
    val history: List<Int> = emptyList() // lịch sử nhiệt độ để vẽ chart
)
