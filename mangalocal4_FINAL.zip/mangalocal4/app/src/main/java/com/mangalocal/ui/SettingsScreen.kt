package com.mangalocal.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*
import com.mangalocal.pipeline.RemoteGenerationClient
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(nav: NavController, vm: MainViewModel) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()
    val llmModels by vm.llmModels.collectAsState()
    var showGuide by remember { mutableStateOf(false) }
    // Model đã convert sẵn (mục 12/14 TECHNICAL_STATUS.md — hệ model_manifest.json
    // mới, KHÁC hẳn settings.sdModelPath/loraPath cũ đã deprecated). LoRA giờ
    // gán RIÊNG từng nhân vật qua CharactersScreen (mục 14), không còn 1
    // "LoRA mặc định" chung cho cả truyện nữa — bỏ hẳn dropdown đó ở đây.
    val convertedModels = remember { vm.storyManager.listConvertedModels() }
    val scope = rememberCoroutineScope()
    var fingerprintResult by remember { mutableStateOf<String?>(null) }
    var fingerprintError by remember { mutableStateOf<String?>(null) }
    var checkingConnection by remember { mutableStateOf(false) }
    var llmApiChecking by remember { mutableStateOf(false) }
    var llmApiResult by remember { mutableStateOf<String?>(null) }
    var llmApiError by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Cài đặt & Model") },
                actions = { IconButton(onClick = { vm.rescanModels(); vm.rescanConsistencySources() }) { Icon(Icons.Default.Refresh, null, tint = C.Blue) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        bottomBar = { AppNavBar(nav, "settings") },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                Surface(onClick = { showGuide = !showGuide }, color = C.PurpleDim, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Purple.copy(0.4f))) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.FolderOpen, null, tint = C.Purple, modifier = Modifier.size(18.dp))
                            Text("📁 Hướng dẫn đặt model", color = C.Purple, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Icon(if (showGuide) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = C.Purple)
                        }
                        if (showGuide) {
                            Spacer(Modifier.height(8.dp))
                            Text(vm.modelSetupGuide(), color = C.T2, fontSize = 11.sp, fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                        }
                    }
                }
            }

            item {
                var showHw by remember { mutableStateOf(false) }
                Surface(onClick = { showHw = !showHw }, color = C.GreenDim, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Green.copy(0.4f))) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Speed, null, tint = C.Green, modifier = Modifier.size(18.dp))
                            Text("⚙️ Tối ưu phần cứng (tự động)", color = C.Green, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Icon(if (showHw) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = C.Green)
                        }
                        Text("Không hardcode cho máy cụ thể — tự phát hiện chipset, GPU, RAM mỗi lần chạy.",
                            color = C.T2, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 4.dp))
                        if (showHw) {
                            Spacer(Modifier.height(8.dp))
                            Text(vm.hardwareSummary(), color = C.T2, fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("trạng thái model")
                    vm.modelStatus().forEach { (name, ok) ->
                        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (ok) Icons.Default.CheckCircle else Icons.Default.Cancel, null,
                                tint = if (ok) C.Green else C.Red, modifier = Modifier.size(16.dp))
                            Text(name, color = C.T1, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Text(if (ok) "sẵn sàng" else "thiếu", color = if (ok) C.Green else C.Red, fontSize = 11.sp)
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("chọn model")
                    // SD Model: chọn theo id trong model_manifest.json (hệ MNN mới),
                    // KHÔNG còn 1 file .safetensors đơn lẻ như trước (mục 9/12
                    // TECHNICAL_STATUS.md — sdModelPath đã deprecated).
                    if (convertedModels.isEmpty()) {
                        Text("Chưa có model nào convert xong — xem hướng dẫn ở trên (prepare_models.yml).",
                            color = C.Orange, fontSize = 11.sp)
                    } else {
                        Text("SD Model (id trong model_manifest.json):", color = C.T3, fontSize = 11.sp)
                        Spacer(Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(convertedModels) { m ->
                                val sel = settings.sdModelId == m.id
                                FilterChip(selected = sel, onClick = { vm.updateSettings { copy(sdModelId = m.id) } },
                                    label = { Text(m.display_name.take(20), fontSize = 11.sp) })
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    ModelDropdown("LLM Model", settings.llmModelPath, llmModels,
                        onSelect = { vm.updateSettings { copy(llmModelPath = it.path) } }, onRescan = { vm.rescanModels() })
                    Spacer(Modifier.height(8.dp))
                    Text("LoRA giờ gán RIÊNG từng nhân vật qua màn hình Nhân vật (mục 14 TECHNICAL_STATUS.md), " +
                        "không còn 1 LoRA mặc định chung ở đây.", color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    Text("Hướng dẫn viết kịch bản cho LLM", color = C.T2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text("Áp dụng cho MỌI truyện — mô tả văn phong, nhịp độ/tốc độ, cách thiết lập bối cảnh, " +
                        "biến tấu/twist bạn muốn, v.v. Để trống = LLM tự quyết hoàn toàn, không ép gì thêm.",
                        color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = settings.llmStoryGuidance,
                        onValueChange = { vm.updateSettings { copy(llmStoryGuidance = it) } },
                        placeholder = { Text(
                            "Ví dụ: văn phong u tối, nhịp độ chậm rãi xây dựng không khí; " +
                            "thiết lập thế giới giả tưởng thời trung cổ; thỉnh thoảng chèn twist bất ngờ ở cuối chương...",
                            fontSize = 11.sp, color = C.T3
                        ) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                        minLines = 3
                    )
                }
            }

            item {
                MlCard {
                    MlLabel("llm ngoài (api — tuỳ chọn, mặc định vẫn dùng model local)")
                    Text("Dùng LLM qua API ngoài (OpenAI/OpenRouter/Groq hay server tự host tương thích OpenAI) " +
                        "THAY VÌ model .gguf local — hữu ích khi máy yếu hoặc muốn model mạnh hơn. " +
                        "⚠ Khác Remote GPU (ảnh): đây là API thật của bên thứ 3, chỉ có TLS chuẩn bảo vệ, " +
                        "không có lớp mã hoá riêng nào của app. Đừng gửi nội dung thực sự riêng tư qua đây.",
                        color = C.Orange, fontSize = 10.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật LLM ngoài", color = C.T1, fontSize = 13.sp)
                            Text("Tắt = luôn dùng model local như trước, không đổi gì cả", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.externalLlm.enabled,
                            onCheckedChange = { vm.updateSettings { copy(externalLlm = externalLlm.copy(enabled = it)) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }

                    if (settings.externalLlm.enabled) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = settings.externalLlm.baseUrl,
                            onValueChange = { vm.updateSettings { copy(externalLlm = externalLlm.copy(baseUrl = it)) } },
                            label = { Text("Base URL (vd https://api.openai.com/v1)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = settings.externalLlm.apiKey,
                            onValueChange = { vm.updateSettings { copy(externalLlm = externalLlm.copy(apiKey = it)) } },
                            label = { Text("API key") },
                            singleLine = true, modifier = Modifier.fillMaxWidth(),
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = settings.externalLlm.modelName,
                            onValueChange = { vm.updateSettings { copy(externalLlm = externalLlm.copy(modelName = it)) } },
                            label = { Text("Tên model (vd gpt-4o-mini, anthropic/claude-3.5-sonnet...)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            enabled = !llmApiChecking && settings.externalLlm.baseUrl.isNotBlank() && settings.externalLlm.modelName.isNotBlank(),
                            onClick = {
                                llmApiChecking = true; llmApiResult = null; llmApiError = null
                                scope.launch {
                                    try {
                                        val reply = com.mangalocal.pipeline.ExternalLlmClient(settings.externalLlm).testConnection()
                                        llmApiResult = reply.trim()
                                    } catch (ex: Exception) {
                                        llmApiError = ex.message ?: "Lỗi không rõ"
                                    } finally { llmApiChecking = false }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (llmApiChecking) "Đang kiểm tra..." else "Kiểm tra kết nối") }
                        llmApiResult?.let { r ->
                            Spacer(Modifier.height(6.dp))
                            Text("✓ API phản hồi: \"$r\"", color = C.Green, fontSize = 11.sp)
                        }
                        llmApiError?.let { err ->
                            Spacer(Modifier.height(6.dp))
                            Text("✗ $err", color = C.Red, fontSize = 11.sp)
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("nhập model (từ file trên máy)")
                    Text("Bộ nhớ app nằm ở Android/data/com.mangalocal/files — khó vào bằng trình quản lý " +
                        "file ngoài trên Android 11+. Dùng các nút dưới đây để chọn file/thư mục TỪ BẤT KỲ ĐÂU " +
                        "(Tải xuống, Google Drive, thẻ nhớ...) — app tự copy vào đúng chỗ cần, không cần tự " +
                        "mò vào thư mục app.", color = C.T3, fontSize = 10.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(10.dp))

                    val pickLlm = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
                        if (it.isNotEmpty()) vm.importLlmModels(it)
                    }
                    val pickLora = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
                        if (it.isNotEmpty()) vm.importLoras(it)
                    }
                    val pickEmbedding = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
                        if (it.isNotEmpty()) vm.importEmbeddingSources(it)
                    }
                    val pickYolo = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
                        if (it.isNotEmpty()) vm.importYoloModels(it)
                    }
                    val pickEsrgan = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
                        if (it.isNotEmpty()) vm.importEsrganModels(it)
                    }

                    MlOutlineBtn("Nhập LLM (.gguf)", onClick = { pickLlm.launch(arrayOf("*/*")) }, icon = Icons.Default.UploadFile)
                    Spacer(Modifier.height(8.dp))
                    MlOutlineBtn("Nhập LoRA (.safetensors)", onClick = { pickLora.launch(arrayOf("*/*")) }, icon = Icons.Default.UploadFile)
                    Spacer(Modifier.height(8.dp))
                    MlOutlineBtn("Nhập embedding gốc (.safetensors)", onClick = { pickEmbedding.launch(arrayOf("*/*")) }, icon = Icons.Default.UploadFile)
                    Spacer(Modifier.height(8.dp))
                    MlOutlineBtn("Nhập model YOLO/MobileSAM (.mnn)", onClick = { pickYolo.launch(arrayOf("*/*")) }, icon = Icons.Default.UploadFile)
                    Spacer(Modifier.height(8.dp))
                    MlOutlineBtn("Nhập model ESRGAN (.mnn)", onClick = { pickEsrgan.launch(arrayOf("*/*")) }, icon = Icons.Default.UploadFile)

                    Spacer(Modifier.height(14.dp))
                    Divider(color = C.Border)
                    Spacer(Modifier.height(10.dp))
                    Text("Model SD (nhiều file: clip/unet/vae.../tokenizer) — chọn CẢ THƯ MỤC chứa các file đó " +
                        "(vd thư mục \"release\" tải từ prepare_models.yml). Đặt tên ID khớp với model_manifest.json " +
                        "để app nhận diện đúng model.", color = C.T3, fontSize = 10.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    var sdModelId by remember { mutableStateOf("") }
                    OutlinedTextField(
                        value = sdModelId, onValueChange = { sdModelId = it },
                        label = { Text("ID model (tên thư mục con trong models/)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    val pickSdFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
                        if (uri != null) {
                            context.contentResolver.takePersistableUriPermission(
                                uri,
                                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            )
                            vm.importSdModelFolder(uri, sdModelId)
                        }
                    }
                    MlOutlineBtn("Chọn thư mục model SD...",
                        onClick = { pickSdFolder.launch(null) }, icon = Icons.Default.FolderOpen)
                }
            }

            item {
                MlCard {
                    MlLabel("kích thước & phong cách")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Kích thước ảnh gốc", color = C.T2, fontSize = 12.sp)
                        Text("${settings.width}x${settings.height}", color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(384, 512, 640, 768).forEach { sz ->
                            val sel = settings.width == sz && settings.height == sz
                            FilterChip(selected = sel, onClick = { vm.updateSettings { copy(width = sz, height = sz) } },
                                label = { Text("${sz}x${sz}", fontSize = 11.sp) })
                        }
                    }
                    Text("512x512 khớp đúng SD1.5 gốc, kích thước khác vẫn chạy được nhưng bố cục có thể lệch tỷ lệ hơn.",
                        color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("Không còn giới hạn số panel — số lớn giờ được LLM viết theo TỪNG ĐỢT nhỏ (chunked) " +
                        "thay vì 1 lần duy nhất, nên không còn bị cắt JSON giữa chừng nữa. Đánh đổi: số càng lớn " +
                        "càng tốn nhiều lượt gọi LLM hơn (chậm hơn khi phân tích truyện, KHÔNG ảnh hưởng tốc độ vẽ ảnh).",
                        color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Số panel/chương", color = C.T2, fontSize = 12.sp)
                        // SỬA (yêu cầu bỏ giới hạn 30): trước đây dùng Slider
                        // valueRange = 1f..30f — Slider cần 1 khoảng CỐ ĐỊNH
                        // nên không thể "không giới hạn" đúng nghĩa. Đổi sang
                        // ô nhập số tự do, chỉ ép tối thiểu 1 (0 panel/số âm
                        // không có nghĩa), không ép trần trên nữa.
                        OutlinedTextField(
                            value = settings.panelCount.toString(),
                            onValueChange = { txt ->
                                val n = txt.filter { it.isDigit() }.toIntOrNull()
                                if (n != null) vm.updateSettings { copy(panelCount = n.coerceAtLeast(1)) }
                                else if (txt.isBlank()) vm.updateSettings { copy(panelCount = 1) }
                            },
                            modifier = Modifier.width(90.dp),
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Style mặc định", color = C.T3, fontSize = 11.sp)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(ImageStyle.values()) { style ->
                            val sel = settings.imageStyle == style
                            FilterChip(selected = sel, onClick = { vm.updateSettings { copy(imageStyle = style) } },
                                label = { Text("${style.emoji} ${style.label}", fontSize = 11.sp) })
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("upscale")
                    UpscaleOption.values().forEach { opt ->
                        val sel = settings.upscaleOption == opt
                        Row(Modifier.fillMaxWidth().clickable { vm.updateSettings { copy(upscaleOption = opt) } }
                            .padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = sel, onClick = { vm.updateSettings { copy(upscaleOption = opt) } },
                                colors = RadioButtonDefaults.colors(selectedColor = C.Blue, unselectedColor = C.T3))
                            Text(opt.label, color = if (sel) C.T1 else C.T2, fontSize = 13.sp)
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("🌡️ kiểm soát nhiệt độ")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Ngưỡng dừng", color = C.T2, fontSize = 12.sp)
                        Text("${settings.thermalThreshold}°C", color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = settings.thermalThreshold.toFloat(),
                        onValueChange = { vm.updateSettings { copy(thermalThreshold = it.toInt()) } },
                        valueRange = 35f..55f,
                        colors = SliderDefaults.colors(thumbColor = C.Red, activeTrackColor = C.Red, inactiveTrackColor = C.Border))
                    Text("Khi vượt ngưỡng, pipeline tự tạm dừng + rung báo động",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Tự động tiếp tục", color = C.T1, fontSize = 13.sp)
                            Text("Khi nguội xuống ngưỡng - 3°C", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.autoResume, onCheckedChange = { vm.updateSettings { copy(autoResume = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("tham số sinh ảnh")
                    @Composable
                    fun SlRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, fmt: String = "%.0f", onChange: (Float) -> Unit) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label, color = C.T2, fontSize = 12.sp)
                            Text(fmt.format(value), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(value = value, onValueChange = onChange, valueRange = range,
                            colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                        Spacer(Modifier.height(4.dp))
                    }
                    SlRow("Steps", settings.steps.toFloat(), 10f..30f) { vm.updateSettings { copy(steps = it.toInt()) } }
                    SlRow("CFG Scale", settings.cfgScale, 3f..15f, "%.1f") { vm.updateSettings { copy(cfgScale = it) } }
                    SlRow("Threads", settings.nThreads.toFloat(), 1f..8f) { vm.updateSettings { copy(nThreads = it.toInt()) } }
                    Divider(color = C.Border, modifier = Modifier.padding(vertical = 8.dp))
                    // ĐÃ THAY "Vulkan GPU" (mục 25 TECHNICAL_STATUS.md — toggle CŨ
                    // KHÔNG được bất kỳ pipeline nào đọc, dead code từ trước khi
                    // đổi engine sang MNN) bằng useOpenCL THẬT — field này mới là
                    // cái ImagePipeline.loadSD() thực sự dùng.
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("OpenCL GPU", color = C.T1, fontSize = 13.sp)
                            Text("Tăng tốc GPU Adreno/Mali qua MNN (tắt = ép CPU, dùng để chẩn đoán lỗi)", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.useOpenCL, onCheckedChange = { vm.updateSettings { copy(useOpenCL = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("🖼️ hires-fix (ultrafix) — mục 16/20")
                    Text("Vẽ lại NHẸ toàn ảnh SAU khi ESRGAN phóng to, trước auto-fix mặt/tay — biến ranh giới " +
                        "nhòe/dính do phóng to thành nét sắc hơn. CHƯA BUILD-TEST, tốn thêm thời gian sinh đáng kể.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật Ultrafix", color = C.T1, fontSize = 13.sp)
                        }
                        Switch(checked = settings.useUltrafixRedraw, onCheckedChange = { vm.updateSettings { copy(useUltrafixRedraw = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                    }
                    if (settings.useUltrafixRedraw) {
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Denoising Strength", color = C.T2, fontSize = 12.sp)
                            Text("%.2f".format(settings.ultrafixDenoiseStrength), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(value = settings.ultrafixDenoiseStrength, onValueChange = { vm.updateSettings { copy(ultrafixDenoiseStrength = it) } },
                            valueRange = 0.2f..0.6f, colors = SliderDefaults.colors(thumbColor = C.Orange, activeTrackColor = C.Orange, inactiveTrackColor = C.Border))
                        Text("Thông số vàng cộng đồng: 0.35-0.45 — thấp hơn giữ nguyên bố cục, cao hơn đổi nhiều chi tiết hơn.",
                            color = C.T3, fontSize = 10.sp)
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("🩹 auto-fix mặt/tay (adetailer-style) — mục 17/20")
                    Text("Tự dò vùng mặt/tay (tái dùng khung xương YOLOv8-pose, KHÔNG cần model riêng — mục 20) " +
                        "rồi vẽ lại qua img2img SAU auto-fix Ultrafix, ở độ phân giải cuối cùng. Không bắt được lỗi " +
                        "\"dính người\" tổng quát — chỉ mặt/tay. CHƯA BUILD-TEST.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật auto-fix mặt/tay", color = C.T1, fontSize = 13.sp)
                        }
                        Switch(checked = settings.autoFixFacesHands, onCheckedChange = { vm.updateSettings { copy(autoFixFacesHands = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                    }
                    if (settings.autoFixFacesHands) {
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Denoising Strength", color = C.T2, fontSize = 12.sp)
                            Text("%.2f".format(settings.autoFixDenoiseStrength), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(value = settings.autoFixDenoiseStrength, onValueChange = { vm.updateSettings { copy(autoFixDenoiseStrength = it) } },
                            valueRange = 0.3f..0.7f, colors = SliderDefaults.colors(thumbColor = C.Orange, activeTrackColor = C.Orange, inactiveTrackColor = C.Border))
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("storydiffusion")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Consistent Self-Attention", color = C.T1, fontSize = 13.sp)
                            Text("Nhất quán mặt + trang phục + vóc dáng", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.useStoryDiffusion, onCheckedChange = { vm.updateSettings { copy(useStoryDiffusion = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                    if (settings.useStoryDiffusion) {
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Mức độ nhất quán", color = C.T2, fontSize = 12.sp)
                            // LƯU Ý: settings.consistencyStrength KHÔNG còn tác dụng ở
                            // engine mới — pipe.set_ip_adapter_scale() bị CỐ ĐỊNH = 1.0
                            // lúc export Python (tools/export_ipa_controlnet_unet.py),
                            // không đổi được lúc runtime. Muốn chỉnh được, phải thêm
                            // "ip_scale" làm input runtime của UNet lúc export lại
                            // (chưa làm). Tạm để slider này hiển thị nhưng không nối
                            // vào logic sinh ảnh.
                            Text("%.0f%%".format(settings.consistencyStrength * 100), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(value = settings.consistencyStrength, onValueChange = { vm.updateSettings { copy(consistencyStrength = it) } },
                            valueRange = 0.3f..1.0f,
                            colors = SliderDefaults.colors(thumbColor = C.Purple, activeTrackColor = C.Purple, inactiveTrackColor = C.Border))
                        Text("⚠ Slider này CHƯA nối vào logic sinh ảnh thật (ip_adapter_scale cố định lúc export, xem comment code) — hiển thị nhưng chưa có tác dụng.",
                            color = C.Orange, fontSize = 10.sp, lineHeight = 13.sp)

                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { nav.navigate("pose_editor") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(6.dp))
                            Text("Vẽ / sửa khung xương tư thế")
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("remote gpu (tuỳ chọn — mặc định vẫn 100% local)")
                    Text("Gửi ảnh sinh ra ngoài Colab/GPU thuê ngoài để nhanh hơn. " +
                        "⚠ Đã mã hoá hybrid RSA+AES giữa máy và server, nhưng CHỦ HẠ TẦNG GPU vẫn có khả năng " +
                        "truy cập dữ liệu lúc đang tính toán trừ khi dùng Confidential-Computing GPU (xem TECHNICAL_STATUS.md). " +
                        "Không dùng cho nội dung thực sự riêng tư/nhạy cảm.",
                        color = C.Orange, fontSize = 10.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật Remote GPU", color = C.T1, fontSize = 13.sp)
                            Text("Tắt = luôn sinh local như trước, không đổi gì cả", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.remoteEndpoint.enabled,
                            onCheckedChange = { vm.updateSettings { copy(remoteEndpoint = remoteEndpoint.copy(enabled = it)) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }

                    if (settings.remoteEndpoint.enabled) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = settings.remoteEndpoint.baseUrl,
                            onValueChange = { vm.updateSettings { copy(remoteEndpoint = remoteEndpoint.copy(baseUrl = it)) } },
                            label = { Text("Base URL (vd https://xxxx.ngrok-free.app)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = settings.remoteEndpoint.authToken,
                            onValueChange = { vm.updateSettings { copy(remoteEndpoint = remoteEndpoint.copy(authToken = it)) } },
                            label = { Text("Auth token (đặt lúc chạy remote_server/app.py)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth(),
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            enabled = !checkingConnection && settings.remoteEndpoint.baseUrl.isNotBlank(),
                            onClick = {
                                checkingConnection = true; fingerprintResult = null; fingerprintError = null
                                scope.launch {
                                    try {
                                        val fp = RemoteGenerationClient(settings.remoteEndpoint).fetchServerFingerprint()
                                        fingerprintResult = fp
                                    } catch (ex: Exception) {
                                        fingerprintError = ex.message ?: "Lỗi không rõ"
                                    } finally { checkingConnection = false }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (checkingConnection) "Đang kiểm tra..." else "Kiểm tra kết nối + lấy fingerprint") }
                        fingerprintResult?.let { fp ->
                            Spacer(Modifier.height(6.dp))
                            Text("✓ Kết nối OK. Fingerprint server:", color = C.Green, fontSize = 11.sp)
                            Text(fp, color = C.T1, fontSize = 10.sp, fontFamily = FontFamily.Monospace, lineHeight = 14.sp)
                            Text("Đối chiếu với fingerprint in ra ở log lúc chạy remote_server/app.py — " +
                                "khớp thì mới chắc chắn không bị bên thứ ba giả mạo server (xem RemoteGenerationClient.kt).",
                                color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                        }
                        fingerprintError?.let { err ->
                            Spacer(Modifier.height(6.dp))
                            Text("✗ $err", color = C.Red, fontSize = 11.sp)
                        }

                        Spacer(Modifier.height(14.dp))
                        Text("Chế độ chọn local/remote", color = C.T2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(RoutingMode.MANUAL to "Thủ công", RoutingMode.AUTO to "Tự động (LLM quyết định)").forEach { (mode, label) ->
                                FilterChip(selected = settings.routingMode == mode,
                                    onClick = { vm.updateSettings { copy(routingMode = mode) } },
                                    label = { Text(label, fontSize = 12.sp) })
                            }
                        }

                        if (settings.routingMode == RoutingMode.MANUAL) {
                            Spacer(Modifier.height(10.dp))
                            Text("Mặc định cho panel không chọn riêng:", color = C.T3, fontSize = 11.sp)
                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(GenerationBackend.LOCAL to "Local", GenerationBackend.REMOTE to "Remote").forEach { (b, label) ->
                                    FilterChip(selected = settings.defaultBackend == b,
                                        onClick = { vm.updateSettings { copy(defaultBackend = b) } },
                                        label = { Text(label, fontSize = 12.sp) })
                                }
                            }
                            Text("Chọn riêng cho từng panel ở Gallery Review (mở panel > Backend) — " +
                                "luôn thắng mọi quy tắc bên dưới.", color = C.T3, fontSize = 10.sp)

                            Spacer(Modifier.height(14.dp))
                            Text("Quy tắc khai báo trước (áp dụng hàng loạt, không cần sinh xong mới chọn):",
                                color = C.T2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("Vd: nhân vật \"Lan\" → luôn Local. Từ khoá \"trong nhà tắm\" → luôn Local. " +
                                "Rule đứng TRÊN thắng khi 1 panel khớp nhiều rule mâu thuẫn.",
                                color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                            Spacer(Modifier.height(6.dp))

                            settings.manualRoutingRules.forEachIndexed { idx, rule ->
                                Row(verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                    Text("${idx + 1}.", color = C.T3, fontSize = 11.sp, modifier = Modifier.width(18.dp))
                                    Text(
                                        (if (rule.matchType == RoutingMatchType.CHARACTER) "Nhân vật: " else "Từ khoá: ") + rule.value,
                                        color = C.T1, fontSize = 12.sp, modifier = Modifier.weight(1f)
                                    )
                                    Text(rule.backend.name, color = if (rule.backend == GenerationBackend.LOCAL) C.Green else C.Blue,
                                        fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 6.dp))
                                    IconButton(onClick = {
                                        vm.updateSettings { copy(manualRoutingRules = manualRoutingRules.filterIndexed { i, _ -> i != idx }) }
                                    }, modifier = Modifier.size(28.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = "Xoá rule", tint = C.T3, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }

                            var newRuleType by remember { mutableStateOf(RoutingMatchType.CHARACTER) }
                            var newRuleValue by remember { mutableStateOf("") }
                            var newRuleBackend by remember { mutableStateOf(GenerationBackend.LOCAL) }

                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(RoutingMatchType.CHARACTER to "Nhân vật", RoutingMatchType.KEYWORD to "Từ khoá").forEach { (t, label) ->
                                    FilterChip(selected = newRuleType == t, onClick = { newRuleType = t },
                                        label = { Text(label, fontSize = 11.sp) })
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            OutlinedTextField(
                                value = newRuleValue, onValueChange = { newRuleValue = it },
                                placeholder = { Text(if (newRuleType == RoutingMatchType.CHARACTER) "Tên nhân vật (đúng như trong kịch bản)" else "Từ khoá xuất hiện trong mô tả cảnh", fontSize = 11.sp) },
                                singleLine = true, modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                listOf(GenerationBackend.LOCAL to "Local", GenerationBackend.REMOTE to "Remote").forEach { (b, label) ->
                                    FilterChip(selected = newRuleBackend == b, onClick = { newRuleBackend = b },
                                        label = { Text(label, fontSize = 11.sp) })
                                }
                                Spacer(Modifier.weight(1f))
                                OutlinedButton(
                                    enabled = newRuleValue.isNotBlank(),
                                    onClick = {
                                        vm.updateSettings { copy(manualRoutingRules = manualRoutingRules + ManualRoutingRule(
                                            matchType = newRuleType, value = newRuleValue.trim(), backend = newRuleBackend)) }
                                        newRuleValue = ""
                                    }
                                ) { Text("Thêm", fontSize = 12.sp) }
                            }
                        } else {
                            Spacer(Modifier.height(10.dp))
                            Text("Hướng dẫn cho LLM (tiếng Việt tự nhiên) — nói rõ panel nào nên local, panel nào remote:",
                                color = C.T3, fontSize = 11.sp)
                            Spacer(Modifier.height(4.dp))
                            OutlinedTextField(
                                value = settings.autoRoutingPolicyPrompt,
                                onValueChange = { vm.updateSettings { copy(autoRoutingPolicyPrompt = it) } },
                                placeholder = { Text("Để trống = dùng quy tắc an toàn mặc định (nhạy cảm→local, còn lại→remote)", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth().height(90.dp)
                            )
                            Text("Panel vẫn có thể override tay ở Gallery Review — override tay LUÔN thắng LLM.",
                                color = C.T3, fontSize = 10.sp)
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("stack kỹ thuật · local mặc định + remote gpu tuỳ chọn")
                    listOf(
                        "🧠 LLM" to "llama.cpp · chia scene + character detection + dịch prompt theo giai đoạn",
                        "🎨 SD 1.5" to "MNN (sd15_cpu) · bất kỳ checkpoint đã convert",
                        "🔄 StoryDiffusion" to "IP-Adapter + ControlNet-Pose (UNet augmented)",
                        "🦴 Pose" to "YOLOv8-pose qua MNN (đã thay MediaPipe — mục 19)",
                        "🩹 Auto-fix mặt/tay" to "tái dùng khung xương YOLOv8-pose, không model riêng (mục 20)",
                        "✂️ Mask thủ công" to "MobileSAM click-to-mask (mục 21)",
                        "🔍 Upscale" to "ESRGAN (4x-UltraSharp) + Ultrafix redraw",
                        "💬 Auto Bubble" to "YOLOv8n qua MNN · object detection",
                        "🌡️ Thermal" to "Kernel thermal_zone · auto pause",
                        "📄 Export" to "PDF + CBZ"
                    ).forEachIndexed { i, (t, d) ->
                        Column(Modifier.padding(vertical = 7.dp)) {
                            Text(t, color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(d, color = C.T3, fontSize = 11.sp)
                        }
                        if (i < 9) Divider(color = C.Border)
                    }
                }
            }
        }
    }
}
