package com.mangalocal.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(nav: NavController, vm: MainViewModel) {
    val settings by vm.settings.collectAsState()
    val llmModels by vm.llmModels.collectAsState()
    var showGuide by remember { mutableStateOf(false) }
    // Model đã convert sẵn (mục 12/14 TECHNICAL_STATUS.md — hệ model_manifest.json
    // mới, KHÁC hẳn settings.sdModelPath/loraPath cũ đã deprecated). LoRA giờ
    // gán RIÊNG từng nhân vật qua CharactersScreen (mục 14), không còn 1
    // "LoRA mặc định" chung cho cả truyện nữa — bỏ hẳn dropdown đó ở đây.
    val convertedModels = remember { vm.storyManager.listConvertedModels() }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Cài đặt & Model") },
                actions = { IconButton(onClick = { vm.rescanModels(); vm.rescanConsistencySources() }) { Icon(Icons.Default.Refresh, null, tint = C.Blue) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        bottomBar = { AppNavBar(nav, "settings") },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                Surface(onClick = { showGuide = !showGuide }, color = C.PurpleDim, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Purple.copy(0.4f))) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.FolderOpen, null, tint = C.Purple, modifier = Modifier.size(18.dp))
                            Text("📁 Hướng dẫn đặt model", color = C.Purple, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Icon(if (showGuide) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = C.Purple)
                        }
                        if (showGuide) {
                            Spacer(Modifier.height(8.dp))
                            Text(vm.modelSetupGuide(), color = C.T2, fontSize = 11.sp, fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                        }
                    }
                }
            }

            item {
                var showHw by remember { mutableStateOf(false) }
                Surface(onClick = { showHw = !showHw }, color = C.GreenDim, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Green.copy(0.4f))) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Speed, null, tint = C.Green, modifier = Modifier.size(18.dp))
                            Text("⚙️ Tối ưu phần cứng (tự động)", color = C.Green, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Icon(if (showHw) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = C.Green)
                        }
                        Text("Không hardcode cho máy cụ thể — tự phát hiện chipset, GPU, RAM mỗi lần chạy.",
                            color = C.T2, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 4.dp))
                        if (showHw) {
                            Spacer(Modifier.height(8.dp))
                            Text(vm.hardwareSummary(), color = C.T2, fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("trạng thái model")
                    vm.modelStatus().forEach { (name, ok) ->
                        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (ok) Icons.Default.CheckCircle else Icons.Default.Cancel, null,
                                tint = if (ok) C.Green else C.Red, modifier = Modifier.size(16.dp))
                            Text(name, color = C.T1, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Text(if (ok) "sẵn sàng" else "thiếu", color = if (ok) C.Green else C.Red, fontSize = 11.sp)
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("chọn model")
                    // SD Model: chọn theo id trong model_manifest.json (hệ MNN mới),
                    // KHÔNG còn 1 file .safetensors đơn lẻ như trước (mục 9/12
                    // TECHNICAL_STATUS.md — sdModelPath đã deprecated).
                    if (convertedModels.isEmpty()) {
                        Text("Chưa có model nào convert xong — xem hướng dẫn ở trên (prepare_models.yml).",
                            color = C.Orange, fontSize = 11.sp)
                    } else {
                        Text("SD Model (id trong model_manifest.json):", color = C.T3, fontSize = 11.sp)
                        Spacer(Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(convertedModels) { m ->
                                val sel = settings.sdModelId == m.id
                                FilterChip(selected = sel, onClick = { vm.updateSettings { copy(sdModelId = m.id) } },
                                    label = { Text(m.display_name.take(20), fontSize = 11.sp) })
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    ModelDropdown("LLM Model", settings.llmModelPath, llmModels,
                        onSelect = { vm.updateSettings { copy(llmModelPath = it.path) } }, onRescan = { vm.rescanModels() })
                    Spacer(Modifier.height(8.dp))
                    Text("LoRA giờ gán RIÊNG từng nhân vật qua màn hình Nhân vật (mục 14 TECHNICAL_STATUS.md), " +
                        "không còn 1 LoRA mặc định chung ở đây.", color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                }
            }

            item {
                MlCard {
                    MlLabel("kích thước & phong cách")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Kích thước ảnh gốc", color = C.T2, fontSize = 12.sp)
                        Text("${settings.width}x${settings.height}", color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(384, 512, 640, 768).forEach { sz ->
                            val sel = settings.width == sz && settings.height == sz
                            FilterChip(selected = sel, onClick = { vm.updateSettings { copy(width = sz, height = sz) } },
                                label = { Text("${sz}x${sz}", fontSize = 11.sp) })
                        }
                    }
                    Text("512x512 khớp đúng SD1.5 gốc, kích thước khác vẫn chạy được nhưng bố cục có thể lệch tỷ lệ hơn.",
                        color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Số panel/chương", color = C.T2, fontSize = 12.sp)
                        Text("${settings.panelCount}", color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Slider(value = settings.panelCount.toFloat(), onValueChange = { vm.updateSettings { copy(panelCount = it.toInt()) } },
                        valueRange = 1f..30f, colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                    Spacer(Modifier.height(10.dp))
                    Text("Style mặc định", color = C.T3, fontSize = 11.sp)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(ImageStyle.values()) { style ->
                            val sel = settings.imageStyle == style
                            FilterChip(selected = sel, onClick = { vm.updateSettings { copy(imageStyle = style) } },
                                label = { Text("${style.emoji} ${style.label}", fontSize = 11.sp) })
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("upscale")
                    UpscaleOption.values().forEach { opt ->
                        val sel = settings.upscaleOption == opt
                        Row(Modifier.fillMaxWidth().clickable { vm.updateSettings { copy(upscaleOption = opt) } }
                            .padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = sel, onClick = { vm.updateSettings { copy(upscaleOption = opt) } },
                                colors = RadioButtonDefaults.colors(selectedColor = C.Blue, unselectedColor = C.T3))
                            Text(opt.label, color = if (sel) C.T1 else C.T2, fontSize = 13.sp)
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("🌡️ kiểm soát nhiệt độ")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Ngưỡng dừng", color = C.T2, fontSize = 12.sp)
                        Text("${settings.thermalThreshold}°C", color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = settings.thermalThreshold.toFloat(),
                        onValueChange = { vm.updateSettings { copy(thermalThreshold = it.toInt()) } },
                        valueRange = 35f..55f,
                        colors = SliderDefaults.colors(thumbColor = C.Red, activeTrackColor = C.Red, inactiveTrackColor = C.Border))
                    Text("Khi vượt ngưỡng, pipeline tự tạm dừng + rung báo động",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Tự động tiếp tục", color = C.T1, fontSize = 13.sp)
                            Text("Khi nguội xuống ngưỡng - 3°C", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.autoResume, onCheckedChange = { vm.updateSettings { copy(autoResume = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("tham số sinh ảnh")
                    @Composable
                    fun SlRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, fmt: String = "%.0f", onChange: (Float) -> Unit) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label, color = C.T2, fontSize = 12.sp)
                            Text(fmt.format(value), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(value = value, onValueChange = onChange, valueRange = range,
                            colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                        Spacer(Modifier.height(4.dp))
                    }
                    SlRow("Steps", settings.steps.toFloat(), 10f..30f) { vm.updateSettings { copy(steps = it.toInt()) } }
                    SlRow("CFG Scale", settings.cfgScale, 3f..15f, "%.1f") { vm.updateSettings { copy(cfgScale = it) } }
                    SlRow("Threads", settings.nThreads.toFloat(), 1f..8f) { vm.updateSettings { copy(nThreads = it.toInt()) } }
                    Divider(color = C.Border, modifier = Modifier.padding(vertical = 8.dp))
                    // ĐÃ THAY "Vulkan GPU" (mục 25 TECHNICAL_STATUS.md — toggle CŨ
                    // KHÔNG được bất kỳ pipeline nào đọc, dead code từ trước khi
                    // đổi engine sang MNN) bằng useOpenCL THẬT — field này mới là
                    // cái ImagePipeline.loadSD() thực sự dùng.
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("OpenCL GPU", color = C.T1, fontSize = 13.sp)
                            Text("Tăng tốc GPU Adreno/Mali qua MNN (tắt = ép CPU, dùng để chẩn đoán lỗi)", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.useOpenCL, onCheckedChange = { vm.updateSettings { copy(useOpenCL = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("🖼️ hires-fix (ultrafix) — mục 16/20")
                    Text("Vẽ lại NHẸ toàn ảnh SAU khi ESRGAN phóng to, trước auto-fix mặt/tay — biến ranh giới " +
                        "nhòe/dính do phóng to thành nét sắc hơn. CHƯA BUILD-TEST, tốn thêm thời gian sinh đáng kể.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật Ultrafix", color = C.T1, fontSize = 13.sp)
                        }
                        Switch(checked = settings.useUltrafixRedraw, onCheckedChange = { vm.updateSettings { copy(useUltrafixRedraw = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                    }
                    if (settings.useUltrafixRedraw) {
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Denoising Strength", color = C.T2, fontSize = 12.sp)
                            Text("%.2f".format(settings.ultrafixDenoiseStrength), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(value = settings.ultrafixDenoiseStrength, onValueChange = { vm.updateSettings { copy(ultrafixDenoiseStrength = it) } },
                            valueRange = 0.2f..0.6f, colors = SliderDefaults.colors(thumbColor = C.Orange, activeTrackColor = C.Orange, inactiveTrackColor = C.Border))
                        Text("Thông số vàng cộng đồng: 0.35-0.45 — thấp hơn giữ nguyên bố cục, cao hơn đổi nhiều chi tiết hơn.",
                            color = C.T3, fontSize = 10.sp)
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("🩹 auto-fix mặt/tay (adetailer-style) — mục 17/20")
                    Text("Tự dò vùng mặt/tay (tái dùng khung xương YOLOv8-pose, KHÔNG cần model riêng — mục 20) " +
                        "rồi vẽ lại qua img2img SAU auto-fix Ultrafix, ở độ phân giải cuối cùng. Không bắt được lỗi " +
                        "\"dính người\" tổng quát — chỉ mặt/tay. CHƯA BUILD-TEST.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật auto-fix mặt/tay", color = C.T1, fontSize = 13.sp)
                        }
                        Switch(checked = settings.autoFixFacesHands, onCheckedChange = { vm.updateSettings { copy(autoFixFacesHands = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                    }
                    if (settings.autoFixFacesHands) {
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Denoising Strength", color = C.T2, fontSize = 12.sp)
                            Text("%.2f".format(settings.autoFixDenoiseStrength), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(value = settings.autoFixDenoiseStrength, onValueChange = { vm.updateSettings { copy(autoFixDenoiseStrength = it) } },
                            valueRange = 0.3f..0.7f, colors = SliderDefaults.colors(thumbColor = C.Orange, activeTrackColor = C.Orange, inactiveTrackColor = C.Border))
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("storydiffusion")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Consistent Self-Attention", color = C.T1, fontSize = 13.sp)
                            Text("Nhất quán mặt + trang phục + vóc dáng", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.useStoryDiffusion, onCheckedChange = { vm.updateSettings { copy(useStoryDiffusion = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                    if (settings.useStoryDiffusion) {
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Mức độ nhất quán", color = C.T2, fontSize = 12.sp)
                            // LƯU Ý: settings.consistencyStrength KHÔNG còn tác dụng ở
                            // engine mới — pipe.set_ip_adapter_scale() bị CỐ ĐỊNH = 1.0
                            // lúc export Python (tools/export_ipa_controlnet_unet.py),
                            // không đổi được lúc runtime. Muốn chỉnh được, phải thêm
                            // "ip_scale" làm input runtime của UNet lúc export lại
                            // (chưa làm). Tạm để slider này hiển thị nhưng không nối
                            // vào logic sinh ảnh.
                            Text("%.0f%%".format(settings.consistencyStrength * 100), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(value = settings.consistencyStrength, onValueChange = { vm.updateSettings { copy(consistencyStrength = it) } },
                            valueRange = 0.3f..1.0f,
                            colors = SliderDefaults.colors(thumbColor = C.Purple, activeTrackColor = C.Purple, inactiveTrackColor = C.Border))
                        Text("⚠ Slider này CHƯA nối vào logic sinh ảnh thật (ip_adapter_scale cố định lúc export, xem comment code) — hiển thị nhưng chưa có tác dụng.",
                            color = C.Orange, fontSize = 10.sp, lineHeight = 13.sp)

                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { nav.navigate("pose_editor") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(6.dp))
                            Text("Vẽ / sửa khung xương tư thế")
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("stack kỹ thuật · 100% local")
                    listOf(
                        "🧠 LLM" to "llama.cpp · chia scene + character detection + dịch prompt theo giai đoạn",
                        "🎨 SD 1.5" to "MNN (sd15_cpu) · bất kỳ checkpoint đã convert",
                        "🔄 StoryDiffusion" to "IP-Adapter + ControlNet-Pose (UNet augmented)",
                        "🦴 Pose" to "YOLOv8-pose qua MNN (đã thay MediaPipe — mục 19)",
                        "🩹 Auto-fix mặt/tay" to "tái dùng khung xương YOLOv8-pose, không model riêng (mục 20)",
                        "✂️ Mask thủ công" to "MobileSAM click-to-mask (mục 21)",
                        "🔍 Upscale" to "ESRGAN (4x-UltraSharp) + Ultrafix redraw",
                        "💬 Auto Bubble" to "YOLOv8n qua MNN · object detection",
                        "🌡️ Thermal" to "Kernel thermal_zone · auto pause",
                        "📄 Export" to "PDF + CBZ"
                    ).forEachIndexed { i, (t, d) ->
                        Column(Modifier.padding(vertical = 7.dp)) {
                            Text(t, color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(d, color = C.T3, fontSize = 11.sp)
                        }
                        if (i < 9) Divider(color = C.Border)
                    }
                }
            }
        }
    }
}
