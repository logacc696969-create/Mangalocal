package com.mangalocal.pipeline

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.mangalocal.model.ThermalState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File

class ThermalMonitor(private val context: Context) {

    private val _state = MutableStateFlow(ThermalState())
    val state: StateFlow<ThermalState> = _state.asStateFlow()

    private var job: Job? = null
    private val historyMax = 60 // 60 điểm = 1 phút nếu poll mỗi giây

    // Đọc nhiệt độ từ thermal zone của kernel Linux
    private fun readTempC(): Int {
        val zones = File("/sys/class/thermal").listFiles()
            ?.filter { it.name.startsWith("thermal_zone") } ?: return 0

        val temps = zones.mapNotNull { zone ->
            try {
                val type = File(zone, "type").readText().trim()
                // Ưu tiên CPU/SOC temperature
                if (type.contains("cpu", ignoreCase = true) ||
                    type.contains("soc", ignoreCase = true) ||
                    type.contains("skin", ignoreCase = true)) {
                    File(zone, "temp").readText().trim().toIntOrNull()?.div(1000)
                } else null
            } catch (e: Exception) { null }
        }

        return if (temps.isNotEmpty()) temps.max() else {
            // Fallback: đọc zone đầu tiên có thể đọc được
            zones.firstNotNullOfOrNull { zone ->
                try { File(zone, "temp").readText().trim().toIntOrNull()?.div(1000) }
                catch (e: Exception) { null }
            } ?: 0
        }
    }

    fun start(thresholdC: Int) {
        job?.cancel()
        job = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                val temp = readTempC()
                val overheating = temp >= thresholdC
                val history = (_state.value.history + temp).takeLast(historyMax)

                _state.update {
                    it.copy(
                        currentTempC = temp,
                        thresholdC = thresholdC,
                        isOverheating = overheating,
                        history = history
                    )
                }

                if (overheating) vibrateAlert()
                delay(1000)
            }
        }
    }

    fun stop() { job?.cancel() }

    fun updateThreshold(thresholdC: Int) {
        _state.update { it.copy(thresholdC = thresholdC) }
    }

    private fun vibrateAlert() {
        try {
            val vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 200, 300), -1))
        } catch (e: Exception) { /* ignore */ }
    }

    fun isSafeToRun(resumeOffset: Int = 3): Boolean {
        val s = _state.value
        return s.currentTempC < s.thresholdC - resumeOffset
    }

    val tempColor: Long get() {
        val t = _state.value.currentTempC
        return when {
            t < 35 -> 0xFF4CAF50 // xanh lá
            t < 40 -> 0xFFFF9800 // cam
            t < 45 -> 0xFFFF5722 // cam đỏ
            else   -> 0xFFEF5350 // đỏ
        }
    }
}
