package com.mangalocal.pipeline

import android.app.*
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.mangalocal.MainActivity

class GenerationService : Service() {
    inner class LocalBinder : Binder() { fun get() = this@GenerationService }
    private val binder = LocalBinder()
    private val CH = "manga_gen"

    override fun onCreate() { super.onCreate(); createChannel() }
    override fun onBind(i: Intent): IBinder = binder
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startForeground(1, buildNotif("Đang tạo truyện tranh...")); return START_STICKY
    }

    fun update(text: String) = getSystemService(NotificationManager::class.java).notify(1, buildNotif(text))
    fun stop() { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }

    private fun buildNotif(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH)
            .setContentTitle("MangaLocal").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentIntent(pi).setOngoing(true).build()
    }

    private fun createChannel() {
        NotificationChannel(CH, "Tạo truyện", NotificationManager.IMPORTANCE_LOW)
            .also { getSystemService(NotificationManager::class.java).createNotificationChannel(it) }
    }
}
