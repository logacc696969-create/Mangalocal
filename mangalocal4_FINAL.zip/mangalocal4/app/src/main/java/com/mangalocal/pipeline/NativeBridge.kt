package com.mangalocal.pipeline

object NativeBridge {
    init { System.loadLibrary("mangalocal_native") }

    // ── LLM ──────────────────────────────────────────────────────────────
    external fun llamaInit(modelPath: String, nThreads: Int, nCtx: Int, nGpuLayers: Int): Long
    external fun llamaGenerate(ctx: Long, prompt: String, maxTokens: Int, temperature: Float): String
    external fun llamaFree(ctx: Long)

    // ── Stable Diffusion (MNN) ──────────────────────────────────────────
    // CHỮ KÝ GIỮ NGUYÊN như bản sd.cpp cũ để không phải sửa ImagePipeline.kt/
    // MainViewModel.kt ở bước này, nhưng PHẦN NATIVE HIỆN LÀ STUB — mọi
    // hàm sd* trả về thất bại (0 / false) cho tới khi jni/mnn_diffusion_
    // pipeline.cpp được viết xong (xem MangaLocal_Technical_Handoff.md
    // mục 6). Không gọi các hàm này trong luồng chính cho tới lúc đó.
    // ĐỔI CHỮ KÝ (xem ghi chú trong ImagePipeline.kt/model_manifest.json):
    // modelDir = thư mục chứa clip/unet/vae*/tokenizer của 1 model,
    // modelId = phải khớp "id" trong assets/model_manifest.json.
    external fun sdInit(modelDir: String, modelId: String, useOpenCL: Boolean, embeddingsDir: String): Long
    external fun sdTxt2Img(ctx: Long, prompt: String, negPrompt: String, width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long, outputPath: String, callback: SDProgressCallback): Boolean
    // ── img2img / inpaint / Ultrafix (upscale-vẽ-lại) THẬT (mục 16
    // TECHNICAL_STATUS.md) — dùng chung ctx đã sdInit()/sdInitAugmented(),
    // KHÔNG cần init riêng. maskImagePath = "" nghĩa là img2img thường
    // (không mask, vẽ lại toàn ảnh ở denoiseStrength cho trước); có mask
    // nghĩa là inpaint thật (chỉ vẽ lại vùng trắng trong mask). ultrafix=true
    // dùng cho upscale-vẽ-lại (Ultimate SD Upscale-style): width/height lúc
    // này là kích thước ĐÍCH đã upscale (lớn hơn 512), ultrafixTile = kích
    // thước tile gốc model (mặc định 512, khớp SD1.5).
    external fun sdImg2Img(ctx: Long, prompt: String, negPrompt: String, inputImagePath: String,
                           maskImagePath: String, denoiseStrength: Float, width: Int, height: Int,
                           steps: Int, cfgScale: Float, seed: Long, ultrafix: Boolean, ultrafixTile: Int,
                           outputPath: String, callback: SDProgressCallback): Boolean
    // ── Nhất quán nhân vật + tư thế (IP-Adapter + ControlNet-Pose) ──────
    // Dùng UNet ĐÃ RE-EXPORT riêng (xem tools/export_ipa_controlnet_unet.py)
    // — KHÁC unet.mnn thường dùng trong sdInit(), không dùng lẫn được.
    // clip/vaeDecoder/vaeEncoder vẫn dùng chung với model gốc (không đổi).
    // embeddingsDir: thư mục .safetensors Textual Inversion (mục 12
    // TECHNICAL_STATUS.md — phương pháp thứ 3, độc lập LoRA/IP-Adapter,
    // hoạt động ở tầng text-encoder nên không đụng UNet/ip_image_embeds).
    external fun sdInitAugmented(modelDir: String, clipPath: String, unetAugmentedPath: String,
                                  vaeDecoderPath: String, vaeEncoderPath: String,
                                  ipEncoderPath: String, tokenizerPath: String, embeddingsDir: String): Long
    // skeletonData: toạ độ khung xương ĐÃ RETARGET theo tỷ lệ từng nhân vật
    // (mục 32/33 TECHNICAL_STATUS.md — tính ở PoseRetargeter.kt), mảng
    // phẳng mỗi người 18 khớp * 4 giá trị (x,y,z,visible 0/1) = 72 float/
    // người. Mảng rỗng -> native tự dùng fallback đứng đơn giản. KHÔNG còn
    // truyền tên template/đường dẫn thư viện — native không tự đọc/chọn
    // pose nữa (đổi kiến trúc, giải quyết luôn lỗ hổng "skeleton không biết
    // ai là ai" — mục 12).
    external fun sdTxt2ImgWithReferenceAndPose(ctx: Long, prompt: String, negPrompt: String,
                                                referenceImagePath: String, skeletonData: FloatArray,
                                                width: Int, height: Int, steps: Int, cfgScale: Float,
                                                seed: Long, outputPath: String): Boolean
    external fun sdFreeAugmented(ctx: Long)
    external fun sdFree(ctx: Long)

    // Convert on-device: dir chứa "checkpoint.safetensors" + tuỳ chọn
    // "lora1.safetensors"... + BẮT BUỘC đã có sẵn unet.mnn/vae_decoder.mnn/
    // vae_encoder.mnn "khung" từ trước (xem sd_model_converter.cpp).
    // KHÔNG cần sdInit trước — đây là tool độc lập, chạy 1 lần trước khi
    // model đó dùng được trong sdInit.
    external fun sdConvertModel(dir: String, safetensorFile: String, clipSkip2: Boolean,
                                 loraFiles: Array<String>, loraWeights: FloatArray): Boolean

    // ── ESRGAN ───────────────────────────────────────────────────────────
    external fun esrganInit(scale: Int, modelDir: String): Long
    external fun esrganUpscale(ctx: Long, inputPath: String, outputPath: String, sharpen: Boolean): Boolean
    external fun esrganFree(ctx: Long)

    // ── YOLOv8n (object/face detection cho auto bubble) ──────────────────
    external fun yoloInit(modelDir: String): Long
    external fun yoloDetect(ctx: Long, imagePath: String): FloatArray // [x1,y1,x2,y2,conf, ...] normalized
    external fun yoloFree(ctx: Long)

    // ── YOLOv8-pose (mục 19 TECHNICAL_STATUS.md — thay MediaPipe Pose) ──
    // Trả về mảng float phẳng, mỗi người 56 giá trị liên tiếp:
    // [x1,y1,x2,y2,conf, kp0_x,kp0_y,kp0_vis, ..., kp16_x,kp16_y,kp16_vis]
    // (17 keypoint COCO chuẩn Ultralytics, x/y normalized 0..1, vis 0..1).
    // Map sang OpenPose-18 làm ở Kotlin (PoseExtractor.kt), không ở native.
    external fun yoloPoseInit(modelDir: String): Long
    external fun yoloPoseDetect(ctx: Long, imagePath: String, confThresh: Float, iouThresh: Float): FloatArray
    external fun yoloPoseFree(ctx: Long)

    // ── MobileSAM click-to-mask (mục 21 TECHNICAL_STATUS.md — "Inpaint
    // Anything" cho UI mask thủ công ở phase cuối) ──
    // Trả về đường dẫn PNG mask đã ghi (trắng=inpaint, đen=giữ nguyên —
    // cùng quy ước buildMaskFile() trong MangaPipeline.kt), feed thẳng vào
    // sdImg2Img() — CÙNG 1 inpainting với auto-fix mặt/tay, không tách riêng.
    external fun mobileSamInit(modelDir: String): Long
    external fun mobileSamClickToMask(ctx: Long, imagePath: String, clickX: Float, clickY: Float, outMaskPath: String): String
    external fun mobileSamFree(ctx: Long)

    interface SDProgressCallback {
        fun onProgress(step: Int, totalSteps: Int)
    }
}
