package com.mangalocal.pipeline

import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.mangalocal.model.*
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ExportEngine {

    fun exportPdf(panels: List<Panel>, outDir: File, title: String): String {
        val doc = PdfDocument()
        val pw = 595; val ph = 842

        panels.chunked(2).forEachIndexed { pageIdx, chunk ->
            val info = PdfDocument.PageInfo.Builder(pw, ph, pageIdx + 1).create()
            val page = doc.startPage(info)
            val c = page.canvas
            c.drawColor(Color.WHITE)

            if (pageIdx == 0) {
                c.drawText(title, 20f, 28f, Paint().apply {
                    color = Color.BLACK; textSize = 16f
                    typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true
                })
            }

            val topPad = if (pageIdx == 0) 42f else 12f
            val halfH = (ph - topPad - 20f) / 2f

            chunk.forEachIndexed { i, panel ->
                val imgPath = panel.upscaledPath ?: panel.imagePath ?: return@forEachIndexed
                val bmp = BitmapFactory.decodeFile(imgPath) ?: return@forEachIndexed
                val top = topPad + if (i == 0) 0f else halfH + 8f
                val dst = RectF(12f, top, pw - 12f, top + halfH - 4f)

                c.drawRect(dst, Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f })
                c.drawBitmap(bmp, null, dst, null)
                bmp.recycle()

                // Vẽ bubble theo vị trí normalized đã lưu trong panel
                panel.bubbles.forEach { bubble -> drawBubbleAtPosition(c, bubble, dst) }

                c.drawText("#${panel.index + 1}", dst.left + 4f, dst.bottom - 4f,
                    Paint().apply { color = Color.DKGRAY; textSize = 8f; isAntiAlias = true })
            }
            doc.finishPage(page)
        }

        val out = File(outDir, "chapter.pdf")
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
        return out.absolutePath
    }

    fun exportCbz(panels: List<Panel>, outDir: File): String {
        val out = File(outDir, "chapter.cbz")
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            panels.forEach { panel ->
                val path = panel.upscaledPath ?: panel.imagePath ?: return@forEach
                val file = File(path)
                if (!file.exists()) return@forEach
                zip.putNextEntry(ZipEntry("panel_%03d.png".format(panel.index + 1)))
                file.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
        return out.absolutePath
    }

    /**
     * Render ảnh panel kèm bubble thành 1 bitmap hoàn chỉnh (dùng cho preview trong app)
     */
    fun renderPanelWithBubbles(imagePath: String, bubbles: List<Bubble>): Bitmap? {
        val original = BitmapFactory.decodeFile(imagePath) ?: return null
        val result = original.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val rect = RectF(0f, 0f, result.width.toFloat(), result.height.toFloat())
        bubbles.forEach { drawBubbleAtPosition(canvas, it, rect) }
        return result
    }

    private fun drawBubbleAtPosition(canvas: Canvas, bubble: Bubble, panelRect: RectF) {
        val bx = panelRect.left + bubble.xNorm * panelRect.width()
        val by = panelRect.top + bubble.yNorm * panelRect.height()
        val bw = bubble.widthNorm * panelRect.width()
        val bh = 0.10f * panelRect.height()

        val rect = RectF(bx, by, bx + bw, by + bh)
        val cornerRadius = bh * 0.25f

        val bgColor = when (bubble.type) {
            BubbleType.THOUGHT -> Color.argb(240, 245, 245, 255)
            BubbleType.SHOUT -> Color.argb(240, 255, 245, 230)
            BubbleType.NARRATION -> Color.argb(220, 255, 255, 220)
            else -> Color.WHITE
        }

        canvas.drawRoundRect(rect, cornerRadius, cornerRadius,
            Paint().apply { color = bgColor; style = Paint.Style.FILL; isAntiAlias = true })
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius,
            Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = bh * 0.04f; isAntiAlias = true })

        val nameSize = bh * 0.18f
        val textSize = bh * 0.22f

        canvas.drawText(bubble.characterName, rect.left + bw*0.04f, rect.top + bh*0.28f,
            Paint().apply { color = Color.DKGRAY; this.textSize = nameSize; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true })

        val maxChars = (bw / (textSize * 0.55f)).toInt().coerceAtLeast(10)
        val text = if (bubble.text.length > maxChars) bubble.text.take(maxChars - 1) + "…" else bubble.text
        canvas.drawText(text, rect.left + bw*0.04f, rect.top + bh*0.62f,
            Paint().apply { color = Color.BLACK; this.textSize = textSize; isAntiAlias = true })
    }
}
