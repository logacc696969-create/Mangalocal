package com.mangalocal

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Bắt crash toàn app, ghi stack trace ra file NỘI BỘ (filesDir — luôn ghi
// được, không cần xin quyền gì, không phụ thuộc Android/data hay quét bằng
// file manager ngoài). MainActivity đọc + xoá file này lúc mở lên, hiện
// ngay trong dialog kèm nút Copy — không cần app logcat, không cần
// Shizuku/ADB, không cần máy thứ 2.
class MangaLocalApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                File(filesDir, "last_crash.txt").writeText("[$ts]\n\n$sw")
            } catch (_: Throwable) {
                // Ghi log thất bại thì thôi, không được để việc ghi log lại
                // chặn luôn tiến trình crash-handler mặc định bên dưới.
            }
            // Vẫn gọi handler mặc định — app vẫn "tiếp tục dừng" như bình
            // thường, chỉ thêm bước ghi log trước đó.
            previousHandler?.uncaughtException(thread, throwable)
                ?: android.os.Process.killProcess(android.os.Process.myPid())
        }
    }
}
