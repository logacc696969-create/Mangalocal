package com.mangalocal

import android.app.Application
import com.mangalocal.pipeline.NativeBridge
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Bắt crash toàn app, ghi stack trace ra file NỘI BỘ (filesDir — luôn ghi
// được, không cần xin quyền gì, không phụ thuộc Android/data hay quét bằng
// file manager ngoài). MainActivity đọc + xoá file này lúc mở lên, hiện
// ngay trong dialog kèm nút Copy — không cần app logcat, không cần
// Shizuku/ADB, không cần máy thứ 2.
//
// LƯU Ý: cơ chế này (Thread.UncaughtExceptionHandler) CHỈ bắt được lỗi
// Java/Kotlin — crash thật ở tầng C++ (native) là tín hiệu hệ điều hành,
// không đi qua đường này. Xem thêm native_crash_handler.cpp: nó bắt crash
// native, ghi ra file riêng (last_native_crash.txt) — được đăng ký đường
// dẫn ngay bên dưới, càng sớm càng tốt trong vòng đời app.
class MangaLocalApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                File(filesDir, "last_crash.txt").writeText("[$ts]\n\n$sw")
            } catch (_: Throwable) {
                // Ghi log thất bại thì thôi, không được để việc ghi log lại
                // chặn luôn tiến trình crash-handler mặc định bên dưới.
            }
            // Vẫn gọi handler mặc định — app vẫn "tiếp tục dừng" như bình
            // thường, chỉ thêm bước ghi log trước đó.
            previousHandler?.uncaughtException(thread, throwable)
                ?: android.os.Process.killProcess(android.os.Process.myPid())
        }

        // Đăng ký đường dẫn file log crash NATIVE càng sớm càng tốt. Việc
        // chạm vào NativeBridge ở đây khiến System.loadLibrary() chạy ngay
        // lúc này (thay vì đợi tới loadSD() như thiết kế ban đầu) — CỐ Ý:
        // nếu app crash ngay lúc dlopen thư viện .so, ta muốn chuyện đó xảy
        // ra sớm, trong lúc signal handler (constructor ưu tiên cao trong
        // native_crash_handler.cpp) đã có cơ hội cài đặt xong.
        try {
            NativeBridge.setCrashLogPath(File(filesDir, "last_native_crash.txt").absolutePath)
        } catch (_: Throwable) {
            // Nếu chính System.loadLibrary() ném UnsatisfiedLinkError ở đây,
            // đó là lỗi Java bình thường -> Thread handler ở trên vẫn bắt
            // được, ghi vào last_crash.txt như mọi exception khác.
        }
    }
}
