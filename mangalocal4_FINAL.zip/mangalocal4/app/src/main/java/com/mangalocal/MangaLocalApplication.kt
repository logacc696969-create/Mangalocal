package com.mangalocal

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Bắt crash toàn app, ghi stack trace ra file NỘI BỘ (filesDir — luôn ghi
// được, không cần xin quyền gì, không phụ thuộc Android/data hay quét bằng
// file manager ngoài). MainActivity đọc + xoá file này lúc mở lên, hiện
// ngay trong dialog kèm nút Copy — không cần app logcat, không cần
// Shizuku/ADB, không cần máy thứ 2.
//
// LƯU Ý: cơ chế này (Thread.UncaughtExceptionHandler) CHỈ bắt được lỗi
// Java/Kotlin — crash thật ở tầng C++ (native) là tín hiệu hệ điều hành,
// không đi qua đường này. Xem native_crash_handler.cpp cho phần đó.
//
// SỬA (sau phản hồi "chưa kịp vẽ giao diện đã văng"): trước đây file này
// CHỦ ĐỘNG chạm vào NativeBridge (System.loadLibrary) ngay trong
// Application.onCreate() — tức là TRƯỚC KHI có bất kỳ khung hình UI nào
// được vẽ. Nếu native lib crash ngay lúc nạp, cả app chết trước khi kịp vẽ
// gì cả — không cách nào biết được "trước khi vẽ UI" nghĩa là do native
// hay do cái gì khác. Giờ bỏ hẳn việc chạm NativeBridge ở đây — để
// MainActivity vẽ xong 1 khung hình UI cơ bản TRƯỚC, rồi mới thử native
// SAU (xem MainActivity.kt, LaunchedEffect trong MangaLocalApp) — tách
// bạch rõ 2 khả năng: (1) crash ngay cả với bước này bỏ đi -> lỗi KHÔNG
// liên quan native, nằm ở Compose/Activity/theme...; (2) UI vẽ được bình
// thường, crash chỉ xảy ra SAU khi chạm NativeBridge -> xác nhận chắc chắn
// là do thư viện native.
class MangaLocalApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                File(filesDir, "last_crash.txt").writeText("[$ts]\n\n$sw")
            } catch (_: Throwable) {
                // Ghi log thất bại thì thôi, không được để việc ghi log lại
                // chặn luôn tiến trình crash-handler mặc định bên dưới.
            }
            // Vẫn gọi handler mặc định — app vẫn "tiếp tục dừng" như bình
            // thường, chỉ thêm bước ghi log trước đó.
            previousHandler?.uncaughtException(thread, throwable)
                ?: android.os.Process.killProcess(android.os.Process.myPid())
        }
    }
}
