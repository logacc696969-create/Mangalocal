package com.mangalocal.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangalocal.model.*
import com.mangalocal.pipeline.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val storyManager = StoryManager(app)
    val thermalMonitor = ThermalMonitor(app)
    val runtimeOptimizer = RuntimeOptimizer(app)
    private val pipeline = MangaPipeline(storyManager, thermalMonitor, runtimeOptimizer)
    // Mask thủ công (mục 21 TECHNICAL_STATUS.md) — ImagePipeline riêng, tách
    // khỏi cái MangaPipeline đang giữ (native context chỉ load thật khi gọi
    // loadSD(), không tốn gì thêm lúc khởi tạo — an toàn tạo instance riêng).
    private val manualMaskImagePipeline = ImagePipeline(storyManager)
    val manualMaskFixer by lazy { ManualMaskFixer(storyManager, manualMaskImagePipeline) }

    val pipelineState = pipeline.state
    val thermalState = thermalMonitor.state

    private val _stories = MutableStateFlow(storyManager.loadAllStories())
    val stories: StateFlow<List<Story>> = _stories

    private val _currentStory = MutableStateFlow<Story?>(null)
    val currentStory: StateFlow<Story?> = _currentStory

    private val _currentChapter = MutableStateFlow<Chapter?>(null)
    val currentChapter: StateFlow<Chapter?> = _currentChapter

    private val _settings = MutableStateFlow(GenerationSettings())
    val settings: StateFlow<GenerationSettings> = _settings

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating

    private val _sdModels  = MutableStateFlow<List<ModelInfo>>(emptyList())
    private val _llmModels = MutableStateFlow<List<ModelInfo>>(emptyList())
    private val _loras     = MutableStateFlow<List<ModelInfo>>(emptyList())
    val sdModels:  StateFlow<List<ModelInfo>> = _sdModels
    val llmModels: StateFlow<List<ModelInfo>> = _llmModels
    val loras:     StateFlow<List<ModelInfo>> = _loras

    init {
        // SỬA (chẩn đoán crash lúc mở app): nếu StoryManager không ghi được
        // vào bộ nhớ ngoài (thiếu quyền "Quản lý tất cả tệp" trên Android
        // 11+), hiện thông báo rõ ràng qua _error (đã có sẵn dialog hiện
        // error này) thay vì để các hàm bên dưới ném IOException không ai
        // bắt -> crash cả app ngay lúc khởi tạo.
        storyManager.initError?.let { _error.value = it }
        storyManager.ensureManifestInitialized(app)
        storyManager.ensurePoseLibraryInitialized(app)
        rescanModels()
        rescanConsistencySources()
    }

    fun rescanModels() {
        _sdModels.value  = storyManager.scanSdModels()
        _llmModels.value = storyManager.scanLlmModels()
        _loras.value     = storyManager.scanLoras()
    }

    fun updateSettings(block: GenerationSettings.() -> GenerationSettings) {
        _settings.update { it.block() }
        thermalMonitor.updateThreshold(_settings.value.thermalThreshold)
    }

    // ── Story management ──────────────────────────────────────────────────
    fun createStory(title: String, description: String, style: ImageStyle, worldRules: String = "") {
        val story = Story(id = UUID.randomUUID().toString(), title = title,
            description = description, style = style, worldRules = worldRules)
        storyManager.saveStory(story)
        _stories.value = storyManager.loadAllStories()
        _currentStory.value = story
    }

    fun updateWorldRules(worldRules: String) {
        val story = _currentStory.value ?: return
        val updated = story.copy(worldRules = worldRules)
        storyManager.saveStory(updated)
        _currentStory.value = updated
    }

    fun selectStory(story: Story) {
        _currentStory.value = storyManager.loadStory(story.id) ?: story
    }

    fun deleteStory(storyId: String) {
        storyManager.deleteStory(storyId)
        _stories.value = storyManager.loadAllStories()
        if (_currentStory.value?.id == storyId) _currentStory.value = null
    }

    fun refreshCurrentStory() {
        _currentStory.value?.let { _currentStory.value = storyManager.loadStory(it.id) }
    }

    // ── Character management ──────────────────────────────────────────────
    fun addCharacter(name: String, anchor: String, neg: String, role: CharacterRole, loraPath: String?, seed: Long?) {
        val story = _currentStory.value ?: return
        val char = Character(
            id = UUID.randomUUID().toString(), name = name.trim(), anchorPrompt = anchor.trim(),
            negativePrompt = neg.ifBlank { "bad anatomy, bad hands, extra fingers" },
            seed = seed ?: (10000L..99999L).random(), role = role,
            loraPath = loraPath?.ifBlank { null }
        )
        storyManager.saveCharacter(story.id, char)
        refreshCurrentStory()
    }

    fun updateCharacter(character: Character) {
        val story = _currentStory.value ?: return
        storyManager.saveCharacter(story.id, character)
        refreshCurrentStory()
    }

    fun deleteCharacter(characterId: String) {
        val story = _currentStory.value ?: return
        storyManager.deleteCharacter(story.id, characterId)
        refreshCurrentStory()
    }

    fun convertCharacterPair(characters: List<Character>, checkpointPath: String) {
        val story = _currentStory.value ?: return
        if (characters.size < 2) { _error.value = "Cần chọn ít nhất 2 nhân vật để ghép cặp"; return }
        val baseModelId = _settings.value.sdModelId
        _convertBusy.value = characters.joinToString("+") { it.name }
        viewModelScope.launch {
            try {
                val ok = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    storyManager.convertAndRegisterPairModel(baseModelId, checkpointPath, characters)
                }
                if (ok) {
                    refreshCurrentStory()
                } else {
                    _error.value = "Ghép cặp LoRA thất bại — kiểm tra model mặc định ($baseModelId) đã convert xong " +
                        "chưa (cần file khung unet.mnn/vae_decoder.mnn/vae_encoder.mnn), và mỗi nhân vật đã có loraPath chưa."
                }
            } catch (ex: Exception) {
                _error.value = "Ghép cặp LoRA lỗi: ${ex.message}"
            } finally {
                _convertBusy.value = null
            }
        }
    }

    fun regenerateAnchor(character: Character) {
        viewModelScope.launch {
            // Tạo lại ảnh anchor từ prompt hiện tại (đã sửa nếu có)
            // Implementation thực tế cần gọi imagePipeline, đơn giản hóa qua pipeline
        }
    }

    // ── 3 phương pháp nhất quán nhân vật (mục 13 TECHNICAL_STATUS.md) ──────
    private val _checkpoints = MutableStateFlow<List<ModelInfo>>(emptyList())
    val checkpoints: StateFlow<List<ModelInfo>> = _checkpoints
    private val _embeddingSources = MutableStateFlow<List<ModelInfo>>(emptyList())
    val embeddingSources: StateFlow<List<ModelInfo>> = _embeddingSources
    private val _convertBusy = MutableStateFlow<String?>(null) // tên đang convert, null = rảnh
    val convertBusy: StateFlow<String?> = _convertBusy

    fun rescanConsistencySources() {
        _checkpoints.value = storyManager.scanSdModels()
        _embeddingSources.value = storyManager.scanEmbeddingSources()
    }

    // LoRA: cần checkpoint gốc + file LoRA -> convert THẬT (tốn thời gian
    // CPU thật trên máy, không giả lập) -> đăng ký model riêng cho nhân vật.
    // sd_model_converter.cpp (đọc kỹ trước khi sửa): checkpointFile/loraFiles
    // PHẢI là TÊN FILE nằm NGAY TRONG modelDir (native tự nối dir+"/"+tên),
    // KHÔNG PHẢI đường dẫn tuyệt đối nơi khác — bản đầu tôi viết truyền
    // thẳng path tuyệt đối từ MangaLocal/models|loras, SẼ LUÔN THẤT BẠI.
    // Ngoài ra modelDir (thư mục riêng characterId, lần đầu convert sẽ RỖNG)
    // cần sẵn 3 file "khung" unet.mnn/vae_decoder.mnn/vae_encoder.mnn TRƯỚC
    // — copy từ model mặc định đang chọn trong settings (base model ĐÃ
    // convert sẵn, coi như nguồn khung dùng chung). Nếu base model đó CŨNG
    // chưa có 3 file khung này (vd chưa build/convert lần đầu bao giờ) thì
    // convert nhân vật cũng sẽ fail — phụ thuộc dây chuyền, không có cách
    // né, phải build/convert model mặc định trước.
    fun convertCharacterLora(character: Character, checkpointPath: String, loraFile: String) {
        val story = _currentStory.value ?: return
        val baseModelId = _settings.value.sdModelId
        _convertBusy.value = character.name
        viewModelScope.launch {
            try {
                val ok = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    val dir = java.io.File(storyManager.modelsDir, character.id).also { it.mkdirs() }
                    val baseDir = java.io.File(storyManager.modelsDir, baseModelId)
                    val templates = listOf("unet.mnn", "vae_decoder.mnn", "vae_encoder.mnn")
                    val missingTemplate = templates.firstOrNull { !java.io.File(baseDir, it).exists() }
                    if (missingTemplate != null) {
                        _error.value = "Model mặc định ($baseModelId) chưa có file khung '$missingTemplate' " +
                            "— phải có model gốc convert thành công trước khi convert riêng cho nhân vật."
                        return@withContext false
                    }
                    templates.forEach { java.io.File(baseDir, it).copyTo(java.io.File(dir, it), overwrite = true) }

                    val checkpointName = java.io.File(checkpointPath).name
                    java.io.File(checkpointPath).copyTo(java.io.File(dir, checkpointName), overwrite = true)
                    val loraName = java.io.File(loraFile).name
                    java.io.File(loraFile).copyTo(java.io.File(dir, loraName), overwrite = true)

                    storyManager.convertAndRegisterModel(
                        modelDirName = character.id, checkpointFile = checkpointName,
                        characterId = character.id, displayName = character.name,
                        loraFiles = listOf(loraName), loraWeights = listOf(character.loraWeight)
                    )
                }
                if (ok) {
                    storyManager.saveCharacter(story.id, character.copy(loraPath = loraFile))
                    refreshCurrentStory()
                } else if (_error.value == null) {
                    _error.value = "Convert LoRA cho ${character.name} thất bại — xem logcat tag MangaLocal_SDConverter"
                }
            } catch (ex: Exception) {
                _error.value = "Convert LoRA lỗi: ${ex.message}"
            } finally {
                _convertBusy.value = null
            }
        }
    }

    // IP-Adapter: chỉ cần copy ảnh vào đúng chỗ, KHÔNG cần convert gì —
    // encode lúc chạy (xem ip_adapter.cpp). uri từ ActivityResultContracts.OpenDocument().
    fun setCharacterAnchorImage(character: Character, uri: android.net.Uri) {
        val story = _currentStory.value ?: return
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val dest = java.io.File(storyManager.anchorsDir(story.id), "anchor_${character.id}.jpg")
                getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                    dest.outputStream().use { output -> input.copyTo(output) }
                }
                storyManager.saveCharacterAnchor(story.id, character.id, dest.absolutePath)
                refreshCurrentStory()
            } catch (ex: Exception) {
                _error.value = "Lưu ảnh anchor lỗi: ${ex.message}"
            }
        }
    }

    // Textual Inversion: copy .safetensors vào embeddingsDir của truyện,
    // đặt tên = trigger word (xem StoryManager.setCharacterEmbedding).
    fun setCharacterEmbeddingFromSource(character: Character, sourcePath: String) {
        val story = _currentStory.value ?: return
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val trigger = storyManager.setCharacterEmbedding(story.id, character.id, sourcePath)
            if (trigger == null) _error.value = "Gán Textual Inversion cho ${character.name} thất bại"
            refreshCurrentStory()
        }
    }

    fun setCharacterEmbeddingFromUri(character: Character, uri: android.net.Uri) {
        val story = _currentStory.value ?: return
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val tmp = java.io.File.createTempFile("ti_", ".safetensors", getApplication<Application>().cacheDir)
                getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                    tmp.outputStream().use { output -> input.copyTo(output) }
                }
                val trigger = storyManager.setCharacterEmbedding(story.id, character.id, tmp.absolutePath)
                tmp.delete()
                if (trigger == null) _error.value = "Gán Textual Inversion cho ${character.name} thất bại"
                refreshCurrentStory()
            } catch (ex: Exception) {
                _error.value = "Gán Textual Inversion lỗi: ${ex.message}"
            }
        }
    }

    fun clearConsistencyMethod(character: Character) {
        val story = _currentStory.value ?: return
        storyManager.saveCharacter(story.id, character.copy(
            loraPath = null, anchorImagePath = null, embeddingPath = null, embeddingTrigger = null
        ))
        refreshCurrentStory()
    }

    // ── Generation flow ──────────────────────────────────────────────────
    fun generatePanels(storyText: String) {
        val story = _currentStory.value ?: run { _error.value = "Chưa chọn truyện"; return }
        val s = _settings.value
        if (s.sdModelPath.isEmpty())  { _error.value = "Chưa chọn SD Model"; return }
        if (s.llmModelPath.isEmpty()) { _error.value = "Chưa chọn LLM Model"; return }
        if (_isGenerating.value) return

        _isGenerating.value = true
        viewModelScope.launch {
            try {
                val chapterId = UUID.randomUUID().toString()
                val chapterNum = (storyManager.loadAllChapters(story.id).maxOfOrNull { it.chapterNumber } ?: 0) + 1
                val chapter = pipeline.generatePanels(story, storyText, s, chapterId, chapterNum)
                storyManager.saveChapter(chapter)
                _currentChapter.value = chapter
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi không xác định"
            } finally {
                _isGenerating.value = false
            }
        }
    }

    fun approvePanel(panelIndex: Int) {
        val ch = _currentChapter.value ?: return
        val updated = ch.panels.map { if (it.index == panelIndex) it.copy(status = PanelStatus.APPROVED) else it }
        _currentChapter.value = ch.copy(panels = updated)
        storyManager.saveChapter(ch.copy(panels = updated))
    }

    fun regeneratePanel(panelIndex: Int, newPrompt: String? = null, overrides: PanelOverrideSettings? = null) {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        val panel = ch.panels.find { it.index == panelIndex } ?: return
        var updatedPanel = if (newPrompt != null) panel.copy(prompt = newPrompt, userNote = newPrompt) else panel
        if (overrides != null) updatedPanel = updatedPanel.copy(overrideSettings = overrides)

        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                val regenerated = pipeline.regeneratePanel(updatedPanel, story, _settings.value, outDir)
                val updated = ch.panels.map { if (it.index == panelIndex) regenerated else it }
                _currentChapter.value = ch.copy(panels = updated)
                storyManager.saveChapter(ch.copy(panels = updated))
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi regenerate panel"
            }
        }
    }

    // Mask thủ công / "Inpaint Anything" (mục 21 TECHNICAL_STATUS.md) —
    // dùng cho PHASE CUỐI (ảnh đã upscale xong, panel.upscaledPath != null)
    // khi user thấy vẫn còn lỗi mà auto-fix không bắt/sửa đúng. clickX/
    // clickY: toạ độ PIXEL theo ảnh tại panel.upscaledPath (UI tự quy đổi
    // từ toạ độ chạm trên màn hình sang toạ độ pixel ảnh thật trước khi gọi).
    private val _manualFixBusy = MutableStateFlow(false)
    val manualFixBusy: StateFlow<Boolean> = _manualFixBusy

    fun manualMaskFixPanel(panelIndex: Int, clickX: Float, clickY: Float, denoiseStrength: Float = 0.4f) {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        val panel = ch.panels.find { it.index == panelIndex } ?: return
        val imagePath = panel.upscaledPath ?: panel.imagePath ?: return
        _manualFixBusy.value = true
        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                val maskPath = manualMaskFixer.clickToMask(imagePath, clickX, clickY, outDir, panelIndex)
                if (maskPath == null) {
                    _error.value = "MobileSAM chưa sẵn sàng (thiếu model mobile_sam_encoder.mnn/mobile_sam_decoder.mnn) hoặc không phân đoạn được điểm này"
                    return@launch
                }
                val bmp = android.graphics.BitmapFactory.decodeFile(imagePath)
                val w = bmp?.width ?: settings.value.width
                val h = bmp?.height ?: settings.value.height
                bmp?.recycle()
                val fixedPath = manualMaskFixer.inpaintMaskedRegion(
                    panelIndex, panel.prompt, panel.negativePrompt, settings.value.imageStyle.stylePrompt,
                    imagePath, maskPath, denoiseStrength, w, h, panel.index.toLong() + 3000L, outDir
                )
                val updated = ch.panels.map { if (it.index == panelIndex) it.copy(upscaledPath = fixedPath) else it }
                _currentChapter.value = ch.copy(panels = updated)
                storyManager.saveChapter(ch.copy(panels = updated))
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi mask thủ công"
            } finally {
                _manualFixBusy.value = false
            }
        }
    }

    // Dịch mô tả tự nhiên -> prompt SD1.5 (mục 24 TECHNICAL_STATUS.md) —
    // dùng cho GalleryReviewScreen, LLMParser instance NGẮN HẠN riêng cho
    // 1 lần dịch (không giữ lâu dài, khác pipeline chính).
    private val _translating = MutableStateFlow(false)
    val translating: StateFlow<Boolean> = _translating

    fun translateNaturalDescription(naturalDesc: String, stage: PromptStage, onResult: (PromptResult) -> Unit) {
        if (naturalDesc.isBlank()) return
        _translating.value = true
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            var parser: LLMParser? = null
            try {
                val worldRules = _currentStory.value?.worldRules ?: ""
                parser = LLMParser(_settings.value.llmModelPath, 4, 0)
                parser.init()
                val result = parser.translateStagePrompt(naturalDesc, stage, worldRules, _settings.value.imageStyle.stylePrompt)
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onResult(result) }
            } catch (e: Exception) {
                _error.value = "Dịch LLM lỗi: ${e.message}"
            } finally {
                parser?.free()
                _translating.value = false
            }
        }
    }

    fun updatePanelBubbles(panelIndex: Int, bubbles: List<Bubble>) {
        val ch = _currentChapter.value ?: return
        val updated = ch.panels.map { if (it.index == panelIndex) it.copy(bubbles = bubbles) else it }
        _currentChapter.value = ch.copy(panels = updated)
        storyManager.saveChapter(ch.copy(panels = updated))
    }

    fun proceedToUpscale() {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        _isGenerating.value = true
        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                val upscaled = pipeline.upscaleApprovedPanels(ch, _settings.value, outDir)
                storyManager.saveChapter(upscaled)
                _currentChapter.value = upscaled
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi upscale"
            } finally { _isGenerating.value = false }
        }
    }

    fun runAutoBubble() {
        val ch = _currentChapter.value ?: return
        _isGenerating.value = true
        viewModelScope.launch {
            try {
                val updated = pipeline.autoPlaceBubbles(ch)
                storyManager.saveChapter(updated)
                _currentChapter.value = updated
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi auto bubble"
            } finally { _isGenerating.value = false }
        }
    }

    fun exportChapter() {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                val exported = pipeline.exportChapter(ch, outDir)
                storyManager.saveChapter(exported)
                _currentChapter.value = exported
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi export"
            }
        }
    }

    fun selectChapter(chapter: Chapter) { _currentChapter.value = chapter }
    fun cancelGeneration() { pipeline.cancel(); _isGenerating.value = false }
    fun clearError() { _error.value = null }
    fun modelSetupGuide() = storyManager.setupGuide()
    fun modelStatus() = storyManager.modelStatus()
    fun hardwareSummary() = runtimeOptimizer.getHardwareSummary()

    override fun onCleared() { super.onCleared(); pipeline.cancel() }
}
