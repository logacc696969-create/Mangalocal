package com.mangalocal.pipeline

import com.mangalocal.model.*

class FamilyManager(private val storyManager: StoryManager) {

    /**
     * Tạo nhân vật con dựa trên quan hệ huyết thống.
     *
     * Quá trình:
     * 1. Trích xuất traits di truyền từ cha/mẹ
     * 2. Blend traits theo tỷ lệ sinh học thực tế
     * 3. Tạo anchor prompt cho nhân vật con
     * 4. [Nếu có embedding] Blend embedding file
     */
    fun createChildCharacter(
        storyId: String,
        childName: String,
        childBaseDesc: String,     // "young girl, 16 years old, high school student"
        childOwnTraits: Map<String, String> = emptyMap(), // trait riêng: màu tóc khác,...
        parentAId: String,
        parentBId: String? = null, // null = không có cha/mẹ B (đơn thân, tìm thấy...)
        relationshipType: RelationshipType,
        childSeed: Long = (10000L..99999L).random(),
        childRole: CharacterRole = CharacterRole.MAIN
    ): Character? {
        val story = storyManager.loadStory(storyId) ?: return null
        val parentA = story.characters.find { it.id == parentAId } ?: return null
        val parentB = parentBId?.let { story.characters.find { c -> c.id == it } }

        // 1. Trích xuất traits
        val traitsA = GeneticTraits.extractTraits(parentA.anchorPrompt)
        val traitsB = parentB?.let { GeneticTraits.extractTraits(it.anchorPrompt) }

        // 2. Blend traits theo tỷ lệ di truyền
        val blended = GeneticTraits.blendTraits(
            parentATraits = traitsA,
            parentBTraits = traitsB,
            childSeed = childSeed,
            inheritanceRatio = relationshipType.blendRatio
        )

        // 3. Tạo anchor prompt
        val childPrompt = GeneticTraits.buildChildPrompt(childBaseDesc, blended, childOwnTraits)

        // 4. Tạo Character
        val childChar = Character(
            id = java.util.UUID.randomUUID().toString(),
            name = childName,
            anchorPrompt = childPrompt,
            negativePrompt = parentA.negativePrompt, // kế thừa negative prompt
            seed = childSeed,
            role = childRole
        )

        storyManager.saveCharacter(storyId, childChar)

        return childChar
    }

    /**
     * Preview anchor prompt sẽ được tạo — dùng trong UI trước khi lưu
     */
    fun previewChildPrompt(
        storyId: String,
        parentAId: String,
        parentBId: String?,
        childBaseDesc: String,
        childSeed: Long,
        relationship: RelationshipType
    ): String {
        val story = storyManager.loadStory(storyId) ?: return "Không tìm thấy truyện"
        val parentA = story.characters.find { it.id == parentAId } ?: return "Không tìm thấy nhân vật cha/mẹ"
        val parentB = parentBId?.let { story.characters.find { c -> c.id == it } }

        val traitsA = GeneticTraits.extractTraits(parentA.anchorPrompt)
        val traitsB = parentB?.let { GeneticTraits.extractTraits(it.anchorPrompt) }
        val blended = GeneticTraits.blendTraits(traitsA, traitsB, childSeed, relationship.blendRatio)
        return GeneticTraits.buildChildPrompt(childBaseDesc, blended)
    }

    /**
     * Lấy danh sách traits di truyền để hiển thị trong UI
     */
    fun explainInheritance(
        storyId: String,
        parentAId: String,
        parentBId: String?,
        childSeed: Long,
        relationship: RelationshipType
    ): List<TraitInheritanceInfo> {
        val story = storyManager.loadStory(storyId) ?: return emptyList()
        val parentA = story.characters.find { it.id == parentAId } ?: return emptyList()
        val parentB = parentBId?.let { story.characters.find { c -> c.id == it } }

        val traitsA = GeneticTraits.extractTraits(parentA.anchorPrompt)
        val traitsB = parentB?.let { GeneticTraits.extractTraits(it.anchorPrompt) }
        val rng = java.util.Random(childSeed)

        val allGroups = (traitsA.keys + (traitsB?.keys ?: emptySet())).toSet()
        return allGroups.mapNotNull { group ->
            val tA = traitsA[group]; val tB = traitsB?.get(group)
            val inherited = when {
                tA == tB && tA != null -> tA
                tA != null && tB != null -> if (rng.nextFloat() < 0.5f) tA else tB
                tA != null -> if (rng.nextFloat() < relationship.blendRatio) tA else null
                tB != null -> if (rng.nextFloat() < relationship.blendRatio) tB else null
                else -> null
            }
            if (inherited != null) TraitInheritanceInfo(
                traitGroup = group,
                parentAValue = tA,
                parentBValue = tB,
                inheritedValue = inherited,
                fromParent = when {
                    tA == tB -> "Cả hai"
                    inherited == tA -> parentA.name
                    else -> parentB?.name ?: "Ngẫu nhiên"
                }
            ) else null
        }
    }
}

data class TraitInheritanceInfo(
    val traitGroup: String,
    val parentAValue: String?,
    val parentBValue: String?,
    val inheritedValue: String,
    val fromParent: String
)
