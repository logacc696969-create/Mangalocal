package com.mangalocal.model

// ── Quan hệ huyết thống ───────────────────────────────────────────────────

enum class RelationshipType(val label: String, val blendRatio: Float) {
    // blendRatio = tỷ lệ di truyền đặc điểm từ parent (0.0 - 1.0)
    PARENT_CHILD("Cha/Mẹ - Con",        0.50f),  // 50% gene từ mỗi cha/mẹ
    SIBLING("Anh/Chị - Em",             0.50f),  // anh chị em ruột ~50% gene chung
    HALF_SIBLING("Anh/Chị em cùng cha hoặc mẹ", 0.25f), // ~25% gene chung
    GRANDPARENT("Ông/Bà - Cháu",        0.25f),  // ~25% gene
    TWIN_IDENTICAL("Sinh đôi cùng trứng", 1.0f), // 100% giống nhau
    TWIN_FRATERNAL("Sinh đôi khác trứng", 0.50f),
    UNCLE_NIECE("Chú/Cô - Cháu",        0.25f),
    COUSIN("Anh/Chị em họ",             0.125f)  // ~12.5%
}

data class FamilyLink(
    val relativeId: String,       // ID nhân vật có quan hệ
    val relationshipType: RelationshipType,
    val isParent: Boolean = true  // true = relative là cha/mẹ của nhân vật này
)

// Extension cho Character để thêm quan hệ huyết thống
data class CharacterWithFamily(
    val character: Character,
    val familyLinks: List<FamilyLink> = emptyList()
)

// ── Trait inheritance — các đặc điểm di truyền ───────────────────────────

object GeneticTraits {

    // Từ khóa ngoại hình có thể di truyền
    val inheritableTraits = mapOf(
        "eye_color"   to listOf("brown eyes", "blue eyes", "green eyes", "black eyes", "hazel eyes", "gray eyes"),
        "eye_shape"   to listOf("almond eyes", "round eyes", "monolid", "hooded eyes", "wide eyes"),
        "nose"        to listOf("sharp nose", "button nose", "broad nose", "straight nose", "upturned nose"),
        "jaw"         to listOf("sharp jawline", "soft jawline", "square jaw", "round jaw", "defined jaw"),
        "skin"        to listOf("fair skin", "olive skin", "tan skin", "dark skin", "pale skin", "warm skin tone"),
        "hair_color"  to listOf("black hair", "brown hair", "blonde hair", "red hair", "dark hair", "white hair"),
        "hair_texture" to listOf("straight hair", "wavy hair", "curly hair", "thick hair", "fine hair"),
        "face_shape"  to listOf("oval face", "round face", "heart face", "square face", "diamond face"),
        "eyebrow"     to listOf("thick eyebrows", "thin eyebrows", "arched eyebrows", "straight eyebrows"),
        "lip"         to listOf("full lips", "thin lips", "defined cupid's bow", "wide lips"),
        "height_build" to listOf("tall", "short", "slender", "athletic build", "petite")
    )

    /**
     * Trích xuất các trait di truyền từ anchor prompt của nhân vật
     */
    fun extractTraits(anchorPrompt: String): Map<String, String> {
        val found = mutableMapOf<String, String>()
        val lowerPrompt = anchorPrompt.lowercase()
        inheritableTraits.forEach { (traitGroup, options) ->
            options.forEach { trait ->
                if (lowerPrompt.contains(trait.lowercase())) {
                    found[traitGroup] = trait
                }
            }
        }
        return found
    }

    /**
     * Blend traits của cha/mẹ theo tỷ lệ di truyền thực tế.
     *
     * Với mỗi nhóm trait:
     * - 50% chance kế thừa từ parent A
     * - 50% chance kế thừa từ parent B
     * - Nếu cả 2 cùng trait → 100% kế thừa (dominant)
     * - Nếu 1 trong 2 thiếu trait → 50% chance kế thừa
     *
     * Dùng seed ổn định để kết quả nhất quán cho cùng 1 nhân vật
     */
    fun blendTraits(
        parentATraits: Map<String, String>,
        parentBTraits: Map<String, String>?,
        childSeed: Long,
        inheritanceRatio: Float = 0.5f
    ): Map<String, String> {
        val result = mutableMapOf<String, String>()
        val rng = java.util.Random(childSeed)

        val allGroups = (parentATraits.keys + (parentBTraits?.keys ?: emptySet())).toSet()

        allGroups.forEach { group ->
            val traitA = parentATraits[group]
            val traitB = parentBTraits?.get(group)

            val selected = when {
                traitA == traitB && traitA != null -> traitA  // cả 2 giống nhau → kế thừa 100%
                traitA != null && traitB != null -> {
                    // Chọn ngẫu nhiên dựa trên seed
                    if (rng.nextFloat() < 0.5f) traitA else traitB
                }
                traitA != null -> {
                    // Chỉ có cha/mẹ A → di truyền theo tỷ lệ inheritanceRatio
                    if (rng.nextFloat() < inheritanceRatio) traitA else null
                }
                traitB != null -> {
                    if (rng.nextFloat() < inheritanceRatio) traitB else null
                }
                else -> null
            }
            if (selected != null) result[group] = selected
        }
        return result
    }

    /**
     * Tạo anchor prompt cho nhân vật con dựa trên traits đã blend
     * Giữ lại phần mô tả riêng của nhân vật (tuổi, giới tính, tính cách...)
     */
    fun buildChildPrompt(
        childBaseDesc: String,   // mô tả riêng: "young girl, 16 years old"
        blendedTraits: Map<String, String>,
        ownTraits: Map<String, String> = emptyMap() // trait riêng override
    ): String {
        val parts = mutableListOf<String>()

        // Phần mô tả riêng của nhân vật (tuổi, giới tính, tính cách)
        if (childBaseDesc.isNotBlank()) parts.add(childBaseDesc.trim())

        // Traits kế thừa (ưu tiên own traits override blend)
        val finalTraits = blendedTraits + ownTraits
        parts.addAll(finalTraits.values)

        return parts.joinToString(", ")
    }
}
