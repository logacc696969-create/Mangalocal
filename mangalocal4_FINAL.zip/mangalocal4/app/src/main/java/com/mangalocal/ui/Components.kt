package com.mangalocal.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.mangalocal.model.*

object C {
    val Bg = Color(0xFF0D0D0D); val S0 = Color(0xFF131313)
    val S1 = Color(0xFF1A1A1A); val S2 = Color(0xFF222222)
    val Border = Color(0xFF2C2C2C); val BorderHi = Color(0xFF3A3A3A)
    val Blue = Color(0xFF4A9ED6); val BlueDim = Color(0xFF162233)
    val Green = Color(0xFF4CAF50); val GreenDim = Color(0xFF122012)
    val Orange = Color(0xFFFF9800); val OrangeDim = Color(0xFF2A1A08)
    val Red = Color(0xFFEF5350); val RedDim = Color(0xFF2A1010)
    val Purple = Color(0xFF9C6FD6); val PurpleDim = Color(0xFF1E1030)
    val T1 = Color(0xFFEAEAEA); val T2 = Color(0xFF999999); val T3 = Color(0xFF505050)

    val scheme = darkColorScheme(
        background = Bg, surface = S1, surfaceVariant = S2,
        primary = Blue, onPrimary = Color.White,
        onBackground = T1, onSurface = T1, outline = Border
    )
}

@Composable
fun MlCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier = modifier.fillMaxWidth(), color = C.S1,
        shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, C.Border)) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun MlLabel(text: String) = Text(text.uppercase(), color = C.T3, fontSize = 10.sp,
    fontWeight = FontWeight.SemiBold, letterSpacing = 0.08.sp, modifier = Modifier.padding(bottom = 8.dp))

@Composable
fun MlChip(text: String, color: Color, bg: Color, modifier: Modifier = Modifier) =
    Surface(color = bg, shape = RoundedCornerShape(6.dp), modifier = modifier) {
        Text(text, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
    }

@Composable
fun MlBtn(text: String, onClick: () -> Unit, enabled: Boolean = true,
          icon: ImageVector = Icons.Default.AutoAwesome, modifier: Modifier = Modifier) =
    Button(onClick = onClick, enabled = enabled, modifier = modifier.fillMaxWidth().height(50.dp),
        colors = ButtonDefaults.buttonColors(containerColor = C.Blue, disabledContainerColor = C.S2)) {
        Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }

@Composable
fun MlOutlineBtn(text: String, onClick: () -> Unit, icon: ImageVector? = null,
                 color: Color = C.T2, modifier: Modifier = Modifier) =
    OutlinedButton(onClick = onClick, modifier = modifier.fillMaxWidth(), border = BorderStroke(1.dp, C.Border),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = color)) {
        icon?.let { Icon(it, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)) }
        Text(text, fontSize = 13.sp)
    }

@Composable
fun CharAvatar(name: String, size: Dp = 38.dp) =
    Surface(Modifier.size(size), CircleShape, C.BlueDim) {
        Box(contentAlignment = Alignment.Center) {
            Text(name.firstOrNull()?.uppercase() ?: "?", color = C.Blue,
                fontWeight = FontWeight.Bold, fontSize = (size.value * 0.37f).sp)
        }
    }

@Composable
fun StatCard(v: String, l: String, modifier: Modifier = Modifier) =
    Surface(modifier, C.S0, RoundedCornerShape(10.dp), border = BorderStroke(1.dp, C.Border)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(v, color = C.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(l, color = C.T3, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }

@Composable
fun RoleChip(role: CharacterRole) {
    val (text, color, bg) = when (role) {
        CharacterRole.MAIN -> Triple("Chính", C.Blue, C.BlueDim)
        CharacterRole.SUPPORTING -> Triple("Phụ", C.Purple, C.PurpleDim)
        CharacterRole.ONETIME -> Triple("Một lần", C.T3, C.S0)
    }
    MlChip(text, color, bg)
}

@Composable
fun ThermalBadge(tempC: Int, threshold: Int) {
    val color = when {
        tempC >= threshold -> C.Red
        tempC >= threshold - 5 -> C.Orange
        else -> C.Green
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.size(8.dp).background(color, CircleShape))
        Text("$tempC°C", color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PipelineIndicator(stage: PipelineStage) {
    val steps = listOf("LLM" to PipelineStage.LLM_PARSING, "Prompt" to PipelineStage.PROMPT_BUILDING,
        "SD" to PipelineStage.SD_GENERATING, "Review" to PipelineStage.REVIEW,
        "Upscale" to PipelineStage.UPSCALING, "Bubble" to PipelineStage.BUBBLE_AUTO,
        "Export" to PipelineStage.LAYOUT_EXPORT)
    val idx = steps.indexOfFirst { it.second == stage }.coerceAtLeast(
        if (stage == PipelineStage.DONE) steps.size else 0)

    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
        steps.forEachIndexed { i, (label, _) ->
            val done = i < idx || stage == PipelineStage.DONE
            val active = i == idx && stage != PipelineStage.DONE && stage != PipelineStage.IDLE
            Column(Modifier.width(56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(Modifier.size(26.dp), CircleShape,
                    color = when { done -> C.GreenDim; active -> C.BlueDim; else -> C.S0 },
                    border = BorderStroke(1.dp, when { done -> C.Green; active -> C.Blue; else -> C.Border })) {
                    Box(contentAlignment = Alignment.Center) {
                        if (done) Icon(Icons.Default.Check, null, tint = C.Green, modifier = Modifier.size(13.dp))
                        else Text("${i+1}", color = if (active) C.Blue else C.T3, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text(label, color = C.T3, fontSize = 8.sp, modifier = Modifier.padding(top = 3.dp))
            }
            if (i < steps.size - 1) Divider(Modifier.width(12.dp).padding(bottom = 13.dp),
                color = if (i < idx) C.Green else C.Border, thickness = 1.dp)
        }
    }
}

@Composable
fun ModelDropdown(label: String, selected: String, models: List<ModelInfo>,
                  onSelect: (ModelInfo) -> Unit, onRescan: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val name = if (selected.isEmpty()) "— chưa chọn —" else selected.substringAfterLast('/').take(36)
    Column {
        MlLabel(label)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Surface(onClick = { if (models.isNotEmpty()) expanded = true }, Modifier.weight(1f),
                C.S0, RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (selected.isEmpty()) C.Red.copy(0.5f) else C.Border)) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = if (selected.isEmpty()) C.Red else C.T1, fontSize = 12.sp,
                        modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Icon(Icons.Default.ArrowDropDown, null, tint = C.T3, modifier = Modifier.size(18.dp))
                }
            }
            IconButton(onClick = onRescan, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Refresh, null, tint = C.T2, modifier = Modifier.size(18.dp))
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            if (models.isEmpty()) DropdownMenuItem(text = { Text("Không tìm thấy", color = C.T3) }, onClick = { expanded = false })
            models.forEach { m ->
                DropdownMenuItem(text = { Column {
                    Text(m.name, color = C.T1, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(m.displaySize, color = C.T3, fontSize = 10.sp)
                }}, onClick = { onSelect(m); expanded = false },
                    trailingIcon = { if (selected == m.path) Icon(Icons.Default.Check, null, tint = C.Green, modifier = Modifier.size(14.dp)) })
            }
        }
    }
}

@Composable
fun AppNavBar(nav: androidx.navigation.NavController, current: String) =
    NavigationBar(containerColor = C.S0, tonalElevation = 0.dp) {
        listOf("stories" to (Icons.Default.AutoStories to "Truyện"),
               "characters" to (Icons.Default.People to "Nhân vật"),
               "settings" to (Icons.Default.Settings to "Cài đặt")).forEach { (route, pair) ->
            val (icon, label) = pair
            NavigationBarItem(selected = current == route,
                onClick = { if (current != route) nav.navigate(route) { launchSingleTop = true } },
                icon = { Icon(icon, null) }, label = { Text(label, fontSize = 9.sp) },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = C.Blue, selectedTextColor = C.Blue,
                    unselectedIconColor = C.T3, unselectedTextColor = C.T3, indicatorColor = C.BlueDim))
        }
    }
