package com.mangalocal.pipeline

import com.mangalocal.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ImagePipeline(private val storyManager: StoryManager) {

    private var sdCtx: Long = 0
    private var sdAugmentedCtx: Long = 0
    private var loadedAugmentedDir = ""
    private var esrganCtx: Long = 0
    private var loadedSdPath = ""

    /**
     * Nạp pipeline "augmented" (IP-Adapter + ControlNet-Pose) — dùng
     * unet_ipa_controlnet.mnn xuất bởi tools/export_ipa_controlnet_unet.py,
     * KHÁC HẲN unet.mnn thường của loadSD(). Chỉ gọi khi thật sự cần giữ
     * nhất quán nhân vật (settings.useStoryDiffusion), không phải lúc nào
     * cũng nạp vì UNet augmented nặng hơn UNet thường (thêm ControlNet).
     */
    suspend fun loadSDAugmented(modelDir: String, embeddingsDir: String) = withContext(Dispatchers.IO) {
        if (modelDir == loadedAugmentedDir) return@withContext
        if (sdAugmentedCtx != 0L) { NativeBridge.sdFreeAugmented(sdAugmentedCtx); sdAugmentedCtx = 0 }
        sdAugmentedCtx = NativeBridge.sdInitAugmented(
            modelDir,
            "$modelDir/clip.mnn",
            "$modelDir/unet_ipa_controlnet.mnn",
            "$modelDir/vae_decoder.mnn",
            "$modelDir/vae_encoder.mnn",
            "$modelDir/ip_image_encoder.mnn",
            "$modelDir/tokenizer.json",
            embeddingsDir
        )
        if (sdAugmentedCtx == 0L) throw RuntimeException(
            "Không load được pipeline augmented tại $modelDir.\n" +
            "Kiểm tra đã chạy tools/export_ipa_controlnet_unet.py và convert sang .mnn chưa.\n" +
            "(xem logcat tag MangaLocal_IPAdapter)")
        loadedAugmentedDir = modelDir
    }

    // ĐỔI CHỮ KÝ: modelPath/loraPath/loraWeight/nThreads/useVulkan (thời
    // sd.cpp) -> modelDir/modelId/useOpenCL (thời MNN + model_manifest.json).
    // Lý do đổi: MNN cần NHIỀU file trong 1 thư mục (clip/unet/vae_decoder/
    // vae_encoder/tokenizer...), không phải 1 file .gguf/.safetensors duy
    // nhất như sd.cpp — nên đổi sang trỏ thư mục + id trong manifest thay vì
    // đường dẫn 1 file. Không giữ được chữ ký cũ ở lần đổi này.
    // CẢNH BÁO CACHE (chưa xử lý, biết trước để không tưởng nhầm): nếu
    // modelId KHÔNG đổi nhưng embeddingsDir có file .safetensors MỚI thêm
    // giữa chừng (vd user vừa gán Textual Inversion cho 1 nhân vật ngay
    // trước khi generate tiếp), hàm này SẼ bỏ qua reload (do check
    // `modelId == loadedSdPath`) -> embedding mới KHÔNG được nạp cho tới khi
    // đổi model khác rồi quay lại, hoặc restart app. Chưa fix vì cần theo
    // dõi thêm state (embeddingsDir đã nạp lần trước là gì), để dành nếu
    // thực tế gặp vấn đề này khi build-test.
    suspend fun loadSD(modelDir: String, modelId: String, useOpenCL: Boolean, embeddingsDir: String) =
        withContext(Dispatchers.IO) {
            if (modelId == loadedSdPath) return@withContext
            if (sdCtx != 0L) { NativeBridge.sdFree(sdCtx); sdCtx = 0 }
            sdCtx = NativeBridge.sdInit(modelDir, modelId, useOpenCL, embeddingsDir)
            if (sdCtx == 0L) throw RuntimeException("Không load được SD model: $modelId\n(xem logcat tag MangaLocal_SDEngine để biết lý do cụ thể)")
            loadedSdPath = modelId
        }

    suspend fun loadEsrgan(scale: Int) = withContext(Dispatchers.IO) {
        if (esrganCtx != 0L || scale <= 1) return@withContext
        if (!storyManager.hasEsrgan()) throw RuntimeException(
            "Thiếu ESRGAN model.\nĐặt vào: ${storyManager.esrganDir.absolutePath}")
        esrganCtx = NativeBridge.esrganInit(scale, storyManager.esrganDir.absolutePath)
        if (esrganCtx == 0L) throw RuntimeException("ESRGAN init thất bại")
    }

    suspend fun generatePanel(
        panelIndex: Int,
        prompt: String,
        negativePrompt: String,
        stylePrompt: String,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        referenceImagePath: String?,
        // Toạ độ khung xương ĐÃ RETARGET (mục 32/33 TECHNICAL_STATUS.md) —
        // tính sẵn ở MangaPipeline qua PoseRetargeter.kt trước khi gọi hàm
        // này. Rỗng = không có pose cụ thể, native tự dùng fallback đứng.
        skeletonData: FloatArray,
        useStoryDiffusion: Boolean,
        outDir: File,
        onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val fullPrompt = prompt + ", " + stylePrompt

        val ok = if (useStoryDiffusion && referenceImagePath != null) {
            // Pipeline augmented KHÔNG có callback tiến trình per-step (khác
            // pipeline thường) — báo tiến trình ở mức panel, không mức bước,
            // vì ip_adapter.cpp hiện chưa nối progress callback (việc nhỏ,
            // có thể thêm sau nếu cần UX mượt hơn).
            onProgress(0, steps)
            val result = NativeBridge.sdTxt2ImgWithReferenceAndPose(
                sdAugmentedCtx, fullPrompt, negativePrompt, referenceImagePath, skeletonData,
                width, height, steps, cfgScale, seed,
                outFile.absolutePath
            )
            onProgress(steps, steps)
            result
        } else {
            val cb = object : NativeBridge.SDProgressCallback {
                override fun onProgress(step: Int, total: Int) = onProgress(step, total)
            }
            NativeBridge.sdTxt2Img(
                sdCtx, fullPrompt, negativePrompt,
                width, height, steps, cfgScale, seed,
                outFile.absolutePath, cb
            )
        }
        if (!ok) throw RuntimeException("SD generate thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // img2img / inpaint / Ultrafix (mục 16 TECHNICAL_STATUS.md). Dùng sdCtx
    // (pipeline THƯỜNG, không phải augmented — Ultrafix/inpaint CHƯA thử
    // nghiệm kết hợp với IP-Adapter/ControlNet-Pose cùng lúc, để dành sau
    // nếu thực tế cần). Yêu cầu đã gọi loadSD() trước (giống generatePanel).
    //
    // maskPath = null -> img2img thường (vẽ lại toàn ảnh theo denoiseStrength).
    // maskPath != null -> inpaint thật, chỉ vẽ lại vùng trắng trong mask.
    // ultrafix = true -> upscale-vẽ-lại: inputPath PHẢI đã là ảnh upscale sẵn
    // (vd qua ESRGAN), width/height = kích thước ĐÍCH (đã upscale), không
    // phải kích thước gốc 512.
    suspend fun img2imgFix(
        panelIndex: Int, prompt: String, negativePrompt: String, stylePrompt: String,
        inputPath: String, maskPath: String?, denoiseStrength: Float,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        ultrafix: Boolean, ultrafixTile: Int, outDir: File, onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val suffix = if (ultrafix) "ultrafix" else "fix"
        val outFile = File(outDir, "panel_%03d_%s.png".format(panelIndex, suffix))
        val fullPrompt = prompt + ", " + stylePrompt
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        val ok = NativeBridge.sdImg2Img(
            sdCtx, fullPrompt, negativePrompt, inputPath, maskPath ?: "",
            denoiseStrength, width, height, steps, cfgScale, seed,
            ultrafix, ultrafixTile, outFile.absolutePath, cb
        )
        if (!ok) throw RuntimeException("img2img/inpaint thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    suspend fun upscale(inputPath: String, panelIndex: Int, outDir: File, option: UpscaleOption): String =
        withContext(Dispatchers.IO) {
            if (option == UpscaleOption.NONE) return@withContext inputPath
            val outFile = File(outDir, "panel_%03d_hd.png".format(panelIndex))
            val ok = NativeBridge.esrganUpscale(esrganCtx, inputPath, outFile.absolutePath, option.sharpen)
            if (!ok) throw RuntimeException("Upscale thất bại tại panel ${panelIndex + 1}")
            outFile.absolutePath
        }

    fun isSdLoaded() = sdCtx != 0L

    fun freeAll() {
        if (sdCtx != 0L) { NativeBridge.sdFree(sdCtx); sdCtx = 0; loadedSdPath = "" }
        if (sdAugmentedCtx != 0L) { NativeBridge.sdFreeAugmented(sdAugmentedCtx); sdAugmentedCtx = 0; loadedAugmentedDir = "" }
        if (esrganCtx != 0L) { NativeBridge.esrganFree(esrganCtx); esrganCtx = 0 }
    }

    fun freeEsrganOnly() {
        if (esrganCtx != 0L) { NativeBridge.esrganFree(esrganCtx); esrganCtx = 0 }
    }
}
