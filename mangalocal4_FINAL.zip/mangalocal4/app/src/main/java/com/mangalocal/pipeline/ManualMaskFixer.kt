package com.mangalocal.pipeline

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Inpaint Anything" thủ công (mục 21 TECHNICAL_STATUS.md) — dùng cho PHASE
 * CUỐI, sau khi ảnh đã ở độ phân giải cuối (upscale + Ultrafix + auto-fix
 * mặt/tay xong) mà VẪN còn lỗi (dính người, giải phẫu sai) mà các bước tự
 * động không bắt được/không sửa đúng.
 *
 * Luồng: user chạm 1 điểm trên vùng lỗi -> MobileSAM (mục 21) tự phân đoạn
 * ra mask chính xác theo đúng khối đó -> mask này feed THẲNG vào
 * `ImagePipeline.img2imgFix()` ĐÃ CÓ (mục 16) — CÙNG 1 inpainting với
 * auto-fix mặt/tay (mục 17), không viết pipeline vẽ lại riêng, đúng yêu
 * cầu "cái inpainting của mask tay cũng cùng 1 inpainting luôn".
 */
class ManualMaskFixer(private val storyManager: StoryManager, private val imagePipeline: ImagePipeline) {

    private val ctx: Long = try {
        NativeBridge.mobileSamInit(storyManager.yoloDir.absolutePath) // dùng chung thư mục model YOLO/detect
    } catch (e: Exception) { 0L }

    fun isReady() = ctx != 0L

    /**
     * clickX/clickY: toạ độ PIXEL theo đúng ảnh gốc tại `imagePath` (không
     * phải toạ độ normalized 0..1 — khác quy ước Rect trong FaceHandDetector,
     * vì đây là input trực tiếp của decoder MobileSAM, giữ nguyên contract
     * gốc của model để không phải quy đổi thêm 1 lớp có thể gây lệch).
     */
    suspend fun clickToMask(imagePath: String, clickX: Float, clickY: Float, outDir: File, panelIndex: Int): String? =
        withContext(Dispatchers.IO) {
            if (!isReady()) return@withContext null
            val maskFile = File(outDir, "panel_%03d_manualmask.png".format(panelIndex))
            val result = NativeBridge.mobileSamClickToMask(ctx, imagePath, clickX, clickY, maskFile.absolutePath)
            result.takeIf { it.isNotBlank() }
        }

    /**
     * Vẽ lại đúng vùng mask vừa phân đoạn — gọi CHUNG `img2imgFix()`, cùng
     * hàm auto-fix mặt/tay (mục 17) đang dùng. denoiseStrength cho user tự
     * chỉnh (mặc định theo cùng "thông số vàng" 0.35-0.45 đã thống nhất).
     */
    suspend fun inpaintMaskedRegion(
        panelIndex: Int, prompt: String, negativePrompt: String, stylePrompt: String,
        imagePath: String, maskPath: String, denoiseStrength: Float,
        width: Int, height: Int, seed: Long, outDir: File
    ): String = imagePipeline.img2imgFix(
        panelIndex = panelIndex, prompt = prompt, negativePrompt = negativePrompt, stylePrompt = stylePrompt,
        inputPath = imagePath, maskPath = maskPath, denoiseStrength = denoiseStrength,
        width = width, height = height, steps = 20, cfgScale = 7f, seed = seed,
        ultrafix = false, ultrafixTile = 512, outDir = outDir
    ) { _, _ -> }

    fun close() { if (ctx != 0L) NativeBridge.mobileSamFree(ctx) }
}
