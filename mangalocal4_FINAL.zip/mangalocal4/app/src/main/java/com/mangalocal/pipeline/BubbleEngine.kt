package com.mangalocal.pipeline

import com.mangalocal.model.*
import java.io.File
import java.util.UUID

class BubbleEngine(private val storyManager: StoryManager) {

    private var yoloCtx: Long = 0

    fun loadYolo(): Boolean {
        if (!storyManager.hasYolo()) return false
        yoloCtx = NativeBridge.yoloInit(storyManager.yoloDir.absolutePath)
        return yoloCtx != 0L
    }

    fun freeYolo() {
        if (yoloCtx != 0L) { NativeBridge.yoloFree(yoloCtx); yoloCtx = 0 }
    }

    /**
     * Tự động đặt bubble dựa trên vị trí nhân vật trong ảnh.
     * YOLOv8 detect face → tính vị trí bubble không che mặt.
     */
    fun autoPplaceBubbles(imagePath: String, dialogues: List<DialogueLine>): List<Bubble> {
        if (dialogues.isEmpty()) return emptyList()

        val detections = if (yoloCtx != 0L && File(imagePath).exists()) {
            NativeBridge.yoloDetect(yoloCtx, imagePath)
                .toList()
                .chunked(5) // [x1,y1,x2,y2,conf]
                .filter { it.size == 5 && it[4] > 0.4f }
                .map { BoundingBox(it[0], it[1], it[2], it[3], it[4]) }
        } else emptyList()

        return dialogues.mapIndexed { i, dialogue ->
            val pos = calculateBubblePosition(detections, i, dialogues.size)
            Bubble(
                id = UUID.randomUUID().toString(),
                characterName = dialogue.characterName,
                text = dialogue.text,
                type = dialogue.type,
                xNorm = pos.first,
                yNorm = pos.second,
                widthNorm = 0.42f,
                isAutoPlaced = true
            )
        }
    }

    /**
     * Tính vị trí bubble tối ưu:
     * - Không đặt lên mặt nhân vật (từ detection boxes)
     * - Phân bố đều nếu có nhiều bubble
     * - Ưu tiên góc trên nếu không có detection
     */
    private fun calculateBubblePosition(
        detections: List<BoundingBox>,
        bubbleIndex: Int,
        totalBubbles: Int
    ): Pair<Float, Float> {
        // Chia màn hình thành các vùng an toàn
        val safeZones = listOf(
            Pair(0.05f, 0.04f),  // góc trên trái
            Pair(0.53f, 0.04f),  // góc trên phải
            Pair(0.05f, 0.55f),  // góc dưới trái
            Pair(0.53f, 0.55f),  // góc dưới phải
            Pair(0.05f, 0.28f),  // giữa trái
            Pair(0.53f, 0.28f)   // giữa phải
        )

        if (detections.isEmpty()) {
            // Không có detection → phân bố theo grid đơn giản
            val zone = safeZones[bubbleIndex % safeZones.size]
            return zone
        }

        // Tìm vùng ít bị che nhất
        val scored = safeZones.map { zone ->
            val overlap = detections.sumOf { det ->
                overlapArea(zone.first, zone.second, 0.42f, 0.18f,
                    det.x1, det.y1, det.x2 - det.x1, det.y2 - det.y1).toDouble()
            }
            Pair(zone, overlap)
        }.sortedBy { it.second }

        return scored[bubbleIndex % scored.size].first
    }

    private fun overlapArea(
        ax: Float, ay: Float, aw: Float, ah: Float,
        bx: Float, by: Float, bw: Float, bh: Float
    ): Float {
        val ox = maxOf(0f, minOf(ax + aw, bx + bw) - maxOf(ax, bx))
        val oy = maxOf(0f, minOf(ay + ah, by + bh) - maxOf(ay, by))
        return ox * oy
    }

    /**
     * Tạo bubble mặc định từ dialogue khi không có YOLO
     */
    fun defaultBubbles(dialogues: List<DialogueLine>): List<Bubble> {
        val positions = listOf(
            Pair(0.05f, 0.04f), Pair(0.53f, 0.04f),
            Pair(0.05f, 0.52f), Pair(0.53f, 0.52f),
            Pair(0.05f, 0.28f), Pair(0.53f, 0.28f)
        )
        return dialogues.mapIndexed { i, d ->
            val pos = positions[i % positions.size]
            Bubble(UUID.randomUUID().toString(), d.characterName, d.text, d.type,
                pos.first, pos.second, 0.40f, false)
        }
    }

    data class BoundingBox(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val conf: Float)
}
