package com.mangalocal.pipeline

import com.mangalocal.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class LLMParser(
    private val modelPath: String,
    private val nThreads: Int = 4,
    private val nGpuLayers: Int = 0
) {

    private var ctx: Long = 0

    // BUG PHÁT HIỆN KHI ĐỘNG VÀO FILE NÀY (không liên quan tính năng routing
    // mới): MangaPipeline.generatePanels()/regeneratePanel() gọi parser.init()
    // nhưng hàm này CHƯA TỪNG TỒN TẠI — nghĩa là ctx luôn = 0, mọi lời gọi
    // llamaGenerate() bên dưới thực chất chạy trên handle rỗng (native trả
    // về "" ngay từ dòng đầu `if (!h) return ""`, xem jni_bridge.cpp) — parse
    // kịch bản/prompt build LẼ RA đã fail-silent về nhánh catch{} (câu Scene
    // rỗng / PromptResult fallback) từ đầu, không phải lỗi mới do tôi gây ra.
    // Thêm hàm init() còn thiếu này để đúng như MangaPipeline đang mong đợi.
    suspend fun init() = withContext(Dispatchers.IO) {
        if (ctx != 0L) return@withContext
        ctx = NativeBridge.llamaInit(modelPath, nThreads, 2048, nGpuLayers)
        if (ctx == 0L) throw RuntimeException(
            "Không load được LLM tại $modelPath.\n(xem logcat tag MangaLocal để biết lý do cụ thể)")
    }

    // Dịch mô tả tự nhiên (tiếng Việt, user tự viết) sang tag SD1.5, riêng
    // theo từng giai đoạn (mục 24 TECHNICAL_STATUS.md — theo đúng yêu cầu
    // "1 setting áp dụng riêng từng giai đoạn + 1 setting riêng từng ảnh").
    // worldRules: quy tắc bối cảnh chung của Story (Story.worldRules) — LLM
    // dùng làm ngữ cảnh nền, KHÔNG lặp lại nguyên văn vào prompt (tránh
    // prompt quá dài) — chỉ dùng để hiểu đúng ý khi dịch.
    suspend fun translateStagePrompt(
        naturalDescription: String, stage: PromptStage, worldRules: String, styleHint: String
    ): PromptResult = withContext(Dispatchers.IO) {
        val raw = NativeBridge.llamaGenerate(ctx, stageTranslatePrompt(naturalDescription, stage, worldRules, styleHint), 350, 0.15f)
        extractStageTranslation(raw)
    }

    private fun stageTranslatePrompt(desc: String, stage: PromptStage, worldRules: String, styleHint: String): String {
        val stageGuide = when (stage) {
            PromptStage.TXT2IMG ->
                "Dịch ĐẦY ĐỦ mô tả cảnh sau sang tag SD1.5 (bối cảnh, nhân vật, hành động, camera, ánh sáng)."
            PromptStage.UPSCALE_REDRAW ->
                "Đây là bước upscale-vẽ-lại (KHÔNG phải sinh cảnh mới) — bố cục ảnh gốc đã đúng, KHÔNG mô tả " +
                "lại toàn cảnh. Chỉ trả về tag về CHẤT LƯỢNG BỀ MẶT/CHI TIẾT (vd \"detailed skin texture, " +
                "sharp focus, fine details\"), tối đa 15 từ, không nhắc lại nhân vật/hành động."
            PromptStage.INPAINT ->
                "Đây là bước inpaint 1 VÙNG LỖI cụ thể (KHÔNG phải toàn ảnh) — CHỈ mô tả đúng hành động/chi " +
                "tiết của vùng đang sửa, KHÔNG lặp lại mô tả toàn cảnh, KHÔNG nhắc bối cảnh/màu tóc/trang phục " +
                "không liên quan trực tiếp vùng lỗi."
        }
        val rulesBlock = if (worldRules.isNotBlank()) "\nBối cảnh chung của truyện (chỉ để HIỂU ý, đừng chép nguyên văn): $worldRules\n" else ""
        return """
$stageGuide
Return ONLY JSON, no markdown: {"positive":"...","negative":"..."}
Style: $styleHint
$rulesBlock
Mô tả cần dịch (tiếng Việt): $desc
""".trimIndent()
    }

    private fun extractStageTranslation(raw: String): PromptResult {
        return try {
            val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
            val o = JSONObject(if (s != -1 && e > s) raw.substring(s, e + 1) else raw.trim())
            PromptResult(o.getString("positive"), o.optString("negative", ""), null, "any")
        } catch (ex: Exception) {
            PromptResult(raw.trim().take(200), "", null, "any")
        }
    }


    // ipAdapterCharacterNames: tên các nhân vật ĐÃ được set anchorImagePath
    // (đã có sẵn trong Story TRƯỚC lúc gọi, ví dụ user tự thêm qua
    // CharactersScreen từ trước) — mỗi người trong nhóm này chỉ neo được
    // ngoại hình khi là NGƯỜI DUY NHẤT trong nhóm xuất hiện ở 1 panel (xem
    // TECHNICAL_STATUS.md mục 12). Đây là gợi ý MỀM cho LLM lúc viết kịch
    // bản — không ép buộc cốt truyện, vì nhiều khi 2 nhân vật BẮT BUỘC phải
    // gặp nhau. detectIpAdapterConflicts() ở StoryManager mới là nơi phát
    // hiện THẬT SỰ đáng tin (đếm code Kotlin, không dựa vào LLM có nghe lời
    // hay không).
    suspend fun parseStory(
        text: String, panelCount: Int, ipAdapterCharacterNames: List<String> = emptyList()
    ): List<Scene> =
        withContext(Dispatchers.IO) {
            val raw = NativeBridge.llamaGenerate(
                ctx, scenePrompt(text, panelCount, ipAdapterCharacterNames), 1800, 0.1f
            )
            parseScenes(raw, panelCount)
        }

    suspend fun buildPrompt(
        scene: Scene,
        charPrompts: Map<String, String>,
        stylePrompt: String,
        availablePoseTemplates: List<String> = emptyList(),
        worldRules: String = "", // mục 24 TECHNICAL_STATUS.md — quy tắc bối cảnh chung, đồng bộ với 2 giai đoạn còn lại
        templateTags: Map<String, List<String>> = emptyMap() // mục 6.4/34 — nhãn tương tác user tự gắn, giúp LLM chọn tư thế khớp kịch bản hơn
    ): PromptResult =
        withContext(Dispatchers.IO) {
            val charDesc = scene.characters.mapNotNull { charPrompts[it] }.joinToString(", ")
            val raw = NativeBridge.llamaGenerate(
                ctx, promptTemplate(scene, charDesc, stylePrompt, availablePoseTemplates, worldRules, templateTags), 400, 0.2f
            )
            extractPrompts(raw, scene, stylePrompt, availablePoseTemplates)
        }

    /**
     * Phân tích tất cả nhân vật xuất hiện trong scenes, đếm tần suất
     * để StoryManager tự động phân loại MAIN/SUPPORTING/ONETIME
     */
    fun extractCharacterFrequency(scenes: List<Scene>): Map<String, Int> {
        val freq = mutableMapOf<String, Int>()
        scenes.forEach { scene ->
            scene.characters.forEach { name ->
                freq[name] = (freq[name] ?: 0) + 1
            }
        }
        return freq
    }

    fun free() { if (ctx != 0L) { NativeBridge.llamaFree(ctx); ctx = 0 } }

    // ── Templates ─────────────────────────────────────────────────────────

    private fun scenePrompt(text: String, count: Int, ipAdapterCharacterNames: List<String>): String {
        val ipaBlock = if (ipAdapterCharacterNames.isNotEmpty())
            "\nLƯU Ý: các nhân vật sau chỉ giữ được ngoại hình nhất quán khi họ là NGƯỜI DUY NHẤT " +
                "thuộc nhóm này xuất hiện trong 1 panel: ${ipAdapterCharacterNames.joinToString(", ")}. " +
                "Khi có thể, TRÁNH để 2+ người trong nhóm này cùng xuất hiện chung 1 panel — tách thành " +
                "2 panel liên tiếp nếu hợp lý. Nếu cốt truyện THẬT SỰ cần họ gặp nhau cùng lúc, cứ viết " +
                "bình thường, đừng bẻ cong nội dung truyện chỉ để né việc này.\n"
        else ""
        return """
Split this story into exactly $count visual comic panels.
Return ONLY a JSON array, no markdown, no explanation.

[{"index":0,"description":"visual scene description","characters":["name1","name2"],"mood":"dark","cameraAngle":"medium-shot","action":"what happens","setting":"location","dialogue":[{"character":"name1","text":"spoken words","type":"SPEECH"}]}]

Mood: dark|bright|tense|calm|dramatic|romantic|comedic|mysterious
Camera: extreme-close-up|close-up|medium-shot|wide-shot|overhead|low-angle
Dialogue type: SPEECH|THOUGHT|NARRATION|SHOUT
List ALL character names that appear, even minor ones.

LƯU Ý VỀ CAMERA khi 2+ nhân vật chạm thân thể trực tiếp (ôm, vật nhau, đánh
nhau tay đôi, kéo/giằng co...): ưu tiên "wide-shot" hoặc "overhead" thay vì
"close-up"/"extreme-close-up" — khung rộng cho model nhiều không gian hơn để
vẽ tách bạch 2 thân người, giảm (KHÔNG loại bỏ hẳn) rủi ro dính/lẫn tay chân
khi render. Đây chỉ là giảm nhẹ, không phải giải pháp triệt để — cảnh chạm
thân thể sát vẫn là trường hợp khó nhất của SD nói chung, có thể vẫn cần sửa
tay ở bước Gallery Review. KHÔNG đổi nội dung/action của cảnh chỉ để né việc
này — chỉ đổi cameraAngle khi hợp lý với ý truyện.
$ipaBlock
Story:
$text
""".trimIndent()
    }

    // Gợi ý rủi ro cụ thể theo thuộc tính scene — để LLM không chỉ lặp lại
    // 1 câu negative chung chung, mà thực sự nghĩ đến lỗi SD1.5 hay gặp
    // trong tình huống NÀY. Đây là phần "mở rộng" đã ghi ở mục 6.3 —
    // heuristic gợi ý, không phải quy tắc cứng, LLM vẫn tự quyết câu chữ.
    private val contactKeywords = listOf(
        "ôm", "hug", "vật nhau", "vật lộn", "grapple", "wrestl", "đánh nhau", "fight",
        "đấm", "punch", "kéo", "giằng", "ghì", "siết", "đè", "pin down", "tay đôi"
    )

    private fun negativeRiskHints(scene: Scene): List<String> {
        val hints = mutableListOf<String>()
        if (scene.characters.size >= 2) hints += "nhiều người đứng gần nhau dễ dính/lẫn tay chân, cân nhắc thêm từ khoá tránh thừa chi/dính người"
        if (scene.cameraAngle in listOf("extreme-close-up", "close-up")) hints += "cận mặt/tay dễ lỗi ngón tay, mắt lệch — cân nhắc thêm từ khoá tránh biến dạng ngón/mắt"
        if (scene.mood in listOf("dark", "tense", "mysterious")) hints += "cảnh tối dễ bị SD kéo sáng bù — cân nhắc từ khoá tránh ánh sáng/không khí không hợp tông tối"
        if (scene.cameraAngle == "wide-shot" || scene.cameraAngle == "overhead") hints += "toàn cảnh dễ lộ nhân vật phụ bị biến dạng ở nền — cân nhắc từ khoá tránh người/vật thể nền bị méo"
        // Chạm thân thể trực tiếp (ôm/vật/đánh nhau tay đôi...) — rủi ro
        // dính người NẶNG NHẤT trong tất cả các trường hợp, kể cả với
        // wide-shot/overhead đã ưu tiên từ scenePrompt(). KHÔNG có cách giải
        // quyết triệt để (đã bàn với user) — đây chỉ là giảm nhẹ thêm ở tầng
        // prompt, không phải fix thật.
        val hasContact = scene.characters.size >= 2 &&
            contactKeywords.any { scene.action.contains(it, ignoreCase = true) || scene.description.contains(it, ignoreCase = true) }
        if (hasContact) hints += "2 người chạm thân thể trực tiếp (ôm/vật/đánh nhau) — RỦI RO DÍNH NGƯỜI CAO NHẤT, " +
            "cân nhắc thêm từ khoá tránh dính liền cơ thể/thừa chi/tay chân sai vị trí; nhắc rõ ranh giới 2 cơ thể trong positive prompt nếu có thể (vd \"two distinct bodies, clear silhouette separation\")"
        return hints
    }

    // Hardcode CỨNG (không chỉ gợi ý cho LLM — LLM có thể quên) — theo đúng
    // đề xuất user: bộ negative chuyên trị dính người/giải phẫu dị thường,
    // TỰ ĐỘNG nối vào MỌI lần sinh có ≥2 người, người dùng không cần gõ.
    // Chỉ áp dụng CÓ ĐIỀU KIỆN (không phải mọi ảnh) — panel 1 người không
    // cần cụm từ "conjoined twins" làm loãng negative prompt, đúng khuyến
    // nghị chung "negative prompt càng có mục tiêu càng tốt".
    private val hardcodedAntiFusionTerms =
        "fused bodies, deformed limbs, extra arms, extra legs, conjoined twins, monstrous body, messy anatomy, merged bodies"

    private fun appendHardcodedNegativeIfNeeded(scene: Scene, llmNegative: String): String {
        if (scene.characters.size < 2) return llmNegative
        // Tránh lặp nếu LLM đã tự viết đúng cụm này rồi (hiếm nhưng có thể xảy ra).
        return if (llmNegative.contains("fused bodies", ignoreCase = true)) llmNegative
        else "$llmNegative, $hardcodedAntiFusionTerms"
    }

    private fun promptTemplate(
        scene: Scene, charDesc: String, styleHint: String, availablePoseTemplates: List<String>,
        worldRules: String = "", templateTags: Map<String, List<String>> = emptyMap()
    ): String {
        val risks = negativeRiskHints(scene)
        val riskBlock = if (risks.isNotEmpty())
            "\nRủi ro cần lưu ý khi viết 'negative' cho CẢNH NÀY (không phải câu negative chung chung):\n" +
                risks.joinToString("\n") { "- $it" }
        else ""
        val worldRulesBlock = if (worldRules.isNotBlank())
            "\nBối cảnh chung của truyện (chỉ để HIỂU ý, đừng chép nguyên văn vào prompt): $worldRules\n"
        else ""
        // Danh sách pose THẬT của user (từ pose_library.json, sinh bởi
        // extract_pose_library.py) — LLM chỉ được chọn trong danh sách này,
        // không được bịa tên. Rỗng thì báo "none", đừng đoán. Kèm actionTags
        // (mục 6.4/34 TECHNICAL_STATUS.md, user tự gắn lúc lưu) nếu có, giúp
        // LLM chọn khớp kịch bản hơn thay vì chỉ đoán theo tên.
        val poseBlock = if (availablePoseTemplates.isNotEmpty()) {
            val listWithTags = availablePoseTemplates.joinToString(", ") { name ->
                val tags = templateTags[name]
                if (!tags.isNullOrEmpty()) "$name [${tags.joinToString(",")}]" else name
            }
            "\nAvailable pose templates (choose the ONE that best matches the action/character " +
                "count above, or \"none\" if nothing fits — do NOT invent a name not in this list; " +
                "tags in [brackets] describe the interaction, use them to pick the best match):\n" +
                listWithTags
        } else "\nNo pose templates available yet — always answer poseTemplate:\"none\"."
        return """
Write a Stable Diffusion prompt for this comic panel.
Return ONLY JSON, no markdown: {"positive":"...","negative":"...","poseTemplate":"...","poseAngle":"front|side_left|side_right|any"}

Scene: ${scene.description}
Action: ${scene.action}
Setting: ${scene.setting}
Mood: ${scene.mood}
Camera: ${scene.cameraAngle}
Characters: $charDesc
Style: $styleHint
$worldRulesBlock
$riskBlock
The "negative" field must be SPECIFIC to this scene's actual risks above (in English,
comma-separated SD keywords), not a generic list. Keep it under 25 words.
The "positive" field must include a concrete facial-expression / body-language detail matching
the mood (e.g. "clenched jaw, narrowed eyes" for tense, not just the word "tense" itself).
$poseBlock
""".trimIndent()
    }

    // ── Parsers ───────────────────────────────────────────────────────────

    private fun parseScenes(raw: String, count: Int): List<Scene> {
        return try {
            val s = raw.indexOf('['); val e = raw.lastIndexOf(']')
            val arr = JSONArray(if (s != -1 && e > s) raw.substring(s, e + 1) else raw.trim())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val chars = o.optJSONArray("characters")
                    ?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
                val dialogue = o.optJSONArray("dialogue")
                    ?.let { a -> (0 until a.length()).mapNotNull { j ->
                        try {
                            val d = a.getJSONObject(j)
                            DialogueLine(d.getString("character"), d.getString("text"),
                                enumValueOf(d.optString("type", "SPEECH")))
                        } catch (ex: Exception) { null }
                    }} ?: emptyList()
                Scene(i, o.optString("description","Scene ${i+1}"), chars,
                    o.optString("mood","neutral"), o.optString("cameraAngle","medium-shot"),
                    o.optString("action",""), o.optString("setting",""), dialogue)
            }
        } catch (e: Exception) {
            val chunk = (raw.length / count).coerceAtLeast(1)
            raw.chunked(chunk).take(count).mapIndexed { i, s ->
                Scene(i, s.take(120), emptyList(), "neutral", "medium-shot")
            }
        }
    }

    private fun extractPrompts(
        raw: String, scene: Scene, style: String, availablePoseTemplates: List<String>
    ): PromptResult {
        return try {
            val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
            val o = JSONObject(if (s != -1 && e > s) raw.substring(s, e + 1) else raw.trim())
            val rawPose = o.optString("poseTemplate", "none")
            // KHÔNG tin thẳng — LLM có thể bịa tên không tồn tại trong
            // pose_library.json thật. Chỉ nhận nếu khớp CHÍNH XÁC 1 key có
            // thật trong danh sách; sai/rỗng/"none" đều -> null (để
            // MangaPipeline tự rơi về fallback heuristic).
            val pose = rawPose.takeIf { it.isNotBlank() && it != "none" && it in availablePoseTemplates }
            val angle = o.optString("poseAngle", "any").let {
                if (it in listOf("front", "side_left", "side_right", "any")) it else "any"
            }
            PromptResult(o.getString("positive"), appendHardcodedNegativeIfNeeded(scene, o.getString("negative")), pose, angle)
        } catch (ex: Exception) {
            PromptResult(
                "${scene.description}, ${scene.mood} mood, ${scene.cameraAngle}, $style",
                appendHardcodedNegativeIfNeeded(scene, "bad quality, blurry, deformed"),
                null, "any"
            )
        }
    }
}
