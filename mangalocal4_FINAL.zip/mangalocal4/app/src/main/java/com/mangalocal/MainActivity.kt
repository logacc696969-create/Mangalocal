package com.mangalocal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.mangalocal.pipeline.NativeBridge
import com.mangalocal.ui.*
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Đọc + xoá log crash lần chạy trước (nếu có — xem
        // MangaLocalApplication.kt cho lỗi Java/Kotlin, và
        // native_crash_handler.cpp cho crash tầng C++).
        val javaCrash = File(filesDir, "last_crash.txt").let {
            if (it.exists()) it.readText().also { _ -> it.delete() } else null
        }
        val nativeCrash = File(filesDir, "last_native_crash.txt").let {
            if (it.exists()) it.readText().also { _ -> it.delete() } else null
        }
        val crashText = listOfNotNull(javaCrash, nativeCrash)
            .takeIf { it.isNotEmpty() }
            ?.joinToString("\n\n──────────\n\n")

        // SỬA (sau phản hồi "vẫn văng, không có log"): BUG THẬT trước đây —
        // dialog hiện crashLog nằm BÊN TRONG MangaLocalApp(vm = viewModel()).
        // Nếu viewModel() crash lại, TOÀN BỘ thân hàm MangaLocalApp không
        // chạy được dòng nào — kể cả đoạn code hiện dialog crashLog! Log có
        // ghi được cũng không bao giờ có cơ hội hiện ra màn hình. Giờ
        // chuyển dialog này ra TẦNG NGOÀI CÙNG, không phụ thuộc ViewModel
        // hay native gì cả. Đồng thời đổi từ tự động chuyển bước
        // (LaunchedEffect — có thể chỉ hiện đúng 1 khung hình rồi văng
        // ngay, mắt thường không kịp thấy) sang BẤM NÚT thủ công ở từng
        // bước — đảm bảo chắc chắn nhìn thấy trạng thái trước khi bước tiếp
        // theo có thể văng.
        setContent {
            // 0 = chưa bấm gì, 1 = đã tạo ViewModel xong, 2 = đã thử native xong
            var stage by remember { mutableStateOf(0) }
            var crashLog by remember { mutableStateOf(crashText) }
            val clipboard = LocalClipboardManager.current

            MaterialTheme(colorScheme = C.scheme) {
                Surface(color = C.Bg) {
                    Column(Modifier.padding(24.dp)) {
                        Text("MangaLocal — chẩn đoán từng bước", color = C.T1, fontSize = 16.sp)
                        Spacer(Modifier.height(16.dp))

                        if (stage == 0) {
                            Text("Bước 1: chưa tạo ViewModel/StoryManager.", color = C.T2, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { stage = 1 }) { Text("Bước tiếp: Tạo ViewModel") }
                        } else {
                            // Chỉ tới đây mới thật sự gọi viewModel() — nếu nó
                            // crash, dòng chữ + dialog phía trên ĐÃ hiện xong
                            // rồi (khác bản cũ: dialog nằm chung 1 hàm với
                            // viewModel() nên không kịp hiện).
                            MangaLocalStages(stage = stage, onAdvance = { stage = it })
                        }
                    }
                }

                crashLog?.let { log ->
                    AlertDialog(
                        onDismissRequest = { crashLog = null },
                        title = { Text("⚠️ App vừa bị crash lần trước", color = C.Orange) },
                        text = {
                            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                                SelectionContainer {
                                    Text(log, color = C.T2, fontSize = 11.sp)
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { clipboard.setText(AnnotatedString(log)) }) { Text("Copy") }
                        },
                        dismissButton = {
                            TextButton(onClick = { crashLog = null }) { Text("Đóng") }
                        },
                        containerColor = C.S1
                    )
                }
            }
        }
    }
}

// Tách riêng để viewModel() chỉ được gọi khi Composable này THẬT SỰ được
// composed (tức sau khi user bấm nút ở Bước 1) — không nằm chung hàm với
// phần hiện dialog crash log ở MainActivity.
@Composable
private fun MangaLocalStages(stage: Int, onAdvance: (Int) -> Unit) {
    val vm: MainViewModel = viewModel()
    // Tới được dòng này nghĩa là viewModel() đã tạo xong, KHÔNG văng.

    Spacer(Modifier.height(12.dp))
    Text("✅ Bước 2 OK: ViewModel/StoryManager tạo xong, không văng.", color = C.T2, fontSize = 12.sp)

    if (stage < 2) {
        Spacer(Modifier.height(12.dp))
        Button(onClick = { onAdvance(2) }) { Text("Bước tiếp: Kiểm tra thư viện native") }
    } else {
        Spacer(Modifier.height(12.dp))
        MangaLocalNativeCheck(vm)
    }
}

@Composable
private fun MangaLocalNativeCheck(vm: MainViewModel) {
    var nativeStatus by remember { mutableStateOf("Đang kiểm tra thư viện native...") }
    LaunchedEffect(Unit) {
        try {
            val app = vm.getApplication<android.app.Application>()
            NativeBridge.setCrashLogPath(File(app.filesDir, "last_native_crash.txt").absolutePath)
            nativeStatus = "✅ Thư viện native nạp thành công."
        } catch (t: Throwable) {
            nativeStatus = "❌ Lỗi Java khi nạp thư viện native: ${t.javaClass.simpleName}: ${t.message}"
        }
    }
    Text(nativeStatus, color = C.T2, fontSize = 12.sp)

    if (nativeStatus.startsWith("✅")) {
        Spacer(Modifier.height(16.dp))
        MangaLocalApp(vm = vm)
    }
}

@Composable
fun MangaLocalApp(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val error by vm.error.collectAsState()

    MaterialTheme(colorScheme = C.scheme) {
        Surface(color = C.Bg) {
            NavHost(nav, startDestination = "stories") {
                composable("stories")          { StoryListScreen(nav, vm) }
                composable("story_detail")     { StoryDetailScreen(nav, vm) }
                composable("generating")       { GeneratingScreen(nav, vm) }
                composable("gallery_review")   { GalleryReviewScreen(nav, vm) }
                composable("post_processing")  { PostProcessingScreen(nav, vm) }
                composable("characters_detail"){ CharactersDetailScreen(nav, vm) }
                composable("characters")       { CharactersDetailScreen(nav, vm) }
                composable("settings")         { SettingsScreen(nav, vm) }
                composable("pose_editor")      { PoseEditorScreen(nav, vm) }
            }
        }

        error?.let { msg ->
            AlertDialog(
                onDismissRequest = { vm.clearError() },
                title = { Text("⚠️ Thông báo", color = C.Orange) },
                text = { Text(msg, color = C.T2) },
                confirmButton = { TextButton(onClick = { vm.clearError() }) { Text("OK") } },
                containerColor = C.S1
            )
        }
    }
}
