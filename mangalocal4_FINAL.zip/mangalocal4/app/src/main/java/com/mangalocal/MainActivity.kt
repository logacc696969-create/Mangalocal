package com.mangalocal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.mangalocal.pipeline.NativeBridge
import com.mangalocal.ui.*
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Đọc + xoá log crash lần chạy trước (nếu có — xem
        // MangaLocalApplication.kt cho lỗi Java/Kotlin, và
        // native_crash_handler.cpp cho crash tầng C++), hiện ngay trong
        // dialog kèm nút Copy.
        val javaCrash = File(filesDir, "last_crash.txt").let {
            if (it.exists()) it.readText().also { _ -> it.delete() } else null
        }
        val nativeCrash = File(filesDir, "last_native_crash.txt").let {
            if (it.exists()) it.readText().also { _ -> it.delete() } else null
        }
        val crashText = listOfNotNull(javaCrash, nativeCrash)
            .takeIf { it.isNotEmpty() }
            ?.joinToString("\n\n──────────\n\n")

        setContent {
            var showApp by remember { mutableStateOf(false) }

            // GIAI ĐOẠN 1: vẽ MỘT DÒNG CHỮ DUY NHẤT, không đụng tới
            // MainViewModel/StoryManager/NativeBridge — nếu ngay cả dòng
            // này cũng không kịp hiện thì crash nằm ở tầng Activity/theme,
            // không liên quan gì tới ViewModel hay native cả.
            MaterialTheme(colorScheme = C.scheme) {
                Surface(color = C.Bg) {
                    if (!showApp) {
                        Text(
                            "Đang khởi động MangaLocal...",
                            color = C.T2,
                            modifier = Modifier.padding(24.dp)
                        )
                    } else {
                        MangaLocalApp(
                            initialCrashLog = crashText,
                            nativeCrashLogPath = File(filesDir, "last_native_crash.txt").absolutePath
                        )
                    }
                }
            }

            // GIAI ĐOẠN 2: sau khi khung hình đầu tiên (chữ "Đang khởi
            // động...") đã kịp vẽ, mới chuyển sang mount MangaLocalApp —
            // lúc đó mới chạm tới MainViewModel (viewModel()) lần đầu.
            LaunchedEffect(Unit) { showApp = true }
        }
    }
}

@Composable
fun MangaLocalApp(
    vm: MainViewModel = viewModel(),
    initialCrashLog: String? = null,
    nativeCrashLogPath: String? = null
) {
    val nav = rememberNavController()
    val error by vm.error.collectAsState()
    var crashLog by remember { mutableStateOf(initialCrashLog) }
    val clipboard = LocalClipboardManager.current

    // CHẨN ĐOÁN (sau phản hồi "chưa kịp vẽ giao diện đã văng"): trước đây
    // NativeBridge được chạm ngay trong Application.onCreate(), TRƯỚC khi
    // có khung hình UI nào — không cách nào biết "văng trước khi vẽ" là do
    // native hay do gì khác. Giờ chỉ chạm NativeBridge ở ĐÂY, bên trong
    // LaunchedEffect — nghĩa là chạy SAU khi khung hình đầu tiên (bao gồm
    // dòng trạng thái bên dưới) đã kịp vẽ lên màn hình. Nếu app vẫn văng,
    // ít nhất sẽ THẤY được dòng "Đang kiểm tra thư viện native..." trước
    // đó — xác nhận chắc chắn Compose/Activity/ViewModel không phải
    // nguyên nhân, chỉ còn lại đúng bước nạp thư viện .so là nghi phạm.
    var nativeStatus by remember { mutableStateOf("Đang kiểm tra thư viện native...") }
    LaunchedEffect(Unit) {
        try {
            if (nativeCrashLogPath != null) NativeBridge.setCrashLogPath(nativeCrashLogPath)
            nativeStatus = "✅ Thư viện native nạp thành công."
        } catch (t: Throwable) {
            nativeStatus = "❌ Lỗi Java khi nạp thư viện native: ${t.javaClass.simpleName}: ${t.message}"
        }
    }

    MaterialTheme(colorScheme = C.scheme) {
        Surface(color = C.Bg) {
            Column {
                // Dòng trạng thái tạm thời để chẩn đoán — có thể bỏ sau khi
                // xác định xong nguyên nhân crash.
                Text(nativeStatus, color = C.T2, fontSize = 11.sp, modifier = Modifier)

                NavHost(nav, startDestination = "stories") {
                    composable("stories")          { StoryListScreen(nav, vm) }
                    composable("story_detail")     { StoryDetailScreen(nav, vm) }
                    composable("generating")       { GeneratingScreen(nav, vm) }
                    composable("gallery_review")   { GalleryReviewScreen(nav, vm) }
                    composable("post_processing")  { PostProcessingScreen(nav, vm) }
                    composable("characters_detail"){ CharactersDetailScreen(nav, vm) }
                    composable("characters")       { CharactersDetailScreen(nav, vm) }
                    composable("settings")         { SettingsScreen(nav, vm) }
                    composable("pose_editor")      { PoseEditorScreen(nav, vm) }
                }
            }
        }

        error?.let { msg ->
            AlertDialog(
                onDismissRequest = { vm.clearError() },
                title = { Text("⚠️ Thông báo", color = C.Orange) },
                text = { Text(msg, color = C.T2) },
                confirmButton = { TextButton(onClick = { vm.clearError() }) { Text("OK") } },
                containerColor = C.S1
            )
        }

        crashLog?.let { log ->
            AlertDialog(
                onDismissRequest = { crashLog = null },
                title = { Text("⚠️ App vừa bị crash lần trước", color = C.Orange) },
                text = {
                    Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                        SelectionContainer {
                            Text(log, color = C.T2, fontSize = 11.sp)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { clipboard.setText(AnnotatedString(log)) }) { Text("Copy") }
                },
                dismissButton = {
                    TextButton(onClick = { crashLog = null }) { Text("Đóng") }
                },
                containerColor = C.S1
            )
        }
    }
}
