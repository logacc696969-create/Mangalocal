package com.mangalocal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.mangalocal.ui.*
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Đọc + xoá log crash lần chạy trước (nếu có — xem
        // MangaLocalApplication.kt), hiện ngay trong dialog kèm nút Copy.
        val crashFile = File(filesDir, "last_crash.txt")
        val crashText = if (crashFile.exists()) {
            crashFile.readText().also { crashFile.delete() }
        } else null

        setContent { MangaLocalApp(initialCrashLog = crashText) }
    }
}

@Composable
fun MangaLocalApp(vm: MainViewModel = viewModel(), initialCrashLog: String? = null) {
    val nav = rememberNavController()
    val error by vm.error.collectAsState()
    var crashLog by remember { mutableStateOf(initialCrashLog) }
    val clipboard = LocalClipboardManager.current

    MaterialTheme(colorScheme = C.scheme) {
        Surface(color = C.Bg) {
            NavHost(nav, startDestination = "stories") {
                composable("stories")          { StoryListScreen(nav, vm) }
                composable("story_detail")     { StoryDetailScreen(nav, vm) }
                composable("generating")       { GeneratingScreen(nav, vm) }
                composable("gallery_review")   { GalleryReviewScreen(nav, vm) }
                composable("post_processing")  { PostProcessingScreen(nav, vm) }
                composable("characters_detail"){ CharactersDetailScreen(nav, vm) }
                composable("characters")       { CharactersDetailScreen(nav, vm) }
                composable("settings")         { SettingsScreen(nav, vm) }
                composable("pose_editor")      { PoseEditorScreen(nav, vm) }
            }
        }

        error?.let { msg ->
            AlertDialog(
                onDismissRequest = { vm.clearError() },
                title = { Text("⚠️ Thông báo", color = C.Orange) },
                text = { Text(msg, color = C.T2) },
                confirmButton = { TextButton(onClick = { vm.clearError() }) { Text("OK") } },
                containerColor = C.S1
            )
        }

        crashLog?.let { log ->
            AlertDialog(
                onDismissRequest = { crashLog = null },
                title = { Text("⚠️ App vừa bị crash lần trước", color = C.Orange) },
                text = {
                    Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                        SelectionContainer {
                            Text(log, color = C.T2, fontSize = 11.sp)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { clipboard.setText(AnnotatedString(log)) }) { Text("Copy") }
                },
                dismissButton = {
                    TextButton(onClick = { crashLog = null }) { Text("Đóng") }
                },
                containerColor = C.S1
            )
        }
    }
}
