package com.mangalocal.pipeline

import com.mangalocal.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Quyết định 1 panel sinh LOCAL (native MNN trên máy) hay REMOTE (gọi
 * RemoteGenerationClient tới GPU thuê ngoài) — xem mục routing trong
 * TECHNICAL_STATUS.md để hiểu đầy đủ mô hình bảo mật (TLS_EPHEMERAL KHÔNG
 * chống được chính chủ hạ tầng, chỉ CONFIDENTIAL_COMPUTING mới chống được).
 *
 * NGUYÊN TẮC AN TOÀN CHUNG cho mọi implementation ở file này: khi không chắc
 * chắn (LLM trả lời không parse được, remoteEndpoint chưa cấu hình/disabled,
 * lỗi bất kỳ...) LUÔN rơi về LOCAL. Không bao giờ fail-open sang REMOTE —
 * REMOTE là lựa chọn phải được xác nhận rõ ràng (tay hoặc policy prompt của
 * chính người dùng), không phải hành vi mặc định khi có lỗi.
 */
data class RoutingDecision(val backend: GenerationBackend, val reason: String)

interface BackendRouter {
    suspend fun decide(panel: Panel, story: Story, settings: GenerationSettings): RoutingDecision
    fun free() {}
}

/**
 * Override tay của panel LUÔN thắng tuyệt đối, bất kể router nào đang dùng
 * (MANUAL hay AUTO) — áp dụng ở MangaPipeline.resolveBackend(), không phải
 * trong từng router riêng, để logic "override tay thắng" chỉ nằm 1 chỗ.
 */
fun Panel.hasManualBackendOverride() = overrideSettings?.backendOverride != null

// ── MANUAL ───────────────────────────────────────────────────────────────
// Thứ tự ưu tiên (cao -> thấp), CHỈ 1 tầng thắng, không cộng dồn/trộn:
//   1. panel.overrideSettings.backendOverride — chọn tay riêng đúng panel này
//      (làm ở GalleryReviewScreen, sau khi đã thấy ảnh/scene cụ thể)
//   2. manualRoutingRules — quy tắc khai báo trước theo nhân vật/từ khoá
//      (làm ở SettingsScreen, áp dụng hàng loạt, không cần sinh xong mới biết)
//   3. settings.defaultBackend — mặc định chung khi không khớp gì cả
class ManualBackendRouter : BackendRouter {
    override suspend fun decide(panel: Panel, story: Story, settings: GenerationSettings): RoutingDecision {
        panel.overrideSettings?.backendOverride?.let {
            return RoutingDecision(it, "Người dùng chọn tay cho panel này")
        }

        // So khớp rule đầu tiên trong list (thứ tự = độ ưu tiên user tự sắp,
        // xem comment ManualRoutingRule) — dừng ngay khi tìm thấy, KHÔNG
        // gom hết rule khớp rồi tự suy luận thêm (giữ hành vi dễ đoán, đúng
        // như thứ tự user thấy trên UI).
        for (rule in settings.manualRoutingRules) {
            val matched = when (rule.matchType) {
                RoutingMatchType.CHARACTER -> panel.scene.characters.any {
                    it.trim().equals(rule.value.trim(), ignoreCase = true)
                }
                RoutingMatchType.KEYWORD -> {
                    val haystack = "${panel.scene.description} ${panel.scene.action} ${panel.scene.setting}".lowercase()
                    rule.value.isNotBlank() && haystack.contains(rule.value.trim().lowercase())
                }
            }
            if (matched) {
                val matchDesc = if (rule.matchType == RoutingMatchType.CHARACTER) "nhân vật \"${rule.value}\"" else "từ khoá \"${rule.value}\""
                return RoutingDecision(rule.backend, "Khớp quy tắc: $matchDesc → ${rule.backend.name}")
            }
        }

        return RoutingDecision(settings.defaultBackend, "Mặc định chung (Cài đặt > Local/Remote), không khớp quy tắc nào")
    }
}

// ── AUTO (LLM quyết định theo policy prompt của người dùng) ────────────────
// Dùng CHÍNH model LLM đang cấu hình (settings.llmModelPath) — không tải
// thêm model riêng cho việc routing, giữ đúng nguyên tắc "1 LLM cho mọi việc
// điều phối" đã áp dụng cho LLMParser. Session ctx RIÊNG, tách khỏi LLMParser
// dùng để parse kịch bản (parser đó bị free() ngay sau khi tách scene, xong
// TRƯỚC khi vào vòng lặp sinh ảnh — xem MangaPipeline.generatePanels()) —
// AutoBackendRouter cần sống xuyên suốt vòng lặp sinh ảnh nên phải tách riêng.
class AutoBackendRouter(
    private val llmModelPath: String,
    private val nThreads: Int = 4
) : BackendRouter {

    private var ctx: Long = 0
    private var initTried = false

    private fun ensureInit(): Boolean {
        if (ctx != 0L) return true
        if (initTried) return false // đã thử và fail lần trước, không thử lại mỗi panel (tốn thời gian)
        initTried = true
        ctx = NativeBridge.llamaInit(llmModelPath, nThreads, 2048, 1)
        return ctx != 0L
    }

    override suspend fun decide(panel: Panel, story: Story, settings: GenerationSettings): RoutingDecision =
        withContext(Dispatchers.IO) {
            // Chưa bật remote hoặc chưa cấu hình endpoint -> khỏi hỏi LLM làm gì,
            // REMOTE không thể thực thi được nên luôn LOCAL (tránh gọi LLM tốn
            // thời gian cho 1 quyết định đã biết trước kết quả).
            if (!settings.remoteEndpoint.enabled || settings.remoteEndpoint.baseUrl.isBlank()) {
                return@withContext RoutingDecision(GenerationBackend.LOCAL, "Chưa bật/cấu hình remote endpoint — mặc định local")
            }
            if (!ensureInit()) {
                return@withContext RoutingDecision(GenerationBackend.LOCAL, "LLM routing không khởi tạo được — fail-safe về local")
            }
            val raw = try {
                NativeBridge.llamaGenerate(ctx, buildRoutingPrompt(panel, story, settings), 120, 0.1f)
            } catch (ex: Exception) {
                return@withContext RoutingDecision(GenerationBackend.LOCAL, "LLM routing lỗi (${ex.message}) — fail-safe về local")
            }
            parseRoutingDecision(raw)
        }

    private fun buildRoutingPrompt(panel: Panel, story: Story, settings: GenerationSettings): String {
        val policy = settings.autoRoutingPolicyPrompt.ifBlank {
            // Chính sách mặc định an toàn khi user chưa tự viết gì — ưu tiên
            // riêng tư (local) cho nội dung có vẻ nhạy cảm, còn lại cho phép
            // remote để tận dụng tốc độ GPU thuê. KHÔNG tự suy diễn thêm tiêu
            // chí nào khác ngoài "nhạy cảm/riêng tư" khi user chưa nói rõ.
            "Nếu cảnh có nội dung riêng tư/nhạy cảm (bạo lực nặng, tình dục, hình ảnh " +
            "cá nhân thật của người dùng...), chọn local. Các cảnh còn lại chọn remote " +
            "để tận dụng tốc độ GPU thuê."
        }
        return """
Bạn là bộ định tuyến sinh ảnh cho 1 app truyện tranh chạy trên điện thoại.
Đọc CHÍNH SÁCH của người dùng bên dưới, rồi quyết định 1 panel nên sinh
"local" (trên máy, chậm hơn nhưng không rời khỏi thiết bị) hay "remote"
(gửi lên GPU thuê ngoài, nhanh hơn nhưng dữ liệu rời thiết bị — xem
CHÍNH SÁCH BẢO MẬT REMOTE bên dưới để hiểu rủi ro thật).

CHÍNH SÁCH CỦA NGƯỜI DÙNG (tuân thủ đúng, không tự suy diễn thêm):
$policy

CHÍNH SÁCH BẢO MẬT REMOTE (để bạn hiểu remote nghĩa là gì, không phải để lặp lại):
security_tier=${settings.remoteEndpoint.securityTier} — TLS_EPHEMERAL nghĩa là
chủ hạ tầng GPU thuê VẪN có khả năng truy cập dữ liệu lúc đang tính toán (đã
giải thích với người dùng ở nơi khác, không phải lỗi của bạn).

Panel cần quyết định:
- Mô tả cảnh: ${panel.scene.description}
- Hành động: ${panel.scene.action}
- Nhân vật: ${panel.scene.characters.joinToString(", ")}
- Tâm trạng: ${panel.scene.mood}

Return ONLY JSON, no markdown: {"backend":"local"|"remote","reason":"lý do ngắn gọn bằng tiếng Việt, dưới 20 từ"}
""".trimIndent()
    }

    private fun parseRoutingDecision(raw: String): RoutingDecision {
        return try {
            val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
            val o = JSONObject(if (s != -1 && e > s) raw.substring(s, e + 1) else raw.trim())
            val backend = when (o.optString("backend", "local").lowercase()) {
                "remote" -> GenerationBackend.REMOTE
                else -> GenerationBackend.LOCAL // bất kỳ giá trị lạ nào khác "remote" đều fail-safe về local
            }
            RoutingDecision(backend, o.optString("reason", "").ifBlank { "LLM không giải thích" })
        } catch (ex: Exception) {
            // Parse thất bại -> KHÔNG đoán mù là remote, luôn fail-safe local.
            RoutingDecision(GenerationBackend.LOCAL, "LLM trả lời không đọc được (raw: ${raw.take(60)}) — fail-safe về local")
        }
    }

    override fun free() {
        if (ctx != 0L) { NativeBridge.llamaFree(ctx); ctx = 0 }
        initTried = false
    }
}

/** Factory — chọn router theo settings.routingMode, áp dụng override tay ở lớp ngoài (MangaPipeline). */
object BackendRouterFactory {
    fun create(settings: GenerationSettings): BackendRouter =
        when (settings.routingMode) {
            RoutingMode.MANUAL -> ManualBackendRouter()
            RoutingMode.AUTO -> AutoBackendRouter(settings.llmModelPath)
        }
}
