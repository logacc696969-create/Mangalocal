package com.mangalocal.pipeline

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.mangalocal.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MangaPipeline(
    private val storyManager: StoryManager,
    private val thermalMonitor: ThermalMonitor,
    private val runtimeOptimizer: RuntimeOptimizer
) {
    private val _state = MutableStateFlow(PipelineState())
    val state: StateFlow<PipelineState> = _state.asStateFlow()

    private val imagePipeline = ImagePipeline(storyManager)
    private val exportEngine  = ExportEngine()
    private val bubbleEngine  = BubbleEngine(storyManager)
    // Dùng CHUNG 1 PoseExtractor (YOLOv8-pose, mục 19) cho cả trích xuất
    // pose_library.json LẪN auto-fix mặt/tay — đúng yêu cầu "dùng YOLO
    // xuyên suốt, không code lại autodetect riêng cho từng việc" (mục 20).
    private val poseExtractor by lazy { PoseExtractor(storyManager.appContext, storyManager) }
    private val faceHandDetector by lazy { FaceHandDetector(poseExtractor) }
    private var llmParser: LLMParser? = null
    private var backendRouter: BackendRouter? = null
    private var job: Job? = null

    // Cache hardware profile — chỉ detect 1 lần, dùng lại cho mọi chương
    private val hwProfile by lazy { runtimeOptimizer.detectHardware() }
    private val optimalConfig by lazy { runtimeOptimizer.computeOptimalConfig(hwProfile) }

    // ── Setting 2 tầng: hợp nhất GenerationSettings (chung) +
    // PanelOverrideSettings (riêng ảnh này) — field nào override có giá
    // trị (không null) thì ƯU TIÊN override, còn lại lấy từ tầng chung.
    // KHÔNG có field LoRA/model ở đây (lý do đã chốt: không bật/tắt LoRA
    // per-ảnh được) — model chỉ đổi được gián tiếp qua characterOverride.
    private data class Effective(
        val prompt: String, val negativePrompt: String, val poseTemplate: String, val poseAngle: String,
        val width: Int, val height: Int, val steps: Int, val cfgScale: Float, val seed: Long, val characterName: String?
    )

    // Chèn trigger word Textual Inversion của các nhân vật KHÔNG được chọn
    // neo chính (eff.characterName) vào đầu prompt — cho họ 1 lớp nhất quán
    // yếu hơn thay vì hoàn toàn không có gì. An toàn khi gọi dù panel chỉ có
    // 1 nhân vật hoặc không ai có TI (trả về prompt gốc, không đổi).
    private fun injectEmbeddingTriggers(
        prompt: String, panel: Panel, allChars: List<Character>, primaryCharacterName: String?
    ): String {
        val triggers = panel.scene.characters
            .filter { it != primaryCharacterName }
            .mapNotNull { name -> allChars.find { c -> c.name == name }?.embeddingTrigger }
            .distinct()
        return if (triggers.isEmpty()) prompt else triggers.joinToString(", ") + ", " + prompt
    }

    // Ultrafix — Hires-fix kiểu Ultimate SD Upscale (mục 16/20
    // TECHNICAL_STATUS.md): vẽ lại NHẸ toàn ảnh SAU khi ESRGAN đã phóng to,
    // ở đúng "thông số vàng" denoise 0.35-0.45 theo khuyến nghị cộng đồng —
    // đủ để AI vẽ đè ranh giới nhòe/dính thành nét sắc, không đổi bố cục/tư
    // thế gốc (denoise thấp = giữ nguyên phần lớn nội dung latent gốc).
    // CHƯA BUILD-TEST — bọc try/catch riêng, lỗi ở đây rơi về ảnh ESRGAN
    // thuần (không có gì tệ hơn trước khi có Ultrafix).
    private suspend fun tryUltrafixRedraw(
        upscaledPath: String, panel: Panel, settings: GenerationSettings, outDir: File
    ): String {
        return try {
            val bitmap = BitmapFactory.decodeFile(upscaledPath) ?: return upscaledPath
            val w = bitmap.width; val h = bitmap.height
            bitmap.recycle()
            log("  → Ultrafix: vẽ lại bề mặt ${w}x${h} (denoise ${settings.ultrafixDenoiseStrength})...")
            imagePipeline.img2imgFix(
                panelIndex = panel.index, prompt = panel.prompt, negativePrompt = panel.negativePrompt,
                stylePrompt = settings.imageStyle.stylePrompt, inputPath = upscaledPath, maskPath = null,
                denoiseStrength = settings.ultrafixDenoiseStrength, width = w, height = h,
                steps = 20, cfgScale = 7f, seed = panel.index.toLong() + 2000L,
                ultrafix = true, ultrafixTile = 512, outDir = outDir
            ) { _, _ -> }
        } catch (ex: Exception) {
            log("  ⚠ Ultrafix lỗi (${ex.message}) — giữ ảnh ESRGAN thuần")
            upscaledPath
        }
    }

    // Auto-fix mặt/tay (mục 16/17 TECHNICAL_STATUS.md, ADetailer-style).
    // CHƯA BUILD-TEST — bọc try/catch RIÊNG, lỗi ở đây tuyệt đối không được
    // làm hỏng panel: fallback về ảnh gốc nếu có bất kỳ vấn đề gì (thiếu
    // model MediaPipe trong assets, lỗi decode, lỗi sdImg2Img...).
    private suspend fun tryAutoFixFacesHands(
        rawPath: String, width: Int, height: Int, prompt: String, negativePrompt: String,
        stylePrompt: String, seed: Long, denoiseStrength: Float, panelIndex: Int, outDir: File
    ): String {
        if (!faceHandDetector.isReady()) {
            log("  ⚠ Auto-fix mặt/tay: thiếu model MediaPipe trong assets (blaze_face_short_range.tflite / hand_landmarker.task) — bỏ qua")
            return rawPath
        }
        return try {
            val bitmap = BitmapFactory.decodeFile(rawPath) ?: return rawPath
            val regions = faceHandDetector.detectRegions(bitmap)
            if (regions.isEmpty()) { bitmap.recycle(); return rawPath }

            val maskFile = File(outDir, "panel_%03d_mask.png".format(panelIndex))
            buildMaskFile(regions, bitmap.width, bitmap.height, maskFile)
            bitmap.recycle()

            log("  → Auto-fix: phát hiện ${regions.size} vùng mặt/tay, đang vẽ lại...")
            imagePipeline.img2imgFix(
                panelIndex = panelIndex, prompt = prompt, negativePrompt = negativePrompt,
                stylePrompt = stylePrompt, inputPath = rawPath, maskPath = maskFile.absolutePath,
                denoiseStrength = denoiseStrength, width = width, height = height,
                steps = 20, cfgScale = 7f, seed = seed, ultrafix = false, ultrafixTile = 512,
                outDir = outDir
            ) { _, _ -> }
        } catch (ex: Exception) {
            log("  ⚠ Auto-fix mặt/tay lỗi (${ex.message}) — giữ ảnh gốc")
            rawPath
        }
    }

    // Canvas đen trắng đơn giản — vùng cần vẽ lại = trắng, giữ nguyên = đen.
    // Rect thẳng góc (chưa feather mềm biên) — đơn giản, ít rủi ro hơn để
    // build-test lần đầu; feather biên là cải tiến chất lượng để sau.
    private fun buildMaskFile(regions: List<android.graphics.Rect>, w: Int, h: Int, outFile: File) {
        val maskBitmap = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = Canvas(maskBitmap)
        canvas.drawColor(Color.BLACK)
        val paint = Paint().apply { color = Color.WHITE; isAntiAlias = true }
        regions.forEach { r -> canvas.drawRect(r.left.toFloat(), r.top.toFloat(), r.right.toFloat(), r.bottom.toFloat(), paint) }
        FileOutputStream(outFile).use { out -> maskBitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out) }
        maskBitmap.recycle()
    }

    // Tính toạ độ khung xương ĐÃ RETARGET cho 1 panel (mục 32/33
    // TECHNICAL_STATUS.md) — thay thế hoàn toàn việc gửi tên template cho
    // native tự đọc/chọn. Đọc thư viện, chọn variant khớp góc mong muốn,
    // gán TƯỜNG MINH scene.characters[i] <-> variant.people[i] (giải quyết
    // luôn lỗ hổng "skeleton không biết ai là ai" — mục 12), retarget theo
    // BoneProportions riêng từng nhân vật, cuối cùng flatten thành FloatArray
    // đúng contract native mong đợi (mỗi người 18*4 float: x,y,z,visible).
    private fun resolveSkeletonData(poseTemplate: String, poseAngle: String, scene: Scene, story: Story): FloatArray {
        if (poseTemplate.isBlank()) return FloatArray(0)
        val library = storyManager.loadPoseLibrary()
        val variants = library[poseTemplate] ?: return FloatArray(0)
        if (variants.isEmpty()) return FloatArray(0)
        val chosen = variants.find { it.angle == poseAngle } ?: variants.first()

        val allChars = storyManager.loadStory(story.id)?.characters ?: story.characters
        val characterProportions = scene.characters.map { name ->
            allChars.find { it.name == name }?.boneProportions ?: BoneProportions()
        }
        val retargeted = PoseRetargeter.retargetVariant(chosen, characterProportions)

        val flat = FloatArray(retargeted.size * 18 * 4)
        var idx = 0
        retargeted.forEach { person ->
            person.forEach { kp ->
                flat[idx++] = kp.x; flat[idx++] = kp.y; flat[idx++] = kp.z; flat[idx++] = if (kp.visible) 1f else 0f
            }
        }
        return flat
    }

    private fun resolveEffective(panel: Panel, settings: GenerationSettings): Effective {
        val ov = panel.overrideSettings
        val autoChar = panel.scene.characters.firstOrNull()
        return Effective(
            prompt = ov?.promptOverride ?: panel.prompt,
            negativePrompt = ov?.negativePrompt ?: (panel.negativePrompt + ", " + settings.imageStyle.negPrompt),
            // Thứ tự ưu tiên: override tay > gợi ý LLM (đã validate khớp tên
            // thật trong pose_library.json, xem LLMParser.extractPrompts) >
            // heuristic dò tên theo substring trong CHÍNH thư viện thật của
            // user (KHÔNG còn đoán mù "two_hugging"/"single_standing" như
            // trước — 2 tên đó có thể không hề tồn tại nếu user tự trích
            // pose bằng ảnh/video riêng, template.
            poseTemplate = ov?.poseTemplate ?: panel.suggestedPoseTemplate ?: guessPoseTemplate(panel),
            poseAngle = ov?.poseAngle ?: panel.suggestedPoseAngle,
            width = ov?.width ?: settings.width,
            height = ov?.height ?: settings.height,
            steps = ov?.steps ?: settings.steps,
            cfgScale = ov?.cfgScale ?: settings.cfgScale,
            seed = ov?.seed ?: (autoChar?.hashCode()?.toLong()?.let { if (it < 0) it + Long.MAX_VALUE else it } ?: 42L),
            characterName = ov?.characterOverride ?: autoChar
        )
    }

    // Fallback cuối cùng khi LLM không gợi ý được gì (thư viện rỗng hoặc LLM
    // trả "none") — dò theo substring trong tên THẬT có trong thư viện, thay
    // vì hardcode 1 tên có thể không tồn tại. Rỗng -> "" ; đã xác nhận trong
    // ip_adapter.cpp (pose_templates::pickVariant + templates.find) rằng tên
    // không khớp/rỗng KHÔNG bị bỏ qua — nó rơi vào pose_templates::fallbackStanding()
    // cứng (đứng thẳng 1 người). Nghĩa là kể cả không đoán được gì, ảnh vẫn có
    // ControlNet-Pose tác động (dáng đứng mặc định), không phải "tắt hẳn".
    // Tự động chọn tư thế khớp mô tả kịch bản (mục 6.4/34 TECHNICAL_STATUS.md)
    // — ƯU TIÊN so khớp actionTags (user tự gắn nhãn lúc lưu vào thư viện,
    // vd "hug"/"fight_lock") với từ khoá trong action/description của scene.
    // Đây là fallback CUỐI CÙNG (sau gợi ý LLM đã validate ở buildPrompt())
    // — chỉ chạy khi LLM không gợi ý được gì. KHÔNG tự suy ra tag từ toạ độ
    // khớp (không đáng tin) — tag phải do user gắn tay, đây chỉ so khớp
    // CHUỖI, không phải AI hiểu nghĩa.
    private fun guessPoseTemplate(panel: Panel): String {
        val names = storyManager.listPoseTemplateNames()
        if (names.isEmpty()) return ""
        val wantMulti = panel.scene.characters.size >= 2
        val sceneText = "${panel.scene.action} ${panel.scene.description}".lowercase()

        // Bước 1: so khớp actionTags thật (đáng tin hơn hẳn match tên template)
        val tagsByTemplate = storyManager.listPoseTemplateTags()
        val tagMatch = names
            .mapNotNull { name -> tagsByTemplate[name]?.let { tags -> name to tags.count { tag -> sceneText.contains(tag.lowercase()) } } }
            .filter { it.second > 0 }
            .maxByOrNull { it.second }
        if (tagMatch != null) return tagMatch.first

        // Bước 2: fallback CŨ — so khớp thô trên TÊN template (chỉ hoạt động
        // nếu user đặt tên template có nghĩa, vd "two_hugging") — giữ lại
        // cho thư viện CHƯA gắn tag nào (tương thích ngược).
        val keywords = if (wantMulti) listOf("hug", "together", "two", "group", "multi")
                       else listOf("single", "solo", "alone", "one")
        return names.firstOrNull { name -> keywords.any { name.contains(it, ignoreCase = true) } }
            ?: names.first()
    }

    // Model đã convert riêng cho nhân vật (nếu có) có id = characterId
    // (xem StoryManager.registerConvertedModel — id truyền vào lúc convert
    // chính là characterId). Không có bản convert riêng -> dùng model gốc
    // (settings.sdModelId) — mọi nhân vật CHƯA convert riêng dùng chung 1
    // model, đúng giới hạn đã ghi trong TECHNICAL_STATUS.md.
    private fun resolveModelIdForCharacter(story: Story, characterName: String?, defaultModelId: String): String {
        if (characterName == null) return defaultModelId
        val char = storyManager.loadStory(story.id)?.characters?.find { it.name == characterName } ?: return defaultModelId
        return if (storyManager.hasConvertedModel(char.id)) char.id else defaultModelId
    }

    // ── Mở rộng cho scene nhiều nhân vật (xem TECHNICAL_STATUS.md mục 12) ──
    // Nếu TẤT CẢ nhân vật trong scene đều đã có LoRA riêng (Character.loraPath
    // != null) VÀ đã convert model ghép cho đúng nhóm này -> dùng model ghép
    // (neo được ngoại hình cho CẢ nhóm, không chỉ 1 người). Ngược lại rơi về
    // logic cũ (chỉ neo 1 người qua resolveModelIdForCharacter/IP-Adapter).
    // KHÔNG tự động convert ở đây — convert cần chạy trước (tốn thời gian
    // thật), việc sinh ảnh chỉ nên DÙNG model đã có sẵn, không đứng chờ.
    private fun resolveModelIdForScene(story: Story, characterNames: List<String>, defaultModelId: String): String {
        if (characterNames.size < 2) {
            return resolveModelIdForCharacter(story, characterNames.firstOrNull(), defaultModelId)
        }
        val allChars = storyManager.loadStory(story.id)?.characters ?: story.characters
        val chars = characterNames.mapNotNull { name -> allChars.find { it.name == name } }
        val allHaveLora = chars.size == characterNames.size && chars.all { it.loraPath != null }
        if (allHaveLora && storyManager.hasConvertedPairModel(chars.map { it.id })) {
            return storyManager.pairModelId(chars.map { it.id })
        }
        // Không có model ghép sẵn -> fallback cũ, chỉ neo 1 người (người đầu
        // danh sách, hoặc người user chọn qua characterOverride ở resolveEffective).
        return resolveModelIdForCharacter(story, characterNames.firstOrNull(), defaultModelId)
    }

    // ── Giai đoạn 1: Sinh panel (dừng lại ở REVIEW) ───────────────────────
    suspend fun generatePanels(
        story: Story,
        storyText: String,
        settings: GenerationSettings,
        chapterId: String,
        chapterNumber: Int
    ): Chapter = coroutineScope {
        val outDir = storyManager.outputDir(story.id, chapterId)
        val startMs = System.currentTimeMillis()
        _state.update { PipelineState(startTimeMs = startMs) }
        thermalMonitor.start(settings.thermalThreshold)

        try {
            // LLM parse — dùng config tự động tối ưu theo phần cứng thực tế,
            // không hardcode. Nếu người dùng đổi máy, config này tự thay đổi
            // theo vì hwProfile detect lại chipset/GPU/RAM mỗi lần cài app mới.
            emit(PipelineStage.LLM_PARSING, "Khởi động LLM...")
            log("⚙️ Phần cứng: ${hwProfile.chipset} · Adreno~${hwProfile.adrenoGen} · ${hwProfile.bigCores} big core")
            log("⚙️ LLM dùng ${optimalConfig.nThreads} thread" +
                if (optimalConfig.useGpuForLlm) " + GPU offload (${optimalConfig.nGpuLayers} layer, ${optimalConfig.gpuBackend.name})"
                else " (CPU-only, không có GPU backend khả dụng)")
            val parser = LLMParser(settings.llmModelPath, optimalConfig.nThreads, optimalConfig.nGpuLayers, settings.externalLlm)
            llmParser = parser
            parser.init()
            log("✓ LLM sẵn sàng")
            log("Đang phân tích truyện, chia ${settings.panelCount} scene...")
            // Nhân vật user ĐÃ tự thêm từ trước (qua CharactersScreen) và đã
            // gán anchorImagePath -> cho LLM biết trước để né ghép cặp khi
            // viết kịch bản (soft hint, xem scenePrompt()). Lần đầu sinh
            // truyện (chưa ai được thêm) thì list này rỗng, không có gì để
            // né - đây là giới hạn thật, không giả vờ né được cái chưa biết.
            val knownIpaNames = story.characters.filter { it.anchorImagePath != null }.map { it.name }
            val scenes = parser.parseStory(storyText, settings.panelCount, knownIpaNames, settings.llmStoryGuidance)
            log("✓ Chia được ${scenes.size} scene")

            // Auto character detection
            val freq = parser.extractCharacterFrequency(scenes)
            val newChars = freq.keys.filter { name ->
                story.characters.none { it.name.equals(name, ignoreCase = true) }
            }
            if (newChars.isNotEmpty()) {
                log("✓ Phát hiện ${newChars.size} nhân vật mới: ${newChars.joinToString(", ")}")
                newChars.forEach { name ->
                    val role = storyManager.autoClassifyCharacter(name, freq[name] ?: 0, scenes.size)
                    val char = Character(
                        id = UUID.randomUUID().toString(), name = name,
                        anchorPrompt = "$name character",
                        seed = (10000L..99999L).random(), role = role
                    )
                    storyManager.saveCharacter(story.id, char)
                    log("  → $name: ${role.name.lowercase()}")
                }
            }

            // Build prompts
            emit(PipelineStage.PROMPT_BUILDING, "Sinh prompt từng panel...")
            val allChars = storyManager.loadStory(story.id)?.characters ?: story.characters
            val charMap = allChars.associate { it.name to it.anchorPrompt }
            val poseTemplates = storyManager.listPoseTemplateNames()

            // Xung đột IP-Adapter THẬT (đếm bằng Kotlin, không dựa vào LLM
            // có nghe lời né hay không — xem StoryManager.detectIpAdapterConflicts).
            val storyForConflictCheck = story.copy(characters = allChars)
            val conflicts = storyManager.detectIpAdapterConflicts(storyForConflictCheck, scenes.map { it.characters })
            if (conflicts.isNotEmpty()) {
                log("⚠ ${conflicts.size} panel có ≥2 nhân vật IP-Adapter cùng khung — chỉ 1 người/panel được neo ảnh thật:")
                conflicts.forEach { (idx, names) -> log("  → panel ${idx + 1}: ${names.joinToString(", ")}") }
            }

            val panels = scenes.mapIndexed { i, scene ->
                log("  Prompt panel ${i+1}: ${scene.description.take(45)}...")
                val result = parser.buildPrompt(scene, charMap, settings.imageStyle.stylePrompt, poseTemplates, story.worldRules, storyManager.listPoseTemplateTags())
                Panel(
                    index = i, scene = scene, prompt = result.positive, negativePrompt = result.negative,
                    suggestedPoseTemplate = result.poseTemplate, suggestedPoseAngle = result.poseAngle,
                    ipAdapterConflictNames = conflicts[i] ?: emptyList()
                )
            }
            parser.free(); llmParser = null
            log("✓ ${panels.size} prompt sẵn sàng")

            // Local/Remote routing (xem BackendRouter.kt) — tạo 1 lần, sống
            // xuyên suốt vòng lặp bên dưới (AutoBackendRouter tự init LLM
            // riêng, tách khỏi `parser` ở trên đã free()).
            val router = BackendRouterFactory.create(settings)
            backendRouter = router
            if (settings.routingMode == RoutingMode.AUTO)
                log("🔀 Routing tự động: LLM sẽ quyết định local/remote từng panel theo chính sách đã cấu hình")
            else if (settings.remoteEndpoint.enabled)
                log("🔀 Routing thủ công: mặc định ${settings.defaultBackend.name}, panel nào override tay dùng theo override")

            // Load SD model
            emit(PipelineStage.SD_GENERATING, totalPanels = panels.size)
            log("Chuẩn bị sinh ảnh (${optimalConfig.sdNThreads} thread" +
                if (settings.useOpenCL) " + OpenCL)" else ", CPU-only)")

            // Generate panels với thermal check
            val completedPanels = mutableListOf<Panel>()

            panels.forEach { panel ->
                // Thermal gate
                waitForThermalSafe(settings)

                _state.update { it.copy(currentPanel = panel.index + 1) }

                val eff = resolveEffective(panel, settings)

                // ── Local/Remote routing ────────────────────────────────
                // Override tay LUÔN thắng tuyệt đối (kể cả đang ở AUTO) —
                // logic "ai thắng" chỉ nằm ở ĐÚNG 1 chỗ này, không lặp lại
                // trong từng router (xem hasManualBackendOverride()).
                var routing = if (panel.hasManualBackendOverride())
                    RoutingDecision(panel.overrideSettings!!.backendOverride!!, "Người dùng chọn tay cho panel này")
                else
                    router.decide(panel, story, settings)

                val wantsAugmented = settings.useStoryDiffusion &&
                    eff.characterName?.let { storyManager.getCharacterAnchor(story.id, it) } != null
                if (routing.backend == GenerationBackend.REMOTE && wantsAugmented) {
                    // remote_server/app.py hiện CHƯA hỗ trợ IP-Adapter+ControlNet-
                    // Pose (chỉ txt2img cơ bản, xem tools/remote_server/app.py) —
                    // đây là giới hạn TÍNH NĂNG (server chưa viết phần đó), không
                    // phải fallback bảo mật, nên tự chuyển về local kèm log rõ lý
                    // do, KHÔNG coi là "âm thầm" vì user thấy ngay trong log panel.
                    routing = RoutingDecision(GenerationBackend.LOCAL,
                        "Remote chưa hỗ trợ giữ nhất quán nhân vật (IP-Adapter/ControlNet-Pose) — tự chuyển local cho panel này")
                }
                log("  → Backend panel ${panel.index + 1}: ${routing.backend.name} (${routing.reason})")

                var rawPath: String
                if (routing.backend == GenerationBackend.REMOTE) {
                    val outFile = File(outDir, "panel_%03d_raw.png".format(panel.index))
                    val effPromptRemote = injectEmbeddingTriggers(eff.prompt, panel, allChars, eff.characterName)
                    try {
                        RemoteGenerationClient(settings.remoteEndpoint).generatePanel(
                            prompt = effPromptRemote + ", " + settings.imageStyle.stylePrompt,
                            negativePrompt = eff.negativePrompt,
                            width = eff.width, height = eff.height, steps = eff.steps,
                            cfgScale = eff.cfgScale, seed = eff.seed, outFile = outFile
                        )
                    } catch (ex: Exception) {
                        // KHÔNG tự fallback local ở đây — user đã chọn remote (tay
                        // hoặc qua policy AUTO), im lặng đổi sang local sẽ khiến họ
                        // tưởng dữ liệu không rời máy trong khi trước đó panel khác
                        // đã gửi đi rồi. Báo lỗi rõ, dừng lại để user tự quyết định
                        // (bấm regenerate panel này với backend khác nếu muốn).
                        throw RuntimeException("Remote generate thất bại tại panel ${panel.index + 1}: ${ex.message}\n" +
                            "Kiểm tra remote endpoint còn chạy không (Cài đặt > Remote GPU > Kiểm tra kết nối), " +
                            "hoặc đổi backend panel này về Local rồi generate lại.", ex)
                    }
                    rawPath = outFile.absolutePath
                } else {
                // ĐÃ NỐI: model giờ chọn theo nhân vật NẾU đã convert riêng
                // (xem StoryManager.registerConvertedModel) — không còn
                // "tạm dùng chung 1 model cho mọi nhân vật" như trước.
                // loadSD() tự bỏ qua nếu model đang load đúng rồi (rẻ khi
                // các panel liên tiếp cùng nhân vật).
                val modelId = if (panel.overrideSettings?.characterOverride != null)
                    resolveModelIdForCharacter(story, eff.characterName, settings.sdModelId)
                else
                    resolveModelIdForScene(story, panel.scene.characters, settings.sdModelId)
                val embeddingsDir = storyManager.embeddingsDir(story.id).absolutePath
                imagePipeline.loadSD(storyManager.modelsDir.absolutePath, modelId, settings.useOpenCL, embeddingsDir)

                // Lấy ẢNH anchor thật của nhân vật (không còn "embedding
                // giả" — IP-Adapter tự encode lại từ ảnh mỗi lần dùng).
                val referenceImage = eff.characterName?.let { storyManager.getCharacterAnchor(story.id, it) }

                // Textual Inversion cho nhân vật PHỤ trong panel (mục 12
                // TECHNICAL_STATUS.md) — người không được chọn làm
                // eff.characterName (chỉ 1 người/panel được neo LoRA/IP-
                // Adapter) vẫn có thể được neo Ở MỨC YẾU HƠN qua trigger
                // word TI, nếu họ có embeddingTrigger. Không thay thế được
                // IP-Adapter/LoRA, chỉ là lớp phòng hộ thêm — vẫn tốt hơn
                // hoàn toàn không có gì.
                val effPrompt = injectEmbeddingTriggers(eff.prompt, panel, allChars, eff.characterName)

                log("SD panel ${panel.index + 1}/${panels.size}" +
                    (if (referenceImage != null) " [anchor ✓]" else "") +
                    (if (modelId != settings.sdModelId) " [model riêng: $modelId]" else ""))

                if (settings.useStoryDiffusion && referenceImage != null) {
                    imagePipeline.loadSDAugmented(storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir)
                }

                var rawPath2 = imagePipeline.generatePanel(
                    panelIndex = panel.index,
                    prompt = effPrompt, negativePrompt = eff.negativePrompt,
                    stylePrompt = settings.imageStyle.stylePrompt,
                    width = eff.width, height = eff.height,
                    steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                    referenceImagePath = referenceImage,
                    skeletonData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story),
                    useStoryDiffusion = settings.useStoryDiffusion, outDir = outDir
                ) { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } }
                rawPath = rawPath2
                } // end local-generation branch

                // Auto-fix mặt/tay ĐÃ CHUYỂN sang upscaleApprovedPanels()
                // (mục 20 TECHNICAL_STATUS.md — chạy SAU upscale, ở độ phân
                // giải cuối, đúng thứ tự Hires-fix trước/ADetailer sau theo
                // chuẩn cộng đồng). KHÔNG còn chạy ở đây (512px, trước upscale).

                // Lưu ảnh gốc làm anchor nếu là lần đầu nhân vật MAIN/SUPPORTING xuất hiện
                eff.characterName?.let { name ->
                    val char = storyManager.loadStory(story.id)?.characters?.find { it.name == name }
                    if (char != null && char.role != CharacterRole.ONETIME && char.anchorImagePath == null) {
                        storyManager.saveCharacterAnchor(story.id, char.id, rawPath)
                        log("  → Lưu anchor cho $name")
                    }
                }

                val elapsed = (System.currentTimeMillis() - startMs) / 1000
                log("✓ Panel ${panel.index + 1} xong (${elapsed}s tổng)")

                completedPanels.add(panel.copy(
                    imagePath = rawPath, status = PanelStatus.DONE,
                    generationTimeMs = System.currentTimeMillis() - startMs,
                    resolvedBackend = routing.backend, routingReason = routing.reason
                ))
                emit(PipelineStage.SD_GENERATING)
            }

            imagePipeline.freeAll()
            backendRouter?.free(); backendRouter = null
            thermalMonitor.stop()

            // Dừng ở REVIEW - người dùng duyệt panel trước khi upscale
            emit(PipelineStage.REVIEW, "✓ Sinh xong! Hãy duyệt từng panel trước khi upscale")
            _state.update { it.copy(stage = PipelineStage.REVIEW) }

            Chapter(
                id = chapterId, storyId = story.id, title = "Chương $chapterNumber",
                chapterNumber = chapterNumber, storyText = storyText, style = settings.imageStyle,
                panels = completedPanels, status = ChapterStatus.REVIEW
            )
        } catch (e: Exception) {
            _state.update { it.copy(stage = PipelineStage.ERROR, error = e.message) }
            llmParser?.free(); backendRouter?.free(); backendRouter = null; imagePipeline.freeAll(); thermalMonitor.stop()
            throw e
        }
    }

    // ── Regenerate 1 panel (từ Gallery Review) ─────────────────────────────
    // ĐÃ NỐI: panel.overrideSettings (setting riêng ảnh này, đặt từ
    // GalleryReviewScreen) giờ được áp dụng qua resolveEffective() — trước
    // đây hàm này bỏ qua hoàn toàn override, luôn dùng tầng chung.
    suspend fun regeneratePanel(
        panel: Panel,
        story: Story,
        settings: GenerationSettings,
        outDir: File
    ): Panel = withContext(Dispatchers.IO) {
        val eff = resolveEffective(panel, settings)
        val modelId = if (panel.overrideSettings?.characterOverride != null)
            resolveModelIdForCharacter(story, eff.characterName, settings.sdModelId)
        else
            resolveModelIdForScene(story, panel.scene.characters, settings.sdModelId)
        val embeddingsDir = storyManager.embeddingsDir(story.id).absolutePath
        imagePipeline.loadSD(storyManager.modelsDir.absolutePath, modelId, settings.useOpenCL, embeddingsDir)

        val referenceImage = eff.characterName?.let { storyManager.getCharacterAnchor(story.id, it) }
        val allChars = storyManager.loadStory(story.id)?.characters ?: story.characters
        val effPrompt = injectEmbeddingTriggers(eff.prompt, panel, allChars, eff.characterName)

        if (settings.useStoryDiffusion && referenceImage != null) {
            imagePipeline.loadSDAugmented(storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir)
        }

        val rawPath = imagePipeline.generatePanel(
            panelIndex = panel.index,
            prompt = effPrompt, negativePrompt = eff.negativePrompt,
            stylePrompt = settings.imageStyle.stylePrompt,
            width = eff.width, height = eff.height,
            steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
            referenceImagePath = referenceImage,
            skeletonData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story),
            useStoryDiffusion = settings.useStoryDiffusion, outDir = outDir
        ) { _, _ -> }
        panel.copy(imagePath = rawPath, status = PanelStatus.DONE, upscaledPath = null)
    }

    // ── Giai đoạn 2: Upscale (sau khi user đã duyệt hết panel) ─────────────
    suspend fun upscaleApprovedPanels(
        chapter: Chapter,
        settings: GenerationSettings,
        outDir: File
    ): Chapter = coroutineScope {
        emit(PipelineStage.UPSCALING, "Upscale ${chapter.panels.size} panel đã duyệt...")
        thermalMonitor.start(settings.thermalThreshold)

        if (settings.upscaleOption != UpscaleOption.NONE) {
            imagePipeline.loadEsrgan(settings.upscaleOption.factor)
        }

        // LLM dịch prompt riêng theo giai đoạn (mục 24 TECHNICAL_STATUS.md)
        // — CHỈ init nếu thật sự cần (1 trong 2 tính năng dùng img2img đang
        // bật), tránh tốn thời gian/RAM tải LLM khi không cần. Instance
        // RIÊNG cho hàm này (không dùng chung `llmParser` ở generatePanels()
        // — cái đó đã free() xong trước khi tới bước này).
        val needsStageLLM = settings.useUltrafixRedraw || settings.autoFixFacesHands
        var stageParser: LLMParser? = null
        val worldRules = storyManager.loadStory(chapter.storyId)?.worldRules ?: ""
        if (needsStageLLM && settings.llmModelPath.isNotBlank()) {
            try {
                stageParser = LLMParser(settings.llmModelPath, 4, 0, settings.externalLlm)
                stageParser.init()
            } catch (ex: Exception) {
                log("⚠ Không khởi động được LLM dịch prompt theo giai đoạn (${ex.message}) — dùng lại prompt gốc")
                stageParser = null
            }
        }

        // Thứ tự ĐÃ ĐẢO theo đúng chuẩn cộng đồng (mục 20 TECHNICAL_STATUS.md
        // — "Hires Fix trước, ADetailer sau, ở độ phân giải CUỐI"), KHÁC bản
        // trước (auto-fix chạy lúc ảnh còn 512px, TRƯỚC upscale — sai thứ tự):
        //   1. ESRGAN upscale (phóng to, đã có từ trước)
        //   2. Ultrafix — vẽ lại NHẸ toàn ảnh ở độ phân giải MỚI (mục 16,
        //      denoise 0.35-0.45 theo đúng "thông số vàng" đã thống nhất) —
        //      biến ranh giới nhòe/dính do phóng to thành nét sắc hơn, KHÔNG
        //      đổi tư thế gốc (denoise thấp = giữ bố cục, chỉ vẽ lại chi tiết bề mặt).
        //   3. Auto-fix mặt/tay (mục 17) — chạy SAU CÙNG, ở độ phân giải cao
        //      nhất, cho mask chính xác hơn hẳn so với làm lúc ảnh còn nhỏ.
        val updated = chapter.panels.map { panel ->
            waitForThermalSafe(settings)
            val path = panel.imagePath ?: return@map panel
            var hd = imagePipeline.upscale(path, panel.index, outDir, settings.upscaleOption)
            var fixApplied = false

            // Mô tả tự nhiên nguồn cho dịch — ưu tiên override riêng panel
            // (PanelOverrideSettings.naturalDescriptionOverride), fallback về
            // mô tả scene tự động (Scene.description đã có từ parseStory()).
            val naturalDesc = panel.overrideSettings?.naturalDescriptionOverride ?: panel.scene.description

            if (settings.upscaleOption != UpscaleOption.NONE && settings.useUltrafixRedraw) {
                val beforeUltrafix = hd
                val (ufPrompt, ufNeg) = stageParser?.let {
                    try {
                        val r = it.translateStagePrompt(naturalDesc, PromptStage.UPSCALE_REDRAW, worldRules, settings.imageStyle.stylePrompt)
                        r.positive to r.negative
                    } catch (ex: Exception) { panel.prompt to panel.negativePrompt }
                } ?: (panel.prompt to panel.negativePrompt)
                hd = tryUltrafixRedraw(hd, panel.copy(prompt = ufPrompt, negativePrompt = ufNeg), settings, outDir)
                if (hd != beforeUltrafix) fixApplied = true
            }

            if (settings.autoFixFacesHands) {
                val fixedWidth = settings.width * settings.upscaleOption.factor
                val fixedHeight = settings.height * settings.upscaleOption.factor
                val beforeAutoFix = hd
                val (afPrompt, afNeg) = stageParser?.let {
                    try {
                        val r = it.translateStagePrompt(naturalDesc, PromptStage.INPAINT, worldRules, settings.imageStyle.stylePrompt)
                        r.positive to r.negative
                    } catch (ex: Exception) { panel.prompt to panel.negativePrompt }
                } ?: (panel.prompt to panel.negativePrompt)
                hd = tryAutoFixFacesHands(
                    hd, fixedWidth, fixedHeight, afPrompt, afNeg,
                    settings.imageStyle.stylePrompt, panel.index.toLong() + 1000L,
                    settings.autoFixDenoiseStrength, panel.index, outDir
                )
                if (hd != beforeAutoFix) fixApplied = true
            }

            log("✓ Panel ${panel.index + 1} upscale xong" + (if (fixApplied) " [đã auto-fix — nên kiểm tra kỹ ở Gallery cuối]" else ""))
            panel.copy(upscaledPath = hd, autoFixApplied = fixApplied)
        }
        stageParser?.free()
        imagePipeline.freeEsrganOnly()
        thermalMonitor.stop()
        chapter.copy(panels = updated, status = ChapterStatus.DONE)
    }

    // ── Giai đoạn 3 (tùy chọn): Auto bubble bằng YOLOv8 ────────────────────
    suspend fun autoPlaceBubbles(chapter: Chapter): Chapter = withContext(Dispatchers.IO) {
        emit(PipelineStage.BUBBLE_AUTO, "Tải YOLOv8n để detect vị trí nhân vật...")
        val loaded = bubbleEngine.loadYolo()
        if (!loaded) {
            log("⚠ Không có YOLOv8n, dùng vị trí mặc định")
        }

        val updated = chapter.panels.map { panel ->
            val imgPath = panel.upscaledPath ?: panel.imagePath ?: return@map panel
            val bubbles = if (loaded) {
                bubbleEngine.autoPplaceBubbles(imgPath, panel.scene.dialogue)
            } else {
                bubbleEngine.defaultBubbles(panel.scene.dialogue)
            }
            log("✓ Panel ${panel.index + 1}: ${bubbles.size} bubble")
            panel.copy(bubbles = bubbles)
        }
        bubbleEngine.freeYolo()
        chapter.copy(panels = updated)
    }

    // ── Giai đoạn 4: Export ─────────────────────────────────────────────────
    // SỬA (yêu cầu chọn định dạng xuất): trước đây LUÔN xuất cả PDF lẫn CBZ,
    // không cho chọn. Giờ nhận thêm 2 cờ, mặc định cả 2 = true (giữ đúng
    // hành vi cũ nếu không truyền gì) — UI (PostProcessingScreen) cho user
    // tự bỏ chọn loại không cần.
    suspend fun exportChapter(
        chapter: Chapter, outDir: File, exportPdf: Boolean = true, exportCbz: Boolean = true
    ): Chapter = withContext(Dispatchers.IO) {
        emit(PipelineStage.LAYOUT_EXPORT, "Đang xuất...")
        val pdfPath = if (exportPdf) exportEngine.exportPdf(chapter.panels, outDir, chapter.title) else null
        val cbzPath = if (exportCbz) exportEngine.exportCbz(chapter.panels, outDir) else null
        log("✅ Hoàn thành!")
        _state.update { it.copy(stage = PipelineStage.DONE) }
        chapter.copy(pdfPath = pdfPath ?: chapter.pdfPath, cbzPath = cbzPath ?: chapter.cbzPath)
    }

    // ── Thermal gate ─────────────────────────────────────────────────────
    private suspend fun waitForThermalSafe(settings: GenerationSettings) {
        while (thermalMonitor.state.value.isOverheating) {
            _state.update { it.copy(
                isPaused = true, pauseReason = PauseReason.THERMAL,
                currentTempC = thermalMonitor.state.value.currentTempC
            )}
            log("🔥 Máy đang nóng ${thermalMonitor.state.value.currentTempC}°C — tạm dừng", LogLevel.WARN)
            delay(2000)
            if (!settings.autoResume) {
                // Chờ người dùng resume thủ công - check lại mỗi 2s
                continue
            }
        }
        if (_state.value.isPaused) {
            log("✓ Máy đã nguội, tiếp tục...", LogLevel.OK)
            _state.update { it.copy(isPaused = false, pauseReason = null) }
        }
    }

    fun cancel() {
        job?.cancel()
        llmParser?.free()
        imagePipeline.freeAll()
        bubbleEngine.freeYolo()
        thermalMonitor.stop()
        _state.value = PipelineState()
    }

    private fun emit(stage: PipelineStage, msg: String? = null, totalPanels: Int? = null) {
        _state.update { prev -> prev.copy(
            stage = stage, totalPanels = totalPanels ?: prev.totalPanels,
            log = if (msg != null) prev.log + LogEntry(time(), msg) else prev.log
        )}
    }

    private fun log(msg: String, level: LogLevel = LogLevel.INFO) {
        val lvl = when {
            msg.startsWith("✓") || msg.startsWith("✅") -> LogLevel.OK
            msg.startsWith("⚠") || msg.startsWith("🔥") -> LogLevel.WARN
            msg.startsWith("❌") -> LogLevel.ERROR
            else -> level
        }
        _state.update { it.copy(log = it.log + LogEntry(time(), msg, lvl)) }
    }

    private fun time() = SimpleDateFormat("mm:ss", Locale.getDefault()).format(Date())
}
