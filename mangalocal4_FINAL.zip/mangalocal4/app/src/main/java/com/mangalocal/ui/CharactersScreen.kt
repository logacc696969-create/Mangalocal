package com.mangalocal.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharactersDetailScreen(nav: NavController, vm: MainViewModel) {
    val story by vm.currentStory.collectAsState()
    val loras by vm.loras.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var editingChar by remember { mutableStateOf<Character?>(null) }

    var newName by remember { mutableStateOf("") }
    var newAnchor by remember { mutableStateOf("") }
    var newNeg by remember { mutableStateOf("") }
    var newRole by remember { mutableStateOf(CharacterRole.MAIN) }
    var newSeed by remember { mutableStateOf("") }
    var selLora by remember { mutableStateOf<String?>(null) }

    if (story == null) { Box(Modifier.fillMaxSize()) { Text("...", color = C.T3) }; return }
    val chars = story!!.characters

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Nhân vật · ${story!!.title}") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                actions = { IconButton(onClick = { showAdd = !showAdd }) {
                    Icon(if (showAdd) Icons.Default.ExpandLess else Icons.Default.Add, null, tint = C.Blue)
                }}, colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("🎯 Phân loại nhân vật", color = C.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("Chính: lưu anchor vĩnh viễn · Phụ: lưu tạm trong chương · Một lần: không lưu",
                            color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                }
            }

            // Ghép cặp LoRA cho nhóm nhân vật (mục 12/14/27 TECHNICAL_STATUS.md
            // — trước đây có API convertAndRegisterPairModel() nhưng KHÔNG có
            // UI nào gọi được, phát hiện khi rà lại toàn bộ việc tồn đọng).
            if (chars.count { it.loraPath != null } >= 2) {
                item {
                    var showPairDialog by remember { mutableStateOf(false) }
                    MlOutlineBtn("🔗 Ghép cặp LoRA cho nhóm nhân vật (nhiều người/panel)",
                        icon = Icons.Default.People, onClick = { showPairDialog = true })
                    if (showPairDialog) {
                        PairConvertDialog(chars.filter { it.loraPath != null }, vm, onDismiss = { showPairDialog = false })
                    }
                }
            }

            listOf(CharacterRole.MAIN to "Nhân vật chính", CharacterRole.SUPPORTING to "Nhân vật phụ",
                CharacterRole.ONETIME to "Xuất hiện một lần").forEach { (role, label) ->
                val list = chars.filter { it.role == role }
                if (list.isNotEmpty()) {
                    item { MlLabel(label + " (${list.size})") }
                    items(list) { c -> CharacterCard(c, onClick = { editingChar = c }, onDelete = { vm.deleteCharacter(c.id) }) }
                }
            }

            if (chars.isEmpty()) item {
                Box(Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                    Text("Chưa có nhân vật. LLM sẽ tự phát hiện khi sinh chương,\nhoặc bạn thêm thủ công.",
                        color = C.T3, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }

            if (showAdd) item {
                MlCard {
                    MlLabel("thêm nhân vật mới")
                    @Composable
                    fun Field(label: String, value: String, hint: String, lines: Int = 1, onChange: (String) -> Unit) {
                        Text(label, color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
                        OutlinedTextField(value = value, onValueChange = onChange,
                            modifier = Modifier.fillMaxWidth().let { if (lines > 1) it.height((lines*26+24).dp) else it },
                            placeholder = { Text(hint, color = C.T3, fontSize = 12.sp) }, singleLine = lines == 1,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                                focusedContainerColor = C.S0, unfocusedContainerColor = C.S0, focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp))
                        Spacer(Modifier.height(10.dp))
                    }
                    Field("Tên *", newName, "vd: Aria") { newName = it }
                    Field("Anchor prompt * (mô tả ngoại hình)", newAnchor,
                        "vd: young woman, long black hair, brown eyes, red jacket", lines = 3) { newAnchor = it }
                    Field("Negative prompt", newNeg, "tùy chọn") { newNeg = it }
                    Field("Seed", newSeed, "để trống = ngẫu nhiên") { newSeed = it }

                    Text("Vai trò", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                        CharacterRole.values().forEach { role ->
                            val sel = newRole == role
                            Surface(onClick = { newRole = role }, color = if (sel) C.BlueDim else C.S0,
                                shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (sel) C.Blue else C.Border)) {
                                Text(when(role) { CharacterRole.MAIN -> "Chính"; CharacterRole.SUPPORTING -> "Phụ"; CharacterRole.ONETIME -> "Một lần" },
                                    color = if (sel) C.Blue else C.T2, fontSize = 12.sp, modifier = Modifier.padding(10.dp, 7.dp))
                            }
                        }
                    }

                    if (loras.isNotEmpty()) {
                        Text("LoRA (tùy chọn)", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                            item {
                                Surface(onClick = { selLora = null }, color = if (selLora == null) C.BlueDim else C.S0,
                                    shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (selLora == null) C.Blue else C.Border)) {
                                    Text("Không", color = if (selLora == null) C.Blue else C.T2, fontSize = 12.sp, modifier = Modifier.padding(10.dp, 7.dp))
                                }
                            }
                            items(loras) { lora ->
                                Surface(onClick = { selLora = lora.path }, color = if (selLora == lora.path) C.BlueDim else C.S0,
                                    shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (selLora == lora.path) C.Blue else C.Border)) {
                                    Text(lora.name.take(18), color = if (selLora == lora.path) C.Blue else C.T2, fontSize = 12.sp, modifier = Modifier.padding(10.dp, 7.dp))
                                }
                            }
                        }
                    }

                    MlBtn("Lưu nhân vật", icon = Icons.Default.PersonAdd,
                        enabled = newName.isNotBlank() && newAnchor.isNotBlank(),
                        onClick = {
                            vm.addCharacter(newName, newAnchor, newNeg, newRole, selLora, newSeed.toLongOrNull())
                            newName = ""; newAnchor = ""; newNeg = ""; newSeed = ""; selLora = null; showAdd = false
                        })
                }
            }
        }
    }

    editingChar?.let { char ->
        EditCharacterDialog(character = char, vm = vm, onDismiss = { editingChar = null })
    }
}

@Composable
private fun PairConvertDialog(candidates: List<Character>, vm: MainViewModel, onDismiss: () -> Unit) {
    val checkpoints by vm.checkpoints.collectAsState()
    val convertBusy by vm.convertBusy.collectAsState()
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var selCheckpoint by remember { mutableStateOf<String?>(checkpoints.firstOrNull()?.path) }

    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.S1,
        title = { Text("Ghép cặp LoRA", color = C.T1) },
        text = {
            Column {
                Text("Chọn ≥2 nhân vật CÙNG xuất hiện chung 1 panel — merge LoRA của họ vào 1 checkpoint dùng " +
                    "chung, để cả nhóm được neo ngoại hình thay vì chỉ 1 người (xem mục 12 TECHNICAL_STATUS.md — " +
                    "có thể bị rò rỉ đặc điểm giữa 2 người, chưa build-test).",
                    color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                Spacer(Modifier.height(6.dp))
                Text("💡 Giảm rò rỉ đặc điểm (Identity Bleeding): chạy tools/lora_block_weight.py trên PC/Colab " +
                    "cho từng file LoRA TRƯỚC khi đặt vào MangaLocal/loras/ — giảm hệ số layer down_blocks (bố " +
                    "cục/trang phục, dễ tràn nhất), giữ nguyên up_blocks/mid_block (khuôn mặt). Xem mục 28 " +
                    "TECHNICAL_STATUS.md — tuỳ chọn, chưa kiểm chứng mức tối ưu.",
                    color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                Spacer(Modifier.height(10.dp))
                candidates.forEach { c ->
                    Row(Modifier.fillMaxWidth().clickable {
                        selected = if (c.id in selected) selected - c.id else selected + c.id
                    }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = c.id in selected, onCheckedChange = {
                            selected = if (it) selected + c.id else selected - c.id
                        }, colors = CheckboxDefaults.colors(checkedColor = C.Blue))
                        Text(c.name, color = C.T1, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (checkpoints.isEmpty()) {
                    Text("Chưa có checkpoint gốc (.safetensors) trong MangaLocal/models/", color = C.Orange, fontSize = 11.sp)
                } else {
                    Text("Checkpoint gốc:", color = C.T3, fontSize = 10.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(checkpoints) { ck ->
                            FilterChip(selected = selCheckpoint == ck.path, onClick = { selCheckpoint = ck.path },
                                label = { Text(ck.name.take(16), fontSize = 10.sp) })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selected.size >= 2 && selCheckpoint != null && convertBusy == null,
                onClick = {
                    vm.convertCharacterPair(candidates.filter { it.id in selected }, selCheckpoint!!)
                    onDismiss()
                }
            ) { Text(if (convertBusy != null) "Đang convert..." else "Ghép & Convert", color = C.Blue) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy", color = C.T3) } }
    )
}

@Composable
private fun CharacterCard(c: Character, onClick: () -> Unit, onDelete: () -> Unit) {
    MlCard(modifier = Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CharAvatar(c.name, 42.dp)
            Column(Modifier.weight(1f)) {
                Text(c.name, color = C.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("seed ${c.seed}", color = C.T3, fontSize = 11.sp)
                Text(c.anchorPrompt.take(50) + if (c.anchorPrompt.length > 50) "…" else "",
                    color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                RoleChip(c.role)
                Spacer(Modifier.height(6.dp))
                if (c.anchorImagePath != null) MlChip("anchor ✓", C.Green, C.GreenDim)
                Spacer(Modifier.height(6.dp))
                Icon(Icons.Default.Delete, null, tint = C.T3, modifier = Modifier.size(16.dp).clickable(onClick = onDelete))
            }
        }
    }
}

@Composable
private fun EditCharacterDialog(character: Character, vm: MainViewModel, onDismiss: () -> Unit) {
    var anchor by remember { mutableStateOf(character.anchorPrompt) }
    var seed by remember { mutableStateOf(character.seed.toString()) }
    val storyManager = vm.storyManager
    val checkpoints by vm.checkpoints.collectAsState()
    val embeddingSources by vm.embeddingSources.collectAsState()
    val convertBusy by vm.convertBusy.collectAsState()
    val current = storyManager.currentConsistencyMethod(character)
    val suggested = storyManager.suggestConsistencyMethod(character.role)
    var selCheckpoint by remember { mutableStateOf<String?>(checkpoints.firstOrNull()?.path) }
    var selLoraFile by remember { mutableStateOf<String?>(null) }
    var selEmbeddingSource by remember { mutableStateOf<String?>(null) }

    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.setCharacterAnchorImage(character, it) }
    }
    val pickEmbeddingLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.setCharacterEmbeddingFromUri(character, it) }
    }

    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.S1,
        title = { Text("Sửa: ${character.name}", color = C.T1) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(value = anchor, onValueChange = { anchor = it },
                    label = { Text("Anchor prompt") }, modifier = Modifier.fillMaxWidth().height(90.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = seed, onValueChange = { seed = it },
                    label = { Text("Seed") }, modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))

                Spacer(Modifier.height(16.dp))
                Divider(color = C.Border)
                Spacer(Modifier.height(10.dp))

                // Gợi ý theo vai trò (mục 13 TECHNICAL_STATUS.md) — CHỈ GỢI Ý,
                // không tự ép. Vai trò của nhân vật này đang là ${character.role}.
                Text("Phương pháp nhất quán — vai trò \"${roleLabel(character.role)}\" → gợi ý ${methodLabel(suggested)}" +
                    (if (current == suggested) " (đang dùng đúng gợi ý)" else if (current != ConsistencyMethod.NONE) " (đang dùng ${methodLabel(current)}, khác gợi ý — không sao)" else ""),
                    color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                Spacer(Modifier.height(8.dp))

                // ── LoRA ──────────────────────────────────────────────
                MethodSection(
                    title = "① LoRA (~90-100%* — cần train sẵn trên PC + convert, tốn thời gian nhất)",
                    active = current == ConsistencyMethod.LORA
                ) {
                    val loraList by vm.loras.collectAsState()
                    if (checkpoints.isEmpty()) {
                        Text("Chưa có checkpoint gốc (.safetensors) trong MangaLocal/models/", color = C.Orange, fontSize = 11.sp)
                    } else if (loraList.isEmpty()) {
                        Text("Chưa có file LoRA (.safetensors) trong MangaLocal/loras/", color = C.Orange, fontSize = 11.sp)
                    } else {
                        Text("Checkpoint gốc:", color = C.T3, fontSize = 10.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(checkpoints) { ck ->
                                FilterChip(selected = selCheckpoint == ck.path, onClick = { selCheckpoint = ck.path },
                                    label = { Text(ck.name.take(16), fontSize = 10.sp) })
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("File LoRA nhân vật:", color = C.T3, fontSize = 10.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(loraList) { lr ->
                                FilterChip(selected = selLoraFile == lr.path, onClick = { selLoraFile = lr.path },
                                    label = { Text(lr.name.take(16), fontSize = 10.sp) })
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        MlBtn(if (convertBusy == character.name) "Đang convert..." else "Convert & dùng LoRA này",
                            icon = Icons.Default.Build,
                            enabled = selCheckpoint != null && selLoraFile != null && convertBusy == null,
                            onClick = { vm.convertCharacterLora(character, selCheckpoint!!, selLoraFile!!) })
                    }
                }

                Spacer(Modifier.height(10.dp))
                // ── IP-Adapter ────────────────────────────────────────
                MethodSection(
                    title = "② IP-Adapter (~80-90%* — chỉ cần 1 ảnh, không cần train)",
                    active = current == ConsistencyMethod.IP_ADAPTER
                ) {
                    if (character.anchorImagePath != null) {
                        Text("Đã có ảnh anchor ✓ (${File(character.anchorImagePath).name})", color = C.Green, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    MlOutlineBtn(if (character.anchorImagePath != null) "Đổi ảnh khác" else "Chọn ảnh nhân vật",
                        icon = Icons.Default.Image,
                        onClick = { pickImageLauncher.launch(arrayOf("image/*")) })
                }

                Spacer(Modifier.height(10.dp))
                // ── Textual Inversion ─────────────────────────────────
                MethodSection(
                    title = "③ Textual Inversion (~40-65%* — nhẹ nhất, ghép nhiều người/panel thoải mái, KHÔNG bị giới hạn 1 người/panel như ②)",
                    active = current == ConsistencyMethod.TEXTUAL_INVERSION
                ) {
                    if (character.embeddingTrigger != null) {
                        Text("Trigger word: \"${character.embeddingTrigger}\" ✓", color = C.Green, fontSize = 11.sp)
                        Spacer(Modifier.height(4.dp))
                    }
                    if (embeddingSources.isNotEmpty()) {
                        Text("Chọn từ MangaLocal/embeddings_source/:", color = C.T3, fontSize = 10.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(embeddingSources) { es ->
                                FilterChip(selected = selEmbeddingSource == es.path, onClick = {
                                    selEmbeddingSource = es.path
                                    vm.setCharacterEmbeddingFromSource(character, es.path)
                                }, label = { Text(es.name.take(16), fontSize = 10.sp) })
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    MlOutlineBtn("Hoặc chọn file .safetensors khác", icon = Icons.Default.FileOpen,
                        onClick = { pickEmbeddingLauncher.launch(arrayOf("*/*")) })
                }

                Spacer(Modifier.height(10.dp))
                if (current != ConsistencyMethod.NONE) {
                    TextButton(onClick = { vm.clearConsistencyMethod(character) }) {
                        Text("④ Bỏ hết, chỉ dùng mô tả chữ (Không)", color = C.T3, fontSize = 12.sp)
                    }
                }

                Spacer(Modifier.height(4.dp))
                Text("* % là ước lượng CHUNG của cộng đồng SD, KHÔNG PHẢI đo trên chính app này " +
                    "— chưa build-test thật để biết số liệu chính xác.", color = C.T3, fontSize = 9.sp, lineHeight = 12.sp)

                Spacer(Modifier.height(10.dp))
                if (character.anchorImagePath != null) {
                    Text("Ảnh anchor hiện tại đã lưu", color = C.Green, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.updateCharacter(character.copy(anchorPrompt = anchor, seed = seed.toLongOrNull() ?: character.seed))
                onDismiss()
            }) { Text("Lưu", color = C.Blue) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy", color = C.T3) } }
    )
}

@Composable
private fun MethodSection(title: String, active: Boolean, content: @Composable ColumnScope.() -> Unit) {
    Surface(color = if (active) C.GreenDim else C.S0, shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (active) C.Green else C.Border)) {
        Column(Modifier.padding(10.dp)) {
            Text(title, color = if (active) C.Green else C.T2, fontSize = 11.sp, lineHeight = 14.sp,
                fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            content()
        }
    }
}

private fun roleLabel(r: CharacterRole) = when (r) {
    CharacterRole.MAIN -> "Chính (xuất hiện nhiều)"
    CharacterRole.SUPPORTING -> "Phụ (xuất hiện trung bình)"
    CharacterRole.ONETIME -> "Một lần / qua đường"
}
private fun methodLabel(m: ConsistencyMethod) = when (m) {
    ConsistencyMethod.LORA -> "① LoRA"
    ConsistencyMethod.IP_ADAPTER -> "② IP-Adapter"
    ConsistencyMethod.TEXTUAL_INVERSION -> "③ Textual Inversion"
    ConsistencyMethod.NONE -> "④ Không dùng (chỉ mô tả chữ)"
}
