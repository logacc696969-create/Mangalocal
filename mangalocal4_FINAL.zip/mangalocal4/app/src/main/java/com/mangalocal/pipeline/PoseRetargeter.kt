package com.mangalocal.pipeline

import com.mangalocal.model.BoneProportions
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * Retarget khung xương theo tỷ lệ xương RIÊNG từng nhân vật (mục 31/32
 * TECHNICAL_STATUS.md) — thay thế hoàn toàn cách "kéo giãn theo vector từ
 * gốc hông" (mục 30, đã lỗi thời — gây góc khớp phi lý đúng như user chỉ
 * ra) bằng thuật toán Forward Kinematics giữ nguyên GÓC GẬP tự nhiên của
 * khớp, chỉ đổi ĐỘ DÀI xương, lan truyền từ gốc thân (hip-center) ra tới
 * đầu chi (bàn tay/bàn chân) — đúng nguyên lý "Pose Space Deformation +
 * Root Translation" mà user cung cấp (không phải Bio-IK đầy đủ, không giải
 * constraint đa khớp — đây là bản ĐƠN GIẢN, nhẹ, dùng lượng giác phẳng
 * thuần, khả thi thật trên CPU di động).
 *
 * GIỚI HẠN THÀNH THẬT (so với Bio-IK đầy đủ đã bàn và quyết định KHÔNG làm):
 * - KHÔNG giải "điểm chạm bắt buộc" (contact point) một cách chính xác —
 *   không có metadata nào trong pose_library.json ghi rõ "tay người A phải
 *   chạm đúng gáy người B", nên bước "bù trừ xoay vai/hông để chạm đúng
 *   điểm khoá" (bước 4 tài liệu 7) CHƯA làm — cần thêm metadata điểm chạm
 *   mới làm được, để dành sau nếu build-test cho thấy cần.
 * - Vẫn CÓ áp dụng đúng phần "giữ góc gập gốc + đổi độ dài + lan truyền từ
 *   gốc" (bước 1-3 tài liệu 7) — đây là phần giá trị nhất, giải quyết đúng
 *   vấn đề "góc khớp phi lý" mà cách cũ (kéo vector thẳng) gây ra.
 * - headSizeRatio KHÔNG áp dụng được chính xác (không có điểm đỉnh đầu
 *   trong OpenPose-18, đã ghi rõ từ mục 30) — field này tồn tại trong
 *   BoneProportions cho tương lai (vd nếu đổi sang bộ khớp có landmark mặt
 *   chi tiết hơn), CHƯA dùng ở hàm retarget này.
 */
object PoseRetargeter {

    private fun dist(a: StoryManager.PoseKeypoint, b: StoryManager.PoseKeypoint) =
        sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y))

    private fun angle(from: StoryManager.PoseKeypoint, to: StoryManager.PoseKeypoint) =
        atan2(to.y - from.y, to.x - from.x)

    // Đặt lại 1 điểm "to" theo: gốc "from" + độ dài mới * hướng góc GỐC
    // (giữ nguyên góc, đổi độ dài) — đúng công thức "Angle Propagation"
    // (bước 3 tài liệu 7): toạ_độ_mới = toạ_độ_gốc(from) + chiều_dài_mới * góc_xoay_gốc.
    private fun placeAtAngleLength(
        from: StoryManager.PoseKeypoint, originalAngle: Float, newLength: Float, template: StoryManager.PoseKeypoint
    ) = template.copy(x = from.x + newLength * cos(originalAngle), y = from.y + newLength * sin(originalAngle))

    /**
     * Retarget 1 người trong khung xương (List<PoseKeypoint> OpenPose-18)
     * từ tỷ lệ nguồn (sourceProportions — tỷ lệ của người THẬT trong
     * video/ảnh gốc, mặc định 1.0 = người lớn) sang tỷ lệ đích (nhân vật cụ
     * thể đang vẽ). Nếu source==target, trả nguyên khung xương gốc (không
     * đổi gì, tránh sai số làm tròn không cần thiết).
     */
    fun retargetPerson(
        person: List<StoryManager.PoseKeypoint>, source: BoneProportions, target: BoneProportions
    ): MutableList<StoryManager.PoseKeypoint> {
        if (source == target) return person.toMutableList()
        val out = person.toMutableList()

        // Điểm gốc (root) = hip-center — giữ NGUYÊN vị trí tuyệt đối, mọi
        // xương khác lan truyền TỪ đây ra (đúng "Root Translation" tài liệu
        // 7 — không cố định vai/hông độc lập, mà lấy 1 gốc chung).
        val rHip = out.getOrNull(8); val lHip = out.getOrNull(11)
        if (rHip?.visible != true || lHip?.visible != true) return out // thiếu điểm gốc, không retarget mù
        val hipCenter = StoryManager.PoseKeypoint((rHip.x + lHip.x) / 2, (rHip.y + lHip.y) / 2, 0f, true, 1f)

        // 1. Trục thân: hip-center -> neck (giữ góc, đổi độ dài theo torsoRatio)
        val neck = out.getOrNull(1)
        var newNeck = neck
        if (neck?.visible == true) {
            val origLen = dist(hipCenter, neck)
            val origAngle = angle(hipCenter, neck)
            val newLen = origLen * (target.torsoRatio / source.torsoRatio)
            newNeck = placeAtAngleLength(hipCenter, origAngle, newLen, neck)
            out[1] = newNeck
        }

        // 2. Tay: neck -> shoulder (offset ngắn, KHÔNG coi là "xương" scale
        // riêng — giữ nguyên offset TƯƠNG ĐỐI so với neck cũ, dịch theo neck
        // mới) -> elbow (upperArmRatio) -> wrist (forearmRatio).
        fun retargetArm(shoulderIdx: Int, elbowIdx: Int, wristIdx: Int) {
            val shoulder = out.getOrNull(shoulderIdx); val elbow = out.getOrNull(elbowIdx); val wrist = out.getOrNull(wristIdx)
            if (neck == null || newNeck == null || shoulder?.visible != true) return
            // Dịch vai theo đúng offset gốc so với neck (neck đã có vị trí mới)
            val shoulderOffsetX = shoulder.x - neck.x; val shoulderOffsetY = shoulder.y - neck.y
            val newShoulder = shoulder.copy(x = newNeck.x + shoulderOffsetX, y = newNeck.y + shoulderOffsetY)
            out[shoulderIdx] = newShoulder

            if (elbow?.visible == true) {
                val origAngle = angle(shoulder, elbow)
                val newLen = dist(shoulder, elbow) * (target.upperArmRatio / source.upperArmRatio)
                val newElbow = placeAtAngleLength(newShoulder, origAngle, newLen, elbow)
                out[elbowIdx] = newElbow

                if (wrist?.visible == true) {
                    val origAngleF = angle(elbow, wrist)
                    val newLenF = dist(elbow, wrist) * (target.forearmRatio / source.forearmRatio)
                    out[wristIdx] = placeAtAngleLength(newElbow, origAngleF, newLenF, wrist)
                }
            }
        }
        retargetArm(2, 3, 4)   // vai phải - khuỷu phải - cổ tay phải
        retargetArm(5, 6, 7)   // vai trái - khuỷu trái - cổ tay trái

        // 3. Chân: hip(R/L) -> knee (upperLegRatio) -> ankle (lowerLegRatio),
        // hip giữ NGUYÊN vị trí tuyệt đối (chính là root, không lan truyền
        // qua neck) — khác tay (lan truyền qua neck), vì trục hông LÀ gốc.
        fun retargetLeg(hipIdx: Int, kneeIdx: Int, ankleIdx: Int) {
            val hip = out.getOrNull(hipIdx); val knee = out.getOrNull(kneeIdx); val ankle = out.getOrNull(ankleIdx)
            if (hip?.visible != true) return
            if (knee?.visible == true) {
                val origAngle = angle(hip, knee)
                val newLen = dist(hip, knee) * (target.upperLegRatio / source.upperLegRatio)
                val newKnee = placeAtAngleLength(hip, origAngle, newLen, knee)
                out[kneeIdx] = newKnee
                if (ankle?.visible == true) {
                    val origAngleA = angle(knee, ankle)
                    val newLenA = dist(knee, ankle) * (target.lowerLegRatio / source.lowerLegRatio)
                    out[ankleIdx] = placeAtAngleLength(newKnee, origAngleA, newLenA, ankle)
                }
            }
        }
        retargetLeg(8, 9, 10)   // hông phải - gối phải - mắt cá phải
        retargetLeg(11, 12, 13) // hông trái - gối trái - mắt cá trái

        return out
    }

    /**
     * Retarget CẢ 1 PoseVariant (nhiều người) — gán mỗi vị trí `people[i]`
     * cho ĐÚNG 1 nhân vật cụ thể theo `characterProportions[i]` (danh sách
     * PHẢI cùng thứ tự với scene.characters — đây chính là chỗ GIẢI QUYẾT
     * lỗ hổng "skeleton không biết ai là ai" đã ghi ở mục 12: trước đây
     * native tự vẽ people[0]/people[1] không biết ứng với nhân vật nào; giờ
     * Kotlin (biết chính xác thứ tự scene.characters) gán tường minh TRƯỚC
     * khi gửi toạ độ cho native — native giờ chỉ vẽ, không cần biết danh
     * tính nữa).
     */
    fun retargetVariant(
        variant: StoryManager.PoseVariant, characterProportions: List<BoneProportions>
    ): List<List<StoryManager.PoseKeypoint>> {
        return variant.people.mapIndexed { i, person ->
            val target = characterProportions.getOrNull(i) ?: BoneProportions() // thiếu nhân vật ứng -> giữ chuẩn người lớn
            retargetPerson(person, variant.sourceProportions, target)
        }
    }
}
