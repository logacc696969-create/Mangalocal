// native_crash_handler.cpp — bắt crash Ở TẦNG NATIVE (SIGSEGV/SIGABRT/...).
//
// MangaLocalApplication.kt (phía Kotlin) chỉ bắt được exception Java/Kotlin
// (Thread.UncaughtExceptionHandler) — một crash THẬT SỰ trong code C++
// (con trỏ null, abort() từ MNN/abseil/sentencepiece, v.v.) là một TÍN HIỆU
// hệ điều hành (signal), không phải Java exception, nên handler Kotlin
// không bao giờ thấy được. File này cài sẵn signal handler ở tầng native để
// bắt đúng loại crash đó, ghi thông tin cơ bản ra file, rồi mới để hệ thống
// xử lý tiếp như bình thường (app vẫn "tiếp tục dừng" như cũ — chỉ thêm
// bước ghi log trước đó).
//
// LƯU Ý: bên trong 1 signal handler chỉ được gọi các hàm async-signal-safe
// (open/write/close/raise/sigaction...) — KHÔNG được malloc, KHÔNG được
// dùng std::string/std::cout, nên phần dưới cố tình viết bằng C thuần +
// buffer cấp phát sẵn. strsignal() không được đảm bảo an toàn 100% theo
// chuẩn POSIX nhưng thực tế dùng ổn định trên Bionic (libc Android) cho
// mục đích chẩn đoán tạm thời như thế này.
#include <jni.h>
#include <signal.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

namespace {

char g_crash_log_path[512] = {0};
struct sigaction g_old_handlers[64];

void CrashHandler(int signum, siginfo_t* info, void* /*ucontext*/) {
    if (g_crash_log_path[0] != '\0') {
        int fd = open(g_crash_log_path, O_WRONLY | O_CREAT | O_TRUNC, 0666);
        if (fd >= 0) {
            char buf[384];
            int len = snprintf(buf, sizeof(buf),
                "[NATIVE CRASH]\nsignal=%d (%s)\nfault_addr=%p\n\n"
                "(Ghi async-signal-safe nen khong co ten ham/stack trace chi "
                "tiet - chi du de phan biet loai loi: SIGSEGV=truy cap bo nho "
                "sai/con tro null, SIGABRT=do abort()/assert() trong thu vien "
                "C++ (MNN/abseil/sentencepiece/tokenizers...), "
                "SIGBUS/SIGILL/SIGFPE=khac.)\n",
                signum, strsignal(signum), info ? info->si_addr : nullptr);
            if (len > 0) write(fd, buf, (size_t)len);
            close(fd);
        }
    }
    // Khôi phục handler mặc định của hệ thống rồi tự raise lại — để
    // debuggerd/hệ thống vẫn xử lý crash tiếp như bình thường sau khi ta đã
    // kịp ghi log, không nuốt mất crash gốc.
    if (signum >= 0 && signum < 64) {
        sigaction(signum, &g_old_handlers[signum], nullptr);
    }
    raise(signum);
}

void InstallHandlers() {
    // Cấp 1 vùng stack RIÊNG cho signal handler (sigaltstack) — phòng
    // trường hợp crash là do TRÀN STACK (đệ quy sâu, buffer cấp phát trên
    // stack quá lớn trong MNN/tokenizer...): lúc đó stack của thread đang
    // chạy đã hết sạch, nếu handler chạy chung stack đó sẽ tự crash tiếp
    // ngay lập tức, không kịp ghi gì cả — đúng kiểu triệu chứng "chưa kịp
    // ghi 1 dòng log nào".
    static char alt_stack[SIGSTKSZ * 4];
    stack_t ss;
    ss.ss_sp = alt_stack;
    ss.ss_size = sizeof(alt_stack);
    ss.ss_flags = 0;
    sigaltstack(&ss, nullptr);

    int signals[] = {SIGSEGV, SIGABRT, SIGBUS, SIGILL, SIGFPE};
    for (int s : signals) {
        struct sigaction sa;
        memset(&sa, 0, sizeof(sa));
        sa.sa_sigaction = CrashHandler;
        sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
        sigaction(s, &sa, (s >= 0 && s < 64) ? &g_old_handlers[s] : nullptr);
    }
}

// Ưu tiên cao nhất còn cho phép với code người dùng (101) — đảm bảo handler
// này được cài đặt TRƯỚC các static initializer khác trong cùng thư viện
// .so (MNN/abseil/sentencepiece...), phòng trường hợp crash xảy ra ngay lúc
// dlopen() (System.loadLibrary phía Kotlin), tức TRƯỚC khi Kotlin kịp gọi
// bất kỳ hàm JNI nào để set đường dẫn file log — nếu vậy g_crash_log_path
// vẫn rỗng nên sẽ không ghi được gì, nhưng ít nhất handler cũng không làm
// hỏng thêm gì, và các crash XẢY RA SAU đó (khi đã set path) sẽ được ghi.
__attribute__((constructor(101)))
void EarlyInstallCrashHandler() {
    InstallHandlers();
}

}  // namespace

extern "C"
JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_setCrashLogPath(JNIEnv* env, jobject /*thiz*/, jstring path) {
    if (!path) return;
    const char* c = env->GetStringUTFChars(path, nullptr);
    if (c) {
        strncpy(g_crash_log_path, c, sizeof(g_crash_log_path) - 1);
        g_crash_log_path[sizeof(g_crash_log_path) - 1] = '\0';
        env->ReleaseStringUTFChars(path, c);
    }
}
