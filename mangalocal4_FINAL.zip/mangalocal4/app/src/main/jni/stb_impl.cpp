// stb_impl.cpp — nơi DUY NHẤT biên dịch phần implementation thật của
// stb_image/stb_image_write/stb_image_resize2 cho toàn bộ thư viện dùng
// chung (mangalocal_native.so). Tách ra đây vì nhiều file .cpp
// (esrgan_wrapper.cpp, yolo_wrapper.cpp, mnn_diffusion_pipeline.cpp,
// ip_adapter.cpp) đều cần các hàm stbi_*/stbir_* nhưng chỉ được có ĐÚNG 1
// bản implementation trong toàn bộ link unit, nếu không sẽ lỗi duplicate
// symbol lúc link (xem ghi chú SỬA trong sd_engine/SDUtils.hpp).
#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION
#define STB_IMAGE_RESIZE_IMPLEMENTATION

#include "stb_image.h"
#include "stb_image_write.h"
#include "sd_engine/stb_image_resize2.h"
