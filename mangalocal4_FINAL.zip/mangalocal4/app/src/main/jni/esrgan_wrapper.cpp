// ESRGAN upscaler viết lại dùng MNN::Interpreter/Session/Tensor — API LÕI
// của MNN (Interpreter::createFromFile, createSession, getSessionInput/
// Output, copyFromHostTensor/copyToHostTensor). Đây là API công khai ổn
// định lâu năm của MNN core (khác với API MNN-Diffusion còn đang xác nhận
// ở jni/mnn_diffusion_pipeline.cpp) nên viết trực tiếp được, KHÔNG cần
// chờ bước in header như phần diffusion.
//
// ĐIỀU CHƯA XÁC NHẬN: tên input/output tensor thật bên trong file
// realesrgan.mnn của bạn (ví dụ "input"/"output", hay tên khác tùy lúc
// convert bằng MNNConvert --keepInputFormat). Code dưới dùng
// getSessionInputAll()/getSessionOutputAll() để tự lấy tensor ĐẦU TIÊN
// thay vì hardcode tên — an toàn hơn, tự thích ứng, nhưng nếu model có
// nhiều input/output thật sự thì cần sửa lại chỗ đó.
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cstring>
#include <memory>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
int            stbi_write_png(const char*, int, int, int, const void*, int);
}

#define TAG "ESRGAN_MNN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

struct EsrganWrapper {
    std::shared_ptr<MNN::Interpreter> net;
    MNN::Session* session = nullptr;
    int scale;
    int tileSize = 128;
    bool ok = false;

    EsrganWrapper(int s, const std::string& modelDir) : scale(s) {
        std::string modelPath = modelDir + "/realesrgan_x" + std::to_string(s) + ".mnn";
        net.reset(MNN::Interpreter::createFromFile(modelPath.c_str()));
        if (!net) { LOGE("Khong doc duoc model: %s", modelPath.c_str()); return; }

        MNN::ScheduleConfig config;
        // Backend: thử OpenCL (Adreno GPU) trước, MNN tự fallback nội bộ
        // về CPU nếu thiết bị/driver không hỗ trợ — không cần code fallback
        // thủ công, đây là hành vi mặc định của MNN khi tạo Session.
        config.type = MNN_FORWARD_OPENCL;
        config.numThread = 4;
        MNN::BackendConfig backendConfig;
        backendConfig.precision = MNN::BackendConfig::Precision_Low; // fp16 nếu ARM82 bật
        config.backendConfig = &backendConfig;

        session = net->createSession(config);
        if (!session) {
            LOGE("createSession OpenCL that bai, roi ve CPU");
            config.type = MNN_FORWARD_CPU;
            session = net->createSession(config);
        }
        if (!session) { LOGE("createSession CPU cung fail"); return; }
        ok = true;
        LOGI("ESRGAN (MNN) x%d nap OK: %s", scale, modelPath.c_str());
    }

    void sharpenInPlace(std::vector<unsigned char>& buf, int w, int h) {
        std::vector<unsigned char> orig = buf;
        const float kernel[9] = {0,-0.5f,0, -0.5f,3.0f,-0.5f, 0,-0.5f,0};
        for (int y = 1; y < h-1; y++) {
            for (int x = 1; x < w-1; x++) {
                for (int c = 0; c < 3; c++) {
                    float sum = 0; int k = 0;
                    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                        sum += orig[((y+dy)*w + (x+dx))*3 + c] * kernel[k++];
                    }
                    buf[(y*w+x)*3+c] = (unsigned char)std::clamp((int)sum, 0, 255);
                }
            }
        }
    }

    // Chạy 1 tile qua session MNN, trả về buffer RGB float [0,1] đã upscale.
    bool runTile(const unsigned char* srcTile, int tw, int th, std::vector<float>& outTile, int& otw, int& oth) {
        auto inputs = net->getSessionInputAll(session);
        if (inputs.empty()) { LOGE("model khong co input tensor"); return false; }
        MNN::Tensor* input = inputs.begin()->second;

        net->resizeTensor(input, {1, 3, th, tw});
        net->resizeSession(session);

        MNN::Tensor hostIn(input, MNN::Tensor::CAFFE);
        for (int y = 0; y < th; y++) for (int x = 0; x < tw; x++) {
            const unsigned char* p = srcTile + (y*tw + x) * 3;
            for (int c = 0; c < 3; c++) {
                hostIn.host<float>()[c*th*tw + y*tw + x] = p[c] / 255.f;
            }
        }
        input->copyFromHostTensor(&hostIn);

        net->runSession(session);

        auto outputs = net->getSessionOutputAll(session);
        if (outputs.empty()) { LOGE("model khong co output tensor"); return false; }
        MNN::Tensor* output = outputs.begin()->second;
        MNN::Tensor hostOut(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&hostOut);

        auto shape = hostOut.shape(); // [1, 3, oh, ow] theo quy uoc CAFFE (NCHW)
        if (shape.size() != 4) { LOGE("output shape khong dung 4 chieu"); return false; }
        oth = shape[2]; otw = shape[3];
        outTile.assign(hostOut.host<float>(), hostOut.host<float>() + (size_t)3*oth*otw);
        return true;
    }

    bool upscale(const std::string& in, const std::string& out, bool sharpen) {
        if (!ok) { LOGE("upscale goi khi chua init xong"); return false; }
        int w, h, c;
        unsigned char* data = stbi_load(in.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("load fail: %s", in.c_str()); return false; }

        int ow = w * scale, oh = h * scale;
        std::vector<unsigned char> outBuf((size_t)ow * oh * 3);
        std::vector<unsigned char> tileBuf((size_t)tileSize * tileSize * 3);

        for (int ty = 0; ty < h; ty += tileSize) {
            for (int tx = 0; tx < w; tx += tileSize) {
                int tw = std::min(tileSize, w - tx);
                int th = std::min(tileSize, h - ty);
                for (int y = 0; y < th; y++)
                    memcpy(tileBuf.data() + (size_t)y*tw*3, data + ((size_t)(ty+y)*w + tx)*3, (size_t)tw*3);

                std::vector<float> outTile; int otw, oth;
                if (!runTile(tileBuf.data(), tw, th, outTile, otw, oth)) {
                    LOGE("runTile fail tai (%d,%d)", tx, ty);
                    stbi_image_free(data);
                    return false;
                }
                int otx = tx*scale, oty = ty*scale;
                for (int y = 0; y < oth && (oty+y) < oh; y++) {
                    for (int x = 0; x < otw && (otx+x) < ow; x++) {
                        unsigned char* p = outBuf.data() + ((size_t)(oty+y)*ow + (otx+x)) * 3;
                        for (int ch = 0; ch < 3; ch++) {
                            float v = outTile[(size_t)ch*oth*otw + y*otw + x] * 255.f;
                            p[ch] = (unsigned char)std::clamp((int)v, 0, 255);
                        }
                    }
                }
            }
        }
        stbi_image_free(data);
        if (sharpen) sharpenInPlace(outBuf, ow, oh);
        bool okWrite = stbi_write_png(out.c_str(), ow, oh, 3, outBuf.data(), ow*3) != 0;
        LOGI("upscale %dx%d -> %dx%d sharpen=%d: %s", w, h, ow, oh, sharpen, okWrite?"OK":"FAIL");
        return okWrite;
    }

    ~EsrganWrapper() {
        if (session && net) net->releaseSession(session);
    }
};

static std::string j2s_e(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_esrganInit(JNIEnv* e, jobject, jint scale, jstring jDir) {
    auto* w = new EsrganWrapper(scale, j2s_e(e, jDir));
    if (!w->ok) { delete w; return 0; }
    return reinterpret_cast<jlong>(w);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_esrganUpscale(JNIEnv* e, jobject, jlong ptr, jstring jin, jstring jout, jboolean sharpen) {
    if (!ptr) return JNI_FALSE;
    return reinterpret_cast<EsrganWrapper*>(ptr)->upscale(j2s_e(e,jin), j2s_e(e,jout), sharpen) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_esrganFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<EsrganWrapper*>(ptr);
}
