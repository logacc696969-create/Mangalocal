// YOLOv8n detect (dùng cho auto bubble) viết lại dùng MNN::Interpreter/
// Session/Tensor — cùng API lõi đã dùng ở esrgan_wrapper.cpp.
//
// Cố ý KHÔNG dùng MNN::CV::ImageProcess (module xử lý ảnh riêng của MNN)
// vì chưa xác nhận chắc API đó — tự viết letterbox-resize + normalize
// bằng tay (chỉ phép toán số học đơn giản, không phụ thuộc API nào chưa
// kiểm chứng), giảm rủi ro đoán sai như bài học đã ghi trong handoff.
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cstring>
#include <memory>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
}

#define TAG "YOLOv8n_MNN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

struct Detection {
    float x1, y1, x2, y2, conf;
};

struct YoloWrapper {
    std::shared_ptr<MNN::Interpreter> net;
    MNN::Session* session = nullptr;
    int inputSize = 320; // input nhỏ cho nhanh trên SD888
    bool ok = false;

    YoloWrapper(const std::string& modelDir) {
        std::string modelPath = modelDir + "/yolov8n.mnn";
        net.reset(MNN::Interpreter::createFromFile(modelPath.c_str()));
        if (!net) { LOGE("khong doc duoc model: %s", modelPath.c_str()); return; }

        MNN::ScheduleConfig config;
        config.type = MNN_FORWARD_OPENCL; // tự fallback CPU nếu thiết bị không hỗ trợ
        config.numThread = 4;
        MNN::BackendConfig backendConfig;
        backendConfig.precision = MNN::BackendConfig::Precision_Low;
        config.backendConfig = &backendConfig;

        session = net->createSession(config);
        if (!session) {
            LOGE("createSession OpenCL fail, roi ve CPU");
            config.type = MNN_FORWARD_CPU;
            session = net->createSession(config);
        }
        if (!session) { LOGE("createSession CPU cung fail"); return; }
        ok = true;
        LOGI("YOLOv8n (MNN) nap OK: %s", modelPath.c_str());
    }

    // Letterbox resize bằng nearest-neighbor thủ công (đủ dùng cho detect,
    // không cần chất lượng nội suy cao như upscale ảnh cuối).
    void letterbox(const unsigned char* src, int w, int h, std::vector<unsigned char>& dst,
                   float& scale, int& padW, int& padH) {
        scale = std::min((float)inputSize / w, (float)inputSize / h);
        int newW = std::max(1, (int)(w * scale)), newH = std::max(1, (int)(h * scale));
        padW = inputSize - newW; padH = inputSize - newH;

        dst.assign((size_t)inputSize * inputSize * 3, 114); // pad màu xám 114 giống ultralytics
        int offX = padW / 2, offY = padH / 2;
        for (int y = 0; y < newH; y++) {
            int srcY = std::min(h - 1, (int)(y / scale));
            for (int x = 0; x < newW; x++) {
                int srcX = std::min(w - 1, (int)(x / scale));
                const unsigned char* sp = src + ((size_t)srcY * w + srcX) * 3;
                unsigned char* dp = dst.data() + ((size_t)(y + offY) * inputSize + (x + offX)) * 3;
                dp[0] = sp[0]; dp[1] = sp[1]; dp[2] = sp[2];
            }
        }
    }

    std::vector<Detection> detect(const std::string& imagePath, float confThresh = 0.4f) {
        std::vector<Detection> results;
        if (!ok) { LOGE("detect goi khi chua init xong"); return results; }

        int w, h, c;
        unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("load fail: %s", imagePath.c_str()); return results; }

        float scale; int padW, padH;
        std::vector<unsigned char> letterboxed;
        letterbox(data, w, h, letterboxed, scale, padW, padH);
        stbi_image_free(data);

        auto inputs = net->getSessionInputAll(session);
        if (inputs.empty()) { LOGE("model khong co input tensor"); return results; }
        MNN::Tensor* input = inputs.begin()->second;
        net->resizeTensor(input, {1, 3, inputSize, inputSize});
        net->resizeSession(session);

        MNN::Tensor hostIn(input, MNN::Tensor::CAFFE);
        for (int y = 0; y < inputSize; y++) for (int x = 0; x < inputSize; x++) {
            const unsigned char* p = letterboxed.data() + ((size_t)y*inputSize + x) * 3;
            for (int ch = 0; ch < 3; ch++)
                hostIn.host<float>()[(size_t)ch*inputSize*inputSize + y*inputSize + x] = p[ch] / 255.f;
        }
        input->copyFromHostTensor(&hostIn);

        net->runSession(session);

        auto outputs = net->getSessionOutputAll(session);
        if (outputs.empty()) { LOGE("model khong co output tensor"); return results; }
        MNN::Tensor* output = outputs.begin()->second;
        MNN::Tensor hostOut(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&hostOut);

        // Output YOLOv8 chuẩn xuất ONNX/MNN thường là [1, 84, numBoxes]
        // (4 toạ độ box + 80 lớp COCO, class 0 = person). Nếu file .mnn thật
        // của bạn xuất ra layout khác (đã transpose thành [1, numBoxes, 84]),
        // đoạn đọc dưới cần đổi lại — CHƯA kiểm chứng với model thật của bạn,
        // chỉ theo đúng quy ước xuất mặc định phổ biến nhất của ultralytics.
        auto shape = hostOut.shape();
        if (shape.size() != 3) { LOGE("output shape khong nhu ky vong: rank=%zu", shape.size()); return results; }
        int numAttrs = shape[1];
        int numBoxes = shape[2];
        const float* raw = hostOut.host<float>();

        for (int i = 0; i < numBoxes; i++) {
            float cx = raw[0*numBoxes + i];
            float cy = raw[1*numBoxes + i];
            float bw = raw[2*numBoxes + i];
            float bh = raw[3*numBoxes + i];
            float personConf = raw[4*numBoxes + i]; // class 0 = person
            (void)numAttrs;
            if (personConf < confThresh) continue;

            float x1 = (cx - bw/2 - padW/2.f) / scale;
            float y1 = (cy - bh/2 - padH/2.f) / scale;
            float x2 = (cx + bw/2 - padW/2.f) / scale;
            float y2 = (cy + bh/2 - padH/2.f) / scale;

            results.push_back({
                std::clamp(x1/w, 0.f, 1.f), std::clamp(y1/h, 0.f, 1.f),
                std::clamp(x2/w, 0.f, 1.f), std::clamp(y2/h, 0.f, 1.f),
                personConf
            });
        }

        std::sort(results.begin(), results.end(), [](auto& a, auto& b) { return a.conf > b.conf; });
        std::vector<Detection> filtered;
        for (auto& d : results) {
            bool overlap = false;
            for (auto& f : filtered) {
                float ox = std::max(0.f, std::min(d.x2,f.x2) - std::max(d.x1,f.x1));
                float oy = std::max(0.f, std::min(d.y2,f.y2) - std::max(d.y1,f.y1));
                if (ox * oy > 0.3f * (d.x2-d.x1)*(d.y2-d.y1)) { overlap = true; break; }
            }
            if (!overlap) filtered.push_back(d);
            if (filtered.size() >= 10) break;
        }

        LOGI("detected %zu boxes", filtered.size());
        return filtered;
    }

    ~YoloWrapper() {
        if (session && net) net->releaseSession(session);
    }
};

static std::string j2s_y(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_yoloInit(JNIEnv* e, jobject, jstring jDir) {
    auto* w = new YoloWrapper(j2s_y(e, jDir));
    if (!w->ok) { delete w; return 0; }
    return reinterpret_cast<jlong>(w);
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_mangalocal_pipeline_NativeBridge_yoloDetect(JNIEnv* e, jobject, jlong ptr, jstring jImg) {
    if (!ptr) return e->NewFloatArray(0);
    auto* yolo = reinterpret_cast<YoloWrapper*>(ptr);
    auto dets = yolo->detect(j2s_y(e, jImg));

    std::vector<float> flat;
    for (auto& d : dets) {
        flat.push_back(d.x1); flat.push_back(d.y1);
        flat.push_back(d.x2); flat.push_back(d.y2);
        flat.push_back(d.conf);
    }
    jfloatArray result = e->NewFloatArray((jsize)flat.size());
    if (!flat.empty()) e->SetFloatArrayRegion(result, 0, (jsize)flat.size(), flat.data());
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_yoloFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<YoloWrapper*>(ptr);
}
