#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>

#include <sstream>
#include <memory>
// llama.h ĐÃ BỎ — chuyển LLM sang MNN-LLM (mở lại quyết định cũ, xem
// comment trong CMakeLists.txt). Header thật của MNN-LLM nằm ở
// transformers/llm/engine/include/llm/llm.hpp — API createLLM/load/
// response đã xác nhận qua tài liệu chính thức MNN (mnn-docs.readthedocs.io),
// KHÔNG phải đoán như phần diffusion.
#include "llm/llm.hpp"
// stable-diffusion.h / story_consistency.h ĐÃ BỎ — chuyển engine sinh ảnh
// sang MNN-Diffusion (xem handoff mục 3 và 8). Phần SD thật sẽ nằm ở
// jni/mnn_diffusion_pipeline.cpp, CHƯA VIẾT — đang chờ bước build in ra
// header thật của MNN transformers/diffusion (xem build.yml, step
// "Print MNN diffusion headers"). Các hàm sd* dưới đây tạm thời là STUB
// trả về thất bại có log rõ ràng, để APK vẫn build được và các phần khác
// (LLM, ESRGAN, YOLO, UI) test được ngay, không phải chờ toàn bộ pipeline
// sinh ảnh viết xong mới có APK chạy được.

#define TAG "MangaLocal"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::string j2s(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

// ── LLM (MNN-LLM) ──────────────────────────────────────────────────────────
//
// Backend fallback: thử NPU (QNN) trước -> GPU (OpenCL) -> CPU. Đây là
// cùng cơ chế "thử rồi bắt lỗi, không whitelist chip cứng" đã áp dụng cho
// phần diffusion. Với build hiện tại (MANGALOCAL_ENABLE_QNN=OFF mặc định,
// xem CMakeLists.txt), nhánh "qnn" sẽ luôn rơi xuống "opencl" — vẫn thỏa
// yêu cầu tối thiểu GPU. Khi có QNN SDK thật và bật MANGALOCAL_ENABLE_QNN,
// nhánh "qnn" mới có cơ hội thành công thật.
//
// THAM SỐ nGpuLayers (giữ tên cũ từ thời llama.cpp để không phải sửa
// LLMParser.kt/RuntimeOptimizer.kt): với MNN-LLM không có khái niệm
// "offload từng layer" như llama.cpp — MNN chọn NGUYÊN backend cho cả
// model. Ở đây diễn giải lại: nGpuLayers > 0 nghĩa là "được phép thử
// GPU/NPU", 0 nghĩa là "ép CPU" (dùng khi cần chẩn đoán lỗi, giống ý
// nghĩa cũ). Ý NGHĨA SỐ LƯỢNG LAYER KHÔNG CÒN ÁP DỤNG — cần xem lại
// RuntimeOptimizer.kt có tính toán gì dựa trên độ lớn con số đó không,
// nếu có phải sửa logic bên Kotlin cho khớp diễn giải mới (0/greater-than-0
// thay vì số layer cụ thể).

struct MnnLlmHandle {
    std::unique_ptr<MNN::Transformer::Llm> llm;
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_llamaInit(JNIEnv* e, jobject, jstring jPath, jint nT, jint nCtx, jint nGpuLayers) {
    using namespace MNN::Transformer;
    std::string configPath = j2s(e, jPath);
    auto* handle = new MnnLlmHandle();
    handle->llm.reset(Llm::createLLM(configPath));
    if (!handle->llm) {
        LOGE("MNN-LLM createLLM that bai: %s", configPath.c_str());
        delete handle;
        return 0;
    }

    bool loaded = false;
    if (nGpuLayers > 0) {
        try {
            handle->llm->set_config(R"({"backend_type": "qnn"})");
            handle->llm->load();
            LOGI("MNN-LLM nap OK voi backend QNN");
            loaded = true;
        } catch (const std::exception& qnnErr) {
            LOGI("QNN khong kha dung cho LLM (%s), thu OpenCL", qnnErr.what());
        }
        if (!loaded) {
            try {
                handle->llm->set_config(R"({"backend_type": "opencl"})");
                handle->llm->load();
                LOGI("MNN-LLM nap OK voi backend OpenCL (GPU)");
                loaded = true;
            } catch (const std::exception& glErr) {
                LOGI("OpenCL khong kha dung cho LLM (%s), roi ve CPU", glErr.what());
            }
        }
    }
    if (!loaded) {
        try {
            handle->llm->set_config(R"({"backend_type": "cpu"})");
            handle->llm->load();
            LOGI("MNN-LLM nap OK voi backend CPU");
            loaded = true;
        } catch (const std::exception& cpuErr) {
            LOGE("MNN-LLM load() that bai ca CPU: %s", cpuErr.what());
        }
    }

    if (!loaded) { delete handle; return 0; }
    LOGI("LLM init xong: threads=%d ctx=%d gpu_layers(hint)=%d", nT, nCtx, nGpuLayers);
    return reinterpret_cast<jlong>(handle);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_mangalocal_pipeline_NativeBridge_llamaGenerate(JNIEnv* e, jobject, jlong ptr, jstring jp, jint maxTok, jfloat temp) {
    auto* h = reinterpret_cast<MnnLlmHandle*>(ptr);
    if (!h || !h->llm) { LOGE("llamaGenerate goi khi chua init"); return e->NewStringUTF(""); }

    std::string prompt = j2s(e, jp);
    std::ostringstream out;
    try {
        // Chữ ký response() chính xác (số tham số, có nhận max_tokens hay
        // không) CHƯA kiểm chứng 100% — đây là điểm duy nhất trong đoạn
        // MNN-LLM này còn rủi ro, sẽ tự lộ ra ngay ở lỗi compile nếu sai,
        // khác với lỗi ngầm lúc runtime. Xem log build.yml step "Print
        // MNN LLM headers" nếu bước biên dịch báo lỗi ở dòng này.
        h->llm->response(prompt, &out, nullptr, maxTok);
    } catch (const std::exception& ex) {
        LOGE("MNN-LLM response loi: %s", ex.what());
        return e->NewStringUTF("");
    }
    return e->NewStringUTF(out.str().c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_llamaFree(JNIEnv*, jobject, jlong ptr) {
    auto* h = reinterpret_cast<MnnLlmHandle*>(ptr);
    delete h; // unique_ptr tự giải phóng Llm*
}

