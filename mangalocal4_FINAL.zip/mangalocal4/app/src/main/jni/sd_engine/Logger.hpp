#ifndef MANGALOCAL_LOGGER_HPP
#define MANGALOCAL_LOGGER_HPP
// Logger.hpp THAY THẾ — bản gốc của local-dream lấy file này từ
// SampleApp của Qualcomm QNN SDK (vá qua `git apply`, xem CMakeLists.txt
// gốc: build.gradle của họ patch trực tiếp vào QNN SDK cài sẵn trên máy,
// không có trong repo git). File đó KHÔNG có trong local-dream-master.zip
// bạn upload (không tự chứa), nên viết lại 1 bản tương thích ở đây.
//
// Chỉ là macro log kiểu printf, không phải phần logic nghiệp vụ — suy ra
// trực tiếp từ cách gọi thấy trong toàn bộ code thật (QNN_INFO/QNN_ERROR/
// QNN_WARN dùng y hệt printf), rủi ro thấp, không phải đoán API lạ.
#include <android/log.h>

#ifndef MANGALOCAL_LOG_TAG
#define MANGALOCAL_LOG_TAG "MangaLocal_SDEngine"
#endif

#define QNN_INFO(...)  __android_log_print(ANDROID_LOG_INFO,  MANGALOCAL_LOG_TAG, __VA_ARGS__)
#define QNN_WARN(...)  __android_log_print(ANDROID_LOG_WARN,  MANGALOCAL_LOG_TAG, __VA_ARGS__)
#define QNN_ERROR(...) __android_log_print(ANDROID_LOG_ERROR, MANGALOCAL_LOG_TAG, __VA_ARGS__)
#define QNN_DEBUG(...) __android_log_print(ANDROID_LOG_DEBUG, MANGALOCAL_LOG_TAG, __VA_ARGS__)

#endif  // MANGALOCAL_LOGGER_HPP
