// ip_adapter.cpp — chạy UNet đã gộp sẵn IP-Adapter (giữ nhân vật) +
// ControlNet-OpenPose (giữ tư thế), xuất bởi tools/export_ipa_controlnet_unet.py.
//
// KHÔNG đoán API MNN ở đây — chỉ dùng lại đúng MNN::Interpreter/Session/
// Tensor đã dùng ổn định ở esrgan_wrapper.cpp/yolo_wrapper.cpp, cộng với
// Pipeline/PipelineSd15Cpu thật đã port. Phần "chưa chắc chắn" duy nhất là
// tên 2 tensor input mới ("control_hint", "ip_image_embeds") và tên output
// ("image_embeds") của ip_image_encoder.mnn — CHÍNH LÀ TÊN TÔI TỰ ĐẶT
// trong script export_ipa_controlnet_unet.py, nên đây không phải đoán API
// người khác, mà là tự thiết kế + tự dùng, khớp theo thiết kế.
//
// THƯ VIỆN TƯ THẾ (pose template): đọc từ pose_library.json thật (sinh ra
// bởi tools/extract_pose_library.py chạy MediaPipe Pose trên ảnh thật),
// KHÔNG còn hardcode toạ độ tự đoán trong file này nữa (xem namespace
// pose_templates bên dưới, hàm loadLibrary()).

#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <cmath>
#include <memory>
#include <map>
#include <fstream>
#include <algorithm>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

#include "sd_engine/PipelineSd15Cpu.hpp"
#include "sd_engine/TextEncoder.hpp"

extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
}
#include "sd_engine/stb_image_resize2.h"  // dùng include thật thay vì tự khai báo extern, tránh lệch chữ ký ABI

#define TAG "MangaLocal_IPAdapter"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ─────────────────────────────────────────────────────────────────────────
// 1. Thư viện tư thế (OpenPose COCO-18 điểm, toạ độ chuẩn hoá 0..1, có z)
//
// ĐÃ SỬA (so với bản đầu tiên): KHÔNG còn hardcode toạ độ tự đoán trong
// C++ nữa — đọc từ "pose_library.json" (assets), sinh ra bởi
// tools/extract_pose_library.py chạy MediaPipe Pose trên ẢNH THẬT. z lấy
// trực tiếp từ MediaPipe ("giá trị càng nhỏ càng gần camera" — tài liệu
// chính thức Google), dùng để sắp thứ tự vẽ, giải quyết đúng vấn đề "tay
// ai đè lên người ai" khi nhiều nhân vật đan vào nhau. Nếu thiếu file
// pose_library.json, fallback về 1 tư thế đứng đơn giản (không phải bịa
// nhiều tư thế phức tạp như bản cũ).
// ─────────────────────────────────────────────────────────────────────────
namespace pose_templates {

struct Keypoint { float x, y, z; bool visible; };
using Skeleton = std::array<Keypoint, 18>;  // thứ tự chuẩn COCO-18 của OpenPose

// Cặp khớp nối để vẽ (chuẩn OpenPose COCO-18 pairs) — định dạng kỹ thuật
// công khai của OpenPose, không phải nội dung sáng tạo riêng.
const std::vector<std::pair<int,int>> kBonePairs = {
    {1,2},{1,5},{2,3},{3,4},{5,6},{6,7},{1,8},{8,9},{9,10},
    {1,11},{11,12},{12,13},{1,0},{0,14},{14,16},{0,15},{15,17}
};

const std::vector<std::array<int,3>> kBoneColors = {
    {255,0,0},{255,85,0},{255,170,0},{255,255,0},{170,255,0},{85,255,0},
    {0,255,0},{0,255,85},{0,255,170},{0,255,255},{0,170,255},{0,85,255},
    {0,0,255},{85,0,255},{170,0,255},{255,0,255},{255,0,170}
};

inline Skeleton fallbackStanding() {
    // Dùng KHI KHÔNG có pose_library.json — chỉ 1 tư thế đơn giản, không
    // bịa thêm tư thế phức tạp (ôm/vật lộn) vì không có ảnh thật kiểm
    // chứng thì thà không có còn hơn có sai.
    Skeleton s{};
    float coords[18][2] = {
        {0.5f,0.10f},{0.5f,0.20f},{0.42f,0.22f},{0.38f,0.35f},{0.35f,0.48f},
        {0.58f,0.22f},{0.62f,0.35f},{0.65f,0.48f},{0.46f,0.50f},{0.45f,0.68f},
        {0.44f,0.85f},{0.54f,0.50f},{0.55f,0.68f},{0.56f,0.85f},
        {0.48f,0.09f},{0.52f,0.09f},{0.46f,0.10f},{0.54f,0.10f}
    };
    for (int i = 0; i < 18; i++) s[i] = {coords[i][0], coords[i][1], 0.f, true};
    return s;
}

struct PoseVariant { std::string angle; std::vector<Skeleton> people; };

// ĐÃ XOÁ loadLibrary()/pickVariant() khỏi file này (mục 33 TECHNICAL_STATUS.md
// — đổi kiến trúc: đọc pose_library.json + chọn variant + RETARGET theo tỷ
// lệ xương từng nhân vật giờ làm ở Kotlin, PoseRetargeter.kt — vì CHỈ
// Kotlin mới biết chính xác scene.characters[i] ứng với người thứ mấy
// trong khung xương, native không có thông tin đó (đúng lỗ hổng "skeleton
// không có tên" đã ghi ở mục 12). Native giờ CHỈ VẼ toạ độ đã nhận sẵn.

// Đọc toạ độ khung xương ĐÃ RETARGET từ Kotlin — mảng float phẳng, mỗi
// người 18 khớp * 4 giá trị (x, y, z, visible dạng 0.0/1.0) = 72 float.
// Rỗng hoặc lỗi format -> trả vector rỗng (gọi nơi khác tự fallback).
inline std::vector<Skeleton> parseSkeletonsFromFloatArray(const float* data, int len) {
    std::vector<Skeleton> result;
    const int stride = 18 * 4;
    if (len <= 0 || len % stride != 0) {
        if (len != 0) LOGE("skeletonData length %d khong chia het cho %d - bo qua", len, stride);
        return result;
    }
    int numPeople = len / stride;
    for (int p = 0; p < numPeople; p++) {
        Skeleton s{};
        for (int k = 0; k < 18; k++) {
            int base = p * stride + k * 4;
            s[k] = {data[base], data[base+1], data[base+2], data[base+3] > 0.5f};
        }
        result.push_back(s);
    }
    return result;
}

// Vẽ khung xương (nhiều người) lên canvas RGB size x size, nền đen.
// ĐÃ SỬA: sắp theo z trước khi vẽ (xa vẽ trước, gần vẽ đè lên sau) —
// trước đây vẽ theo thứ tự bất kỳ, không xét độ sâu.
inline std::vector<uint8_t> renderSkeletons(std::vector<Skeleton> people, int size) {
    std::sort(people.begin(), people.end(), [](const Skeleton& a, const Skeleton& b) {
        auto avgZ = [](const Skeleton& s) {
            float sum = 0; int n = 0;
            for (auto& k : s) if (k.visible) { sum += k.z; n++; }
            return n ? sum / n : 0.f;
        };
        return avgZ(a) > avgZ(b);  // z lớn hơn (xa camera hơn) vẽ TRƯỚC
    });

    std::vector<uint8_t> canvas((size_t)size * size * 3, 0);
    auto putPixel = [&](int x, int y, int r, int g, int b) {
        if (x < 0 || y < 0 || x >= size || y >= size) return;
        uint8_t* p = canvas.data() + ((size_t)y * size + x) * 3;
        p[0] = (uint8_t)r; p[1] = (uint8_t)g; p[2] = (uint8_t)b;
    };
    auto drawLine = [&](float x1, float y1, float x2, float y2, int r, int g, int b) {
        int steps = size / 4;
        for (int i = 0; i <= steps; i++) {
            float t = (float)i / steps;
            int x = (int)((x1 + (x2 - x1) * t) * size);
            int y = (int)((y1 + (y2 - y1) * t) * size);
            for (int ox = -3; ox <= 3; ox++)
                for (int oy = -3; oy <= 3; oy++)
                    putPixel(x + ox, y + oy, r, g, b);
        }
    };
    for (auto& person : people) {
        for (size_t i = 0; i < kBonePairs.size(); i++) {
            auto [a, b] = kBonePairs[i];
            if (!person[a].visible || !person[b].visible) continue;
            auto c = kBoneColors[i % kBoneColors.size()];
            drawLine(person[a].x, person[a].y, person[b].x, person[b].y, c[0], c[1], c[2]);
        }
    }
    return canvas;
}

}  // namespace pose_templates

// ─────────────────────────────────────────────────────────────────────────
// 2. Bộ mã hoá ảnh nhân vật -> image_embeds (chạy ip_image_encoder.mnn)
// ─────────────────────────────────────────────────────────────────────────
class IpImageEncoder {
public:
    explicit IpImageEncoder(const std::string& modelPath) {
        net_.reset(MNN::Interpreter::createFromFile(modelPath.c_str()));
        if (!net_) { LOGE("IpImageEncoder: khong doc duoc %s", modelPath.c_str()); return; }
        MNN::ScheduleConfig cfg; cfg.type = MNN_FORWARD_CPU; cfg.numThread = 4;
        session_ = net_->createSession(cfg);
        ok_ = session_ != nullptr;
    }
    bool ok() const { return ok_; }

    // Trả về embedding thô (đọc shape thật từ tensor, không hardcode số).
    bool encode(const std::string& imagePath, std::vector<float>& outEmbed, std::vector<int>& outShape) {
        if (!ok_) return false;
        int w, h, c;
        unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("IpImageEncoder: load anh fail %s", imagePath.c_str()); return false; }

        std::vector<unsigned char> resized(224 * 224 * 3);
        stbir_resize_uint8_srgb(data, w, h, 0, resized.data(), 224, 224, 0, STBIR_RGB);
        stbi_image_free(data);

        auto inputs = net_->getSessionInputAll(session_);
        if (inputs.empty()) { LOGE("ip_image_encoder.mnn khong co input"); return false; }
        MNN::Tensor* input = inputs.begin()->second;

        MNN::Tensor hostIn(input, MNN::Tensor::CAFFE);
        // Chuẩn hoá CLIP: mean/std xấp xỉ chuẩn OpenAI CLIP ViT (0.481,0.457,0.408)/(0.268,0.261,0.275)
        const float mean[3] = {0.481f, 0.457f, 0.408f};
        const float stdv[3] = {0.268f, 0.261f, 0.275f};
        for (int y = 0; y < 224; y++) for (int x = 0; x < 224; x++) {
            unsigned char* p = resized.data() + (y * 224 + x) * 3;
            for (int ch = 0; ch < 3; ch++)
                hostIn.host<float>()[ch*224*224 + y*224 + x] = (p[ch]/255.f - mean[ch]) / stdv[ch];
        }
        input->copyFromHostTensor(&hostIn);
        net_->runSession(session_);

        auto outputs = net_->getSessionOutputAll(session_);
        if (outputs.empty()) { LOGE("ip_image_encoder.mnn khong co output"); return false; }
        MNN::Tensor* output = outputs.begin()->second;
        MNN::Tensor hostOut(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&hostOut);

        outShape = hostOut.shape();
        size_t n = 1; for (int d : outShape) n *= (size_t)std::max(1, d);
        outEmbed.assign(hostOut.host<float>(), hostOut.host<float>() + n);
        return true;
    }
private:
    std::shared_ptr<MNN::Interpreter> net_;
    MNN::Session* session_ = nullptr;
    bool ok_ = false;
};

// ─────────────────────────────────────────────────────────────────────────
// 3. Pipeline mở rộng — override hook đã thêm ở PipelineSd15Cpu.hpp để nạp
//    thêm "control_hint" + "ip_image_embeds" trước mỗi bước UNet.
// ─────────────────────────────────────────────────────────────────────────
class PipelineSd15CpuAugmented : public PipelineSd15Cpu {
public:
    PipelineSd15CpuAugmented(TextEncoder& te, const std::string& dir,
        const std::string& clip, const std::string& unet,
        const std::string& vaeDec, const std::string& vaeEnc, bool vPred)
        : PipelineSd15Cpu(te, dir, clip, unet, vaeDec, vaeEnc, vPred) {}

    // Gọi 1 lần trước khi bắt đầu sinh ảnh — set embedding nhân vật + tư thế.
    void setConditioning(const std::vector<float>& ipEmbed, const std::vector<int>& ipShape,
                          const std::vector<uint8_t>& controlHintRgb, int controlSize) {
        ipEmbed_ = ipEmbed; ipShape_ = ipShape;
        controlHintRgb_ = controlHintRgb; controlSize_ = controlSize;
        hasConditioning_ = true;
    }

protected:
    void onBeforeUnetRun(MNN::Interpreter* unetInterp, MNN::Session* unetSess) override {
        if (!hasConditioning_) return;  // không có điều kiện phụ -> chạy như bản gốc

        // ip_image_embeds — tên tự đặt trong export_ipa_controlnet_unet.py
        if (auto* t = unetInterp->getSessionInput(unetSess, "ip_image_embeds")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            size_t n = std::min(ipEmbed_.size(), (size_t)host.elementSize());
            memcpy(host.host<float>(), ipEmbed_.data(), n * sizeof(float));
            t->copyFromHostTensor(&host);
        } else {
            LOGE("Model nay khong co input 'ip_image_embeds' - co phai unet.mnn chua phai ban augmented?");
        }

        // control_hint — ảnh RGB khung xương, chuẩn hoá [0,1], NCHW
        if (auto* t = unetInterp->getSessionInput(unetSess, "control_hint")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            int size = controlSize_;
            for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
                const uint8_t* p = controlHintRgb_.data() + ((size_t)y*size+x)*3;
                for (int ch = 0; ch < 3; ch++)
                    host.host<float>()[(size_t)ch*size*size + y*size + x] = p[ch] / 255.f;
            }
            t->copyFromHostTensor(&host);
        } else {
            LOGE("Model nay khong co input 'control_hint' - co phai unet.mnn chua phai ban augmented?");
        }
    }

private:
    bool hasConditioning_ = false;
    std::vector<float> ipEmbed_;
    std::vector<int> ipShape_;
    std::vector<uint8_t> controlHintRgb_;
    int controlSize_ = 512;
};

// ─────────────────────────────────────────────────────────────────────────
// 4. JNI — nối vào sdTxt2ImgWithReference (đã là stub từ trước)
// ─────────────────────────────────────────────────────────────────────────
static std::string j2s_ip(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

// Handle riêng cho pipeline augmented — KHÁC SdHandle trong
// mnn_diffusion_pipeline.cpp (pipeline chuẩn không có input phụ).
struct SdAugmentedHandle {
    std::unique_ptr<TextEncoder> textEncoder;
    std::unique_ptr<PipelineSd15CpuAugmented> pipeline;
    std::unique_ptr<IpImageEncoder> ipEncoder;
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdInitAugmented(JNIEnv* e, jobject,
    jstring jModelDir, jstring jClip, jstring jUnetAugmented, jstring jVaeDec,
    jstring jVaeEnc, jstring jIpEncoderPath, jstring jTokenizer, jstring jEmbeddingsDir) {

    std::string dir = j2s_ip(e, jModelDir);
    try {
        auto handle = std::make_unique<SdAugmentedHandle>();
        handle->textEncoder = std::make_unique<TextEncoder>(false, false);
        handle->textEncoder->loadTokenizer(j2s_ip(e, jTokenizer));
        handle->textEncoder->loadEmbeddingTables(dir);
        // Textual Inversion — xem ghi chú tương ứng trong mnn_diffusion_pipeline.cpp sdInit().
        std::string embeddingsDir = j2s_ip(e, jEmbeddingsDir);
        if (!embeddingsDir.empty()) handle->textEncoder->loadTextualInversions(embeddingsDir);

        handle->pipeline = std::make_unique<PipelineSd15CpuAugmented>(
            *handle->textEncoder, dir, j2s_ip(e, jClip), j2s_ip(e, jUnetAugmented),
            j2s_ip(e, jVaeDec), j2s_ip(e, jVaeEnc), false);
        if (!handle->pipeline->initialize()) { LOGE("PipelineSd15CpuAugmented initialize() fail"); return 0; }

        handle->ipEncoder = std::make_unique<IpImageEncoder>(j2s_ip(e, jIpEncoderPath));
        if (!handle->ipEncoder->ok()) { LOGE("IpImageEncoder load fail"); return 0; }

        return reinterpret_cast<jlong>(handle.release());
    } catch (const std::exception& ex) {
        LOGE("sdInitAugmented loi: %s", ex.what());
        return 0;
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgWithReferenceAndPose(JNIEnv* e, jobject,
    jlong ptr, jstring jPrompt, jstring jNeg, jstring jRefImage, jfloatArray jSkeletonData,
    jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut) {

    auto* handle = reinterpret_cast<SdAugmentedHandle*>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgWithReferenceAndPose: chua init"); return JNI_FALSE; }

    std::vector<float> ipEmbed; std::vector<int> ipShape;
    if (!handle->ipEncoder->encode(j2s_ip(e, jRefImage), ipEmbed, ipShape)) {
        LOGE("Encode anh tham chieu that bai");
        return JNI_FALSE;
    }

    // Toạ độ khung xương ĐÃ RETARGET theo tỷ lệ từng nhân vật, tính sẵn ở
    // Kotlin (PoseRetargeter.kt, mục 32/33 TECHNICAL_STATUS.md) — native
    // KHÔNG còn tự đọc pose_library.json/chọn variant nữa.
    std::vector<pose_templates::Skeleton> chosen;
    if (jSkeletonData) {
        jsize len = e->GetArrayLength(jSkeletonData);
        std::vector<float> buf(len);
        e->GetFloatArrayRegion(jSkeletonData, 0, len, buf.data());
        chosen = pose_templates::parseSkeletonsFromFloatArray(buf.data(), (int)len);
    }
    if (chosen.empty()) {
        LOGI("Khong co skeleton data hop le tu Kotlin, dung fallback don gian");
        chosen = {pose_templates::fallbackStanding()};
    }
    auto controlHint = pose_templates::renderSkeletons(chosen, 512);

    handle->pipeline->setConditioning(ipEmbed, ipShape, controlHint, 512);

    GenerationRequest req;
    req.prompt = j2s_ip(e, jPrompt);
    req.negative_prompt = j2s_ip(e, jNeg);
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = false; req.img2img = false;

    try {
        GenerationResult result = handle->pipeline->generate(req, [](int,int,const std::string&){});
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_ip(e, jOut), std::ios::binary);
        if (!out) return JNI_FALSE;
        out.write(reinterpret_cast<const char*>(png.data()), (std::streamsize)png.size());
        return JNI_TRUE;
    } catch (const std::exception& ex) {
        LOGE("generate() (augmented) loi: %s", ex.what());
        return JNI_FALSE;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdFreeAugmented(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<SdAugmentedHandle*>(ptr);
}
