// MobileSAM click-to-mask (mục 21 TECHNICAL_STATUS.md — "Inpaint Anything"
// cho UI mask thủ công ở PHASE CUỐI, sau khi mọi quy trình tự động vẫn
// sai). User chạm 1 điểm trên vùng lỗi -> trả về mask chính xác theo đúng
// khối đó -> mask này feed thẳng vào sdImg2Img() ĐÃ CÓ (mục 16) — CÙNG 1
// inpainting với auto-fix mặt/tay, không viết inpainting riêng, đúng yêu
// cầu.
//
// TẠI SAO MOBILESAM: đã tra cứu xác nhận (không đoán) — nhẹ nhất họ SAM
// cho mobile (<10M tham số, encoder TinyViT), CHÍNH XÁC HƠN và NHANH HƠN
// FastSAM (dù FastSAM dùng kiến trúc YOLOv8-seg — không có lý do chọn
// FastSAM ở đây dù đang ưu tiên YOLO cho các việc khác). Tài liệu chính
// thức samexporter: "MobileSAM is the best choice for CPU-only environments
// with tight latency requirements" — đúng môi trường CPU-only trên di động.
//
// ĐÁNH ĐỔI KỸ THUẬT ĐÃ CHỌN (ghi rõ để không quên): encoder chạy LẠI MỖI
// LẦN CLICK (không cache image_embeddings qua nhiều click) — đơn giản hoá
// native code, chấp nhận được vì đây là tool DÙNG HIẾM (chỉ khi auto-fix
// vẫn sai), không phải tương tác liên tục thời gian thực. Muốn tối ưu sau
// (cache embeddings, chỉ decoder chạy lại mỗi click) thì sửa handle giữ
// image_embeddings qua nhiều lần gọi — CHƯA làm.
//
// RỦI RO CHƯA KIỂM CHỨNG QUAN TRỌNG NHẤT: input chính xác encoder khi
// export với --use-preprocess (ảnh 1024x1024 RGB uint8 thô hay đã chuẩn
// hoá ImageNet mean/std) CHỈ dựa trên tài liệu samexporter/MobileSAM, CHƯA
// tự chạy thử. Code dưới đây giả định graph tự lo chuẩn hoá (feed RGB
// 0..255 thô) — nếu build-test cho ra mask vô nghĩa, đây là chỗ đầu tiên
// cần soát lại.
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <memory>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
int            stbi_write_png(const char*, int, int, int, const void*, int);
}

#define TAG "MobileSAM_MNN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static const int SAM_INPUT_SIZE = 1024; // chuẩn SAM/MobileSAM, KHÔNG đổi được (kiến trúc cố định)

struct MobileSamHandle {
    std::shared_ptr<MNN::Interpreter> encoderNet, decoderNet;
    MNN::Session* encoderSession = nullptr;
    MNN::Session* decoderSession = nullptr;
    bool ok = false;

    MobileSamHandle(const std::string& modelDir) {
        std::string encPath = modelDir + "/mobile_sam_encoder.mnn";
        std::string decPath = modelDir + "/mobile_sam_decoder.mnn";
        encoderNet.reset(MNN::Interpreter::createFromFile(encPath.c_str()));
        decoderNet.reset(MNN::Interpreter::createFromFile(decPath.c_str()));
        if (!encoderNet || !decoderNet) { LOGE("khong doc duoc model encoder/decoder"); return; }

        MNN::ScheduleConfig config;
        config.type = MNN_FORWARD_CPU; // encoder ViT khá nặng, ưu tiên CPU ổn định
                                        // hơn OpenCL cho graph attention phức tạp —
                                        // CHƯA benchmark thật để biết OpenCL có nhanh
                                        // hơn không trên graph cụ thể này.
        config.numThread = 4;
        encoderSession = encoderNet->createSession(config);
        decoderSession = decoderNet->createSession(config);
        if (!encoderSession || !decoderSession) { LOGE("createSession fail"); return; }
        ok = true;
        LOGI("MobileSAM (MNN) nap OK: %s / %s", encPath.c_str(), decPath.c_str());
    }

    ~MobileSamHandle() {
        if (encoderSession && encoderNet) encoderNet->releaseSession(encoderSession);
        if (decoderSession && decoderNet) decoderNet->releaseSession(decoderSession);
    }
};

static std::string j2s_ms(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_mobileSamInit(JNIEnv* e, jobject, jstring jDir) {
    auto* h = new MobileSamHandle(j2s_ms(e, jDir));
    if (!h->ok) { delete h; return 0; }
    return reinterpret_cast<jlong>(h);
}

// Trả về đường dẫn file PNG mask đã ghi (trắng = vùng cần inpaint, đen =
// giữ nguyên — CÙNG QUY ƯỚC với buildMaskFile() trong MangaPipeline.kt để
// feed thẳng vào sdImg2Img() không cần chuyển đổi gì thêm). Rỗng ("") nếu lỗi.
extern "C" JNIEXPORT jstring JNICALL
Java_com_mangalocal_pipeline_NativeBridge_mobileSamClickToMask(
    JNIEnv* e, jobject, jlong ptr, jstring jImg, jfloat clickX, jfloat clickY, jstring jOutMask) {
    auto* h = reinterpret_cast<MobileSamHandle*>(ptr);
    if (!h || !h->ok) { LOGE("mobileSamClickToMask goi khi chua init"); return e->NewStringUTF(""); }

    std::string imgPath = j2s_ms(e, jImg);
    int origW, origH, c;
    unsigned char* pixels = stbi_load(imgPath.c_str(), &origW, &origH, &c, 3);
    if (!pixels) { LOGE("khong doc duoc anh: %s", imgPath.c_str()); return e->NewStringUTF(""); }

    // Letterbox resize cạnh dài về 1024 (chuẩn SAM), pad vuông — GIỐNG hệt
    // triết lý letterbox tay đã dùng ở yolo_wrapper.cpp/yolo_pose_wrapper.cpp,
    // không dùng API resize ngoài chưa kiểm chứng.
    float scale = std::min((float)SAM_INPUT_SIZE / origW, (float)SAM_INPUT_SIZE / origH);
    int newW = std::max(1, (int)(origW * scale)), newH = std::max(1, (int)(origH * scale));
    std::vector<unsigned char> letterboxed((size_t)SAM_INPUT_SIZE * SAM_INPUT_SIZE * 3, 0);
    for (int y = 0; y < newH; y++) {
        int srcY = std::min(origH - 1, (int)(y / scale));
        for (int x = 0; x < newW; x++) {
            int srcX = std::min(origW - 1, (int)(x / scale));
            const unsigned char* sp = pixels + ((size_t)srcY * origW + srcX) * 3;
            unsigned char* dp = letterboxed.data() + ((size_t)y * SAM_INPUT_SIZE + x) * 3;
            dp[0] = sp[0]; dp[1] = sp[1]; dp[2] = sp[2];
        }
    }
    stbi_image_free(pixels);

    // ── Encoder ──
    auto encInputs = h->encoderNet->getSessionInputAll(h->encoderSession);
    if (encInputs.empty()) { LOGE("encoder khong co input"); return e->NewStringUTF(""); }
    MNN::Tensor* encInput = encInputs.begin()->second;
    h->encoderNet->resizeTensor(encInput, {1, 3, SAM_INPUT_SIZE, SAM_INPUT_SIZE});
    h->encoderNet->resizeSession(h->encoderSession);

    MNN::Tensor hostEncIn(encInput, MNN::Tensor::CAFFE);
    // Feed RGB 0..255 thô (giả định graph --use-preprocess tự chuẩn hoá
    // bên trong — xem cảnh báo rủi ro đầu file).
    for (int y = 0; y < SAM_INPUT_SIZE; y++) for (int x = 0; x < SAM_INPUT_SIZE; x++) {
        const unsigned char* p = letterboxed.data() + ((size_t)y*SAM_INPUT_SIZE + x) * 3;
        for (int ch = 0; ch < 3; ch++)
            hostEncIn.host<float>()[(size_t)ch*SAM_INPUT_SIZE*SAM_INPUT_SIZE + y*SAM_INPUT_SIZE + x] = (float)p[ch];
    }
    encInput->copyFromHostTensor(&hostEncIn);
    h->encoderNet->runSession(h->encoderSession);

    auto encOutputs = h->encoderNet->getSessionOutputAll(h->encoderSession);
    if (encOutputs.empty()) { LOGE("encoder khong co output"); return e->NewStringUTF(""); }
    MNN::Tensor* embedTensor = encOutputs.begin()->second;
    MNN::Tensor hostEmbed(embedTensor, MNN::Tensor::CAFFE);
    embedTensor->copyToHostTensor(&hostEmbed);

    // ── Decoder ──
    auto decInputs = h->decoderNet->getSessionInputAll(h->decoderSession);
    // Tên input decoder ONNX chuẩn SAM (đã tra cứu xác nhận qua samexporter/
    // MobileSAM export script): image_embeddings, point_coords, point_labels,
    // mask_input, has_mask_input, orig_im_size. Tìm theo tên thay vì thứ tự
    // để tránh phụ thuộc convention thứ tự map không đảm bảo.
    auto findInput = [&](const std::string& name) -> MNN::Tensor* {
        for (auto& kv : decInputs) if (kv.first.find(name) != std::string::npos) return kv.second;
        return nullptr;
    };
    MNN::Tensor* tEmbed = findInput("image_embeddings");
    MNN::Tensor* tPointCoords = findInput("point_coords");
    MNN::Tensor* tPointLabels = findInput("point_labels");
    MNN::Tensor* tMaskInput = findInput("mask_input");
    MNN::Tensor* tHasMask = findInput("has_mask_input");
    MNN::Tensor* tOrigSize = findInput("orig_im_size");
    if (!tEmbed || !tPointCoords || !tPointLabels || !tMaskInput || !tHasMask || !tOrigSize) {
        LOGE("decoder thieu input mong doi — kiem tra lai ten input ONNX that (xem cmt dau file)");
        return e->NewStringUTF("");
    }

    MNN::Tensor hostEmbedIn(tEmbed, MNN::Tensor::CAFFE);
    std::memcpy(hostEmbedIn.host<float>(), hostEmbed.host<float>(), hostEmbed.elementSize() * sizeof(float));
    tEmbed->copyFromHostTensor(&hostEmbedIn);

    // Toạ độ click PHẢI theo hệ ẢNH GỐC (không phải 1024x1024) theo đúng
    // contract decoder chuẩn SAM.
    MNN::Tensor hostCoords(tPointCoords, MNN::Tensor::CAFFE);
    hostCoords.host<float>()[0] = clickX; hostCoords.host<float>()[1] = clickY;
    tPointCoords->copyFromHostTensor(&hostCoords);

    MNN::Tensor hostLabels(tPointLabels, MNN::Tensor::CAFFE);
    hostLabels.host<float>()[0] = 1.0f; // 1 = foreground click
    tPointLabels->copyFromHostTensor(&hostLabels);

    MNN::Tensor hostMaskIn(tMaskInput, MNN::Tensor::CAFFE);
    std::memset(hostMaskIn.host<float>(), 0, hostMaskIn.elementSize() * sizeof(float));
    tMaskInput->copyFromHostTensor(&hostMaskIn);

    MNN::Tensor hostHasMask(tHasMask, MNN::Tensor::CAFFE);
    hostHasMask.host<float>()[0] = 0.0f;
    tHasMask->copyFromHostTensor(&hostHasMask);

    MNN::Tensor hostOrigSize(tOrigSize, MNN::Tensor::CAFFE);
    hostOrigSize.host<float>()[0] = (float)origH; hostOrigSize.host<float>()[1] = (float)origW;
    tOrigSize->copyFromHostTensor(&hostOrigSize);

    h->decoderNet->runSession(h->decoderSession);

    auto decOutputs = h->decoderNet->getSessionOutputAll(h->decoderSession);
    MNN::Tensor* maskOut = nullptr;
    for (auto& kv : decOutputs) if (kv.first.find("mask") != std::string::npos && kv.first.find("iou") == std::string::npos) { maskOut = kv.second; break; }
    if (!maskOut) maskOut = decOutputs.begin()->second;
    MNN::Tensor hostMaskOut(maskOut, MNN::Tensor::CAFFE);
    maskOut->copyToHostTensor(&hostMaskOut);

    // Output là logit (dương = trong mask, âm = ngoài mask — quy ước chuẩn
    // SAM) kích thước [1,1,origH,origW] (decoder tự upscale về đúng
    // orig_im_size). Ghi ra PNG đen/trắng — CÙNG QUY ƯỚC buildMaskFile() ở
    // Kotlin (trắng = inpaint).
    std::vector<unsigned char> maskPng((size_t)origW * origH);
    const float* maskData = hostMaskOut.host<float>();
    for (int i = 0; i < origW * origH; i++) maskPng[i] = maskData[i] > 0.f ? 255 : 0;

    std::string outPath = j2s_ms(e, jOutMask);
    stbi_write_png(outPath.c_str(), origW, origH, 1, maskPng.data(), origW);
    LOGI("click-to-mask xong: %s (%dx%d)", outPath.c_str(), origW, origH);
    return e->NewStringUTF(outPath.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_mobileSamFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<MobileSamHandle*>(ptr);
}
