// YOLOv8-pose detect (thay MediaPipe Pose Landmarker — mục 19
// TECHNICAL_STATUS.md). Bám SÁT ĐÚNG pattern yolo_wrapper.cpp (cùng cách
// letterbox-resize tay + MNN::Interpreter/Session/Tensor, cùng lý do
// KHÔNG dùng MNN::CV::ImageProcess chưa kiểm chứng).
//
// TẠI SAO THAY MEDIAPIPE: MediaPipe Pose Landmarker vốn thiết kế cho 1
// người/khung (đã tra cứu xác nhận qua tài liệu + GitHub issue #5806 —
// "ảo giác" khớp sai khi nhiều người occlusion nhau). YOLOv8-pose là
// kiến trúc single-stage (không tách "detect người rồi crop-riêng-từng-
// người" như MediaPipe) — phù hợp hơn cho đúng cảnh khó nhất MangaLocal
// cần: nhiều người ôm/vật lộn/quần nhau.
//
// Output ONNX YOLOv8-pose (đã tra cứu xác nhận qua nhiều nguồn Ultralytics
// chính thức — KHÔNG đoán): shape [1, 56, numBoxes]. 56 = 4 (cx,cy,w,h) +
// 1 (conf) + 17*3 (x,y,visibility mỗi keypoint COCO-17 CHUẨN ULTRALYTICS,
// thứ tự: nose,left_eye,right_eye,left_ear,right_ear,left_shoulder,
// right_shoulder,left_elbow,right_elbow,left_wrist,right_wrist,left_hip,
// right_hip,left_knee,right_knee,left_ankle,right_ankle). Toạ độ box/keypoint
// đã ở pixel-space theo input 640x640 (Ultralytics export bake sẵn decode,
// KHÔNG cần sigmoid thêm) — cùng quy ước "không sigmoid" mà yolo_wrapper.cpp
// đã áp dụng cho box detect, giữ nhất quán trong cùng dự án.
//
// Việc map COCO-17 -> OpenPose-18 (thêm điểm "neck" = trung điểm 2 vai) làm
// bên Kotlin (PoseExtractor.kt), KHÔNG làm ở native — giữ đúng chỗ đang có
// logic mapping tương tự (33 điểm MediaPipe -> 18 điểm cũng làm ở Kotlin),
// một chỗ duy nhất, dễ so sánh/sửa.
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cstring>
#include <memory>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
}

#define TAG "YOLOv8Pose_MNN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static const int NUM_KEYPOINTS = 17;

struct PoseDetection {
    float x1, y1, x2, y2, conf; // box (0..1, normalized theo ảnh gốc)
    float kp[NUM_KEYPOINTS][3]; // x, y (0..1 normalized), visibility (0..1)
};

struct YoloPoseWrapper {
    std::shared_ptr<MNN::Interpreter> net;
    MNN::Session* session = nullptr;
    int inputSize = 640; // chuẩn Ultralytics cho pose (khác 320 của yolo_wrapper.cpp
                          // dùng cho detect nhanh — pose cần độ phân giải cao hơn để
                          // giữ độ chính xác keypoint, đúng khuyến nghị Ultralytics)
    bool ok = false;

    YoloPoseWrapper(const std::string& modelDir) {
        std::string modelPath = modelDir + "/yolov8_pose.mnn";
        net.reset(MNN::Interpreter::createFromFile(modelPath.c_str()));
        if (!net) { LOGE("khong doc duoc model: %s", modelPath.c_str()); return; }

        MNN::ScheduleConfig config;
        config.type = MNN_FORWARD_OPENCL;
        config.numThread = 4;
        MNN::BackendConfig backendConfig;
        backendConfig.precision = MNN::BackendConfig::Precision_Low;
        config.backendConfig = &backendConfig;

        session = net->createSession(config);
        if (!session) {
            LOGE("createSession OpenCL fail, roi ve CPU");
            config.type = MNN_FORWARD_CPU;
            session = net->createSession(config);
        }
        if (!session) { LOGE("createSession CPU cung fail"); return; }
        ok = true;
        LOGI("YOLOv8-pose (MNN) nap OK: %s", modelPath.c_str());
    }

    // Giống hệt letterbox() trong yolo_wrapper.cpp — copy nguyên logic, cố
    // ý KHÔNG factor ra file dùng chung để tránh rủi ro sửa 1 chỗ quên chỗ
    // kia (2 struct độc lập, inputSize khác nhau: 640 vs 320).
    void letterbox(const unsigned char* src, int w, int h, std::vector<unsigned char>& dst,
                   float& scale, int& padW, int& padH) {
        scale = std::min((float)inputSize / w, (float)inputSize / h);
        int newW = std::max(1, (int)(w * scale)), newH = std::max(1, (int)(h * scale));
        padW = inputSize - newW; padH = inputSize - newH;

        dst.assign((size_t)inputSize * inputSize * 3, 114);
        int offX = padW / 2, offY = padH / 2;
        for (int y = 0; y < newH; y++) {
            int srcY = std::min(h - 1, (int)(y / scale));
            for (int x = 0; x < newW; x++) {
                int srcX = std::min(w - 1, (int)(x / scale));
                const unsigned char* sp = src + ((size_t)srcY * w + srcX) * 3;
                unsigned char* dp = dst.data() + ((size_t)(y + offY) * inputSize + (x + offX)) * 3;
                dp[0] = sp[0]; dp[1] = sp[1]; dp[2] = sp[2];
            }
        }
    }

    std::vector<PoseDetection> detect(const std::string& imagePath, float confThresh, float iouThresh) {
        std::vector<PoseDetection> results;
        if (!ok) { LOGE("detect goi khi chua init xong"); return results; }

        int w, h, c;
        unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("load fail: %s", imagePath.c_str()); return results; }

        float scale; int padW, padH;
        std::vector<unsigned char> letterboxed;
        letterbox(data, w, h, letterboxed, scale, padW, padH);
        stbi_image_free(data);

        auto inputs = net->getSessionInputAll(session);
        if (inputs.empty()) { LOGE("model khong co input tensor"); return results; }
        MNN::Tensor* input = inputs.begin()->second;
        net->resizeTensor(input, {1, 3, inputSize, inputSize});
        net->resizeSession(session);

        MNN::Tensor hostIn(input, MNN::Tensor::CAFFE);
        for (int y = 0; y < inputSize; y++) for (int x = 0; x < inputSize; x++) {
            const unsigned char* p = letterboxed.data() + ((size_t)y*inputSize + x) * 3;
            for (int ch = 0; ch < 3; ch++)
                hostIn.host<float>()[(size_t)ch*inputSize*inputSize + y*inputSize + x] = p[ch] / 255.f;
        }
        input->copyFromHostTensor(&hostIn);

        net->runSession(session);

        auto outputs = net->getSessionOutputAll(session);
        if (outputs.empty()) { LOGE("model khong co output tensor"); return results; }
        MNN::Tensor* output = outputs.begin()->second;
        MNN::Tensor hostOut(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&hostOut);

        auto shape = hostOut.shape();
        if (shape.size() != 3) { LOGE("output shape khong nhu ky vong: rank=%zu", shape.size()); return results; }
        int numAttrs = shape[1]; // ky vong 56 = 4+1+17*3
        int numBoxes = shape[2];
        if (numAttrs != 4 + 1 + NUM_KEYPOINTS * 3) {
            LOGE("output numAttrs=%d khac ky vong %d — model .mnn co dung yolov8-pose 17-keypoint khong?",
                 numAttrs, 4 + 1 + NUM_KEYPOINTS * 3);
            // Vẫn thử đọc tiếp thay vì bỏ hẳn — có thể chỉ lệch nhẹ, nhưng
            // CẢNH BÁO RÕ để dễ debug lúc build-test thật thay vì fail âm thầm.
        }
        const float* raw = hostOut.host<float>();
        int offX = padW / 2, offY = padH / 2;

        for (int i = 0; i < numBoxes; i++) {
            float cx = raw[0*numBoxes + i];
            float cy = raw[1*numBoxes + i];
            float bw = raw[2*numBoxes + i];
            float bh = raw[3*numBoxes + i];
            float conf = raw[4*numBoxes + i];
            if (conf < confThresh) continue;

            PoseDetection d{};
            float x1 = (cx - bw/2 - offX) / scale;
            float y1 = (cy - bh/2 - offY) / scale;
            float x2 = (cx + bw/2 - offX) / scale;
            float y2 = (cy + bh/2 - offY) / scale;
            d.x1 = std::clamp(x1/w, 0.f, 1.f); d.y1 = std::clamp(y1/h, 0.f, 1.f);
            d.x2 = std::clamp(x2/w, 0.f, 1.f); d.y2 = std::clamp(y2/h, 0.f, 1.f);
            d.conf = conf;

            for (int k = 0; k < NUM_KEYPOINTS; k++) {
                float kx = raw[(5 + k*3 + 0)*numBoxes + i];
                float ky = raw[(5 + k*3 + 1)*numBoxes + i];
                float kv = raw[(5 + k*3 + 2)*numBoxes + i];
                d.kp[k][0] = std::clamp((kx - offX) / scale / w, 0.f, 1.f);
                d.kp[k][1] = std::clamp((ky - offY) / scale / h, 0.f, 1.f);
                d.kp[k][2] = kv;
            }
            results.push_back(d);
        }

        // NMS — cùng heuristic overlap-area đã dùng trong yolo_wrapper.cpp
        // (không phải IoU chuẩn, nhưng ĐÃ CHỨNG MINH đủ dùng ở chỗ đó, giữ
        // nhất quán thay vì viết IoU khác trong cùng dự án).
        std::sort(results.begin(), results.end(), [](auto& a, auto& b) { return a.conf > b.conf; });
        std::vector<PoseDetection> filtered;
        for (auto& d : results) {
            bool overlap = false;
            for (auto& f : filtered) {
                float ox = std::max(0.f, std::min(d.x2,f.x2) - std::max(d.x1,f.x1));
                float oy = std::max(0.f, std::min(d.y2,f.y2) - std::max(d.y1,f.y1));
                float areaD = (d.x2-d.x1)*(d.y2-d.y1);
                if (areaD > 0 && ox * oy > iouThresh * areaD) { overlap = true; break; }
            }
            if (!overlap) filtered.push_back(d);
            if (filtered.size() >= 8) break; // đủ cho cảnh đông nhân vật nhất
        }

        LOGI("detected %zu people (pose)", filtered.size());
        return filtered;
    }

    ~YoloPoseWrapper() {
        if (session && net) net->releaseSession(session);
    }
};

static std::string j2s_yp(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_yoloPoseInit(JNIEnv* e, jobject, jstring jDir) {
    auto* w = new YoloPoseWrapper(j2s_yp(e, jDir));
    if (!w->ok) { delete w; return 0; }
    return reinterpret_cast<jlong>(w);
}

// Trả về mảng float phẳng: mỗi người 56 giá trị liên tiếp
// [x1,y1,x2,y2,conf, kp0_x,kp0_y,kp0_vis, kp1_x,kp1_y,kp1_vis, ..., kp16_x,kp16_y,kp16_vis]
// Kotlin (PoseExtractor.kt) tự cắt theo block 56 và map COCO-17 -> OpenPose-18.
extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_mangalocal_pipeline_NativeBridge_yoloPoseDetect(
    JNIEnv* e, jobject, jlong ptr, jstring jImg, jfloat confThresh, jfloat iouThresh) {
    if (!ptr) return e->NewFloatArray(0);
    auto* yolo = reinterpret_cast<YoloPoseWrapper*>(ptr);
    auto dets = yolo->detect(j2s_yp(e, jImg), confThresh, iouThresh);

    std::vector<float> flat;
    flat.reserve(dets.size() * (5 + NUM_KEYPOINTS * 3));
    for (auto& d : dets) {
        flat.push_back(d.x1); flat.push_back(d.y1); flat.push_back(d.x2); flat.push_back(d.y2); flat.push_back(d.conf);
        for (int k = 0; k < NUM_KEYPOINTS; k++) {
            flat.push_back(d.kp[k][0]); flat.push_back(d.kp[k][1]); flat.push_back(d.kp[k][2]);
        }
    }
    jfloatArray result = e->NewFloatArray((jsize)flat.size());
    if (!flat.empty()) e->SetFloatArrayRegion(result, 0, (jsize)flat.size(), flat.data());
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_yoloPoseFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<YoloPoseWrapper*>(ptr);
}
