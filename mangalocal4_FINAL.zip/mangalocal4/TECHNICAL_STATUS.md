# MangaLocal — Trạng thái kỹ thuật (cập nhật liên tục)

> File này PHẢI được cập nhật sau mỗi lần: sửa code, đổi quyết định kỹ
> thuật, hoặc phát hiện thông tin mới làm thay đổi giả định trước đó.
> Mục tiêu: đọc file này là đủ để làm việc tiếp mà không lặp lại lỗi cũ
> hay quên mất quyết định đã chốt.

---

## 1. Kiến trúc tổng quan (đã chốt)

| Thành phần | Engine | Trạng thái |
|---|---|---|
| LLM (parse truyện → kịch bản panel) | **MNN-LLM** (thay llama.cpp) | Hoạt động, đã port |
| Sinh ảnh SD1.5 (CPU/OpenCL) | **MNN-Diffusion**, port từ local-dream | Hoạt động, đã port |
| Sinh ảnh SDXL/Anima | — | **BỎ HẲN** — QNN-only trong local-dream, không có bản CPU, không có tiền lệ MNN nào |
| Upscale ảnh | MNN (ESRGAN) | Hoạt động, viết mới bằng MNN::Interpreter core API |
| Tách bubble thoại | MNN (YOLOv8n) | Hoạt động, viết mới |
| Nhất quán nhân vật (ảnh) | IP-Adapter (re-export UNet) | Hoạt động (Phase đầu), xem mục 4 |
| Tư thế nhiều người (tránh dính người) | ControlNet-OpenPose (cùng UNet re-export) | Hoạt động (preset cứng), cần cải thiện — xem mục 6 |
| LoRA nhân vật (ảnh) | Merge offline vào .mnn | Hoạt động, convert on-device được (nhẹ, không phải training) |
| LoRA (chữ, LLM) | MNN-LLM `apply_lora()` — **runtime, KHÔNG cần merge** | Chưa dùng (MangaLocal chưa cần LoRA cho LLM) |

**Nhắc lại quan trọng — dễ nhầm nhất:** MNN-LLM hỗ trợ đổi LoRA lúc chạy (`apply_lora`), nhưng **MNN-Diffusion (ảnh) không có cơ chế này** — LoRA ảnh vẫn phải merge chết vào `.mnn` lúc convert. 2 cơ chế khác hẳn nhau, đừng lẫn.

---

## 2. Cấu trúc file (jni/)

```
jni/
├── CMakeLists.txt
├── jni_bridge.cpp              — LLM (MNN-LLM) + JNI helpers dùng chung
├── esrgan_wrapper.cpp          — Upscale, MNN::Interpreter thuần
├── yolo_wrapper.cpp            — Detect bubble, MNN::Interpreter thuần
├── mnn_diffusion_pipeline.cpp  — SD1.5 CPU/OpenCL thường (không reference/pose)
├── sd_model_converter.cpp      — Convert/merge LoRA on-device (generateMNNModels)
├── ip_adapter.cpp              — Pipeline augmented: IP-Adapter + ControlNet-Pose
├── stb_impl.cpp                — DUY NHẤT nơi build STB_IMAGE_IMPLEMENTATION (tránh duplicate symbol)
└── sd_engine/                  — Port THẬT từ local-dream (xem NOTICE_local-dream.md)
    ├── Pipeline.hpp, PipelineSd15Cpu.hpp  (ĐÃ SỬA — xem mục 3)
    ├── TextEncoder.hpp, SDUtils.hpp (ĐÃ SỬA — bỏ STB_IMPLEMENTATION), ...
    ├── SafeTensor2MNN.hpp, SDStructure.hpp, LoraMapping.hpp (convert tool)
    └── stb_image*.h (chỉ khai báo, implementation ở stb_impl.cpp)
```

---

## 3. Các chỗ ĐÃ SỬA so với bản gốc local-dream (bắt buộc ghi vì lý do CC BY-NC)

1. **`PipelineSd15Cpu.hpp`**: đổi `unet_interpreter_`/`unet_session_` từ `private` → `protected`; thêm hook ảo `onBeforeUnetRun()` gọi ngay trước `runSession()`. Mục đích: cho phép `PipelineSd15CpuAugmented` (trong `ip_adapter.cpp`) nạp thêm tensor input phụ mà không phải chép lại toàn bộ file.
2. **`SDUtils.hpp`**: bỏ 3 dòng `#define STB_..._IMPLEMENTATION` (chuyển sang `stb_impl.cpp` riêng) — vì local-dream gốc chỉ có 1 file `.cpp` include nó, còn MangaLocal có nhiều file `.cpp` cùng include, để nguyên sẽ lỗi duplicate symbol lúc link.

Ngoài 2 chỗ trên, mọi file khác trong `sd_engine/` giữ nguyên văn.

---

## 4. Hệ thống nhất quán nhân vật (IP-Adapter + ControlNet-Pose)

### Thiết kế UNet augmented (tự thiết kế, KHÔNG đoán API người khác)
- Input thêm: `ip_image_embeds` (shape THẬT chỉ biết sau khi chạy `tools/export_ipa_controlnet_unet.py` — script tự dò, không hardcode số), `control_hint` [1,3,512,512] RGB khung xương.
- Export bằng `diffusers` (API thật, đã xác nhận): `pipe.load_ip_adapter(...)`, `ControlNetModel`, `down_block_additional_residuals`/`mid_block_additional_residual`/`added_cond_kwargs={"image_embeds":[...]}`.
- Convert ONNX → `.mnn` bằng `MNNConvert` (thủ công, chưa tự động hoá trong build.yml).

### Thư viện tư thế — ĐÃ SỬA, không còn hardcode, giờ trích NGAY TRÊN ĐIỆN THOẠI
- **Trước:** 2 preset toạ độ tự đoán trong C++, chưa kiểm nghiệm.
- **Giờ (ĐƯỜNG CHÍNH — không cần máy tính):** `PoseExtractor.kt` dùng **MediaPipe Tasks Vision Android SDK thật** (`com.google.mediapipe:tasks-vision:0.10.18`, xác nhận qua tài liệu chính thức `ai.google.dev/edge/mediapipe`) — chọn ảnh/video từ thư viện điện thoại ngay trong `PoseEditorScreen.kt`, tự trích, tự gắn nhãn góc, tự lọc frame trùng, lưu thẳng vào `pose_library.json`. Hoàn toàn offline, không Python, không máy tính.
- **`tools/extract_pose_library.py` (Python) — GIỜ LÀ ĐƯỜNG PHỤ**, dùng khi muốn xử lý hàng loạt nhiều video cùng lúc trên máy tính (nhanh hơn cho khối lượng lớn). 2 bên dùng CHUNG 1 mapping 33→18 điểm + 1 heuristic ước lượng góc — **sửa 1 bên phải sửa cả 2 bên** (đã ghi chú rõ trong cả 2 file).
- **Lọc frame trùng (mới, chỉ có ở bản Android)**: `PoseExtractor.extractFromVideo()` so khoảng cách Euclid trung bình giữa khớp frame hiện tại và frame trước, bỏ qua nếu quá giống — giảm nhiễu, giảm số biến thể gần như y hệt nhau.
- **Nhãn góc nhìn tự động**: ước lượng từ chênh lệch z giữa 2 vai — heuristic thô, không phải model chuyên dụng.
- **z-order thật**: MediaPipe trả về `z` (giá trị càng nhỏ càng gần camera — xác nhận qua tài liệu chính thức). `renderSkeletons()` (C++) sắp người theo z trung bình trước khi vẽ.
- **CHƯA LÀM XONG**: vẫn cần người dùng tự tải model `pose_landmarker_heavy.task` đặt vào `assets/` trước khi build (MediaPipe không tự tải model qua mạng lúc runtime trong thiết lập hiện tại) — MỘT LẦN duy nhất, không phải mỗi lần dùng.
- **CHƯA TEST**: cả `PoseExtractor.kt` lẫn UI chọn media — chưa build/chạy thử trên thiết bị thật.

### Vai trò 3 thành phần khi sinh 1 panel có nhân vật (chiến lược đã thống nhất)
- Khung xương (ControlNet) → tư thế/vị trí.
- LoRA nhân vật → nhận diện khuôn mặt + tỷ lệ vóc dáng (bao gồm theo độ tuổi nếu LoRA train đúng).
- Prompt → CHỈ còn biểu cảm/cảm xúc (tận dụng tối đa 77 token CLIP, không lãng phí vào mô tả ngoại hình/tư thế đã có LoRA+khung xương lo).

---

## 5. Hệ thống Settings — 2 tầng (đã chốt kiến trúc, CHƯA VIẾT UI)

**Tầng chung (GenerationSettings)**: áp dụng mặc định cho mọi ảnh trong story — model, LoRA addon (chất lượng chung, KHÔNG cho override per-ảnh vì lý do kỹ thuật ở mục 5.1), steps/cfg mặc định.

**Tầng riêng từng ảnh (PanelOverrideSettings — CHƯA TẠO)**: override cho 1 ảnh cụ thể trong gallery preview trước upscale. Ưu tiên tầng riêng > tầng chung khi có giá trị khác null. Gồm:
- Negative prompt riêng (LLM gợi ý tự động HOẶC người dùng tự sửa)
- Chọn nhân vật (dropdown, override tự-nhận-diện từ LLMParser)
- **UI vẽ/kéo khung xương riêng cho ảnh đó** (quan trọng nhất, ưu tiên làm trước)
- Steps/CFG/seed riêng

### 5.1. Vì sao LoRA addon KHÔNG vào được tầng riêng từng ảnh
Đã giải thích ở mục 1 — LoRA ảnh phải merge chết lúc convert, không bật/tắt lúc chạy. → LoRA addon **chỉ có ở tầng chung**, áp dụng cho toàn bộ model đang dùng, không đổi được per-ảnh trừ khi có sẵn nhiều bộ `.mnn` khác nhau để CHỌN (không phải bật/tắt cờ).

**CHƯA VIẾT**: cả 2 tầng Kotlin data class + UI Compose. Việc tiếp theo.

---

## 6. Việc đang xếp hàng, thứ tự ưu tiên (theo thảo luận gần nhất)

1. **UI vẽ/kéo khung xương + trích tư thế từ ảnh/video (Compose Canvas + MediaPipe Android)** — **ĐÃ VIẾT** (`PoseEditorScreen.kt` + `PoseExtractor.kt`, route `"pose_editor"`, vào từ nút trong `SettingsScreen.kt`). Gồm 2 phần: (a) chọn ảnh/video từ thư viện → MediaPipe tự trích + gắn nhãn góc + lọc trùng → lưu vào `pose_library.json`; (b) kéo-thả tay từng khớp để sửa tư thế lỗi. **CHƯA TEST trên thiết bị thật**. **CHƯA CÓ**: truy cập per-ảnh từ gallery — sẽ nối khi làm Settings 2 tầng (mục 2).
2. **Settings 2 tầng (Kotlin data class + UI)** — **ĐÃ VIẾT**. `PanelOverrideSettings` (Models.kt) + `MangaPipeline.resolveEffective()` (hợp nhất 2 tầng, field override không null thì ưu tiên) + UI trong `GalleryReviewScreen.kt` (khối "⚙️ Cài đặt riêng ảnh này"). Không có field LoRA (đúng quyết định đã chốt).
   - **NHÂN TIỆN SỬA LUÔN 1 LỖ HỔNG CŨ**: trước đây "model theo nhân vật đã convert riêng" (`StoryManager.registerConvertedModel`) đã VIẾT nhưng **chưa từng được GỌI** khi sinh ảnh — `generatePanels`/`regeneratePanel` luôn dùng `settings.sdModelId` cố định. Giờ đã nối qua `resolveModelIdForCharacter()`: chọn nhân vật (override hoặc tự nhận diện) → tự tìm model convert riêng cho nhân vật đó nếu có → dùng model gốc nếu chưa convert.
   - **Đã gộp thêm**: prompt SD giờ sửa tay được ngay trong cùng khối "Cài đặt riêng" (trước tách riêng 1 nút "Sửa prompt"), thêm `width`/`height`/`seed` vào `PanelOverrideSettings` — TẤT CẢ thông số sinh ảnh (trừ LoRA) giờ chỉnh tay được per-ảnh. `GalleryReviewScreen.kt` cũng hiện **kịch bản LLM đầy đủ** (mô tả/hành động/bối cảnh/tâm trạng/góc máy/nhân vật) trước khi người dùng quyết định sửa gì.
   - **Xác nhận đã đúng từ trước, không cần sửa**: UI vẽ khung xương LUÔN lưu vào `pose_library.json` dùng chung (không có đường lưu "chỉ riêng ảnh này") — nghĩa là khung xương sửa cho 1 ảnh tự động dùng lại được cho ảnh khác, đúng yêu cầu "đồng bộ vào kho".
   - **Hạn chế UX nhỏ**: danh sách pose template trong `GalleryReviewScreen` chỉ đọc 1 lần lúc mở sheet (`remember`), nếu vừa tạo template mới bên `PoseEditorScreen` rồi quay lại thì KHÔNG tự refresh — phải đóng/mở lại sheet.

## 7. Rà soát toàn chuỗi SD1.5+ControlNet-Pose+IP-Adapter (đợt kiểm tra chéo)

Đã kiểm tra chữ ký JNI khớp C++↔Kotlin, thứ tự tham số tại các call site, schema JSON khớp Python↔C++↔Kotlin, CMakeLists đủ include/nguồn.

**Bug tìm được và đã sửa**: `build.yml` vẫn clone `llama.cpp` dù đã bỏ hẳn nhiều lượt trước (chuyển sang MNN-LLM) — xoá, bump cache key `tp-mnn-v4`.

Không phát hiện thêm lỗi khớp nối nào khác trong đợt rà soát này.

Đã kiểm tra kỹ (web search, nhiều nguồn): **Flux-schnell** (vẫn 12B, chỉ ít bước hơn, không nhỏ hơn), **Flux.1-lite** (8B, vẫn quá nặng), **SD3.5 Medium** (2.5B, nặng ngang SDXL — đã loại vì không có bản CPU/MNN), **Hunyuan-DiT** (1.5B + text encoder mT5 1.6B riêng, **không tìm được bất kỳ bằng chứng nào** về tối ưu MNN/ncnn dù tra 2 lần, ControlNet còn ghi "chưa phát hành"). Các model này CÓ giải phẫu tốt hơn SD1.5 thật (xác nhận), nhưng không có model nào có tiền lệ chạy qua MNN trên điện thoại. → Giữ nguyên hướng SD1.5 + IP-Adapter + ControlNet-Pose, không đổi nền tảng.
3. **Negative prompt tự động qua LLM** — **ĐÃ XONG** (rà lại thấy phần lõi thật ra đã có sẵn từ trước — `LLMParser.buildPrompt()` vốn đã sinh negative cùng lúc với positive — nhưng 2 chỗ sau CHƯA xong, giờ đã sửa):
   - `LLMParser.promptTemplate()`: thêm `negativeRiskHints()` — gợi ý LLM các rủi ro CỤ THỂ theo thuộc tính scene (≥2 nhân vật → dễ dính/thừa chi; close-up → dễ lỗi ngón/mắt; mood tối → SD hay kéo sáng bù; wide-shot → nhân vật nền dễ biến dạng) thay vì để LLM tự bịa 1 câu negative chung chung không ăn khớp scene.
   - `GalleryReviewScreen.kt`: ô "negative prompt riêng" TRƯỚC luôn khởi tạo rỗng với placeholder sai ("để trống = dùng chung" — thực ra fallback là `panel.negativePrompt` do LLM sinh riêng, không phải "chung"). Giờ pre-fill đúng gợi ý LLM để người dùng THẤY và sửa trực tiếp; logic lưu override cũng sửa lại: chỉ collapse về `null` (không đóng băng override) khi giá trị y hệt gợi ý gốc, còn nếu user xoá trắng cố ý thì lưu `""` = họ muốn không có negative gì cả (khác với "không sửa gì").
4. **Depth ControlNet (multi-ControlNet)** — thêm nhánh điều kiện độ sâu để xử lý đúng "ai trước ai sau" khi nhân vật đan vào nhau (bổ sung, không thay z-order 2D đã có). Cần re-export UNet LẦN NỮA (thêm 1 input). CHƯA BẮT ĐẦU.
5. **Nâng cấp DWPose** (chính xác hơn MediaPipe cho x,y) nếu z-order + MediaPipe chưa đủ tốt sau khi test thật. CHƯA CẦN THIẾT NGAY.
6. **LLM orchestration (chọn pose template + prompt nhấn cảm xúc)** — **ĐÃ VIẾT MỘT PHẦN** (không phải toàn bộ ý ban đầu — xem giới hạn dưới):
   - `LLMParser.buildPrompt()` giờ nhận thêm `availablePoseTemplates: List<String>` (danh sách tên THẬT lấy từ `StoryManager.listPoseTemplateNames()` — tức `pose_library.json` thật của user, không phải tên bịa), trả về `PromptResult(positive, negative, poseTemplate, poseAngle)` thay vì `Pair<String,String>` cũ.
   - LLM được yêu cầu chọn 1 tên KHỚP CHÍNH XÁC trong danh sách hoặc `"none"` — `extractPrompts()` validate lại (`rawPose in availablePoseTemplates`), không tin thẳng, chống LLM bịa tên không tồn tại.
   - `Panel` có thêm `suggestedPoseTemplate`/`suggestedPoseAngle`; `MangaPipeline.resolveEffective()` đổi thứ tự ưu tiên: override tay > gợi ý LLM (đã validate) > `guessPoseTemplate()` (dò substring trong tên thật, thay vì hardcode `"two_hugging"/"single_standing"` như TRƯỚC — 2 tên đó **có thể không hề tồn tại** nếu user tự trích pose từ ảnh/video riêng, đây là bug thật đã sửa luôn).
   - **Đã xác nhận qua đọc `ip_adapter.cpp`**: `poseTemplate` rỗng/không khớp KHÔNG làm tắt ControlNet-Pose — rơi vào `pose_templates::fallbackStanding()` cứng (dáng đứng 1 người). Đã sửa comment/UI cho đúng thực tế này (trước định ghi nhầm là "bỏ qua hẳn").
   - `GalleryReviewScreen.kt` hiện thêm dòng "LLM gợi ý: ... (góc: ...)" để người dùng thấy được gợi ý thật thay vì hộp đen "Tự động".
   - Positive prompt: thêm yêu cầu LLM viết chi tiết biểu cảm/ngôn ngữ cơ thể cụ thể khớp mood (vd "clenched jaw, narrowed eyes" thay vì chỉ ghi từ "tense").
   - **GIỚI HẠN — CHƯA LÀM**: "tự chọn LoRA" trong ý ban đầu KHÔNG cần thêm việc gì mới — cơ chế chọn model/LoRA theo nhân vật (`resolveModelIdForCharacter`) đã tự động từ trước (mục 6.2), không liên quan đến bước LLM này. Việc thật sự CHƯA LÀM: chưa test trên thiết bị thật xem LLM 1-2B chạy local có đủ khả năng tuân theo đúng schema JSON mở rộng (4 field) hay không — rủi ro model nhỏ trả JSON sai định dạng cao hơn khi thêm field, `extractPrompts()` có try/catch fallback nhưng fallback đó bỏ qua hoàn toàn pose suggestion.

---

## 8. Việc đã có nhưng CHƯA test/xác nhận trên thiết bị thật (rủi ro còn treo)

- **MỌI THỨ Ở MỤC NÀY GIỜ CHẠY ĐƯỢC KHÔNG CẦN PC** — xem workflow mới `.github/workflows/prepare_models.yml` (bấm "Run workflow" từ tab Actions trên GitHub, mở được bằng trình duyệt điện thoại, chạy hoàn toàn trên máy ảo cloud). Dùng `pip install MNN` để có sẵn `mnnconvert` — KHÔNG cần build MNNConverter từ C++ nữa.
- **Đổi kiến trúc quan trọng**: bỏ cơ chế "khung .mnn + patch trọng số" của local-dream (không có script gốc tạo khung, không tái tạo chính xác được) — thay bằng `tools/export_sd15_base.py`, export THẲNG từ `diffusers` sang ONNX rồi `.mnn`, tự đặt tên tensor khớp `PipelineSd15Cpu.hpp`. LoRA giờ merge lúc export (`pipe.fuse_lora()`, API thật của diffusers) thay vì convert on-device — **`sd_model_converter.cpp`/`SafeTensor2MNN.hpp` trở thành ĐƯỜNG PHỤ**, không bắt buộc nữa.
- Model MediaPipe `pose_landmarker_heavy.task` — **build.yml giờ TỰ TẢI**, không cần chuẩn bị tay.
- Tên target CMake `llm` (link MNN-LLM) — suy ra từ quy ước, chưa chạy build thật để xác nhận.
- Chữ ký chính xác `Llm::response()` (số tham số) — chưa build thật.
- **RỦI RO MỚI, CHƯA KIỂM CHỨNG**: `export_sd15_base.py` tách embedding CLIP (token_emb.bin/pos_emb.bin) dựa trên SUY LUẬN từ tên file trong `model_manifest.json`, KHÔNG có script gốc local-dream để đối chiếu shape/thứ tự cộng — có khả năng sai, cần build-test thật.
- Shape thật `ip_image_embeds` — chỉ biết sau khi CHẠY `export_ipa_controlnet_unet.py`.
- `nlohmann/json` header path (`single_include` vs `include`) — có bước in log chẩn đoán trong `build.yml`, chưa xem log thật.

---

## 9. Việc UI Kotlin còn nợ (chưa đụng tới)

- `SettingsScreen.kt` — chưa cập nhật cho hệ thống model/manifest mới (vẫn còn field cũ `sdModelPath`/`loraPath` trên UI dù đã deprecated).
- `consistencyStrength` slider — hiện KHÔNG có tác dụng (IP-Adapter scale cố định = 1.0 lúc export Python), cần thêm `ip_scale` làm input runtime nếu muốn chỉnh được.
- Chưa có UI thêm/quản lý LoRA addon (chất lượng chung) tách biệt UI LoRA nhân vật.
- Chưa có UI xuất dataset (ảnh+caption) để train LoRA trên PC.

---

## 10. Bản quyền

Xem `NOTICE_local-dream.md` — CC BY-NC 4.0, xác nhận MangaLocal miễn phí 100% (điều kiện bắt buộc để hợp lệ dùng code local-dream).

---

## 11. Nghiên cứu model thay thế SD1.5 — đã tra, KHÔNG áp dụng được (tránh hỏi lại)

Đã kiểm tra kỹ (web search, nhiều nguồn): **Flux-schnell** (vẫn 12B, chỉ ít bước hơn, không nhỏ hơn), **Flux.1-lite** (8B, vẫn quá nặng), **SD3.5 Medium** (2.5B, nặng ngang SDXL — đã loại vì không có bản CPU/MNN), **Hunyuan-DiT** (1.5B + text encoder mT5 1.6B riêng, **không tìm được bất kỳ bằng chứng nào** về tối ưu MNN/ncnn dù tra 2 lần, ControlNet còn ghi "chưa phát hành"). Các model này CÓ giải phẫu tốt hơn SD1.5 thật (xác nhận), nhưng không có model nào có tiền lệ chạy qua MNN trên điện thoại. → Giữ nguyên hướng SD1.5 + IP-Adapter + ControlNet-Pose, không đổi nền tảng.

---

## 12. Giới hạn kiến trúc đã biết — CHỈ 1 nhân vật được neo danh tính mỗi panel

**Phát hiện khi rà lại mục 6 (LLM orchestration)**: pose skeleton hỗ trợ vẽ NHIỀU người/panel (đã có sẵn), nhưng danh tính hình ảnh (IP-Adapter reference HOẶC LoRA-merge-riêng) thì KHÔNG — 2 lý do đứt gãy, đã xác nhận đọc code:

1. `pose_templates::Skeleton` (ip_adapter.cpp) chỉ có toạ độ khớp xương, KHÔNG có trường tên nhân vật — `PoseVariant.people` là 1 danh sách người vô danh, không biết "người thứ mấy trong khung xương" là ai.
2. UNet augmented chỉ nhận **đúng 1** input `ip_image_embeds` — 1 lần sinh ảnh chỉ mang được 1 danh tính hình ảnh. `MangaPipeline.resolveEffective()` cũng chỉ chọn 1 `characterName` (mặc định = người đầu tiên trong `scene.characters`, đổi được tay qua chip "nhân vật" trong `GalleryReviewScreen` — chip này ĐÃ CÓ SẴN từ trước, không phải mới). LoRA-merge-riêng-per-nhân-vật cũng vậy — `imagePipeline.loadSD()` chỉ load được 1 model/lần.

**Hệ quả**: panel có 2+ nhân vật → chỉ 1 người được neo ngoại hình nhất quán; người còn lại chỉ có mô tả chữ (`anchorPrompt`), ngoại hình có thể trôi giữa các panel.

**Đã hỏi user hướng xử lý — user chọn "không có preference" (để Claude tự quyết)**. Quyết định: **CHƯA sửa phần native/re-export** — lý do: mục 8 đang có nhiều rủi ro CHƯA KIỂM CHỨNG treo sẵn (build chưa chạy lần nào thật), thêm phức tạp native trước khi build-test lần đầu là rủi ro chồng rủi ro, đi ngược nguyên tắc "không đề xuất giải pháp chưa kiểm chứng" đã thống nhất ở mục 8 gốc. Việc ĐÃ LÀM ngay (rẻ, không đụng native):
- Thêm dòng cảnh báo rõ trong `GalleryReviewScreen.kt` cạnh chip chọn "nhân vật": nói rõ ĐÂY LÀ chọn ai được neo danh tính (không phải chọn ai xuất hiện), người khác trong cảnh KHÔNG được neo — để user hiểu đúng thay vì tưởng chip đó chỉ đổi tên hiển thị.

**2 hướng CHƯA LÀM, còn treo, cần bàn lại sau khi build lần đầu ổn định**:
- **(a) 2 lượt sinh + inpaint**: neo nhân vật A cả ảnh, inpaint riêng vùng khung xương của B bằng ảnh neo của B. Không cần re-export UNet, dùng lại pipeline hiện có, nhưng tốn ~gấp đôi thời gian/nhiệt mỗi panel đa nhân vật, và cần viết thêm logic mask theo bounding-box khung xương (chưa viết).
- **(b) Multi-identity thật trong 1 lượt**: cần re-export UNet lần nữa + tự thiết kế logic gán embedding theo vùng không gian khớp xương. Mạnh nhất nhưng KHÔNG có tiền lệ MNN mobile nào tìm được để đối chiếu — rủi ro kỹ thuật thật sự, không phải chỉ rủi ro build.

**CẬP NHẬT (rà lại sau câu hỏi "chả lẽ cả 2 không chơi LoRA được sao")**: user chỉ ra đúng — kiểm tra lại thấy `sdConvertModel`/`convertAndRegisterModel` (StoryManager) **đã nhận sẵn `List<String> loraFiles` + `List<Float> loraWeights`** — không có gì chặn việc merge LoRA của 2+ NHÂN VẬT khác nhau vào 1 checkpoint, khác hẳn giới hạn của IP-Adapter (chỉ 1 `ip_image_embeds`, không merge được vì đó là injection runtime chứ không phải trọng số nướng sẵn). Đã làm ngay (KHÔNG cần sửa native/re-export):
- `StoryManager`: thêm `pairModelId()`, `hasConvertedPairModel()`, `convertAndRegisterPairModel()` — dùng lại nguyên `convertAndRegisterModel()` đã có.
- `MangaPipeline`: `resolveModelIdForCharacter()` → thêm `resolveModelIdForScene()` — ưu tiên model ghép nếu TẤT CẢ nhân vật trong scene có `loraPath` VÀ đã convert ghép sẵn; nếu user override tay 1 nhân vật cụ thể (`characterOverride`) thì tôn trọng lựa chọn đó, không tự ý dùng model ghép.
- **Rủi ro thật, chưa kiểm chứng**: merge nhiều LoRA nhân vật khác nhau vào 1 checkpoint là kỹ thuật cộng đồng SD dùng phổ biến, nhưng được biết có thể "rò rỉ đặc điểm" giữa 2 người (tóc/mặt lẫn nhau) — mức độ tuỳ cường độ train từng LoRA, không có cách nào biết chắc ngoài build-test thật trên máy.
- **GIỚI HẠN CÒN LẠI, QUAN TRỌNG HƠN CẢ**: rà lại thì phát hiện **KHÔNG CÓ MÀN HÌNH UI NÀO gọi `convertAndRegisterModel`/`convertAndRegisterPairModel` cả** — nghĩa là dù giờ có API ghép cặp, hiện KHÔNG có cách nào trong app để user thực sự BẤM để convert (đơn hay ghép cặp). Đây là gap chặn đường thật sự, có trước cả câu hỏi ghép cặp — cần 1 màn hình chọn checkpoint gốc + chọn nhân vật (1 hoặc nhiều) + bấm convert, chưa viết.

**Bug phụ tìm thấy & đã sửa trong lúc rà** (không liên quan câu hỏi, nhưng chặn build): `FamilyManager.kt` còn nguyên cụm code blend-vector (`tryBlendEmbeddings`/`blendSingleParent`/`blendTwoParents`/`loadEmbedding`/`saveEmbedding`) — đúng kỹ thuật đã bị mục 2 chốt bỏ ("Blend vector tự chế không có cơ sở khoa học"), và bản thân cụm này cũng không compile được (gọi `saveCharacterAnchor()` 4 tham số trong khi hàm thật chỉ nhận 3; tham chiếu `Character.anchorEmbeddingPath` — field không tồn tại, tên thật là `anchorImagePath`, sai ở 4 chỗ: `FamilyManager.kt` x2, `CharactersScreen.kt`, `FamilyScreen.kt`). Đã xoá cụm code thừa, sửa tên field đúng ở cả 4 chỗ.

**CẬP NHẬT (theo đề xuất "sao không để LLM tự né")**: đã làm 2 việc RẺ, KHÔNG đảo pipeline:
1. `parseStory()` giờ nhận thêm `ipAdapterCharacterNames: List<String>` — nếu user ĐÃ tự thêm nhân vật + anchor ảnh từ trước (qua CharactersScreen, độc lập với sinh truyện), LLM được nhắc mềm: cố tránh ghép 2+ người trong nhóm này chung 1 panel, trừ khi cốt truyện thật sự cần. Đây CHỈ là gợi ý mềm, không đảm bảo LLM tuân theo.
2. `StoryManager.detectIpAdapterConflicts()` — phát hiện xung đột THẬT bằng Kotlin (đếm trực tiếp, không tin lời LLM), chạy sau khi có kịch bản đầy đủ. Kết quả lưu vào `Panel.ipAdapterConflictNames`, hiện cảnh báo CHÍNH XÁC trong `GalleryReviewScreen` (trước đây cảnh báo mọi panel ≥2 nhân vật kể cả không ai dùng IP-Adapter — gây nhiễu, đã sửa).

**GIỚI HẠN CÒN LẠI — đây mới là ý CHÍNH của đề xuất, CHƯA LÀM**: user đề xuất đảo hẳn thứ tự pipeline — (1) tóm tắt truyện + chốt danh sách nhân vật theo tần suất TRƯỚC, (2) dừng lại cho user set LoRA/IP-Adapter từng người, (3) MỚI viết kịch bản chi tiết (biết trước ai dùng IP-Adapter để né ngay từ đầu, không phải né sau khi đã trót viết). Đã xác nhận: **hiện tại pipeline làm NGƯỢC lại hoàn toàn** — `parseStory()` viết hết kịch bản 1 lần, xong mới tự tạo `Character` rỗng (chưa gán method gì) từ tần suất, và chạy `buildPrompt` NGAY LẬP TỨC, không hề dừng cho user set gì cả. Cũng phát hiện `autoClassifyCharacter()` (hàm tính role theo tần suất) **định nghĩa xong nhưng chưa từng được gọi ở đâu** — code chết, giờ mới gọi thật lần đầu.

Việc 2 fix vừa làm chỉ giúp được TRƯỜNG HỢP: user tự tay thêm nhân vật + anchor ảnh trước khi bấm "sinh truyện" — không giúp được luồng bình thường (auto-detect nhân vật từ truyện). Đảo hẳn pipeline theo đúng ý user cần: `LLMParser.extractCharacterSummary()` (hàm mới, tóm tắt + liệt kê nhân vật + ước lượng vai trò TỪ VĂN BẢN GỐC, chưa cắt panel), 1 màn hình UI mới (hoặc mở rộng CharactersScreen) để dừng pipeline giữa chừng cho user xác nhận/set method, rồi mới gọi `parseStory` đầy đủ. Đây là thay đổi lớn ở state machine (`MainViewModel`/`StoryScreens.kt`/`PipelineStage`), CHƯA làm, cần xác nhận trước khi bắt tay.

---

## 13. Phương pháp thứ 3 để nhất quán nhân vật — Textual Inversion (PHÁT HIỆN LỚN)

**Bối cảnh**: user hỏi "ngoài LoRA và IP-Adapter còn cách nào khác, thấp hơn cũng được". Rà lại `TextEncoder.hpp`/`PromptProcessor.hpp` (phần port từ local-dream) phát hiện: **Textual Inversion đã được cài đặt ĐẦY ĐỦ trong native engine từ trước** (`loadTextualInversions()`, `PromptProcessor` tự nhận diện trigger word khớp tên file `.safetensors` trong prompt, tự thay bằng embedding vector tại đúng vị trí token) — nhưng **CHƯA TỪNG được Kotlin/pipeline của MangaLocal gọi tới** cho tới hôm nay. Đây là phát hiện quan trọng nhất trong các lượt rà gần đây.

**Vì sao đáng giá hơn hẳn 2 cách kia cho đúng bài toán đang bàn (nhiều nhân vật/1 panel)**:
- Hoạt động THUẦN ở tầng text-encoder (CLIP), KHÔNG đụng UNet — khác hẳn IP-Adapter (bị khoá cứng 1 `ip_image_embeds`/lượt) và LoRA-merge (bake vào trọng số, rủi ro rò rỉ đặc điểm khi ghép nhiều người).
- **Nhiều trigger word của NHIỀU nhân vật khác nhau dùng CHUNG 1 prompt/1 panel được, không giới hạn số lượng** — vì mỗi trigger chiếm 1 vị trí token riêng trong chuỗi 77 token, độc lập nhau. Đây chính là câu trả lời trực tiếp cho vấn đề "2+ người IP-Adapter cùng khung".
- Format `.safetensors` CHUẨN cộng đồng (train qua AUTOMATIC1111/kohya_ss hoặc lấy có sẵn), không cần convert riêng như LoRA/UNet.
- **CHƯA kiểm chứng, cần nói rõ**: cộng đồng SD ghi nhận Textual Inversion nhìn chung YẾU HƠN LoRA/IP-Adapter về độ giống mặt chính xác — hợp với "nhất quán khái niệm" (trang phục, tông màu, đặc điểm nổi bật) hơn là tái tạo khuôn mặt chi tiết. Đúng như user chấp nhận ("thấp hơn ipadapter cũng được").

**Đã làm (wiring đầy đủ, không cần re-export UNet)**:
- `sdInit()`/`sdInitAugmented()` (cả 2 native init) nhận thêm `jEmbeddingsDir`, gọi `textEncoder->loadTextualInversions(...)` — thư mục rỗng/không tồn tại thì bỏ qua an toàn (đã đọc code xác nhận).
- `NativeBridge.kt`, `ImagePipeline.loadSD()/loadSDAugmented()` cập nhật chữ ký tương ứng.
- `StoryManager`: thêm `embeddingsDir(storyId)`, `setCharacterEmbedding(storyId, characterId, sourceSafetensorsPath)` — copy file vào thư mục, đặt tên = trigger word (sanitize từ tên nhân vật, né trùng).
- `Character`: thêm `embeddingPath`/`embeddingTrigger`.
- `MangaPipeline`: thêm `injectEmbeddingTriggers()` — với MỌI nhân vật trong panel KHÔNG phải là người được neo chính (LoRA/IP-Adapter), nếu họ có `embeddingTrigger`, tự động chèn trigger word vào đầu prompt. Áp dụng cả `generatePanels` và `regeneratePanel`.

**CẢNH BÁO cần ghi cho user (UI CHƯA LÀM)**: nếu tên nhân vật trùng 1 từ tiếng Anh thông dụng hay dùng trong prompt (vd đặt tên nhân vật là "Hero"), từ đó sẽ BỊ THAY bằng embedding trong MỌI prompt, kể cả không cố ý nhắc nhân vật — nên khuyên đặt tên tránh trùng từ thường dùng, hoặc UI cần cảnh báo khi phát hiện trùng.

**GIỚI HẠN CÒN LẠI, CHƯA LÀM**:
- Cache `loadSD()`: nếu `modelId` không đổi nhưng `embeddingsDir` vừa có file mới thêm giữa chừng, hàm SẼ bỏ qua reload (chỉ check `modelId == loadedSdPath`) — embedding mới không được nạp cho tới khi đổi model khác rồi quay lại. Chưa fix, cần theo dõi thêm state nếu gặp vấn đề thật khi build-test.
- **KHÔNG CÓ UI nào để user upload/gán file Textual Inversion cho nhân vật** — giống hệt vấn đề đã ghi ở mục 12 cho LoRA convert: cần 1 màn hình/nút bấm gọi `setCharacterEmbedding()`. Nên gộp chung với màn hình "Convert model" còn thiếu (mục 12) thành 1 màn hình quản lý consistency-method đầy đủ: LoRA (cần convert) / IP-Adapter (chỉ cần ảnh, có sẵn) / Textual Inversion (chỉ cần copy file, không cần convert) — 3 lựa chọn cho mỗi nhân vật.
- Chưa thử nghiệm build thật để biết `loadTextualInversions()` từ local-dream có tương thích 100% với tokenizer/pos_emb/token_emb hiện tại của MangaLocal hay không (project port từ local-dream nhưng có thể có sai khác nhỏ về format — CHƯA build-test).

---

## 14. Màn hình "Phương pháp nhất quán" — ĐÃ XÂY (theo yêu cầu ưu tiên cao)

Gộp cả 3 phương pháp (LoRA/IP-Adapter/Textual Inversion) + "Không dùng" vào `EditCharacterDialog` (CharactersScreen.kt), với gợi ý tự động theo vai trò:

- `ConsistencyMethod` enum mới (Models.kt) + `StoryManager.suggestConsistencyMethod(role)`: MAIN → LoRA, SUPPORTING → IP-Adapter, ONETIME → Không dùng (mặc định).
- **Đã thu hẹp 4 tier user đề xuất (nhiều/trung bình/ít/qua đường) xuống còn 3 tier hiện có** (MAIN/SUPPORTING/ONETIME) — gộp "ít" và "qua đường" chung vào ONETIME, mặc định "Không dùng" cho tier này, Textual Inversion vẫn chọn tay được nếu user vẫn muốn 1 chút nhận diện cho nhân vật ONETIME nào đó. Nếu sau này thấy cần tách riêng 4 tier thật, phải thêm giá trị enum `CharacterRole` mới — chưa làm vì ảnh hưởng dây chuyền tới `RoleChip`/`FamilyScreen`/label ở nhiều nơi.
- % hiển thị trong UI: LoRA ~90-100%, IP-Adapter ~80-90%, Textual Inversion ~40-65% — **đã ghi rõ trong UI đây là ước lượng CỘNG ĐỒNG SD chung, KHÔNG PHẢI đo trên chính app này**.

**2 BUG THẬT tự phát hiện và sửa trong lúc xây** (đọc kỹ `sd_model_converter.cpp` mới thấy): `checkpointFile`/`loraFiles` truyền vào `sdConvertModel` PHẢI là TÊN FILE tương đối nằm ngay trong `modelDir`, KHÔNG PHẢI đường dẫn tuyệt đối — bản đầu viết (cả `MainViewModel.convertCharacterLora` lẫn `StoryManager.convertAndRegisterPairModel` viết ở mục 12) đều truyền thẳng path tuyệt đối, sẽ LUÔN THẤT BẠI. Đã sửa cả 2: giờ tự copy checkpoint + LoRA + 3 file "khung" (unet.mnn/vae_decoder.mnn/vae_encoder.mnn, lấy từ model mặc định đã convert sẵn) vào đúng thư mục trước khi gọi convert, dùng tên tương đối.

**Rủi ro dây chuyền cần biết**: convert LoRA riêng cho 1 nhân vật (hoặc ghép cặp) phụ thuộc vào việc model MẶC ĐỊNH đã convert thành công từ trước (để lấy 3 file "khung") — nếu build lần đầu chưa từng convert xong model mặc định, tính năng LoRA riêng/ghép cặp sẽ báo lỗi rõ ràng (không còn fail âm thầm) nhưng vẫn không dùng được cho tới khi model gốc ổn.

**Đã dọn dẹp thêm 1 chỗ**: nút "🔄 Tạo lại ảnh anchor từ prompt này" (gọi `regenerateAnchor()`) đã bị XOÁ khỏi `EditCharacterDialog` — phát hiện `regenerateAnchor()` trong `MainViewModel.kt` là **hàm rỗng** (chỉ có comment, không làm gì cả) — để lại nút đó sẽ đánh lừa user tưởng có tác dụng. Cần viết lại thật nếu muốn tính năng "tạo lại anchor từ prompt" — CHƯA LÀM, ghi nhận riêng ở đây để không quên.

**CHƯA LÀM (biết trước)**:
- Chưa có UI cho `convertAndRegisterPairModel` (ghép 2+ nhân vật, mục 12) — mới có UI cho convert LoRA đơn từng người. Ghép cặp vẫn phải chờ 1 màn hình riêng (chọn 2+ nhân vật cùng lúc).
- Cache `loadSD()` (mục 13) vẫn chưa xử lý reload khi embeddings đổi giữa chừng.
- Đảo pipeline "tóm tắt trước → chốt nhân vật → user set method → mới viết kịch bản chi tiết" (mục 12 gốc) — CHƯA LÀM, màn hình vừa xây chỉ hoạt động TỐT NHẤT nếu user chủ động vào Nhân vật set trước khi bấm "Sinh truyện" (script viết sau vẫn được nhắc né xung đột — mục 13). Nếu user chỉnh SAU khi đã sinh xong, chỉ ảnh hưởng panel `regeneratePanel` sau đó, không viết lại được kịch bản đã trót fix.

---

## 15. Giảm nhẹ (KHÔNG giải quyết triệt để) rủi ro "dính người" khi ôm/vật nhau

Theo đúng thảo luận với user — xác nhận: **không có cách giải quyết dứt điểm** khi 2 nhân vật chạm thân thể trực tiếp (ôm, vật nhau, đánh nhau tay đôi), kể cả nếu đầu tư regional attention masking (mục 13) — vùng chồng lấn giữa 2 thân thể chính là chỗ khó nhất, cộng đồng SD thừa nhận rộng rãi, không có giải pháp triệt để kể cả trên desktop full-power (ComfyUI Attention Couple/Latent Couple cũng chỉ giảm nhẹ). Đã làm 2 việc RẺ để giảm nhẹ (không phải fix):

1. `scenePrompt()` (LLMParser): thêm gợi ý camera — ưu tiên "wide-shot"/"overhead" thay vì "close-up"/"extreme-close-up" cho cảnh có chạm thân thể trực tiếp, KHÔNG đổi nội dung truyện chỉ để né.
2. `negativeRiskHints()` (buildPrompt, per-panel): thêm phát hiện từ khoá chạm thân thể (ôm/vật/đánh nhau/kéo giằng...) trong `scene.action`/`scene.description` — gắn cờ rủi ro CAO NHẤT, gợi ý LLM thêm từ khoá negative + nhấn mạnh "two distinct bodies, clear silhouette separation" trong positive prompt.

**Thực tế cần chấp nhận**: cảnh ôm/vật nhau nhiều khả năng vẫn cần sửa tay qua Gallery Review (regenerate đổi seed, hoặc inpaint thủ công) — 2 việc trên chỉ giảm tần suất lỗi, không loại bỏ.

---

## 16. Nền tảng img2img/inpaint/Ultrafix — ĐÃ NỐI DÂY THẬT (lần đầu)

**Phát hiện** (giống hệt kiểu Textual Inversion mục 13): `Pipeline.hpp` (port từ local-dream) đã có ĐẦY ĐỦ `GenerationRequest.img2img`/`has_mask`/`ultrafix` — kể cả "Ultrafix: tiled img2img over an arbitrarily large (upscaled) input" (chính là kỹ thuật "Ultimate SD Upscale" — upscale bằng vẽ lại tile, không chỉ làm nét). Nhưng `mnn_diffusion_pipeline.cpp` hardcode `req.img2img = false` — CHƯA TỪNG dùng.

**Đã làm**: thêm hàm `sdImg2Img()` thật vào `mnn_diffusion_pipeline.cpp` (cùng file với `sdTxt2Img`, tái dùng `SdHandle`) — nhận ảnh input + mask tuỳ chọn + denoiseStrength + cờ ultrafix, gọi đúng `Pipeline::generate()` thật. Nối `NativeBridge.kt` + `ImagePipeline.img2imgFix()`.

**Quyết định kỹ thuật quan trọng**: TỰ VIẾT resize bilinear bằng tay (arithmetic đơn giản) cho ảnh input + mask, THAY VÌ dùng `stb_image_resize2.h` (dù build.yml có tải về) — vì KHÔNG có mạng lúc viết file này để tự kiểm chứng chữ ký hàm thật của thư viện đó, né rủi ro đoán sai API — đúng triết lý `yolo_wrapper.cpp` đã áp dụng trước (né `MNN::CV::ImageProcess` chưa kiểm chứng).

**Contract đã đọc kỹ và tuân theo** (Pipeline.hpp dòng ~38-43, ~869): `img_data` [1,3,H,W] float -1..1; **CẢ HAI** `mask_data` (latent space [1,4,H/8,W/8]) VÀ `mask_data_full` (pixel space [1,3,H,W]) đều phải tự tính — pipeline KHÔNG tự suy ra cái này từ cái kia, đã xác nhận ở chỗ validate input.

**CHƯA LÀM, CHƯA TEST — rất quan trọng phải đọc trước khi tưởng tính năng đã xong**:
1. **Toàn bộ đoạn C++ mới viết CHƯA TỪNG BUILD/CHẠY THẬT** — resize bilinear tự viết, cách dựng `mask_data`/`mask_data_full`, layout bộ nhớ — đều dựa trên đọc comment/contract trong `Pipeline.hpp`, chưa có gì xác nhận bằng compile/run thật. Rủi ro có lỗi tinh vi (off-by-one, sai layout kênh...) là CÓ THẬT, chỉ build-test lần đầu mới biết chắc.
2. **Auto-detect mặt/tay (ADetailer-style)**: CHƯA LÀM. Cần 1 trong 2 hướng: (a) đổi model `.mnn` trong `yolo_wrapper.cpp` sang model face/hand-detector cùng định dạng YOLOv8 chuẩn (hiện code đang đọc "class 0 = person" từ model COCO chuẩn — comment đầu file ghi "dùng cho auto bubble" nhưng code thật lại đọc person, KHÔNG khớp — phát hiện thêm 1 chỗ không nhất quán, chưa sửa), hoặc (b) dùng MediaPipe Face/Hand (đã tích hợp sẵn cho pose, có thể mở rộng). Chưa quyết hướng nào.
3. **Auto-detect "dính người"/giải phẫu sai chung**: KHÔNG CÓ pretrained model nào biết, đã nói rõ với user, không hứa làm được.
4. **UI mask thủ công**: HOÀN TOÀN CHƯA CÓ — không có màn hình vẽ mask nào trong app.
5. **Wiring vào `upscale()`**: hàm `ImagePipeline.upscale()` hiện vẫn CHỈ dùng ESRGAN thuần t (làm nét), CHƯA gọi `img2imgFix(ultrafix=true)` — cần sửa flow: ESRGAN trước (phóng to) → rồi `img2imgFix(ultrafix=true)` vẽ lại theo tile. CHƯA làm.
6. **Giả định CHƯA kiểm chứng**: width/height cho SD phải là bội số 8 (quy ước chuẩn latent /8) — code mới chưa validate/làm tròn, nếu UI truyền số lẻ sẽ lỗi ở bước latent-mask (dstW/8 lẻ). Cần thêm validate hoặc làm tròn trước khi build-test.

**Việc tiếp theo theo đúng thứ tự cần làm** (đã thống nhất "cả 2 đều cần"): (1) build-test thật để xác nhận `sdImg2Img` không lỗi cơ bản, (2) quyết hướng auto-detect mặt/tay, (3) wiring `upscale()` dùng Ultrafix, (4) UI mask thủ công (thấp ưu tiên hơn vì tốn UI nhất, auto-fix có giá trị ngay không cần UI mới).

---

## 17. Auto-fix mặt/tay (ADetailer-style) — ĐÃ NỐI DÂY, dùng MediaPipe tái sử dụng

Theo đúng tiêu chí user đặt ra ("hiệu suất cao, không kéo chậm app, dùng nhiều nơi, không code lại"): chọn **MediaPipe Tasks Vision** (KHÔNG chọn hướng đổi model trong `yolo_wrapper.cpp`) vì:
- Đã là dependency có sẵn (`com.google.mediapipe:tasks-vision:0.10.18`), đang dùng cho pose (`PoseExtractor.kt`) — thêm Face Detector + Hand Landmarker là dùng chung 1 thư viện, KHÔNG thêm engine detect thứ 2 song song với MNN/YOLO.
- BlazeFace (face) + palm-detection 2 tầng (hand) là model CHUYÊN BIỆT do Google tối ưu cho di động, có benchmark công bố (Pixel 6 CPU/GPU) — khác `yolo_wrapper.cpp` hiện đang đọc "class person" từ model COCO chung chung (comment đầu file ghi nhầm "auto bubble", chưa sửa — xem mục 16).

**Đã làm**:
- `FaceHandDetector.kt` (mới) — mirror đúng pattern `PoseExtractor.kt` (BaseOptions/RunningMode/createFromOptions). `detectRegions(bitmap)` trả về list `Rect` (đã pad 25%) của mặt + tay phát hiện được.
- `MangaPipeline`: thêm `tryAutoFixFacesHands()` — sau khi sinh ảnh gốc, nếu bật `settings.autoFixFacesHands`, detect vùng → dựng mask (`buildMaskFile`, canvas đen/trắng đơn giản, CHƯA feather mềm biên) → gọi `imagePipeline.img2imgFix()` (mục 16) → thay `rawPath`. Bọc try/catch RIÊNG, lỗi ở bước này KHÔNG làm hỏng panel (rơi về ảnh gốc).
- `GenerationSettings`: thêm `autoFixFacesHands: Boolean = false` (mặc định TẮT, chưa build-test), `autoFixDenoiseStrength: Float = 0.45f`.

**2 URL model đã TRA CỨU XÁC NHẬN qua tài liệu chính thức Google AI Edge (không đoán)**, cần tự tải và đặt vào `assets/` trước khi build (giống hệt quy ước `pose_landmarker_heavy.task` đã có):
- `assets/blaze_face_short_range.tflite` ← `https://storage.googleapis.com/mediapipe-models/face_detector/blaze_face_short_range/float16/1/blaze_face_short_range.tflite`
- `assets/hand_landmarker.task` ← `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`

**RỦI RO CHƯA KIỂM CHỨNG — quan trọng nhất phải đọc**:
1. **Tên hàm API `Detection.boundingBox()` / `HandLandmarkerResult.landmarks()` / `.x()`/`.y()` là NHỚ LẠI, không đọc được javadoc thật của bản `tasks-vision:0.10.18`** lúc viết (không tìm được source đầy đủ). Nếu build lỗi "unresolved reference" ở `FaceHandDetector.kt`, đây chính là chỗ cần sửa theo javadoc thật.
2. Toàn bộ chuỗi auto-fix (detect → mask → img2imgFix) CHƯA CHẠY THẬT LẦN NÀO — phụ thuộc cả vào mục 16 (sdImg2Img) cũng chưa build-test.
3. Mask hiện là hình chữ nhật cứng, chưa feather biên mềm — có thể để lại đường viền cứng thấy rõ ở chỗ ghép giữa vùng vẽ lại và ảnh gốc. Cải tiến sau nếu build-test cho thấy cần.
4. **Chưa có UI toggle** cho `autoFixFacesHands` trong SettingsScreen — field đã có trong `GenerationSettings`, nhưng phải sửa code (đổi default hoặc thêm switch UI) mới bật được, chưa thể bật qua UI.
5. Chưa xử lý performance thật: MediaPipe benchmark công bố nhanh, nhưng CHƯA đo thời gian THẬT khi cộng thêm vào mỗi panel (detect + 1 lượt img2img nữa = tốn thêm thời gian sinh đáng kể mỗi panel có phát hiện lỗi).

**Việc tiếp theo**: build-test thật để xác nhận cả mục 16+17 không lỗi cơ bản; thêm UI toggle; cân nhắc feather mask nếu thấy viền cứng khi test.

---

## 18. Giới hạn MediaPipe Pose — chỉ ảnh hưởng bước TRÍCH XUẤT, đã có cơ chế phòng hộ sẵn

User chỉ ra: MediaPipe Pose vốn thiết kế cho 1 người (tài liệu kỹ thuật xác nhận: "unlike YOLOv8/YOLO-NAS structured for multiple people, MediaPipe Pose is a framework aimed at pose estimation for a single person"), và có báo cáo lỗi thật trên GitHub MediaPipe: khi 1 người che tay/bị occlusion trong cảnh nhiều người, model vẫn "ảo giác" ra toạ độ khớp không đúng thật thay vì báo không thấy — dễ xảy ra nhất đúng lúc cảnh ôm/vật/quần nhau.

**Đã xác nhận phạm vi ảnh hưởng**: `tools/extract_pose_library.py` (bản PC) VÀ `PoseExtractor.kt` (bản điện thoại) đều dùng CHUNG MediaPipe BlazePose — không có đường nào trong dự án né được giới hạn này ở bước trích xuất. NHƯNG bước ÁP DỤNG (ControlNet-Pose lúc sinh ảnh) không bị ảnh hưởng — chỉ đọc toạ độ đã lưu sẵn trong `pose_library.json`, không quan tâm nguồn gốc.

**Tin tốt — cơ chế phòng hộ ĐÃ CÓ SẴN từ trước** (không phải việc mới cần làm): `PoseEditorScreen.kt` dùng kết quả MediaPipe làm BẢN NHÁP đổ vào editor thủ công (dòng ~126: `people = variant.people...`), cho phép thêm/xoá người + kéo từng khớp bằng tay trước khi lưu — đúng mô hình "tự động nháp + thủ công sửa" đã bàn với user.

**Khuyến nghị dùng thực tế (ghi vào doc để không quên)**: với cảnh ôm/vật/quần nhau, coi kết quả MediaPipe tự động là ĐIỂM KHỞI ĐẦU cần kiểm tra kỹ, không tin tưởng tuyệt đối — nhiều khả năng cần tách lại 2 khung xương bị lẫn bằng tay trong `PoseEditorScreen` trước khi lưu vào thư viện.

**Hướng thay thế thật, CHƯA làm, không cấp thiết**: YOLOv8-Pose hoặc DWPose — kiến trúc khác hẳn (không phải "detect người rồi crop-riêng-từng-người" như MediaPipe), ít bị lỗi ảo giác khớp khi occlusion hơn theo y văn multi-person pose estimation. Cần convert model riêng sang MNN, dự án đã có tiền lệ hạ tầng YOLO (`yolo_wrapper.cpp`) có thể tái dùng một phần, nhưng đây là đầu tư engineering thật, CHƯA kiểm chứng, và không cấp thiết vì đường thủ công đã hoạt động.

---

## 19. Trả lời câu hỏi YOLO version + 3 cơ chế cảnh báo tự động (theo yêu cầu chi tiết của user)

**Version YOLO — đã tra cứu xác nhận, không đoán**: YOLOv8/YOLO11/YOLO26 (cùng Ultralytics) đều có biến thể "-pose" (COCO-17 keypoint, cùng layout tensor). Đổi version chỉ cần sửa 1 dòng tên model trong `tools/export_yolo_pose.py`, tên file `.mnn` giữ nguyên "yolov8_pose.mnn" (đặt theo VAI TRÒ, không theo version, để không phải sửa code Kotlin/C++ khi đổi bản). **YOLOv9 KHÔNG có biến thể "-pose" chính thức** (chỉ detect/segment) — không phải lựa chọn khả dụng, không phải bỏ sót.

**3 cơ chế cảnh báo tự động đã cài đặt ĐÚNG như yêu cầu** (`PoseExtractor.validatePerson()`, đồng bộ Kotlin + `extract_pose_library.py` Python):
1. Điểm tự tin khớp quan trọng (khuỷu/cổ tay/gối/mắt cá) < 0.5 → "che khuất".
2. Số khớp visible < 17/17 → "thiếu chi".
3. Khoảng cách khớp liền kề > 3x đơn vị tham chiếu vai-hông → "cấu trúc xương dị thường" (ngưỡng 3.0x là KINH NGHIỆM tự chọn, không phải số đo khoa học chính xác — chỉ lọc ca rõ ràng vô lý).

Kết quả lưu vào `PoseVariant.needsReview`/`reviewReasons`, hiển thị trong `PoseEditorScreen.kt` khi trích từ ảnh/video — user thấy rõ biến thể nào cần tự kiểm tra trước khi lưu vào thư viện.

**Đánh đổi phải chấp nhận khi bỏ z-depth của MediaPipe**: `estimateAngle()` đổi từ heuristic z-depth (chính xác hơn) sang heuristic 2D (độ lệch ngang mũi so với vai) — kém chính xác hơn, CHƯA build-test để biết mức sai khác thực tế.

---

## 20. Hợp nhất autodetect về YOLO xuyên suốt + pipeline "ảnh hoàn hảo" (Hires-fix → ADetailer)

Theo yêu cầu user: dùng YOLO cho MỌI autodetect, áp dụng đúng thứ tự Hires-fix trước/ADetailer sau theo chuẩn cộng đồng.

**① Hợp nhất Face/Hand về YOLO — PHÁT HIỆN HAY HƠN DỰ KIẾN**: thay vì thêm 1 model YOLO-face/YOLO-hand riêng (cần model cộng đồng khác, chưa rõ chất lượng), `FaceHandDetector.kt` viết lại để **tái dùng NGAY khung xương YOLOv8-pose đã detect sẵn** — vùng mặt suy từ mũi/mắt/tai, vùng tay suy từ khuỷu tay→cổ tay (đo độ dài cẳng tay để ước lượng kích thước bàn tay). KHÔNG CẦN THÊM MODEL NÀO — dùng lại đúng 1 lần detect pose đã chạy cho cả 2 việc. Đã bỏ HẲN dependency `com.google.mediapipe:tasks-vision` khỏi `app/build.gradle` — xác nhận không còn `import com.google.mediapipe.*` nào trong toàn bộ codebase.

**Đánh đổi thành thật**: model face/hand CHUYÊN BIỆT (train riêng để tìm đúng ranh giới) chính xác hơn suy luận hình học từ keypoint. Chấp nhận vì mask vốn đã có padding rộng (60%/50%), và tái dùng detect có sẵn đúng tinh thần "hiệu suất cao, không code lại" đã thống nhất. CHƯA build-test để biết độ lệch thực tế.

**② Pipeline "ảnh hoàn hảo" — đã đảo đúng thứ tự chuẩn cộng đồng**:
- TRƯỚC: auto-fix mặt/tay chạy NGAY SAU sinh ảnh gốc (512px, TRƯỚC upscale) — SAI thứ tự, mask kém chính xác hơn vì ảnh còn nhỏ.
- GIỜ: đã chuyển `tryAutoFixFacesHands` từ `generatePanels()` sang `upscaleApprovedPanels()`, chạy theo đúng thứ tự: **(1) ESRGAN upscale → (2) Ultrafix vẽ lại nhẹ toàn ảnh (denoise 0.35-0.45, "thông số vàng" theo đúng khuyến nghị user) → (3) auto-fix mặt/tay ở độ phân giải CUỐI cùng** (mask chính xác hơn hẳn).
- Thêm `GenerationSettings.useUltrafixRedraw`/`ultrafixDenoiseStrength` (mặc định TẮT, chưa build-test).
- `tryUltrafixRedraw()` (mới) gọi `imagePipeline.img2imgFix(ultrafix=true)` (nền tảng đã xây mục 16) sau ESRGAN.

**③ Model upscale 4x-UltraSharp — đã viết pipeline convert đầy đủ**: `tools/export_esrgan.py` dùng thư viện `spandrel` (lõi chaiNNer, tự nhận diện kiến trúc ESRGAN — old-arch vs RealESRGAN khác nhau ở tên layer, TỰ VIẾT lại có rủi ro sai thật, dùng `spandrel` an toàn hơn hẳn). Đã xác nhận URL + SHA256 của `4x-UltraSharp.pth` khớp nhau trên nhiều mirror HuggingFace độc lập (dấu hiệu file gốc không bị giả mạo). Nối vào `prepare_models.yml`.

**RỦI RO CHƯA KIỂM CHỨNG — quan trọng nhất**:
1. `tools/export_esrgan.py` **CHƯA CHẠY THẬT LẦN NÀO** — rủi ro thật: (a) input size cố định dùng để trace ONNX có thể không khớp 1 số kiến trúc nhạy kích thước, (b) `spandrel` có thể không nhận diện đúng kiến trúc của bản `.pth` cụ thể. Đã ghi rõ trong docstring script.
2. Suy luận vùng mặt/tay từ pose keypoint (thay vì model chuyên biệt) CHƯA build-test độ chính xác thực tế.
3. Toàn bộ pipeline mới (Ultrafix sau ESRGAN, auto-fix sau Ultrafix) CHƯA chạy thật lần nào — phụ thuộc cả mục 16 (sdImg2Img) và mục 17 (auto-fix) cũng chưa build-test.
4. **CHƯA làm**: "Inpaint Anything" (SAM — Segment Anything Model, click 1 điểm tự động phân đoạn mask chính xác) — đây là model NẶNG, tương tác thời gian thực, khác hẳn quy mô các việc đã làm. Đề xuất ĐỂ SAU nếu thực tế cần — UI mask thủ công đơn giản (vẽ tay, chưa làm — mục 12/16/17 đã ghi) là bước trung gian rẻ hơn, nên làm trước khi cân nhắc SAM.

---

## 21. MobileSAM click-to-mask (chỉ tạo mask, KHÔNG tự vẽ) — nền tảng UI thủ công

**Đính chính hiểu nhầm của user đã tự sửa đúng**: MobileSAM CHỈ phân đoạn ra mask, KHÔNG tự vẽ/inpaint gì cả — việc vẽ lại là do checkpoint SD1.5 làm qua `img2imgFix()` (mục 16) đã có. `ManualMaskFixer.kt` tách đúng 2 bước: `clickToMask()` (gọi MobileSAM lấy mask) → `inpaintMaskedRegion()` (gọi `img2imgFix`, CÙNG 1 inpainting với auto-fix mặt/tay mục 17, không viết riêng).

**Đã chọn MobileSAM** (không phải EdgeSAM/FastSAM) — tra cứu xác nhận: <10M tham số, tài liệu chính thức `samexporter` ghi rõ "best choice for CPU-only environments". Viết `tools/export_mobilesam.py` dùng thư viện `samexporter` (không tự viết wrapper ONNX — rủi ro sai thật nếu tự làm). Native `mobile_sam_wrapper.cpp`: encoder+decoder 2 MNN session riêng, encoder chạy LẠI MỖI LẦN CLICK (không cache — đơn giản hoá, chấp nhận được vì tool dùng hiếm).

**RỦI RO CHƯA KIỂM CHỨNG QUAN TRỌNG NHẤT**: input chính xác encoder khi export `--use-preprocess` (ảnh thô hay đã chuẩn hoá) chỉ dựa tài liệu, CHƯA tự chạy thử. Toàn bộ pipeline CHƯA build-test lần nào.

**UI**: `PostProcessingScreen.kt` — thêm `ManualMaskFixCanvas` (hiện ảnh THẬT qua Coil, phát hiện `BubbleEditCanvas` cũ chỉ là placeholder chữ, không hiện ảnh thật — không sửa cái đó, chỉ đảm bảo canvas mới của mình hiện đúng). Chạm 1 điểm → tự quy đổi toạ độ hiển thị sang toạ độ pixel ảnh thật → gọi MobileSAM → `img2imgFix`.

**BUG THẬT tự phát hiện và sửa ngay trong lúc build**: khi chèn `ManualMaskFixCanvas` vào file, dòng khai báo hàm `private fun BubbleEditCanvas(...)  {` bị mất — gây lệch ngoặc, code sau đó (thân hàm BubbleEditCanvas) trở thành mồ côi không có function bao ngoài. Phát hiện qua kiểm tra cân bằng ngoặc (bỏ qua comment) trước khi đóng gói, đã sửa.

## 22. Cảnh báo panel đã auto-fix + xác nhận Gallery cuối trước bubble đã tồn tại sẵn

Theo yêu cầu "trong tự động nếu có lỗi thì báo cho người dùng" + "gallery kiểm tra cuối trước khi đắp bubble":
- `Panel.autoFixApplied` (mới) — set `true` nếu Ultrafix HOẶC auto-fix mặt/tay thực sự thay đổi ảnh (so sánh path trước/sau). Hiện badge cam trên `PostProcessingScreen` + chấm cảnh báo nhỏ trên từng nút chọn panel — thấy tổng quan panel nào cần xem kỹ mà không phải bấm từng cái.
- **Xác nhận**: `PostProcessingScreen.kt` (nơi đặt `runAutoBubble()`) ĐÃ LÀ đúng vị trí "gallery cuối trước bubble" — đã có sẵn bộ chọn duyệt qua từng panel, giờ thêm canvas sửa tay ngay tại đây. KHÔNG cần xây màn hình riêng mới, chỉ cần nối đúng thứ tự (đã đúng: upscale → PostProcessingScreen review/sửa tay → auto bubble).

## 23. TỪ CHỐI một phần yêu cầu — nội dung tình dục

User đề xuất thêm "nguyên lý giao thoa chính xác" cho inpainting: mở rộng mask từ hông nhân vật này sang mông nhân vật khác, prompt tập trung "intense penetration, seamless skin contact", denoise 0.55-0.65 để "đập đi xây lại" vùng đó. ĐÃ TỪ CHỐI phần này — đây là tối ưu hoá kỹ thuật riêng cho dựng cảnh giao hợp, không còn là sửa lỗi giải phẫu ôm/vật nhau nữa. Không cài đặt prompt template/mask strategy cho mục đích này.

---

## 24. LLM dịch prompt theo giai đoạn + quy tắc bối cảnh chung (theo thiết kế user)

Theo đúng kiến trúc user mô tả: 1 lớp LLM trung gian dịch "mô tả tự nhiên tiếng Việt + quy tắc bối cảnh chung" → prompt SD1.5, áp dụng RIÊNG theo từng giai đoạn (txt2img/upscale-redraw/inpaint) + override riêng từng ảnh.

**Đã làm**:
- `Story.worldRules: String` (mới) — quy tắc bối cảnh chung, tiếng Việt tự nhiên, user tự viết lúc tạo truyện. LLM dùng làm ngữ cảnh nền (không chép nguyên văn vào prompt).
- `PromptStage` enum (TXT2IMG/UPSCALE_REDRAW/INPAINT) — mỗi giai đoạn có trọng tâm dịch khác nhau: TXT2IMG mô tả đầy đủ cảnh; UPSCALE_REDRAW chỉ tag chất lượng bề mặt (không mô tả lại cảnh — bố cục đã đúng); INPAINT chỉ mô tả hành động/vùng đang sửa (không lặp lại toàn cảnh).
- `LLMParser.translateStagePrompt()` (mới) — hàm dịch chung, dùng cho UPSCALE_REDRAW (trong `tryUltrafixRedraw`) và INPAINT (trong `tryAutoFixFacesHands`).
- `buildPrompt()` (giai đoạn TXT2IMG, đã có từ trước) — thêm tham số `worldRules` cho đồng bộ với 2 giai đoạn còn lại.
- `PanelOverrideSettings.naturalDescriptionOverride` (mới) — override mô tả tự nhiên RIÊNG 1 ảnh, LLM dịch thay vì dùng mô tả scene tự động. Khác `promptOverride` (tag SD1.5 gõ tay trực tiếp) — 2 cái không xung đột, `promptOverride` ưu tiên hơn nếu cả 2 đều set.
- `upscaleApprovedPanels()`: khởi tạo 1 `LLMParser` RIÊNG (không dùng chung `llmParser` của `generatePanels()` — cái đó đã `free()` xong trước khi tới bước upscale) — CHỈ init nếu Ultrafix hoặc auto-fix mặt/tay đang bật, tránh tốn tài nguyên khi không cần.
- UI: thêm ô "Quy tắc bối cảnh chung" khi tạo truyện (`StoryScreens.kt`) + `MainViewModel.updateWorldRules()` để sửa sau.

**Đã từ chối 1 phần yêu cầu liên quan** (mục 23): dù cơ chế LLM dịch prompt là trung lập, nếu "quy tắc bối cảnh chung" được viết để định hướng sinh nội dung tình dục, tôi vẫn không giúp hiệu chỉnh phần đó — ranh giới không phụ thuộc việc chữ do user gõ tay hay LLM tự sinh theo quy tắc.

**CHƯA LÀM**: UI cho `naturalDescriptionOverride` (ô nhập mô tả tự nhiên + nút "Dịch qua LLM" xem trước kết quả) — mới có ở tầng dữ liệu/pipeline, GalleryReviewScreen CHƯA có ô nhập cho field này. CHƯA build-test toàn bộ luồng dịch 3 giai đoạn.

---

## 25. SettingsScreen.kt viết lại đầy đủ — nối hết tham số kỹ thuật, sửa 2 lỗ hổng thật

Theo câu hỏi user ("setting có đầy đủ tham số kỹ thuật... không") — rà lại phát hiện thiếu nhiều, đã viết lại toàn bộ:

**Sửa 2 vấn đề thật tự phát hiện**:
1. **Toggle "Vulkan GPU" là dead code** — `settings.useVulkan` KHÔNG được bất kỳ pipeline nào đọc (xác nhận grep toàn bộ `pipeline/*.kt`, 0 kết quả) — dấu tích lịch sử từ trước khi đổi engine sang MNN (mục 3: "MNN thay ncnn/sd.cpp"). Đã thay bằng toggle `useOpenCL` THẬT — field này mới là cái `ImagePipeline.loadSD()` thực sự dùng.
2. **Dropdown "SD Model"/"LoRA mặc định" trỏ sai hệ thống** — dùng `settings.sdModelPath`/`loraPath` (đã `@Deprecated`) qua `scanSdModels()` (liệt kê CHECKPOINT GỐC .safetensors dùng để CONVERT, không phải model đã convert xong). Đã sửa: SD Model giờ chọn theo `sdModelId` từ `storyManager.listConvertedModels()` (đúng hệ `model_manifest.json` mới). Bỏ hẳn dropdown "LoRA mặc định" — LoRA giờ gán RIÊNG từng nhân vật qua CharactersScreen (mục 14), không còn khái niệm 1 LoRA chung.

**Đã thêm mới (trước đây KHÔNG có UI nào cả)**:
- Card "kích thước & phong cách": `width`/`height` (chip 384/512/640/768), `panelCount` (slider), `imageStyle` (chip).
- Card "Hires-fix (Ultrafix)": toggle `useUltrafixRedraw` + slider `ultrafixDenoiseStrength` (0.2-0.6, ghi rõ "thông số vàng" 0.35-0.45).
- Card "Auto-fix mặt/tay": toggle `autoFixFacesHands` + slider `autoFixDenoiseStrength`.
- Cả 2 card mới đều ghi rõ "CHƯA BUILD-TEST" ngay trong UI, không giấu user.
- Cập nhật card "stack kỹ thuật" cho khớp thực tế sau các thay đổi phiên này (YOLOv8-pose thay MediaPipe, MobileSAM, Ultrafix...) — trước đó vẫn ghi "YOLOv8n ncnn" dù đã đổi sang MNN từ lâu, và "sd.cpp" dù đã đổi sang MNN.

**Vẫn còn 1 field dead-nhưng-vô-hại**: `GenerationSettings.useVulkan` vẫn còn trong data class (không xoá, tránh phá vỡ chỗ khác có thể đang serialize/deserialize field này trong settings đã lưu), chỉ không còn hiện trên UI nữa.

---

## 26. Rà toàn bộ CMakeLists.txt/build.yml/prepare_models.yml lần cuối — 3 bug thật tìm thấy

Theo yêu cầu "làm cho xong toàn bộ việc ưu tiên tồn đọng" — rà lại từ đầu:

**Đối chiếu TOÀN BỘ hàm JNI**: viết script so khớp mọi `external fun` trong `NativeBridge.kt` với mọi `Java_com_mangalocal_pipeline_NativeBridge_*` trong `.cpp` — **0 hàm thiếu, 0 hàm thừa, tất cả tên khớp 100%**. Spot-check chữ ký `sdInit`/`sdInitAugmented`/`sdImg2Img` (những hàm sửa nhiều lần nhất phiên này) — khớp chính xác số lượng + thứ tự tham số.

**Bug 1 — `prepare_models.yml` còn sót bước tải MediaPipe Face/Hand đã bỏ dùng**: mục 20 nói đã xoá, nhưng thực ra chỉ xoá dòng COPY ở bước đóng gói, quên xoá hẳn BƯỚC TẢI — CI vẫn tải 2 file không dùng vào đâu cả. Đã xoá dứt điểm.

**Bug 2 — `StoryManager.hasEsrgan()`/`hasYolo()`/`modelStatus()`/`setupGuide()` lỗi thời nghiêm trọng**: toàn bộ 4 hàm này vẫn kiểm tra/hướng dẫn theo định dạng **ncnn cũ** (`realesrgan-x4plus.param/.bin`, `yolov8n.param/.bin`) — đúng công nghệ đã bị BỎ HẲN từ quyết định gốc "MNN thay ncnn" (mục 3), không khớp bất kỳ file `.mnn` thật nào engine hiện dùng. Nghĩa là màn hình "trạng thái model"/"hướng dẫn đặt model" trong Settings — thứ đầu tiên user đọc để biết cần đặt file gì — đã SAI suốt từ đầu tới giờ, không ai phát hiện vì chưa từng đọc kỹ 2 hàm này cho tới lượt rà cuối này. Đã viết lại hoàn toàn: kiểm tra đúng tên file `.mnn` thật, bổ sung trạng thái cho YOLOv8-pose/MobileSAM/UNet augmented (trước đây không hề có trong danh sách), hướng dẫn đặt file viết lại đúng cấu trúc thư mục thật.

## 27. UI còn thiếu — đã hoàn thiện thêm 2 việc

1. **`naturalDescriptionOverride` UI** (mục 24) — thêm ô "mô tả tự nhiên" + nút "Dịch qua LLM" trong `GalleryReviewScreen.kt`, gọi `MainViewModel.translateNaturalDescription()` (LLMParser ngắn hạn riêng cho 1 lần dịch). Kết quả LLM tự điền vào ô prompt SD có sẵn để user xem/sửa trước khi lưu — không tự áp dụng thẳng, đúng nguyên tắc minh bạch xuyên suốt dự án.
2. **UI ghép cặp LoRA** (mục 12/14) — API `convertAndRegisterPairModel()` có từ mục 12 nhưng KHÔNG CÓ UI nào gọi được. Đã thêm `PairConvertDialog` trong `CharactersScreen.kt`: chọn ≥2 nhân vật đã có `loraPath` + chọn checkpoint gốc → `MainViewModel.convertCharacterPair()`.

**CHƯA LÀM (còn lại, ghi rõ để không quên)**:
- Feather mềm biên mask (auto-fix mặt/tay, mục 17) — vẫn là hình chữ nhật cứng.
- `regenerateAnchor()` vẫn là hàm rỗng (đã xoá khỏi UI single-character dialog nhưng chưa viết lại thật).
- Cache `loadSD()` chưa reload khi embeddings đổi giữa chừng (mục 13).
- Đảo pipeline "tóm tắt trước → chốt nhân vật → set method → viết kịch bản" (mục 12 gốc) — thay đổi lớn ở state machine, vẫn treo.
- **TOÀN BỘ CHƯA BUILD-TEST THẬT LẦN NÀO** — đây là rủi ro lớn nhất bao trùm mọi mục, chỉ build thật trên GitHub Actions mới biết chắc còn lỗi gì.

---

## 28. LoRA Block Weight — giảm Identity Bleeding (theo đúng kỹ thuật cộng đồng user cung cấp)

User cung cấp đúng thuật ngữ + 3 hướng khắc phục "Identity Bleeding"/"Concept Contamination" (cộng đồng SD nghiên cứu). Đánh giá tính khả thi cho pipeline này:

- **① Regional Prompter (multi-region LoRA)** — cần ĐÚNG cơ chế "regional attention masking" đã nói ở mục 13/15 là CHƯA làm, việc nặng (cần re-export UNet + hook cross-attention), CHƯA kiểm chứng cho MNN mobile. Không có gì mới giải quyết dễ hơn — vẫn treo y nguyên.
- **② LoRA Block Weight** — **ĐÃ LÀM**, khả thi thật vì áp dụng ở bước tiền xử lý offline (Python), không đụng native runtime.
- **③ Đổi trigger word độc nhất** — là khuyến nghị lúc TRAIN LoRA, không phải thứ code app sửa được cho 1 LoRA có sẵn tải về. Ghi nhận là khuyến nghị dùng, không code.

**Đã làm cho ②**: `tools/lora_block_weight.py` — scale riêng từng nhóm layer LoRA (`down_blocks`/`mid_block`/`up_blocks`/text-encoder, đúng key `.lora_up.weight`/`.lora_down.weight` chuẩn kohya_ss đã đọc từ `SafeTensor2MNN.hpp`) TRƯỚC khi đưa vào `convertAndRegisterPairModel()` có sẵn — KHÔNG sửa code C++ đã port (native chỉ nhận 1 hệ số/file LoRA, không có granularity theo layer — sửa ở đó rủi ro hơn nhiều so với tiền xử lý ở Python).

Mặc định: giữ `up_blocks`/`mid_block` (khuôn mặt) hệ số 1.0, giảm `down_blocks` (bố cục/trang phục — dễ tràn nhất theo nguyên lý chung) còn 0.5. Đã ghi rõ trong docstring: đây là **điểm khởi đầu theo nguyên lý chung cộng đồng, KHÔNG PHẢI số liệu khoa học chính xác đã kiểm chứng** — cần tự thử nghiệm build-test thật để tinh chỉnh cho từng cặp LoRA cụ thể.

Đã thêm gợi ý bước này vào `PairConvertDialog` (CharactersScreen.kt) — chạy trên PC/Colab TRƯỚC khi đặt LoRA vào `MangaLocal/loras/`, không chạy trên điện thoại (cần `torch`, không hợp lý chạy trên máy yếu).

---

## 29. Đánh giá 2 đề xuất mới — 1 không hoạt động, 1 đã hardcode cứng

**"BREAK" tự động chèn — KHÔNG hoạt động trong engine này, đã kiểm tra thật**: grep toàn bộ `TextEncoder.hpp`/`PromptProcessor.hpp` — không có xử lý nào cho từ khoá "BREAK" (mọi "break" tìm thấy đều là câu lệnh C++ thoát vòng lặp). "BREAK" là cú pháp A1111 WebUI tự viết thêm để cắt chunk token CLIP, KHÔNG phải tính năng CLIP/SD1.5 gốc. Quan trọng hơn: **kể cả trên chính A1111**, BREAK đơn thuần không tương đương Regional Prompter — tách vùng KHÔNG GIAN thật là do extension Regional Prompter tự thêm attention mask riêng, BREAK chỉ là quy ước cú pháp extension đó dùng để nhận biết ranh giới prompt. Nếu hardcode chèn "BREAK" vào đây, nó chỉ bị tokenize như 1 từ tiếng Anh vô nghĩa — KHÔNG tách vùng gì cả, chỉ thêm nhiễu. KHÔNG cài đặt.

**Hardcode negative prompt ẩn — ĐÃ CÀI ĐẶT, đúng đề xuất user**: trước đây `negativeRiskHints()` chỉ GỢI Ý cho LLM tự viết thêm từ khoá (LLM có thể quên). Đã thêm `appendHardcodedNegativeIfNeeded()` — nối CỨNG cụm `"fused bodies, deformed limbs, extra arms, extra legs, conjoined twins, monstrous body, messy anatomy, merged bodies"` (đúng các từ user đề xuất) vào negative prompt cuối cùng, TỰ ĐỘNG khi scene có ≥2 nhân vật — không phụ thuộc LLM có nhớ viết hay không, không cần user gõ tay. Chỉ áp dụng CÓ ĐIỀU KIỆN (≥2 người), không phải mọi ảnh — tránh làm loãng negative prompt cho panel 1 người.

---

## 30. [ĐÃ THAY THẾ bởi mục 31/32] Cách scale khung xương theo tuổi cũ — lỗi thời

**Ghi lại để biết lịch sử quyết định, KHÔNG dùng nữa**: bản đầu (`AgeCategory` enum CHILD/TEEN/ADULT + `PoseExtractor.rescaleLegsForAge()`) chỉ kéo giãn điểm chân theo **vector thẳng** từ gốc hông — user chỉ ra đúng: cách này **không giữ góc gập tự nhiên của khớp**, tạo ra tư thế phi lý về giải phẫu, và "profile theo nhóm tuổi" không đủ chính xác (cùng tuổi vẫn có thể cao/thấp/dậy thì sớm-muộn khác nhau). Đã bỏ hẳn `AgeCategory` enum khỏi vai trò dữ liệu chính, `rescaleLegsForAge()` không còn được gọi ở luồng chính — xem mục 31/32 cho hướng thay thế.

## 31. BoneProportions — dữ liệu tỷ lệ xương RIÊNG từng nhân vật (thay AgeCategory)

Theo đúng góp ý user: không dùng "1 trong 3 nhóm tuổi cứng" mà cho **mỗi nhân vật tự có tỷ lệ xương riêng** (`Character.boneProportions: BoneProportions`) — 6 hệ số nhân so với chuẩn người lớn (1.0): `torsoRatio` (thân), `upperArmRatio`/`forearmRatio` (tay), `upperLegRatio`/`lowerLegRatio` (chân), `headSizeRatio` (đầu — **ghi rõ CHƯA dùng được chính xác**, OpenPose-18 không có điểm đỉnh đầu). Giữ lại `BoneProportions.presetChild()/presetTeen()/presetAdult()` làm điểm khởi đầu NHANH (không phải số liệu y văn đã kiểm chứng), user tự tinh chỉnh tiếp bằng UI.

`PoseVariant` (pose_library.json) thêm `sourceProportions: BoneProportions` (mặc định = chuẩn người lớn) — ghi nhận tỷ lệ của NGƯỜI THẬT trong video/ảnh trích xuất ra variant đó, cần biết baseline này để tính đúng hệ số retarget. Cũng thêm `actionTags: List<String>` (user tự gõ nhãn tương tác lúc lưu, vd "hug"/"fight_lock" — mục 33, tự động chọn tư thế khớp kịch bản).

## 32. PoseRetargeter — thuật toán FK giữ góc gập (thay Bio-IK đầy đủ, theo đúng tài liệu cộng đồng user cung cấp)

Đã đánh giá 2 hướng user đưa ra (Bio-IK đầy đủ multi-joint constraint solver vs. FK giữ-góc-gập + lan truyền từ gốc) — chọn hướng NHẸ (FK), vì Bio-IK đầy đủ cần tự viết solver từ đầu (không có thư viện C++ nhẹ sẵn cho NDK Android), rủi ro kỹ thuật lớn hơn nhiều so với lợi ích thêm, đặc biệt khi cả dự án chưa build-test lần nào.

`PoseRetargeter.kt` (mới) — thuật toán: **giữ nguyên góc xoay gốc của từng đoạn xương (từ khung xương trích xuất gốc), chỉ đổi ĐỘ DÀI theo tỷ lệ nhân vật đích, lan truyền từ gốc thân (hip-center) ra tới đầu chi** — đúng nguyên lý "Angle Propagation + Root Translation" trong tài liệu cộng đồng user cung cấp. Thứ tự lan truyền: hip-center (gốc, giữ nguyên tuyệt đối) → neck (trục thân) → vai (offset theo neck mới) → khuỷu → cổ tay; và hip-center → hông → gối → mắt cá.

**GIỚI HẠN THÀNH THẬT so với Bio-IK đầy đủ (đã quyết định KHÔNG làm, ghi rõ để không quên)**:
- **KHÔNG giải "điểm chạm bắt buộc"** (bước 4 tài liệu cộng đồng — xoay bù trừ vai/hông để 1 điểm CHẠM ĐÚNG 1 điểm khác của người kia) — cần metadata "điểm A phải chạm điểm B" hoàn toàn chưa có trong `pose_library.json`. Bản hiện tại CHỈ làm đúng phần "giữ góc + đổi độ dài + lan truyền" (giá trị chính, giải quyết đúng "góc khớp phi lý" mà cách cũ gây ra), CHƯA đảm bảo 2 người vẫn chạm đúng nhau sau khi retarget nếu tỷ lệ lệch nhiều.
- `headSizeRatio` chưa dùng (giới hạn OpenPose-18 nhắc lại từ mục 30).
- CHƯA build-test — thuật toán viết dựa trên lượng giác phẳng chuẩn, tự tin về mặt toán học, nhưng chưa chạy thử trên thiết bị thật.

## 33. Đổi kiến trúc — chuyển đọc thư viện pose + chọn variant từ NATIVE sang KOTLIN (ĐANG LÀM DỞ)

**Phát hiện quan trọng khi làm mục 32**: retarget cần biết CHÍNH XÁC nhân vật nào ứng với vị trí nào trong mảng `people[]` của 1 `PoseVariant` — nhưng kiến trúc CŨ để native (`ip_adapter.cpp`) tự đọc `pose_library.json` VÀ tự chọn variant (`pose_templates::loadLibrary`/`pickVariant`), Kotlin chỉ gửi 1 CHUỖI TÊN template — native hoàn toàn không biết "người thứ mấy trong khung xương là nhân vật nào" (đúng lỗ hổng đã ghi ở mục 12 "skeleton không có tên").

**Giải pháp — ĐANG LÀM, CHƯA XONG**: chuyển việc đọc thư viện + chọn variant + retarget SANG KOTLIN (nơi CÓ SẴN thông tin `scene.characters` theo đúng thứ tự) — Kotlin gán tường minh `variant.people[i]` ↔ `scene.characters[i]`, gọi `PoseRetargeter.retargetVariant()`, rồi gửi THẲNG toạ độ khung xương ĐÃ RETARGET (mảng float phẳng) cho native — native giờ CHỈ VẼ, không tự đọc/chọn gì nữa. Đây là thay đổi CÓ LỢI KÉP: vừa giải quyết bài toán retarget theo tỷ lệ, vừa giải quyết luôn lỗ hổng danh tính đã treo từ mục 12.

**Việc cần làm tiếp (CHƯA XONG, đang dở khi viết mục này)**:
1. Đổi chữ ký JNI `sdTxt2ImgWithReferenceAndPose`: bỏ `jPoseTemplate`/`jPoseLibraryPath`/`jDesiredAngle`, thay bằng `jfloatArray jSkeletonData` (toạ độ đã retarget, phẳng).
2. Đơn giản hoá `ip_adapter.cpp`: xoá lời gọi `loadLibrary`/`pickVariant` khỏi hàm sinh ảnh (giữ struct `Skeleton`/`renderSkeletons` — vẫn cần để VẼ, chỉ bỏ phần ĐỌC THƯ VIỆN/CHỌN vì Kotlin đã làm).
3. `MangaPipeline`: gọi `storyManager.loadPoseLibrary()` + `PoseRetargeter.retargetVariant()` trước khi gọi native, dùng `Character.boneProportions` của từng nhân vật trong scene.
4. Cập nhật `NativeBridge.kt`/`ImagePipeline.kt` chữ ký tương ứng.
5. Mục 6.4 (Auto-select tư thế khớp kịch bản qua `actionTags`) — CHƯA làm, để sau khi xong 4 bước trên.

**Việc user yêu cầu nhưng ĐÃ ĐÁNH GIÁ KHÔNG THEO**: bỏ hẳn quy trình trích xuất pose trong APK, chạy retarget ở nơi khác — KHÔNG cần, vì retarget (lượng giác phẳng, không mạng nơ-ron) rẻ hơn hẳn 1 bước inference SD, chạy trên điện thoại hoàn toàn ổn, không có lý do đẩy ra ngoài.

---

## MỤC 33 — CẬP NHẬT: ĐÃ HOÀN THÀNH (trước đó ghi "đang làm dở")

5 bước còn lại đã xong hết:
1. **JNI đổi chữ ký** — `sdTxt2ImgWithReferenceAndPose` bỏ `poseTemplate`/`poseLibraryPath`/`desiredAngle` (3 string), thay bằng `skeletonData: FloatArray` (toạ độ đã retarget, phẳng). Đã đối chiếu khớp chính xác giữa `NativeBridge.kt` và `ip_adapter.cpp`.
2. **`ip_adapter.cpp` đơn giản hoá** — xoá hẳn `loadLibrary()`/`pickVariant()` (không cần nữa, Kotlin đã làm), thêm `parseSkeletonsFromFloatArray()` đọc trực tiếp mảng float từ Kotlin. Xoá include `nlohmann/json.hpp` không còn dùng trong file này.
3. **`MangaPipeline.resolveSkeletonData()`** (mới) — đọc `pose_library.json`, chọn variant khớp góc, gán TƯỜNG MINH `scene.characters[i]` ↔ `variant.people[i]` (giải quyết dứt điểm lỗ hổng "skeleton không có tên" — mục 12), gọi `PoseRetargeter.retargetVariant()`, flatten thành `FloatArray`. Đã nối vào cả `generatePanels()` và `regeneratePanel()` (2 chỗ gọi `generatePanel` trước đó dùng chữ ký cũ, đã sửa cả 2).
4. **`ImagePipeline.kt`/`NativeBridge.kt`** — chữ ký `generatePanel()` cập nhật đồng bộ.
5. Auto-select tư thế theo `actionTags` — VẪN CHƯA LÀM, để mục 6.4 sau.

**Tự phát hiện lúc sửa**: khi đổi JNI signature ở lượt trước, quên cập nhật 2 nơi gọi `imagePipeline.generatePanel()` trong `MangaPipeline.kt` (vẫn dùng tham số cũ `poseTemplate`/`poseLibraryPath`/`desiredAngle` không còn tồn tại) — sẽ lỗi biên dịch nếu không sửa. Đã sửa cả 2 ngay khi phát hiện, không để sót.

## 34. Import khung xương từ nguồn khác — ĐÃ XÂY

User hỏi: nếu muốn dùng thư viện tư thế từ nguồn khác (không tự trích xuất trong app) thì import được không.

**Trả lời + đã làm**: `StoryManager.importOpenPoseJson()` — chỉ hỗ trợ định dạng **OpenPose BODY_18 chuẩn** (18 điểm, đúng thứ tự CMU OpenPose gốc — TRÙNG KHỚP thứ tự OpenPose-18 đã dùng xuyên suốt app, không cần map lại). KHÔNG hỗ trợ BODY_25 (25 điểm, thứ tự khác hẳn) — từ chối rõ ràng thay vì đoán map sai, đúng nguyên tắc "không đề xuất giải pháp chưa kiểm chứng".

Input mong đợi: JSON chuẩn `{"people": [{"pose_keypoints_2d": [x,y,c, ...]}]}` — x,y là PIXEL theo ảnh gốc, user phải tự nhập đúng `canvasWidth`/`canvasHeight` để normalize về 0..1 (JSON OpenPose gốc không tự kèm kích thước canvas).

Kết quả import LUÔN đánh dấu `needsReview = true` — vì chưa qua 3 cơ chế validate tự động của chính app (mục 19: điểm tự tin thấp/thiếu khớp/giải phẫu dị thường), user nên tự xem lại trong `PoseEditorScreen` trước khi tin dùng.

UI: thêm card "Import từ nguồn khác" trong `PoseEditorScreen.kt` — chọn file `.json`, nhập kích thước ảnh gốc, đặt tên template, bấm import.

**CHƯA LÀM**: hỗ trợ định dạng khác ngoài OpenPose BODY_18 chuẩn (vd JSON riêng của ComfyUI/ControlNet Editor có thể có schema khác đôi chút, ảnh normalized sẵn thay vì pixel...) — nếu gặp thực tế cần, phải thêm parser riêng cho từng định dạng, không đoán chung 1 parser cho tất cả.

---

## 35. Mục 6.4 hoàn thành — tự động chọn tư thế khớp mô tả kịch bản

**Đã làm**: `MangaPipeline.guessPoseTemplate()` viết lại — TRƯỚC chỉ so khớp thô tên template (vd tên phải chứa chữ "hug" mới nhận ra là cảnh ôm), GIỜ ưu tiên so khớp `actionTags` thật (`StoryManager.listPoseTemplateTags()`) với từ khoá trong `scene.action`/`scene.description` — đáng tin hơn hẳn vì không phụ thuộc tên template có đặt "có nghĩa" hay không. Giữ lại cách so khớp tên cũ làm fallback cho thư viện CHƯA gắn tag (tương thích ngược, không phá dữ liệu cũ).

Cũng cho LLM thấy `actionTags` ngay trong `promptTemplate()` (dạng `tên_template [tag1,tag2]`) để LLM tự chọn thông minh hơn ở bước gợi ý đầu tiên (trước khi rơi về `guessPoseTemplate()` fallback).

**UI**: thêm ô nhập "Nhãn tương tác" trong `PoseEditorScreen.kt` lúc lưu variant — không bắt buộc, nhưng nếu để trống thì tư thế đó chỉ được auto-chọn qua so khớp tên (kém chính xác hơn).

Đến đây, toàn bộ danh sách việc ưu tiên đã liệt kê trong phiên này đã được xử lý hoặc ghi nhận rõ ràng lý do chưa làm. Việc CÒN LẠI DUY NHẤT, LỚN NHẤT: **build-test thật lần đầu trên GitHub Actions** — chưa có gì trong toàn bộ ~35 mục đã chạy thử thực tế.

---

## 36. Sửa lỗi build đầu tiên (CXX1429) + thêm input chọn model tuỳ chỉnh cho ESRGAN/YOLOv8-pose/MobileSAM

**Bối cảnh**: log build thật đầu tiên trên GitHub Actions (`build.yml #29`) fail ở bước CMake configure, KHÔNG phải lỗi trong code project — lỗi nằm trong chính `CMakeLists.txt` của MNN.

**① Lỗi CMake `[CXX1429]` — đã vá**:
- Nguyên nhân: `third_party/MNN/tools/cv/CMakeLists.txt:103` và `third_party/MNN/transformers/llm/engine/CMakeLists.txt:76` gọi `add_custom_command(TARGET ... POST_BUILD ...)` trên 2 target (`MNNOpenCV`, `llm`) được khai báo kiểu `OBJECT` library (nhánh `MNN_SEP_BUILD=OFF`, mặc định của project này) — CMake (mọi bản 3.9→4.x theo tài liệu chính thức, đã tra cứu xác nhận) không cho phép `PRE_BUILD`/`PRE_LINK`/`POST_BUILD` trên `OBJECT` library, đây là giới hạn vĩnh viễn không tự hết ở bản CMake mới hơn.
- Đã tra cứu xác nhận: đây là kiểu lỗi từng xảy ra trong chính MNN từ 2022 (khi đó ở target `MNNConverterTorch`) — lặp lại ở 2 target khác, có vẻ là lỗi lặp trong cách MNN viết CMakeLists.txt của họ, không phải lỗi trong file project viết.
- Cách sửa: thêm bước **"Vá CMakeLists.txt của MNN — OBJECT không được gắn PRE_BUILD/POST_BUILD (lỗi CXX1429)"** trong `build.yml`, chạy ngay sau bước clone MNN, trước khi Gradle/CMake chạy — dùng `sed` đổi đúng 2 dòng `add_library(MNNOpenCV OBJECT ...)` → `STATIC` và `add_library(llm OBJECT ...)` → `STATIC` (chỉ 2 dòng gây lỗi, không đụng gì khác trong repo MNN gốc). Có `grep -q` xác nhận đúng dòng trước khi `sed`, `exit 1` báo lỗi rõ ràng nếu MNN đổi cấu trúc khác đi (không âm thầm im lặng nếu vá trật).
- Không cần đổi cache key thủ công — key third-party cache đã dựa trên `hashFiles('.github/workflows/build.yml')`, sửa file này tự động làm cache cũ (chưa vá) hết hạn, ép clone lại + vá lại từ đầu.

**② Input chọn model tuỳ chỉnh cho ESRGAN/YOLOv8-pose/MobileSAM — đã thêm**:
- 3 script export (`export_yolo_pose.py --model_size`, `export_esrgan.py --checkpoint`, `export_mobilesam.py --checkpoint_url`) **đã sẵn CLI args** từ trước — chỉ chưa expose ra `workflow_dispatch.inputs` của `prepare_models.yml`, khiến 3 model này vẫn hardcode dù script bên dưới đã linh hoạt.
- Đã thêm 3 input mới vào `prepare_models.yml`: `yolo_pose_size` (dropdown `n/s/m/l/x`, mặc định `n`), `esrgan_checkpoint_url` (URL `.pth`, mặc định 4x-UltraSharp — đổi được sang RealESRGAN_x4plus hay bản finetune khác cùng họ RRDBNet vì `spandrel` tự nhận diện kiến trúc), `mobilesam_checkpoint_url` (URL `.pt`, mặc định checkpoint gốc MobileSAM).
- ControlNet-Pose/IP-Adapter vốn đã có input riêng từ trước (`controlnet_model`, `ip_adapter_repo`) — không đổi.
- Kết quả: **cả 6 model trong `prepare_models.yml` giờ đều chọn được qua input khi bấm "Run workflow"**, không còn model nào bắt buộc sửa file YAML mới đổi được.

**CHƯA LÀM / rủi ro còn lại**:
- Patch CMake trên là **thao tác đầu tiên chưa build-test thành công** — mới xác nhận đúng vị trí lỗi + đúng cách sửa chuẩn qua tài liệu CMake chính thức, chưa có lần chạy `build.yml` nào PASS hẳn để xác nhận sau khi vá không phát sinh lỗi CXX/link mới ở bước sau (build còn dài, MNN + tokenizers-cpp + xtensor + sd_engine đều chưa qua vòng biên dịch thật nào).
- `mnn_check` (bản MNN clone để đối chiếu số dòng lúc vá) là **bản `main` mới nhất tại thời điểm viết mục này** — vì `build.yml` clone `--depth 1` không ghim version (rủi ro đã ghi ở mục trước), số dòng/cấu trúc file có thể lệch giữa lần clone này và lần CI thực sự chạy. Bước `grep -q` trong patch đã có để tự phát hiện nếu MNN đổi cấu trúc (không match dòng cần thay → fail rõ ràng thay vì vá sai âm thầm), nhưng CHƯA ghim version MNN cụ thể để đảm bảo tái lập — vẫn là rủi ro treo, chưa xử lý ở mục này.

---

## 37. Tính năng Local/Remote GPU routing (Colab/GPU thuê ngoài)

**Kiến trúc tổng quan** (`BackendRouter.kt`, `RemoteGenerationClient.kt`, wiring trong `MangaPipeline.kt`, UI trong `SettingsScreen.kt`):

**① Mô hình bảo mật — đã thống nhất rõ với user, KHÔNG quảng cáo quá mức**:
- Mã hoá hybrid RSA-OAEP (bọc key) + AES-256-GCM (payload) giữa APK và tiến trình Python trên server — chống được **trung gian mạng** (tunnel provider như ngrok, ISP, proxy công ty) vì lớp mã hoá này độc lập với TLS.
- **KHÔNG** chống được chính **chủ hạ tầng GPU thuê** (Google/chủ máy RunPod-Vast.ai) — họ có quyền truy cập VM đang chạy, không có cách nào phần mềm thuần ngăn được (đã giải thích kỹ trong hội thoại: không phải vấn đề "tốc độ soi kịp hay không", là quyền truy cập hạ tầng vốn có). Chỉ Confidential-Computing GPU (TEE phần cứng, `RemoteSecurityTier.CONFIDENTIAL_COMPUTING`) mới chống được — cờ đã có sẵn trong model, **CHƯA triển khai thật** ở bản này.
- Xác thực server qua fingerprint TOFU (Trust On First Use, giống Signal safety number) — user tự đối chiếu ở nút "Kiểm tra kết nối".

**② Local/Remote routing — 2 chế độ, ranh giới rõ ràng**:
- **MANUAL** (`ManualBackendRouter`): thứ tự ưu tiên — (1) override tay riêng từng panel ở Gallery Review, thắng tuyệt đối > (2) `manualRoutingRules` khai báo trước ở Settings (theo tên nhân vật hoặc từ khoá cảnh, rule đứng trên thắng khi mâu thuẫn, xử lý bằng code Kotlin thuần deterministic — KHÔNG qua LLM, vì MANUAL nghĩa là user muốn chắc chắn 100%) > (3) `defaultBackend` mặc định chung.
- **AUTO** (`AutoBackendRouter`): dùng CHÍNH LLM local (MNN-LLM, cùng model dùng parse kịch bản) đọc `autoRoutingPolicyPrompt` — văn bản tiếng Việt tự nhiên do NGƯỜI DÙNG tự viết (vd "nhân vật Lan chỉ local, còn lại remote"), LLM tự quyết định local/remote cho từng panel dựa theo scene/nhân vật đưa vào prompt. **QUAN TRỌNG — đã sửa đúng theo yêu cầu user**: quyết định AUTO hoàn toàn KHÔNG hardcode theo tên nhân vật/scene ở tầng Kotlin — mọi tiêu chí đều nằm trong prompt gửi cho LLM, tầng code chỉ có 1 fallback text mặc định khi user chưa viết gì (an toàn: nhạy cảm→local). Fail-safe: parse JSON lỗi/LLM lỗi/chưa cấu hình remote → luôn về LOCAL, không bao giờ fail-open sang REMOTE.
- Override tay ở Gallery Review LUÔN thắng tuyệt đối bất kể MANUAL hay AUTO (áp dụng ở 1 chỗ duy nhất trong `MangaPipeline.generatePanels()` trước khi gọi `router.decide()`).

**③ Giới hạn tính năng đã biết (không phải bảo mật)**: remote server tham chiếu (`tools/remote_server/app.py` — CHƯA VIẾT, xem mục CHƯA LÀM) dự kiến chỉ hỗ trợ txt2img cơ bản ban đầu, chưa hỗ trợ IP-Adapter+ControlNet-Pose (giữ nhất quán nhân vật) — `MangaPipeline` tự phát hiện panel cần augmented pipeline mà đang route REMOTE thì tự chuyển về LOCAL kèm log rõ lý do (không phải fallback bảo mật, chỉ là feature-availability).

**CHƯA LÀM**:
- `tools/remote_server/app.py` (FastAPI, RSA keypair, giải mã AES, gọi diffusers SD1.5, không log/không lưu đĩa) + Colab notebook mẫu + hướng dẫn chạy trên RunPod/Vast.ai — **CHƯA VIẾT**, tính năng remote hiện tại KHÔNG chạy được thật (client đã sẵn sàng gọi, nhưng chưa có server để gọi tới).
- Chưa build-test — cả tính năng routing lẫn bug `LLMParser.init()` vừa sửa đều chưa qua compile thật (không có kotlinc trong sandbox để xác nhận), chỉ đã sanity-check cân bằng ngoặc bằng script.
- Chưa thêm UI hiển thị `resolvedBackend`/`routingReason` của panel đã sinh ở Gallery Review (model đã có field, UI đọc field này chưa làm).
- Dropdown chọn tên nhân vật có sẵn khi tạo `manualRoutingRules` (hiện là free-text, dễ gõ sai tên lệch với kịch bản khiến rule không khớp) — chưa làm, cần nối với danh sách Character của Story hiện tại.

---

## 38. Remote server tham chiếu (`tools/remote_server/`) — tính năng Remote GPU giờ chạy được thật

Hoàn thiện phần còn thiếu ở mục 37 (`RemoteGenerationClient.kt` trước đó có sẵn client nhưng chưa có server để gọi tới):

- **`app.py`**: FastAPI, RSA-2048 keypair ephemeral sinh mới mỗi lần chạy (không ghi đĩa), endpoint `GET /pubkey` (lấy public key + để client tự tính fingerprint) và `POST /generate` (Bearer token auth, giải mã hybrid RSA-OAEP+AES-256-GCM đúng khớp với `RemoteGenerationClient.kt`, chạy `diffusers.StableDiffusionPipeline`, mã lại kết quả bằng cùng AES key + IV mới cho chiều về). Không log nội dung prompt, không lưu ảnh/prompt ra đĩa, `del` biến plaintext sớm nhất có thể (ghi rõ trong docstring: đây là best-effort, Python không đảm bảo wipe RAM cứng như C — không quảng cáo quá).
- **`colab_remote_server.ipynb`**: notebook Colab tự chứa — nhúng thẳng toàn bộ nội dung `app.py` qua `%%writefile` (đã viết script xác nhận nội dung nhúng khớp 100% byte-for-byte với file gốc), cài `pyngrok` mở tunnel, in ra Base URL + nhắc đối chiếu fingerprint. Chạy được hoàn toàn từ trình duyệt điện thoại, không cần upload file gì (nhất quán với cách `prepare_models.yml` đã làm ở mục trước — "không cần PC").
- **`requirements.txt`**, **`README.md`** (2 cách triển khai: Colab miễn phí vs GPU thuê ngoài trả phí).

**CHƯA LÀM / rủi ro còn treo**:
- **Chưa build-test/run-test thật** — cả `app.py` lẫn notebook mới chỉ qua `py_compile` (cú pháp hợp lệ) và kiểm tra JSON nhúng khớp, CHƯA chạy thật trên Colab để xác nhận toàn bộ chuỗi mã hoá RSA+AES giữa `RemoteGenerationClient.kt` (Kotlin) và `app.py` (Python) thực sự tương thích byte-for-byte (padding OAEP, GCM tag length 128-bit, encoding DER... đã cố tình khớp theo chuẩn nhưng chưa có lần chạy thật nào xác nhận).
- Chưa hỗ trợ LoRA ở remote server (đã ghi trong README, người dùng tự thêm nếu cần).
- Chưa hỗ trợ Confidential Computing thật (cờ có sẵn trong model, server chưa có code nhánh riêng cho tier này).
- Chưa có UI hiển thị `resolvedBackend`/`routingReason` ở Gallery Review (vẫn còn treo từ mục 37).

---

## 39. Đơn giản hoá notebook Colab — 1-click thật hơn (Cloudflare Tunnel thay ngrok)

User hỏi đúng điểm yếu: notebook cũ 12 cell + bắt tự đăng ký tài khoản ngrok mới lấy được token — chưa "1 click" như tên gọi. Đã sửa:

- **Đổi ngrok → Cloudflare Tunnel (`cloudflared tunnel --url`, chế độ quick tunnel)** — tải thẳng binary từ GitHub release Cloudflare chính chủ, **không cần đăng ký tài khoản/token nào**, ra ngay URL `*.trycloudflare.com`.
- **Auth token tự sinh** bằng `secrets.token_urlsafe(24)` — không bắt user tự nghĩ/gõ mật khẩu.
- Gộp 12 cell → còn 3 code cell — dùng **Runtime > Run all** chạy hết 1 lượt.
- Chỉ còn ĐÚNG 1 bước tay không thể tự động hoá được: chọn GPU runtime (giới hạn nền tảng Colab, notebook không tự đổi runtime của chính nó).
- Đã xác nhận lại bằng script: nội dung `app.py` nhúng trong Cell 2 vẫn khớp 100% byte-for-byte với `tools/remote_server/app.py` gốc sau khi viết lại toàn bộ notebook.

**Làm rõ luôn (user hỏi)**: `app.py` KHÔNG hardcode riêng cho Colab — không có API nào của Colab trong file này, chạy y hệt trên RunPod/Vast.ai/VPS riêng/máy cá nhân có GPU (`pip install -r requirements.txt && python app.py ...`). Notebook chỉ là lớp vỏ tiện lợi bọc quanh đúng file đó cho riêng Colab (vì Colab cần cách cài đặt + mở tunnel khác các nơi khác, không phải vì server logic khác).

**CHƯA LÀM**: vẫn như mục 38 — toàn bộ chuỗi (kể cả bản Cloudflare Tunnel mới) chưa chạy thật trên Colab lần nào, chỉ mới kiểm tra cấu trúc JSON + nội dung nhúng khớp.

---

## 40. Fix build #34 — ghim version xtensor-stack (đúng rủi ro đã cảnh báo trước, nay xảy ra thật)

**Log build #34** đã xác nhận bản vá CMake ở mục 36 có tác dụng thật — build vượt qua hẳn bước CMake configure, biên dịch được 1021/1049 file (kể cả Rust/tokenizers-cpp rất nặng), mới fail ở lỗi HOÀN TOÀN KHÁC:
```
sd_engine/Pipeline.hpp:15:10: fatal error: 'xtensor/xadapt.hpp' file not found
```

**Nguyên nhân xác nhận bằng cách tự clone kiểm tra** (không đoán mù): `git clone --depth 1` không ghim version với xtensor trong `build.yml` kéo về nhánh `main` mới nhất — mà xtensor **đã tái cấu trúc thư mục header** kể từ bản `0.26.0`: `include/xtensor/xadapt.hpp` (phẳng, code project + local-dream gốc dùng kiểu này) bị dời vào `include/xtensor/containers/xadapt.hpp` (và tương tự cho các header khác). Đây đúng là rủi ro **"clone không ghim version"** đã ghi nhận từ mục 36, giờ mới thực sự xảy ra ở phần xtensor (trước đó MNN clone cũng không ghim nhưng may mắn chưa gặp vấn đề tương tự).

**Cách sửa — ghim 4 version xtensor-stack tương thích nhau** (tra bảng dependency chính chủ trên GitHub từng repo, xác nhận bằng cách tự `git show <tag>:<path>` kiểm tra từng header có tồn tại thật không, không suy đoán):
| Thư viện | Tag ghim | Vì sao chọn |
|---|---|---|
| `xtensor` | `0.25.0` | Bản MỚI NHẤT còn layout phẳng (`0.26.0` trở đi đã đổi) |
| `xtl` | `0.7.7` | Khớp yêu cầu `^0.7.0` của xtensor 0.25.0 |
| `xsimd` | `10.0.0` | Khớp yêu cầu `^10.0.0` của xtensor 0.25.0 |
| `xtensor-blas` | `0.21.0` | Khớp yêu cầu `^0.25.0` của xtensor (theo bảng dependency của chính xtensor-blas) |

Đã verify tất cả 9 header xtensor (`xadapt/xarray/xbuilder/xeval/xmanipulation/xmath/xrandom/xview/xio.hpp`) + `xlinalg.hpp` (xtensor-blas) mà code project thực sự `#include` đều tồn tại đúng vị trí phẳng ở các tag đã ghim — verify bằng `git show <tag>:<path>`, không chỉ tin bảng compatibility suông.

**Sửa trong `build.yml`**: đổi 4 dòng `git clone --depth 1 <url>` (không ghim) thành `git clone --depth 1 --branch <tag> <url>` (ghim cứng), đặt tên thư mục đích tường minh (`xtl`, `xsimd`, `xtensor`, `xtensor-blas`) để không phụ thuộc tên mặc định của git.

**MNN vẫn CHƯA ghim** (rủi ro tương tự có thể xảy ra lần nữa ở MNN, đặc biệt 2 target `MNNOpenCV`/`llm` vừa vá ở mục 36 — nếu MNN đổi cấu trúc CMakeLists.txt lần nữa, bước `grep -q` trong bản vá sẽ tự báo lỗi rõ ràng thay vì âm thầm sai, nhưng vẫn chưa ghim version để tránh hẳn rủi ro này) — cân nhắc ghim ở lần build kế tiếp nếu ổn định.

**CHƯA LÀM**: build #34 chưa chạy lại với bản ghim version này — chưa xác nhận đây là lỗi CUỐI CÙNG hay còn lỗi biên dịch nào khác ở các file .cpp còn lại (chỉ 3/1049 file bị fail ở lần build #34: `mnn_diffusion_pipeline.cpp`, còn `yolo_pose_wrapper.cpp`/`yolo_wrapper.cpp` build tiếp bình thường theo log nên không liên quan xtensor).
