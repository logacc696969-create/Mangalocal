"""
export_ipa_controlnet_unet.py — Xuất 1 bản UNet SD1.5 đã gộp sẵn
IP-Adapter (giữ nhân vật) + ControlNet-OpenPose (giữ tư thế) thành ONNX,
rồi convert sang .mnn để MangaLocal dùng.

CHẠY TRÊN MÁY TÍNH (không phải điện thoại), cần Python + GPU khuyến khích
(chạy CPU vẫn được, chỉ chậm hơn — đây là việc làm 1 LẦN, không phải lúc
sinh ảnh).

API dùng trong script này đều là API CHÍNH THỨC của `diffusers`, đã xác
nhận qua tài liệu/source thật (không đoán):
  - ControlNetModel, StableDiffusionControlNetPipeline
  - UNet2DConditionModel.forward(..., down_block_additional_residuals,
    mid_block_additional_residual, added_cond_kwargs) — xác nhận từ chính
    source code diffusers (unet_2d_condition.py)
  - pipe.load_ip_adapter(...) — xác nhận từ tài liệu chính thức HuggingFace

ĐIỀU CHƯA KIỂM CHỨNG (tự dò lúc chạy, KHÔNG hardcode để tránh sai):
  - Shape chính xác của image_embeds do IP-Adapter image_proj_model sinh
    ra (tài liệu không nêu con số cụ thể cho SD1.5) — script này TỰ chạy
    thử 1 lần để lấy đúng shape thật, không đoán số.

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_unet.py \
        --base_model runwayml/stable-diffusion-v1-5 \
        --output_dir ./exported \
        --image_size 512
"""
import argparse
import os

import numpy as np
import torch
import torch.nn as nn
from diffusers import ControlNetModel, StableDiffusionControlNetPipeline


class AugmentedUNet(nn.Module):
    """Bọc UNet + ControlNet thành 1 module duy nhất để export ONNX 1 lần.

    KHÔNG tự viết lại toán học của UNet/ControlNet — chỉ gọi đúng API thật
    của diffusers (forward() có sẵn), nối kết quả ControlNet vào UNet đúng
    theo cách StableDiffusionControlNetPipeline làm nội bộ (xem
    down_block_additional_residuals/mid_block_additional_residual trong
    source diffusers, đã xác nhận thật).
    """

    def __init__(self, unet, controlnet):
        super().__init__()
        self.unet = unet
        self.controlnet = controlnet

    def forward(self, sample, timestep, encoder_hidden_states, control_hint, ip_image_embeds):
        down_res, mid_res = self.controlnet(
            sample,
            timestep,
            encoder_hidden_states=encoder_hidden_states,
            controlnet_cond=control_hint,
            return_dict=False,
        )
        noise_pred = self.unet(
            sample,
            timestep,
            encoder_hidden_states=encoder_hidden_states,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            # image_embeds bọc trong list vì diffusers hỗ trợ nhiều IP-Adapter
            # cùng lúc (list of tensors) — dùng 1 phần tử ở đây.
            added_cond_kwargs={"image_embeds": [ip_image_embeds]},
            return_dict=False,
        )[0]
        return noise_pred


def probe_ip_adapter_embed_shape(pipe, device):
    """Tự dò shape thật của image_embeds bằng 1 lần chạy thử với ảnh giả
    (toàn màu xám), thay vì đoán con số — tránh lặp lỗi 'hardcode chưa
    kiểm chứng' đã rút kinh nghiệm trong dự án này."""
    from PIL import Image

    dummy_image = Image.new("RGB", (224, 224), color=(128, 128, 128))
    with torch.no_grad():
        embeds = pipe.prepare_ip_adapter_image_embeds(
            ip_adapter_image=[dummy_image],
            ip_adapter_image_embeds=None,
            device=device,
            num_images_per_prompt=1,
            do_classifier_free_guidance=False,
        )
    # prepare_ip_adapter_image_embeds trả về list (1 phần tử mỗi IP-Adapter)
    embed_tensor = embeds[0]
    print(f"[probe] image_embeds shape THẬT (dò được, không đoán): {tuple(embed_tensor.shape)}")
    return embed_tensor


class ImageEncoderForExport(nn.Module):
    """Bọc CLIP image encoder + lớp projection của IP-Adapter thành 1 module
    độc lập — để chạy trên điện thoại (encode ảnh nhân vật -> image_embeds)
    mà không cần mang theo toàn bộ pipeline. Dùng đúng 2 thành phần thật
    (pipe.image_encoder, pipe.unet.encoder_hid_proj.image_projection_layers[0])
    đã xác nhận qua tài liệu chính thức diffusers, không tự viết lại toán học
    CLIP hay projection."""

    def __init__(self, image_encoder, image_projection_layer):
        super().__init__()
        self.image_encoder = image_encoder
        self.image_projection_layer = image_projection_layer

    def forward(self, pixel_values):
        # output_hidden_states=True cho biến thể "Plus" (patch embeddings);
        # bản ip-adapter_sd15.bin thường (không phải Plus) dùng embedding
        # gộp (pooler_output) — dùng hidden_states[-2] là lựa chọn phổ biến
        # nhất trong cộng đồng cho tương thích rộng, NHƯNNG đây là điểm cần
        # đối chiếu lại với đúng loại checkpoint bạn dùng (ip-adapter thường
        # vs ip-adapter-plus) nếu ảnh ra không giống nhân vật tham chiếu.
        outputs = self.image_encoder(pixel_values, output_hidden_states=True)
        image_embeds = outputs.image_embeds  # CLIPVisionModelWithProjection output chuẩn
        projected = self.image_projection_layer(image_embeds)
        return projected


def export_image_encoder(pipe, output_dir, device):
    print("Đang export CLIP image encoder + projection riêng (ip_image_encoder.onnx)...")
    image_proj_layer = pipe.unet.encoder_hid_proj.image_projection_layers[0]
    encoder_module = ImageEncoderForExport(pipe.image_encoder, image_proj_layer).to(device).eval()

    example_pixels = torch.randn(1, 3, 224, 224, device=device)  # kích thước chuẩn CLIP ViT
    onnx_path = os.path.join(output_dir, "ip_image_encoder.onnx")
    with torch.no_grad():
        output = encoder_module(example_pixels)
        torch.onnx.export(
            encoder_module, example_pixels, onnx_path,
            input_names=["pixel_values"], output_names=["image_embeds"],
            opset_version=17, do_constant_folding=True,
        )
    print(f"  -> {onnx_path}, output shape: {tuple(output.shape)}")
    return output


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="runwayml/stable-diffusion-v1-5")
    ap.add_argument("--controlnet_model", default="lllyasviel/control_v11p_sd15_openpose")
    ap.add_argument("--ip_adapter_repo", default="h94/IP-Adapter")
    ap.add_argument("--ip_adapter_weight", default="ip-adapter_sd15.bin")
    ap.add_argument("--output_dir", default="./exported")
    ap.add_argument("--image_size", type=int, default=512)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_size = args.image_size // 8

    print("Đang tải ControlNet-OpenPose...")
    controlnet = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)

    print("Đang tải base SD1.5 + gắn ControlNet...")
    pipe = StableDiffusionControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet, torch_dtype=torch.float32, safety_checker=None
    )

    print(f"Đang nạp IP-Adapter ({args.ip_adapter_repo}/{args.ip_adapter_weight})...")
    pipe.load_ip_adapter(args.ip_adapter_repo, subfolder="models", weight_name=args.ip_adapter_weight)
    pipe.set_ip_adapter_scale(1.0)  # scale thật sẽ chỉnh lúc chạy trên điện thoại, ở đây để mặc định
    pipe.to(device)

    # Dò shape thật của image_embeds — KHÔNG đoán.
    example_embeds = probe_ip_adapter_embed_shape(pipe, device)

    # Export riêng CLIP image encoder để dùng lúc runtime (encode ảnh nhân
    # vật tham chiếu trên điện thoại).
    export_image_encoder(pipe, args.output_dir, device)

    print("Đang lắp AugmentedUNet (UNet + ControlNet gộp)...")
    augmented = AugmentedUNet(pipe.unet, pipe.controlnet).to(device).eval()

    # Input mẫu để trace ONNX — dùng đúng shape thật sẽ dùng lúc infer.
    example_sample = torch.randn(1, 4, latent_size, latent_size, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_encoder_hidden = torch.randn(1, 77, 768, device=device)  # CLIP SD1.5, xác nhận qua TextEncoder.hpp đã port
    example_control_hint = torch.randn(1, 3, args.image_size, args.image_size, device=device)

    onnx_path = os.path.join(args.output_dir, "unet_ipa_controlnet.onnx")
    print(f"Đang export ONNX -> {onnx_path} (có thể mất vài phút)...")
    with torch.no_grad():
        torch.onnx.export(
            augmented,
            (example_sample, example_timestep, example_encoder_hidden, example_control_hint, example_embeds),
            onnx_path,
            input_names=["sample", "timestep", "encoder_hidden_states", "control_hint", "ip_image_embeds"],
            output_names=["out_sample"],
            opset_version=17,
            do_constant_folding=True,
            # KHÔNG dùng dynamic_axes — MNN trên điện thoại chạy nhanh hơn
            # với shape cố định; nếu cần nhiều size ảnh, export nhiều bản.
        )

    print("\n=== XONG PHẦN ONNX ===")
    print(f"Shape ip_image_embeds thật đã dò được: {tuple(example_embeds.shape)}")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, 'unet_ipa_controlnet.mnn')} \\")
    print(f"      --bizCode biz")
    print(f"  MNNConvert -f ONNX --modelFile {os.path.join(args.output_dir, 'ip_image_encoder.onnx')} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, 'ip_image_encoder.mnn')} \\")
    print(f"      --bizCode biz")
    print("\nSau khi convert xong, đổi tên file .mnn kết quả thành 'unet.mnn' trong")
    print("thư mục model tương ứng, và dùng model_manifest.json với pipeline")
    print("'sd15_cpu_augmented' (xem ip_adapter.cpp phía MangaLocal).")
    print(f"\nQUAN TRỌNG: ghi lại số {example_embeds.shape[1]} (số token) và "
          f"{example_embeds.shape[2]} (chiều embedding) — cần khớp đúng trong "
          f"ip_adapter.cpp (hằng số IP_EMBED_TOKENS/IP_EMBED_DIM).")


if __name__ == "__main__":
    main()
