"""
export_yolo_pose.py — Export YOLOv8n-pose (Ultralytics, pretrained COCO
keypoints) sang ONNX, để prepare_models.yml tự convert tiếp sang .mnn bằng
`mnnconvert` (giống quy ước export_sd15_base.py/export_ipa_controlnet_unet.py
— script Python chỉ lo tới ONNX, việc gọi mnnconvert nằm trong workflow YAML).

TẠI SAO CÓ FILE NÀY (mục 19 TECHNICAL_STATUS.md — thay MediaPipe Pose
bằng YOLOv8-Pose): MediaPipe Pose Landmarker vốn thiết kế cho 1 người/khung,
đã xác nhận qua tài liệu + báo cáo lỗi thật (GitHub issue #5806) rằng dễ
"ảo giác" khớp sai khi nhiều người occlusion nhau (đúng cảnh ôm/vật lộn
MangaLocal cần nhất). YOLOv8-pose là kiến trúc single-stage khác hẳn
(không phải "detect người rồi crop-riêng-từng-người" như MediaPipe) — dự
án ĐÃ CÓ hạ tầng JNI đọc output YOLOv8 (yolo_wrapper.cpp, dù bản digest
"person" hiện tại cũng CHƯA có pipeline convert model thật — file này
cũng là lần đầu dự án có 1 pipeline convert YOLO hoàn chỉnh, không chỉ
riêng cho pose).

Output tensor ONNX của YOLOv8-pose (đã tra cứu xác nhận qua nhiều nguồn
Ultralytics chính thức, KHÔNG đoán): shape [1, 56, 8400] — 8400 = số
candidate box (ứng với input 640x640), 56 = 4 (cx,cy,w,h) + 1 (conf) +
17*3 (x,y,visibility mỗi keypoint COCO-17 chuẩn Ultralytics). Native
(yolo_pose_wrapper.cpp) tự transpose + decode + NMS, xem file đó.

Cài đặt:
    pip install ultralytics onnx

Chạy:
    python export_yolo_pose.py --model_size n --output_dir ./exported_yolo_pose

model_size: n (nano, ~3.3M tham số, khuyến nghị cho mobile) | s | m | l | x
"""
import argparse
import os
import shutil


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_size", default="n", choices=["n", "s", "m", "l", "x"],
                         help="n=nano (khuyến nghị mobile, nhanh nhất) .. x=xlarge (chính xác nhất, chậm nhất)")
    parser.add_argument("--imgsz", type=int, default=640,
                         help="Kích thước input vuông — 640 là chuẩn Ultralytics, ảnh sẽ letterbox-resize về đây trước khi vào model")
    parser.add_argument("--output_dir", default="./exported_yolo_pose")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    from ultralytics import YOLO

    model_name = f"yolov8{args.model_size}-pose.pt"
    print(f"Tải/dùng model pretrained: {model_name} (tự tải từ Ultralytics release nếu chưa có)")
    model = YOLO(model_name)

    print(f"Export sang ONNX (imgsz={args.imgsz}, không kèm NMS — NMS tự viết ở native để kiểm soát chắc chắn 100% logic)...")
    # opset 12 — đủ ổn định cho hầu hết converter, khớp mức dùng trong
    # export_sd15_base.py để nhất quán trong cùng dự án.
    exported_path = model.export(format="onnx", imgsz=args.imgsz, opset=12, simplify=True, nms=False)

    dest = os.path.join(args.output_dir, "yolov8_pose.onnx")
    shutil.move(exported_path, dest)
    print(f"Xong: {dest}")
    print("\nBƯỚC TIẾP THEO (đã tự động trong prepare_models.yml, chỉ cần chạy tay nếu tự convert):")
    print(f"  mnnconvert -f ONNX --modelFile {dest} --MNNModel {os.path.join(args.output_dir, 'yolov8_pose.mnn')} --bizCode biz")


if __name__ == "__main__":
    main()
