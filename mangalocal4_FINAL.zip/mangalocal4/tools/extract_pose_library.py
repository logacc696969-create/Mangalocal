"""
extract_pose_library.py — Trích khung xương từ ẢNH/VIDEO tham khảo, dùng
YOLOv8-pose (Ultralytics) — THAY MediaPipe Pose trước đây (mục 19
TECHNICAL_STATUS.md).

TẠI SAO ĐỔI: MediaPipe Pose Landmarker vốn thiết kế cho 1 người/khung — đã
xác nhận qua tài liệu chính thức + báo cáo lỗi GitHub thật (issue #5806:
"ảo giác" khớp sai khi bị occlusion nhiều người) rằng không đáng tin cho
đúng cảnh MangaLocal cần nhất: nhiều người ôm/vật lộn/quần nhau. YOLOv8-
pose (kiến trúc single-stage, không tách "detect người rồi crop-riêng-
từng-người" như MediaPipe) phù hợp hơn cho occlusion nhiều người.

ĐÁNH ĐỔI PHẢI CHẤP NHẬN: YOLOv8-pose CHỈ xuất 2D (x, y, confidence) —
KHÔNG có z-depth như MediaPipe. Heuristic ước lượng góc nhìn (estimate_angle)
và thứ tự vẽ (ai đè lên ai) trước đây dùng z giờ phải đổi sang proxy 2D kém
chính xác hơn (độ lệch ngang mũi so với vai, và vị trí y của box) — xem ghi
chú tại các hàm liên quan. CHƯA build-test để biết mức sai khác thực tế.

3 CƠ CHẾ CẢNH BÁO TỰ ĐỘNG (theo yêu cầu, giống hệt logic Kotlin
PoseExtractor.kt — 2 bên PHẢI đồng bộ, sửa 1 bên phải sửa bên kia):
  Lỗi 1 — điểm tự tin (confidence) bất kỳ khớp quan trọng < 0.5 (che khuất).
  Lỗi 2 — số khớp visible (>=0.5) < 17 (thiếu chi).
  Lỗi 3 — khoảng cách giữa 2 khớp liền kề vượt 3x đơn vị tham chiếu vai-hông
          (ngưỡng kinh nghiệm, không phải số đo khoa học chính xác).

Cài đặt:
    pip install ultralytics pillow numpy opencv-python

Chạy (ảnh tĩnh):
    python extract_pose_library.py --input_dir ./pose_photos --output pose_library.json

Chạy (có cả video, tự động lấy mẫu frame):
    python extract_pose_library.py --input_dir ./pose_photos --output pose_library.json --video_fps_sample 2

Cấu trúc thư mục input mong đợi (trộn ảnh VÀ video đều được):
    pose_photos/
      single_standing/
        photo1.jpg
      two_hugging/
        photo1.jpg
        fight_scene.mp4   (video vật lộn — tự lấy mẫu N frame/giây)
      two_fighting/
        clip.mp4
    (tên thư mục con = tên template, khớp với id dùng trong
    ip_adapter.cpp pose_templates::loadLibrary())
"""
import argparse
import json
import math
import os

import cv2
import numpy as np

# COCO-17 (chuẩn Ultralytics) -> chỉ số OpenPose-18 dùng xuyên suốt app.
# GIỐNG HỆT coco17ToOpenPose18 trong PoseExtractor.kt — 2 bên PHẢI đồng bộ.
COCO17_TO_OPENPOSE18 = {
    0: 0,
    6: 2, 8: 3, 10: 4,
    5: 5, 7: 6, 9: 7,
    12: 8, 14: 9, 16: 10,
    11: 11, 13: 12, 15: 13,
    2: 14, 1: 15,
    4: 16, 3: 17,
}

BONE_CONNECTIONS = [
    (1, 2), (2, 3), (3, 4),
    (1, 5), (5, 6), (6, 7),
    (1, 8), (8, 9), (9, 10),
    (1, 11), (11, 12), (12, 13),
]
IMPORTANT_IDX = [3, 4, 6, 7, 9, 10, 12, 13]  # khuỷu/cổ tay/gối/mắt cá cả 2 bên


def estimate_angle(person_coco):
    """Ước lượng góc nhìn — ĐÃ ĐỔI heuristic (không còn z-depth). Dùng độ
    lệch ngang mũi so với trung điểm 2 vai. KÉM CHÍNH XÁC HƠN bản z-depth
    cũ, chấp nhận đánh đổi để có độ tin cậy multi-person tốt hơn."""
    nose, right_sh, left_sh = person_coco[0], person_coco[2], person_coco[5]
    if not (nose["visible"] and right_sh["visible"] and left_sh["visible"]):
        return "unknown"
    mid_x = (right_sh["x"] + left_sh["x"]) / 2
    shoulder_width = abs(right_sh["x"] - left_sh["x"]) + 1e-6
    ratio = (nose["x"] - mid_x) / shoulder_width
    if abs(ratio) < 0.15:
        return "front"
    return "side_left" if ratio > 0 else "side_right"


def validate_person(person_coco):
    """3 cơ chế cảnh báo tự động — xem docstring đầu file."""
    reasons = []

    low_conf = [i for i in IMPORTANT_IDX
                if person_coco[i]["visible"] and person_coco[i].get("confidence", 1.0) < 0.5]
    if low_conf:
        reasons.append(f"Điểm tự tin thấp ở {len(low_conf)} khớp (có thể do che khuất) — kiểm tra kỹ vùng tay/chân")

    visible_count = sum(1 for idx, p in enumerate(person_coco) if idx != 1 and p["visible"])
    if visible_count < 17:
        reasons.append(f"Chỉ nhận diện {visible_count}/17 khớp — nghi ngờ bị 'nuốt mất' 1 tay/chân, cần tự vẽ thêm")

    ref_sh, ref_hip = person_coco[2], person_coco[8]
    ref_unit = None
    if ref_sh["visible"] and ref_hip["visible"]:
        dx = ref_sh["x"] - ref_hip["x"]; dy = ref_sh["y"] - ref_hip["y"]
        d = math.sqrt(dx*dx + dy*dy)
        if d > 1e-4:
            ref_unit = d
    if ref_unit:
        anomaly_count = 0
        for a, b in BONE_CONNECTIONS:
            pa, pb = person_coco[a], person_coco[b]
            if pa["visible"] and pb["visible"]:
                dx = pa["x"] - pb["x"]; dy = pa["y"] - pb["y"]
                if math.sqrt(dx*dx + dy*dy) > ref_unit * 3.0:
                    anomaly_count += 1
        if anomaly_count > 0:
            reasons.append(f"Cấu trúc xương dị thường ở {anomaly_count} điểm nối — khoảng cách khớp vượt xa tỷ lệ cơ thể bình thường")

    return len(reasons) > 0, reasons


def coco17_to_openpose18(xyn, conf):
    """xyn: (17,2) normalized x,y. conf: (17,) confidence 0..1."""
    coco = [{"x": 0.0, "y": 0.0, "z": 0.0, "visible": False, "confidence": 1.0} for _ in range(18)]
    for src_idx, dst_idx in COCO17_TO_OPENPOSE18.items():
        x, y = float(xyn[src_idx][0]), float(xyn[src_idx][1])
        c = float(conf[src_idx])
        coco[dst_idx] = {"x": x, "y": y, "z": 0.0, "visible": c >= 0.5, "confidence": c}
    if coco[2]["visible"] and coco[5]["visible"]:
        coco[1] = {
            "x": (coco[2]["x"] + coco[5]["x"]) / 2,
            "y": (coco[2]["y"] + coco[5]["y"]) / 2,
            "z": 0.0, "visible": True,
            "confidence": min(coco[2]["confidence"], coco[5]["confidence"]),
        }
    return coco


def people_from_yolo_result(result):
    """result: 1 phần tử Results của ultralytics (model(image)[0])."""
    if result.keypoints is None or len(result.keypoints.data) == 0:
        return None
    xyn = result.keypoints.xyn.cpu().numpy()   # (num_people, 17, 2) normalized
    conf = result.keypoints.conf
    if conf is None:
        conf = np.ones((xyn.shape[0], 17))
    else:
        conf = conf.cpu().numpy()
    boxes = result.boxes.xyxyn.cpu().numpy() if result.boxes is not None else None

    people = [coco17_to_openpose18(xyn[i], conf[i]) for i in range(xyn.shape[0])]
    # Sắp theo y-center giảm dần (proxy 2D thay z-depth cũ — KHÔNG chính
    # xác bằng độ sâu thật, chỉ dùng vị trí dọc khung hình làm gần đúng).
    if boxes is not None and len(boxes) == len(people):
        order = sorted(range(len(people)), key=lambda i: (boxes[i][1] + boxes[i][3]) / 2, reverse=True)
        people = [people[i] for i in order]
    return people


def extract_one_image(image_path, model):
    result = model(image_path, verbose=False)[0]
    people = people_from_yolo_result(result)
    if not people:
        print(f"  [CẢNH BÁO] không phát hiện được người trong: {image_path}")
        return None
    return people


def extract_video(video_path, model, fps_sample):
    cap = cv2.VideoCapture(video_path)
    video_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frame_interval = max(1, int(round(video_fps / fps_sample)))

    variants = []
    frame_idx = 0
    ok, frame = cap.read()
    while ok:
        if frame_idx % frame_interval == 0:
            result = model(frame, verbose=False)[0]
            people = people_from_yolo_result(result)
            if people:
                variants.append(people)
        frame_idx += 1
        ok, frame = cap.read()
    cap.release()
    print(f"  -> video {video_path}: lấy mẫu {len(variants)} frame có người")
    return variants


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input_dir", required=True)
    ap.add_argument("--output", default="pose_library.json")
    ap.add_argument("--video_fps_sample", type=float, default=2.0)
    ap.add_argument("--model_size", default="n", choices=["n", "s", "m", "l", "x"],
                     help="n=nano (khuyến nghị, tự tải yolov8n-pose.pt nếu chưa có)")
    args = ap.parse_args()

    from ultralytics import YOLO
    model = YOLO(f"yolov8{args.model_size}-pose.pt")

    library = {}
    for template_name in sorted(os.listdir(args.input_dir)):
        template_dir = os.path.join(args.input_dir, template_name)
        if not os.path.isdir(template_dir):
            continue
        variants = []
        for fname in sorted(os.listdir(template_dir)):
            path = os.path.join(template_dir, fname)
            lower = fname.lower()
            if lower.endswith((".jpg", ".jpeg", ".png")):
                print(f"Đang xử lý ảnh: {path}")
                people = extract_one_image(path, model)
                if people:
                    variants.append(people)
            elif lower.endswith((".mp4", ".mov", ".avi", ".mkv")):
                print(f"Đang xử lý video: {path}")
                variants.extend(extract_video(path, model, args.video_fps_sample))
        if variants:
            tagged = []
            need_review_count = 0
            for people in variants:
                angle = estimate_angle(people[0]) if people else "unknown"
                validations = [validate_person(p) for p in people]
                any_needs_review = any(v[0] for v in validations)
                all_reasons = []
                for idx, (needs, reasons) in enumerate(validations):
                    prefix = f"Người {idx+1}: " if len(people) > 1 else ""
                    all_reasons.extend(prefix + r for r in reasons)
                if any_needs_review:
                    need_review_count += 1
                tagged.append({
                    "angle": angle, "people": people,
                    "needsReview": any_needs_review, "reviewReasons": all_reasons,
                })
            library[template_name] = tagged
            warn = f" (⚠ {need_review_count} cần kiểm tra tay)" if need_review_count else ""
            print(f"  -> {template_name}: {len(tagged)} biến thể{warn}")

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(library, f, ensure_ascii=False, indent=2)
    print(f"\nXong. Đã ghi {args.output} — copy file này vào "
          f"app/src/main/assets/pose_library.json của MangaLocal.")
    print("LƯU Ý: mở lại file JSON, tìm 'needsReview': true để biết biến thể "
          "nào nên kiểm tra bằng tay qua PoseEditorScreen trước khi tin dùng.")


if __name__ == "__main__":
    main()
