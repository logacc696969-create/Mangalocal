"""
export_esrgan.py — Export 1 model ESRGAN họ hàng (4x-UltraSharp,
8x_NMKD-Superscale, RealESRGAN_x4plus, ...) sang ONNX, để prepare_models.yml
convert tiếp sang .mnn (giống quy ước export_yolo_pose.py/export_sd15_base.py).

TẠI SAO DÙNG `spandrel` THAY VÌ TỰ VIẾT KIẾN TRÚC RRDBNet: các model ESRGAN
trôi nổi trên mạng (4x-UltraSharp, 8x_NMKD-Superscale...) có thể là "old-arch
ESRGAN" (kiến trúc gốc 2018) HOẶC "RealESRGAN" (kiến trúc mới hơn, khác tên
layer trong state_dict) — tự viết lại 2 kiến trúc + logic tự nhận diện đúng
cái nào có rủi ro sai layer/hyperparameter THẬT (không build-test được ngay
để biết sai ở đâu). `spandrel` (thư viện Python — chính chaiNNer, công cụ
convert model phổ biến nhất cộng đồng SD, dùng nó làm lõi) đã giải quyết
đúng vấn đề "tự nhận diện + load đúng kiến trúc" này, kiểm chứng qua hàng
nghìn model khác nhau — dùng lại đáng tin hơn tự viết.

MODEL KHUYẾN NGHỊ (theo đúng yêu cầu — "thông số vàng" cho da/người thật):
    4x-UltraSharp — https://huggingface.co/uwg/upscaler/resolve/main/ESRGAN/4x-UltraSharp.pth
    (67MB, SHA256 a5812231fc936b42af08a5edba784195495d303d5b3248c24489ef0c4021fe01
    — đã tra cứu xác nhận khớp nhau trên NHIỀU bản mirror độc lập trên
    HuggingFace, dấu hiệu tốt là file gốc không bị chỉnh sửa/giả mạo)

Cài đặt:
    pip install spandrel torch onnx

Chạy:
    python export_esrgan.py --checkpoint 4x-UltraSharp.pth --output_dir ./exported_esrgan

LƯU Ý QUAN TRỌNG — CHƯA BUILD-TEST: script này CHƯA chạy thật lần nào (viết
dựa trên API `spandrel` công khai + quy ước export ONNX chuẩn PyTorch, KHÔNG
phải đoán mù, nhưng chưa tự kiểm chứng bằng cách chạy thật). Nếu export lỗi,
rất có thể do (a) input size cố định 128x128 dùng để trace ONNX không khớp
gì đó trong graph (một số ESRGAN dùng pixel-shuffle nhạy kích thước chia
hết), hoặc (b) phiên bản `spandrel` không nhận diện được đúng kiến trúc của
file .pth cụ thể — cả 2 đều là rủi ro thật, không phải lý thuyết suông.
"""
import argparse
import os


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True,
                         help="File .pth ESRGAN (vd 4x-UltraSharp.pth) — tự tải trước, script này KHÔNG tự tải")
    parser.add_argument("--output_dir", default="./exported_esrgan")
    parser.add_argument("--input_size", type=int, default=128,
                         help="Kích thước ảnh giả dùng để trace ONNX — hầu hết kiến trúc ESRGAN chạy được mọi kích thước "
                              "chia hết cho 4/8 lúc INFERENCE thật dù trace ở size nào, nhưng CHƯA kiểm chứng cho mọi kiến trúc")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    import torch
    from spandrel import ModelLoader

    print(f"Đang load {args.checkpoint} qua spandrel (tự nhận diện kiến trúc)...")
    model = ModelLoader().load_from_file(args.checkpoint)
    print(f"Kiến trúc nhận diện được: {model.architecture.name} — scale: {model.scale}x")

    torch_model = model.model
    torch_model.eval()

    dummy_input = torch.randn(1, 3, args.input_size, args.input_size)
    onnx_path = os.path.join(args.output_dir, "esrgan_upscaler.onnx")

    print(f"Export ONNX (input giả {args.input_size}x{args.input_size}, dynamic H/W để dùng được kích thước khác lúc infer)...")
    torch.onnx.export(
        torch_model, dummy_input, onnx_path,
        input_names=["input"], output_names=["output"],
        dynamic_axes={"input": {2: "height", 3: "width"}, "output": {2: "height", 3: "width"}},
        opset_version=12
    )
    print(f"Xong: {onnx_path} (scale factor thật: {model.scale}x — đặt tên file .mnn theo đúng scale này, "
          f"vd realesrgan_x{model.scale}.mnn khớp quy ước esrgan_wrapper.cpp đang đọc)")
    print("\nBƯỚC TIẾP THEO (đã tự động trong prepare_models.yml, chỉ cần chạy tay nếu tự convert):")
    print(f"  mnnconvert -f ONNX --modelFile {onnx_path} --MNNModel {os.path.join(args.output_dir, f'realesrgan_x{model.scale}.mnn')} --bizCode biz")


if __name__ == "__main__":
    main()
