# Remote GPU server (tuỳ chọn — app mặc định vẫn 100% local)

Server tham chiếu để app MangaLocal gọi sinh ảnh trên GPU thuê ngoài, dùng
cho tính năng **Remote GPU** (Cài đặt > Remote GPU trong app). Xem
`app.py` (docstring đầu file) để hiểu đầy đủ mô hình bảo mật — tóm tắt:
mã hoá thật giữa app và server này (chống được bên trung gian mạng), nhưng
**không** chống được chính chủ hạ tầng GPU thuê (đây là giới hạn vật lý,
không phải thiếu sót có thể vá bằng code).

## 2 cách chạy

### A. Google Colab (miễn phí, dễ nhất — chạy được từ điện thoại, gần như 1-click)
Mở `colab_remote_server.ipynb` bằng Google Colab (colab.research.google.com
> File > Upload notebook). Chỉ 2 bước tay:
1. **Runtime > Change runtime type > GPU** (Colab không cho notebook tự đổi
   runtime của chính nó, bắt buộc làm tay).
2. **Runtime > Run all** — không cần đăng ký tài khoản gì (dùng Cloudflare
   Tunnel quick tunnel, không phải ngrok), auth token tự sinh ngẫu nhiên.

**Hạn chế Colab free**: phiên có giới hạn thời gian, bị ngắt khi rảnh lâu,
GPU T4 chậm hơn RunPod/Vast.ai trả phí. Mỗi lần Run all lại = fingerprint +
URL + auth token đều đổi mới (RSA key và tunnel đều ephemeral) — phải copy
lại vào app.

### B. GPU thuê ngoài (RunPod / Vast.ai / VPS riêng có GPU — trả phí, ổn định hơn)
```bash
pip install -r requirements.txt
python app.py --auth-token "chuoi-bi-mat-cua-ban" --model runwayml/stable-diffusion-v1-5
```
Mở port 8000 ra ngoài (tuỳ nhà cung cấp — RunPod có sẵn "expose port" trong
dashboard, Vast.ai tương tự, VPS riêng thì tự cấu hình firewall/reverse proxy).

## Cấu hình trong app
Cài đặt > Remote GPU > điền **Base URL** (URL ngrok hoặc IP:port server) +
**Auth token** (đúng chuỗi đã đặt ở `--auth-token`) > bấm **"Kiểm tra kết
nối"** > đối chiếu fingerprint hiển thị với fingerprint in ra ở log server
lúc khởi động (dòng "Public key fingerprint") — khớp thì mới an toàn.

## Giới hạn tính năng hiện tại
- Chỉ hỗ trợ txt2img SD1.5 cơ bản.
- **Chưa** hỗ trợ IP-Adapter + ControlNet-Pose (giữ nhất quán nhân vật) —
  app tự phát hiện panel cần tính năng này và tự chuyển về local, xem
  `MangaPipeline.kt` (tìm `wantsAugmented`).
- Chưa hỗ trợ LoRA — nếu cần, thêm `pipe.load_lora_weights(...)` vào
  `get_pipe()` trong `app.py` (chưa làm ở bản này).
