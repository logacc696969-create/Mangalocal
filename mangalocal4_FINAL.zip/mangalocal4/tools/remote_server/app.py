"""
remote_server/app.py — Server tham chiếu chạy trên Colab (miễn phí) hoặc GPU
thuê ngoài (RunPod/Vast.ai/VPS riêng có GPU) để nhận request sinh ảnh từ app
MangaLocal (xem RemoteGenerationClient.kt phía app).

MÔ HÌNH BẢO MẬT — đọc kỹ trước khi chạy, đừng hiểu nhầm đây là "an toàn tuyệt đối":
  - Mã hoá hybrid RSA-OAEP (bọc AES key) + AES-256-GCM (payload thật) giữa APK
    và CHÍNH TIẾN TRÌNH PYTHON NÀY — độc lập với TLS, nên dù ngrok/Cloudflare
    Tunnel/ISP đứng giữa có đọc được gói HTTPS (vì họ terminate TLS ở edge của
    họ trước khi forward tiếp), nội dung bên trong (prompt, ảnh) vẫn là
    ciphertext đối với họ.
  - KHÔNG chống được chính chủ hạ tầng đang chạy tiến trình này (hạ tầng
    Google Colab, hoặc chủ máy vật lý bên dưới RunPod/Vast.ai) — lúc dòng
    code này chạy AESGCM.decrypt(...), RAM tiến trình chứa plaintext, ai có
    quyền truy cập hypervisor/VM đọc được. KHÔNG có cách nào phần mềm thuần
    ngăn được — xem TECHNICAL_STATUS.md mục 37 và giải thích trong hội thoại
    thiết kế (không phải vấn đề "tốc độ soi kịp hay không", là quyền truy cập
    hạ tầng vốn có của chủ máy). Chỉ Confidential-Computing GPU (TEE phần
    cứng) mới chống được điều này — server này CHƯA hỗ trợ CC.
  - Server KHÔNG ghi log nội dung (prompt/ảnh) — chỉ log kích thước/số bước.
    KHÔNG lưu file ảnh/prompt ra đĩa cho từng request. Các biến plaintext
    được `del` sớm nhất có thể sau khi dùng xong — đây là BEST-EFFORT, Python
    không đảm bảo wipe RAM ngay lập tức như cách C làm (GC có thể giữ lại
    bản sao trong bộ nhớ đệm nội bộ interpreter một thời gian) — không quảng
    cáo đây là đảm bảo cứng.
  - RSA keypair sinh MỚI mỗi lần chạy server, CHỈ ở RAM, không ghi đĩa —
    nghĩa là tắt server/đóng ngrok thì phải tạo lại + user phải đối chiếu
    fingerprint mới (TOFU lại từ đầu, xem RemoteGenerationClient.kt).

GIỚI HẠN TÍNH NĂNG (không phải bảo mật): server này CHỈ làm txt2img SD1.5 cơ
bản. CHƯA hỗ trợ IP-Adapter/ControlNet-Pose (giữ nhất quán nhân vật) — app
tự phát hiện và chuyển các panel cần tính năng đó về local (xem MangaPipeline
.kt, tìm "wantsAugmented").

CHẠY:
  pip install -r requirements.txt
  python app.py --auth-token "chuoi-bi-mat-tu-dat-khong-chia-se" --model runwayml/stable-diffusion-v1-5

Sau đó lộ endpoint ra ngoài:
  - Colab: dùng notebook colab_remote_server.ipynb đi kèm (tự động ngrok tunnel)
  - RunPod/Vast.ai/VPS riêng: mở port 8000 trực tiếp (đã có TLS+mã hoá ứng
    dụng nên không bắt buộc phải có HTTPS ở tầng ngoài, nhưng nên có thêm cho
    chắc — vd Caddy/nginx reverse proxy với cert Let's Encrypt).

Copy base URL + đúng auth-token đã đặt, dán vào app > Cài đặt > Remote GPU.
Bấm "Kiểm tra kết nối" trong app rồi ĐỐI CHIẾU fingerprint hiển thị với dòng
"Public key fingerprint" in ra ở terminal/log Colab bên dưới trước khi tin
tưởng gửi bất kỳ ảnh nào.
"""

import argparse
import base64
import hashlib
import io
import json
import os
from typing import Optional

import uvicorn
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding as rsa_padding
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

# ── Cấu hình từ CLI — KHÔNG hardcode auth token trong source, tự đặt lúc chạy ──
_arg_parser = argparse.ArgumentParser()
_arg_parser.add_argument("--auth-token", required=True,
    help="Bearer token app phải gửi kèm mỗi request — tự đặt 1 chuỗi ngẫu nhiên đủ dài, không chia sẻ công khai")
_arg_parser.add_argument("--model", default="runwayml/stable-diffusion-v1-5",
    help="HuggingFace model id hoặc đường dẫn local .safetensors — đổi được sang bất kỳ SD1.5 finetune nào")
_arg_parser.add_argument("--port", type=int, default=8000)
_arg_parser.add_argument("--host", default="0.0.0.0")
args = _arg_parser.parse_args()

# ── RSA keypair ephemeral (xem docstring đầu file) ──────────────────────────
_private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
_public_key_der = _private_key.public_key().public_bytes(
    encoding=serialization.Encoding.DER,
    format=serialization.PublicFormat.SubjectPublicKeyInfo,
)
_fp_hex = hashlib.sha256(_public_key_der).hexdigest().upper()
_fingerprint_display = ":".join(_fp_hex[i:i + 2] for i in range(0, len(_fp_hex), 2))

print("=" * 72)
print("MangaLocal Remote Server — khởi động")
print(f"Model: {args.model}")
print("Public key fingerprint (đối chiếu với app TRƯỚC KHI tin tưởng):")
print(f"  {_fingerprint_display}")
print("=" * 72)

# ── Lazy load model — chỉ load lúc có request /generate đầu tiên, để /pubkey
# trả lời được ngay lúc server vừa khởi động (Colab cold-start model rất chậm).
_pipe = None


def get_pipe():
    global _pipe
    if _pipe is None:
        import torch
        from diffusers import StableDiffusionPipeline
        print("Đang load model lần đầu (có thể mất vài phút trên Colab free)...")
        dtype = torch.float16 if torch.cuda.is_available() else torch.float32
        _pipe = StableDiffusionPipeline.from_pretrained(
            args.model, torch_dtype=dtype, safety_checker=None
        )
        _pipe = _pipe.to("cuda" if torch.cuda.is_available() else "cpu")
        print("✓ Model đã load, sẵn sàng nhận request")
    return _pipe


app = FastAPI(title="MangaLocal Remote Server")


class GenerateRequest(BaseModel):
    wrapped_key_b64: str   # AES-256 key, đã bọc bằng RSA-OAEP public key của server
    iv_b64: str             # IV cho AES-GCM (chiều gửi lên)
    ciphertext_b64: str     # payload JSON {prompt, negative_prompt, width, height, steps, cfg_scale, seed}, đã mã AES-GCM


@app.get("/pubkey")
def pubkey():
    """App gọi 1 lần lúc bấm 'Kiểm tra kết nối' — lấy public key + tính fingerprint để user tự đối chiếu (TOFU)."""
    return {"public_key_der_b64": base64.b64encode(_public_key_der).decode()}


@app.post("/generate")
def generate(req: GenerateRequest, authorization: Optional[str] = Header(None)):
    if authorization != f"Bearer {args.auth_token}":
        raise HTTPException(status_code=401, detail="Auth token sai hoặc thiếu")

    # 1. Mở khoá AES session key bằng RSA private key của server
    try:
        wrapped_key = base64.b64decode(req.wrapped_key_b64)
        aes_key = _private_key.decrypt(
            wrapped_key,
            rsa_padding.OAEP(
                mgf=rsa_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(), label=None,
            ),
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Không giải mã được session key: {e}")

    # 2. Giải mã payload thật bằng AES-256-GCM
    try:
        iv = base64.b64decode(req.iv_b64)
        ciphertext = base64.b64decode(req.ciphertext_b64)
        plaintext = AESGCM(aes_key).decrypt(iv, ciphertext, None)
        payload = json.loads(plaintext.decode("utf-8"))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Không giải mã được payload (sai key hoặc dữ liệu hỏng): {e}")

    prompt = payload.get("prompt", "")
    negative_prompt = payload.get("negative_prompt", "")
    width = int(payload.get("width", 512))
    height = int(payload.get("height", 512))
    steps = int(payload.get("steps", 25))
    cfg_scale = float(payload.get("cfg_scale", 7.0))
    seed = payload.get("seed", -1)

    # KHÔNG log nội dung prompt — chỉ log thông số không nhạy cảm
    print(f"[generate] {width}x{height}, {steps} steps, cfg={cfg_scale} — đang chạy...")

    try:
        pipe = get_pipe()
        import torch
        generator = None
        if seed is not None and int(seed) >= 0:
            generator = torch.Generator(device=pipe.device).manual_seed(int(seed))
        result = pipe(
            prompt=prompt, negative_prompt=negative_prompt,
            width=width, height=height,
            num_inference_steps=steps, guidance_scale=cfg_scale,
            generator=generator,
        )
        image = result.images[0]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generate lỗi: {e}")
    finally:
        # Best-effort xoá reference plaintext sớm nhất có thể — xem giới hạn
        # thật của cách này trong docstring đầu file, không phải đảm bảo cứng.
        del prompt, negative_prompt, payload, plaintext, wrapped_key

    # 3. Mã hoá lại ảnh PNG bằng CÙNG aes_key (đối xứng, IV MỚI cho chiều trả về —
    #    KHÔNG BAO GIỜ tái dùng IV với cùng 1 key trong AES-GCM)
    buf = io.BytesIO()
    image.save(buf, format="PNG")
    image_bytes = buf.getvalue()
    resp_iv = os.urandom(12)
    resp_ciphertext = AESGCM(aes_key).encrypt(resp_iv, image_bytes, None)

    del image_bytes, aes_key  # best-effort, xem docstring đầu file

    return {
        "iv_b64": base64.b64encode(resp_iv).decode(),
        "ciphertext_b64": base64.b64encode(resp_ciphertext).decode(),
    }


if __name__ == "__main__":
    uvicorn.run(app, host=args.host, port=args.port)
