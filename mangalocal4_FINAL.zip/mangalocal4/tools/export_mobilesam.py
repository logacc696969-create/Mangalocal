"""
export_mobilesam.py — Export MobileSAM (encoder + decoder riêng) sang ONNX,
để prepare_models.yml convert tiếp sang .mnn.

TẠI SAO MOBILESAM (đã tra cứu xác nhận qua nhiều nguồn, không đoán — mục 21
TECHNICAL_STATUS.md — "Inpaint Anything" click-to-mask cho UI mask thủ công
ở phase cuối):
  - < 10M tham số (encoder TinyViT thay ViT-H 632M của SAM gốc) — nhẹ nhất
    trong họ SAM cho mobile.
  - Chính xác HƠN VÀ nhanh HƠN FastSAM (dù FastSAM dùng kiến trúc YOLOv8-seg,
    tưởng hợp "dùng YOLO xuyên suốt" hơn — nhưng theo chính paper MobileSAM,
    FastSAM có mIoU thấp hơn hẳn khi so khớp với SAM gốc, và MobileSAM còn
    nhanh hơn 5 lần, nhỏ hơn 7 lần). Không có lý do chọn FastSAM ở đây.
  - Tài liệu chính thức của `samexporter` (công cụ export ONNX phổ biến cho
    họ SAM) ghi rõ: "MobileSAM is the best choice for CPU-only environments
    with tight latency requirements" — ĐÚNG môi trường CPU-only trên di động.

DÙNG THƯ VIỆN `samexporter` (KHÔNG tự viết wrapper ONNX) — export SAM/
MobileSAM cần 1 lớp wrapper Python riêng để gộp prompt-encoder+mask-decoder
thành 1 graph ONNX xuất được (không đơn giản như export 1 model thuần túy
classify/detect) — `samexporter` đã làm việc này, kiểm chứng qua hàng nghìn
người dùng (dùng trong AnyLabeling), tự viết lại có rủi ro sai thật.

Cài đặt:
    pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
    pip install samexporter

Chạy (tự tải mobile_sam.pt nếu chưa có):
    python export_mobilesam.py --output_dir ./exported_mobilesam

LƯU Ý QUAN TRỌNG — CHƯA BUILD-TEST: script này CHƯA chạy thật lần nào. Contract
input/output của encoder/decoder ONNX (đã tra cứu xác nhận qua tài liệu
samexporter + MobileSAM chính thức, KHÔNG đoán):
  encoder.onnx  — input: ảnh RGB đã tiền xử lý chuẩn SAM (resize cạnh dài
                  về 1024, pad vuông 1024x1024, chuẩn hoá ImageNet mean/std
                  — với cờ --use-preprocess, encoder TỰ làm bước này, input
                  là ảnh gốc chưa xử lý) -> output: image_embeddings [1,256,64,64]
  decoder.onnx  — input: image_embeddings, point_coords [1,N,2] (toạ độ pixel
                  THEO ẢNH GỐC, không phải 1024x1024), point_labels [1,N]
                  (1=foreground click, 0=background click), mask_input
                  [1,1,256,256] (mask trước đó, để 0 nếu lần đầu),
                  has_mask_input [1] (0 nếu chưa có mask_input thật),
                  orig_im_size [2] (H, W ảnh gốc)
                  -> output: masks [1,1,H,W] (--return-single-mask), iou_predictions

RỦI RO CHƯA KIỂM CHỨNG: (a) input chính xác của encoder khi dùng
--use-preprocess (ảnh nguyên hay đã resize sẵn) chỉ dựa trên tài liệu, chưa
tự chạy thử; (b) native code (mobile_sam_wrapper.cpp) tính encoder MỖI LẦN
CLICK (không cache embedding qua nhiều lần click) để đơn giản hoá — đánh đổi
chấp nhận được cho công cụ dùng HIẾM (chỉ khi auto-fix vẫn sai), không phải
tool tương tác liên tục, nhưng nghĩa là mỗi click sẽ chậm hơn app gốc SAM
(vốn cache embedding, chỉ decoder chạy lại mỗi click).
"""
import argparse
import os
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output_dir", default="./exported_mobilesam")
    parser.add_argument("--checkpoint_url", default="https://github.com/ChaoningZhang/MobileSAM/raw/master/weights/mobile_sam.pt")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    ckpt_path = os.path.join(args.output_dir, "mobile_sam.pt")

    if not os.path.exists(ckpt_path):
        print(f"Tải mobile_sam.pt (checkpoint gốc, ~40MB) từ {args.checkpoint_url}...")
        subprocess.run(["curl", "-L", "-o", ckpt_path, args.checkpoint_url], check=True)

    encoder_onnx = os.path.join(args.output_dir, "mobile_sam.encoder.onnx")
    decoder_onnx = os.path.join(args.output_dir, "mobile_sam.decoder.onnx")

    print("Export encoder (TinyViT, ~40ms/ảnh trên CPU theo benchmark công bố)...")
    subprocess.run([
        sys.executable, "-m", "samexporter.export_encoder",
        "--checkpoint", ckpt_path, "--output", encoder_onnx,
        "--model-type", "vit_t", "--use-preprocess",
    ], check=True)

    print("Export decoder (prompt encoder + mask decoder gộp 1 graph)...")
    subprocess.run([
        sys.executable, "-m", "samexporter.export_decoder",
        "--checkpoint", ckpt_path, "--output", decoder_onnx,
        "--model-type", "vit_t", "--return-single-mask",
    ], check=True)

    print(f"\nXong: {encoder_onnx}\n      {decoder_onnx}")
    print("\nBƯỚC TIẾP THEO (đã tự động trong prepare_models.yml, chỉ cần chạy tay nếu tự convert):")
    print(f"  mnnconvert -f ONNX --modelFile {encoder_onnx} --MNNModel {os.path.join(args.output_dir, 'mobile_sam_encoder.mnn')} --bizCode biz")
    print(f"  mnnconvert -f ONNX --modelFile {decoder_onnx} --MNNModel {os.path.join(args.output_dir, 'mobile_sam_decoder.mnn')} --bizCode biz")


if __name__ == "__main__":
    main()
