"""
lora_block_weight.py — Tiền xử lý 1 file LoRA .safetensors TRƯỚC khi đưa
vào convertAndRegisterPairModel() (mục 12/14 TECHNICAL_STATUS.md), giảm
"Identity Bleeding"/"Concept Contamination" khi merge nhiều LoRA nhân vật
vào 1 checkpoint — kỹ thuật cộng đồng SD gọi là "LoRA Block Weight" (LBW),
KHÔNG do tôi tự nghĩ ra.

TẠI SAO LÀM Ở PYTHON, KHÔNG SỬA NATIVE (mục 28 TECHNICAL_STATUS.md):
`sd_model_converter.cpp`/`SafeTensor2MNN.hpp` (port từ local-dream) chỉ nhận
1 hệ số weight DUY NHẤT cho CẢ FILE LoRA (không có granularity theo layer).
Thay vì sửa code C++ đã port (rủi ro phá vỡ logic đã hoạt động, khó build-
test), tool này SCALE TRƯỚC từng nhóm layer trong chính file .safetensors
(ghi ra 1 file MỚI), rồi đưa file ĐÃ SCALE đó vào pipeline convert hiện có
KHÔNG ĐỔI GÌ Ở NATIVE CẢ — an toàn hơn, không cần build-test lại C++.

NGUYÊN LÝ (đã tra cứu xác nhận qua tài liệu chuẩn kohya_ss LoRA + nguyên lý
chung của LoRA Block Weight extension — KHÔNG đoán mù key naming, đã đọc
SafeTensor2MNN.hpp để khớp đúng "{lora_key}.lora_down.weight"/".lora_up.weight"):
- Mỗi layer LoRA trong UNet có tên dạng "lora_unet_down_blocks_N_...",
  "lora_unet_mid_block_...", "lora_unet_up_blocks_N_...", và
  "lora_te_..." (text encoder).
- Theo NGUYÊN LÝ CHUNG được cộng đồng ghi nhận (không phải số liệu khoa học
  chính xác — CẦN tinh chỉnh thực nghiệm cho từng cặp LoRA cụ thể):
  down_blocks (sớm) ảnh hưởng nhiều đến bố cục/trang phục/nền — dễ "tràn"
  giữa 2 nhân vật khi merge chung. up_blocks + mid_block (muộn hơn) ảnh
  hưởng nhiều đến chi tiết cuối như khuôn mặt — đặc trưng nhận dạng riêng
  từng người, ít nên giảm.
- Mặc định (preset "reduce_composition_bleed"): giữ nguyên up_blocks/
  mid_block (hệ số 1.0), giảm down_blocks còn 0.5 — giảm rủi ro tràn bố cục/
  trang phục mà vẫn giữ phần lớn đặc trưng khuôn mặt của mỗi LoRA.

CHƯA BUILD-TEST — mức giảm 0.5 là điểm khởi đầu hợp lý theo nguyên lý
chung, KHÔNG PHẢI con số tối ưu đã kiểm chứng cho cặp LoRA cụ thể nào. Cần
tự thử nghiệm build-test thật để tinh chỉnh.

Cài đặt:
    pip install safetensors torch

Chạy:
    python lora_block_weight.py --input charA.safetensors --output charA_lbw.safetensors \
        --down_weight 0.5 --mid_weight 1.0 --up_weight 1.0 --te_weight 1.0
"""
import argparse
import re

from safetensors.torch import load_file, save_file


def block_category(key: str) -> str:
    if key.startswith("lora_te") or "text_encoder" in key:
        return "te"
    if "down_blocks" in key:
        return "down"
    if "mid_block" in key:
        return "mid"
    if "up_blocks" in key:
        return "up"
    return "other"  # input_blocks/output_blocks đặt tên khác kohya đôi khi gặp — không rõ nhóm, giữ nguyên hệ số 1.0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--down_weight", type=float, default=0.5,
                         help="Hệ số nhân cho down_blocks (bố cục/trang phục/nền — dễ tràn nhất)")
    parser.add_argument("--mid_weight", type=float, default=1.0)
    parser.add_argument("--up_weight", type=float, default=1.0,
                         help="Hệ số nhân cho up_blocks (chi tiết/khuôn mặt — nên giữ cao)")
    parser.add_argument("--te_weight", type=float, default=1.0, help="Hệ số nhân cho text encoder layers")
    args = parser.parse_args()

    weights = {"down": args.down_weight, "mid": args.mid_weight, "up": args.up_weight,
               "te": args.te_weight, "other": 1.0}

    tensors = load_file(args.input)
    scaled = {}
    counts = {"down": 0, "mid": 0, "up": 0, "te": 0, "other": 0}
    for key, tensor in tensors.items():
        # Chỉ scale tensor LoRA thật (.lora_up.weight/.lora_down.weight) —
        # scale CẢ up VÀ down đều nhân đôi hệ số thực tế (vì delta = up@down),
        # nên chỉ cần scale 1 TRONG 2 (chọn lora_up, quy ước tương đương
        # scale alpha) để tránh scale kép ngoài ý muốn.
        cat = block_category(key)
        if key.endswith(".lora_up.weight") and cat in weights:
            scaled[key] = tensor * weights[cat]
            counts[cat] += 1
        else:
            scaled[key] = tensor

    save_file(scaled, args.output)
    print(f"Xong: {args.output}")
    print(f"Số layer đã scale theo nhóm: {counts}")
    print(f"Hệ số dùng: down={args.down_weight} mid={args.mid_weight} up={args.up_weight} te={args.te_weight}")
    print("\nLƯU Ý: đây là điểm khởi đầu theo nguyên lý chung cộng đồng, CHƯA build-test "
          "để biết mức giảm tối ưu cho cặp LoRA cụ thể của bạn — thử vài hệ số khác nhau nếu vẫn thấy tràn đặc tính.")


if __name__ == "__main__":
    main()
