# Ghi công mã nguồn — bắt buộc theo giấy phép CC BY-NC 4.0

Các file trong thư mục `app/src/main/jni/sd_engine/` được chép/chuyển thể
(port) từ dự án mã nguồn mở:

- **Dự án gốc:** local-dream (https://github.com/xororz/local-dream)
- **Tác giả:** xororz
- **Giấy phép gốc:** Creative Commons Attribution-NonCommercial 4.0
  International (CC BY-NC 4.0) — https://creativecommons.org/licenses/by-nc/4.0/

## Điều kiện sử dụng
Giấy phép CC BY-NC 4.0 chỉ cho phép sử dụng **phi thương mại**. MangaLocal
sử dụng các file này với điều kiện: **hoàn toàn miễn phí, không quảng cáo,
không thu phí dưới bất kỳ hình thức nào** (xác nhận với người yêu cầu tại
thời điểm chuyển thể). Nếu sau này MangaLocal chuyển sang có thu phí/quảng
cáo, PHẢI xin phép tác giả gốc trước hoặc gỡ bỏ các file trong thư mục này
và viết lại từ đầu.

## Danh sách file đã chép nguyên văn (không sửa nội dung)
Pipeline.hpp, PipelineSd15Cpu.hpp, Config.hpp, MnnUtils.hpp, Tiling.hpp,
SDUtils.hpp, Scheduler.hpp, MemUtils.hpp, LaplacianBlend.hpp,
PromptCache.hpp, Sha256.hpp, FloatConversion.hpp,
DPMSolverMultistepScheduler.hpp, EulerAncestralDiscreteScheduler.hpp,
EulerDiscreteScheduler.hpp, LCMScheduler.hpp, TextEncoder.hpp,
PromptProcessor.hpp, SafeTensorReader.hpp, SDStructure.hpp,
LoraMapping.hpp, SafeTensor2MNN.hpp.

## File viết mới (không phải của tác giả gốc)
- `Logger.hpp` — bản thay thế do file gốc (lấy từ Qualcomm QNN SDK
  SampleApp) không có trong mã nguồn công khai.
- `mnn_diffusion_pipeline.cpp` — lớp adapter JNI riêng cho MangaLocal,
  gọi vào `Pipeline::generate()` thật của local-dream, KHÔNG chép logic
  nghiệp vụ của họ, chỉ nối dây vào JNI.
- `sd_model_converter.cpp` — adapter JNI gọi `generateMNNModels()` thật để
  convert/merge LoRA NGAY TRÊN ĐIỆN THOẠI (xem điều kiện tiên quyết ghi
  trong chính file này — cần sẵn file "khung" .mnn trước khi dùng).
- `model_manifest.json` (mẫu, trong assets) + manifest động (ghi trong
  `StoryManager.kt`, lưu ngoài APK) — định dạng khai báo model riêng của
  MangaLocal, không liên quan tới định dạng của local-dream.

## Chưa dùng ở giai đoạn này
`PipelineSdxl.hpp`, `PipelineAnima.hpp`, `PipelineSd15Npu.hpp`,
`QnnModel.hpp`, `QnnRuntime.hpp`, `PipelineQnn.hpp` — các file này bắt buộc
Qualcomm QNN SDK + chip NPU thật để chạy, không hoạt động qua GitHub
Actions CI. Sẽ thêm khi có SDK thật + thiết bị thật để test. SDXL cũng
không có tiền lệ chạy qua MNN ở bất kỳ dự án nào được tìm thấy (xem hội
thoại) — tạm ngừng theo đuổi hướng MNN cho SDXL.

## Việc còn thiếu, chưa bắt đầu (theo dõi để không bỏ dở)
- `ip_adapter.cpp` + ControlNet-Pose: sẽ gộp chung 1 lần re-export UNet
  bằng Python/diffusers (script chưa viết) rồi mới viết C++ tương ứng.
- Cần thư viện khung `.mnn` (unet/vae_decoder/vae_encoder cấu trúc rỗng)
  để tính năng convert on-device (`sdConvertModel`) hoạt động — KHÔNG có
  sẵn trong repo, người dùng phải tự chuẩn bị.
- SettingsScreen.kt (UI) chưa cập nhật cho hệ thống model/manifest mới.
