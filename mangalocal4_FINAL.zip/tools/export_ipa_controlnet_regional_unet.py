"""
export_ipa_controlnet_regional_unet.py — Regional Prompting THẬT (gán PROMPT
CHỮ riêng cho từng vùng ảnh, khác mục 52 là gán ẢNH NHÂN VẬT riêng cho từng
vùng) + ControlNet-Pose. Đây là mục ưu tiên #1 trong bảng gap user dán vào
("Regional Prompting / Latent Couple — bắt buộc để tách biệt nhiều nhân vật").

CHẠY TRÊN MÁY TÍNH (không phải điện thoại), cần Python + GPU khuyến khích.

=== NGUỒN THẬT ĐÃ TRA — KHÔNG ĐOÁN ===
Cơ chế THẬT (đã đọc source, không suy diễn): diffusers có pipeline cộng
đồng CHÍNH THỨC `examples/community/regional_prompting_stable_diffusion.py`
(tác giả hako-mikan — cùng người viết extension "Regional Prompter" nổi
tiếng cho A1111), 2 chế độ "col"/"row" hoạt động như sau (đọc trực tiếp
hàm `hook_forward()` monkey-patch lên MỌI module `attn2` — cross-attention
— của UNet):
  1. Với MỖI layer cross-attention, chạy TOÀN BỘ phép attention chuẩn
     (Q/K/V + softmax + to_out + residual) NHIỀU LẦN — 1 lần cho mỗi vùng,
     mỗi lần dùng CÙNG hidden_states (ảnh đầy đủ) nhưng KHÁC
     encoder_hidden_states (prompt riêng của vùng đó).
  2. SAU KHI có N kết quả attention ĐẦY ĐỦ KÍCH THƯỚC ẢNH (không phải
     N kết quả đã cắt sẵn), mới CẮT VÀ GHÉP theo lưới cột/hàng: vùng i chỉ
     lấy đúng phần cột/hàng của NÓ từ kết quả attention thứ i, ghép lại
     thành 1 hidden_states cuối cùng.
Đây LÀ kỹ thuật Regional Prompting/Latent Couple thật — KHÁC HẲN cách làm
"cắt ảnh trước, chạy riêng từng mảnh" (dễ đoán sai) — attention được tính
trên TOÀN ẢNH cho mỗi vùng rồi mới cắt, giữ được ngữ cảnh toàn cục trong
mỗi vùng thay vì cô lập hoàn toàn.

=== BẢN ĐƠN GIẢN HOÁ CỦA SCRIPT NÀY — NÓI RÕ, KHÔNG PHẢI PORT 1:1 ===
Bản gốc hako-mikan hỗ trợ lưới hàng+cột tuỳ ý, chế độ "prompt" (mask suy từ
attention map), Compel, base-prompt trộn tỷ lệ, v.v. — quá phức tạp để
export tĩnh (fixed-shape, không dynamic_axes, đúng nguyên tắc toàn dự án).
Bản NÀY đơn giản hoá còn:
  - CHỈ chế độ CỘT dọc (chia N cột đều nhau trái->phải) — đủ cho bài toán
    "nhiều nhân vật đứng cạnh nhau" (trường hợp phổ biến nhất), KHÔNG hỗ
    trợ chia hàng ngang hay lưới 2D.
  - CHỈ ảnh VUÔNG (image_size x image_size) — suy (h,w) của mỗi layer từ
    sqrt(sequence_length), CHỈ đúng khi ảnh vuông. Ảnh không vuông sẽ suy
    sai (h,w) — KHÔNG hỗ trợ, dự án này vốn đã dùng 512x512 vuông xuyên
    suốt (control_hint/depth_hint/mask đều vậy) nên không phải hạn chế
    mới.
  - Prompt NEGATIVE dùng CHUNG cho toàn ảnh (không chia vùng) — chỉ prompt
    DƯƠNG (positive) được chia N vùng. Đây là đơn giản hoá HỢP LÝ (negative
    prompt thường mang tính toàn cục — "xấu, méo, thiếu chi tiết" — không
    có ý nghĩa "vùng nào xấu vùng nấy").
  - N cố định lúc export (giống mọi export script khác của dự án — không
    dynamic_axes).
  - KHÔNG kết hợp với IP-Adapter mask (mục 52) trong CÙNG 1 model — 2 kỹ
    thuật SONG SONG (regional PROMPT vs regional ẢNH NHÂN VẬT), dùng model
    nào tuỳ nhu cầu panel, không ép gộp chung để tránh nhân độ phức tạp
    export lên nhiều lần cùng lúc (rủi ro lỗi cao hơn hẳn).

=== TRACE VỚI BATCH=2 (KHÁC bản 1/2/N-nhân-vật ở mục 51/52/52b) ===
PHÁT HIỆN QUAN TRỌNG khi rà lại `PipelineSd15Cpu.hpp::runUnetStep()`: native
runtime LUÔN gọi UNet với `sample`/`encoder_hidden_states` batch=2 (gộp
[negative, positive] trong CÙNG 1 lần chạy session — xem comment "Copy both
batches (negative and positive) at once" trong file đó). Các export script
mục 51/52 lại TRACE với batch=1 — hoạt động được VÌ conv/attention nói
chung không cần biết trước batch size cụ thể lúc trace (không có phép
reshape nào khoá cứng batch=1 vào hằng số trong đồ thị các model đó), nên
suy luận đồ thị vẫn áp dụng đúng khi runtime đưa vào batch=2 — NHƯNG ĐIỀU
NÀY CHƯA ĐƯỢC XÁC NHẬN CHẠY THẬT cho BẤT KỲ export script nào của dự án
(kể cả các bản trước mục này), chỉ là suy luận hợp lý từ cấu trúc đồ thị.

Với Regional Prompting, vế uncond (âm) và vế cond (dương) BẮT BUỘC xử lý
KHÁC NHAU (uncond = toàn ảnh 1 prompt, cond = N vùng ghép) — không thể dựa
vào "may ra đồ thị linh hoạt" như depth/mask (áp dụng ĐỒNG NHẤT cho cả 2
vế nên batch=1 hay 2 không quan trọng). Vì vậy script NÀY trace THẲNG với
batch=2, đúng NGUYÊN VẸN batch mà runtime thật sự dùng — AN TOÀN HƠN, ít
suy đoán hơn hẳn so với đi theo đúng pattern batch=1 của mục 51/52 cho
trường hợp CẦN phân biệt batch index này.

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_regional_unet.py \\
        --base_model runwayml/stable-diffusion-v1-5 \\
        --num_regions 2 --output_dir ./exported_regional --image_size 512
"""
import argparse
import math
import os

import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers import ControlNetModel, StableDiffusionControlNetPipeline


def hook_regional_attn2(unet: nn.Module, num_regions: int):
    """Monkey-patch forward() của MỌI module cross-attention (`attn2`) —
    ĐÚNG cơ chế đã đọc từ regional_prompting_stable_diffusion.py (xem
    docstring đầu file), viết lại tối giản cho ảnh vuông + N cột + trace
    tĩnh (không cần dict rp_args/mode runtime như bản gốc, N đã cố định
    ngay tại đây lúc export).

    Sau khi gọi hàm này, unet(sample_batch2, t, encoder_hidden_states=?, ...)
    sẽ IGNORE tham số encoder_hidden_states thường — mỗi attn2 tự lấy prompt
    đúng vùng từ 2 biến toàn cục `_uncond_embeds`/`_region_embeds` (gán bởi
    AugmentedUNetRegional.forward() mỗi lần forward, xem bên dưới) — cách
    này TRÁNH phải sửa signature của mọi UNet2DConditionModel.forward() nội
    bộ (quá sâu, dễ vỡ), ĐÚNG kiểu monkey-patch mà bản gốc hako-mikan cũng
    làm (hook_forwards() gắn thẳng vào từng attn2.forward), không phải cách
    làm tự nghĩ ra khác biệt.
    """
    state = {"uncond": None, "regions": None}  # gán từ ngoài mỗi lần forward, xem set_regional_state()

    def make_forward(attn: nn.Module):
        def forward(hidden_states, encoder_hidden_states=None, attention_mask=None, temb=None, **kw):
            # hidden_states vào đây LUÔN batch=2 ([uncond, cond]) — do
            # AugmentedUNetRegional gọi self.unet(sample_batch2, ...) 1 lần
            # duy nhất, đúng batch=2 thật của runtime (xem docstring).
            residual = hidden_states
            if attn.spatial_norm is not None:
                hidden_states = attn.spatial_norm(hidden_states, temb)
            input_ndim = hidden_states.ndim
            if input_ndim == 4:
                b, c, h4, w4 = hidden_states.shape
                hidden_states = hidden_states.view(b, c, h4 * w4).transpose(1, 2)

            seq_len = hidden_states.shape[1]
            side = int(round(math.sqrt(seq_len)))  # ảnh vuông -> h=w=sqrt(seq_len), xem giới hạn ở docstring

            uncond_hs = hidden_states[0:1]   # batch index 0 = uncond, đúng quy ước [negative, positive] của Pipeline.hpp
            cond_hs = hidden_states[1:2]     # batch index 1 = cond (dương) -> sẽ chia N vùng

            def run_attn(hs, enc_hs):
                q = attn.to_q(hs)
                k = attn.to_k(enc_hs)
                v = attn.to_v(enc_hs)
                inner_dim = k.shape[-1]
                head_dim = inner_dim // attn.heads
                q = q.view(hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                k = k.view(enc_hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                v = v.view(enc_hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                out = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0, is_causal=False)
                out = out.transpose(1, 2).reshape(hs.shape[0], -1, attn.heads * head_dim).to(q.dtype)
                out = attn.to_out[0](out)
                out = attn.to_out[1](out)
                return out

            # Vế uncond: 1 lần, TOÀN ẢNH, prompt âm chung (không chia vùng —
            # xem "đơn giản hoá" ở docstring).
            uncond_out = run_attn(uncond_hs, state["uncond"])

            # Vế cond: chạy N lần, MỖI LẦN toàn ảnh với đúng 1 prompt vùng —
            # ĐÚNG thứ tự "tính attention đầy đủ RỒI MỚI cắt" của bản gốc,
            # không cắt hidden_states trước khi vào attention.
            region_outs = [run_attn(cond_hs, state["regions"][i:i + 1]) for i in range(num_regions)]

            # Ghép N kết quả theo CỘT — mỗi vùng i chỉ đóng góp đúng dải cột
            # của nó vào kết quả cond cuối cùng (đúng cơ chế splice của bản
            # gốc, đơn giản hoá còn 1 chiều ngang).
            spliced = torch.zeros_like(region_outs[0])
            spliced_2d = spliced.view(1, side, side, -1)
            for i, out in enumerate(region_outs):
                lo = int(side * i / num_regions)
                hi = int(side * (i + 1) / num_regions)
                out_2d = out.view(1, side, side, -1)
                spliced_2d[:, :, lo:hi, :] = out_2d[:, :, lo:hi, :]
            cond_out = spliced_2d.view(1, seq_len, -1)

            hidden_states = torch.cat([uncond_out, cond_out], dim=0)

            if input_ndim == 4:
                hidden_states = hidden_states.transpose(-1, -2).reshape(b, c, h4, w4)
            if attn.residual_connection:
                hidden_states = hidden_states + residual
            hidden_states = hidden_states / attn.rescale_output_factor
            return hidden_states
        return forward

    for name, module in unet.named_modules():
        if "attn2" in name and module.__class__.__name__ == "Attention":
            module.forward = make_forward(module)

    def set_regional_state(uncond_embeds, region_embeds):
        state["uncond"] = uncond_embeds
        state["regions"] = region_embeds

    return set_regional_state


class AugmentedUNetRegional(nn.Module):
    """UNet + ControlNet-Pose + Regional Prompting (N cột). set_state là
    closure trả về từ hook_regional_attn2() — gọi TRƯỚC self.unet(...) mỗi
    lần forward để nạp đúng embeds cho vòng attn2 hook dùng."""

    def __init__(self, unet, controlnet, num_regions):
        super().__init__()
        self.unet = unet
        self.controlnet = controlnet
        self.set_state = hook_regional_attn2(unet, num_regions)

    def forward(self, sample, timestep, uncond_embeds, region_embeds, control_hint):
        # sample: batch=2 [uncond, cond] — xem docstring lý do trace batch=2.
        # ControlNet chạy CHO CẢ 2 batch bằng embeds ghép [uncond, region_embeds[0]]
        # làm placeholder cross-attention của ControlNet (ControlNet-Pose
        # dùng encoder_hidden_states y hệt UNet gốc theo đúng API MultiControlNetModel
        # đã dùng ở mục 51, KHÔNG có khái niệm "vùng" ở tầng ControlNet — pose
        # là điều kiện KHÔNG GIAN đã tự nhiên phủ toàn ảnh, không cần chia vùng).
        cn_encoder_hidden = torch.cat([uncond_embeds, region_embeds[0:1]], dim=0)
        down_res, mid_res = self.controlnet(
            sample, timestep, encoder_hidden_states=cn_encoder_hidden,
            controlnet_cond=control_hint, return_dict=False,
        )
        self.set_state(uncond_embeds, region_embeds)
        # encoder_hidden_states truyền vào đây bị hook attn2 GHI ĐÈ (đọc từ
        # set_state ở trên) — vẫn phải truyền 1 tensor hợp lệ vì UNet2DConditionModel.
        # forward() có nơi khác (không phải attn2) cũng đọc shape của nó (vd
        # time embedding phụ nếu có) — dùng uncond_embeds lặp batch=2 làm placeholder.
        placeholder_encoder_hidden = torch.cat([uncond_embeds, uncond_embeds], dim=0)
        noise_pred = self.unet(
            sample, timestep, encoder_hidden_states=placeholder_encoder_hidden,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            return_dict=False,
        )[0]
        return noise_pred


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="runwayml/stable-diffusion-v1-5")
    ap.add_argument("--controlnet_model", default="lllyasviel/control_v11p_sd15_openpose")
    ap.add_argument("--num_regions", type=int, default=2,
                     help="So cot doc chia deu tu trai sang phai (>=2)")
    ap.add_argument("--output_dir", default="./exported_regional")
    ap.add_argument("--image_size", type=int, default=512,
                     help="PHAI la anh VUONG (xem GIOI HAN THAT o dau file)")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    if args.num_regions < 2:
        raise ValueError("num_regions phai >= 2 (chia 1 vung thi khong con la regional prompting)")

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_size = args.image_size // 8

    print("Đang tải ControlNet-OpenPose...")
    controlnet = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)

    print("Đang tải base SD1.5 + gắn ControlNet...")
    pipe = StableDiffusionControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet, torch_dtype=torch.float32, safety_checker=None
    ).to(device)

    print(f"Đang gắn hook Regional Prompting ({args.num_regions} cột)...")
    augmented = AugmentedUNetRegional(pipe.unet, pipe.controlnet, args.num_regions).to(device).eval()

    # Dò shape encoder_hidden_states THẬT bằng chính tokenizer/text_encoder
    # của pipe (không đoán 77/768 — dù SD1.5 gần như luôn là vậy, vẫn đọc
    # thật để nhất quán nguyên tắc toàn dự án).
    with torch.no_grad():
        dummy_ids = pipe.tokenizer(["a photo"], padding="max_length",
                                    max_length=pipe.tokenizer.model_max_length,
                                    truncation=True, return_tensors="pt").input_ids.to(device)
        probe_embed = pipe.text_encoder(dummy_ids)[0]
    print(f"[probe] encoder_hidden_states 1 prompt shape THẬT: {tuple(probe_embed.shape)}")

    example_sample = torch.randn(2, 4, latent_size, latent_size, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_uncond = torch.randn_like(probe_embed)
    example_regions = torch.randn(args.num_regions, *probe_embed.shape[1:], device=device)
    example_control_hint = torch.randn(2, 3, args.image_size, args.image_size, device=device)

    onnx_name = f"unet_regional_controlnet_{args.num_regions}col.onnx"
    mnn_name = f"unet_regional_controlnet_{args.num_regions}col.mnn"
    onnx_path = os.path.join(args.output_dir, onnx_name)
    print(f"Đang export ONNX -> {onnx_path} (có thể mất vài phút)...")
    with torch.no_grad():
        torch.onnx.export(
            augmented,
            (example_sample, example_timestep, example_uncond, example_regions, example_control_hint),
            onnx_path,
            input_names=["sample", "timestep", "uncond_encoder_hidden_states",
                         "region_encoder_hidden_states", "control_hint"],
            output_names=["out_sample"],
            opset_version=17,
            do_constant_folding=True,
            # KHÔNG dùng dynamic_axes — giống mọi bản export khác trong dự
            # án này. sample/control_hint batch=2 CỐ ĐỊNH (khớp đúng batch
            # thật của runtime — xem docstring, KHÁC bản mask/depth batch=1).
        
            dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
            # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
            # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
            # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
            # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
            # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
            # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
            # xác nhận hoạt động đúng bằng thực nghiệm.
        )

    print("\n=== XONG PHẦN ONNX ===")
    print(f"Shape uncond_encoder_hidden_states: {tuple(example_uncond.shape)}")
    print(f"Shape region_encoder_hidden_states ({args.num_regions} vùng): {tuple(example_regions.shape)}")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, mnn_name)} --bizCode biz")
    print(f"\nQUAN TRỌNG: model CỐ ĐỊNH cho ĐÚNG {args.num_regions} cột VÀ ảnh VUÔNG")
    print(f"{args.image_size}x{args.image_size} — sai kích thước/tỉ lệ sẽ suy (h,w) SAI ở")
    print("mọi layer attn2 (side = sqrt(seq_len) không còn đúng), KHÔNG có kiểm tra runtime")
    print("nào bắt lỗi này — ảnh ra sẽ hỏng ÂM THẦM, không crash. Luôn dùng đúng image_size")
    print("đã export khi gọi sinh ảnh với model này.")


if __name__ == "__main__":
    main()
