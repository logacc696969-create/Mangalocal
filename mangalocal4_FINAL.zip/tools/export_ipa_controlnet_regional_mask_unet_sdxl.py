"""
export_ipa_controlnet_regional_mask_unet_sdxl.py — mục 180
TECHNICAL_STATUS.md (SDXL Phase 2e). Bản SDXL tương đương
export_ipa_controlnet_regional_mask_unet.py (SD1.5, mục 172) — ĐỌC
DOCSTRING FILE ĐÓ + export_ipa_controlnet_regional_unet_sdxl.py (SDXL cột,
mục 179) TRƯỚC. `hook_regional_mask_attn2()` COPY GẦN NGUYÊN VĂN bản SD1.5
(khác bản cột đúng 1 chỗ: ghép theo MASK THẬT qua argmax thay vì slice
cột cứng — xem comment "---- Ghép theo MASK THẬT ----" trong hàm) — không
có gì SD1.5-specific trong đó (chỉ thao tác Q/K/V/to_out generic).

=== PHẦN THÊM CHO SDXL (giống hệt lý do đã nêu ở bản cột mục 179) ===
ControlNet+UNet SDXL bắt buộc added_cond_kwargs={"text_embeds",
"time_ids"}. Vế cond dùng pooled embedding của BACKGROUND (không phải
vùng 0) làm đại diện — khác bản cột 1 chút vì ControlNet ở đây vốn đã
dùng background_embeds làm placeholder (xem AugmentedUNetRegionalMask bản
SD1.5: `cn_encoder_hidden = torch.cat([uncond_embeds, background_embeds])`)
— giữ NHẤT QUÁN với lựa chọn đó thay vì tự đổi sang vùng 0.

=== PHẠM VI — Y HỆT GIỚI HẠN BẢN SD1.5 + BẢN CỘT SDXL (mục 172/179) ===
Batch=2 chưa xác nhận chạy thật (kế thừa), ảnh vuông bắt buộc, N cố định
lúc export, mask downsample "nearest" (giữ biên cứng, không nội suy mờ).

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_regional_mask_unet_sdxl.py \\
        --num_regions 2 --output_dir ./exported_sdxl_regional_mask
"""
import argparse
import math
import os

import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers import ControlNetModel, StableDiffusionXLControlNetPipeline


def hook_regional_mask_attn2(unet: nn.Module, num_regions: int):
    """COPY GẦN NHƯ NGUYÊN VĂN từ export_ipa_controlnet_regional_mask_unet.py
    (SD1.5) — xem docstring đầy đủ ở đó. Không có gì SDXL-specific."""
    state = {"uncond": None, "background": None, "regions": None, "masks": None}

    def make_forward(attn: nn.Module):
        def forward(hidden_states, encoder_hidden_states=None, attention_mask=None, temb=None, **kw):
            residual = hidden_states
            if attn.spatial_norm is not None:
                hidden_states = attn.spatial_norm(hidden_states, temb)
            input_ndim = hidden_states.ndim
            if input_ndim == 4:
                b, c, h4, w4 = hidden_states.shape
                hidden_states = hidden_states.view(b, c, h4 * w4).transpose(1, 2)

            seq_len = hidden_states.shape[1]
            side = int(round(math.sqrt(seq_len)))

            uncond_hs = hidden_states[0:1]
            cond_hs = hidden_states[1:2]

            def run_attn(hs, enc_hs):
                q = attn.to_q(hs)
                k = attn.to_k(enc_hs)
                v = attn.to_v(enc_hs)
                inner_dim = k.shape[-1]
                head_dim = inner_dim // attn.heads
                q = q.view(hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                k = k.view(enc_hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                v = v.view(enc_hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                out = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0, is_causal=False)
                out = out.transpose(1, 2).reshape(hs.shape[0], -1, attn.heads * head_dim).to(q.dtype)
                out = attn.to_out[0](out)
                out = attn.to_out[1](out)
                return out

            uncond_out = run_attn(uncond_hs, state["uncond"])
            background_out = run_attn(cond_hs, state["background"])
            region_outs = [run_attn(cond_hs, state["regions"][i:i + 1]) for i in range(num_regions)]

            masks_ds = F.interpolate(
                state["masks"].unsqueeze(1), size=(side, side), mode="nearest",
            ).squeeze(1)
            max_vals, best_idx = torch.max(masks_ds, dim=0)
            has_owner = (max_vals > 0.5).view(1, side * side, 1).to(uncond_out.dtype)
            best_idx_flat = best_idx.view(side * side)

            cond_out = background_out * (1.0 - has_owner)
            for i, out in enumerate(region_outs):
                weight_i = (best_idx_flat == i).view(1, side * side, 1).to(out.dtype) * has_owner
                cond_out = cond_out + out * weight_i

            hidden_states = torch.cat([uncond_out, cond_out], dim=0)
            if input_ndim == 4:
                hidden_states = hidden_states.transpose(-1, -2).reshape(b, c, h4, w4)
            if attn.residual_connection:
                hidden_states = hidden_states + residual
            hidden_states = hidden_states / attn.rescale_output_factor
            return hidden_states
        return forward

    for name, module in unet.named_modules():
        if "attn2" in name and module.__class__.__name__ == "Attention":
            module.forward = make_forward(module)

    def set_regional_state(uncond_embeds, background_embeds, region_embeds, region_masks):
        state["uncond"] = uncond_embeds
        state["background"] = background_embeds
        state["regions"] = region_embeds
        state["masks"] = region_masks

    return set_regional_state


class AugmentedUNetRegionalMaskXL(nn.Module):
    """Y HỆT AugmentedUnetRegionalXL (bản cột, mục 179) — CHỈ thêm
    background_embeds/region_masks, ControlNet dùng background_embeds làm
    placeholder text (thay vì vùng 0, giữ nhất quán với bản SD1.5)."""

    def __init__(self, unet, controlnet, num_regions):
        super().__init__()
        self.unet = unet
        self.controlnet = controlnet
        self.set_state = hook_regional_mask_attn2(unet, num_regions)

    def forward(self, sample, timestep, uncond_embeds, background_embeds, region_embeds,
                region_masks, uncond_pooled, background_pooled, time_ids, control_hint):
        text_embeds_b2 = torch.cat([uncond_pooled, background_pooled], dim=0)
        added_cond = {"text_embeds": text_embeds_b2, "time_ids": time_ids}

        cn_encoder_hidden = torch.cat([uncond_embeds, background_embeds], dim=0)
        down_res, mid_res = self.controlnet(
            sample, timestep, encoder_hidden_states=cn_encoder_hidden,
            controlnet_cond=control_hint, added_cond_kwargs=added_cond, return_dict=False,
        )
        self.set_state(uncond_embeds, background_embeds, region_embeds, region_masks)
        placeholder_encoder_hidden = torch.cat([uncond_embeds, uncond_embeds], dim=0)
        noise_pred = self.unet(
            sample, timestep, encoder_hidden_states=placeholder_encoder_hidden,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            added_cond_kwargs=added_cond,
            return_dict=False,
        )[0]
        return noise_pred


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="stabilityai/stable-diffusion-xl-base-1.0")
    ap.add_argument("--controlnet_model", default="thibaud/controlnet-openpose-sdxl-1.0")
    ap.add_argument("--num_regions", type=int, default=2)
    ap.add_argument("--output_dir", default="./exported_sdxl_regional_mask")
    ap.add_argument("--image_size", type=int, default=1024)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    if args.num_regions < 2:
        raise ValueError("num_regions phai >= 2")
    if args.image_size % 64 != 0:
        raise ValueError(f"image_size phải chia hết cho 64 — nhận {args.image_size}")

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_size = args.image_size // 8

    print("Đang tải ControlNet-OpenPose-SDXL...")
    controlnet = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)
    print("Đang tải base SDXL + gắn ControlNet...")
    pipe = StableDiffusionXLControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet, torch_dtype=torch.float32
    ).to(device)

    print(f"Đang gắn hook Regional-Mask SDXL ({args.num_regions} vùng + 1 nền)...")
    augmented = AugmentedUNetRegionalMaskXL(pipe.unet, pipe.controlnet, args.num_regions).to(device).eval()

    with torch.no_grad():
        ids1 = pipe.tokenizer(["a photo"], padding="max_length", max_length=pipe.tokenizer.model_max_length,
                               truncation=True, return_tensors="pt").input_ids.to(device)
        ids2 = pipe.tokenizer_2(["a photo"], padding="max_length", max_length=pipe.tokenizer_2.model_max_length,
                                 truncation=True, return_tensors="pt").input_ids.to(device)
        out1 = pipe.text_encoder(ids1, output_hidden_states=True)
        out2 = pipe.text_encoder_2(ids2, output_hidden_states=True)
        probe_hidden = torch.cat([out1.hidden_states[-2], out2.hidden_states[-2]], dim=-1)
        probe_pooled = out2[0]
    print(f"[probe] encoder_hidden_states shape THẬT: {tuple(probe_hidden.shape)}")
    print(f"[probe] pooled shape THẬT: {tuple(probe_pooled.shape)}")

    example_sample = torch.randn(2, 4, latent_size, latent_size, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_uncond = torch.randn_like(probe_hidden)
    example_background = torch.randn_like(probe_hidden)
    example_regions = torch.randn(args.num_regions, *probe_hidden.shape[1:], device=device)
    example_uncond_pooled = torch.randn_like(probe_pooled)
    example_background_pooled = torch.randn_like(probe_pooled)
    example_masks = torch.zeros(args.num_regions, args.image_size, args.image_size, device=device)
    for i in range(args.num_regions):
        lo = args.image_size * i // args.num_regions
        hi = args.image_size * (i + 1) // args.num_regions
        example_masks[i, :, lo:hi] = 1.0
    example_time_ids = torch.tensor(
        [[args.image_size, args.image_size, 0, 0, args.image_size, args.image_size]] * 2,
        device=device, dtype=torch.float32)
    example_control_hint = torch.randn(2, 3, args.image_size, args.image_size, device=device)

    onnx_name = f"unet_regional_mask_controlnet_sdxl_{args.num_regions}char.onnx"
    mnn_name = f"unet_regional_mask_controlnet_sdxl_{args.num_regions}char.mnn"
    onnx_path = os.path.join(args.output_dir, onnx_name)
    print(f"Đang export ONNX -> {onnx_path} (model SDXL lớn, có thể mất nhiều phút)...")
    with torch.no_grad():
        torch.onnx.export(
            augmented,
            (example_sample, example_timestep, example_uncond, example_background, example_regions,
             example_masks, example_uncond_pooled, example_background_pooled, example_time_ids,
             example_control_hint),
            onnx_path,
            input_names=["sample", "timestep", "uncond_encoder_hidden_states",
                         "background_encoder_hidden_states", "region_encoder_hidden_states",
                         "region_masks", "uncond_text_embeds", "background_text_embeds",
                         "time_ids", "control_hint"],
            output_names=["out_sample"],
            opset_version=17, do_constant_folding=True,
            dynamo=False,  # xem export_ipa_controlnet_unet_sdxl.py / mục 97 TECHNICAL_STATUS.md
        )

    print("\n=== XONG PHẦN ONNX ===")
    print(f"Shape region_masks ({args.num_regions} vùng): {tuple(example_masks.shape)}")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, mnn_name)} --bizCode biz")
    print(f"\nQUAN TRỌNG: model CỐ ĐỊNH cho ĐÚNG {args.num_regions} vùng VÀ ảnh VUÔNG "
          f"{args.image_size}x{args.image_size} — mask truyền lúc infer PHẢI cùng kích thước.")


if __name__ == "__main__":
    main()
