"""
export_sdxl_base.py — mục 59 TECHNICAL_STATUS.md ("Xây hệ sinh thái SDXL").
Export SDXL (CLIP-L + CLIP-bigG + UNet + VAE) trực tiếp từ `diffusers` sang
ONNX rồi .mnn, TỰ ĐẶT TÊN TENSOR khớp đúng những gì
`sd_engine/PipelineSdxlCpu.hpp` (mới viết, mirror kiến trúc
`PipelineSd15Cpu.hpp`/`export_sd15_base.py`) đọc thật:
    - CLIP-L (clip_l.mnn):  input "input_embedding"                 -> output "last_hidden_state"
    - CLIP-G (clip_g.mnn):  input "input_embedding"+"input_ids_2"    -> output "last_hidden_state"+"pooled_output"
    - UNet   (unet_sdxl.mnn): input "sample"/"timestep"/"encoder_hidden_states"/"text_embeds"/"time_ids" -> output "out_sample"
    - VAE decoder: input "latent_sample" -> output "sample"
    - VAE encoder: input "input" -> output "mean"/"std"  (giống hệt SD1.5)

=== KIẾN TRÚC ĐÃ CÓ SẴN, KHÔNG TỰ THIẾT KẾ TỪ ĐẦU ===
Trước khi viết file này đã rà `Pipeline.hpp` (base class) và phát hiện
TOÀN BỘ khung SDXL đã được thiết kế sẵn từ trước (không phải do phiên làm
việc này): `sdxl_` flag, `vaeScale()` tự trả 0.13025, `textHiddenDim()` tự
trả 768+1280, `textPooledDim()` tự trả 1280, và quan trọng nhất —
`Pipeline::encodePrompts()` đã TỰ SINH `time_ids` (`[h,w,0,0,h,w]` — không
cắt/resize khác tỉ lệ gốc). `TextEncoder.hpp` cũng đã có sẵn 2 bộ token/pos-
embedding-table + `ProcessedPromptPair::negative_embeddings_2`/
`positive_embeddings_2` (77×1280) khi `TextEncoder(/*sdxl=*/true, ...)`.
File Python này CHỈ cần export đúng 5 model khớp những gì phía C++ đã sẵn
sàng đọc — không đoán API, tự kiểm soát cả 2 đầu Python/C++ giống hệt
nguyên tắc đã dùng ở `export_sd15_base.py`.

=== API SDXL THẬT ĐÃ TRA (không suy diễn từ SD1.5) ===
Đọc `StableDiffusionXLPipeline.encode_prompt()`/`_get_add_time_ids()` thật
(huggingface/diffusers) xác nhận:
  - CẢ 2 encoder dùng `hidden_states[-2]` (lớp áp chót, output_hidden_states=
    True) làm encoder_hidden_states — KHÔNG áp final_layer_norm, KHÁC hẳn
    SD1.5 (`export_sd15_base.py::ClipBodyOnly` CÓ áp final_layer_norm).
  - `encoder_hidden_states` cuối = `torch.concat([hidden_1, hidden_2], dim=-1)`
    -> 768+1280=2048, hidden_1 (CLIP-L) TRƯỚC.
  - `pooled_prompt_embeds` CHỈ lấy từ encoder 2 (CLIP-bigG có
    `text_projection`, CLIP-L không dùng cho pooled trong SDXL) — pooled =
    hidden-state tại VỊ TRÍ TOKEN EOS (sau final_layer_norm) chiếu qua
    `text_projection`. Vị trí EOS thay đổi theo từng prompt — clip_g.mnn cần
    thêm input `input_ids_2` để dò đúng vị trí (xem PipelineSdxlCpu.hpp).
  - `add_time_ids` = `[original_h, original_w, crop_top, crop_left,
    target_h, target_w]` (6 giá trị) — Pipeline.hpp đã tự sinh
    (original=target=req.height/width, crop=0,0), KHÔNG cần script này làm
    gì thêm, chỉ cần UNet export đúng nhận input "time_ids" shape [batch,6].
  - `added_cond_kwargs={"text_embeds": pooled, "time_ids": time_ids}` —
    UNet2DConditionModel(sdxl) TỰ xử lý bên trong (qua `add_embedding`
    module), script này chỉ cần forward đúng 2 tham số đó vào unet(...),
    không tự tính toán gì thêm.

=== GIỚI HẠN THẬT — PHẠM VI MỤC NÀY CHỈ LÀ NỀN TẢNG TXT2IMG ===
Script này CHỈ export base pipeline (CLIP×2 + UNet + VAE) — KHÔNG bao gồm
IP-Adapter/ControlNet/LoRA/Regional-mask cho SDXL (những thứ đã có cho
SD1.5 ở mục 4/28/51/52/55/56). Đây là quyết định phạm vi CÓ CHỦ ĐÍCH —
xem TECHNICAL_STATUS.md mục 59 để biết lý do và các bước tiếp theo nếu cần
mở rộng.

Cài đặt:
    pip install torch diffusers transformers accelerate onnx MNN

Chạy:
    python export_sdxl_base.py --base_model stabilityai/stable-diffusion-xl-base-1.0 \\
        --output_dir ./exported_sdxl_base
"""
import argparse
import os

import numpy as np
import torch
import torch.nn as nn
from diffusers import StableDiffusionXLPipeline


class ClipLBodyOnly(nn.Module):
    """CLIP-L (text_encoder), nhận input_embedding đã cộng sẵn (giống hệt
    quy ước SD1.5) -> trả hidden_states[-2] (KHÔNG áp final_layer_norm —
    khác SD1.5, xem docstring đầu file)."""

    def __init__(self, text_encoder):
        super().__init__()
        self.encoder = text_encoder.text_model.encoder
        seq_len = 77
        mask = torch.full((seq_len, seq_len), float("-inf"))
        mask = torch.triu(mask, diagonal=1)
        self.register_buffer("causal_mask", mask.unsqueeze(0).unsqueeze(0))

    def forward(self, input_embedding):
        out = self.encoder(input_embedding, attention_mask=None,
                           causal_attention_mask=self.causal_mask,
                           output_hidden_states=True, return_dict=True)
        return out.hidden_states[-2]


class ClipGBodyOnly(nn.Module):
    """CLIP-bigG (text_encoder_2), nhận input_embedding đã cộng sẵn (1280-
    dim) + input_ids_2 (để dò vị trí EOS) -> trả (hidden_states[-2],
    pooled_projected). Pooled DÙNG LẠI đúng `final_layer_norm`/
    `text_projection` THẬT của model (không tự viết lại logic pooling —
    xem docstring đầu file)."""

    def __init__(self, text_encoder_2):
        super().__init__()
        self.encoder = text_encoder_2.text_model.encoder
        self.final_layer_norm = text_encoder_2.text_model.final_layer_norm
        self.text_projection = text_encoder_2.text_projection
        # SD1.5/SDXL encoder-1 dùng eos=49407 (TextEncoder.hpp đã xác nhận,
        # dùng chung quy ước) — encoder 2 (OpenCLIP) VỊ TRÍ eos giống hệt vị
        # trí trong `ids` gốc (chỉ đổi phần ĐUÔI sau eos thành pad=0, xem
        # PipelineSdxlCpu.hpp) nên dùng chung hằng số 49407 để dò vị trí là
        # đúng, không đoán.
        self.eos_token_id = 49407
        seq_len = 77
        mask = torch.full((seq_len, seq_len), float("-inf"))
        mask = torch.triu(mask, diagonal=1)
        self.register_buffer("causal_mask", mask.unsqueeze(0).unsqueeze(0))

    def forward(self, input_embedding, input_ids_2):
        out = self.encoder(input_embedding, attention_mask=None,
                           causal_attention_mask=self.causal_mask,
                           output_hidden_states=True, return_dict=True)
        hidden_penultimate = out.hidden_states[-2]

        last_hidden = self.final_layer_norm(out.hidden_states[-1])
        # Dò vị trí EOS đầu tiên/nhân vật (argmax trả về index PHẦN TỬ ĐẦU
        # TIÊN đạt max khi có nhiều giá trị bằng nhau — đúng hành vi cần,
        # vì is_eos là 0/1, "1" đầu tiên = EOS đầu tiên).
        is_eos = (input_ids_2 == self.eos_token_id).int()
        eos_pos = is_eos.argmax(dim=-1)
        pooled_raw = last_hidden[torch.arange(last_hidden.shape[0]), eos_pos]
        pooled = self.text_projection(pooled_raw)
        return hidden_penultimate, pooled


class UnetXLWrapper(nn.Module):
    def __init__(self, unet):
        super().__init__()
        self.unet = unet

    def forward(self, sample, timestep, encoder_hidden_states, text_embeds, time_ids):
        added_cond_kwargs = {"text_embeds": text_embeds, "time_ids": time_ids}
        return self.unet(sample, timestep, encoder_hidden_states,
                         added_cond_kwargs=added_cond_kwargs, return_dict=False)[0]


class VaeDecoderWrapper(nn.Module):
    def __init__(self, vae):
        super().__init__()
        self.vae = vae

    def forward(self, latent_sample):
        return self.vae.decode(latent_sample, return_dict=False)[0]


class VaeEncoderWrapper(nn.Module):
    def __init__(self, vae):
        super().__init__()
        self.vae = vae

    def forward(self, sample):
        dist = self.vae.encode(sample, return_dict=False)[0]
        return dist.mean, dist.std


def export_embedding_tables(pipe, output_dir):
    """token_emb.bin/pos_emb.bin (encoder 1, giống SD1.5) +
    token_emb_2.bin/pos_emb_2.bin (encoder 2, SDXL riêng) — TextEncoder.hpp
    ĐÃ xác nhận đọc đúng 4 tên file này khi sdxl_=true (loadEmbeddingTables()),
    không đoán tên."""
    te1 = pipe.text_encoder
    te2 = pipe.text_encoder_2

    tok1 = te1.text_model.embeddings.token_embedding.weight.detach().numpy().astype(np.float32)
    pos1 = te1.text_model.embeddings.position_embedding.weight.detach().numpy().astype(np.float32)
    tok1.tofile(os.path.join(output_dir, "token_emb.bin"))
    pos1.tofile(os.path.join(output_dir, "pos_emb.bin"))
    print(f"  token_emb (encoder 1): shape {tok1.shape}")
    print(f"  pos_emb   (encoder 1): shape {pos1.shape}")

    # TextEncoder.hpp: loadTokenEmb(..., force_fp16=sdxl_) -> encoder-2 table
    # LUÔN fp16 khi sdxl_ — xuất sẵn fp16 ở đây để KHỚP ĐÚNG, tránh C++ phải
    # tự convert (rủi ro sai byte nếu suy đoán sai chiều convert).
    tok2 = te2.text_model.embeddings.token_embedding.weight.detach().numpy().astype(np.float16)
    pos2 = te2.text_model.embeddings.position_embedding.weight.detach().numpy().astype(np.float16)
    tok2.tofile(os.path.join(output_dir, "token_emb_2.bin"))
    pos2.tofile(os.path.join(output_dir, "pos_emb_2.bin"))
    print(f"  token_emb_2 (encoder 2, fp16): shape {tok2.shape}")
    print(f"  pos_emb_2   (encoder 2, fp16): shape {pos2.shape}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="stabilityai/stable-diffusion-xl-base-1.0")
    ap.add_argument("--output_dir", default="./exported_sdxl_base")
    ap.add_argument("--image_size", type=int, default=1024,
                     help="SDXL sinh tot nhat o 1024 (khac SD1.5 512) - xem GIOI HAN THAT")
    args = ap.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    latent_size = args.image_size // 8

    print(f"Đang tải {args.base_model} (SDXL — model NẶNG, ~7GB, tải lâu hơn SD1.5 nhiều)...")
    if args.base_model.endswith((".safetensors", ".ckpt")):
        pipe = StableDiffusionXLPipeline.from_single_file(args.base_model, torch_dtype=torch.float32)
    else:
        pipe = StableDiffusionXLPipeline.from_pretrained(args.base_model, torch_dtype=torch.float32)

    pipe.tokenizer.save_pretrained(args.output_dir)
    # QUAN TRỌNG: dự án dùng CHUNG 1 tokenizer.json cho cả 2 encoder (xem
    # TextEncoder.hpp — chỉ 1 `tokenizer_`, KHÔNG có tokenizer_2 riêng, dùng
    # `ids` gốc build `ids_2` bằng cách đổi pad token, KHÔNG tokenize lại
    # bằng tokenizer khác). SDXL thật dùng 2 tokenizer HƠI khác nhau (CLIP-L
    # dùng chuẩn openai/clip-vit-large, CLIP-G dùng chuẩn OpenCLIP) — kiểm
    # tra xác nhận: 2 tokenizer CÓ CHUNG vocab/merge cơ bản (cả 2 đều BPE
    # 49408 token chuẩn CLIP), CHỈ khác quy ước pad token (49407 vs 0) mà
    # TextEncoder.hpp ĐÃ xử lý đúng qua đổi ids sau EOS — chưa build-test để
    # xác nhận 100% không có token nào lệch giữa 2 tokenizer trên mọi prompt,
    # rủi ro nói rõ ở TECHNICAL_STATUS.md mục 59.
    if not os.path.exists(os.path.join(args.output_dir, "tokenizer.json")):
        print("[CANH BAO] Khong thay tokenizer.json hop nhat - tuong tu rui ro da ghi o export_sd15_base.py.")

    print("Đang export embedding tables (4 file: encoder 1 + encoder 2)...")
    export_embedding_tables(pipe, args.output_dir)

    print("Đang export CLIP-L body (input_embedding -> last_hidden_state)...")
    clip_l = ClipLBodyOnly(pipe.text_encoder).eval()
    example_embed_l = torch.randn(1, 77, 768)
    torch.onnx.export(
        clip_l, example_embed_l, os.path.join(args.output_dir, "clip_l.onnx"),
        input_names=["input_embedding"], output_names=["last_hidden_state"],
        opset_version=17, do_constant_folding=True,
    
        dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
        # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
        # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
        # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
        # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
        # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
        # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
        # xác nhận hoạt động đúng bằng thực nghiệm.
    )

    print("Đang export CLIP-G body (input_embedding+input_ids_2 -> last_hidden_state+pooled_output)...")
    clip_g = ClipGBodyOnly(pipe.text_encoder_2).eval()
    example_embed_g = torch.randn(1, 77, 1280)
    example_ids_2 = torch.randint(0, 49408, (1, 77), dtype=torch.long)
    example_ids_2[0, 10] = 49407  # đảm bảo có ít nhất 1 eos trong ví dụ trace, tránh argmax rơi vào vị trí 0 gây hiểu nhầm
    torch.onnx.export(
        clip_g, (example_embed_g, example_ids_2), os.path.join(args.output_dir, "clip_g.onnx"),
        input_names=["input_embedding", "input_ids_2"],
        output_names=["last_hidden_state", "pooled_output"],
        opset_version=17, do_constant_folding=True,
    
        dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
        # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
        # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
        # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
        # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
        # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
        # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
        # xác nhận hoạt động đúng bằng thực nghiệm.
    )

    print("Đang export UNet SDXL (sample/timestep/encoder_hidden_states/text_embeds/time_ids -> out_sample)...")
    unet_wrap = UnetXLWrapper(pipe.unet).eval()
    example_sample = torch.randn(1, 4, latent_size, latent_size)
    example_timestep = torch.tensor([999], dtype=torch.long)
    example_hidden = torch.randn(1, 77, 2048)
    example_text_embeds = torch.randn(1, 1280)
    example_time_ids = torch.tensor([[args.image_size, args.image_size, 0, 0, args.image_size, args.image_size]], dtype=torch.float32)
    torch.onnx.export(
        unet_wrap, (example_sample, example_timestep, example_hidden, example_text_embeds, example_time_ids),
        os.path.join(args.output_dir, "unet_sdxl.onnx"),
        input_names=["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids"],
        output_names=["out_sample"],
        opset_version=17, do_constant_folding=True,
    
        dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
        # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
        # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
        # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
        # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
        # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
        # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
        # xác nhận hoạt động đúng bằng thực nghiệm.
    )

    print("Đang export VAE decoder (latent_sample -> sample)...")
    vae_dec = VaeDecoderWrapper(pipe.vae).eval()
    example_latent = torch.randn(1, 4, latent_size, latent_size)
    torch.onnx.export(
        vae_dec, example_latent, os.path.join(args.output_dir, "vae_decoder.onnx"),
        input_names=["latent_sample"], output_names=["sample"],
        opset_version=17, do_constant_folding=True,
    
        dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
        # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
        # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
        # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
        # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
        # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
        # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
        # xác nhận hoạt động đúng bằng thực nghiệm.
    )

    print("Đang export VAE encoder (sample -> mean, std)...")
    vae_enc = VaeEncoderWrapper(pipe.vae).eval()
    example_pixels = torch.randn(1, 3, args.image_size, args.image_size)
    torch.onnx.export(
        vae_enc, example_pixels, os.path.join(args.output_dir, "vae_encoder.onnx"),
        input_names=["input"], output_names=["mean", "std"],
        opset_version=17, do_constant_folding=True,
    
        dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
        # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
        # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
        # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
        # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
        # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
        # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
        # xác nhận hoạt động đúng bằng thực nghiệm.
    )

    print("\n=== XONG PHẦN ONNX ===")
    print("BƯỚC TIẾP THEO (mnnconvert từ `pip install MNN`):")
    for name, mnn_name in [("clip_l", "clip_l"), ("clip_g", "clip_g"),
                            ("unet_sdxl", "unet_sdxl"), ("vae_decoder", "vae_decoder"),
                            ("vae_encoder", "vae_encoder")]:
        onnx_path = os.path.join(args.output_dir, f"{name}.onnx")
        mnn_path = os.path.join(args.output_dir, f"{mnn_name}.mnn")
        print(f"mnnconvert -f ONNX --modelFile {onnx_path} --MNNModel {mnn_path} --bizCode biz")
    print("\nSau khi convert xong, thêm 1 entry \"pipeline\": \"sdxl_cpu\" vào")
    print("model_manifest.json (xem ví dụ trong TECHNICAL_STATUS.md mục 59) với đủ")
    print("9 file: tokenizer.json, clip_l.mnn, clip_g.mnn, unet_sdxl.mnn, vae_decoder.mnn,")
    print("vae_encoder.mnn (tuỳ chọn), token_emb.bin, pos_emb.bin, token_emb_2.bin, pos_emb_2.bin.")


if __name__ == "__main__":
    main()
