"""
export_ipa_controlnet_mask_unet_sdxl.py — mục 178 TECHNICAL_STATUS.md
(SDXL Phase 2c). Bản SDXL tương đương export_ipa_controlnet_mask_unet.py
(SD1.5, mục 52) — 1 IP-Adapter dùng cho N ảnh nhân vật CÓ MASK VÙNG, đúng
API "IP-Adapter masking" chính thức của diffusers (docs/source/en/using-
diffusers/ip_adapter.md, PR #10346, issue #8626 — xem docstring đầy đủ ở
export_ipa_controlnet_mask_unet.py, KHÔNG lặp lại ở đây, cơ chế giống hệt,
chỉ khác input SDXL: encoder_hidden_states 2048-dim + text_embeds/time_ids).

=== PHẠM VI CÓ CHỦ ĐÍCH (giống export_ipa_controlnet_unet_sdxl.py) ===
KHÔNG có Smooth Timestep Decay / Per-Instance Decay (mục 97/100/147 ở
SD1.5) — scale IP-Adapter TĨNH, đóng băng lúc export (--char_scales),
giống hệt "PHẠM VI" đã nêu ở export_ipa_controlnet_unet_sdxl.py. Lý do:
decay là tinh chỉnh trên nền đã chạy, không phải năng lực cốt lõi — thêm
sau nếu Phase 2 cơ bản (bản 1-người + bản N-người này) build-test ổn.

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_mask_unet_sdxl.py \\
        --num_characters 2 --output_dir ./exported_sdxl_mask
"""
import argparse
import os

import torch
import torch.nn as nn
from diffusers import ControlNetModel, StableDiffusionXLControlNetPipeline
from diffusers.image_processor import IPAdapterMaskProcessor

# Tái dùng export_image_encoder từ bản SDXL 1-người — KHÔNG copy trùng lặp,
# API generic (xem export_ipa_controlnet_unet_sdxl.py).
from export_ipa_controlnet_unet_sdxl import export_image_encoder


class AugmentedUnetMaskXL(nn.Module):
    """Giống AugmentedUnetXL (bản 1 nhân vật) nhưng dùng 1 IP-Adapter cho
    N ẢNH nhân vật CÓ MASK VÙNG — mirror ĐÚNG AugmentedUNetMask (SD1.5, xem
    export_ipa_controlnet_mask_unet.py), thêm text_embeds/time_ids cho CẢ
    controlnet LẪN unet (khác biệt SDXL đã xác nhận ở export_ipa_controlnet_
    unet_sdxl.py điểm #4)."""

    def __init__(self, unet, controlnet):
        super().__init__()
        self.unet = unet
        self.controlnet = controlnet

    def forward(self, sample, timestep, encoder_hidden_states, text_embeds, time_ids,
                control_hint, ip_image_embeds, ip_masks):
        added_cond = {"text_embeds": text_embeds, "time_ids": time_ids}
        down_res, mid_res = self.controlnet(
            sample, timestep, encoder_hidden_states=encoder_hidden_states,
            controlnet_cond=control_hint, added_cond_kwargs=added_cond, return_dict=False,
        )
        noise_pred = self.unet(
            sample, timestep, encoder_hidden_states=encoder_hidden_states,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            added_cond_kwargs={**added_cond, "image_embeds": [ip_image_embeds]},
            cross_attention_kwargs={"ip_adapter_masks": [ip_masks]},
            return_dict=False,
        )[0]
        return noise_pred


def probe_multi_char_embeds_xl(pipe, device, num_characters):
    """Mirror probe_multi_char_embeds() (SD1.5) — API giống hệt, chỉ
    pipe/image_encoder khác (bigG thay vì H)."""
    from PIL import Image

    colors = [(160, 120, 120), (120, 120, 160), (120, 160, 120), (160, 160, 120),
              (160, 120, 160), (120, 160, 160)]
    dummies = [Image.new("RGB", (224, 224), color=colors[i % len(colors)]) for i in range(num_characters)]
    with torch.no_grad():
        embeds = pipe.prepare_ip_adapter_image_embeds(
            ip_adapter_image=[dummies], ip_adapter_image_embeds=None,
            device=device, num_images_per_prompt=1, do_classifier_free_guidance=False,
        )
    embed_tensor = embeds[0]
    print(f"[probe] image_embeds SDXL ({num_characters} nhân vật) shape THẬT: {tuple(embed_tensor.shape)}")
    return embed_tensor


def probe_multi_char_masks(width, height, device, num_characters):
    """Nguyên văn probe_multi_char_masks() (SD1.5) — không có gì SDXL-
    specific (chỉ là tiền xử lý mask nhị phân qua IPAdapterMaskProcessor,
    độc lập kiến trúc UNet)."""
    from PIL import Image

    masks = []
    for i in range(num_characters):
        m = Image.new("L", (width, height), color=0)
        lo = int(width * i / num_characters)
        hi = int(width * (i + 1) / num_characters)
        for x in range(lo, hi):
            for y in range(0, height, 8):
                m.putpixel((x, y), 255)
        masks.append(m)

    processor = IPAdapterMaskProcessor()
    mask_tensor = processor.preprocess(masks, height=height, width=width).to(device)
    print(f"[probe] ip_adapter_masks shape THẬT ({num_characters} nhân vật): {tuple(mask_tensor.shape)}")
    return mask_tensor


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="stabilityai/stable-diffusion-xl-base-1.0")
    ap.add_argument("--controlnet_model", default="thibaud/controlnet-openpose-sdxl-1.0")
    ap.add_argument("--ip_adapter_repo", default="h94/IP-Adapter")
    ap.add_argument("--ip_adapter_weight", default="ip-adapter_sdxl.bin")
    ap.add_argument("--num_characters", type=int, default=2,
                     help="So nhan vat can tach vung (mac dinh 2, giong khuyen nghi SD1.5)")
    ap.add_argument("--char_scales", default="",
                     help="Danh sach scale cach nhau boi dau phay, dung --num_characters gia tri. Rong = 0.8 cho tat ca.")
    ap.add_argument("--output_dir", default="./exported_sdxl_mask")
    ap.add_argument("--image_size", type=int, default=None,
                     help="LƯU Ý: đặt CẢ width VÀ height bằng giá trị này (chỉ dùng cho ảnh vuông, tương thích ngược với prepare_models.yml hiện tại — mục 208). Ưu tiên dùng --width/--height nếu cần ảnh không vuông.")
    ap.add_argument("--width", type=int, default=1024, help="SDXL sinh tốt nhất ở 1024 (khác SD1.5 512). Phải chia hết cho 64 (VAE 8x + UNet giảm thêm 8x = 64x thật; mirror đúng export_ipa_controlnet_mask_unet.py SD1.5, mục 161 đợt 7/mục 208).")
    ap.add_argument("--height", type=int, default=1024, help="Xem --width.")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    num_chars = args.num_characters
    if num_chars < 2:
        raise ValueError("num_characters phai >= 2 (mask vung chi co y nghia khi >=2 nhan vat)")
    if args.char_scales.strip():
        scales = [float(s) for s in args.char_scales.split(",")]
        if len(scales) != num_chars:
            raise ValueError(f"--char_scales co {len(scales)} gia tri nhung --num_characters={num_chars}")
    else:
        scales = [0.8] * num_chars
    # mục 208 TECHNICAL_STATUS.md — cùng logic tương thích ngược mirror ĐÚNG
    # export_ipa_controlnet_mask_unet.py (SD1.5) đã làm từ trước — khác
    # export_ipa_controlnet_regional_unet_sdxl.py/regional_mask (CỐ Ý giữ
    # vuông, kế thừa giới hạn thật từ thuật toán chia cột/sqrt(seq_len),
    # KHÔNG áp dụng đổi này cho 2 script đó).
    if args.image_size is not None:
        args.width = args.height = args.image_size
    if args.width % 64 != 0 or args.height % 64 != 0:
        raise ValueError(f"width/height phải chia hết cho 64 — nhận {args.width}x{args.height}")

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_h, latent_w = args.height // 8, args.width // 8

    print("Đang tải ControlNet-OpenPose-SDXL...")
    controlnet = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)
    print(f"Đang tải base SDXL ({args.base_model}) + gắn ControlNet...")
    pipe = StableDiffusionXLControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet, torch_dtype=torch.float32
    )
    print(f"Đang nạp IP-Adapter SDXL...")
    pipe.load_ip_adapter(args.ip_adapter_repo, subfolder="sdxl_models", weight_name=args.ip_adapter_weight)
    pipe.set_ip_adapter_scale([scales])  # list lồng — 1 adapter, N ảnh (issue #8626), giống hệt SD1.5
    pipe.to(device)

    example_embeds = probe_multi_char_embeds_xl(pipe, device, num_chars)
    example_masks = probe_multi_char_masks(args.width, args.height, device, num_chars)
    export_image_encoder(pipe, args.output_dir, device)

    print(f"Đang lắp AugmentedUnetMaskXL ({num_chars} nhân vật)...")
    augmented = AugmentedUnetMaskXL(pipe.unet, pipe.controlnet).to(device).eval()

    example_sample = torch.randn(1, 4, latent_h, latent_w, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_encoder_hidden = torch.randn(1, 77, 2048, device=device)
    example_text_embeds = torch.randn(1, 1280, device=device)
    example_time_ids = torch.tensor(
        [[args.height, args.width, 0, 0, args.height, args.width]],
        device=device, dtype=torch.float32)
    example_control_hint = torch.randn(1, 3, args.height, args.width, device=device)

    onnx_name = f"unet_ipa_mask_controlnet_sdxl_{num_chars}char.onnx"
    mnn_name = f"unet_ipa_mask_controlnet_sdxl_{num_chars}char.mnn"
    onnx_path = os.path.join(args.output_dir, onnx_name)
    print(f"Đang export ONNX -> {onnx_path} (model SDXL lớn, có thể mất nhiều phút)...")
    with torch.no_grad():
        torch.onnx.export(
            augmented,
            (example_sample, example_timestep, example_encoder_hidden, example_text_embeds,
             example_time_ids, example_control_hint, example_embeds, example_masks),
            onnx_path,
            input_names=["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids",
                         "control_hint", "ip_image_embeds", "ip_adapter_masks"],
            output_names=["out_sample"],
            opset_version=17, do_constant_folding=True,
            dynamo=False,  # xem export_ipa_controlnet_unet_sdxl.py / mục 97 TECHNICAL_STATUS.md
        )

    print("\n=== XONG PHẦN ONNX ===")
    print(f"Shape ip_image_embeds thật: {tuple(example_embeds.shape)}")
    print(f"Shape ip_adapter_masks thật: {tuple(example_masks.shape)}")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, mnn_name)} --bizCode biz")
    print(f"  (ip_image_encoder.onnx dùng CHUNG lệnh convert với bản 1-người, xem")
    print(f"   export_ipa_controlnet_unet_sdxl.py — KHÔNG cần export lại ở đây)")
    print(f"\nModel này CỐ ĐỊNH cho ĐÚNG {num_chars} nhân vật (tên file có '{num_chars}char').")


if __name__ == "__main__":
    main()
