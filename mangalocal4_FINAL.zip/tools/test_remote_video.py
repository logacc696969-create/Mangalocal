#!/usr/bin/env python3
"""mục 249 — kiểm thử "ảnh → clip qua server từ xa" (Stable Video Diffusion).

Chạy THẬT hàm `_run_video_sync` của server (rút ra bằng ast) với `torch`/`diffusers` GIẢ và Pillow thật: kiểm kẹp tham số,
đặt ảnh vào khung 1024x576 giữ tỉ lệ (không cắt), seed, giải phóng bộ nhớ, giữ pipeline khi --keep-svd. KHÔNG có GPU/diffusers ở
đây nên KHÔNG chứng minh SVD chạy hay mp4 phát được; phía Kotlin chỉ đối chiếu chuỗi nguồn (CHƯA build-test).
"""
import ast, base64, gc, io, os, re, sys, types
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
APP = open(os.path.join(ROOT, 'tools', 'remote_server', 'app.py'), encoding='utf8').read()
KB = os.path.join(ROOT, 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(KB, *p), encoding='utf8').read()

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

tree = ast.parse(APP)
fn = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_run_video_sync'), None)
check('server có hàm _run_video_sync', fn is not None)
gen = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_run_generation_sync')
gsrc = ast.get_source_segment(APP, gen)
reg = next(n for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == '_TASK_HANDLERS' for t in n.targets))
reg_map = {k.value: v.id for k, v in zip(reg.value.keys, reg.value.values)}
check('điều phối (mục 250 đã tổng quát hoá): task "video" ánh xạ tới _run_video_sync và chạy TRƯỚC khi đọc prompt (đường ảnh cũ không đổi)', reg_map.get('video') == '_run_video_sync' and 'handler = _TASK_HANDLERS.get(task)' in gsrc and gsrc.index('_TASK_HANDLERS') < gsrc.index('payload.get("prompt"'))
check('tham số dòng lệnh --svd-model-id và --keep-svd có mặt', '"--svd-model-id"' in APP and '"--keep-svd"' in APP and 'stable-video-diffusion-img2vid-xt' in APP)

# ---------- chạy hàm thật với module giả ----------
calls = {'from_pretrained': 0, 'pipe_calls': [], 'offload': 0, 'empty_cache': 0, 'kwargs': None, 'export': None}
class FakePipe:
    def enable_model_cpu_offload(self): calls['offload'] += 1
    def __call__(self, image, **kw):
        calls['pipe_calls'].append((image, kw))
        return types.SimpleNamespace(frames=[['f%d' % i for i in range(kw['num_frames'])]])
def from_pretrained(model_id, **kw):
    calls['from_pretrained'] += 1; calls['kwargs'] = (model_id, kw); return FakePipe()

def install_fakes():
    torch = types.ModuleType('torch'); torch.float16 = 'fp16'
    torch.manual_seed = lambda s: ('GEN', s)
    torch.cuda = types.SimpleNamespace(empty_cache=lambda: calls.__setitem__('empty_cache', calls['empty_cache'] + 1))
    dif = types.ModuleType('diffusers'); dif.StableVideoDiffusionPipeline = types.SimpleNamespace(from_pretrained=from_pretrained)
    du = types.ModuleType('diffusers.utils')
    def export_to_video(frames, path, fps=7):
        calls['export'] = (list(frames), fps)
        open(path, 'wb').write(b'\x00\x00\x00\x18ftypmp42' + b'\x00' * 8 + ('%d' % len(frames)).encode())
    du.export_to_video = export_to_video
    sys.modules.update({'torch': torch, 'diffusers': dif, 'diffusers.utils': du})

def run(payload, keep=False):
    install_fakes()
    ns = {'Image': Image, 'io': io, 'base64': base64, 'os': os, 'gc': gc, '_svd_pipe': None,
          'args': types.SimpleNamespace(svd_model_id='fake/svd', keep_svd=keep)}
    exec(compile(ast.Module(body=[fn], type_ignores=[]), 'app.py', 'exec'), ns)
    return ns['_run_video_sync'], ns

def b64png(w, h, color=(255, 0, 0)):
    b = io.BytesIO(); Image.new('RGB', (w, h), color).save(b, 'PNG'); return base64.b64encode(b.getvalue()).decode()

def reset():
    calls.update({'from_pretrained': 0, 'pipe_calls': [], 'offload': 0, 'empty_cache': 0, 'kwargs': None, 'export': None})

if fn is not None:
    reset(); f, ns = run({})
    out = f({'image_b64': b64png(512, 512)})
    img, kw = calls['pipe_calls'][0]
    check('trả bytes mp4 (4 byte kế là "ftyp") đúng như client kiểm', out[4:8] == b'ftyp')
    check('mặc định: 14 khung, fps 7, motion 127, noise 0.02, decode_chunk 2, generator None', kw['num_frames'] == 14 and kw['fps'] == 7 and kw['motion_bucket_id'] == 127 and abs(kw['noise_aug_strength'] - 0.02) < 1e-9 and kw['decode_chunk_size'] == 2 and kw['generator'] is None)
    check('nạp model từ --svd-model-id, fp16 + variant fp16, bật cpu offload', calls['kwargs'] == ('fake/svd', {'torch_dtype': 'fp16', 'variant': 'fp16'}) and calls['offload'] == 1)
    check('ảnh vào model đúng 1024x576; export_to_video nhận đủ số khung và fps', img.size == (1024, 576) and calls['export'] == (['f%d' % i for i in range(14)], 7))
    check('không --keep-svd: giải phóng (pipeline không được giữ, gọi empty_cache)', ns['_svd_pipe'] is None and calls['empty_cache'] >= 1)

    # kẹp tham số
    for key, lo_in, lo_out, hi_in, hi_out in [('num_frames', 1, 6, 100, 25), ('fps', 0, 3, 99, 30), ('motion_bucket_id', 0, 1, 999, 255), ('decode_chunk_size', 0, 1, 99, 8)]:
        reset(); f, _ = run({}); f({'image_b64': b64png(64, 64), key: lo_in}); a = calls['pipe_calls'][0][1]
        reset(); f, _ = run({}); f({'image_b64': b64png(64, 64), key: hi_in}); b = calls['pipe_calls'][0][1]
        check('kẹp %s: %s→%s, %s→%s' % (key, lo_in, lo_out, hi_in, hi_out), a[key] == lo_out and b[key] == hi_out)
    reset(); f, _ = run({}); f({'image_b64': b64png(64, 64), 'noise_aug_strength': 5}); a = calls['pipe_calls'][0][1]['noise_aug_strength']
    reset(); f, _ = run({}); f({'image_b64': b64png(64, 64), 'noise_aug_strength': -1}); b = calls['pipe_calls'][0][1]['noise_aug_strength']
    check('kẹp noise_aug_strength vào [0,1]', a == 1.0 and b == 0.0)

    # letterbox
    reset(); f, _ = run({}); f({'image_b64': b64png(512, 768, (255, 0, 0))}); cv = calls['pipe_calls'][0][0]
    check('ảnh dọc 512x768 -> đặt giữa khung 1024x576, KHÔNG cắt: lề trái/phải đen, giữa đỏ, chiều cao đầy khung', cv.getpixel((5, 5)) == (0, 0, 0) and cv.getpixel((1020, 300)) == (0, 0, 0) and cv.getpixel((512, 288)) == (255, 0, 0) and cv.getpixel((512, 2))[0] > 200)
    reset(); f, _ = run({}); f({'image_b64': b64png(2048, 1152, (0, 255, 0))}); cv = calls['pipe_calls'][0][0]
    check('ảnh 16:9 lớn -> thu nhỏ vừa khung, không còn viền đen', cv.getpixel((2, 2)) == (0, 255, 0) and cv.getpixel((1021, 573)) == (0, 255, 0))
    reset(); f, _ = run({}); f({'image_b64': b64png(100, 100), 'width': 4000, 'height': 100}); cv = calls['pipe_calls'][0][0]
    check('width/height tuỳ chọn bị kẹp trong [256,1024] và chia hết cho 8', cv.size == (1024, 256))

    # seed
    reset(); f, _ = run({}); f({'image_b64': b64png(64, 64), 'seed': 7}); g1 = calls['pipe_calls'][0][1]['generator']
    reset(); f, _ = run({}); f({'image_b64': b64png(64, 64), 'seed': -1}); g2 = calls['pipe_calls'][0][1]['generator']
    check('seed ≥ 0 -> generator theo seed; seed < 0 -> None (ngẫu nhiên)', g1 == ('GEN', 7) and g2 is None)

    # lỗi đầu vào
    try:
        reset(); f, _ = run({}); f({}); raised = False
    except ValueError: raised = True
    check('thiếu image_b64 -> ValueError rõ ràng (server trả lỗi, client không thử lại mù quáng)', raised)

    # --keep-svd
    reset(); f, ns = run({}, keep=True); f({'image_b64': b64png(64, 64)}); n1 = calls['from_pretrained']; held = ns['_svd_pipe'] is not None
    f({'image_b64': b64png(64, 64)}); n2 = calls['from_pretrained']
    check('--keep-svd: giữ pipeline và KHÔNG tải lại ở request sau', n1 == 1 and held and n2 == 1)

    # pipeline lỗi vẫn giải phóng
    class Boom(FakePipe):
        def __call__(self, image, **kw): raise RuntimeError('OOM')
    def fp2(model_id, **kw): calls['from_pretrained'] += 1; return Boom()
    reset(); f, ns = run({}); sys.modules['diffusers'].StableVideoDiffusionPipeline.from_pretrained = fp2
    try: f({'image_b64': b64png(64, 64)}); err = False
    except RuntimeError: err = True
    check('pipeline lỗi giữa chừng (vd hết VRAM): lỗi được ném lên VÀ bộ nhớ vẫn được giải phóng (finally)', err and ns['_svd_pipe'] is None and calls['empty_cache'] >= 1)
    for m in ('torch', 'diffusers', 'diffusers.utils'): sys.modules.pop(m, None)

# ---------- phía Kotlin ----------
RV, RC, MP, ML, ST, PE, VM = rd('pipeline', 'RemoteVideo.kt'), rd('pipeline', 'RemoteGenerationClient.kt'), rd('pipeline', 'MangaPipeline.kt'), rd('model', 'Models.kt'), rd('ui', 'SettingsScreen.kt'), rd('pipeline', 'PublishExporter.kt'), rd('ui', 'MainViewModel.kt')
c = lambda n: int(re.search(r'const val %s = (\d+)' % n, RV).group(1))
check('Kotlin kẹp trùng với server: khung 6..25, fps 3..30, motion 1..255 (so với chữ số trong app.py)',
      (c('MIN_FRAMES'), c('MAX_FRAMES'), c('MIN_FPS'), c('MAX_FPS'), c('MIN_MOTION'), c('MAX_MOTION')) == (6, 25, 3, 30, 1, 255)
      and 'max(6, min(25, int(payload.get("num_frames"' in APP and 'max(3, min(30, int(payload.get("fps"' in APP and 'max(1, min(255, int(payload.get("motion_bucket_id"' in APP)
check('Kotlin: mặc định trùng server (14 khung, fps 7, motion 127, noise 0.02)', (c('DEFAULT_FRAMES'), c('DEFAULT_FPS'), c('DEFAULT_MOTION')) == (14, 7, 127) and 'DEFAULT_NOISE_AUG = 0.02f' in RV
      and 'payload.get("num_frames", 14)' in APP and 'payload.get("fps", 7)' in APP and 'payload.get("motion_bucket_id", 127)' in APP and 'payload.get("noise_aug_strength", 0.02)' in APP)
def is_mp4(b): return len(b) >= 12 and b[4:8] == b'ftyp'
check('isMp4: mp4 hợp lệ -> đúng; PNG / rỗng / ngắn -> sai (server cũ trả PNG bị từ chối)', is_mp4(b'\x00\x00\x00\x18ftypmp42\x00\x00\x00\x00') and not is_mp4(b'\x89PNG\r\n\x1a\n' + b'\x00' * 20) and not is_mp4(b'') and not is_mp4(b'ftyp'))
check('Kotlin: isMp4 khớp bản chép (byte 4..7 = f,t,y,p; cần ≥ 12 byte)', all(t in RV for t in ['b.size >= 12', "b[4] == 'f'.code.toByte()", "b[5] == 't'.code.toByte()", "b[6] == 'y'.code.toByte()", "b[7] == 'p'.code.toByte()"]))
check('client: payload task="video" + image_b64, cùng đường mã hoá (AES-GCM + RSA-OAEP) và cùng endpoint /generate', 'put("task", "video")' in RC and 'put("image_b64"' in RC and RC.count('aesGcmEncrypt(aesKey') >= 2 and RC.count('rsaOaepEncrypt(pubKey, aesKey.encoded)') >= 2)
check('client: thời hạn đọc riêng dài (≥ 900s), tham số được kẹp trước khi gửi', 'RemoteVideo.VIDEO_READ_TIMEOUT_S' in RC and 'RemoteVideo.clampFrames(numFrames)' in RC and 'RemoteVideo.clampFps(fps)' in RC and 'RemoteVideo.clampMotion(motionBucket)' in RC and 'VIDEO_READ_TIMEOUT_S = 900L' in RV)
check('client: KHÔNG thử lại lỗi cố định (server cũ trả PNG, HTTP lỗi) — chỉ thử lại 429/lỗi mạng', 'catch (ex: RemoteVideoException) {\n                throw ex' in RC and 'throw RemoteVideoException("Remote video thất bại: HTTP' in RC and 'throw RemoteVideoException("Server không trả về video' in RC and 'if (resp.code == 429)' in RC)
check('nối dây: Settings → ViewModel (chỉ khi Remote GPU bật) → ExportExtras → exportVideoPack(remote=)', 'exportVideoRemote: Boolean = false' in ML and 'videoRemote = if (st.exportVideoRemote && st.remoteEndpoint.enabled) st.remoteEndpoint else null' in VM
      and 'val videoRemote: RemoteEndpointConfig? = null' in PE and 'remote = extras.videoRemote' in MP and 'settings.exportVideoRemote' in ST and 'copy(exportVideoRemote = it)' in ST)
check('nối dây: lỗi một panel không làm hỏng gói; server không hỗ trợ video thì dừng thử các panel còn lại; clip vào zip + info.json',
      'remoteClient.generateVideo(startPng)' in MP and 'catch (ex: RemoteGenerationClient.RemoteVideoException)' in MP and 'remoteStopped = true' in MP and 'put(dir + "clip.mp4", clip)' in MP and 'meta["remoteClip"]' in MP)
check('nối dây: công tắc nằm BÊN TRONG khối `if (settings.exportVideoPack)` (cùng chỗ với giọng đọc)', ST.index('if (settings.exportVideoPack) {') < ST.index('Tạo clip chuyển động trên server') < ST.index('Khung đích'))

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
