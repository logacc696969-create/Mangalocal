// mục 284 — kiểm PoseRetargeter (BỀ NGANG vai/hông theo tuổi) bằng đáp án HÌNH HỌC độc lập: khoảng cách vai/hông đổi đúng hệ số; độ dài và GÓC mọi xương dọc theo chi giữ nguyên;
// tâm hông và cổ không đổi; đối xứng; xoay thân; nghịch đảo; hệ số xấu; đường tiếp xúc (IK); và dữ liệu JSON cũ thiếu trường widthRatio.
import com.mangalocal.model.AgeBodyTable
import com.mangalocal.model.BodySex
import com.mangalocal.model.BoneProportions
import com.mangalocal.pipeline.PoseRetargeter
import com.mangalocal.pipeline.StoryManager
import com.mangalocal.pipeline.StoryManager.PoseKeypoint
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

var fails = 0; var passes = 0
fun check(c: Boolean, n: String) { if (c) { passes++; println("PASS $n") } else { fails++; println("FAIL $n") } }
fun near(a: Float, b: Float, e: Float = 1e-4f) = abs(a - b) <= e
fun d(a: PoseKeypoint, b: PoseKeypoint) = hypot(a.x - b.x, a.y - b.y)
fun ang(a: PoseKeypoint, b: PoseKeypoint) = atan2(b.y - a.y, b.x - a.x)
fun angDiff(a: Float, b: Float): Float { var x = (a - b) % (2 * Math.PI.toFloat()); if (x > Math.PI) x -= 2 * Math.PI.toFloat(); if (x < -Math.PI) x += 2 * Math.PI.toFloat(); return abs(x) }

// Người đứng, tay gập, chân hơi dạng. Xoay cả khung quanh tâm hông một góc rot (rad) để thử trục thân nghiêng.
fun person(rot: Float = 0f): MutableList<PoseKeypoint> {
    val raw = listOf(0.50f to 0.14f, 0.50f to 0.24f, 0.43f to 0.25f, 0.38f to 0.36f, 0.42f to 0.46f, 0.57f to 0.25f, 0.64f to 0.34f, 0.60f to 0.30f,
                     0.46f to 0.56f, 0.44f to 0.72f, 0.45f to 0.90f, 0.54f to 0.56f, 0.57f to 0.72f, 0.58f to 0.90f, 0.48f to 0.12f, 0.52f to 0.12f, 0.46f to 0.13f, 0.54f to 0.13f)
    val cx = 0.50f; val cy = 0.56f
    return raw.map { (x, y) -> val dx = x - cx; val dy = y - cy
        PoseKeypoint(cx + dx * cos(rot) - dy * sin(rot), cy + dx * sin(rot) + dy * cos(rot), 0f, true, 1f) }.toMutableList()
}
fun center(p: List<PoseKeypoint>) = PoseKeypoint((p[8].x + p[11].x) / 2, (p[8].y + p[11].y) / 2, 0f, true, 1f)
val ADULT = BoneProportions()
fun lens(p: List<PoseKeypoint>) = listOf(d(p[2], p[3]), d(p[3], p[4]), d(p[5], p[6]), d(p[6], p[7]), d(p[8], p[9]), d(p[9], p[10]), d(p[11], p[12]), d(p[12], p[13]))
val bones = listOf(2 to 3, 3 to 4, 5 to 6, 6 to 7, 8 to 9, 9 to 10, 11 to 12, 12 to 13)

fun main() {
    val p = person()
    // 1. không đổi gì
    check(PoseRetargeter.retargetPerson(p, ADULT, ADULT) == p, "nguồn = đích: trả nguyên khung xương")
    // 2. CHỈ đổi bề ngang
    for (k in listOf(0.5f, 0.69f, 0.88f, 1.2f)) {
        val t = ADULT.copy(widthRatio = k); val o = PoseRetargeter.retargetPerson(p, ADULT, t)
        check(near(d(o[2], o[5]), d(p[2], p[5]) * k) && near(d(o[8], o[11]), d(p[8], p[11]) * k), "chỉ đổi bề ngang ×$k: khoảng cách hai vai và hai hông đúng ×$k")
    }
    run {
        val t = ADULT.copy(widthRatio = 0.7f); val o = PoseRetargeter.retargetPerson(p, ADULT, t)
        check(near(center(o).x, center(p).x, 1e-6f) && near(center(o).y, center(p).y, 1e-6f), "tâm hông KHÔNG đổi")
        check(near(o[1].x, p[1].x, 1e-6f) && near(o[1].y, p[1].y, 1e-6f), "cổ KHÔNG đổi (thân không đổi dài)")
        check(lens(o).zip(lens(p)).all { (a, b) -> near(a, b, 1e-5f) }, "độ dài cả 8 xương tay/chân KHÔNG đổi")
        check(bones.all { (a, b) -> angDiff(ang(o[a], o[b]), ang(p[a], p[b])) < 1e-4f }, "GÓC cả 8 xương tay/chân KHÔNG đổi (chỉ dời gốc xương)")
        // vai: offset cổ→vai nhân k; hông: offset tâm→hông nhân k
        check(near(o[2].x - o[1].x, (p[2].x - p[1].x) * 0.7f, 1e-5f) && near(o[2].y - o[1].y, (p[2].y - p[1].y) * 0.7f, 1e-5f)
            && near(o[5].x - o[1].x, (p[5].x - p[1].x) * 0.7f, 1e-5f) && near(o[5].y - o[1].y, (p[5].y - p[1].y) * 0.7f, 1e-5f), "vai: offset cổ→vai nhân đúng 0,7 (cả hai bên, cả x lẫn y)")
        val c = center(p)
        check(near(o[8].x - c.x, (p[8].x - c.x) * 0.7f, 1e-5f) && near(o[8].y - c.y, (p[8].y - c.y) * 0.7f, 1e-5f)
            && near(o[11].x - c.x, (p[11].x - c.x) * 0.7f, 1e-5f) && near(o[11].y - c.y, (p[11].y - c.y) * 0.7f, 1e-5f), "hông: offset tâm hông→hông nhân đúng 0,7")
        check(near((o[8].x - c.x) + (o[11].x - c.x), 0f, 1e-5f) && near((o[8].y - c.y) + (o[11].y - c.y), 0f, 1e-5f), "hai hông vẫn ĐỐI XỨNG qua tâm hông")
        check(listOf(0, 14, 15, 16, 17).all { near(o[it].x - o[1].x, p[it].x - p[1].x, 1e-6f) && near(o[it].y - o[1].y, p[it].y - p[1].y, 1e-6f) }, "đầu (mũi, mắt, tai) KHÔNG đổi so với cổ")
        check(o.indices.all { it == 2 || it == 5 || it == 8 || it == 11 || it in listOf(3, 4, 6, 7, 9, 10, 12, 13) || (near(o[it].x, p[it].x, 1e-6f)) }, "điểm không liên quan bề ngang giữ nguyên toạ độ")
    }
    // 3. k = 1 (cùng widthRatio nguồn và đích) nhưng đổi tỷ lệ khác: vai GIỮ offset cổ→vai, hông GIỮ NGUYÊN vị trí (đúng trước mục 284)
    run {
        // chỉ đổi thân/tay (KHÔNG đụng chân: đổi độ dài chân làm neo mặt đất dịch cả khung từ mục 113 nên hông không đứng yên)
        val t = ADULT.copy(torsoRatio = 0.8f, upperArmRatio = 0.9f, forearmRatio = 0.9f); val o = PoseRetargeter.retargetPerson(p, ADULT, t)
        check(o[8] == p[8] && o[11] == p[11], "k = 1: hông giữ NGUYÊN vị trí (từng bit)")
        check(near(o[2].x - o[1].x, p[2].x - p[1].x, 1e-7f) && near(o[5].y - o[1].y, p[5].y - p[1].y, 1e-7f), "k = 1: offset cổ→vai giữ nguyên")
    }
    // 4. nguồn và đích cùng widthRatio ≠ 1: k = 1
    run {
        val s = ADULT.copy(widthRatio = 0.7f, torsoRatio = 1.1f); val t = ADULT.copy(widthRatio = 0.7f, torsoRatio = 0.9f); val o = PoseRetargeter.retargetPerson(p, s, t)
        check(o[8] == p[8] && o[11] == p[11] && near(d(o[2], o[5]) / d(o[1], o[1].copy(x = o[1].x + 1f)), d(p[2], p[5]), 1e-4f), "nguồn và đích cùng widthRatio 0,7: bề ngang không đổi (k = 1)")
        val o2 = PoseRetargeter.retargetPerson(p, ADULT.copy(widthRatio = 0.7f), ADULT.copy(widthRatio = 1.0f))
        check(near(d(o2[2], o2[5]), d(p[2], p[5]) / 0.7f, 1e-4f), "nguồn 0,7 → đích 1,0: bề ngang nở ×(1/0,7)")
    }
    // 5. preset theo tuổi: bề ngang đúng widthRatio, độ dài xương theo hệ số RIÊNG
    for (age in listOf(6, 8, 12, 16)) {
        val t = BoneProportions.forAge(age); val o = PoseRetargeter.retargetPerson(p, ADULT, t)
        check(near(d(o[2], o[5]), d(p[2], p[5]) * t.widthRatio, 2e-4f) && near(d(o[8], o[11]), d(p[8], p[11]) * t.widthRatio, 2e-4f), "preset $age tuổi: vai và hông ×${"%.3f".format(t.widthRatio)} (khớp AgeBodyTable.widthVsAdult)")
        check(near(d(o[2], o[3]), d(p[2], p[3]) * t.upperArmRatio, 2e-4f) && near(d(o[9], o[10]), d(p[9], p[10]) * t.lowerLegRatio, 2e-4f), "preset $age tuổi: độ dài cánh tay trên/cẳng chân vẫn theo hệ số riêng (không lẫn bề ngang)")
    }
    // 6. thân nghiêng (xoay 25° và −40°): bề ngang vẫn nhân đúng, hướng đường hai hông/hai vai giữ nguyên
    for (rot in listOf(0.436f, -0.70f)) {
        val q = person(rot); val o = PoseRetargeter.retargetPerson(q, ADULT, ADULT.copy(widthRatio = 0.6f))
        check(near(d(o[8], o[11]), d(q[8], q[11]) * 0.6f) && angDiff(ang(o[11], o[8]), ang(q[11], q[8])) < 1e-4f, "thân nghiêng ${"%.0f".format(rot * 57.3f)}°: hông ×0,6 và HƯỚNG đường hai hông giữ nguyên")
        check(near(d(o[2], o[5]), d(q[2], q[5]) * 0.6f) && angDiff(ang(o[5], o[2]), ang(q[5], q[2])) < 1e-4f, "thân nghiêng ${"%.0f".format(rot * 57.3f)}°: vai ×0,6 và hướng đường hai vai giữ nguyên")
    }
    // 7. nghịch đảo: adult → trẻ → adult trả bề ngang về cũ
    run {
        val t = BoneProportions.forAge(7); val mid = PoseRetargeter.retargetPerson(p, ADULT, t); val back = PoseRetargeter.retargetPerson(mid, t, ADULT)
        check(near(d(back[2], back[5]), d(p[2], p[5]), 1e-4f) && near(d(back[8], back[11]), d(p[8], p[11]), 1e-4f), "adult → 7 tuổi → adult: bề ngang vai/hông trở về như cũ")
    }
    // 8. hệ số xấu coi như 1,0 (dữ liệu cũ thiếu trường, người dùng nhập bậy)
    for (bad in listOf(0f, -1f, Float.NaN, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY)) {
        val a = PoseRetargeter.retargetPerson(p, ADULT, ADULT.copy(widthRatio = bad, torsoRatio = 0.9f)); val b = PoseRetargeter.retargetPerson(p, ADULT, ADULT.copy(widthRatio = 1f, torsoRatio = 0.9f))
        check(a.indices.all { near(a[it].x, b[it].x, 1e-6f) && near(a[it].y, b[it].y, 1e-6f) && a[it].x.isFinite() }, "widthRatio = $bad ≡ 1,0 (không NaN, không đổi bề ngang)")
    }
    // 9. thiếu hông (không retarget mù) và vai khuất không bị đụng
    run {
        val q = person().also { it[8] = it[8].copy(visible = false) }; val o = PoseRetargeter.retargetPerson(q, ADULT, ADULT.copy(widthRatio = 0.5f))
        check(o == q, "thiếu điểm hông: trả nguyên (không retarget mù)")
        val r = person().also { it[2] = it[2].copy(visible = false) }; val o2 = PoseRetargeter.retargetPerson(r, ADULT, ADULT.copy(widthRatio = 0.5f))
        check(o2[2] == r[2] && near(d(o2[8], o2[11]), d(r[8], r[11]) * 0.5f), "vai phải khuất giữ nguyên, hông vẫn co theo bề ngang")
    }
    // 10. đường TIẾP XÚC (IK, applyGroundAnchor = false): bề ngang vẫn nhân đúng, mọi toạ độ hữu hạn
    run {
        val v = StoryManager.PoseVariant(people = mutableListOf(person(), person(0.2f).also { for (i in it.indices) it[i] = it[i].copy(x = it[i].x + 0.25f) }), actionTags = listOf("hug"))
        val tt = listOf(BoneProportions.forAge(8), BoneProportions.forAge(14)); val out = PoseRetargeter.retargetVariant(v, tt)
        check(out.size == 2 && out.all { pl -> pl.all { it.x.isFinite() && it.y.isFinite() } }, "tư thế tiếp xúc (hug): kết quả hữu hạn, đủ 2 người")
        check(near(d(out[0][8], out[0][11]), d(v.people[0][8], v.people[0][11]) * tt[0].widthRatio, 5e-4f) && near(d(out[1][2], out[1][5]), d(v.people[1][2], v.people[1][5]) * tt[1].widthRatio, 5e-4f), "tư thế tiếp xúc: hông người 1 và vai người 2 vẫn nhân đúng bề ngang theo tuổi từng người")
    }
    // 11. kích thước: trẻ 6 tuổi hẹp hơn người lớn một cách ĐO ĐƯỢC (≈ 0,685), không phải 1
    run {
        val o = PoseRetargeter.retargetPerson(p, ADULT, BoneProportions.forAge(6)); val r = d(o[2], o[5]) / d(p[2], p[5])
        check(r in 0.67f..0.70f, "người lớn → 6 tuổi: vai hẹp còn ${"%.3f".format(r)} (số đo thật ≈ 0,685)")
    }
    // 12. dữ liệu JSON CŨ thiếu widthRatio: Gson dựng bằng hàm tạo mặc định ⇒ 1,0 (không phải 0)
    run {
        val g = com.google.gson.Gson()
        val old = g.fromJson("{\"torsoRatio\":0.8,\"headSizeRatio\":1.1}", BoneProportions::class.java)
        check(old.widthRatio == 1.0f && old.torsoRatio == 0.8f, "JSON cũ thiếu widthRatio nạp ra 1,0 (không rơi về 0)")
        val rt = g.fromJson(g.toJson(BoneProportions.forAge(9)), BoneProportions::class.java)
        check(rt == BoneProportions.forAge(9) && rt.widthRatio < 1f, "khứ hồi JSON preset 9 tuổi giữ nguyên widthRatio")
        check(BoneProportions.forAge(AgeBodyTable.ADULT_AGE) == BoneProportions(), "forAge(18) vẫn ĐÚNG BẰNG BoneProportions() (widthRatio = 1,0 từng bit)")
    }
    // 13. mục 285: HÔNG có hệ số RIÊNG (hipWidthRatio); chưa đặt (0) ⇒ theo vai y hệt trước mục 285
    run {
        val o = PoseRetargeter.retargetPerson(p, ADULT, ADULT.copy(widthRatio = 1f, hipWidthRatio = 0.6f))
        check(near(d(o[8], o[11]), d(p[8], p[11]) * 0.6f) && near(d(o[2], o[5]), d(p[2], p[5])), "hông riêng ×0,6 mà vai giữ nguyên")
        val o2 = PoseRetargeter.retargetPerson(p, ADULT, ADULT.copy(widthRatio = 0.7f, hipWidthRatio = 1.2f))
        check(near(d(o2[2], o2[5]), d(p[2], p[5]) * 0.7f) && near(d(o2[8], o2[11]), d(p[8], p[11]) * 1.2f), "vai ×0,7 và hông ×1,2 độc lập với nhau")
        val a = PoseRetargeter.retargetPerson(p, ADULT, ADULT.copy(widthRatio = 0.8f)); val b = PoseRetargeter.retargetPerson(p, ADULT, ADULT.copy(widthRatio = 0.8f, hipWidthRatio = 0.8f))
        check(a == b && near(d(a[8], a[11]), d(p[8], p[11]) * 0.8f), "hipWidthRatio = 0 (không đặt) cho kết quả GIỐNG HỆT đặt hông = vai: dữ liệu cũ không đổi")
        check(PoseRetargeter.hipScale(ADULT, ADULT.copy(widthRatio = 0.8f)) == PoseRetargeter.widthScale(ADULT, ADULT.copy(widthRatio = 0.8f)), "hipScale == widthScale khi chưa đặt hông riêng (từng bit)")
        check(near(center(o2).x, center(p).x, 1e-6f) && lens(o2).zip(lens(p)).all { (x, y) -> near(x, y, 1e-5f) } && bones.all { (u, v) -> angDiff(ang(o2[u], o2[v]), ang(p[u], p[v])) < 1e-4f }, "đổi hông riêng: tâm hông, độ dài và GÓC mọi xương chi giữ nguyên")
        val f = BoneProportions.forAge(18, BodySex.FEMALE); val m = BoneProportions.forAge(18, BodySex.MALE)
        val of = PoseRetargeter.retargetPerson(p, ADULT, f); val om = PoseRetargeter.retargetPerson(p, ADULT, m)
        check(near(d(of[2], of[5]) / d(p[2], p[5]), f.widthRatio) && near(d(of[8], of[11]) / d(p[8], p[11]), f.hipWidthRatio), "người lớn trung bình → nữ 18: vai ×${"%.3f".format(f.widthRatio)}, hông ×${"%.3f".format(f.hipWidthRatio)} (hai hệ số khác nhau)")
        val sf = d(of[2], of[5]) / d(of[8], of[11]); val sm = d(om[2], om[5]) / d(om[8], om[11])
        check(sm > sf * 1.07f, "tỷ lệ vai/hông của nam lớn hơn nữ ≥ 7% sau retarget (${"%.3f".format(sm / sf)}) — nét dị biệt giới nhìn thấy được trên khung xương")
        val ofm = PoseRetargeter.retargetPerson(of, f, m)    // nguồn CÓ hông riêng → đích: hệ số = tỷ số hai bên
        check(near(d(ofm[8], ofm[11]) / d(of[8], of[11]), m.hipWidthRatio / f.hipWidthRatio) && near(d(ofm[2], ofm[5]) / d(of[2], of[5]), m.widthRatio / f.widthRatio), "nguồn có hông riêng: hệ số hông = đích/nguồn của CHÍNH hông (không lẫn với vai)")
        check(PoseRetargeter.retargetPerson(of, f, f) == of, "nguồn = đích có hông riêng: trả nguyên khung xương")
    }
    println(if (fails == 0) "ĐẠT ($passes)" else "THẤT BẠI: $fails")
    if (fails != 0) System.exit(1)
}
