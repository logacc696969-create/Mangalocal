package com.mangalocal.pipeline
// Stub tối thiểu: chỉ có PoseKeypoint, đúng chữ ký ở StoryManager.kt (class StoryManager { data class PoseKeypoint(...) }).
class StoryManager { data class PoseKeypoint(val x: Float = 0f, val y: Float = 0f, val z: Float = 0f, val visible: Boolean = false, val confidence: Float = 1f) }
