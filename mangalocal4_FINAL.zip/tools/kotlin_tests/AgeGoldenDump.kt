// mục 285 — in ra HÀNH VI CỦA MÃ TRƯỚC MỤC 285 (không chọn giới) dưới dạng bit của Float, để làm "đáp án vàng" (tools/data/age_body_unisex_golden.txt).
// Biên dịch với mã CHƯA sửa; sau khi thêm giới, test kiểm nhánh mặc định (UNSPECIFIED) cho ĐÚNG từng bit các số này.
import com.mangalocal.model.AgeBodyTable
import com.mangalocal.model.BoneProportions

fun b(f: Float) = java.lang.Float.floatToRawIntBits(f).toUInt().toString(16).padStart(8, '0')
fun seg(s: AgeBodyTable.Segments) = listOf(s.head, s.trunk, s.shoulder, s.thigh, s.shank, s.upperArm, s.forearm).joinToString(" ") { b(it) }
fun main() {
    for (age in 4..20) {   // kể cả ngoài 6–18 (kẹp)
        println("A $age ${b(AgeBodyTable.heightCm(age))} ${b(AgeBodyTable.headSizeVsAdult(age))} ${b(AgeBodyTable.headsTall(age))} ${b(AgeBodyTable.widthVsAdult(age))} ${b(AgeBodyTable.widthSpread(age))} ${b(AgeBodyTable.shoulderFraction(age))}")
        println("F $age ${seg(AgeBodyTable.heightFractions(age))}")
        println("R $age ${seg(AgeBodyTable.ratiosVsAdult(age))}")
        val p = BoneProportions.forAge(age)
        println("P $age ${listOf(p.torsoRatio, p.upperArmRatio, p.forearmRatio, p.upperLegRatio, p.lowerLegRatio, p.headSizeRatio, p.widthRatio).joinToString(" ") { b(it) }} ${b(p.approxHeadsTall())} ${p.headsTallPromptTag()}")
    }
    for ((a, c) in listOf(8 to 18, 18 to 8, 12 to 14, 6 to 6, 14 to 8, 18 to 12)) println("X $a $c ${seg(AgeBodyTable.factors(a, c))}")
}
