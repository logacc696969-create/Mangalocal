// mục 280 — cầu nối Kotlin cho test TÍCH HỢP với mô hình BlazePose THẬT (tools/test_blazepose_lift.py điều phối: Kotlin cắt ROI → Python chạy model → Kotlin phân tích → Python so với tham chiếu).
// Giao tiếp bằng tệp văn bản/nhị phân đơn giản, không cần thư viện JSON.
//   cases.txt, mỗi dòng:  tên|đường_dẫn_ảnh|box|x1 y1 x2 y2                  (chuẩn hoá theo ảnh)
//                         tên|đường_dẫn_ảnh|kps|18 × "x y v"                 (OpenPose-18, chuẩn hoá theo ảnh, v = 0/1)
//   crop  <cases.txt> <outdir>: ghi <tên>.crop.f32 (256*256*3 float LE, HWC, 0..1) và <tên>.roi.txt (cx cy size rotation)
//   parse <cases.txt> <outdir>: đọc <tên>.out.f32 (313 float LE) → ghi <tên>.lifted.txt (33 dòng: imgX imgY vis wx wy wz) và, với ca kps, <tên>.z.txt (18 dòng z, "nan" nếu depthFor null)
import com.mangalocal.pipeline.BlazePoseLift
import com.mangalocal.pipeline.StoryManager.PoseKeypoint
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.imageio.ImageIO

class Case(val name: String, val image: String, val mode: String, val data: List<Float>)

fun readCases(path: String) = File(path).readLines().filter { it.isNotBlank() }.map {
    val p = it.split("|"); Case(p[0], p[1], p[2], p[3].trim().split(Regex("\\s+")).map { s -> s.toFloat() })
}

fun person(c: Case): MutableList<PoseKeypoint> =
    if (c.mode == "kps") MutableList(18) { i -> PoseKeypoint(c.data[3 * i], c.data[3 * i + 1], 0f, c.data[3 * i + 2] > 0.5f, 1f) }
    else MutableList(18) { PoseKeypoint() }

fun main(args: Array<String>) {
    val mode = args[0]; val cases = readCases(args[1]); val out = File(args[2]); out.mkdirs()
    for (c in cases) {
        val img = ImageIO.read(File(c.image)); val w = img.width; val h = img.height
        val px = img.getRGB(0, 0, w, h, null, 0, w)
        val per = person(c)
        val box = if (c.mode == "box") floatArrayOf(c.data[0], c.data[1], c.data[2], c.data[3]) else null
        val roi = BlazePoseLift.roiFromPerson(per, w, h, box) ?: error("không dựng được ROI cho ${c.name}")
        if (mode == "crop") {
            val crop = BlazePoseLift.sampleCrop(px, w, h, roi)
            val bb = ByteBuffer.allocate(crop.size * 4).order(ByteOrder.LITTLE_ENDIAN); crop.forEach { bb.putFloat(it) }
            File(out, "${c.name}.crop.f32").writeBytes(bb.array())
            File(out, "${c.name}.roi.txt").writeText("${roi.cx} ${roi.cy} ${roi.size} ${roi.rotation}\n")
        } else {
            val raw = ByteBuffer.wrap(File(out, "${c.name}.out.f32").readBytes()).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().let { fb -> FloatArray(fb.remaining()).also { fb.get(it) } }
            val lf = BlazePoseLift.parseOutput(raw, roi) ?: error("parseOutput null cho ${c.name} (cờ=${raw.getOrNull(0)})")
            File(out, "${c.name}.lifted.txt").writeText((0 until 33).joinToString("\n") { "${lf.imgX[it]} ${lf.imgY[it]} ${lf.visibility[it]} ${lf.worldX[it]} ${lf.worldY[it]} ${lf.worldZ[it]}" } + "\n")
            if (c.mode == "kps") {
                val d = BlazePoseLift.depthFor(per, lf, w.toFloat() / h)   // mục 282: đúng như BlazePoseEstimator.lift
                File(out, "${c.name}.z.txt").writeText((0 until 18).joinToString("\n") { if (d == null) "nan" else d[it].z.toString() } + "\n")
            }
        }
    }
}
