// mục 288 — test CHẠY MÃ KOTLIN THẬT cho BodyVariation (nhịp + kích thước + nội suy tuổi phân số). Biên dịch cùng AgeBodyTable.kt — xem tools/test_body_variation.py.
import com.mangalocal.model.AgeBodyTable
import com.mangalocal.model.AgeBodyTable.Segments
import com.mangalocal.model.BodySex
import com.mangalocal.model.BodyVariation
import kotlin.math.abs

var fails = 0
fun check(ok: Boolean, name: String) { println((if (ok) "PASS " else "FAIL ") + name); if (!ok) fails++ }
fun near(a: Float, b: Float, eps: Float = 1e-5f) = abs(a - b) <= eps
fun fields(s: Segments) = floatArrayOf(s.head, s.trunk, s.shoulder, s.thigh, s.shank, s.upperArm, s.forearm, s.hip)
val SEXES = listOf(BodySex.MALE, BodySex.FEMALE, BodySex.UNSPECIFIED)

fun main() {
    // 1) tuổi nguyên + tempo 0 => BẰNG HỆT (==) hàm Int cũ — thêm tính năng không đổi hành vi
    var same = true
    for (s in SEXES) for (a in 6..18) {
        if (BodyVariation.heightCmAt(a.toFloat(), s) != AgeBodyTable.heightCm(a, s)) same = false
        if (!fields(BodyVariation.heightFractionsAt(a.toFloat(), s)).contentEquals(fields(AgeBodyTable.heightFractions(a, s)))) same = false
    }
    check(same, "tuổi nguyên + tempo 0: heightCmAt/heightFractionsAt BẰNG HỆT (==) hàm Int của AgeBodyTable, cả 3 giới × 13 tuổi")

    // 2) nội suy: tại a+0.5 là trung bình hai đầu; luôn nằm giữa hai đầu; liên tục (không nhảy)
    var mid = true; var between = true; var cont = true
    for (s in SEXES) for (a in 6..17) {
        val lo = fields(AgeBodyTable.heightFractions(a, s)); val hi = fields(AgeBodyTable.heightFractions(a + 1, s)); val m = fields(BodyVariation.heightFractionsAt(a + 0.5f, s))
        for (i in lo.indices) { if (!near(m[i], (lo[i] + hi[i]) / 2f, 1e-5f)) mid = false }
        for (w in listOf(0.1f, 0.3f, 0.7f, 0.9f)) { val x = fields(BodyVariation.heightFractionsAt(a + w, s)); for (i in lo.indices) { val l = minOf(lo[i], hi[i]) - 1e-6f; val h = maxOf(lo[i], hi[i]) + 1e-6f; if (x[i] < l || x[i] > h) between = false } }
        val h0 = BodyVariation.heightCmAt(a + 0.999f, s); val h1 = BodyVariation.heightCmAt((a + 1).toFloat(), s); if (abs(h0 - h1) > 0.5f) cont = false
    }
    check(mid, "nội suy: tại a+0,5 mọi trường tỷ lệ = trung bình hai tuổi nguyên kề")
    check(between, "nội suy: mọi trường tại a+0,1/0,3/0,7/0,9 nằm giữa hai đầu (không vượt)")
    check(cont, "nội suy: chiều cao liên tục tại ranh tuổi nguyên (a+0,999 ≈ a+1)")

    // 3) kẹp ngoài dải bảng, NaN không làm hỏng
    check(BodyVariation.heightCmAt(3f) == AgeBodyTable.heightCm(6) && BodyVariation.heightCmAt(30f) == AgeBodyTable.heightCm(18), "ngoài dải 6–18: kẹp vào đầu/cuối bảng, KHÔNG ngoại suy")
    check(!BodyVariation.heightCmAt(Float.NaN).isNaN() && !BodyVariation.sizeScale(10f, BodySex.MALE, Float.NaN).isNaN() && BodyVariation.biologicalAge(10f, Float.NaN) == 10f, "NaN: không lan ra kết quả (tuổi→6, z→0, tempo→0)")
    check(BodyVariation.biologicalAge(10f, 99f) == 13f && BodyVariation.biologicalAge(10f, -99f) == 7f, "tempo kẹp ±3 năm")
    check(BodyVariation.biologicalAge(17f, 3f) == 18f && BodyVariation.biologicalAge(7f, -3f) == 6f, "tuổi sinh học kẹp trong dải bảng")

    // 4) nhịp: sớm => cao hơn/trưởng thành hơn ở tuổi giữa dậy thì; đơn điệu theo tempo; người lớn không đổi theo nhịp dương
    var mono = true; var early = true
    for (s in listOf(BodySex.MALE, BodySex.FEMALE)) for (a in 8..15) {
        var prev = -1f
        for (t in listOf(-2f, -1f, 0f, 1f, 2f)) { val h = BodyVariation.heightCmAt(a.toFloat(), s, t); if (h < prev - 1e-4f) mono = false; prev = h }
        if (!(BodyVariation.heightCmAt(a.toFloat(), s, 1.5f) > BodyVariation.heightCmAt(a.toFloat(), s, -1.5f))) early = false
    }
    check(mono, "chiều cao không GIẢM khi tempo tăng (nam/nữ, 8–15 tuổi, tempo −2…+2)")
    check(early, "người dậy thì sớm (+1,5 năm) cao hơn người muộn (−1,5) cùng tuổi cùng giới ở 8–15 tuổi")
    check(BodyVariation.heightCmAt(18f, BodySex.MALE, 2f) == AgeBodyTable.heightCm(18, BodySex.MALE) && BodyVariation.heightCmAt(18f, BodySex.FEMALE, 1f) == AgeBodyTable.heightCm(18, BodySex.FEMALE),
        "kích thước người lớn KHÔNG đổi theo nhịp dương (18 tuổi, tempo ≥ 0 = chiều cao người lớn của bảng)")
    // nhịp nữ sớm hơn nam ~1,8 năm (287.3c): nữ tại tuổi a ≈ nam tại a+1,8 về chiều cao TƯƠNG ĐỐI so với người lớn cùng giới
    var shiftOk = true
    for (a in 9..11) { val fr = BodyVariation.heightCmAt(a.toFloat(), BodySex.FEMALE) / AgeBodyTable.heightCm(18, BodySex.FEMALE); val mr = BodyVariation.heightCmAt(a + 1.8f, BodySex.MALE) / AgeBodyTable.heightCm(18, BodySex.MALE); if (abs(fr - mr) > 0.025f) shiftOk = false }
    check(shiftOk, "đối chiếu độc lập với 287.3c: nữ tuổi a ≈ nam tuổi a+1,8 về % chiều cao người lớn cùng giới (sai ≤ 2,5% ở 9–11 tuổi)")

    // 5) kích thước: z=0 => đúng 1; đối xứng; đơn điệu; CV đúng cỡ 287.3a; kẹp ±3
    var one = true; var sym = true; var up = true
    for (s in SEXES) for (a in 6..18) { if (BodyVariation.sizeScale(a.toFloat(), s, 0f) != 1f) one = false
        val p = BodyVariation.sizeScale(a.toFloat(), s, 1f); val m = BodyVariation.sizeScale(a.toFloat(), s, -1f); if (!near(p + m, 2f, 1e-5f)) sym = false
        if (!(BodyVariation.sizeScale(a.toFloat(), s, 2f) > p && p > 1f && m < 1f)) up = false }
    check(one, "heightZ = 0 => hệ số ĐÚNG 1,0 (==) mọi tuổi, mọi giới")
    check(sym, "z=+1 và z=−1 đối xứng quanh 1,0 (cộng lại = 2)")
    check(up, "hệ số tăng nghiêm ngặt theo z; z>0 → >1, z<0 → <1")
    check(BodyVariation.cv(13f, BodySex.MALE) in 0.0500f..0.0506f && BodyVariation.cv(11f, BodySex.FEMALE) in 0.0503f..0.0507f, "CV đỉnh dậy thì ≈ 5,03% (nam 13 tuổi) / 5,05% (nữ 11 tuổi) — khớp 287.3a")
    check(BodyVariation.cv(18f, BodySex.MALE) in 0.0404f..0.0409f && BodyVariation.cv(18f, BodySex.FEMALE) in 0.0395f..0.0399f, "CV người lớn ≈ 4,0% — khớp 287.3a")
    check(near(BodyVariation.sizeScale(13f, BodySex.MALE, 99f), 1f + 3f * BodyVariation.cv(13f, BodySex.MALE)) && near(BodyVariation.sizeScale(13f, BodySex.MALE, -99f), 1f - 3f * BodyVariation.cv(13f, BodySex.MALE)), "z kẹp ±3 SD")
    check(near(BodyVariation.cv(12.5f, BodySex.MALE), (BodyVariation.cv(12f, BodySex.MALE) + BodyVariation.cv(13f, BodySex.MALE)) / 2f, 1e-6f), "CV nội suy tuyến tính theo tuổi phân số")
    println(if (fails == 0) "TẤT CẢ ĐẠT" else "CÓ LỖI: $fails")
    if (fails > 0) System.exit(1)
}
