// mục 278 — test CHẠY MÃ KOTLIN THẬT (không mô phỏng) cho AgeBodyTable + AgeBodyScaler + BoneProportions.forAge.
// Biên dịch cùng StubStoryManager.kt (chỉ cần StoryManager.PoseKeypoint) bằng kotlinc — xem tools/test_age_body_table.py.
import com.mangalocal.model.AgeBodyTable
import com.mangalocal.model.BoneProportions
import com.mangalocal.pipeline.AgeBodyScaler
import com.mangalocal.pipeline.StoryManager.PoseKeypoint
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot

var fails = 0
fun check(ok: Boolean, name: String) { println((if (ok) "PASS " else "FAIL ") + name); if (!ok) fails++ }
fun near(a: Float, b: Float, eps: Float = 1e-4f) = abs(a - b) <= eps

fun P(x: Float, y: Float) = PoseKeypoint(x, y, 0f, true, 1f)
/** người đứng thẳng, hơi lệch (không đối xứng tuyệt đối) để bắt lỗi giả định đối xứng */
fun standing(): MutableList<PoseKeypoint> {
    val s = MutableList(18) { PoseKeypoint() }
    s[0] = P(.50f, .12f); s[1] = P(.50f, .20f); s[2] = P(.44f, .21f); s[5] = P(.56f, .21f)
    s[3] = P(.42f, .33f); s[6] = P(.59f, .32f); s[4] = P(.41f, .45f); s[7] = P(.60f, .44f)
    s[8] = P(.46f, .50f); s[11] = P(.54f, .50f); s[9] = P(.45f, .70f); s[12] = P(.55f, .71f); s[10] = P(.45f, .90f); s[13] = P(.55f, .91f)
    s[14] = P(.48f, .10f); s[15] = P(.52f, .10f); s[16] = P(.46f, .11f); s[17] = P(.54f, .11f)
    return s
}
/** tay gập, chân gập (ngồi xổm một phần), thân nghiêng */
fun bent(): MutableList<PoseKeypoint> {
    val s = standing()
    s[3] = P(.40f, .30f); s[4] = P(.50f, .33f)      // tay phải gập
    s[6] = P(.60f, .31f); s[7] = P(.58f, .20f)      // tay trái giơ lên
    s[9] = P(.40f, .62f); s[10] = P(.47f, .80f)     // chân phải gập
    s[1] = P(.53f, .21f)                            // cổ lệch
    return s
}
fun d(s: List<PoseKeypoint>, a: Int, b: Int) = hypot(s[b].x - s[a].x, s[b].y - s[a].y)
fun ang(s: List<PoseKeypoint>, a: Int, b: Int) = atan2(s[b].y - s[a].y, s[b].x - s[a].x)
fun hip(s: List<PoseKeypoint>) = Pair((s[8].x + s[11].x) / 2f, (s[8].y + s[11].y) / 2f)
fun trunk(s: List<PoseKeypoint>): Float { val h = hip(s); return hypot(s[1].x - h.first, s[1].y - h.second) }
fun mean2(a: Float, b: Float) = (a + b) / 2f
fun chainTotal(s: List<PoseKeypoint>) = d(s, 0, 1) + trunk(s) + mean2(d(s, 8, 9), d(s, 11, 12)) + mean2(d(s, 9, 10), d(s, 12, 13))

fun main() {
    // ── bảng số liệu ──
    check(near(AgeBodyTable.heightCm(6), (118.2f + 117.4f) / 2f), "heightCm(6) = trung bình nam-nữ của bảng gốc")
    check(near(AgeBodyTable.heightFractions(6).thigh, (0.234f + 0.220f) / 2f), "đùi 6 tuổi = (0,234+0,220)/2")
    check(near(AgeBodyTable.heightFractions(18).forearm, (0.149f + 0.144f) / 2f), "cẳng tay 18 tuổi = (0,149+0,144)/2")
    check(AgeBodyTable.heightFractions(3) == AgeBodyTable.heightFractions(6) && AgeBodyTable.heightFractions(40) == AgeBodyTable.heightFractions(18), "ngoài 6–18 tuổi: kẹp, không ngoại suy")
    check(near(AgeBodyTable.headsTall(18), 7.5f, 1e-3f), "người lớn = 7,5 số đầu")
    check(near(AgeBodyTable.headsTall(6), 6.0f, 0.05f), "6 tuổi ≈ 6,0 số đầu (khớp quy ước cũ)")
    var headOk = true; var prev = 0f; var lim = true
    for (a in 6..18) {
        val r = AgeBodyTable.ratiosVsAdult(a)
        if (AgeBodyTable.headSizeVsAdult(a) < prev) headOk = false
        prev = AgeBodyTable.headSizeVsAdult(a)
        for (v in listOf(r.head, r.trunk, r.thigh, r.shank, r.upperArm, r.forearm)) if (v <= 0f || v > 1.02f) lim = false
    }
    check(headOk, "kích thước đầu không giảm theo tuổi")
    check(lim, "mọi đoạn ở mọi tuổi 6–18 nằm trong (0; 1,02] so với người lớn (không có đoạn trẻ em dài hơn người lớn)")
    val r18 = AgeBodyTable.ratiosVsAdult(18)
    check(listOf(r18.head, r18.trunk, r18.thigh, r18.shank, r18.upperArm, r18.forearm).all { it == 1f }, "ratiosVsAdult(18) đúng 1,0 từng bit")
    check(BoneProportions.presetAdult() == BoneProportions.forAge(18) && BoneProportions.presetAdult() == BoneProportions(), "presetAdult = forAge(18) = BoneProportions() mặc định")
    val c = BoneProportions.presetChild(); val t = BoneProportions.presetTeen()
    check(c.upperLegRatio != c.lowerLegRatio && c.upperArmRatio != c.forearmRatio, "preset Trẻ em: đùi ≠ cẳng chân và cánh tay trên ≠ cẳng tay (từng đoạn có số riêng)")
    check(c.upperArmRatio < t.upperArmRatio && c.upperLegRatio < t.upperLegRatio && t.upperLegRatio < 1f, "trẻ em < thiếu niên < người lớn ở các đoạn chi")
    check(c.headSizeRatio < 1f && c.headSizeRatio > c.upperLegRatio, "đầu trẻ em < đầu người lớn nhưng co ÍT hơn chân (đầu to tương đối)")
    check(near(AgeBodyTable.factors(18, 6).thigh * AgeBodyTable.factors(6, 18).thigh, 1f, 1e-5f), "factors(A,B) × factors(B,A) = 1")

    // ── hình học ──
    val pairs = listOf(1 to 0, 2 to 3, 3 to 4, 5 to 6, 6 to 7, 8 to 9, 9 to 10, 11 to 12, 12 to 13)
    for ((tag, mk) in listOf<Pair<String, () -> MutableList<PoseKeypoint>>>("đứng" to ::standing, "gập" to ::bent)) {
        for ((fa, ta) in listOf(18 to 8, 8 to 18, 14 to 8, 18 to 14, 6 to 18)) {
            val s0 = mk(); val f = AgeBodyTable.factors(fa, ta); val s1 = AgeBodyScaler.rescale(s0, f); val n = "[$tag $fa→$ta]"
            check(s1 !== s0, "$n trả danh sách MỚI")
            check(near(hip(s0).first, hip(s1).first) && near(hip(s0).second, hip(s1).second), "$n giữ nguyên tâm hông")
            check(near(chainTotal(s0), chainTotal(s1)), "$n giữ nguyên tổng độ dài các đoạn đứng (đầu+thân+đùi+cẳng chân)")
            check(pairs.all { (a, b) -> abs(ang(s0, a, b) - ang(s1, a, b)) < 1e-4f } , "$n mỗi đoạn giữ NGUYÊN HƯỚNG")
            // hệ số riêng từng đoạn: tỷ lệ độ dài mới/cũ của hai đoạn bất kỳ = tỷ lệ hệ số
            val g = { a: Int, b: Int -> d(s1, a, b) / d(s0, a, b) }
            check(near(g(2, 3) / g(3, 4), f.upperArm / f.forearm, 1e-3f) && near(g(5, 6) / g(6, 7), f.upperArm / f.forearm, 1e-3f), "$n cánh tay trên : cẳng tay đổi đúng bằng hệ số riêng")
            check(near(g(8, 9) / g(9, 10), f.thigh / f.shank, 1e-3f) && near(g(11, 12) / g(12, 13), f.thigh / f.shank, 1e-3f), "$n đùi : cẳng chân đổi đúng bằng hệ số riêng")
            check(near(g(8, 9) / g(2, 3), f.thigh / f.upperArm, 1e-3f), "$n đùi : cánh tay trên đổi đúng bằng hệ số riêng")
            val back = AgeBodyScaler.rescale(s1, AgeBodyTable.factors(ta, fa))
            check(s0.indices.all { near(s0[it].x, back[it].x, 2e-4f) && near(s0[it].y, back[it].y, 2e-4f) }, "$n đổi qua rồi đổi lại về ĐÚNG hình cũ")
        }
    }
    // khớp ẩn / thiếu điểm
    val hid = standing(); hid[4] = hid[4].copy(visible = false); hid[17] = hid[17].copy(visible = false)
    val rh = AgeBodyScaler.rescale(hid, AgeBodyTable.factors(18, 8))
    check(rh[4] == hid[4] && rh[17] == hid[17], "khớp đang ẩn không bị động tới")
    val noNeck = standing(); noNeck[1] = noNeck[1].copy(visible = false)
    check(AgeBodyScaler.rescale(noNeck, AgeBodyTable.factors(18, 8)) === noNeck, "thiếu cổ: trả đúng danh sách cũ")
    val oneHip = standing(); oneHip[11] = oneHip[11].copy(visible = false)
    check(AgeBodyScaler.rescale(oneHip, AgeBodyTable.factors(18, 8)) === oneHip, "thiếu một hông: trả đúng danh sách cũ")
    check(AgeBodyScaler.rescale(MutableList(10) { P(0f, 0f) }, AgeBodyTable.factors(18, 8)).size == 10, "danh sách ngắn hơn 18 khớp: không lỗi")
    val noNose = standing(); noNose[0] = noNose[0].copy(visible = false)
    val rn = AgeBodyScaler.rescale(noNose, AgeBodyTable.factors(18, 8))
    check(rn[0] == noNose[0] && near(d(noNose, 8, 9) + d(noNose, 9, 10) + trunk(noNose), d(rn, 8, 9) + d(rn, 9, 10) + trunk(rn)), "không có mũi: vẫn chạy, đầu không bị động, tổng thân+chân giữ nguyên")
    // hiệu ứng nhìn thấy được: sang trẻ em chân ngắn đi tương đối so với đầu
    val a0 = standing(); val a1 = AgeBodyScaler.rescale(a0, AgeBodyTable.factors(18, 8))
    check(d(a1, 0, 1) / d(a1, 9, 10) > d(a0, 0, 1) / d(a0, 9, 10), "sang TRẺ EM: đầu tương đối to hơn chân")
    check(d(a1, 2, 3) < d(a1, 8, 9) * (d(a0, 2, 3) / d(a0, 8, 9)) * 1.0f + 1f, "(kiểm hợp lý) tay không dài ra bất thường")
    // ── mục 283: approxHeadsTall() có tính kích thước đầu (sửa điểm lệch 278.6) ──
    check(near(BoneProportions().approxHeadsTall(), 7.5f, 1e-3f), "người lớn chuẩn (mọi hệ số 1) = 7,5 đầu")
    check(near(BoneProportions.presetAdult().approxHeadsTall(), BoneProportions.forAge(18).approxHeadsTall(), 1e-6f), "presetAdult = forAge(18)")
    var worst = 0f
    for (age in AgeBodyTable.MIN_AGE..AgeBodyTable.MAX_AGE) worst = maxOf(worst, abs(BoneProportions.forAge(age).approxHeadsTall() - AgeBodyTable.headsTall(age)))
    check(worst < 0.05f, "khớp AgeBodyTable.headsTall ở MỌI tuổi 6–18 (lệch lớn nhất ${"%.3f".format(worst)} đầu, bản cũ lệch ~1 đầu ở trẻ nhỏ)")
    check(near(BoneProportions.forAge(8).approxHeadsTall(), 6.25f, 0.05f) && near(BoneProportions.forAge(6).approxHeadsTall(), 5.98f, 0.05f), "tuổi 8 ≈ 6,25 đầu và tuổi 6 ≈ 5,98 (bản cũ: 5,49 và 4,98)")
    var mono = true; for (age in AgeBodyTable.MIN_AGE until AgeBodyTable.MAX_AGE) if (BoneProportions.forAge(age + 1).approxHeadsTall() < BoneProportions.forAge(age).approxHeadsTall()) mono = false
    check(mono, "số đầu không giảm khi tuổi tăng")
    // đầu to hơn (chibi) → ít đầu hơn; đầu nhỏ hơn → nhiều đầu hơn; mọi thứ khác giữ nguyên
    val big = BoneProportions(headSizeRatio = 2.0f).approxHeadsTall(); val small = BoneProportions(headSizeRatio = 0.8f).approxHeadsTall()
    check(big < 7.5f && small > 7.5f && big < 5f, "đầu to gấp đôi → ${"%.2f".format(big)} đầu (< 5); đầu nhỏ 0,8 → ${"%.2f".format(small)} (> 7,5) — bản cũ bỏ qua kích thước đầu nên luôn 7,5")
    check(BoneProportions(headSizeRatio = 2.0f, torsoRatio = 0.6f, upperLegRatio = 0.5f, lowerLegRatio = 0.5f).approxHeadsTall() < 3.5f, "chibi thật (đầu ×2, thân ×0,6, chân ×0,5) < 3,5 đầu")
    check(BoneProportions(upperLegRatio = 1.2f, lowerLegRatio = 1.2f).approxHeadsTall() > 7.5f, "chân dài hơn → nhiều đầu hơn")
    check(BoneProportions(headSizeRatio = 0f).approxHeadsTall().isFinite() && BoneProportions(headSizeRatio = -1f).approxHeadsTall().isFinite(), "headSizeRatio = 0 hoặc âm: không chia cho 0 (kết quả hữu hạn)")
    // cụm tag giữ NGUYÊN nhóm theo tuổi như trước khi sửa: 6–8 child, 9–13 youthful, ≥ 14 không tag
    fun tagKind(age: Int): String { val s = BoneProportions.forAge(age).headsTallPromptTag(); return when { s.isEmpty() -> "none"; "child body" in s -> "child"; "youthful" in s -> "youthful"; "chibi" in s -> "chibi"; else -> "?" } }
    check((6..8).all { tagKind(it) == "child" }, "tuổi 6–8 → tag \"child body proportions\" (giữ nhóm cũ)")
    check((9..13).all { tagKind(it) == "youthful" }, "tuổi 9–13 → tag \"youthful\" (giữ nhóm cũ)")
    check((14..18).all { tagKind(it) == "none" }, "tuổi 14–18 → KHÔNG tag (giữ nhóm cũ)")
    check(tagKind(8) == "child" && BoneProportions.presetChild().headsTallPromptTag().contains("heads tall"), "preset Trẻ em còn tag có số đầu")
    check(BoneProportions.presetAdult().headsTallPromptTag() == "" && BoneProportions().headsTallPromptTag() == "", "người lớn chuẩn: không tag")
    check(BoneProportions(headSizeRatio = 2.0f, torsoRatio = 0.6f, upperLegRatio = 0.5f, lowerLegRatio = 0.5f).headsTallPromptTag().contains("chibi"), "chibi → tag chibi")
    // ngưỡng KHÔNG-TAG (7,1) nằm giữa 7,0 và 7,2: nhân vật tuỳ chỉnh (đầu hơi to) ở 7,05 đầu vẫn còn tag, ở ~7,2 đầu thì hết (preset theo tuổi không rơi vào khoảng này nên cần ca riêng)
    val h705 = BoneProportions(headSizeRatio = 1.074f); val h72 = BoneProportions(headSizeRatio = 1.048f)
    check(near(h705.approxHeadsTall(), 7.05f, 0.03f) && h705.headsTallPromptTag().contains("youthful"), "tuỳ chỉnh ~7,05 đầu: còn tag \"youthful\" (dưới ngưỡng 7,1)")
    check(near(h72.approxHeadsTall(), 7.2f, 0.03f) && h72.headsTallPromptTag() == "", "tuỳ chỉnh ~7,2 đầu: không tag (trên ngưỡng 7,1)")
    // biên ngưỡng không sát số của các tuổi (không nhảy nhóm vì sai số nhỏ)
    val ages = (6..18).map { BoneProportions.forAge(it).approxHeadsTall() }
    check(ages.none { abs(it - BoneProportions.CHILD_HEADS_MAX) < 0.03f || abs(it - BoneProportions.ADULT_HEADS_MAX_FOR_NO_TAG) < 0.03f }, "không tuổi nào nằm sát ngưỡng nhóm (< 0,03 đầu)")
    // ── mục 284: BỀ NGANG vai/hông theo tuổi = SỐ ĐO THẬT (NHANES III + Zivicnjak 2008) ──
    check(AgeBodyTable.widthVsAdult(18) == 1.0f && BoneProportions.forAge(AgeBodyTable.ADULT_AGE) == BoneProportions(), "18 tuổi: widthVsAdult = 1,0 đúng từng bit và forAge(18) == BoneProportions()")
    check(near(AgeBodyTable.widthVsAdult(6), 0.685f, 0.015f) && near(AgeBodyTable.widthVsAdult(12), 0.88f, 0.02f), "trẻ 6 tuổi ≈ 0,685 và 12 tuổi ≈ 0,88 bề ngang người lớn (số đo)")
    check((AgeBodyTable.MIN_AGE..AgeBodyTable.MAX_AGE).all { AgeBodyTable.widthSpread(it) <= 0.06f }, "HAI quần thể × vai/hông đồng thuận: bốn chuỗi lệch nhau ≤ 0,06 so với người lớn ở MỌI tuổi (lớn nhất ${"%.3f".format((AgeBodyTable.MIN_AGE..AgeBodyTable.MAX_AGE).maxOf { AgeBodyTable.widthSpread(it) })})")
    var wMono = true; for (a in AgeBodyTable.MIN_AGE until AgeBodyTable.MAX_AGE) if (AgeBodyTable.widthVsAdult(a + 1) < AgeBodyTable.widthVsAdult(a) - 0.002f) wMono = false
    check(wMono, "bề ngang không giảm khi tuổi tăng (cho phép nhiễu mẫu 0,002 quanh 17–18 tuổi)")
    check(near(AgeBodyTable.shoulderFraction(18), 0.245f, 1e-6f), "mốc người lớn 0,245 chiều cao giữ nguyên (không đổi hành vi người lớn)")
    check((AgeBodyTable.MIN_AGE..AgeBodyTable.MAX_AGE).all { AgeBodyTable.shoulderFraction(it) in 0.23f..0.26f }, "bề ngang theo CHIỀU CAO gần như HẰNG ở mọi tuổi (0,23–0,26): vai trẻ em KHÔNG hẹp tương đối như công thức cũ ngầm định")
    val oldFrac = { a: Int -> (0.215f + (a - 6) / 12f * 0.030f) }   // công thức TUYẾN TÍNH cũ (ước lượng) — để chứng minh mức sửa
    val oldAbs6 = oldFrac(6) * AgeBodyTable.heightCm(6) / (oldFrac(18) * AgeBodyTable.heightCm(18))
    check(AgeBodyTable.widthVsAdult(6) > oldAbs6 * 1.08f && AgeBodyTable.widthVsAdult(8) > (oldFrac(8) * AgeBodyTable.heightCm(8) / (oldFrac(18) * AgeBodyTable.heightCm(18))) * 1.05f, "so với ước lượng tuyến tính CŨ: số đo rộng hơn ≥ 8% lúc 6 tuổi và ≥ 5% lúc 8 (bản cũ làm trẻ nhỏ quá hẹp)")
    check((AgeBodyTable.MIN_AGE..AgeBodyTable.MAX_AGE).all { BoneProportions.forAge(it).widthRatio == AgeBodyTable.ratiosVsAdult(it).shoulder && near(AgeBodyTable.ratiosVsAdult(it).shoulder, AgeBodyTable.widthVsAdult(it), 1e-5f) }, "BoneProportions.forAge(tuổi).widthRatio = ratiosVsAdult.shoulder = widthVsAdult (một nguồn dữ liệu)")
    check(AgeBodyTable.widthVsAdult(3) == AgeBodyTable.widthVsAdult(6) && AgeBodyTable.widthVsAdult(40) == 1.0f, "ngoài 6–18 tuổi kẹp về 6 hoặc 18 (không ngoại suy)")
    System.getenv("AGE_WIDTH_EXPECTED")?.let { path ->   // đáp án do Python tính ĐỘC LẬP từ tệp chép nguyên văn nguồn (tools/data/*.txt)
        val rows = java.io.File(path).readLines().filter { it.isNotBlank() }.map { it.trim().split(" ") }
        check(rows.size == 13 && rows.all { r -> val a = r[0].toInt(); near(AgeBodyTable.widthVsAdult(a), r[1].toFloat(), 1e-4f) && near(AgeBodyTable.widthSpread(a), r[2].toFloat(), 1e-4f) && near(AgeBodyTable.shoulderFraction(a), r[3].toFloat(), 1e-4f) },
            "khớp đáp án Python độc lập (tính từ tệp NHANES III + Zivicnjak chép nguyên văn): widthVsAdult, widthSpread, shoulderFraction ở cả 13 tuổi")
    }
    println(if (fails == 0) "ĐẠT" else "THẤT BẠI: $fails")
    if (fails != 0) System.exit(1)
}
