package com.mangalocal.pipeline
import com.mangalocal.model.BoneProportions
// Stub tối thiểu cho test PoseRetargeter: PoseKeypoint và PoseVariant đúng chữ ký ở StoryManager.kt (mục 284; chưa có test nào cho PoseRetargeter trước đó).
class StoryManager {
    data class PoseKeypoint(val x: Float = 0f, val y: Float = 0f, val z: Float = 0f, val visible: Boolean = false, val confidence: Float = 1f)
    data class PoseVariant(val angle: String = "unknown", val people: MutableList<MutableList<PoseKeypoint>> = mutableListOf(), val needsReview: Boolean = false,
                           val reviewReasons: List<String> = emptyList(), val sourceProportions: BoneProportions = BoneProportions(), val actionTags: List<String> = emptyList())
}
