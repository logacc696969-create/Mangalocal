// mục 280 — test CHẠY MÃ KOTLIN THẬT cho BlazePoseLift (ROI có xoay, cắt ảnh, ánh xạ ngược, 33 điểm → OpenPose-18 với z) bằng dữ liệu tổng hợp có đáp án biết trước.
// Phần kiểm với MÔ HÌNH THẬT trên ảnh thật nằm ở BlazePoseLiftIT.kt + tools/test_blazepose_lift.py.
import com.mangalocal.pipeline.BlazePoseLift
import com.mangalocal.pipeline.BlazePoseLift.Roi
import com.mangalocal.pipeline.StoryManager.PoseKeypoint
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

var fails = 0
var passes = 0
fun check(ok: Boolean, name: String) { println((if (ok) "PASS " else "FAIL ") + name); if (ok) passes++ else fails++ }
fun near(a: Float, b: Float, eps: Float = 1e-3f) = abs(a - b) <= eps

/** Ảnh w×h: đỏ = x (0..255 theo cột), xanh lá = y (theo hàng), xanh dương = 128. */
fun gradientImage(w: Int, h: Int) = IntArray(w * h) { i ->
    val x = i % w; val y = i / w
    (0xFF shl 24) or ((x * 255 / (w - 1)) shl 16) or ((y * 255 / (h - 1)) shl 8) or 128
}

fun person18(vararg set: Pair<Int, Pair<Float, Float>>): MutableList<PoseKeypoint> {
    val p = MutableList(18) { PoseKeypoint() }
    for ((i, xy) in set) p[i] = PoseKeypoint(xy.first, xy.second, 0f, true, 1f)
    return p
}

fun main() {
    val W = 400; val H = 600
    // ── 1. ROI và ánh xạ ngược ──
    val roi = Roi(200f, 300f, 300f, 0.7f)
    var rt = true
    for ((u, v) in listOf(0f to 0f, 255f to 255f, 128f to 64f, 30f to 220f)) {
        val (X, Y) = BlazePoseLift.cropToImage(u, v, roi)
        // đảo thủ công: trừ tâm, xoay ngược góc, chia cạnh
        val dx = X - roi.cx; val dy = Y - roi.cy
        val a = dx * cos(-roi.rotation) - dy * sin(-roi.rotation); val b = dx * sin(-roi.rotation) + dy * cos(-roi.rotation)
        if (!(near(u, (a / roi.size + 0.5f) * 256f, 1e-2f) && near(v, (b / roi.size + 0.5f) * 256f, 1e-2f))) rt = false
    }
    check(rt, "cropToImage: khứ hồi qua phép đảo độc lập (góc 0,7 rad)")
    val c0 = BlazePoseLift.cropToImage(128f, 128f, Roi(123f, 77f, 50f, 1.1f))
    check(near(c0.first, 123f) && near(c0.second, 77f), "tâm ảnh cắt (128,128) = tâm ROI, bất kể góc xoay")

    // ── 2. cắt ảnh ──
    val img = gradientImage(W, H)
    val crop1 = BlazePoseLift.sampleCrop(img, W, H, Roi(200f, 300f, 256f, 0f))   // 1 pixel ảnh = 1 pixel cắt
    val ctr = (128 * 256 + 128) * 3
    // pixel cắt u = 128 có tâm 128,5 ⇒ ảnh x = 200,5 ⇒ chỉ số pixel liên tục 200,0 ⇒ ĐÚNG cột 200 (không nội suy). Ảnh thử dùng chia SỐ NGUYÊN: đỏ = 200·255/399 = 127.
    check(near(crop1[ctr], (200 * 255 / (W - 1)) / 255f, 1e-6f), "cắt 1:1: pixel giữa lấy đúng cột 200, không nội suy (đỏ ${"%.4f".format(crop1[ctr])} = 127/255)")
    val half = BlazePoseLift.sampleCrop(img, W, H, Roi(200.5f, 300.5f, 256f, 0f))    // lệch nửa pixel: giữa hai cột 200 và 201 ⇒ nội suy
    check(near(half[ctr], ((200 * 255 / (W - 1)) + (201 * 255 / (W - 1))) / 2f / 255f, 1e-6f) || near(half[ctr], (200 * 255 / (W - 1)) / 255f, 1e-6f) || near(half[ctr], (201 * 255 / (W - 1)) / 255f, 1e-6f), "cắt lệch nửa pixel: giá trị nằm giữa hai cột lân cận")
    check(crop1[ctr + 2] > 0.49f && crop1[ctr + 2] < 0.51f, "kênh xanh dương hằng 128/255 giữ nguyên")
    // quay 90° theo chiều kim đồng hồ: đi sang PHẢI trong ảnh cắt = đi XUỐNG trong ảnh gốc ⇒ đỏ (theo x ảnh) KHÔNG đổi theo u; đi XUỐNG trong ảnh cắt = đi sang TRÁI ảnh gốc ⇒ đỏ GIẢM theo v
    val cr = BlazePoseLift.sampleCrop(img, W, H, Roi(200f, 300f, 200f, (PI / 2).toFloat()))
    fun red(u: Int, v: Int) = cr[(v * 256 + u) * 3]
    check(near(red(40, 128), red(220, 128), 2e-3f) && red(128, 30) > red(128, 220) + 0.1f, "xoay ROI +90° (kim đồng hồ): đỏ hằng theo u, giảm theo v — đúng quy ước Roi.rotation")
    val green = { u: Int, v: Int -> cr[(v * 256 + u) * 3 + 1] }
    check(green(220, 128) > green(40, 128) + 0.1f, "xoay ROI +90°: xanh lá (theo y ảnh) TĂNG theo u — đi sang phải trong ảnh cắt là đi xuống trong ảnh gốc")
    val out = BlazePoseLift.sampleCrop(img, W, H, Roi(-500f, -500f, 100f, 0f))
    check(out.all { it == 0f }, "ROI nằm ngoài ảnh: toàn đen (0)")
    val edge = BlazePoseLift.sampleCrop(img, W, H, Roi(0f, 300f, 100f, 0f))
    check(edge[(128 * 256 + 5) * 3] == 0f && edge[(128 * 256 + 250) * 3] > 0f, "ROI cắt qua mép ảnh: phần ngoài đen, phần trong có dữ liệu")

    // ── 3. ROI từ khung xương ──
    val upright = person18(2 to (0.45f to 0.30f), 5 to (0.55f to 0.30f), 8 to (0.47f to 0.55f), 11 to (0.53f to 0.55f), 10 to (0.47f to 0.90f), 0 to (0.5f to 0.20f))
    val r1 = BlazePoseLift.roiFromPerson(upright, W, H)!!
    val rBig = listOf(hypot((0.47f - 0.50f) * W, (0.90f - 0.55f) * H), hypot((0.5f - 0.5f) * W, (0.20f - 0.55f) * H)).max()
    check(near(r1.cx, 0.50f * W, 1e-3f) && near(r1.cy, 0.55f * H, 1e-3f) && near(r1.rotation, 0f, 1e-3f) && near(r1.size, 2.5f * rBig, 0.5f), "người thẳng đứng: tâm = tâm hông, không xoay, cạnh = 2,5 × bán kính xa nhất")
    // cùng người nằm ngang, đầu về bên PHẢI ảnh: tâm hông → tâm vai chỉ sang phải ⇒ ROI xoay +90°
    val lying = person18(2 to (0.60f to 0.45f), 5 to (0.60f to 0.55f), 8 to (0.40f to 0.47f), 11 to (0.40f to 0.53f), 0 to (0.70f to 0.50f), 10 to (0.10f to 0.50f))
    val r2 = BlazePoseLift.roiFromPerson(lying, W, H)!!
    check(near(r2.rotation, (PI / 2).toFloat(), 1e-2f), "người nằm, đầu về bên phải: ROI xoay +π/2 để thân dựng đứng (${"%.3f".format(r2.rotation)})")
    val noShoulder = person18(8 to (0.47f to 0.55f), 11 to (0.53f to 0.55f), 10 to (0.47f to 0.90f), 0 to (0.5f to 0.20f))
    val r3 = BlazePoseLift.roiFromPerson(noShoulder, W, H, floatArrayOf(0.3f, 0.1f, 0.7f, 0.95f, 0.9f))!!
    check(near(r3.rotation, 0f) && near(r3.cx, 0.5f * W, 1e-3f) && near(r3.size, 1.25f * 0.85f * H, 0.5f), "thiếu vai: dùng hộp YOLO, không xoay, cạnh = 1,25 × cạnh dài")
    check(BlazePoseLift.roiFromPerson(person18(), W, H) == null && BlazePoseLift.roiFromPerson(MutableList(5) { PoseKeypoint() }, W, H) == null, "không đủ thông tin / danh sách ngắn: null")

    // ── 4. parseOutput ──
    fun rawWith(flag: Float, nose: Triple<Float, Float, Float>, wNose: Triple<Float, Float, Float>): FloatArray {
        val r = FloatArray(BlazePoseLift.RESULT_FLOATS); r[0] = flag
        r[1] = nose.first; r[2] = nose.second; r[3] = nose.third; r[4] = 4f      // thấy-logit 4 → ~0,98
        val w0 = 1 + 195; r[w0] = wNose.first; r[w0 + 1] = wNose.second; r[w0 + 2] = wNose.third
        return r
    }
    val roiR = Roi(100f, 200f, 128f, (PI / 2).toFloat())
    val lf = BlazePoseLift.parseOutput(rawWith(0.9f, Triple(64f, 192f, -0.5f), Triple(1f, 0f, -0.3f)), roiR)!!
    val exp = BlazePoseLift.cropToImage(64f, 192f, roiR)
    check(near(lf.imgX[0], exp.first) && near(lf.imgY[0], exp.second), "parseOutput: điểm ảnh đổi qua ROI ngược")
    check(near(lf.worldX[0], 0f, 1e-5f) && near(lf.worldY[0], 1f, 1e-5f) && near(lf.worldZ[0], -0.3f, 1e-6f), "parseOutput: world xoay (1,0) → (0,1) theo ROI +90°, z giữ nguyên")
    check(lf.visibility[0] > 0.97f && lf.visibility[0] < 0.99f, "độ thấy = sigmoid(logit)")
    check(BlazePoseLift.parseOutput(rawWith(0.3f, Triple(0f, 0f, 0f), Triple(0f, 0f, 0f)), roiR) == null, "cờ có người < 0,5: null")
    check(BlazePoseLift.parseOutput(FloatArray(300), roiR) == null, "độ dài ≠ 313: null")

    // ── 5. depthFor: đáp án biết trước ──
    // dựng người 3D (mét) và chiếu: x_ảnh = hip + s0·x_world (chuẩn hoá), y tương tự; z đúng = s0·(z_w − z_hông)
    val s0 = 0.9f; val hip0 = 0.5f to 0.55f
    val wX = FloatArray(33); val wY = FloatArray(33); val wZ = FloatArray(33); val vis = FloatArray(33) { 0.95f }
    fun setW(i: Int, x: Float, y: Float, z: Float) { wX[i] = x; wY[i] = y; wZ[i] = z }
    setW(23, 0.10f, 0f, 0.02f); setW(24, -0.10f, 0f, 0.02f)       // hông T/P (z_hông = 0,02)
    setW(11, 0.18f, -0.45f, -0.20f); setW(12, -0.17f, -0.45f, 0.10f)   // vai T ra TRƯỚC (-0,20), vai P ra SAU
    setW(15, 0.30f, -0.20f, -0.50f)                                   // cổ tay T vươn mạnh ra trước
    setW(0, 0.01f, -0.62f, -0.10f); setW(27, 0.08f, 0.85f, 0.25f)     // mũi, cổ chân T
    val lifted = BlazePoseLift.Lifted(0.95f, FloatArray(33), FloatArray(33), vis, wX, wY, wZ)
    // khung xương OpenPose-18 có x, y = hip0 + s0·(wx, wy)
    fun proj(i: Int) = (hip0.first + s0 * wX[i]) to (hip0.second + s0 * wY[i])
    val neckW = Pair((wX[11] + wX[12]) / 2f, (wY[11] + wY[12]) / 2f)
    val per = person18(
        0 to proj(0), 1 to ((hip0.first + s0 * neckW.first) to (hip0.second + s0 * neckW.second)), 2 to proj(12), 5 to proj(11), 7 to proj(15),
        8 to proj(24), 11 to proj(23), 13 to proj(27))
    val dz = BlazePoseLift.depthFor(per, lifted)!!
    val zh = 0.02f
    check(near(dz[5].z, s0 * (-0.20f - zh), 2e-4f) && near(dz[2].z, s0 * (0.10f - zh), 2e-4f), "z đúng và TRÁI/PHẢI không đảo: vai trái (OpenPose 5 ← MediaPipe 11) ra trước, vai phải (2 ← 12) ra sau")
    check(near(dz[7].z, s0 * (-0.50f - zh), 2e-4f) && dz[7].z < dz[5].z, "cổ tay trái (7 ← 15) vươn ra trước nhất")
    check(near(dz[1].z, s0 * ((-0.20f + 0.10f) / 2f - zh), 2e-4f), "cổ (1) = trung bình z hai vai")
    check(near(dz[13].z, s0 * (0.25f - zh), 2e-4f) && dz[13].z > 0f, "cổ chân trái ra sau (z dương)")
    check(near(dz[8].z + dz[11].z, 0f, 2e-4f), "hai hông cùng z = 0 so với tâm hông (trung bình 0)")
    check(per.indices.all { near(dz[it].x, per[it].x, 0f) && near(dz[it].y, per[it].y, 0f) && dz[it].visible == per[it].visible }, "x, y, visible giữ NGUYÊN")
    check(dz[3].z == 0f && !dz[3].visible, "khớp không hiện (YOLO) không được gán z")
    check(dz.size == 18 && per !== dz, "trả bản sao 18 khớp")
    check(BlazePoseLift.depthFor(per, BlazePoseLift.Lifted(0.2f, FloatArray(33), FloatArray(33), vis, wX, wY, wZ)) == null, "cờ thấp: null")
    val noHip = per.toMutableList().also { it[8] = it[8].copy(visible = false) }
    check(BlazePoseLift.depthFor(noHip, lifted) == null, "thiếu một hông: null")
    // người bị chiếu NGƯỢC (x, y ảnh ngược dấu với world) ⇒ s ≤ 0 ⇒ null (không đặt z bừa)
    val flipped = person18(0 to ((hip0.first - s0 * wX[0]) to (hip0.second - s0 * wY[0])), 2 to ((hip0.first - s0 * wX[12]) to (hip0.second - s0 * wY[12])),
        5 to ((hip0.first - s0 * wX[11]) to (hip0.second - s0 * wY[11])), 8 to ((hip0.first - s0 * wX[24]) to (hip0.second - s0 * wY[24])), 11 to ((hip0.first - s0 * wX[23]) to (hip0.second - s0 * wY[23])))
    check(BlazePoseLift.depthFor(flipped, lifted) == null, "ảnh và world ngược chiều (s ≤ 0): null")
    val lowVis = BlazePoseLift.Lifted(0.95f, FloatArray(33), FloatArray(33), FloatArray(33) { 0.1f }, wX, wY, wZ)
    check(BlazePoseLift.depthFor(per, lowVis) == null, "mọi khớp độ thấy thấp: không khớp được tỷ lệ → null")

    // ── 6. mục 282: ảnh KHÔNG VUÔNG (aspect = rộng/cao ≠ 1) — z phải cùng đơn vị bề ngang với x và khung đẳng hướng phải nhất quán ──
    // Dựng cảnh bằng PIXEL: ảnh 810×1080, tiêu cự f px/mét (đẳng hướng), toạ độ chuẩn hoá x = hip + f·wx/W, y = hip + f·wy/H. Đáp án đúng: z = (f/W)·(z_w − z_hông).
    run {
        val iw = 810f; val ih = 1080f; val asp = iw / ih; val f = 900f
        fun nx(i: Int) = hip0.first + f * wX[i] / iw
        fun ny(i: Int) = hip0.second + f * wY[i] / ih
        val neckNx = hip0.first + f * ((wX[11] + wX[12]) / 2f) / iw; val neckNy = hip0.second + f * ((wY[11] + wY[12]) / 2f) / ih
        val perN = person18(0 to (nx(0) to ny(0)), 1 to (neckNx to neckNy), 2 to (nx(12) to ny(12)), 5 to (nx(11) to ny(11)), 7 to (nx(15) to ny(15)),
            8 to (nx(24) to ny(24)), 11 to (nx(23) to ny(23)), 13 to (nx(27) to ny(27)))
        val dn = BlazePoseLift.depthFor(perN, lifted, asp)!!
        val zExpect = { b: Int -> (f / iw) * (wZ[b] - 0.02f) }
        check(near(dn[5].z, zExpect(11), 2e-4f) && near(dn[2].z, zExpect(12), 2e-4f) && near(dn[7].z, zExpect(15), 2e-4f) && near(dn[13].z, zExpect(27), 2e-4f),
            "ảnh 810×1080: z = (f/W)·(z_world − z_hông) tính theo bề NGANG (khớp đáp án dựng từ pixel)")
        // BẤT BIẾN ĐẲNG HƯỚNG: trong khung (x·aspect, y, z·aspect) mọi đoạn xương có độ dài 3D = (f/H) × độ dài thật (mét), bất kể hướng ngang/dọc/sâu.
        val k = f / ih
        fun len3(p: List<PoseKeypoint>, a: Int, b: Int) = Math.sqrt(Math.pow(((p[b].x - p[a].x) * asp).toDouble(), 2.0) + Math.pow((p[b].y - p[a].y).toDouble(), 2.0) + Math.pow(((p[b].z - p[a].z) * asp).toDouble(), 2.0)).toFloat()
        fun trueLen(a: Int, b: Int) = Math.sqrt(Math.pow((wX[b] - wX[a]).toDouble(), 2.0) + Math.pow((wY[b] - wY[a]).toDouble(), 2.0) + Math.pow((wZ[b] - wZ[a]).toDouble(), 2.0)).toFloat()
        // cặp (OpenPose, MediaPipe) cho vai→cổ tay trái (ra trước, sâu), hông→cổ chân trái (dọc), vai trái→vai phải (ngang)
        val pairs = listOf(Triple(5, 7, Pair(11, 15)), Triple(11, 13, Pair(23, 27)), Triple(5, 2, Pair(11, 12)))
        val ratios = pairs.map { (a, b, mp) -> len3(dn, a, b) / (k * trueLen(mp.first, mp.second)) }
        check(ratios.all { near(it, 1f, 3e-3f) }, "bất biến đẳng hướng: độ dài 3D (x·aspect, y, z·aspect) = (f/H)·mét cho đoạn sâu/dọc/ngang (tỷ lệ ${ratios.joinToString { "%.4f".format(it) }})")
        // Đối chứng: gọi như bản cũ (aspect = 1) trên cùng dữ liệu phải cho z SAI — chứng minh test đủ nhạy với lỗi mục 280.7
        val dOld = BlazePoseLift.depthFor(perN, lifted)!!
        val relErr = abs(dOld[7].z - dn[7].z) / abs(dn[7].z)
        check(relErr > 0.10f, "đối chứng: bỏ aspect (hành vi cũ) làm z cổ tay lệch ${"%.0f".format(relErr * 100)}% so với đáp án đúng (> 10%) — test đủ nhạy")
        // Ảnh vuông: aspect = 1 cho y hệt tham số mặc định (không hồi quy)
        val dSq = BlazePoseLift.depthFor(per, lifted, 1f)!!
        check(dSq.indices.all { dSq[it].z == dz[it].z }, "aspect = 1 ≡ mặc định (ảnh vuông không đổi)")
        // Ảnh nằm ngang (aspect > 1) cũng đúng
        val aw = 1920f; val ah = 1080f; val asp2 = aw / ah; val f2 = 1200f
        val perL = person18(0 to ((hip0.first + f2 * wX[0] / aw) to (hip0.second + f2 * wY[0] / ah)), 2 to ((hip0.first + f2 * wX[12] / aw) to (hip0.second + f2 * wY[12] / ah)),
            5 to ((hip0.first + f2 * wX[11] / aw) to (hip0.second + f2 * wY[11] / ah)), 7 to ((hip0.first + f2 * wX[15] / aw) to (hip0.second + f2 * wY[15] / ah)),
            8 to ((hip0.first + f2 * wX[24] / aw) to (hip0.second + f2 * wY[24] / ah)), 11 to ((hip0.first + f2 * wX[23] / aw) to (hip0.second + f2 * wY[23] / ah)))
        val dL = BlazePoseLift.depthFor(perL, lifted, asp2)!!
        check(near(dL[7].z, (f2 / aw) * (-0.50f - 0.02f), 2e-4f) && near(dL[5].z, (f2 / aw) * (-0.20f - 0.02f), 2e-4f), "ảnh ngang 1920×1080 (aspect > 1): z = (f/W)·(z_w − z_hông)")
        check(BlazePoseLift.depthFor(perN, lifted, 0f) == null && BlazePoseLift.depthFor(perN, lifted, -1f) == null && BlazePoseLift.depthFor(perN, lifted, Float.NaN) == null &&
            BlazePoseLift.depthFor(perN, lifted, Float.POSITIVE_INFINITY) == null, "aspect không hợp lệ (0, âm, NaN, ∞) → null, không đặt z bừa")
    }

    println(if (fails == 0) "ĐẠT ($passes)" else "THẤT BẠI: $fails")
    if (fails != 0) System.exit(1)
}
