// mục 281 — test CHẠY MÃ KOTLIN THẬT cho BundledModels (chép model đóng trong APK ra thư mục model, "chép nếu chưa có").
import com.mangalocal.pipeline.BundledModels
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream

var fails = 0
var passes = 0
fun check(ok: Boolean, name: String) { println((if (ok) "PASS " else "FAIL ") + name); if (ok) passes++ else fails++ }

val LITE = ByteArray(3000) { (it % 251).toByte() }
val FULL = ByteArray(7000) { (it % 241).toByte() }
val NAMES = listOf("blazepose_lite.mnn", "blazepose_full.mnn")
val ASSETS = mapOf("blazepose_lite.mnn" to LITE, "blazepose_full.mnn" to FULL)
fun opener(map: Map<String, ByteArray> = ASSETS): (String) -> InputStream? = { n -> map[n]?.let { ByteArrayInputStream(it) } }
fun tmpDir(): File = java.nio.file.Files.createTempDirectory("bm_").toFile()
fun leftovers(d: File) = d.listFiles()?.filter { it.name.endsWith(".part") } ?: emptyList()

/** Luồng đọc được n byte rồi ném IOException (mô phỏng hết chỗ / mất kết nối giữa chừng). */
class FailingStream(private val n: Int) : InputStream() {
    private var i = 0
    override fun read(): Int { if (i++ >= n) throw IOException("đứt giữa chừng"); return 7 }
}

fun main() {
    // a) chưa có gì → chép cả hai, đúng từng byte, không để lại tệp tạm
    val d1 = File(tmpDir(), "yolo")   // thư mục CHƯA tồn tại: phải tạo
    val n1 = BundledModels.copyIfNoneExist(d1, NAMES, opener())
    check(n1 == 2 && File(d1, NAMES[0]).readBytes().contentEquals(LITE) && File(d1, NAMES[1]).readBytes().contentEquals(FULL), "chưa có model + thư mục chưa tồn tại: tạo thư mục, chép đủ 2 tệp, đúng từng byte")
    check(leftovers(d1).isEmpty(), "không để lại tệp .part")
    check(BundledModels.copyIfNoneExist(d1, NAMES, opener()) == 0, "gọi lần hai: không chép gì (idempotent)")

    // b) người dùng đã tự đặt MỘT model → không đụng gì, không chép thêm tệp kia, không ghi đè
    val d2 = tmpDir(); val mine = ByteArray(10) { 1 }
    File(d2, "blazepose_lite.mnn").writeBytes(mine)
    check(BundledModels.copyIfNoneExist(d2, NAMES, opener()) == 0 && File(d2, "blazepose_lite.mnn").readBytes().contentEquals(mine) && !File(d2, "blazepose_full.mnn").exists(),
        "đã có blazepose_lite.mnn của người dùng: không ghi đè, không chép thêm full")
    val d3 = tmpDir(); File(d3, "blazepose_full.mnn").writeBytes(mine)
    check(BundledModels.copyIfNoneExist(d3, NAMES, opener()) == 0 && !File(d3, "blazepose_lite.mnn").exists(), "chỉ có full của người dùng: không chép lite")

    // c) thiếu asset cho một tệp → chép tệp kia, không tạo tệp cụt cho tệp thiếu
    val d4 = tmpDir()
    val n4 = BundledModels.copyIfNoneExist(d4, NAMES, opener(mapOf("blazepose_full.mnn" to FULL)))
    check(n4 == 1 && !File(d4, "blazepose_lite.mnn").exists() && File(d4, "blazepose_full.mnn").exists() && leftovers(d4).isEmpty(), "thiếu asset lite: chép full, không tạo tệp lite, không tệp tạm")

    // d) luồng đứt giữa chừng → KHÔNG có tệp model cụt (tệp cụt sẽ làm MNN nạp lỗi mãi), tệp kia vẫn chép được
    val d5 = tmpDir()
    val n5 = BundledModels.copyIfNoneExist(d5, NAMES) { n -> if (n == "blazepose_lite.mnn") FailingStream(1000) else ByteArrayInputStream(FULL) }
    check(n5 == 1 && !File(d5, "blazepose_lite.mnn").exists() && File(d5, "blazepose_full.mnn").readBytes().contentEquals(FULL) && leftovers(d5).isEmpty(), "luồng lite đứt giữa chừng: không để lại tệp cụt/tệp tạm; full vẫn chép đủ")

    // e) tệp rỗng từ asset → không coi là đã chép
    val d6 = tmpDir()
    check(BundledModels.copyIfNoneExist(d6, NAMES, opener(mapOf("blazepose_lite.mnn" to ByteArray(0)))) == 0 && !File(d6, "blazepose_lite.mnn").exists() && leftovers(d6).isEmpty(), "asset rỗng (0 byte): không tạo tệp model rỗng")

    // f) không tạo được thư mục (đã có một TỆP trùng tên) → trả 0, KHÔNG ném lỗi
    val base = tmpDir(); val blocker = File(base, "yolo"); blocker.writeText("không phải thư mục")
    var threw = false; var n7 = -1
    try { n7 = BundledModels.copyIfNoneExist(blocker, NAMES, opener()) } catch (e: Throwable) { threw = true }
    check(!threw && n7 == 0, "không tạo được thư mục: trả 0, không ném lỗi")

    // g) opener ném lỗi (asset không mở được) → bỏ qua, không ném
    var threw2 = false; var n8 = -1
    try { n8 = BundledModels.copyIfNoneExist(tmpDir(), NAMES) { throw IllegalStateException("không mở được asset") } } catch (e: Throwable) { threw2 = true }
    check(!threw2 && n8 == 0, "opener ném lỗi: bỏ qua, trả 0")
    check(BundledModels.copyIfNoneExist(tmpDir(), emptyList(), opener()) == 0, "danh sách tên rỗng: 0")

    println(if (fails == 0) "ĐẠT ($passes)" else "THẤT BẠI: $fails")
    if (fails != 0) System.exit(1)
}
