// mục 285 — test CHẠY MÃ KOTLIN THẬT cho GIỚI (nam/nữ) trong AgeBodyTable + BoneProportions + Character + CharacterLibrary + AgeBodyScaler (hông tách riêng).
// Biên dịch bằng tools/test_age_sex.py (cần kotlinc, Gson, android.jar). Đáp án số do Python tính ĐỘC LẬP từ tệp nguồn chép nguyên văn (biến môi trường AGE_SEX_EXPECTED).
import com.mangalocal.model.AgeBodyTable
import com.mangalocal.model.BodySex
import com.mangalocal.model.BoneProportions
import com.mangalocal.model.Character
import com.mangalocal.pipeline.AgeBodyScaler
import com.mangalocal.pipeline.CharacterLibrary
import com.mangalocal.pipeline.StoryManager.PoseKeypoint
import kotlin.math.abs
import kotlin.math.hypot

var fails = 0; var passes = 0
fun check(ok: Boolean, name: String) { if (ok) passes++ else fails++; println((if (ok) "PASS " else "FAIL ") + name) }
fun near(a: Float, b: Float, eps: Float = 1e-4f) = abs(a - b) <= eps
val AGES = AgeBodyTable.MIN_AGE..AgeBodyTable.MAX_AGE
val SEXES = listOf(BodySex.MALE, BodySex.FEMALE)
fun kind(tag: String) = when { tag.isEmpty() -> "none"; "chibi" in tag -> "chibi"; "child body" in tag -> "child"; "youthful" in tag -> "youthful"; else -> "?" }
fun P(x: Float, y: Float) = PoseKeypoint(x, y, 0f, true, 1f)
fun standing(): MutableList<PoseKeypoint> {
    val s = MutableList(18) { PoseKeypoint() }
    s[0] = P(.50f, .12f); s[1] = P(.50f, .20f); s[2] = P(.44f, .21f); s[5] = P(.56f, .21f)
    s[3] = P(.42f, .33f); s[6] = P(.59f, .32f); s[4] = P(.41f, .45f); s[7] = P(.60f, .44f)
    s[8] = P(.46f, .50f); s[11] = P(.54f, .50f); s[9] = P(.45f, .70f); s[12] = P(.55f, .71f); s[10] = P(.45f, .90f); s[13] = P(.55f, .91f)
    s[14] = P(.48f, .10f); s[15] = P(.52f, .10f); s[16] = P(.46f, .11f); s[17] = P(.54f, .11f)
    return s
}
fun dist(a: PoseKeypoint, b: PoseKeypoint) = hypot(a.x - b.x, a.y - b.y)

fun main() {
    // ── 1. đáp án Python độc lập (tính từ schmid2019_tableA1 + nhanes3 + zivicnjak chép nguyên văn) ──
    System.getenv("AGE_SEX_EXPECTED")?.let { path ->
        val rows = java.io.File(path).readLines().filter { it.isNotBlank() }.map { it.trim().split(" ") }
        check(rows.size == 26, "tệp đáp án có 26 dòng (2 giới × 13 tuổi): ${rows.size}")
        var okAll = true; var bad = ""
        for (r in rows) {
            val sex = if (r[0] == "M") BodySex.MALE else BodySex.FEMALE; val a = r[1].toInt(); val v = r.drop(2).map { it.toFloat() }
            val q = AgeBodyTable.ratiosVsAdult(a, sex)
            val got = listOf(AgeBodyTable.shoulderVsAdult(a, sex), AgeBodyTable.hipVsAdult(a, sex), AgeBodyTable.shoulderFraction(a, sex), AgeBodyTable.hipFraction(a, sex),
                q.head, q.trunk, q.shoulder, q.thigh, q.shank, q.upperArm, q.forearm, q.hip)
            for (i in got.indices) if (!near(got[i], v[i], 1e-4f)) { okAll = false; bad += " [${r[0]}$a#$i ${got[i]} vs ${v[i]}]" }
        }
        check(okAll, "khớp đáp án Python độc lập (vai, hông, phần-trăm-chiều-cao của vai/hông, 8 tỷ lệ tuyệt đối) ở cả 26 ô nam/nữ × 6–18 tuổi$bad")
    }

    // ── 2. dị biệt giới là SỐ ĐO THẬT (ngưỡng rút từ chính số liệu, xem mục 285.3) ──
    val shR = { a: Int -> AgeBodyTable.shoulderVsAdult(a, BodySex.MALE) / AgeBodyTable.shoulderVsAdult(a, BodySex.FEMALE) }
    val hpR = { a: Int -> AgeBodyTable.hipVsAdult(a, BodySex.MALE) / AgeBodyTable.hipVsAdult(a, BodySex.FEMALE) }
    check(shR(18) in 1.10f..1.15f && shR(17) in 1.09f..1.14f, "vai nam/nữ lúc 17–18 tuổi ≈ 1,12 (${"%.3f".format(shR(18))}) — khớp ghi chép 284.2")
    check((6..12).all { shR(it) in 0.98f..1.03f }, "dưới 13 tuổi vai nam và nữ gần như bằng nhau (0,98–1,03)")
    check(shR(14) >= 1.03f && shR(16) >= 1.08f, "dậy thì: vai nam vượt nữ rõ từ 14 tuổi (≥1,03) và 16 tuổi (≥1,08)")
    var mono = true; for (a in 12 until 18) if (shR(a + 1) < shR(a) - 0.005f) mono = false
    check(mono, "chênh lệch vai nam/nữ không giảm từ 12 → 18 tuổi (nhiễu mẫu cho phép 0,005)")
    check((10..14).all { AgeBodyTable.hipVsAdult(it, BodySex.MALE) < AgeBodyTable.hipVsAdult(it, BodySex.FEMALE) }, "hông nữ RỘNG HƠN nam ở mọi tuổi 10–14 (số đo)")
    check(hpR(18) in 1.01f..1.05f, "người lớn: hông nam rộng hơn nữ ~2–3% (${"%.3f".format(hpR(18))}) — nhỏ hơn nhiều so với chênh lệch vai")
    val fRel = { a: Int -> (AgeBodyTable.hipVsAdult(a, BodySex.FEMALE) / AgeBodyTable.shoulderVsAdult(a, BodySex.FEMALE)) / (AgeBodyTable.hipVsAdult(a, BodySex.MALE) / AgeBodyTable.shoulderVsAdult(a, BodySex.MALE)) }
    check(fRel(18) >= 1.07f && (6..9).all { fRel(it) in 0.985f..1.02f }, "hông/vai của nữ so với nam: ≈1,09 lúc 18 tuổi, ≈1,0 lúc 6–9 tuổi (${"%.3f".format(fRel(18))})")
    check(AGES.all { AgeBodyTable.shoulderVsAdult(it) == AgeBodyTable.widthVsAdult(it) && AgeBodyTable.hipVsAdult(it) == AgeBodyTable.widthVsAdult(it) }, "không chọn giới: vai = hông = widthVsAdult CŨ, bằng nhau từng bit (một hệ số chung)")
    check(AGES.all { abs((AgeBodyTable.shoulderVsAdult(it, BodySex.MALE) + AgeBodyTable.shoulderVsAdult(it, BodySex.FEMALE)) / 2f - AgeBodyTable.widthVsAdult(it)) <= 0.02f }, "trung bình vai nam–nữ ≈ widthVsAdult trung bình (≤ 0,02) — hai cách định nghĩa nhất quán")

    // ── 3. độ dài các đoạn theo giới ──
    check(AgeBodyTable.heightCm(18, BodySex.MALE) == 175.5f && AgeBodyTable.heightCm(18, BodySex.FEMALE) == 163.4f && AgeBodyTable.heightCm(18) in 169.4f..169.5f, "chiều cao 18 tuổi: nam 175,5; nữ 163,4; trung bình ≈169,45 cm (bảng Schmid)")
    val m18 = BoneProportions.forAge(18, BodySex.MALE); val f18 = BoneProportions.forAge(18, BodySex.FEMALE)
    check(listOf(m18.torsoRatio, m18.upperArmRatio, m18.forearmRatio, m18.upperLegRatio, m18.lowerLegRatio, m18.headSizeRatio, m18.widthRatio, m18.hipWidthRatio).all { it > 1f }, "nam 18 tuổi: MỌI số đo > mốc trung bình (1,0)")
    check(listOf(f18.torsoRatio, f18.upperArmRatio, f18.forearmRatio, f18.upperLegRatio, f18.lowerLegRatio, f18.headSizeRatio, f18.widthRatio, f18.hipWidthRatio).all { it < 1f }, "nữ 18 tuổi: MỌI số đo < mốc trung bình (1,0)")
    check(f18.widthRatio < f18.hipWidthRatio && m18.widthRatio > m18.hipWidthRatio, "người lớn: nữ vai hẹp hơn hông (so với mốc), nam vai rộng hơn hông — hai hệ số đi NGƯỢC chiều")
    check(AGES.all { a -> SEXES.all { s -> AgeBodyTable.heightFractions(a, s).head == AgeBodyTable.heightFractions(a).head } }, "ĐẦU (phần trăm chiều cao) chỉ phụ thuộc TUỔI, bằng nhau từng bit ở mọi giới — quy ước \"N đầu\"")
    // nhóm tag prompt KHÔNG đổi theo giới ở bất kỳ tuổi nào, số đầu lệch ≤ 0,05 so với bảng trung bình
    var tagBad = ""; var headBad = ""
    for (a in AGES) {
        val ref = kind(BoneProportions.forAge(a).headsTallPromptTag())
        for (s in SEXES) {
            val p = BoneProportions.forAge(a, s)
            if (kind(p.headsTallPromptTag()) != ref) tagBad += " $a/$s"
            if (abs(p.approxHeadsTall() - AgeBodyTable.headsTall(a)) > 0.05f) headBad += " $a/$s"
        }
    }
    check(tagBad.isEmpty(), "nhóm tag prompt (child/youthful/không tag) GIỮ NGUYÊN theo giới ở mọi tuổi 6–18$tagBad")
    check(headBad.isEmpty(), "số đầu của nam/nữ lệch ≤ 0,05 so với AgeBodyTable.headsTall mọi tuổi$headBad")
    check(kind(f18.headsTallPromptTag()) == "none" && kind(m18.headsTallPromptTag()) == "none", "người lớn nam/nữ đều KHÔNG tag (≈7,5 đầu)")

    // ── 4. hipWidthRatio: mặc định "theo vai", preset giới điền riêng ──
    check(AGES.all { BoneProportions.forAge(it).hipWidthRatio == 0f && BoneProportions.forAge(it).hipRatio() == BoneProportions.forAge(it).widthRatio }, "không chọn giới: hipWidthRatio = 0 (theo vai), hipRatio() == widthRatio — y hệt trước mục 285")
    check(AGES.all { a -> SEXES.all { s -> BoneProportions.forAge(a, s).hipWidthRatio > 0f } }, "preset theo giới luôn điền hông riêng (> 0)")
    check(BoneProportions(widthRatio = 0.8f, hipWidthRatio = -1f).hipRatio() == 0.8f && BoneProportions(widthRatio = 0.8f, hipWidthRatio = Float.NaN).hipRatio() == 0.8f && BoneProportions(widthRatio = 0.8f, hipWidthRatio = Float.POSITIVE_INFINITY).hipRatio() == 0.8f, "hông ≤ 0 / NaN / ∞ ⇒ theo vai")
    check(BoneProportions(widthRatio = 0.8f, hipWidthRatio = 1.1f).hipRatio() == 1.1f, "hông đặt riêng thì dùng riêng")
    check(BoneProportions.presetAdult() == BoneProportions() && BoneProportions.presetChild() == BoneProportions.forAge(AgeBodyTable.CHILD_AGE) && BoneProportions.presetAdult(BodySex.FEMALE) == f18, "preset: người lớn mặc định == BoneProportions(); preset theo giới == forAge(tuổi, giới)")

    // ── 5. matchingAge: đổi giới áp lại đúng tuổi khi chưa chỉnh tay ──
    check(AGES.all { a -> BodySex.values().all { s -> BoneProportions.forAge(a, s).matchingAge(s) == a } }, "forAge(a, giới).matchingAge(giới) == a ở mọi tuổi và mọi giới")
    check(AGES.all { a -> BoneProportions.forAge(a, BodySex.MALE).matchingAge(BodySex.FEMALE) == null }, "bộ số của nam KHÔNG bị nhận nhầm là của nữ")
    check(BoneProportions.forAge(12, BodySex.FEMALE).copy(torsoRatio = 0.9f).matchingAge(BodySex.FEMALE) == null, "đã chỉnh tay MỘT slider ⇒ không khớp tuổi nào (số của người dùng không bị ghi đè khi đổi giới)")
    check(BoneProportions().matchingAge(BodySex.UNSPECIFIED) == AgeBodyTable.ADULT_AGE, "mặc định (1.0 mọi mặt) khớp 18 tuổi không giới")

    // ── 6. Gson thật: Character và BoneProportions, dữ liệu cũ, null, tên lạ ──
    val g = com.google.gson.Gson()
    val c = Character(id = "c1", name = "An", anchorPrompt = "a girl", seed = 7L, boneProportions = BoneProportions.forAge(12, BodySex.FEMALE), bodySex = BodySex.FEMALE)
    val rt = g.fromJson(g.toJson(c), Character::class.java)
    check(rt == c && rt.sexOrDefault() == BodySex.FEMALE && rt.boneProportions.hipWidthRatio > 0f, "Character khứ hồi JSON giữ NGUYÊN giới và hông riêng")
    val oldJson = "{\"id\":\"c0\",\"name\":\"Cu\",\"anchorPrompt\":\"x\",\"seed\":1,\"role\":\"MAIN\"}"
    val old = g.fromJson(oldJson, Character::class.java)
    check(old.sexOrDefault() == BodySex.UNSPECIFIED, "JSON cũ (không có bodySex) đọc bằng Gson TRẦN ⇒ sexOrDefault() = UNSPECIFIED (dù trường là null vì Character không có hàm tạo mặc định)")
    val gs = com.google.gson.GsonBuilder().registerTypeAdapter(Character::class.java, com.google.gson.InstanceCreator<Character> { Character.blankForGson() }).create()
    val old2 = gs.fromJson(oldJson, Character::class.java)
    check(old2.bodySex == BodySex.UNSPECIFIED && old2.boneProportions == BoneProportions() && old2.loraWeight == 0.75f && old2.anchorVersions.isEmpty() && old2.role == com.mangalocal.model.CharacterRole.MAIN,
        "với InstanceCreator (như StoryManager): trường thiếu lấy ĐÚNG mặc định (boneProportions, loraWeight 0,75, anchorVersions rỗng, bodySex UNSPECIFIED) — không còn null/0")
    check(gs.fromJson(gs.toJson(c), Character::class.java) == c && gs.fromJson("{\"id\":\"z\",\"name\":\"Z\",\"anchorPrompt\":\"p\",\"seed\":2,\"bodySex\":\"MALE\",\"loraWeight\":0.4}", Character::class.java).let { it.bodySex == BodySex.MALE && it.loraWeight == 0.4f },
        "với InstanceCreator: trường CÓ trong JSON vẫn ghi đè mặc định; khứ hồi nguyên vẹn")
    check(g.fromJson("{\"id\":\"c\",\"name\":\"n\",\"anchorPrompt\":\"\",\"seed\":1,\"bodySex\":null}", Character::class.java).sexOrDefault() == BodySex.UNSPECIFIED, "JSON ghi bodySex = null ⇒ sexOrDefault() = UNSPECIFIED (không văng NPE)")
    check(g.fromJson("{\"id\":\"c\",\"name\":\"n\",\"anchorPrompt\":\"\",\"seed\":1,\"bodySex\":\"ALIEN\"}", Character::class.java).sexOrDefault() == BodySex.UNSPECIFIED, "tên giới lạ ⇒ UNSPECIFIED")
    val ob = g.fromJson("{\"torsoRatio\":0.8,\"widthRatio\":0.7}", BoneProportions::class.java)
    check(ob.hipWidthRatio == 0f && ob.hipRatio() == 0.7f, "BoneProportions JSON cũ (có widthRatio, thiếu hông) ⇒ hông theo vai 0,7 (người dùng đã chỉnh vẫn giữ)")
    check(BodySex.parse(null) == BodySex.UNSPECIFIED && BodySex.parse("FEMALE") == BodySex.FEMALE && BodySex.parse("female") == BodySex.UNSPECIFIED && BodySex.safe(null) == BodySex.UNSPECIFIED, "BodySex.parse / safe")

    // ── 7. CharacterLibrary THẬT (Gson thật, tệp thật): giới và hông riêng sống sót qua xuất → nhập ──
    val tmp = java.nio.file.Files.createTempDirectory("lib285").toFile()
    try {
        val lib = java.io.File(tmp, "lib"); val anchors = java.io.File(tmp, "anchors")
        for (s in BodySex.values()) {
            val ch = Character(id = "id_$s", name = "Nhân vật ${s.name}", anchorPrompt = "p", seed = 5L, boneProportions = BoneProportions.forAge(15, s), bodySex = s)
            val e = CharacterLibrary.export(lib, ch)
            check(e != null, "export ${s.name}: ghi được")
            val back = if (e != null) CharacterLibrary.importFrom(lib, e.dirName, emptySet(), anchors) else null
            check(back != null && back.sexOrDefault() == s && back.boneProportions == BoneProportions.forAge(15, s), "thư viện nhân vật: khứ hồi ${s.name} giữ nguyên giới VÀ số đo (kể cả hông riêng)")
        }
        // tệp thư viện CŨ (trước mục 285): không có bodySex, có boneProportions cũ
        val oldDir = java.io.File(lib, "cu"); oldDir.mkdirs()
        java.io.File(oldDir, "character.json").writeText("{\"savedAt\":1,\"name\":\"Cũ\",\"anchorPrompt\":\"x\",\"seed\":3,\"role\":\"MAIN\",\"boneProportions\":{\"torsoRatio\":0.9,\"widthRatio\":0.8}}", Charsets.UTF_8)
        val oc = CharacterLibrary.importFrom(lib, "cu", emptySet(), anchors)
        check(oc != null && oc.sexOrDefault() == BodySex.UNSPECIFIED && oc.boneProportions.widthRatio == 0.8f && oc.boneProportions.hipRatio() == 0.8f, "tệp thư viện CŨ không có bodySex nạp ra UNSPECIFIED, số đo cũ nguyên vẹn")
    } finally { tmp.deleteRecursively() }

    // ── 8. AgeBodyScaler: hông có hệ số riêng; mặc định (hip = shoulder) y hệt cũ ──
    run {
        val p = standing()
        val unit = AgeBodyTable.Segments(1f, 1f, 1f, 1f, 1f, 1f, 1f)
        val o0 = AgeBodyScaler.rescale(p, unit.copy(shoulder = 0.9f, hip = 0.9f)); val o1 = AgeBodyScaler.rescale(p, AgeBodyTable.Segments(1f, 1f, 0.9f, 1f, 1f, 1f, 1f))
        check(o0 == o1, "Segments.hip mặc định = shoulder ⇒ cùng kết quả như truyền hông = vai (hành vi cũ)")
        val o = AgeBodyScaler.rescale(p, unit.copy(shoulder = 1f, hip = 0.8f))
        check(near(dist(o[8], o[11]), dist(p[8], p[11]) * 0.8f, 1e-5f) && near(dist(o[2], o[5]), dist(p[2], p[5]), 1e-5f), "hông ×0,8 mà vai giữ nguyên: hai hệ số độc lập")
        val o2 = AgeBodyScaler.rescale(p, unit.copy(shoulder = 0.7f, hip = 1f))
        check(near(dist(o2[2], o2[5]), dist(p[2], p[5]) * 0.7f, 1e-5f) && near(dist(o2[8], o2[11]), dist(p[8], p[11]), 1e-5f), "vai ×0,7 mà hông giữ nguyên")
        val f = AgeBodyTable.factors(8, 18, BodySex.FEMALE); val m = AgeBodyTable.factors(8, 18, BodySex.MALE)
        check(f.shoulder != f.hip && m.shoulder != m.hip && f.shoulder < m.shoulder && f.hip != m.hip, "factors(8→18) theo giới: vai và hông có hệ số khác nhau; vai nữ lớn lên ít hơn vai nam")
        val u = AgeBodyTable.factors(8, 18); check(u.shoulder == u.hip, "factors không chọn giới: hệ số vai = hông từng bit (như cũ)")
    }

    println(if (fails == 0) "ĐẠT ($passes)" else "THẤT BẠI: $fails")
    if (fails != 0) System.exit(1)
}
