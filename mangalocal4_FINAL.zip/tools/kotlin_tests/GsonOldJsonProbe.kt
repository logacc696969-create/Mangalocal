// mục 286 — ĐO hiểm hoạ "JSON cũ thiếu trường" cho các lớp mô hình được StoryManager lưu ra đĩa. Với mỗi lớp: dựng bản mặc định, ghi JSON, XOÁ TỪNG TRƯỜNG khỏi JSON (giả lập tệp do bản cũ lưu),
// nạp lại và so với giá trị mặc định ban đầu. Gson trần: trường thiếu không lấy mặc định nếu lớp không có hàm tạo không đối số (mọi lớp dưới đây đều có tham số bắt buộc).
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.mangalocal.model.*

val TIME_FIELDS = setOf("createdAt", "updatedAt")   // mặc định theo đồng hồ: khác nhau giữa hai lần dựng, không phải lỗi
fun probe(name: String, obj: Any, blank: Any, g: Gson): Pair<Int, List<String>> {
    val cls = obj.javaClass; val tree = g.toJsonTree(obj).asJsonObject; val bad = mutableListOf<String>(); var n = 0
    for (k in tree.keySet().toList()) {
        if (k in TIME_FIELDS) continue
        val copy = JsonObject(); for ((kk, v) in tree.entrySet()) if (kk != k) copy.add(kk, v)
        n++
        val back = try { g.fromJson(copy, cls) } catch (e: Throwable) { bad.add("$k(ném ${e.javaClass.simpleName})"); continue }
        val f = cls.getDeclaredField(k).apply { isAccessible = true }
        if (f.get(back) != f.get(blank)) bad.add("$k(${f.get(back)} thay vì ${f.get(blank)})".take(90))
    }
    return n to bad
}
fun sc(i: Int = 0, d: String = "", c: List<String> = emptyList(), m: String = "", a: String = "") = Scene(index = i, description = d, characters = c, mood = m, cameraAngle = a)
// (tên, bản CÓ GIÁ TRỊ để sinh JSON, bản TRỐNG = mặc định Kotlin + giá trị trống không-null cho trường bắt buộc — đáp án mong đợi khi trường vắng trong JSON; viết ĐỘC LẬP với ModelJson)
fun cases(): List<Triple<String, Any, Any>> = listOf(
    Triple("Character", Character(id = "c", name = "n", anchorPrompt = "p", seed = 1L), Character(id = "", name = "", anchorPrompt = "", seed = 0L)),
    Triple("Story", Story(id = "s", title = "t"), Story(id = "", title = "")),
    Triple("Chapter", Chapter(id = "c", storyId = "s", title = "t", chapterNumber = 1, storyText = "x", style = ImageStyle.MANGA, panels = emptyList()),
        Chapter(id = "", storyId = "", title = "", chapterNumber = 0, storyText = "", style = ImageStyle.REALISTIC, panels = emptyList())),
    Triple("Panel", Panel(index = 1, scene = sc(1, "d", listOf("a"), "m", "c"), prompt = "p", negativePrompt = "n"), Panel(index = 0, scene = sc(), prompt = "", negativePrompt = "")),
    Triple("Scene", sc(1, "d", listOf("a"), "m", "c"), sc()),
    Triple("Bubble", Bubble(id = "b", characterName = "n", text = "t"), Bubble(id = "", characterName = "", text = "")),
    Triple("DialogueLine", DialogueLine(characterName = "n", text = "t"), DialogueLine(characterName = "", text = "")),
    Triple("ObjectBox", ObjectBox(label = "l", xmin = 0.1f, ymin = 0.1f, xmax = 0.5f, ymax = 0.5f), ObjectBox(label = "", xmin = 0f, ymin = 0f, xmax = 0f, ymax = 0f)),
    Triple("Location", Location(id = "l", name = "n"), Location(id = "", name = "")),
    Triple("CharacterAnchorVersion", CharacterAnchorVersion(fromChapterNumber = 2, imagePath = "p"), CharacterAnchorVersion(fromChapterNumber = 0, imagePath = "")),
    Triple("AddonLora", AddonLora(id = "i", displayName = "d", fileName = "f"), AddonLora(id = "", displayName = "", fileName = "")),
    Triple("PageSpec", PageSpec(template = "t", panelIndexes = listOf(0, 1)), PageSpec(template = "", panelIndexes = emptyList())),
    Triple("ConditioningPreset", ConditioningPreset(0.5f, 0.6f, 300f, 0.3f, 100f, 1f), ConditioningPreset(0f, 0f, 0f, 0f, 0f, 0f))
)

// ── ĐỦ LỚP CHƯA? Duyệt đồ thị kiểu (reflection) từ các lớp gốc; lớp mô hình lồng bên trong mà KHÔNG có hàm tạo không đối số và CHƯA được đăng ký sẽ nạp JSON cũ thành null/0 như Character trước mục 285.
fun visitModelType(t: java.lang.reflect.Type, seen: MutableSet<Class<*>>) {
    when (t) {
        is Class<*> -> visitModelClass(t, seen)
        is java.lang.reflect.ParameterizedType -> { visitModelType(t.rawType, seen); t.actualTypeArguments.forEach { visitModelType(it, seen) } }
        is java.lang.reflect.WildcardType -> { t.upperBounds.forEach { visitModelType(it, seen) }; t.lowerBounds.forEach { visitModelType(it, seen) } }
        is java.lang.reflect.GenericArrayType -> visitModelType(t.genericComponentType, seen)
    }
}
fun visitModelClass(c: Class<*>, seen: MutableSet<Class<*>>) {
    if (c.isArray) { visitModelClass(c.componentType, seen); return }
    if (!c.name.startsWith("com.mangalocal.model.") || c.isEnum || c.isInterface || c.name.endsWith("\$Companion") || !seen.add(c)) return
    for (f in c.declaredFields) if (!java.lang.reflect.Modifier.isStatic(f.modifiers)) visitModelType(f.genericType, seen)
}
fun reachableModelClasses(roots: List<Class<*>>): Set<Class<*>> { val seen = linkedSetOf<Class<*>>(); roots.forEach { visitModelClass(it, seen) }; return seen }
fun hasNoArgCtor(c: Class<*>) = try { c.getDeclaredConstructor(); true } catch (e: NoSuchMethodException) { false }
// các lớp đã đăng ký InstanceCreator THẬT SỰ trong Gson được kiểm (đọc qua reflection: Gson.constructorConstructor.instanceCreators) — không dùng danh sách của chính probe, nếu không bỏ đăng ký trong ModelJson sẽ không bị lộ
fun registeredCreators(g: Gson): Set<Class<*>> {
    val cc = Gson::class.java.getDeclaredField("constructorConstructor").apply { isAccessible = true }.get(g)
    val m = cc.javaClass.getDeclaredField("instanceCreators").apply { isAccessible = true }.get(cc) as Map<*, *>
    return m.keys.filterIsInstance<Class<*>>().toSet()
}
fun completeness(g: Gson): List<String> {
    // gốc = những gì StoryManager nạp từ đĩa: Character, Story, Chapter, AddonLora (+ mọi thứ lồng bên trong)
    val reach = reachableModelClasses(listOf(Character::class.java, Story::class.java, Chapter::class.java, AddonLora::class.java))
    val reg = registeredCreators(g)
    return reach.filter { !hasNoArgCtor(it) && it !in reg }.map { it.simpleName }.sorted()
}
fun main(args: Array<String>) {
    val g = if (args.isNotEmpty() && args[0] == "fixed") ModelJson.gson() else Gson()
    var total = 0; var totalBad = 0
    for ((name, obj, blank) in cases()) {
        val (n, bad) = probe(name, obj, blank, g); total += n; totalBad += bad.size
        println(String.format("%-24s %2d trường thử; KHÔNG khôi phục đúng mặc định: %2d %s", name, n, bad.size, if (bad.isEmpty()) "" else bad.take(6).toString()))
    }
    val missing = completeness(g); println("CHƯA ĐĂNG KÝ (lớp mô hình lồng bên trong, không có hàm tạo không đối số): ${missing.size} ${if (missing.isEmpty()) "" else missing}")
    println("TỔNG: $totalBad / $total trường")
    if (args.isNotEmpty() && args[0] == "fixed" && (totalBad != 0 || missing.isNotEmpty())) System.exit(1)
}
