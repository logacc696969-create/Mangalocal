// mục 279 — test CHẠY MÃ KOTLIN THẬT cho Pose3D (biến đổi cả người 2D, dựng độ sâu từ khung xương 2D, camera orbit).
// Biên dịch cùng StubStoryManager.kt + AgeBodyTable.kt + Pose3D.kt bằng kotlinc — xem tools/test_pose3d.py.
// Cách kiểm độ sâu: dựng khung xương 3D THẬT (độ dài xương đúng tỷ lệ AgeBodyTable), chiếu trực giao xuống 2D (bỏ z), chạy reconstructDepth rồi so z với z thật.
// LƯU Ý trung thực: mô hình đầu và hướng vai trong bộ dựng dùng cùng giả định với mã dựng độ sâu, nên phần đầu/vai chỉ kiểm được RẰNG GIẢI ĐÚNG hệ phương trình, không kiểm được
// rằng giả định ấy đúng với người thật. Phần chi (cánh tay, chân) mới là kiểm độc lập hơn: tỷ lệ từ bảng số đo thật, hình học co đoạn là toán thuần.
import com.mangalocal.model.AgeBodyTable
import com.mangalocal.pipeline.Pose3D
import com.mangalocal.pipeline.StoryManager.PoseKeypoint
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

var fails = 0
var passes = 0
fun check(ok: Boolean, name: String) { println((if (ok) "PASS " else "FAIL ") + name); if (ok) passes++ else fails++ }
fun near(a: Float, b: Float, eps: Float = 1e-3f) = abs(a - b) <= eps

typealias V3 = Triple<Float, Float, Float>
class Truth(val X: FloatArray, val Y: FloatArray, val Z: FloatArray)

fun norm(v: V3): V3 { val n = sqrt(v.first * v.first + v.second * v.second + v.third * v.third); return V3(v.first / n, v.second / n, v.third / n) }

/**
 * Khung xương 3D thật (đơn vị đẳng hướng, aspect 1). Khung thân (trước khi xoay): x = bên TRÁI nhân vật (+), y xuống, z = ra TRƯỚC camera (−).
 * Xoay thân bodyYaw rồi dời tâm hông tới (ox, oy, 0). Đầu có góc xoay riêng headYaw (cùng công thức xoay quanh trục dọc: x' = x cos + z sin, z' = −x sin + z cos).
 */
fun buildTruth(H: Float, bodyYaw: Float, headYaw: Float, leanDeg: Float, dirs: Map<String, V3>, ox: Float = 0.5f, oy: Float = 0.5f): Truth {
    val fr = AgeBodyTable.heightFractions(AgeBodyTable.ADULT_AGE)
    val b = Array(18) { FloatArray(3) }
    val lean = Math.toRadians(leanDeg.toDouble())
    b[1] = floatArrayOf(0f, (-cos(lean) * fr.trunk * H).toFloat(), (-sin(lean) * fr.trunk * H).toFloat())
    val hs = H * fr.shoulder / 2f; val hh = 0.8f * hs
    fun add(p: FloatArray, dx: Float, dy: Float, dz: Float) = floatArrayOf(p[0] + dx, p[1] + dy, p[2] + dz)
    b[2] = add(b[1], -hs, 0f, 0f); b[5] = add(b[1], hs, 0f, 0f)
    b[8] = floatArrayOf(-hh, 0f, 0f); b[11] = floatArrayOf(hh, 0f, 0f)
    fun limb(parent: Int, child: Int, key: String, l: Float) {
        val d = norm(dirs[key] ?: V3(0f, 1f, 0f))
        b[child] = add(b[parent], d.first * l * H, d.second * l * H, d.third * l * H)
    }
    limb(2, 3, "uaR", fr.upperArm); limb(3, 4, "faR", fr.forearm); limb(5, 6, "uaL", fr.upperArm); limb(6, 7, "faL", fr.forearm)
    limb(8, 9, "thR", fr.thigh); limb(9, 10, "shR", fr.shank); limb(11, 12, "thL", fr.thigh); limb(12, 13, "shL", fr.shank)
    val psi = Math.toRadians(bodyYaw.toDouble()); val cp = cos(psi).toFloat(); val sp = sin(psi).toFloat()
    val X = FloatArray(18); val Y = FloatArray(18); val Z = FloatArray(18)
    for (i in 1..13) { if (i == 1 || i in 2..13) { X[i] = ox + b[i][0] * cp + b[i][2] * sp; Y[i] = oy + b[i][1]; Z[i] = -b[i][0] * sp + b[i][2] * cp } }
    // đầu: tâm đầu ngay trên cổ (không lệch độ sâu), điểm mặt theo mô hình chuẩn xoay headYaw
    val r = H * fr.head / 2f
    val hy = Math.toRadians(headYaw.toDouble()); val ch = cos(hy).toFloat(); val sh = sin(hy).toFloat()
    val hcX = X[1]; val hcY = Y[1] - 1.2f * r; val hcZ = Z[1]
    fun face(i: Int, lateral: Float, fwd: Float, dy: Float) {
        val x = lateral * r; val z = -fwd * r
        X[i] = hcX + x * ch + z * sh; Y[i] = hcY + dy * r; Z[i] = hcZ - x * sh + z * ch
    }
    face(0, 0f, 0.9f, 0.1f); face(15, +0.4f, 0.8f, -0.25f); face(14, -0.4f, 0.8f, -0.25f); face(17, +1f, 0f, 0f); face(16, -1f, 0f, 0f)
    return Truth(X, Y, Z)
}
fun toPose(t: Truth, aspect: Float, withZ: Boolean): MutableList<PoseKeypoint> =
    MutableList(18) { PoseKeypoint(t.X[it] / aspect, t.Y[it], if (withZ) t.Z[it] / aspect else 0f, true, 1f) }

val ALL = (0 until 18).toList()
fun zErr(rec: List<PoseKeypoint>, t: Truth, aspect: Float, idx: List<Int>): Float = idx.maxOf { abs(rec[it].z * aspect - t.Z[it]) }

fun dirsA() = mapOf(
    "uaR" to V3(-0.2f, 1f, -0.3f), "faR" to V3(-0.1f, 0.5f, -0.9f),
    "uaL" to V3(0.2f, 1f, -0.2f), "faL" to V3(0.3f, 0.2f, -0.9f),
    "thR" to V3(-0.05f, 1f, -0.5f), "shR" to V3(0f, 1f, 0.6f),
    "thL" to V3(0.05f, 1f, -0.3f), "shL" to V3(0f, 1f, 0f))

fun main(args: Array<String>) {
    if (args.contains("--noise")) { noiseStudy(); return }
    if (args.contains("--sweep")) { sweepStudy(); return }
    if (args.contains("--coco")) { cocoNoiseStudy(); return }
    // Các kiểm khôi phục CHÍNH XÁC (mục 1–3) chạy với tham số toán thuần (không biên chống nhiễu, s = đoạn dài nhất) để kiểm đúng công thức Taylor; mục 6 kiểm hành vi với tham số chốt có nhiễu.
    val defMargin = Pose3D.noiseMargin; val defTopK = Pose3D.scaleTopK
    Pose3D.noiseMargin = 0f; Pose3D.scaleTopK = 1
    val limbsIdx = listOf(3, 4, 6, 7, 9, 10, 12, 13)

    // ── 1. dựng độ sâu: chi (kiểm độc lập hơn) ──
    for (aspect in listOf(1f, 1.5f)) {
        val tA = buildTruth(0.7f, 0f, 0f, 10f, dirsA())
        val pA = toPose(tA, aspect, false)
        val rec = Pose3D.reconstructDepth(pA, aspect, limbDepth = true)
        check(zErr(rec, tA, aspect, limbsIdx) < 2e-3f, "[aspect $aspect] chi: z dựng lại khớp z THẬT (dấu mặc định đúng) — sai số ${"%.5f".format(zErr(rec, tA, aspect, limbsIdx))}")
        check(zErr(rec, tA, aspect, listOf(1)) < 2e-3f, "[aspect $aspect] thân nghiêng ra trước: z cổ khớp")
        check(ALL.all { near(rec[it].x, pA[it].x, 0f) && near(rec[it].y, pA[it].y, 0f) }, "[aspect $aspect] không đổi x, y")
    }
    // dấu mặc định SAI → lật theo chi sửa được
    val dirsB = dirsA().toMutableMap().also {
        it["uaL"] = V3(0.2f, 1f, 0.4f); it["faL"] = V3(0.3f, 0.3f, 0.9f)       // cả tay trái ra SAU camera (ngược mặc định)
        it["thR"] = V3(-0.05f, 1f, 0.5f); it["shR"] = V3(0f, 1f, -0.6f)         // chân phải: đùi ra sau, cẳng chân ra trước (ngược mặc định)
    }
    val tB = buildTruth(0.7f, 0f, 0f, 10f, dirsB); val pB = toPose(tB, 1f, false)
    val noFlip = Pose3D.reconstructDepth(pB, limbDepth = true)
    check(zErr(noFlip, tB, 1f, listOf(6, 7, 9, 10)) > 0.02f, "không lật: tay trái và chân phải dựng NGƯỢC chiều sâu (một ảnh 2D không phân biệt được — đây là mập mờ thật)")
    val flipped = Pose3D.reconstructDepth(pB, flips = Pose3D.FLIP_L_ARM or Pose3D.FLIP_R_LEG, limbDepth = true)
    check(zErr(flipped, tB, 1f, limbsIdx) < 2e-3f, "lật FLIP_L_ARM + FLIP_R_LEG: khớp z thật")
    check(near(flipped[0].x, pB[0].x, 0f), "lật chiều sâu không đụng x")
    val f0 = Pose3D.reconstructDepth(pA0(), limbDepth = true); val fL = Pose3D.reconstructDepth(pA0(), flips = Pose3D.FLIP_L_ARM, limbDepth = true)
    check(near(fL[6].z - fL[5].z, -(f0[6].z - f0[5].z)) && near(fL[7].z - fL[6].z, -(f0[7].z - f0[6].z)) && near(fL[9].z, f0[9].z) , "FLIP_L_ARM chỉ đảo cánh tay trái, chân giữ nguyên")

    // ── 2. dựng độ sâu: xoay thân (vai/hông) ──
    val straight = mapOf("uaR" to V3(0f, 1f, 0f), "faR" to V3(0f, 1f, 0f), "uaL" to V3(0f, 1f, 0f), "faL" to V3(0f, 1f, 0f), "thR" to V3(0f, 1f, 0f), "shR" to V3(0f, 1f, 0f), "thL" to V3(0f, 1f, 0f), "shL" to V3(0f, 1f, 0f))
    val fr = AgeBodyTable.heightFractions(AgeBodyTable.ADULT_AGE)
    for (yaw in listOf(0f, 15f, 30f, 45f, 60f, 75f, 80f, 90f)) {
        val t = buildTruth(0.7f, yaw, yaw, 0f, straight); val rec = Pose3D.reconstructDepth(toPose(t, 1f, false), limbDepth = true)
        val sh = listOf(2, 5, 8, 11)
        val err = zErr(rec, t, 1f, sh); val planar = sh.maxOf { abs(t.Z[it]) }
        check(err <= planar + 1e-3f, "thân xoay ${yaw.toInt()}°: sai số vai/hông (${"%.4f".format(err)}) KHÔNG tệ hơn giả định phẳng (${"%.4f".format(planar)})")
    }
    for (yaw in listOf(0f, 80f, 90f)) {
        val t = buildTruth(0.7f, yaw, yaw, 0f, straight); val rec = Pose3D.reconstructDepth(toPose(t, 1f, false), limbDepth = true)
        check(zErr(rec, t, 1f, listOf(2, 5, 8, 11)) < 4e-3f, "thân xoay ${yaw.toInt()}° (đủ hẹp hoặc chính diện): vai/hông khôi phục đúng — sai số ${"%.4f".format(zErr(rec, t, 1f, listOf(2, 5, 8, 11)))}")
        check(zErr(rec, t, 1f, listOf(0, 14, 15, 16, 17)) < 4e-3f, "đầu xoay ${yaw.toInt()}°: điểm mặt khớp mô hình đầu chuẩn")
    }
    val tm = buildTruth(0.7f, 60f, 60f, 0f, straight); val recm = Pose3D.reconstructDepth(toPose(tm, 1f, false), limbDepth = true)
    val flipT = Pose3D.reconstructDepth(toPose(tm, 1f, false), flips = Pose3D.FLIP_TORSO, limbDepth = true)
    check(recm[5].z < recm[2].z && flipT[5].z > flipT[2].z, "FLIP_TORSO đảo bên nào của vai ra trước")

    // ── 3. camera orbit ──
    val tC = buildTruth(0.7f, 0f, 0f, 10f, dirsA(), 0.5f, 0.5f)
    val truthWithZ = toPose(tC, 1f, true)
    val recC = Pose3D.reconstructDepth(toPose(tC, 1f, false), limbDepth = true)
    val oTruth = Pose3D.orbit(listOf(truthWithZ), listOf(0), 40f, 15f)[0]
    val oRec = Pose3D.orbit(listOf(toPose(tC, 1f, false)), listOf(0), 40f, 15f, limbDepth = true)[0]
    val dev = ALL.maxOf { max(abs(oTruth[it].x - oRec[it].x), max(abs(oTruth[it].y - oRec[it].y), abs(oTruth[it].z - oRec[it].z))) }
    check(dev < 3e-3f, "xoay camera yaw 40° pitch 15°: dựng độ sâu từ 2D rồi xoay khớp xoay khung xương 3D thật — lệch tối đa ${"%.5f".format(dev)}")
    val id = Pose3D.orbit(listOf(truthWithZ), listOf(0), 0f, 0f)[0]
    check(ALL.all { id[it] == truthWithZ[it] }, "yaw = pitch = 0 trả đúng dữ liệu cũ (không trôi số)")
    val boneList = listOf(1 to 2, 1 to 5, 2 to 3, 3 to 4, 5 to 6, 6 to 7, 8 to 9, 9 to 10, 11 to 12, 12 to 13, 8 to 11)
    var lenOk = true
    for ((y, p) in listOf(33f to -20f, -70f to 10f, 90f to 45f, 12f to 0f)) {
        val o = Pose3D.orbit(listOf(truthWithZ), listOf(0), y, p)[0]
        if (!boneList.all { (a, b) -> near(Pose3D.dist3(truthWithZ, a, b), Pose3D.dist3(o, a, b), 1e-4f) }) lenOk = false
    }
    check(lenOk, "xoay camera giữ nguyên độ dài xương 3D (bốn góc khác nhau)")
    val hipBefore = Triple((truthWithZ[8].x + truthWithZ[11].x) / 2f, (truthWithZ[8].y + truthWithZ[11].y) / 2f, (truthWithZ[8].z + truthWithZ[11].z) / 2f)
    val o40 = Pose3D.orbit(listOf(truthWithZ), listOf(0), 40f, 15f)[0]
    check(near((o40[8].x + o40[11].x) / 2f, hipBefore.first, 1e-4f) && near((o40[8].y + o40[11].y) / 2f, hipBefore.second, 1e-4f), "tâm hông đứng yên khi xoay camera")
    val back = Pose3D.orbit(listOf(o40.let { Pose3D.orbit(listOf(truthWithZ), listOf(0), 40f, 0f)[0] }), listOf(0), -40f, 0f)[0]
    check(ALL.all { near(back[it].x, truthWithZ[it].x, 1e-4f) && near(back[it].y, truthWithZ[it].y, 1e-4f) && near(back[it].z, truthWithZ[it].z, 1e-4f) }, "yaw +40° rồi −40° về đúng hình cũ")
    check(Pose3D.orbit(listOf(truthWithZ), listOf(0), 200f, 0f)[0].let { o -> val c = Pose3D.orbit(listOf(truthWithZ), listOf(0), 90f, 0f)[0]; ALL.all { near(o[it].x, c[it].x, 1e-5f) } }, "yaw 200° bị chặn về 90°")
    check(Pose3D.orbit(listOf(truthWithZ), listOf(0), 0f, 80f)[0].let { o -> val c = Pose3D.orbit(listOf(truthWithZ), listOf(0), 0f, 45f)[0]; ALL.all { near(o[it].y, c[it].y, 1e-5f) } }, "pitch 80° bị chặn về 45°")

    // hướng camera theo ĐÚNG vị trí camera mà poseorbit tài liệu hoá: (sin yaw·cos pitch, −sin pitch, −cos yaw·cos pitch). Điểm nằm trên đường nhìn phải rơi vào tâm màn hình, gần camera hơn gốc.
    var camOk = true
    for ((y, p) in listOf(30f to 0f, -50f to 0f, 0f to 20f, 45f to -30f, -80f to 40f)) {
        val k = 0.3f; val yr = Math.toRadians(y.toDouble()); val pr = Math.toRadians(p.toDouble())
        val cx = (sin(yr) * cos(pr)).toFloat(); val cy = (-sin(pr)).toFloat(); val cz = (-cos(yr) * cos(pr)).toFloat()
        val pose = MutableList(18) { PoseKeypoint(0.5f, 0.5f, 0f, false, 1f) }
        pose[8] = PoseKeypoint(0.48f, 0.5f, 0f, true, 1f); pose[11] = PoseKeypoint(0.52f, 0.5f, 0f, true, 1f)   // tâm hông (0.5, 0.5, 0)
        pose[1] = PoseKeypoint(0.5f + k * cx, 0.5f + k * cy, k * cz, true, 1f)                                      // điểm trên đường nhìn của camera
        val o = Pose3D.orbit(listOf(pose), listOf(0), y, p)[0]
        if (!(near(o[1].x, 0.5f, 1e-4f) && near(o[1].y, 0.5f, 1e-4f) && near(o[1].z, -k, 1e-4f))) camOk = false
    }
    check(camOk, "camera ở đúng (sin yaw·cos pitch, −sin pitch, −cos yaw·cos pitch): điểm trên đường nhìn rơi vào tâm màn hình, gần camera hơn gốc (z = −k)")
    // yaw dương: mũi (ra trước camera) hiện LỆCH TRÁI trên ảnh; âm: lệch phải
    val flat = Pose3D.reconstructDepth(toPose(buildTruth(0.7f, 0f, 0f, 0f, straight), 1f, false))
    val yp = Pose3D.orbit(listOf(flat), listOf(0), 90f, 0f)[0]; val yn = Pose3D.orbit(listOf(flat), listOf(0), -90f, 0f)[0]
    check(yp[0].x < yp[1].x - 0.02f && yn[0].x > yn[1].x + 0.02f, "yaw +90°: mũi lệch trái so với cổ; yaw −90°: lệch phải (mô hình đầu chuẩn)")
    check(near(yp[2].x, yp[5].x, 3e-3f), "người phẳng nhìn ngang 90°: hai vai trùng x (bề rộng vai về 0)")
    // một tay vươn rất sâu về phía camera + nghiêng camera → nếu không fitInside thì y vọt ra ngoài khung
    val reach = toPose(tC, 1f, true); reach[7] = reach[7].copy(y = 0.6f, z = -0.9f)
    val oReach = Pose3D.orbit(listOf(reach), listOf(0), 0f, 45f)[0]
    val rawY = 0.5f + (cos(Math.toRadians(45.0)) * (0.6 - 0.5) - sin(Math.toRadians(45.0)) * (-0.9 - 0.0)).toFloat()
    check(rawY > 1f && oReach.all { it.x in 0f..1f && it.y in 0f..1f }, "xoay camera đẩy khớp ra ngoài khung (y thô = ${"%.2f".format(rawY)} > 1) → được đưa lại vào trong khung")
    // nhóm: tâm chung, giữ bố cục; người không chọn giữ nguyên
    val pa = toPose(buildTruth(0.5f, 0f, 0f, 0f, straight, 0.3f, 0.5f), 1f, false); val pb = toPose(buildTruth(0.5f, 0f, 0f, 0f, straight, 0.7f, 0.5f), 1f, false)
    val og = Pose3D.orbit(listOf(pa, pb), listOf(0, 1), 60f, 0f)
    val d0 = (pb[8].x + pb[11].x) / 2f - (pa[8].x + pa[11].x) / 2f; val d1 = (og[1][8].x + og[1][11].x) / 2f - (og[0][8].x + og[0][11].x) / 2f
    check(near(d1, d0 * cos(Math.toRadians(60.0)).toFloat(), 4e-3f), "nhóm 2 người xoay quanh tâm chung: khoảng cách ngang giữa hai người co theo cos(yaw)")
    val og1 = Pose3D.orbit(listOf(pa, pb), listOf(0), 40f, 0f)
    check(ALL.all { og1[1][it] == pb[it] }, "người không được chọn giữ nguyên tuyệt đối")
    val hid = toPose(tC, 1f, true); hid[4] = hid[4].copy(visible = false)
    val oh = Pose3D.orbit(listOf(hid), listOf(0), 30f, 10f)[0]
    check(oh[4] == hid[4], "khớp đang ẩn không bị động")
    check(Pose3D.orbit(listOf(MutableList(18) { PoseKeypoint() }), listOf(0), 30f, 0f).size == 1, "người không khớp nào hiện: không lỗi")

    // ── 4. biến đổi cả người 2D ──
    val base = toPose(buildTruth(0.5f, 0f, 0f, 0f, straight, 0.5f, 0.5f), 1f, false)
    val tr = Pose3D.translate(base, 0.1f, -0.1f)
    check(near(tr[8].x - base[8].x, 0.1f, 1e-5f) && near(tr[8].y - base[8].y, -0.1f, 1e-5f), "dời cả người đúng độ dời")
    val far = Pose3D.translate(base, 5f, 5f)
    check(far.all { it.x <= 1f + 1e-6f && it.y <= 1f + 1e-6f } && far.maxOf { it.x } > 0.99f, "dời quá xa: dừng sát mép khung, không lòi ra")
    val out = base.map { it.copy(x = it.x - 0.45f) }.toMutableList()   // đang lòi ra bên trái
    val outMoved = Pose3D.translate(out, -0.2f, 0f)
    check(near(outMoved.minOf { it.x }, out.minOf { it.x }, 1e-6f) && Pose3D.translate(out, 0.2f, 0f).minOf { it.x } > out.minOf { it.x }, "đã lòi ra: không dời thêm ra ngoài, nhưng dời vào thì được")
    val cen = Pose3D.centerTo(Pose3D.translate(base, 0.2f, 0.2f))
    check(near((cen[8].x + cen[11].x) / 2f, 0.5f, 1e-4f) && near((cen[8].y + cen[11].y) / 2f, 0.5f, 1e-4f), "về giữa khung: tâm hông về (0,5; 0,5)")
    val half = Pose3D.scaleAbout(base, 0.5f)
    check(near(hypot(half[3].x - half[2].x, half[3].y - half[2].y), 0.5f * hypot(base[3].x - base[2].x, base[3].y - base[2].y), 1e-5f)
        && near((half[8].x + half[11].x) / 2f, (base[8].x + base[11].x) / 2f, 1e-5f), "thu 0,5×: xương còn một nửa, tâm hông đứng yên")
    val big = Pose3D.scaleAbout(base, 3f)
    check(big.all { it.x in -1e-5f..1.00001f && it.y in -1e-5f..1.00001f } && big.maxOf { it.y } - big.minOf { it.y } > base.maxOf { it.y } - base.minOf { it.y }, "phóng 3×: chỉ phóng tới sát mép, không lòi")
    check(Pose3D.scaleAbout(base, 1f) === base && Pose3D.scaleAbout(base, 0f) === base && Pose3D.scaleAbout(base, -1f) === base, "hệ số 1 / ≤ 0: trả đúng danh sách cũ")
    for (asp in listOf(1f, 1.5f)) {
        val r90 = Pose3D.roll(base, 90f, asp); val rBack = Pose3D.roll(r90, -90f, asp)
        check(base.indices.all { near(rBack[it].x, base[it].x, 1e-5f) && near(rBack[it].y, base[it].y, 1e-5f) }, "[aspect $asp] xoay phẳng +90° rồi −90° về đúng hình cũ")
        check(near(hypot((r90[3].x - r90[2].x) * asp, r90[3].y - r90[2].y), hypot((base[3].x - base[2].x) * asp, base[3].y - base[2].y), 1e-5f), "[aspect $asp] xoay phẳng giữ nguyên độ dài xương")
    }
    val right = base.map { it }.toMutableList(); right[3] = right[3].copy(x = base[8].x + 0.1f, y = (base[8].y + base[11].y) / 2f)   // khuỷu nằm ngang bên PHẢI tâm hông
    val rr = Pose3D.roll(right, 90f)
    check(rr[3].y > (rr[8].y + rr[11].y) / 2f + 0.05f, "xoay dương = theo chiều kim đồng hồ: điểm bên phải tâm hông đi XUỐNG")
    check(Pose3D.roll(base, 0f) === base, "xoay 0° trả đúng danh sách cũ")
    val m = Pose3D.mirror(tC.let { toPose(it, 1f, true) })
    val mp = toPose(tC, 1f, true); val pv = (mp[8].x + mp[11].x) / 2f
    check(near(m[2].x, 2f * pv - mp[5].x, 1e-5f) && near(m[5].x, 2f * pv - mp[2].x, 1e-5f) && near(m[7].y, mp[4].y, 1e-6f) && near(m[4].y, mp[7].y, 1e-6f), "lật trái-phải: HOÁN ĐỔI nhãn (vai P↔T, cổ tay P↔T) và lật x quanh tâm hông")
    check(m[2].x < m[5].x && m[8].x < m[11].x && m[14].x < m[15].x && m[16].x < m[17].x, "sau khi lật, nhân vật quay mặt về phía người xem vẫn có bên PHẢI ở trái ảnh")
    check(near(m[6].z, mp[3].z, 1e-6f) && near(m[10].z, mp[13].z, 1e-6f), "lật trái-phải giữ nguyên z cùng điểm")
    val mm = Pose3D.mirror(m)
    check(mp.indices.all { near(mm[it].x, mp[it].x, 1e-5f) && near(mm[it].y, mp[it].y, 1e-5f) && near(mm[it].z, mp[it].z, 1e-6f) }, "lật hai lần về đúng hình cũ")
    val outShape = base.map { it.copy(x = it.x + 0.7f) }.toMutableList()
    val fit = Pose3D.fitInside(listOf(outShape))[0]
    check(fit.all { it.x in 0f..1f && it.y in 0f..1f }, "fitInside: hình lòi ra ngoài được đưa vào trong khung")
    check(Pose3D.fitInside(listOf(base))[0] === base, "fitInside: đang nằm trong khung thì trả đúng danh sách cũ")
    val g = Pose3D.fitInside(listOf(outShape, outShape.map { it.copy(x = it.x - 0.3f) }.toMutableList()))
    check(near((g[0][8].x - g[1][8].x), (outShape[8].x - (outShape[8].x - 0.3f)) * (g[0][8].x - g[1][8].x) / 0.3f, 1e-4f) && g.flatMap { it }.all { it.x in 0f..1f }, "fitInside nhóm: biến đổi chung cho mọi người (giữ bố cục)")
    // ── 5. biến đổi NHÓM quanh tâm chung (pa ở x≈0,3 và pb ở x≈0,7) ──
    fun hipC(p: List<PoseKeypoint>) = Pair((p[8].x + p[11].x) / 2f, (p[8].y + p[11].y) / 2f)
    val gp = listOf(pa, pb)
    val gpv = Pose3D.groupPivot(gp, listOf(0, 1))!!
    check(near(gpv.first, 0.5f, 1e-4f), "groupPivot = trung bình tâm hông của nhóm")
    check(Pose3D.groupPivot(listOf(MutableList(18) { PoseKeypoint() }), listOf(0)) == null, "groupPivot: không khớp nào hiện → null")
    val sg = Pose3D.scaleGroup(gp, listOf(0, 1), 0.5f)
    check(near(hipC(sg[1]).first - hipC(sg[0]).first, 0.5f * (hipC(pb).first - hipC(pa).first), 1e-4f)
        && near(hypot(sg[0][3].x - sg[0][2].x, sg[0][3].y - sg[0][2].y), 0.5f * hypot(pa[3].x - pa[2].x, pa[3].y - pa[2].y), 1e-5f), "thu nhóm 0,5×: khoảng cách giữa hai người VÀ cỡ mỗi người cùng co một nửa (giữ bố cục)")
    check(Pose3D.scaleGroup(gp, listOf(0, 1), 1f) === gp, "scaleGroup hệ số 1: trả đúng danh sách cũ")
    val rg = Pose3D.rollGroup(gp, listOf(0, 1), 90f)
    check(near(abs(hipC(rg[1]).second - hipC(rg[0]).second), hipC(pb).first - hipC(pa).first, 1e-4f) && near(hipC(rg[1]).first, hipC(rg[0]).first, 1e-4f), "xoay phẳng nhóm 90°: hai người xếp theo chiều dọc, khoảng cách giữ nguyên")
    val mg = Pose3D.mirrorGroup(gp, listOf(0, 1))
    check(near(hipC(mg[0]).first, hipC(pb).first, 1e-4f) && near(hipC(mg[1]).first, hipC(pa).first, 1e-4f), "lật nhóm: hai người đổi chỗ trái-phải quanh tâm chung")
    check(mg[0][2].x < mg[0][5].x && mg[1][2].x < mg[1][5].x, "lật nhóm: nhãn trái-phải của từng người được hoán đổi (vai P vẫn ở bên trái ảnh)")
    val mgBack = Pose3D.mirrorGroup(mg, listOf(0, 1))
    check(gp.indices.all { i -> ALL.all { near(mgBack[i][it].x, gp[i][it].x, 1e-5f) && near(mgBack[i][it].y, gp[i][it].y, 1e-5f) } }, "lật nhóm hai lần về đúng hình cũ")
    val mOne = Pose3D.mirrorGroup(gp, listOf(0))
    check(mOne[1] === pb, "lật một người trong nhóm: người kia giữ nguyên đối tượng")
    val tg = Pose3D.translateGroup(gp, listOf(0, 1), 0.5f, 0f)
    check(near(hipC(tg[1]).first - hipC(tg[0]).first, hipC(pb).first - hipC(pa).first, 1e-5f) && tg.flatMap { it }.all { it.x <= 1f + 1e-6f } && tg.flatMap { it }.maxOf { it.x } > 0.99f,
        "dời nhóm: chặn theo người ngoài cùng, cả nhóm cùng dừng, khoảng cách giữa hai người giữ nguyên")
    val cg = Pose3D.centerGroup(Pose3D.translateGroup(gp, listOf(0, 1), -0.2f, 0.3f), listOf(0, 1))
    val cgp = Pose3D.groupPivot(cg, listOf(0, 1))!!
    check(near(cgp.first, 0.5f, 1e-4f) && near(cgp.second, 0.5f, 1e-4f), "centerGroup: tâm chung về giữa khung")
    check(Pose3D.translateGroup(gp, listOf(0), 0.1f, 0f)[1] === pb, "dời một người: người kia giữ nguyên đối tượng")

    check(!Pose3D.hasDepth(base) && Pose3D.hasDepth(truthWithZ), "hasDepth: phân biệt khung phẳng và khung có độ sâu")
    check(Pose3D.reconstructDepth(MutableList(10) { PoseKeypoint(0.5f, 0.5f, 0f, true, 1f) }, limbDepth = true).size == 10 && Pose3D.reconstructDepth(MutableList(18) { PoseKeypoint() }, limbDepth = true).all { it.z == 0f }, "danh sách ngắn / không khớp nào hiện: không lỗi, z giữ nguyên")

    // ── 6. chống nhiễu với tham số CHỐT (đo ở 279.5: nhiễu độc lập vào x, y; σ 0,007 ≈ 1% chiều cao) ──
    Pose3D.noiseMargin = defMargin; Pose3D.scaleTopK = defTopK
    val aFlat = noiseMedian(dirsA(), 0.007f, false, 0); val aRec = noiseMedian(dirsA(), 0.007f, true, 0)
    check(aRec <= 0.75f * aFlat, "nhiễu 1%, tay chân CO MẠNH: xoay có dựng độ sâu lệch ${"%.3f".format(aRec)} ≤ 0,75× so với coi người phẳng (${"%.3f".format(aFlat)})")
    val bFlat1 = noiseMedian(straightDirs(), 0.007f, false, 1); val bRec1 = noiseMedian(straightDirs(), 0.007f, true, 1)
    val bFlat2 = noiseMedian(straightDirs(), 0.014f, false, 1); val bRec2 = noiseMedian(straightDirs(), 0.014f, true, 1)
    check(bRec1 <= 1.15f * bFlat1 && bRec2 <= 1.15f * bFlat2, "nhiễu 1% và 2%, ĐỨNG THẲNG: không tệ hơn coi người phẳng quá 15% (${"%.3f".format(bRec1)} vs ${"%.3f".format(bFlat1)}; ${"%.3f".format(bRec2)} vs ${"%.3f".format(bFlat2)}) — không bịa độ sâu giả")
    val cFlat = noiseMedian(mildDirs(), 0.007f, false, 2); val cRec = noiseMedian(mildDirs(), 0.007f, true, 2)
    check(cRec <= 1.15f * cFlat, "nhiễu 1%, tay chân lệch NHẸ: không tệ hơn coi người phẳng quá 15% (${"%.3f".format(cRec)} vs ${"%.3f".format(cFlat)})")

    // ── 7. CHẾ ĐỘ AN TOÀN (mặc định): chỉ đầu + xoay thân, không đoán tay/chân; nhiễu hiệu chỉnh theo COCO ──
    val safeP = Pose3D.reconstructDepth(toPose(buildTruth(0.7f, 0f, 0f, 10f, dirsA()), 1f, false))
    check(near(safeP[3].z, safeP[2].z, 1e-6f) && near(safeP[4].z, safeP[3].z, 1e-6f) && near(safeP[9].z, safeP[8].z, 1e-6f) && near(safeP[10].z, safeP[9].z, 1e-6f) && safeP[0].z < safeP[1].z,
        "mặc định (limbDepth = false): z của khuỷu/cổ tay/gối/cổ chân bằng z khớp cha (không đoán chi), nhưng mũi vẫn ra TRƯỚC cổ (mô hình đầu)")
    val fullP = Pose3D.reconstructDepth(toPose(buildTruth(0.7f, 0f, 0f, 10f, dirsA()), 1f, false), limbDepth = true)
    check(abs(fullP[4].z - fullP[3].z) > 0.02f, "limbDepth = true: có đoán độ sâu cho cẳng tay")
    for ((nm, dirs, si) in listOf(Triple("B đứng thẳng", straightDirs(), 1L), Triple("D dấu SAI", wrongSignDirs(), 3L))) for (f in listOf(0.7f, 1.0f)) {
        val safe = cocoMedian(dirs, f, si, 1); val flatM = cocoMedian(dirs, f, si, 2)
        check(safe <= 1.05f * flatM, "nhiễu COCO×${"%.1f".format(f)}, $nm: chế độ an toàn (${"%.3f".format(safe)}) KHÔNG tệ hơn coi người phẳng (${"%.3f".format(flatM)}) quá 5%")
    }
    val fullB = cocoMedian(straightDirs(), 1.0f, 1, 0); val flatB = cocoMedian(straightDirs(), 1.0f, 1, 2)
    val fullD = cocoMedian(wrongSignDirs(), 0.7f, 3, 0); val flatD = cocoMedian(wrongSignDirs(), 0.7f, 3, 2)
    check(fullB > 1.2f * flatB && fullD > 1.1f * flatD, "CẢNH BÁO có chủ đích: đoán cả chi TỆ hơn phẳng khi đứng thẳng nhiễu COCO×1 (${"%.3f".format(fullB)} vs ${"%.3f".format(flatB)}) và khi dấu đoán sai ×0,7 (${"%.3f".format(fullD)} vs ${"%.3f".format(flatD)}) — vì vậy KHÔNG là mặc định")
    val flz = Pose3D.flattenDepth(toPose(buildTruth(0.7f, 0f, 0f, 10f, dirsA()), 1f, true))
    check(flz.all { it.z == 0f } && near(flz[3].x, toPose(buildTruth(0.7f, 0f, 0f, 10f, dirsA()), 1f, true)[3].x, 0f) && Pose3D.flattenDepth(flz) === flz, "flattenDepth: z = 0, x/y giữ nguyên, đã phẳng thì trả đúng danh sách cũ")

    println(if (fails == 0) "ĐẠT ($passes)" else "THẤT BẠI: $fails")
    if (fails != 0) System.exit(1)
}

fun pA0() = toPose(buildTruth(0.7f, 0f, 0f, 10f, dirsA()), 1f, false)

/**
 * Độ nhạy với NHIỄU (chạy bằng: java -jar … --noise). Thêm nhiễu Gauss độc lập vào x, y của từng khớp trong khung 2D chiếu từ khung 3D thật, dựng độ sâu, rồi so với z thật.
 * Cho biết dựng độ sâu hỏng nhanh cỡ nào khi bộ phát hiện khớp (YOLO) sai vài phần trăm chiều cao. σ tính theo khung (người cao 0,7 khung): σ 0,007 ≈ 1% chiều cao.
 */
fun noiseStudy() {
    val rnd = java.util.Random(12345)
    val H = 0.7f
    val limbs = listOf(3, 4, 6, 7, 9, 10, 12, 13)
    val boneList = listOf(2 to 3, 3 to 4, 5 to 6, 6 to 7, 8 to 9, 9 to 10, 11 to 12, 12 to 13)
    val scenarios = listOf("A: tay vươn ra trước, đùi ra trước" to dirsA(), "B: đứng thẳng (không co)" to mapOf(
        "uaR" to V3(0f, 1f, 0f), "faR" to V3(0f, 1f, 0f), "uaL" to V3(0f, 1f, 0f), "faL" to V3(0f, 1f, 0f),
        "thR" to V3(0f, 1f, 0f), "shR" to V3(0f, 1f, 0f), "thL" to V3(0f, 1f, 0f), "shL" to V3(0f, 1f, 0f)))
    println("σ(khung) σ/cao | scenario | z-lệch chi: trung vị / p95 (÷cao) | lệch 2D sau xoay 40°/15°: tối đa trung vị / p95 (÷cao) | so với KHÔNG dựng độ sâu (z=0): trung vị / p95")
    for ((name, dirs) in scenarios) {
        val truth = buildTruth(H, 0f, 0f, 10f, dirs)
        val truthPose = toPose(truth, 1f, true)
        val orbitTruth = Pose3D.orbit(listOf(truthPose), listOf(0), 40f, 15f)[0]
        for (sigma in listOf(0f, 0.003f, 0.007f, 0.014f, 0.028f)) {
            val zErrs = ArrayList<Float>(); val devs = ArrayList<Float>(); val flatDevs = ArrayList<Float>()
            for (trial in 0 until 300) {
                val noisy = toPose(truth, 1f, false).map { it.copy(x = it.x + sigma * rnd.nextGaussian().toFloat(), y = it.y + sigma * rnd.nextGaussian().toFloat()) }.toMutableList()
                val rec = Pose3D.reconstructDepth(noisy, limbDepth = true)
                zErrs.add(limbs.map { abs(rec[it].z - truth.Z[it]) }.average().toFloat() / H)
                val o = Pose3D.orbit(listOf(noisy), listOf(0), 40f, 15f)[0]
                devs.add((0 until 18).maxOf { max(abs(o[it].x - orbitTruth[it].x), abs(o[it].y - orbitTruth[it].y)) } / H)
                // mốc "không dựng độ sâu": coi người phẳng (z = 0) rồi xoay camera cùng góc — x' = cx + cos(yaw)·px, y' = cy + sin(pitch)·sin(yaw)·px + cos(pitch)·py
                val cxp = (noisy[8].x + noisy[11].x) / 2f; val cyp = (noisy[8].y + noisy[11].y) / 2f
                val ps = Math.toRadians(40.0); val ph = Math.toRadians(15.0)
                flatDevs.add((0 until 18).maxOf {
                    val px = noisy[it].x - cxp; val py = noisy[it].y - cyp
                    val fx = cxp + (cos(ps) * px).toFloat(); val fy = cyp + (sin(ph) * sin(ps) * px + cos(ph) * py).toFloat()
                    max(abs(fx - orbitTruth[it].x), abs(fy - orbitTruth[it].y))
                } / H)
            }
            fun q(l: List<Float>, p: Double) = l.sorted()[((l.size - 1) * p).toInt()]
            println("%.3f  %4.1f%% | %-34s | %.3f / %.3f | %.3f / %.3f | %.3f / %.3f".format(sigma, 100f * sigma / H, name.take(34), q(zErrs, 0.5), q(zErrs, 0.95), q(devs, 0.5), q(devs, 0.95), q(flatDevs, 0.5), q(flatDevs, 0.95)))
        }
    }
}

/** Dò tham số chống nhiễu: với mỗi (biên, top-k) in lệch 2D sau xoay (tối đa trên các khớp, ÷cao) ở vài mức nhiễu và 3 tư thế. Chỉ để chọn hằng số; không phải kiểm. */
fun sweepStudy() {
    val H = 0.7f
    val straight = straightDirs(); val mild = mildDirs()
    val scen = listOf("A co mạnh" to dirsA(), "B thẳng" to straight, "C lệch nhẹ" to mild)
    val sigmas = listOf(0.003f, 0.007f, 0.014f)
    val truths = scen.map { (_, d) -> buildTruth(H, 0f, 0f, 10f, d) }
    val orbT = truths.map { Pose3D.orbit(listOf(toPose(it, 1f, true)), listOf(0), 40f, 15f)[0] }
    println("biên  topK | median độ lệch 2D (÷cao) theo [tư thế × σ]: " + scen.flatMap { (n, _) -> sigmas.map { "${n.take(1)}@${(100 * it / H).toInt()}%" } }.joinToString(" ") + " | trung bình")
    for (k in listOf(1, 3, 5)) for (m in listOf(0f, 0.01f, 0.02f, 0.03f, 0.05f)) {
        Pose3D.noiseMargin = m; Pose3D.scaleTopK = k
        val meds = ArrayList<Float>()
        for ((si, tr) in truths.withIndex()) for (sg in sigmas) {
            val rnd = java.util.Random(777L + si)
            val devs = ArrayList<Float>()
            for (t in 0 until 200) {
                val noisy = toPose(tr, 1f, false).map { it.copy(x = it.x + sg * rnd.nextGaussian().toFloat(), y = it.y + sg * rnd.nextGaussian().toFloat()) }.toMutableList()
                val o = Pose3D.orbit(listOf(noisy), listOf(0), 40f, 15f, limbDepth = true)[0]
                devs.add((0 until 18).maxOf { max(abs(o[it].x - orbT[si][it].x), abs(o[it].y - orbT[si][it].y)) } / H)
            }
            meds.add(devs.sorted()[devs.size / 2])
        }
        println("%.2f   %d    | %s | %.3f".format(m, k, meds.joinToString(" ") { "%.3f".format(it) }, meds.average()))
    }
    Pose3D.noiseMargin = 0.03f; Pose3D.scaleTopK = 5
    // mốc phẳng (không dựng độ sâu), cùng nhiễu
    val flat = ArrayList<Float>()
    for ((si, tr) in truths.withIndex()) for (sg in sigmas) {
        val rnd = java.util.Random(777L + si); val devs = ArrayList<Float>()
        for (t in 0 until 200) {
            val noisy = toPose(tr, 1f, false).map { it.copy(x = it.x + sg * rnd.nextGaussian().toFloat(), y = it.y + sg * rnd.nextGaussian().toFloat()) }.toMutableList()
            val cxp = (noisy[8].x + noisy[11].x) / 2f; val cyp = (noisy[8].y + noisy[11].y) / 2f
            val ps = Math.toRadians(40.0); val ph = Math.toRadians(15.0)
            devs.add((0 until 18).maxOf { val px = noisy[it].x - cxp; val py = noisy[it].y - cyp
                max(abs(cxp + (cos(ps) * px).toFloat() - orbT[si][it].x), abs(cyp + (sin(ph) * sin(ps) * px + cos(ph) * py).toFloat() - orbT[si][it].y)) } / H)
        }
        flat.add(devs.sorted()[devs.size / 2])
    }
    println("phẳng (z=0)  | %s | %.3f".format(flat.joinToString(" ") { "%.3f".format(it) }, flat.average()))
}

fun straightDirs() = mapOf("uaR" to V3(0f, 1f, 0f), "faR" to V3(0f, 1f, 0f), "uaL" to V3(0f, 1f, 0f), "faL" to V3(0f, 1f, 0f),
    "thR" to V3(0f, 1f, 0f), "shR" to V3(0f, 1f, 0f), "thL" to V3(0f, 1f, 0f), "shL" to V3(0f, 1f, 0f))
fun mildDirs() = mapOf("uaR" to V3(-0.2f, 1f, -0.5f), "faR" to V3(0f, 1f, -0.6f), "uaL" to V3(0.2f, 1f, -0.4f), "faL" to V3(0.1f, 1f, -0.7f),
    "thR" to V3(-0.05f, 1f, -0.4f), "shR" to V3(0f, 1f, 0.3f), "thL" to V3(0.05f, 1f, -0.3f), "shL" to V3(0f, 1f, 0.2f))

/** Trung vị (200 lần, hạt giống cố định) của độ lệch 2D lớn nhất sau xoay 40°/15° so với xoay khung xương 3D thật, ÷chiều cao; [withDepth] = dùng Pose3D.orbit, không = coi người phẳng. */
fun noiseMedian(dirs: Map<String, V3>, sigma: Float, withDepth: Boolean, seedOffset: Long): Float {
    val H = 0.7f
    val truth = buildTruth(H, 0f, 0f, 10f, dirs)
    val orbT = Pose3D.orbit(listOf(toPose(truth, 1f, true)), listOf(0), 40f, 15f)[0]
    val rnd = java.util.Random(777L + seedOffset); val devs = ArrayList<Float>()
    for (t in 0 until 200) {
        val noisy = toPose(truth, 1f, false).map { it.copy(x = it.x + sigma * rnd.nextGaussian().toFloat(), y = it.y + sigma * rnd.nextGaussian().toFloat()) }.toMutableList()
        if (withDepth) {
            val o = Pose3D.orbit(listOf(noisy), listOf(0), 40f, 15f, limbDepth = true)[0]
            devs.add((0 until 18).maxOf { max(abs(o[it].x - orbT[it].x), abs(o[it].y - orbT[it].y)) } / H)
        } else {
            val cxp = (noisy[8].x + noisy[11].x) / 2f; val cyp = (noisy[8].y + noisy[11].y) / 2f
            val ps = Math.toRadians(40.0); val ph = Math.toRadians(15.0)
            devs.add((0 until 18).maxOf { val px = noisy[it].x - cxp; val py = noisy[it].y - cyp
                max(abs(cxp + (cos(ps) * px).toFloat() - orbT[it].x), abs(cyp + (sin(ph) * sin(ps) * px + cos(ph) * py).toFloat() - orbT[it].y)) } / H)
        }
    }
    return devs.sorted()[devs.size / 2]
}

fun wrongSignDirs() = dirsA().toMutableMap().also {
    it["uaL"] = V3(0.2f, 1f, 0.4f); it["faL"] = V3(0.3f, 0.3f, 0.9f)       // cả tay trái ra SAU camera (ngược mặc định)
    it["thR"] = V3(-0.05f, 1f, 0.5f); it["shR"] = V3(0f, 1f, -0.6f)         // chân phải: đùi ra sau, cẳng chân ra trước (ngược mặc định)
}

/**
 * Nhiễu hiệu chỉnh theo COCO: σ từng khớp (nose .026, mắt .025, tai .035, vai .079, khuỷu .072, cổ tay .062, hông .107, gối .087, cổ chân .089; cổ lấy như vai) là độ lệch chuẩn của NGƯỜI GÁN NHÃN so với
 * cỡ người s = √(diện tích phân vùng) (cocodataset.org/keypoints-eval). Ở đây s = √(0,6 × bao quanh khung xương) — ước lượng của mình (bao quanh khớp nhỏ hơn bao quanh người ~10–15%), nhân hệ số f
 * (f = 1: σ là độ lệch chuẩn MỖI TRỤC; 0,7: σ là độ lệch chuẩn Euclid; 0,35: bộ phát hiện tốt gấp đôi người gán nhãn). Bộ phát hiện thật có thể tốt hơn hoặc tệ hơn người gán nhãn — CHƯA đo.
 */
/** Trung vị (300 lần, hạt giống cố định) độ lệch 2D lớn nhất sau xoay 40°/15° so với khung xương 3D thật ÷cao, với nhiễu COCO nhân [f]. mode: 0 = đoán cả chi, 1 = chỉ đầu+thân (mặc định của app), 2 = coi người phẳng. */
fun cocoMedian(dirs: Map<String, V3>, f: Float, seedOffset: Long, mode: Int): Float {
    val H = 0.7f
    val sig = floatArrayOf(.026f, .079f, .079f, .072f, .062f, .079f, .072f, .062f, .107f, .087f, .089f, .107f, .087f, .089f, .025f, .025f, .035f, .035f)
    val truth = buildTruth(H, 0f, 0f, 10f, dirs)
    val orbT = Pose3D.orbit(listOf(toPose(truth, 1f, true)), listOf(0), 40f, 15f)[0]
    val sObj = sqrt(0.6f * (truth.X.max() - truth.X.min()) * (truth.Y.max() - truth.Y.min()))
    val rnd = java.util.Random(4242L + seedOffset); val devs = ArrayList<Float>()
    for (t in 0 until 300) {
        val noisy = toPose(truth, 1f, false).mapIndexed { i, k -> k.copy(x = k.x + f * sig[i] * sObj * rnd.nextGaussian().toFloat(), y = k.y + f * sig[i] * sObj * rnd.nextGaussian().toFloat()) }.toMutableList()
        if (mode < 2) {
            val o = Pose3D.orbit(listOf(noisy), listOf(0), 40f, 15f, limbDepth = (mode == 0))[0]
            devs.add((0 until 18).maxOf { max(abs(o[it].x - orbT[it].x), abs(o[it].y - orbT[it].y)) } / H)
        } else {
            val cxp = (noisy[8].x + noisy[11].x) / 2f; val cyp = (noisy[8].y + noisy[11].y) / 2f
            val ps = Math.toRadians(40.0); val ph = Math.toRadians(15.0)
            devs.add((0 until 18).maxOf { val px = noisy[it].x - cxp; val py = noisy[it].y - cyp
                max(abs(cxp + (cos(ps) * px).toFloat() - orbT[it].x), abs(cyp + (sin(ph) * sin(ps) * px + cos(ph) * py).toFloat() - orbT[it].y)) } / H)
        }
    }
    return devs.sorted()[devs.size / 2]
}

fun cocoNoiseStudy() {
    val scen = listOf("A co mạnh, dấu ĐÚNG" to dirsA(), "B đứng thẳng" to straightDirs(), "C lệch nhẹ, dấu ĐÚNG" to mildDirs(), "D co mạnh, dấu SAI (tay T + chân P)" to wrongSignDirs())
    println("f     | " + scen.joinToString(" | ") { it.first } + "   (trung vị độ lệch 2D sau xoay 40°/15° ÷cao: ĐOÁN CẢ CHI / chỉ đầu+thân / coi người phẳng)")
    for (f in listOf(0.35f, 0.7f, 1.0f))
        println("%.2f  | %s".format(f, scen.mapIndexed { si, sc -> "%.3f / %.3f / %.3f".format(cocoMedian(sc.second, f, si.toLong(), 0), cocoMedian(sc.second, f, si.toLong(), 1), cocoMedian(sc.second, f, si.toLong(), 2)) }.joinToString(" | ")))
}
