#!/usr/bin/env python3
"""mục 261 — kiểm thử `pipeline/ContactMap.kt` bằng cách BIÊN DỊCH THẬT bằng kotlinc (cùng bản 1.9.10 với dự án) và CHẠY trên JVM.

Đối chiếu từng phần tử với bản tham chiếu numpy viết độc lập từ ĐỊNH NGHĨA (capsule theo xương + tứ giác thân + đầu, độ phủ giảm tuyến tính
trong biên tiếp xúc, M = max theo cặp của tích độ phủ, làm mượt 3x3). Kiểm thêm tính chất: 2 người xa nhau -> không có bản đồ; ôm nhau ->
đỉnh cao nằm GIỮA hai người; đối xứng gương; ảnh không vuông giữ capsule tròn; thiếu khớp thân -> bỏ người đó; NaN không làm sập.
Thử phá mã: mỗi đột biến phải bị bắt.
Cần kotlinc: biến môi trường KOTLINC (mặc định tìm trong PATH, rồi /home/claude/work/kotlinc/bin/kotlinc). Không có -> BỎ QUA (exit 0, in SKIP).
KHÔNG chứng minh: OccCFG làm ảnh tốt hơn; bản đồ khớp cơ thể thật trên ảnh thật.
"""
import os, re, shutil, struct, subprocess, sys, tempfile
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline/ContactMap.kt')

def find_kotlinc():
    for c in [os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/work/kotlinc/bin/kotlinc']:
        if c and os.path.exists(c): return c
    return None

KOTLINC = find_kotlinc()
if not KOTLINC:
    print('SKIP: không có kotlinc (đặt KOTLINC=...). Test này cần biên dịch Kotlin thật.')
    sys.exit(0)
KLIB = os.path.join(os.path.dirname(os.path.dirname(KOTLINC)), 'lib', 'kotlin-stdlib.jar')

ok = True
def check(name, cond, detail=''):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + detail) if (detail and not cond) else ''))
    ok &= bool(cond)

DRIVER = r'''
import com.mangalocal.pipeline.ContactMap
import java.io.*
import java.nio.*
fun main(args: Array<String>) {
    val bb = ByteBuffer.wrap(File(args[0]).readBytes()).order(ByteOrder.LITTLE_ENDIAN)
    val n = bb.int; val iw = bb.int; val ih = bb.int; val mw = bb.int; val mh = bb.int
    val sk = FloatArray((bb.remaining()) / 4) { bb.float }
    if (args.size > 2) {  // mục 261.11: chế độ mask vùng
        val rm = ContactMap.regionMasks(sk, n, iw, ih, mw, mh)
        val ob = ByteBuffer.allocate(4 * (3 + (rm?.data?.size ?: 0))).order(ByteOrder.LITTLE_ENDIAN)
        if (rm == null) { ob.putFloat(0f); ob.putFloat(0f); ob.putFloat(0f) } else { ob.putFloat(rm.k.toFloat()); ob.putFloat(rm.w.toFloat()); ob.putFloat(rm.h.toFloat()); rm.data.forEach { ob.putFloat(it) } }
        File(args[1]).writeBytes(ob.array())
        return
    }
    val r = ContactMap.build(sk, n, iw, ih, mw, mh)
    val out = ByteBuffer.allocate(4 * (3 + (r?.map?.size ?: 0))).order(ByteOrder.LITTLE_ENDIAN)
    if (r == null) { out.putFloat(0f); out.putFloat(0f); out.putFloat(0f) }
    else { out.putFloat(1f); out.putFloat(r.peak); out.putFloat(r.area); r.map.forEach { out.putFloat(it) } }
    File(args[1]).writeBytes(out.array())
    println("W " + ContactMap.gradedWeight(0f, 0.4f) + " " + ContactMap.gradedWeight(1f, 0.4f) + " " + ContactMap.gradedWeight(0.5f, 0.4f) + " " +
        ContactMap.gradedWeight(Float.NaN, 0.4f) + " " + ContactMap.gradedWeight(0.7f, 2f) + " " + ContactMap.gradedWeight(0.7f, -1f))
    if (r != null) println("I " + r.intensityAt(0.5f, 0.5f) + " " + r.intensityAt(-3f, -3f) + " " + r.intensityAt(9f, 9f))
}
'''

def compile_kt(src_path, tmp, tag):
    drv = os.path.join(tmp, 'Driver.kt'); open(drv, 'w').write(DRIVER)
    jar = os.path.join(tmp, f'{tag}.jar')
    r = subprocess.run([KOTLINC, src_path, drv, '-d', jar], capture_output=True, text=True)
    return jar, r

def run_kt(jar, tmp, skel, n, iw, ih, mw, mh):
    fi = os.path.join(tmp, 'in.bin'); fo = os.path.join(tmp, 'out.bin')
    open(fi, 'wb').write(struct.pack('<5i', n, iw, ih, mw, mh) + np.asarray(skel, np.float32).tobytes())
    r = subprocess.run(['java', '-cp', f'{jar}:{KLIB}', 'DriverKt', fi, fo], capture_output=True, text=True)
    if r.returncode != 0: return None, r.stdout, r.stderr
    d = np.fromfile(fo, dtype=np.float32)
    return d, r.stdout, r.stderr

def run_region(jar, tmp, skel, n, iw, ih, mw, mh):
    fi = os.path.join(tmp, 'inr.bin'); fo = os.path.join(tmp, 'outr.bin')
    open(fi, 'wb').write(struct.pack('<5i', n, iw, ih, mw, mh) + np.asarray(skel, np.float32).tobytes())
    r = subprocess.run(['java', '-cp', f'{jar}:{KLIB}', 'DriverKt', fi, fo, 'region'], capture_output=True, text=True)
    if r.returncode != 0: return None
    d = np.fromfile(fo, dtype=np.float32)
    k = int(d[0])
    return None if k == 0 else (k, int(d[1]), int(d[2]), d[3:])

# ---------- khung xương mẫu ----------
def person(cx, cy, s, vis=True, aspect=1.0):
    """1 người đứng; s = chiều cao thân (chuẩn hoá theo cạnh Y). 18 khớp x (x,y,z,vis). aspect = imgH/imgW để giữ tỉ lệ pixel."""
    ax = aspect
    def J(dx, dy): return (cx + dx * s * ax, cy + dy * s)
    j = {0: J(0, -0.55), 1: J(0, -0.42), 2: J(-0.13, -0.40), 5: J(0.13, -0.40), 3: J(-0.20, -0.22), 6: J(0.20, -0.22),
         4: J(-0.22, -0.05), 7: J(0.22, -0.05), 8: J(-0.08, 0.0), 11: J(0.08, 0.0), 9: J(-0.09, 0.30), 12: J(0.09, 0.30),
         10: J(-0.09, 0.60), 13: J(0.09, 0.60), 14: J(-0.03, -0.58), 15: J(0.03, -0.58), 16: J(-0.07, -0.55), 17: J(0.07, -0.55)}
    out = []
    for i in range(18):
        x, y = j[i]
        out += [x, y, 0.0, 1.0 if vis else 0.0]
    return out

# ---------- tham chiếu numpy ----------
LINKS = [(2, 3, 0.14), (3, 4, 0.11), (5, 6, 0.14), (6, 7, 0.11), (8, 9, 0.17), (9, 10, 0.13), (11, 12, 0.17), (12, 13, 0.13),
         (1, 0, 0.10), (1, 2, 0.10), (1, 5, 0.10)]
def ref_build(sk, n, iw, ih, mw, mh):
    sk = np.asarray(sk, np.float64).reshape(-1, 18, 4)
    n = min(n, len(sk))
    persons = []
    for i in range(n):
        P = sk[i]; V = P[:, 3] > 0.5
        if not (V[2] and V[5] and V[8] and V[11]): continue
        px = lambda j: P[j, 0] * iw; py = lambda j: P[j, 1] * ih
        sw = np.hypot(px(2) - px(5), py(2) - py(5)); th = abs((py(8) + py(11)) / 2 - (py(2) + py(5)) / 2)
        size = (sw + th) / 2
        if size < 8: continue
        links = [(px(a), py(a), px(b), py(b), r * size) for a, b, r in LINKS if V[a] and V[b]]
        quad = [(px(2), py(2)), (px(5), py(5)), (px(11), py(11)), (px(8), py(8))]
        hid = [k for k in (0, 14, 15, 16, 17) if V[k]]
        head = (np.mean([px(k) for k in hid]), np.mean([py(k) for k in hid]), 0.34 * size) if hid else None
        persons.append((links, quad, head, 0.12 * size, size))
    if len(persons) < 2: return None
    ys, xs = np.mgrid[0:mh, 0:mw]
    X = (xs + 0.5) / mw * iw; Y = (ys + 0.5) / mh * ih
    def dseg(ax, ay, bx, by):
        dx, dy = bx - ax, by - ay; l2 = dx * dx + dy * dy
        t = np.zeros_like(X) if l2 <= 1e-9 else np.clip(((X - ax) * dx + (Y - ay) * dy) / l2, 0, 1)
        return np.hypot(X - (ax + t * dx), Y - (ay + t * dy))
    covs = []
    for links, quad, head, pad, size in persons:
        sd = np.full(X.shape, np.inf)
        for ax, ay, bx, by, r in links: sd = np.minimum(sd, dseg(ax, ay, bx, by) - r)
        inside = np.zeros(X.shape, bool); md = np.full(X.shape, np.inf); j = 3
        for i in range(4):
            xi, yi = quad[i]; xj, yj = quad[j]
            cond = ((yi > Y) != (yj > Y)) & (X < (xj - xi) * (Y - yi) / (yj - yi + 1e-12) + xi)
            inside ^= cond; md = np.minimum(md, dseg(xi, yi, xj, yj)); j = i
        sd = np.minimum(sd, np.where(inside, -md, md) - pad)
        if head is not None: sd = np.minimum(sd, np.hypot(X - head[0], Y - head[1]) - head[2])
        margin = max(size * 0.10, 1e-3)
        covs.append(np.where(sd <= 0, 1.0, np.maximum(0, 1 - sd / margin)))
    raw = np.zeros(X.shape)
    for i in range(len(covs)):
        for k in range(i + 1, len(covs)): raw = np.maximum(raw, covs[i] * covs[k])
    pad = np.pad(raw, 1); cnt = np.pad(np.ones_like(raw), 1)
    s = sum(pad[1 + dy:1 + dy + mh, 1 + dx:1 + dx + mw] for dy in (-1, 0, 1) for dx in (-1, 0, 1))
    c = sum(cnt[1 + dy:1 + dy + mh, 1 + dx:1 + dx + mw] for dy in (-1, 0, 1) for dx in (-1, 0, 1))
    out = np.clip(s / c, 0, 1)
    if out.max() < 0.25: return None
    return out.astype(np.float32)

def ref_region(sk, n, iw, ih, mw, mh, mf=0.35):
    """tham chiếu độc lập cho ContactMap.regionMasks: độ phủ mềm từng người, biên = mf * kích thước thân; thiếu khớp thân/đỉnh < 0.5 -> None."""
    sk = np.asarray(sk, np.float64).reshape(-1, 18, 4)
    if n < 2 or len(sk) < n: return None
    ys, xs = np.mgrid[0:mh, 0:mw]
    X = (xs + 0.5) / mw * iw; Y = (ys + 0.5) / mh * ih
    def dseg(ax, ay, bx, by):
        dx, dy = bx - ax, by - ay; l2 = dx * dx + dy * dy
        t = np.zeros_like(X) if l2 <= 1e-9 else np.clip(((X - ax) * dx + (Y - ay) * dy) / l2, 0, 1)
        return np.hypot(X - (ax + t * dx), Y - (ay + t * dy))
    outs = []
    for i in range(n):
        P = sk[i]; V = P[:, 3] > 0.5
        if not (V[2] and V[5] and V[8] and V[11]): return None
        px = lambda j: P[j, 0] * iw; py = lambda j: P[j, 1] * ih
        sw = np.hypot(px(2) - px(5), py(2) - py(5)); th = abs((py(8) + py(11)) / 2 - (py(2) + py(5)) / 2)
        size = (sw + th) / 2
        if size < 8: return None
        sd = np.full(X.shape, np.inf)
        for a, b, r in LINKS:
            if V[a] and V[b]: sd = np.minimum(sd, dseg(px(a), py(a), px(b), py(b)) - r * size)
        quad = [(px(2), py(2)), (px(5), py(5)), (px(11), py(11)), (px(8), py(8))]
        inside = np.zeros(X.shape, bool); md = np.full(X.shape, np.inf); j = 3
        for q in range(4):
            xi, yi = quad[q]; xj, yj = quad[j]
            inside ^= ((yi > Y) != (yj > Y)) & (X < (xj - xi) * (Y - yi) / (yj - yi + 1e-12) + xi)
            md = np.minimum(md, dseg(xi, yi, xj, yj)); j = q
        sd = np.minimum(sd, np.where(inside, -md, md) - 0.12 * size)
        hid = [k for k in (0, 14, 15, 16, 17) if V[k]]
        if hid: sd = np.minimum(sd, np.hypot(X - np.mean([px(k) for k in hid]), Y - np.mean([py(k) for k in hid])) - 0.34 * size)
        margin = max(size * mf, 1e-3)
        cov = np.where(sd <= 0, 1.0, np.maximum(0, 1 - sd / margin))
        if cov.max() < 0.5: return None
        outs.append(cov.astype(np.float32))
    return np.stack(outs)

def parse(d, mw, mh):
    if d is None or d.size < 3: return None, 0, 0
    if d[0] == 0: return None, 0, 0
    return d[3:3 + mw * mh].reshape(mh, mw), float(d[1]), float(d[2])

def suite(jar, tmp, quiet=False):
    bad = 0
    def chk(name, cond, detail=''):
        nonlocal bad
        if not cond: bad += 1
        if not quiet: check(name, cond, detail)
    mw = mh = 64
    # 1) hai người xa nhau
    far = person(0.2, 0.5, 0.5) + person(0.8, 0.5, 0.5)
    d, so, se = run_kt(jar, tmp, far, 2, 512, 512, mw, mh)
    m, _, _ = parse(d, mw, mh)
    chk('2 người xa nhau -> không có bản đồ (null, không bật OccCFG)', d is not None and m is None, se[-200:])
    # 2) ôm nhau: thân chồng lên nhau
    hug = person(0.45, 0.5, 0.5) + person(0.57, 0.5, 0.5)
    d, so, se = run_kt(jar, tmp, hug, 2, 512, 512, mw, mh)
    m, peak, area = parse(d, mw, mh)
    chk('ôm nhau -> có bản đồ, đỉnh >= 0.9', m is not None and peak >= 0.9, f'peak={peak}')
    if m is not None:
        ys, xs = np.nonzero(m > 0.5)
        cx = xs.mean() / mw if len(xs) else -1
        chk('trọng tâm vùng tiếp xúc nằm GIỮA hai người (x ≈ 0.51)', 0.46 < cx < 0.56, f'cx={cx}')
        chk('giá trị trong [0,1], hữu hạn', bool(np.all(np.isfinite(m)) and m.min() >= 0 and m.max() <= 1))
        chk('vùng tiếp xúc là một phần ảnh, không phủ hết (diện tích < 60%)', 0 < area < 0.6, f'area={area}')
    # 3) khớp tham chiếu numpy (nhiều cảnh, kể cả ảnh không vuông, thiếu khớp)
    scenes = []
    scenes.append(('ôm 512x512', hug, 2, 512, 512, 64, 64))
    scenes.append(('ôm hơi lệch hai độ cao', person(0.42, 0.45, 0.55) + person(0.58, 0.55, 0.45), 2, 512, 512, 64, 64))
    scenes.append(('sát nhau không chồng', person(0.38, 0.5, 0.5) + person(0.62, 0.5, 0.5), 2, 512, 512, 64, 64))
    scenes.append(('ảnh dọc 512x768', person(0.45, 0.5, 0.5, aspect=512 / 768) + person(0.58, 0.5, 0.5, aspect=512 / 768), 2, 512, 768, 64, 96))
    scenes.append(('ảnh ngang 768x512', person(0.45, 0.5, 0.5, aspect=768 / 512) + person(0.56, 0.5, 0.5, aspect=768 / 512), 2, 768, 512, 96, 64))
    t3 = person(0.30, 0.5, 0.45) + person(0.45, 0.5, 0.45) + person(0.60, 0.5, 0.45)
    scenes.append(('3 người chen nhau', t3, 3, 512, 512, 64, 64))
    worst = 0.0; cnt = 0
    for name, sk, n, iw, ih, w_, h_ in scenes:
        d, so, se = run_kt(jar, tmp, sk, n, iw, ih, w_, h_)
        m, _, _ = parse(d, w_, h_)
        ref = ref_build(sk, n, iw, ih, w_, h_)
        if (m is None) != (ref is None):
            chk(f'[{name}] null/không-null khớp tham chiếu', False, f'kt={m is None} ref={ref is None} {se[-200:]}'); continue
        if m is None: continue
        e = float(np.max(np.abs(m - ref))); worst = max(worst, e); cnt += 1
    chk(f'khớp tham chiếu numpy trên {cnt} cảnh (sai lệch lớn nhất < 2e-4)', worst < 2e-4 and cnt >= 4, f'worst={worst} cnt={cnt}')
    # 4) đối xứng gương
    mir = []
    for P in (person(0.45, 0.5, 0.5), person(0.60, 0.5, 0.5)):
        a = np.array(P, np.float32).reshape(18, 4).copy(); a[:, 0] = 1.0 - a[:, 0]
        # hoán khớp trái-phải để thân vẫn đúng bố cục
        sw = {2: 5, 5: 2, 3: 6, 6: 3, 4: 7, 7: 4, 8: 11, 11: 8, 9: 12, 12: 9, 10: 13, 13: 10, 14: 15, 15: 14, 16: 17, 17: 16}
        b = a.copy()
        for k, v in sw.items(): b[k] = a[v]
        mir += list(b.ravel())
    d1, _, _ = run_kt(jar, tmp, person(0.45, 0.5, 0.5) + person(0.60, 0.5, 0.5), 2, 512, 512, 64, 64)
    d2, _, _ = run_kt(jar, tmp, mir, 2, 512, 512, 64, 64)
    m1, _, _ = parse(d1, 64, 64); m2, _, _ = parse(d2, 64, 64)
    chk('đối xứng gương: lật cảnh -> bản đồ lật theo', m1 is not None and m2 is not None and float(np.max(np.abs(m1[:, ::-1] - m2))) < 2e-3,
        '' if m1 is None or m2 is None else str(float(np.max(np.abs(m1[:, ::-1] - m2)))))
    # 5) thiếu khớp thân -> bỏ người đó
    p2 = np.array(person(0.57, 0.5, 0.5), np.float32).reshape(18, 4); p2[8, 3] = 0.0
    d, so, se = run_kt(jar, tmp, hug[:72] + list(p2.ravel()), 2, 512, 512, 64, 64)
    m, _, _ = parse(d, 64, 64)
    chk('1 trong 2 người thiếu khớp hông -> chỉ còn 1 người dùng được -> null', d is not None and m is None, se[-200:])
    d, _, se = run_kt(jar, tmp, person(0.5, 0.5, 0.5), 1, 512, 512, 64, 64)
    chk('1 người -> null', d is not None and parse(d, 64, 64)[0] is None, se[-200:])
    d, _, se = run_kt(jar, tmp, hug, 5, 512, 512, 64, 64)
    chk('numPersons lớn hơn dữ liệu -> kẹp theo dữ liệu, không sập', d is not None and parse(d, 64, 64)[0] is not None, se[-200:])
    # 6) NaN trong toạ độ
    bad_sk = np.array(hug, np.float32).reshape(2, 18, 4).copy(); bad_sk[1, 3, 0] = np.nan
    d, _, se = run_kt(jar, tmp, list(bad_sk.ravel()), 2, 512, 512, 64, 64)
    m, _, _ = parse(d, 64, 64)
    chk('NaN ở 1 khớp -> không sập, đầu ra hữu hạn', d is not None and (m is None or bool(np.all(np.isfinite(m)))), se[-200:])
    # 6b) mục 261.11 — regionMasks (mask vùng từng người cho Regional Composite)
    rg = run_region(jar, tmp, hug, 2, 512, 512, 64, 64)
    ref = ref_region(hug, 2, 512, 512, 64, 64)
    chk('regionMasks (ôm nhau): có k=2, 64x64 và KHỚP numpy độc lập từng pixel (< 2e-4)',
        rg is not None and ref is not None and rg[0] == 2 and rg[1] == 64 and rg[2] == 64 and float(np.max(np.abs(rg[3].reshape(2, 64, 64) - ref))) < 2e-4,
        '' if rg is None or ref is None else str(float(np.max(np.abs(rg[3].reshape(2, 64, 64) - ref)))))
    if rg is not None:
        M = rg[3].reshape(2, 64, 64)
        cx = [float((M[i] * np.arange(64)[None, :]).sum() / M[i].sum()) / 64 for i in range(2)]
        chk('mask người 0 nằm BÊN TRÁI mask người 1 (đúng thứ tự khung xương), trọng tâm quanh 0.45 và 0.57', cx[0] < cx[1] and abs(cx[0] - 0.45) < 0.03 and abs(cx[1] - 0.57) < 0.03, str(cx))
        chk('mask trong [0,1], hữu hạn, đỉnh = 1 (trong thân)', bool(np.all(np.isfinite(M)) and M.min() >= 0 and M.max() <= 1 and abs(M.max() - 1.0) < 1e-6))
    far_rg = run_region(jar, tmp, far, 2, 512, 512, 64, 64)
    chk('hai người XA nhau vẫn dựng được mask vùng (khác contact map) và hai mask không chồng nhau', far_rg is not None and float((far_rg[3].reshape(2, 64, 64)[0] * far_rg[3].reshape(2, 64, 64)[1]).max()) < 1e-6)
    sw_sk = person(0.57, 0.5, 0.5) + person(0.45, 0.5, 0.5)
    sw_rg = run_region(jar, tmp, sw_sk, 2, 512, 512, 64, 64)
    if sw_rg is not None and rg is not None:
        chk('hoán thứ tự người trong khung xương thì hoán mask theo (mask i = người i)', np.allclose(sw_rg[3].reshape(2, 64, 64)[0], rg[3].reshape(2, 64, 64)[1], atol=1e-5) and np.allclose(sw_rg[3].reshape(2, 64, 64)[1], rg[3].reshape(2, 64, 64)[0], atol=1e-5))
    else:
        chk('hoán thứ tự chạy được', False)
    p2m = np.array(person(0.57, 0.5, 0.5), np.float32).reshape(18, 4); p2m[8, 3] = 0.0
    chk('một nhân vật thiếu khớp hông -> null (KHÔNG đoán mask, tránh gán sai LoRA)', run_region(jar, tmp, hug[:72] + list(p2m.ravel()), 2, 512, 512, 64, 64) is None)
    chk('numPersons = 1 -> null', run_region(jar, tmp, person(0.5, 0.5, 0.5), 1, 512, 512, 64, 64) is None)
    chk('numPersons = 3 nhưng khung xương chỉ có 2 người -> null (không bỏ sót người)', run_region(jar, tmp, hug, 3, 512, 512, 64, 64) is None)
    out_sk = person(0.45, 0.5, 0.5) + person(-1.4, 0.5, 0.5)
    chk('một người nằm hoàn toàn ngoài khung -> null (mask rỗng không dùng được)', run_region(jar, tmp, out_sk, 2, 512, 512, 64, 64) is None)
    # 7) gradedWeight + intensityAt
    d, so, se = run_kt(jar, tmp, hug, 2, 512, 512, 64, 64)
    mw_ = re.search(r'^W (.*)$', so, re.M)
    if mw_:
        w = [float(x) for x in mw_.group(1).split()]
        chk('gradedWeight(0,floor=.4)=.4; (1)=1; (.5)=.7; NaN->floor; floor>1 kẹp 1; floor<0 kẹp 0', np.allclose(w, [0.4, 1.0, 0.7, 0.4, 1.0, 0.7], atol=1e-6), str(w))
    else:
        chk('gradedWeight in được', False, so[-200:] + se[-200:])
    mi = re.search(r'^I (.*)$', so, re.M)
    if mi and m is not None or mi:
        v = [float(x) for x in mi.group(1).split()]
        chk('intensityAt: giữa 2 người cao, ngoài ảnh kẹp về biên (không sập)', v[0] > 0.5 and all(0 <= x <= 1 for x in v), str(v))
    return bad

tmp = tempfile.mkdtemp()
jar, r = compile_kt(SRC, tmp, 'real')
check('ContactMap.kt biên dịch bằng kotlinc thật', r.returncode == 0, r.stderr[-800:])
if r.returncode == 0:
    check('bộ kiểm trên mã THẬT: 0 lỗi', suite(jar, tmp) == 0)
    src = open(SRC, encoding='utf-8').read()
    mutants = [
        ('M = min thay vì tích độ phủ', 'val v = cov[i] * cov[j]', 'val v = min(cov[i], cov[j])'),
        ('bỏ làm mượt (chia c=1)', 'val v = (s / c).coerceIn(0f, 1f)', 'val v = raw[y * mapW + x]'),
        ('biên tiếp xúc gấp đôi', 'const val CONTACT_MARGIN = 0.10f', 'const val CONTACT_MARGIN = 0.20f'),
        ('đầu to gấp đôi', 'const val R_HEAD = 0.34f', 'const val R_HEAD = 0.68f'),
        ('lật y khi rasterize', 'val y = (my + 0.5f) / mapH * imgH', 'val y = (mapH - my - 0.5f) / mapH * imgH'),
        ('bỏ giữ capsule tròn (bỏ imgW)', 'fun px(j: Int) = data[base + j * 4] * imgW', 'fun px(j: Int) = data[base + j * 4] * imgH'),
        ('gradedWeight đảo', 'return f + (1f - f) * i', 'return f + (1f - f) * (1f - i)'),
        ('bỏ yêu cầu đủ 4 khớp thân', 'if (!torsoOk) return null', ''),
        ('bỏ ngưỡng MIN_PEAK', 'if (peak < Params.MIN_PEAK) return null', ''),
        ('regionMasks: biên mềm dùng CONTACT_MARGIN thay REGION_MARGIN', 'val mf = if (marginFactor.isFinite() && marginFactor > 0f) marginFactor else Params.REGION_MARGIN', 'val mf = Params.CONTACT_MARGIN'),
        ('regionMasks: bỏ qua người thiếu khớp thay vì trả null', 'if (c == null) return null', 'if (c == null) continue'),
        ('regionMasks: bỏ ngưỡng đỉnh mask', 'if ((c.maxOrNull() ?: 0f) < Params.MIN_REGION_PEAK) return null', ''),
        ('regionMasks: sai thứ tự (người i -> mask k-1-i)', 'System.arraycopy(c, 0, data, i * mapW * mapH, c.size)', 'System.arraycopy(c, 0, data, (numPersons - 1 - i) * mapW * mapH, c.size)'),
    ]
    caught = 0
    lo, hi = (int(x) for x in os.environ.get('MUT_RANGE', '0:999').split(':'))
    mutants_all = mutants
    mutants = [(n_, o_, w_) for k_, (n_, o_, w_) in enumerate(mutants_all) if lo <= k_ < hi]
    for name, old, new in mutants:
        if old not in src:
            check(f'đột biến "{name}": mẫu có trong mã', False, 'mẫu không còn khớp — cập nhật test'); continue
        tag = 'mut%d' % mutants_all.index((name, old, new)); mp = os.path.join(tmp, tag + '.kt')
        open(mp, 'w', encoding='utf-8').write(src.replace(old, new, 1))
        mjar, mr = compile_kt(mp, tmp, tag)
        if mr.returncode != 0:
            check(f'đột biến "{name}" phải BIÊN DỊCH được (nếu không thì "bị bắt" là vô nghĩa)', False, mr.stderr[-300:]); continue
        b = suite(mjar, tmp, quiet=True)
        check(f'đột biến "{name}" bị bộ kiểm bắt', b > 0); caught += b > 0
    check(f'thử phá mã: {caught}/{len(mutants)} đột biến bị bắt', caught == len(mutants))
shutil.rmtree(tmp, ignore_errors=True)
print('ALL OK' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
