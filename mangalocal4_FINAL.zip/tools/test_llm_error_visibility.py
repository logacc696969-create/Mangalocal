#!/usr/bin/env python3
"""mục 267 — canh các nhánh `catch` quanh lời gọi LLM: KHÔNG được nuốt lỗi âm thầm (hạng mục "rà catch nuốt lỗi LLM" đã treo từ mục 266.7).

Lý do: bậc API miễn phí hết hạn mức / khoá sai / mất mạng là chuyện thường; nếu `catch` chỉ trả giá trị dự phòng mà không để lại dấu vết thì chất lượng giảm mà không ai biết vì sao
(ví dụ trước mục 267: 4 nhánh dịch prompt cho bước upscale/inpaint lặng lẽ dùng lại prompt TXT2IMG của panel — chính là prompt SAI cho các bước đó, mục 93; và `planEmotionArc` nuốt lỗi
trong vòng lặp lô nên `catch` ngoài có `log` không bao giờ chạy, trong khi giao diện bảo "xem log" mà log trống).

Cách kiểm: bộ tách chuỗi/chú thích Kotlin (xử lý cả `${...}` lồng nhau) -> khớp ngoặc đáng tin -> với MỌI `try { ... } catch (...) { ... }` mà thân `try` có lời gọi LLM, thân `catch` phải có ít nhất một
trong: ghi log, báo lỗi lên UI, gọi hàm báo lỗi, hoặc ném lại. Thêm: CancellationException không được bị nuốt ở các nhánh dự phòng; thử phá mã (cài lại nhánh im lặng PHẢI bị bắt).
KHÔNG chứng minh: thông báo hiển thị đúng chỗ trên màn hình, hay bản thân việc rơi về dự phòng là hợp lý — chỉ chứng minh lỗi không biến mất không dấu vết.
Thuần Python (không cần kotlinc).
"""
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + d) if (d and not c) else '')); ok &= bool(c)

# ───────── bộ tách Kotlin ─────────
def mask(src):
    """Trả về chuỗi CÙNG ĐỘ DÀI: nội dung chú thích, chuỗi, ký tự được thay bằng dấu cách (giữ xuống dòng và dấu nháy bao quanh)."""
    n = len(src); out = list(src)
    def blank(a, b):
        for k in range(a, b):
            if out[k] != '\n': out[k] = ' '
    def skip_char(i):  # src[i] == "'"
        j = i + 1
        if j < n and src[j] == '\\':
            j += 2
            while j < n and src[j] != "'" and j - i < 10: j += 1
        else:
            j += 1
        return min(j + 1, n)
    def skip_code(i):  # sau '${' ; trả về chỉ số sau '}' khớp
        depth = 1
        while i < n:
            c = src[i]
            if c == '"': i = skip_string(i)
            elif c == "'": i = skip_char(i)
            elif c == '/' and src.startswith('//', i):
                while i < n and src[i] != '\n': i += 1
            elif c == '/' and src.startswith('/*', i):
                e = src.find('*/', i + 2); i = n if e < 0 else e + 2
            elif c == '{': depth += 1; i += 1
            elif c == '}':
                depth -= 1; i += 1
                if depth == 0: return i
            else: i += 1
        return n
    def skip_string(i):  # src[i] == '"'
        if src.startswith('"""', i):
            e = src.find('"""', i + 3)
            while e >= 0 and e + 3 < n and src[e + 3] == '"': e += 1   # """" ở cuối
            return n if e < 0 else e + 3
        i += 1
        while i < n:
            c = src[i]
            if c == '\\': i += 2
            elif c == '"': return i + 1
            elif src.startswith('${', i): i = skip_code(i + 2)
            else: i += 1
        return n
    i = 0
    while i < n:
        c = src[i]
        if c == '/' and src.startswith('//', i):
            j = i
            while j < n and src[j] != '\n': j += 1
            blank(i, j); i = j
        elif c == '/' and src.startswith('/*', i):
            depth = 1; j = i + 2
            while j < n and depth:
                if src.startswith('/*', j): depth += 1; j += 2
                elif src.startswith('*/', j): depth -= 1; j += 2
                else: j += 1
            blank(i, j); i = j
        elif c == '"':
            j = skip_string(i); blank(i + 1, j - 1); i = j
        elif c == "'":
            j = skip_char(i); blank(i + 1, j - 1); i = j
        else: i += 1
    return ''.join(out)

def match_brace(m, i):
    """m[i] == '{' -> chỉ số của '}' khớp (trên chuỗi đã mask)."""
    depth = 0
    for j in range(i, len(m)):
        if m[j] == '{': depth += 1
        elif m[j] == '}':
            depth -= 1
            if depth == 0: return j
    return -1

LLM_CALL = re.compile(r'(?<!VideoPrep)\.(?:translateStagePrompt|planEmotionArc|extractCharacterSummary|parseStory|buildPrompt|generateWithImageBlocking|testConnection)\s*\(|(?<![\w.])generate\s*\(|externalClient\.generate\s*\(')
HANDLED = re.compile(r'\blog\(|\bstagePromptFallback\(|\bonChunkError\(|\bthrow\b|_error\.value|_planMessage|\.error\b|\berror\s*=|\bemit\(|\bLog\.[wei]\(')

def find_try_catches(src):
    m = mask(src); res = []
    for t in re.finditer(r'\btry\s*\{', m):
        b = m.index('{', t.start()); e = match_brace(m, b)
        if e < 0: continue
        body_m = m[b:e + 1]
        pos = e + 1
        while True:
            c = re.match(r'\s*catch\s*\(([^)]*)\)\s*\{', m[pos:])
            if not c: break
            cb = pos + c.end() - 1; ce = match_brace(m, cb)
            if ce < 0: break
            res.append({'try_line': src.count('\n', 0, t.start()) + 1, 'catch_line': src.count('\n', 0, pos) + 1, 'param': c.group(1),
                        'try_masked': body_m, 'catch_masked': m[cb:ce + 1], 'catch_src': src[cb:ce + 1]})
            pos = ce + 1
    return res

def violations(src):
    bad = []
    for r in find_try_catches(src):
        if not LLM_CALL.search(r['try_masked']): continue
        if not HANDLED.search(r['catch_masked']):
            bad.append((r['catch_line'], r['catch_src'].strip().replace('\n', ' ')[:90]))
    return bad

def count_sites(src):
    return sum(1 for r in find_try_catches(src) if LLM_CALL.search(r['try_masked']))

FILES = ['pipeline/MangaPipeline.kt', 'pipeline/LLMParser.kt', 'pipeline/ExternalLlmClient.kt', 'pipeline/VisionJudge.kt', 'pipeline/PersonCountArbiter.kt', 'ui/MainViewModel.kt']
SRC = {f: open(os.path.join(KT, f), encoding='utf-8').read() for f in FILES}

# ───────── 0. bộ tách tự kiểm (nếu nó sai thì mọi kết luận sau vô nghĩa) ─────────
t = 'val a = "x { y"; // } ngoặc trong chú thích\nval b = "${if (z) "}" else "{"}"; val c = \'{\'\ntry { gen("a") } catch (e: Exception) { }\n'
mt = mask(t)
tc = find_try_catches(t)
check('bộ tách: ngoặc trong chuỗi, chuỗi lồng trong ${}, chú thích, ký tự đều không làm lệch cặp ngoặc', len(tc) == 1 and tc[0]['try_masked'].replace(' ', '') == '{gen("")}' and tc[0]['param'] == 'e: Exception', str([x['try_masked'] for x in tc]))
check('bộ tách: giữ nguyên độ dài và số dòng', len(mt) == len(t) and mt.count('\n') == t.count('\n'))
fx = 'fun f() {\n  try { x.translateStagePrompt(1) } catch (e: Exception) { r }\n  try { x.translateStagePrompt(1) } catch (e: Exception) { log("lỗi ${e.message}"); r }\n  try { 5 } catch (e: Exception) { r }\n  try { generate(p) } catch (e: Exception) {\n    if (e is java.util.concurrent.CancellationException) throw e\n    ""\n  }\n}\n'
v = violations(fx)
check('bộ tách: bắt đúng nhánh im lặng (dòng 2), bỏ qua nhánh có log, nhánh không gọi LLM, nhánh có throw', [x[0] for x in v] == [2], str(v))

# ───────── 1. mã thật: không còn nhánh im lặng ─────────
tot = 0
for f in FILES:
    v = violations(SRC[f]); tot += count_sites(SRC[f])
    check(f'{f}: mọi try/catch quanh lời gọi LLM đều để lại dấu vết (log/báo lỗi/ném lại)', not v, str(v))
check('đã quét được các điểm gọi LLM thật (không phải quét rỗng)', tot >= 14, f'chỉ thấy {tot} điểm')

# ───────── 2. nối dây cụ thể của mục 267 ─────────
mp = SRC['pipeline/MangaPipeline.kt']; lp = SRC['pipeline/LLMParser.kt']
check('MangaPipeline có hàm stagePromptFallback, có log mức WARN và ném lại CancellationException', re.search(r'private fun stagePromptFallback\(stage: String, ex: Exception\) \{\s*if \(ex is java\.util\.concurrent\.CancellationException\) throw ex\s*log\([^\n]*LogLevel\.WARN\)', mp) is not None)
check('đúng 4 nơi dịch prompt theo giai đoạn gọi stagePromptFallback (2 upscale-vẽ-lại, 2 sửa lỗi inpaint)', len(re.findall(r'stagePromptFallback\("upscale-vẽ-lại", ex\)', mp)) == 2 and len(re.findall(r'stagePromptFallback\("sửa lỗi \(inpaint\)", ex\)', mp)) == 2)
check('không còn `catch (ex: Exception) { ...panel.prompt to ...negativePrompt }` trần', not re.search(r'catch \(ex: Exception\) \{\s*(r\.)?panel\.prompt to', mp))
check('LLMParser.planEmotionArc nhận onChunkError, gọi nó khi lô lỗi và ném lại CancellationException', re.search(r'onChunkError: \(Exception\) -> Unit = \{\}', lp) is not None and re.search(r'catch \(e: Exception\) \{\s*if \(e is java\.util\.concurrent\.CancellationException\) throw e\s*onChunkError\(e\)', lp) is not None)
check('MangaPipeline.planEmotionArc truyền onChunkError và ghi log mức WARN', re.search(r'parser\.planEmotionArc\(arc, onChunkError = \{ ex ->\s*log\([^\n]*LogLevel\.WARN\)', mp) is not None)

# ───────── 3. thử phá mã: cài lại từng nhánh im lặng PHẢI bị bắt ─────────
muts = [
    ('planEmotionArc: nuốt lô lỗi như cũ', 'lp', 'catch (e: Exception) {\n                    if (e is java.util.concurrent.CancellationException) throw e\n                    onChunkError(e); ""\n                }', 'catch (e: Exception) { "" }'),
    ('upscale-vẽ-lại (panel r): im lặng', 'mp', 'catch (ex: Exception) { stagePromptFallback("upscale-vẽ-lại", ex); r.panel.prompt to r.panel.negativePrompt }', 'catch (ex: Exception) { r.panel.prompt to r.panel.negativePrompt }'),
    ('inpaint (panel r): im lặng', 'mp', 'catch (ex: Exception) { stagePromptFallback("sửa lỗi (inpaint)", ex); r.panel.prompt to r.panel.negativePrompt }', 'catch (ex: Exception) { r.panel.prompt to r.panel.negativePrompt }'),
    ('upscale-vẽ-lại (panel): im lặng', 'mp', 'catch (ex: Exception) { stagePromptFallback("upscale-vẽ-lại", ex); panel.prompt to panel.negativePrompt }', 'catch (ex: Exception) { panel.prompt to panel.negativePrompt }'),
    ('inpaint (panel): im lặng', 'mp', 'catch (ex: Exception) { stagePromptFallback("sửa lỗi (inpaint)", ex); panel.prompt to panel.negativePrompt }', 'catch (ex: Exception) { panel.prompt to panel.negativePrompt }'),
    ('nhánh đã có log từ trước (dịch rách vải): bỏ log thì bị bắt', 'mp', 'log("  ⚠ Dịch mô tả rách vải lỗi (${e.message}) — bỏ qua phần này cho vùng này")', '/* im lặng */'),
]
for name, which, a, b in muts:
    s = mp if which == 'mp' else lp
    f = 'pipeline/MangaPipeline.kt' if which == 'mp' else 'pipeline/LLMParser.kt'
    if a not in s:
        check(f'đột biến "{name}": mẫu có trong mã', False, 'không thấy mẫu — mã đã đổi, cập nhật test'); continue
    mut = s.replace(a, b, 1)
    check(f'thử phá mã: "{name}" bị bắt', len(violations(mut)) > 0)

print('\nKẾT QUẢ:', 'ĐẠT' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
