#!/usr/bin/env python3
"""mục 284 — kiểm PoseRetargeter: BỀ NGANG vai/hông theo tuổi (BoneProportions.widthRatio). Trước mục này PoseRetargeter KHÔNG có test nào.
Biên dịch PoseRetargeter.kt + PoseInverseKinematics.kt + Models.kt + AgeBodyTable.kt THẬT bằng kotlinc (stub tối thiểu cho StoryManager.PoseKeypoint/PoseVariant), kiểm bằng đáp án hình học
độc lập, có phép PHÁ MÃ trên PoseRetargeter.kt. Cần kotlinc 1.9.x và Gson (GSON_JAR) — thiếu thì BỎ QUA nói rõ lý do. Đặt MUT_RANGE=0:0 để bỏ đột biến cho nhanh."""
import os, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); TD = os.path.join(ROOT, 'tools/kotlin_tests')
K = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
RET, IK, MOD, TBL = (os.path.join(K, p) for p in ('pipeline/PoseRetargeter.kt', 'pipeline/PoseInverseKinematics.kt', 'model/Models.kt', 'model/AgeBodyTable.kt'))
def find(env, names):
    for c in [os.environ.get(env)] + [shutil.which(n) for n in names]:
        if c and os.path.exists(c): return c
kc = find('KOTLINC', ['kotlinc']) or ('/home/claude/tools/kotlinc/bin/kotlinc' if os.path.exists('/home/claude/tools/kotlinc/bin/kotlinc') else None)
gs = find('GSON_JAR', []) or ('/home/claude/tools/gson-2.10.1.jar' if os.path.exists('/home/claude/tools/gson-2.10.1.jar') else None)
if not kc or not gs: print('BỎ QUA: cần kotlinc 1.9.x (KOTLINC) và Gson (GSON_JAR). Test này kiểm PoseRetargeter bằng kotlinc thật.'); sys.exit(0)
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)
def run(ret=RET, tbl=TBL, mod=MOD):
    with tempfile.TemporaryDirectory() as td:
        jar = os.path.join(td, 't.jar')
        r = subprocess.run([kc, '-nowarn', '-cp', gs, os.path.join(TD, 'StubStoryManagerVariant.kt'), os.path.join(TD, 'RetargetWidthTest.kt'), ret, IK, mod, tbl, '-include-runtime', '-d', jar], capture_output=True, text=True)
        if r.returncode != 0: return None, r.stderr[-1500:]
        o = subprocess.run(['java', '-Dstdout.encoding=UTF-8', '-cp', jar + os.pathsep + gs, 'RetargetWidthTestKt'], capture_output=True, text=True)
        return o.stdout, o.stderr
out, err = run()
check(out is not None, 'biên dịch PoseRetargeter + IK + Models + AgeBodyTable + test bằng kotlinc' + ('' if out is not None else '\n' + str(err)))
if out is not None:
    n = sum(1 for l in out.splitlines() if l.startswith('PASS')); bad = [l for l in out.splitlines() if l.startswith('FAIL')]
    for l in bad: print(l)
    check(not bad and n >= 50, f'mã Kotlin thật: {n} phép kiểm đạt, {len(bad)} lỗi')
src = open(RET, encoding='utf-8').read()
muts = [
 ('vai: bỏ hệ số k', 'newNeck.x + shoulderOffsetX * k, y = newNeck.y + shoulderOffsetY * k', 'newNeck.x + shoulderOffsetX, y = newNeck.y + shoulderOffsetY'),
 ('vai: chỉ nhân x', 'y = newNeck.y + shoulderOffsetY * k', 'y = newNeck.y + shoulderOffsetY'),
 ('hông: không dời', 'if (kHip != 1f) out[hipIdx] = hip', ''),
 ('hông: chỉ nhân x', 'y = hipCenter.y + (origHip.y - hipCenter.y) * kHip)', 'y = origHip.y)'),
 ('hông: dùng hệ số của vai (mục 285)', 'val kHip = hipScale(source, target)', 'val kHip = k'),
 ('hông: hệ số đảo (mục 285)', 'safeWidth(target.hipRatio()) / safeWidth(source.hipRatio())', 'safeWidth(source.hipRatio()) / safeWidth(target.hipRatio())'),
 ('hông: bỏ hipRatio, dùng widthRatio (mục 285)', 'safeWidth(target.hipRatio()) / safeWidth(source.hipRatio())', 'safeWidth(target.widthRatio) / safeWidth(source.widthRatio)'),
 ('xương đùi: góc tính từ hông MỚI', 'val origAngle = angle(origHip, knee)\n                val newLen = dist(origHip, knee)', 'val origAngle = angle(hip, knee)\n                val newLen = dist(origHip, knee)'),
 ('xương đùi: độ dài tính từ hông MỚI', 'val newLen = dist(origHip, knee) * (target.upperLegRatio / source.upperLegRatio)', 'val newLen = dist(hip, knee) * (target.upperLegRatio / source.upperLegRatio)'),
 ('hệ số đảo (nguồn/đích)', 'safeWidth(target.widthRatio) / safeWidth(source.widthRatio)', 'safeWidth(source.widthRatio) / safeWidth(target.widthRatio)'),
 ('chấp nhận hệ số ≤ 0', 'if (r > 0f && r.isFinite()) r else 1f', 'r'),
 ('không loại NaN/∞', 'if (r > 0f && r.isFinite()) r else 1f', 'if (r > 0f) r else 1f'),
]
lo, hi = (int(x) for x in os.environ.get('MUT_RANGE', '0:999').split(':'))
sel = muts[lo:hi]; caught = 0
for name, old, new in sel:
    if old not in src: print('  ?? không tìm thấy mẫu:', name); continue
    with tempfile.TemporaryDirectory() as td:
        mp = os.path.join(td, 'PoseRetargeter.kt'); open(mp, 'w', encoding='utf-8').write(src.replace(old, new, 1))
        o, e = run(ret=mp); bad = o is None or any(l.startswith('FAIL') for l in o.splitlines())
    caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name)
if sel: check(caught == len(sel), f'phá mã: {caught}/{len(sel)} đột biến trên PoseRetargeter.kt bị bắt')
else: print('(bỏ qua đột biến — MUT_RANGE)')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
