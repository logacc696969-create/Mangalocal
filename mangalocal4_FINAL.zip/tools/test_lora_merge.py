#!/usr/bin/env python3
"""mục 259 — kiểm thử `sd_engine/LoraMerge.hpp` (gộp LoRA kiểu TIES/DARE) bằng C++ THẬT.

Biên dịch một chương trình thử nhỏ với g++ (-Wall -Wextra -Werror, ASan + UBSan), chạy trên dữ liệu ngẫu nhiên và so từng phần tử với bản
THAM CHIẾU numpy viết độc lập từ định nghĩa TIES. Ngoài ra kiểm ca tay (đáp án tính bằng tay), tính chất thống kê của DARE, tính tất định,
đầu vào hỏng (kích thước lệch, rỗng, NaN) và nối dây vào applyLoRA/JNI/Kotlin.
KHÔNG chứng minh: chất lượng ảnh khi gộp LoRA nhân vật bằng TIES (chưa đo); chỉ chứng minh phép gộp đúng như định nghĩa.
"""
import os, re, struct, subprocess, sys, tempfile
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JNI = os.path.join(ROOT, 'app/src/main/jni')
ok = True
def check(name, cond, detail=''):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + detail) if (detail and not cond) else ''))
    ok &= bool(cond)

TEST_CPP = r'''
#include "LoraMerge.hpp"
#include <cstdio>
#include <cstdlib>
#include <string>
// dùng: lora_test <cmd> <in> <out> [density dare lambda seed]
// cmd=ties : in = int32 N, int32 n, N*n float32 ; out = n float32 (kết quả tiesMerge)
// cmd=trim : in = int32 n, float32*n ; out = n float32 (sau trimTopK với density)
// cmd=dare : in = int32 n, float32*n ; out = n float32 (sau dareDrop với p = dare, seed)
int main(int argc, char **argv) {
  if (argc < 4) return 2;
  std::string cmd = argv[1];
  float density = argc > 4 ? std::strtof(argv[4], nullptr) : 1.0f;
  float dare = argc > 5 ? std::strtof(argv[5], nullptr) : 0.0f;
  float lambda = argc > 6 ? std::strtof(argv[6], nullptr) : 1.0f;
  unsigned long long seed = argc > 7 ? std::strtoull(argv[7], nullptr, 10) : 0ULL;
  FILE *f = std::fopen(argv[2], "rb"); if (!f) return 3;
  std::vector<float> out;
  if (cmd == "ties") {
    int N = 0, n = 0;
    if (std::fread(&N, 4, 1, f) != 1 || std::fread(&n, 4, 1, f) != 1) return 4;
    std::vector<std::vector<float>> ds(N);
    for (int t = 0; t < N; ++t) { ds[t].resize(n); if (n && std::fread(ds[t].data(), 4, n, f) != (size_t)n) return 5; }
    lora_merge::Options o; o.mode = lora_merge::TIES; o.density = density; o.dare_drop = dare; o.lambda = lambda;
    out = lora_merge::tiesMerge(std::move(ds), o, seed);
  } else {
    int n = 0; if (std::fread(&n, 4, 1, f) != 1) return 4;
    std::vector<float> d(n); if (n && std::fread(d.data(), 4, n, f) != (size_t)n) return 5;
    if (cmd == "trim") lora_merge::trimTopK(d, density); else lora_merge::dareDrop(d, dare, seed);
    out = d;
  }
  std::fclose(f);
  FILE *g = std::fopen(argv[3], "wb"); if (!g) return 6;
  if (!out.empty()) std::fwrite(out.data(), 4, out.size(), g);
  std::fclose(g);
  return 0;
}
'''

tmp = tempfile.mkdtemp()
src = os.path.join(tmp, 'lora_test.cpp'); exe = os.path.join(tmp, 'lora_test')
open(src, 'w').write(TEST_CPP)
cc = subprocess.run(['g++', '-std=c++17', '-O1', '-g', '-Wall', '-Wextra', '-Werror', '-fsanitize=address,undefined', '-fno-sanitize-recover=all',
                     '-I', os.path.join(JNI, 'sd_engine'), src, '-o', exe], capture_output=True, text=True)
check('LoraMerge.hpp biên dịch sạch (-Wall -Wextra -Werror, ASan+UBSan)', cc.returncode == 0, cc.stderr[:600])
if cc.returncode != 0:
    print('\nKẾT QUẢ: CÓ LỖI'); sys.exit(1)

def run(cmd, arrays, density=1.0, dare=0.0, lam=1.0, seed=0):
    fin = os.path.join(tmp, 'in.bin'); fout = os.path.join(tmp, 'out.bin')
    with open(fin, 'wb') as f:
        if cmd == 'ties':
            N = len(arrays); n = len(arrays[0]) if N else 0
            f.write(struct.pack('ii', N, n))
            for a in arrays: f.write(np.asarray(a, dtype=np.float32).tobytes())
        else:
            a = np.asarray(arrays, dtype=np.float32); f.write(struct.pack('i', len(a))); f.write(a.tobytes())
    if os.path.exists(fout): os.remove(fout)
    p = subprocess.run([exe, cmd, fin, fout, repr(float(density)), repr(float(dare)), repr(float(lam)), str(seed)], capture_output=True, text=True)
    if p.returncode != 0: raise RuntimeError(f'{cmd} rc={p.returncode} {p.stderr[:300]}')
    return np.fromfile(fout, dtype=np.float32)

# ---------- bản tham chiếu numpy (độc lập, theo định nghĩa) ----------
def ref_trim(d, density):
    d = d.copy(); n = d.size
    if n == 0 or not (density < 1.0): return d
    if not (density > 0.0): return np.zeros_like(d)
    k = int(np.ceil(np.float32(density).astype(np.float64) * n - 1e-7 * n))  # quy ước đặc tả: k = ceil(density·n) có dung sai biểu diễn float32
    if k >= n: return d
    k = max(k, 1)
    thr = np.sort(np.abs(d))[n - k]
    d[np.abs(d) < thr] = 0.0
    return d
def ref_ties(deltas, density, lam):
    if len(deltas) == 1: return deltas[0].copy()
    ds = [ref_trim(d.astype(np.float32), density) for d in deltas]
    S = np.sum(ds, axis=0, dtype=np.float32)
    out = np.zeros_like(S)
    sgn = np.sign(S)
    acc = np.zeros_like(S); cnt = np.zeros_like(S)
    for d in ds:
        agree = (np.sign(d) == sgn) & (d != 0) & (sgn != 0)
        acc += np.where(agree, d, 0.0); cnt += agree
    nz = cnt > 0
    out[nz] = lam * acc[nz] / cnt[nz]
    return out

rng = np.random.default_rng(1234)
# 1. so khớp với tham chiếu trên dữ liệu ngẫu nhiên
worst = 0.0; cases = 0
for N in (2, 3, 4):
    for density in (1.0, 0.5, 0.2, 0.05):
        for lam in (1.0, 1.7):
            deltas = [rng.normal(0, 0.05, 1500).astype(np.float32) for _ in range(N)]
            got = run('ties', deltas, density=density, lam=lam)
            exp = ref_ties(deltas, density, lam)
            worst = max(worst, float(np.max(np.abs(got - exp)))); cases += 1
check(f'TIES khớp bản tham chiếu numpy trên {cases} cấu hình (N=2..4, density 1..0.05, lambda 1/1.7), sai lệch lớn nhất {worst:.2e}', worst < 1e-6)

# 2. ca tay: đáp án tính bằng tay
r = run('ties', [[3.0], [1.0]]);   check('cùng dấu 3 và 1 -> trung bình 2', r[0] == 2.0)
r = run('ties', [[3.0], [-1.0]]);  check('ngược dấu 3 và -1 -> dấu thắng + (tổng 2>0), chỉ lấy 3 (không phải 1 như phép cộng)', r[0] == 3.0)
r = run('ties', [[-3.0], [1.0]]);  check('ngược dấu -3 và 1 -> dấu thắng -, chỉ lấy -3', r[0] == -3.0)
r = run('ties', [[2.0], [-2.0]]);  check('triệt tiêu đúng 2 và -2 -> tổng 0, dấu không xác định -> 0', r[0] == 0.0)
r = run('ties', [[0.0], [4.0]]);   check('một delta bằng 0, một bằng 4 -> 4 (trung bình RỜI chỉ tính phần tử khác 0, không chia đôi)', r[0] == 4.0)
r = run('ties', [[1, 2, 3], [4, 5, 6], [-1, -2, -3]]); check('3 delta: [1,4,-1] -> tổng 4>0 -> (1+4)/2=2.5; [2,5,-2] -> 3.5; [3,6,-3] -> 4.5', np.allclose(r, [2.5, 3.5, 4.5]))
r = run('ties', [[1.0], [3.0]], lam=1.5); check('lambda nhân kết quả: mean(1,3)=2 -> 3.0', r[0] == 3.0)

# 3. trim
d = [1, -5, 3, 2, -4]
check('trim density 0.4 (k=2): giữ -5 và -4', np.array_equal(run('trim', d, density=0.4), [0, -5, 0, 0, -4]))
check('trim density 0.5 (k=ceil(2.5)=3): giữ -5, -4, 3', np.array_equal(run('trim', d, density=0.5), [0, -5, 3, 0, -4]))
check('trim density 0.01 (k=1): chỉ giữ phần tử lớn nhất', np.array_equal(run('trim', d, density=0.01), [0, -5, 0, 0, 0]))
check('trim density 0 -> toàn 0', not run('trim', d, density=0.0).any())
check('trim density 1 và >1 -> không đổi', np.array_equal(run('trim', d, density=1.0), d) and np.array_equal(run('trim', d, density=3.0), d))
check('trim density NaN -> không đổi (không phá dữ liệu)', np.array_equal(run('trim', d, density=float('nan')), d))
check('trim mảng toàn bằng nhau (hoà): không crash, giữ nguyên', np.array_equal(run('trim', [2, 2, 2, 2], density=0.5), [2, 2, 2, 2]))
big = rng.normal(0, 1, 20000).astype(np.float32)
t = run('trim', big, density=0.2); kept = int((t != 0).sum())
check('trim 20000 phần tử density 0.2: giữ đúng ~4000 phần tử lớn nhất, phần giữ không bị đổi giá trị', abs(kept - 4000) <= 2 and np.array_equal(t[t != 0], big[t != 0]) and np.abs(t[t != 0]).min() >= np.abs(big[t == 0]).max())

# 4. một delta: trả nguyên, kể cả khi density/dare được bật
one = rng.normal(0, 1, 500).astype(np.float32)
check('1 delta -> trả NGUYÊN (không trim/DARE: không có xung đột để giải)', np.array_equal(run('ties', [one], density=0.1, dare=0.5, lam=3.0), one))

# 5. DARE
ones = np.ones(100000, dtype=np.float32)
a = run('dare', ones, dare=0.5, seed=7); frac = float((a == 0).mean())
check('DARE p=0.5: ~50% bị bỏ, phần giữ nhân đúng 1/(1-p)=2', abs(frac - 0.5) < 0.01 and set(np.unique(a).tolist()) <= {0.0, 2.0})
check('DARE tất định: cùng seed -> y hệt; khác seed -> khác', np.array_equal(a, run('dare', ones, dare=0.5, seed=7)) and not np.array_equal(a, run('dare', ones, dare=0.5, seed=8)))
check('DARE kỳ vọng được bảo toàn: trung bình ≈ 1', abs(float(a.mean()) - 1.0) < 0.02)
check('DARE p=0 và p=NaN -> không đổi', np.array_equal(run('dare', ones, dare=0.0), ones) and np.array_equal(run('dare', ones, dare=float('nan')), ones))
c = run('dare', ones, dare=5.0, seed=3)
nzc = c[c != 0]
check('DARE p>=1 bị kẹp 0.99 (không chia 0): phần giữ nhân ≈100, hữu hạn', np.isfinite(c).all() and nzc.size > 0 and np.allclose(nzc, 100.0, rtol=1e-3) and abs((c == 0).mean() - 0.99) < 0.01)
p1 = run('ties', [ones[:5000], ones[:5000] * 2], dare=0.5, seed=11); p2 = run('ties', [ones[:5000], ones[:5000] * 2], dare=0.5, seed=11)
check('TIES+DARE tất định theo seed', np.array_equal(p1, p2))

# 6. đầu vào bất thường
check('0 delta -> rỗng, không crash', run('ties', []).size == 0)
check('N delta rỗng (n=0) -> rỗng, không crash', run('ties', [[], []]).size == 0)
check('NaN trong delta không làm crash (ASan/UBSan sạch)', run('ties', [[float('nan'), 1.0], [2.0, 3.0]]).size == 2)

# 7. TIES giảm nhiễu so với cộng thẳng ở phần tử xung đột
x = np.array([5.0, 5.0, 5.0], dtype=np.float32); y = np.array([-1.0, -1.0, -1.0], dtype=np.float32)
check('xung đột: cộng thẳng 5-1=4 lệch khỏi 5 của delta mạnh; TIES giữ đúng 5', np.allclose(x + y, 4.0) and np.allclose(run('ties', [x, y]), 5.0))

# ---------- nối dây (đọc mã nguồn) ----------
ST = open(os.path.join(JNI, 'sd_engine/SafeTensor2MNN.hpp'), encoding='utf-8').read()
check('SafeTensor2MNN.hpp include LoraMerge.hpp', '#include "LoraMerge.hpp"' in ST)
check('applyLoRA nhận merge_opts và chỉ bật TIES khi mode==TIES và có >=2 LoRA',
      'const lora_merge::Options &merge_opts' in ST and 'merge_opts.mode == lora_merge::TIES' in ST and 'lora_readers.size() >= 2' in ST)
check('applyLoRA: đường TIES gom delta rồi gộp MỘT lần bằng tiesMerge, seed ổn định theo tên trọng số',
      'ties_deltas.emplace_back(' in ST and 'lora_merge::tiesMerge(' in ST and 'std::hash<std::string>{}(weight_name)' in ST)
check('applyLoRA: đường mặc định (cộng/trực giao) GIỮ NGUYÊN — vẫn có `original_tensor += lora_delta;`', 'original_tensor += lora_delta;' in ST and 'ortho_basis.push_back(lora_delta);' in ST)
n_pass = len(re.findall(r'lora_weights,\s*orthogonal_lora,\s*merge_opts\)', ST))
check('merge_opts được truyền qua MỌI lời gọi applyLoRA/generateModel/generateClipModel (>=7 chỗ)', n_pass >= 7, str(n_pass))
check('generateModel/generateClipModel/generateMNNModels đều có tham số merge_opts mặc định (không phá lời gọi cũ)',
      len(re.findall(r'const lora_merge::Options &merge_opts = lora_merge::Options\(\)', ST)) >= 4, str(len(re.findall(r'merge_opts = lora_merge::Options\(\)', ST))))
JN = open(os.path.join(JNI, 'sd_model_converter.cpp'), encoding='utf-8', errors='replace').read()
check('JNI sd_model_converter.cpp: nhận jMergeMode/jTiesDensity/jDareDrop và dựng Options, kẹp giá trị',
      'jint jMergeMode' in JN and 'jfloat jTiesDensity' in JN and 'jfloat jDareDrop' in JN and 'lora_merge::Options' in JN and 'merge_opts' in JN)
NB = open(os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline/NativeBridge.kt'), encoding='utf-8').read()
_d0 = NB.index('external fun sdConvertModel(')
_decl = NB[_d0:NB.index('): Boolean', _d0) + len('): Boolean')]
_decl = re.sub(r'//[^\n]*', '', _decl)  # bỏ chú thích (trong chú thích có dấu ngoặc làm hỏng regex đơn giản)
check('Kotlin NativeBridge.sdConvertModel: thêm mergeMode/tiesDensity/dareDrop có mặc định, đúng thứ tự sau orthogonalLora (lời gọi cũ vẫn biên dịch)',
      re.search(r'orthogonalLora: Boolean = false,\s*mergeMode: Int = 0,\s*tiesDensity: Float = 0\.5f,\s*dareDrop: Float = 0f\)', _decl) is not None)
_jn = re.search(r'jboolean jOrthogonalLora,\s*jint jMergeMode, jfloat jTiesDensity, jfloat jDareDrop\)', JN)
check('JNI và Kotlin khớp thứ tự/kiểu: (…, Boolean orthogonal, Int mergeMode, Float density, Float dare) <-> (jboolean, jint, jfloat, jfloat)', _jn is not None)
check('JNI kẹp giá trị lạ: mode lạ -> SUM, mật độ [0.05,1], độ bỏ [0,0.95], NaN -> mặc định',
      'jMergeMode == lora_merge::TIES' in JN and 'std::max(0.05f' in JN and 'std::min(0.95f' in JN and 'jTiesDensity == jTiesDensity' in JN)

print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
