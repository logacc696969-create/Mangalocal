#!/usr/bin/env python3
"""mục 269 — KIỂM CHỨNG TOÀN CHUỖI LoRA-ghép-lúc-suy-luận trên FILE THẬT (không mô phỏng): UNet diffusers thu nhỏ -> torch.onnx.export (TorchScript, opset 17, đúng tham số script của MNN) ->
`mnnconvert` THẬT -> `lora_attach_branch --list` THẬT -> LoRA kiểu kohya dựng từ TÊN MODULE TORCH -> tools/lora_to_mnn_spec.py -> `lora_attach_branch` -> chạy bằng MNN THẬT và so SỐ HỌC với torch
(nền so với nền; nền + nhánh LoRA so với torch đã cộng thẳng W + scale*B@A vào trọng số).

Kết quả đã đo (mục 269, torch 2.5.1 CPU, diffusers 0.31, MNN 3.6.1): nền vs torch 5,6e-5; nền+LoRA vs torch-gộp 6,7e-5; LoRA làm đầu ra đổi 1,83 (nên phép thử đủ nhạy). 82/83 module khớp tự động,
conv cuối `out_sample` cần --map (MNN đổi tên op cuối thành tên đầu ra của đồ thị).

KHÔNG phải test mặc định (nặng: cần torch+diffusers+MNN python+g++, ~1–2 phút). Dựng môi trường (không cần GPU; conda-forge cho torch CPU vì bản PyPI là bản CUDA):
    micromamba create -n t -c conda-forge python=3.12 "pytorch=2.5.1=cpu_generic*" "numpy<2" onnx=1.17 diffusers=0.31 safetensors && pip install MNN==3.6.1
    MNN_SRC=/đường/dẫn/MNN-3.6.1 python3 tools/real_unet_lora_check.py        # MNN_SRC: mã nguồn MNN (cần include/, schema/current/, 3rd_party/flatbuffers/include/)
KHÔNG chứng minh: UNet SD1.5 THẬT kích thước đầy đủ (tên op của bản do bên thứ ba chuyển đổi có thể khác — chạy `--list` trên file đó), NPU/QNN, tốc độ/RAM trên máy, và việc nối vào
PipelineSd15Cpu (264.3 c–d). Mã thoát: 0 = đạt; 1 = sai số/ánh xạ không đạt; 2 = thiếu môi trường.
"""
import json, os, shutil, struct, subprocess, sys, tempfile, warnings
warnings.filterwarnings('ignore')
HERE = os.path.dirname(os.path.abspath(__file__))
TOL_BASE, TOL_LORA, MIN_EFFECT = 5e-4, 5e-4, 0.05


def need_env():
    miss = []
    for m in ('torch', 'diffusers', 'onnx', 'numpy', 'MNN'):
        try: __import__(m)
        except Exception as e: miss.append(f'{m} ({type(e).__name__})')
    src = os.environ.get('MNN_SRC', '')
    for sub in ('include', 'schema/current', '3rd_party/flatbuffers/include'):
        if not os.path.isdir(os.path.join(src, sub)): miss.append(f'MNN_SRC/{sub}')
    mc = shutil.which('mnnconvert') or os.path.join(os.path.dirname(sys.executable), 'mnnconvert')
    if not os.path.exists(mc): miss.append('mnnconvert')
    if not shutil.which('g++'): miss.append('g++')
    return miss, src, mc


def write_st(path, tensors):
    import numpy as np
    hdr, blobs, off = {}, [], 0
    for k, a in tensors.items():
        b = np.ascontiguousarray(a, dtype='<f4').tobytes()
        hdr[k] = {'dtype': 'F32', 'shape': list(a.shape), 'data_offsets': [off, off + len(b)]}; off += len(b); blobs.append(b)
    h = json.dumps(hdr).encode(); h += b' ' * ((8 - len(h) % 8) % 8)
    open(path, 'wb').write(struct.pack('<Q', len(h)) + h + b''.join(blobs))


def sh(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, text=True, **kw)
    return r.returncode, (r.stdout or '') + (r.stderr or '')


def main():
    miss, src, mnnconvert = need_env()
    if miss:
        print('THIẾU môi trường:', ', '.join(miss)); return 2
    import numpy as np, torch
    import MNN.nn as nn, MNN.expr as F
    from diffusers import UNet2DConditionModel
    work = tempfile.mkdtemp(prefix='unet_lora_')
    ok = True
    def check(name, cond, detail=''):
        nonlocal ok
        print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + str(detail)[:300]) if (detail and not cond) else '')); ok &= bool(cond)
    # 1. công cụ native
    exe = os.path.join(work, 'lora_attach')
    rc, out = sh(['g++', '-std=c++17', '-O1', '-w', os.path.join(HERE, 'mnn_probe/lora_attach_branch.cpp'), '-I', os.path.join(src, 'include'), '-I', os.path.join(src, 'schema/current'),
                  '-I', os.path.join(src, '3rd_party/flatbuffers/include'), '-o', exe])
    check('lora_attach_branch.cpp biên dịch với MNN thật', rc == 0, out[-300:])
    if rc: return 1
    # 2. UNet thu nhỏ + ONNX (đúng tham số script MNN: do_constant_folding=True, dynamic_axes=None, timestep int32) + mnnconvert
    def mk():
        return UNet2DConditionModel(sample_size=8, in_channels=4, out_channels=4, down_block_types=('CrossAttnDownBlock2D', 'DownBlock2D'), up_block_types=('UpBlock2D', 'CrossAttnUpBlock2D'),
                                    block_out_channels=(16, 32), layers_per_block=1, cross_attention_dim=24, attention_head_dim=4, norm_num_groups=4).eval()
    torch.manual_seed(0); unet = mk()
    sample, ts, ehs = torch.randn(2, 4, 8, 8), torch.randn(2).to(dtype=torch.int32), torch.randn(2, 6, 24)
    with torch.no_grad():
        out_base = unet(sample, ts, ehs, return_dict=False)[0].numpy()
        torch.onnx.export(unet, (sample, ts, ehs, False), os.path.join(work, 'model.onnx'), input_names=['sample', 'timestep', 'encoder_hidden_states'], output_names=['out_sample'],
                          dynamic_axes=None, do_constant_folding=True, opset_version=17)
    mnn = os.path.join(work, 'unet.mnn')
    rc, out = sh([mnnconvert, '-f', 'ONNX', '--modelFile', os.path.join(work, 'model.onnx'), '--MNNModel', mnn, '--saveExternalData=1'])
    check('mnnconvert (MNN 3.6.1, cờ mặc định) chuyển UNet thành công', rc == 0 and os.path.exists(mnn), out[-300:])
    if rc: return 1
    rc, ops_txt = sh([exe, '--list', mnn])
    open(os.path.join(work, 'ops.txt'), 'w', encoding='utf-8').write(ops_txt)
    # 3. LoRA kohya từ tên module torch (độc lập với tên op MNN) + bản torch đã gộp trọng số
    mods = {n: m for n, m in unet.named_modules() if isinstance(m, (torch.nn.Linear, torch.nn.Conv2d))}
    rng = np.random.default_rng(7); r = 4; tens = {}
    merged = mk(); merged.load_state_dict(unet.state_dict()); mm = dict(merged.named_modules())
    for name, m in mods.items():
        W = m.weight.detach().numpy(); o_, i_ = W.shape[0], W.shape[1]; conv = W.ndim == 4
        A = (rng.standard_normal((r, i_) + W.shape[2:]) * 0.2).astype('f4'); B = (rng.standard_normal((o_, r) + ((1, 1) if conv else ())) * 0.2).astype('f4')
        alpha = float(rng.choice([2, 4, 8])); key = 'lora_unet_' + name.replace('.', '_')
        tens[key + '.lora_down.weight'], tens[key + '.lora_up.weight'], tens[key + '.alpha'] = A, B, np.array(alpha, dtype='f4')
        mm[name].weight.data += torch.from_numpy((alpha / r * (B.reshape(o_, r) @ A.reshape(r, -1))).reshape(W.shape).astype('f4'))
    write_st(os.path.join(work, 'lora.safetensors'), tens)
    with torch.no_grad(): out_merged = merged(sample, ts, ehs, return_dict=False)[0].numpy()
    # 4. ánh xạ: lần 1 không --map (mong đợi đúng 1 module thiếu = conv_out), lần 2 có --map
    mapper = [sys.executable, os.path.join(HERE, 'lora_to_mnn_spec.py'), '--lora', os.path.join(work, 'lora.safetensors'), '--ops', os.path.join(work, 'ops.txt'), '--out', os.path.join(work, 'spec')]
    rc, out = sh(mapper)
    check('ánh xạ lần 1 (không --map): đúng 82/83 khớp, thiếu duy nhất conv_out, mã 3 và không ghi spec', rc == 3 and 'khớp & ghi 82' in out and 'conv_out' in out and not os.path.exists(os.path.join(work, 'spec', 'spec.txt')), out[-400:])
    rc, out = sh(mapper + ['--map', 'conv_out=out_sample'])
    check('ánh xạ lần 2 (--map conv_out=out_sample): đủ 83/83, mã 0', rc == 0 and 'khớp & ghi 83' in out, out[-400:])
    if rc: return 1
    # 5. gắn nhánh + chạy
    lora_mnn = os.path.join(work, 'unet_lora.mnn')
    rc, out = sh([exe, mnn, os.path.join(work, 'spec', 'spec.txt'), lora_mnn])
    check('lora_attach_branch gắn đủ 83 nhánh', rc == 0 and 'gắn 83 nhánh' in out, out[-300:])
    if rc: return 1
    shutil.copy(mnn + '.weight', lora_mnn + '.weight')
    def run(path):
        m = nn.load_module_from_file(path, ['sample', 'timestep', 'encoder_hidden_states'], ['out_sample'])
        o = m.forward([F.const(sample.numpy().flatten().tolist(), [2, 4, 8, 8], F.NCHW), F.const(ts.numpy().astype('int32').flatten().tolist(), [2], F.NCHW, F.int),
                       F.const(ehs.numpy().flatten().tolist(), [2, 6, 24], F.NCHW)])
        return np.array((o[0] if isinstance(o, (list, tuple)) else o).read()).reshape(2, 4, 8, 8)
    mb, ml = run(mnn), run(lora_mnn)
    d = lambda a, b: float(np.abs(a - b).max())
    print(f'  MNN nền vs torch nền: {d(mb, out_base):.3g} | MNN+LoRA vs torch gộp: {d(ml, out_merged):.3g} | LoRA làm đổi đầu ra: {d(ml, mb):.3g}')
    check(f'MNN nền khớp torch nền (≤ {TOL_BASE})', d(mb, out_base) <= TOL_BASE)
    check(f'MNN + 83 nhánh LoRA khớp torch đã gộp W+ΔW (≤ {TOL_LORA})', d(ml, out_merged) <= TOL_LORA)
    check(f'đối chứng: LoRA thật sự làm đổi đầu ra (≥ {MIN_EFFECT}) và MNN+LoRA KHÁC torch nền', d(ml, mb) >= MIN_EFFECT and d(ml, out_base) >= MIN_EFFECT)
    shutil.rmtree(work, ignore_errors=True)
    print('\nKẾT QUẢ:', 'ĐẠT' if ok else 'CÓ LỖI')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
