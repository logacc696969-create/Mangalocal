"""
export_sd15_base.py — Export SD1.5 (CLIP + UNet + VAE) trực tiếp từ
`diffusers` sang ONNX rồi .mnn, tự đặt tên tensor KHỚP ĐÚNG những gì
sd_engine/PipelineSd15Cpu.hpp (port từ local-dream) đã dùng thật:
    - UNet:  input "sample"/"timestep"/"encoder_hidden_states" -> output "out_sample"
    - VAE decoder: input "latent_sample" -> output "sample"
    - CLIP: input "input_embedding" -> output "last_hidden_state"

QUAN TRỌNG — LÝ DO DÙNG CÁCH NÀY THAY VÌ CƠ CHẾ "khung + patch" CỦA
LOCAL-DREAM (SafeTensor2MNN.hpp/generateModel()/patchModel()): local-dream
CẦN SẴN 1 file .mnn "khung" trước khi patch trọng số vào — nhưng script
PyTorch/ONNX gốc TẠO RA cái khung đó KHÔNG có trong local-dream-master.zip
(không phải mã nguồn mở công khai, chỉ có phần C++ đọc/patch). Nên KHÔNG
thể tái tạo chính xác 100% cơ chế của họ — thay vào đó, export THẲNG từ
diffusers (đường làm chuẩn, nhiều người dùng, có tài liệu) và TỰ ĐẶT TÊN
TENSOR khớp với những gì phía C++ đang đọc — vì tôi kiểm soát cả 2 đầu
(Python export lẫn C++ đọc), đây không phải đoán API, mà tự thiết kế nối
khớp nhau.

RỦI RO CÒN LẠI (khác với patch cơ chế local-dream): CLIP theo local-dream
nhận "input_embedding" (embedding ĐÃ TÍNH SẴN — token_emb + pos_emb cộng
lại), KHÔNG tự làm embedding lookup bên trong đồ thị CLIP — token_emb.bin/
pos_emb.bin (2 file riêng) được TextEncoder.hpp đọc rồi tự cộng embedding
bên C++ trước khi đưa vào CLIP session. Script này tách embedding ra khỏi
CLIP transformer để khớp đúng quy ước đó — ĐÂY LÀ SUY LUẬN TỪ TÊN
TENSOR/FILE ĐÃ THẤY (model_manifest.json có files.pos_emb/token_emb),
CHƯA build-test thật để xác nhận 100% đúng thứ tự cộng/shape.

Cài đặt (đã có sẵn trong prepare_models.yml, không cần cài tay nếu chạy
qua GitHub Actions):
    pip install torch diffusers transformers accelerate onnx MNN

Chạy:
    python export_sd15_base.py --base_model runwayml/stable-diffusion-v1-5 \
        --lora_repo "" --output_dir ./exported_base
"""
import argparse
import os

import numpy as np
import torch
import torch.nn as nn
from diffusers import StableDiffusionPipeline


class ClipBodyOnly(nn.Module):
    """CLIP text transformer BỎ lớp embedding đầu (token+pos) — nhận thẳng
    input_embedding đã cộng sẵn, khớp quy ước TextEncoder.hpp đã port."""

    def __init__(self, text_encoder):
        super().__init__()
        self.encoder = text_encoder.text_model.encoder
        self.final_layer_norm = text_encoder.text_model.final_layer_norm
        # CLIP dùng causal attention mask cố định theo độ dài chuỗi (77 token SD1.5)
        seq_len = 77
        mask = torch.full((seq_len, seq_len), float("-inf"))
        mask = torch.triu(mask, diagonal=1)
        self.register_buffer("causal_mask", mask.unsqueeze(0).unsqueeze(0))

    def forward(self, input_embedding):
        out = self.encoder(input_embedding, attention_mask=None, causal_attention_mask=self.causal_mask)
        last_hidden_state = self.final_layer_norm(out[0])
        return last_hidden_state


class UnetWrapper(nn.Module):
    """UNet chuẩn SD1.5 — đặt lại tên input/output khớp local-dream."""
    def __init__(self, unet):
        super().__init__()
        self.unet = unet

    def forward(self, sample, timestep, encoder_hidden_states):
        return self.unet(sample, timestep, encoder_hidden_states, return_dict=False)[0]


class VaeDecoderWrapper(nn.Module):
    def __init__(self, vae):
        super().__init__()
        self.vae = vae

    def forward(self, latent_sample):
        return self.vae.decode(latent_sample, return_dict=False)[0]


class VaeEncoderWrapper(nn.Module):
    def __init__(self, vae):
        super().__init__()
        self.vae = vae

    def forward(self, sample):
        dist = self.vae.encode(sample, return_dict=False)[0]
        return dist.mean, dist.std  # khớp field "mean"/"std" quan sát được trong SDUtils.hpp lúc port


def export_embedding_tables(text_encoder, output_dir):
    """Xuất token_emb.bin + pos_emb.bin dạng float32 thô — TextEncoder.hpp
    (C++) tự đọc 2 file này rồi cộng lại thành input_embedding trước khi
    gọi CLIP. CHƯA xác nhận 100% đúng thứ tự byte/shape mong đợi — cần đối
    chiếu lại khi build-test thật (xem TECHNICAL_STATUS.md)."""
    token_emb = text_encoder.text_model.embeddings.token_embedding.weight.detach().numpy().astype(np.float32)
    pos_emb = text_encoder.text_model.embeddings.position_embedding.weight.detach().numpy().astype(np.float32)
    token_emb.tofile(os.path.join(output_dir, "token_emb.bin"))
    pos_emb.tofile(os.path.join(output_dir, "pos_emb.bin"))
    print(f"  token_emb: shape {token_emb.shape} -> token_emb.bin")
    print(f"  pos_emb:   shape {pos_emb.shape} -> pos_emb.bin")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="runwayml/stable-diffusion-v1-5")
    ap.add_argument("--lora_repo", default="")
    ap.add_argument("--output_dir", default="./exported_base")
    # mục 161 TECHNICAL_STATUS.md (đợt 5 — "#3 Dynamic Axes/Aspect Ratio",
    # đề xuất từ đợt audit PDF ngoài, mục 146/161, PHIÊN BẢN THU HẸP: N
    # PROFILE CỐ ĐỊNH thay vì dynamic_axes thật — dự án đã quyết KHÔNG dùng
    # dynamic_axes cho MNN mobile, mục 52b). width/height MẶC ĐỊNH 512/512
    # -> HÀNH VI CŨ 100% nếu không truyền gì (mọi lệnh gọi hiện có trong
    # prepare_models.yml chưa truyền 2 tham số này). Đây là script AN TOÀN
    # để làm non-square (đã audit — KHÔNG có phép suy (h,w) từ sqrt(seq_len)
    # như export_ipa_controlnet_regional_unet.py/triple_combo_unet.py, 2
    # script đó CỐ Ý CHƯA đụng tới, xem GIỚI HẠN THẬT ở mục 161 đợt 5).
    ap.add_argument("--width", type=int, default=512, help="Phải chia hết cho 64 (VAE 8x downsample + UNet giảm thêm 8x = 64x thật; mục 161 đợt 7 TECHNICAL_STATUS.md)")
    ap.add_argument("--height", type=int, default=512, help="Phải chia hết cho 64 (VAE 8x downsample + UNet giảm thêm 8x = 64x thật; mục 161 đợt 7 TECHNICAL_STATUS.md)")
    args = ap.parse_args()
    if args.width % 64 != 0 or args.height % 64 != 0:
        # mục 161 (đợt 7) — tra cứu web xác nhận: UNet SD1.5 cần chia hết
        # 64 (KHÔNG PHẢI 8) — chia hết 8 nhưng không chia hết 64 sẽ crash
        # giữa chừng ở bước concat skip-connection giữa down-block/up-block
        # (lỗi thật đã được báo cáo: huggingface/diffusers issue #255,
        # "Sizes of tensors must match except in dimension 1" — do UNet có
        # 3 tầng downsample nội bộ (/2 x3) CHỒNG thêm lên 8x downsample của
        # VAE, cần cả 2 tầng đều ra số nguyên, không chỉ tầng VAE). Đã SỬA
        # LẠI từ %8 (SAI, để lọt qua các giá trị như 520 gây crash thật) —
        # phát hiện được NHỜ tra cứu web, không phải tự nghĩ ra hay đoán.
        raise ValueError(f"width/height phải chia hết cho 64 (không phải 8 — UNet có thêm 3 tầng downsample nội bộ ngoài VAE, xem comment) — nhận {args.width}x{args.height}")
    os.makedirs(args.output_dir, exist_ok=True)

    print(f"Đang tải {args.base_model}...")
    # HỖ TRỢ CẢ 2 ĐỊNH DẠNG (mục 30 TECHNICAL_STATUS.md — user hỏi dùng
    # được model merge cộng đồng, vd tải từ Civitai, không):
    #  - repo HuggingFace / folder diffusers (model_index.json + unet/, vae/...)
    #    -> from_pretrained() (cách CŨ, vẫn hoạt động)
    #  - 1 FILE .safetensors/.ckpt đơn (ĐỊNH DẠNG PHỔ BIẾN của model merge
    #    cộng đồng trên Civitai) -> from_single_file() — API CHÍNH THỨC của
    #    diffusers cho đúng việc này, KHÔNG cần tự convert sang diffusers-repo
    #    trước. Bất kỳ checkpoint merge nào vẫn ĐÚNG kiến trúc SD1.5 gốc
    #    (cùng UNet/CLIP/VAE, 512x512) đều dùng được ở đây KHÔNG cần sửa gì
    #    thêm — vì file .mnn cuối cùng vẫn cùng shape/tensor-name bất kể
    #    checkpoint gốc là bản nào.
    if args.base_model.endswith((".safetensors", ".ckpt")):
        pipe = StableDiffusionPipeline.from_single_file(args.base_model, torch_dtype=torch.float32, safety_checker=None)
    else:
        pipe = StableDiffusionPipeline.from_pretrained(args.base_model, torch_dtype=torch.float32, safety_checker=None)

    if args.lora_repo:
        # Merge LoRA NGAY LÚC EXPORT (API thật, chính thức của diffusers) —
        # THAY THẾ cơ chế convert on-device (sd_model_converter.cpp) vì
        # không có PC/máy mạnh thì merge ở đây (cloud, GitHub Actions) đơn
        # giản và chắc chắn hơn.
        print(f"Đang merge LoRA từ {args.lora_repo}...")
        pipe.load_lora_weights(args.lora_repo)
        pipe.fuse_lora()

    pipe.tokenizer.save_pretrained(args.output_dir)
    # tokenizer.json thật theo format HuggingFace tokenizers — TextEncoder.hpp
    # dùng tokenizers-cpp (FromBlobJSON) nên cần đúng "tokenizer.json", không
    # phải vocab.json/merges.txt rời — save_pretrained() xuất đủ file, nhưng
    # bản thân "tokenizer.json" hợp nhất chỉ có ở tokenizer "fast" — dùng
    # AutoTokenizer nếu thiếu (CHƯA test, ghi chú rủi ro).
    if not os.path.exists(os.path.join(args.output_dir, "tokenizer.json")):
        print("[CANH BAO] Khong thay tokenizer.json hop nhat - TextEncoder.hpp co the doc khong duoc, can kiem tra lai.")

    print("Đang export embedding tables (pos_emb.bin / token_emb.bin)...")
    export_embedding_tables(pipe.text_encoder, args.output_dir)

    print("Đang export CLIP body (input_embedding -> last_hidden_state)...")
    clip_body = ClipBodyOnly(pipe.text_encoder).eval()
    example_embed = torch.randn(1, 77, 768)
    torch.onnx.export(
        clip_body, example_embed, os.path.join(args.output_dir, "clip.onnx"),
        input_names=["input_embedding"], output_names=["last_hidden_state"],
        opset_version=17, do_constant_folding=True,
    
        dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
        # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
        # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
        # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
        # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
        # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
        # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
        # xác nhận hoạt động đúng bằng thực nghiệm.
    )

    print("Đang export UNet (sample/timestep/encoder_hidden_states -> out_sample)...")
    unet_wrap = UnetWrapper(pipe.unet).eval()
    # mục 161 (đợt 5) — latent_h/latent_w THAY vì 64,64 cố định — VAE
    # downsample 8x (đã validate width/height chia hết 8 ở argparse).
    latent_h, latent_w = args.height // 8, args.width // 8
    example_sample = torch.randn(1, 4, latent_h, latent_w)
    example_timestep = torch.tensor([999], dtype=torch.long)
    example_hidden = torch.randn(1, 77, 768)
    torch.onnx.export(
        unet_wrap, (example_sample, example_timestep, example_hidden),
        os.path.join(args.output_dir, "unet.onnx"),
        input_names=["sample", "timestep", "encoder_hidden_states"], output_names=["out_sample"],
        opset_version=17, do_constant_folding=True,
    
        dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
        # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
        # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
        # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
        # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
        # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
        # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
        # xác nhận hoạt động đúng bằng thực nghiệm.
    )

    print("Đang export VAE decoder (latent_sample -> sample)...")
    vae_dec = VaeDecoderWrapper(pipe.vae).eval()
    example_latent = torch.randn(1, 4, latent_h, latent_w)
    torch.onnx.export(
        vae_dec, example_latent, os.path.join(args.output_dir, "vae_decoder.onnx"),
        input_names=["latent_sample"], output_names=["sample"],
        opset_version=17, do_constant_folding=True,
    
        dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
        # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
        # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
        # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
        # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
        # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
        # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
        # xác nhận hoạt động đúng bằng thực nghiệm.
    )

    print("Đang export VAE encoder (sample -> mean, std)...")
    vae_enc = VaeEncoderWrapper(pipe.vae).eval()
    example_pixels = torch.randn(1, 3, args.height, args.width)
    torch.onnx.export(
        vae_enc, example_pixels, os.path.join(args.output_dir, "vae_encoder.onnx"),
        input_names=["input"], output_names=["mean", "std"],
        opset_version=17, do_constant_folding=True,
    
        dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
        # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
        # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
        # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
        # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
        # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
        # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
        # xác nhận hoạt động đúng bằng thực nghiệm.
    )

    print("\n=== Xong phần ONNX. Convert sang .mnn (dùng mnnconvert từ `pip install MNN`) ===")
    for name in ["clip", "unet", "vae_decoder", "vae_encoder"]:
        onnx_path = os.path.join(args.output_dir, f"{name}.onnx")
        mnn_path = os.path.join(args.output_dir, f"{name}.mnn")
        print(f"mnnconvert -f ONNX --modelFile {onnx_path} --MNNModel {mnn_path} --bizCode biz")
    print("\n(prepare_models.yml đã tự chạy các lệnh mnnconvert này — nếu chạy tay, copy đúng lệnh trên)")


if __name__ == "__main__":
    main()
