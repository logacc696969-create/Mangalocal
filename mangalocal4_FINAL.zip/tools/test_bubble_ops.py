#!/usr/bin/env python3
"""mục 249 — kiểm thử BubbleOps (bật/tắt đuôi, kéo đích đuôi, thứ tự lớp) và nối dây màn sửa bubble.

Thuật toán thuần được chép lại bằng Python (không có kotlinc); phần Compose chỉ đối chiếu chuỗi nguồn — KHÔNG chạy được
cảm ứng/kéo thả ở đây, và chưa build-test.
"""
import os, random, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
KB = os.path.join(ROOT, 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(KB, *p), encoding='utf8').read()
KT = rd('pipeline', 'BubbleOps.kt')
DY = float(re.search(r'const val TAIL_DEFAULT_DY = ([0-9.]+)f', KT).group(1)); MAXY = float(re.search(r'const val TAIL_MAX_Y = ([0-9.]+)f', KT).group(1))

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

cl = lambda v, lo, hi: max(lo, min(hi, v))
def B(id, x=0.1, y=0.05, w=0.4, tx=None, ty=None): return dict(id=id, x=x, y=y, w=w, tx=tx, ty=ty)
def default_tail(b): return (cl(b['x'] + b['w'] / 2, 0, 1), cl(b['y'] + DY, 0, MAXY))
def with_tail(b, en):
    b = dict(b)
    if not en: b['tx'] = b['ty'] = None; return b
    if b['tx'] is not None and b['ty'] is not None: return b
    b['tx'], b['ty'] = default_tail(b); return b
def move_tail(b, dx, dy):
    if b['tx'] is None or b['ty'] is None: return b
    b = dict(b); b['tx'] = cl(b['tx'] + dx, 0, 1); b['ty'] = cl(b['ty'] + dy, 0, 1); return b
def move_stack(lst, id, d):
    f = next((i for i, b in enumerate(lst) if b['id'] == id), -1)
    if f < 0 or d == 0: return lst
    to = cl(f + d, 0, len(lst) - 1)
    if to == f: return lst
    m = list(lst); it = m.pop(f); m.insert(to, it); return m

# ---- đuôi ----
b = B('a', 0.2, 0.3, 0.4)
dt = default_tail(b)
check('đuôi mặc định: giữa chiều ngang bubble, thấp hơn đỉnh %.2f' % DY, abs(dt[0] - 0.4) < 1e-9 and abs(dt[1] - 0.55) < 1e-9)
check('đuôi mặc định luôn nằm trong ảnh (kể cả bubble sát đáy/sát phải)', all(0 <= x <= 1 and 0 <= y <= MAXY for x, y in [default_tail(B('z', 0.9, 0.95, 0.4)), default_tail(B('z', 0.0, 0.0, 0.0)), default_tail(B('z', 0.99, 0.99, 0.99))]))
check('bật đuôi khi chưa có -> đặt mặc định', with_tail(b, True)['tx'] == dt[0] and with_tail(b, True)['ty'] == dt[1])
kept = B('k', tx=0.9, ty=0.9)
check('bật đuôi khi ĐÃ có -> giữ vị trí người dùng đã kéo (không ghi đè)', with_tail(kept, True) == kept)
check('tắt đuôi -> null cả hai; tắt rồi bật lại -> về mặc định (không nhớ vị trí cũ)', with_tail(kept, False)['tx'] is None and with_tail(kept, False)['ty'] is None and with_tail(with_tail(kept, False), True)['tx'] == default_tail(kept)[0])
check('kéo đuôi: cộng độ dời, kẹp trong [0,1]', move_tail(B('m', tx=0.5, ty=0.5), 0.2, -0.1)['tx'] == 0.7 and move_tail(B('m', tx=0.5, ty=0.5), 0.9, 0.9)['tx'] == 1 and move_tail(B('m', tx=0.1, ty=0.1), -0.5, -0.5)['ty'] == 0)
check('kéo đuôi khi bubble KHÔNG có đuôi -> không đổi', move_tail(B('n'), 0.3, 0.3) == B('n'))
check('thao tác đuôi không đổi vị trí/kích thước bubble', all(with_tail(b, e)[k] == b[k] for e in (True, False) for k in ('x', 'y', 'w')) and all(move_tail(kept, 0.1, 0.1)[k] == kept[k] for k in ('x', 'y', 'w')))

# ---- lớp ----
L = [B('a'), B('b'), B('c'), B('d')]
ids = lambda l: [x['id'] for x in l]
check('lên trên 1 bậc: a -> sau b (b,a,c,d)', ids(move_stack(L, 'a', 1)) == ['b', 'a', 'c', 'd'])
check('xuống dưới 1 bậc: c -> trước b (a,c,b,d)', ids(move_stack(L, 'c', -1)) == ['a', 'c', 'b', 'd'])
check('kẹp ở hai đầu: đã trên cùng mà lên tiếp / đã dưới cùng mà xuống tiếp -> nguyên', move_stack(L, 'd', 1) == L and move_stack(L, 'a', -1) == L)
check('nhảy nhiều bậc bị kẹp: a +10 -> cuối; d -10 -> đầu', ids(move_stack(L, 'a', 10)) == ['b', 'c', 'd', 'a'] and ids(move_stack(L, 'd', -10)) == ['d', 'a', 'b', 'c'])
check('id không tồn tại / delta 0 / danh sách rỗng -> không đổi, không lỗi', move_stack(L, 'zz', 1) == L and move_stack(L, 'a', 0) == L and move_stack([], 'a', 1) == [])
rng = random.Random(249); bad = []
for t in range(3000):
    n = rng.randint(0, 9); lst = [B('i%d' % i) for i in range(n)]
    if n == 0: continue
    pick = rng.choice(lst)['id']; d = rng.randint(-12, 12); out = move_stack(lst, pick, d)
    if sorted(ids(out)) != sorted(ids(lst)) or len(out) != n: bad.append(('hoán vị', t)); continue
    if out is not lst and ids(out).index(pick) != cl(ids(lst).index(pick) + d, 0, n - 1): bad.append(('vị trí', t))
    if move_stack(move_stack(out, pick, -d), pick, d) != out and abs(d) < n and ids(lst).index(pick) + d == cl(ids(lst).index(pick) + d, 0, n - 1): bad.append(('đảo ngược', t))
check('fuzz 3000: luôn là hoán vị của danh sách cũ, phần tử đích đúng vị trí đã kẹp, thao tác ngược lại trả về nguyên', not bad)
if bad: print('   ví dụ lỗi:', bad[:4])

# ---- nối dây Kotlin ----
PP = rd('ui', 'PostProcessingScreen.kt')
check('Kotlin: hằng số/biểu thức BubbleOps khớp bản chép', 'const val TAIL_DEFAULT_DY = 0.25f' in KT and 'coerceIn(0f, TAIL_MAX_Y)' in KT and 'b.xNorm + b.widthNorm / 2f' in KT
      and 'if (!enabled) return b.copy(tailXNorm = null, tailYNorm = null)' in KT and 'if (b.tailXNorm != null && b.tailYNorm != null) return b' in KT
      and 'val to = (from + delta).coerceIn(0, list.size - 1)' in KT and 'val tx = b.tailXNorm ?: return b' in KT)
check('UI: dùng cạnh THẬT của khung (BoxWithConstraints) thay hằng 300 cũ', 'BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1f)' in PP and 'val side = maxWidth.value' in PP and '* 300' not in PP and '/ 300f' not in PP)
check('UI: độ dời kéo (px) đổi sang dp trước khi chuẩn hoá — cho cả bubble lẫn đích đuôi', PP.count('.toDp().value / side') >= 4)
check('UI: có vẽ đường đuôi và chấm kéo đích đuôi, kéo gọi BubbleOps.moveTail và báo thay đổi', 'Canvas(Modifier.fillMaxSize())' in PP and 'drawLine(Color.Black' in PP and 'BubbleOps.moveTail(it, ' in PP and '.background(C.Orange, CircleShape)' in PP)
check('UI: hộp thoại có chọn loại, công tắc đuôi, nút đổi lớp; Lưu áp dụng loại + đuôi', all(t in PP for t in ['BubbleType.SPEECH to "Thoại"', 'BubbleType.THOUGHT to "Nghĩ"', 'BubbleType.NARRATION to "Dẫn"', 'BubbleType.SHOUT to "Hét"',
      'HelpSwitch(helpKey = "bubbleTail", checked = hasTail', 'onMove(-1)', 'onMove(1)', 'BubbleOps.withTail(bubble.copy(characterName = name, text = text, type = type), hasTail)']))
check('UI: onMove nối tới BubbleOps.moveInStack và onBubblesChanged; dialog có tham số mặc định (không phá lời gọi khác)', 'BubbleOps.moveInStack(bubbles, b.id, delta)' in PP and 'onMove: (Int) -> Unit = {}' in PP)
check('UI: import BubbleOps', 'import com.mangalocal.pipeline.BubbleOps' in PP)
EX = rd('pipeline', 'ExportEngine.kt')
check('xuất file: thứ tự lớp = thứ tự danh sách (bubbles.forEach) và đuôi đọc từ tailXNorm/tailYNorm — nên UI đổi lớp/đuôi có hiệu lực thật', 'bubbles.forEach' in EX and 'tailXNorm' in EX and 'tailYNorm' in EX)


# ---- mục 258: font + cỡ chữ ----
FMIN = float(re.search(r'const val FONT_SCALE_MIN = ([0-9.]+)f', KT).group(1)); FMAX = float(re.search(r'const val FONT_SCALE_MAX = ([0-9.]+)f', KT).group(1))
FONTS = re.findall(r'(\w+)\("([^"]+)"\)', re.search(r'enum class BubbleFont\(val label: String\) \{(.*?)\}', KT, re.S).group(1))
FONT_NAMES = [n for n, _ in FONTS]
def font_of(name): return name if name in FONT_NAMES else 'SANS'
def scale_of(b):
    sc = b.get('fs')
    if sc is None: return 1.0
    if sc != sc: return 1.0
    return cl(sc, FMIN, FMAX)
def with_font(b, scale, font):
    b = dict(b); sc = 1.0 if scale != scale else cl(scale, FMIN, FMAX)
    b['fs'] = None if abs(sc - 1.0) < 0.01 else sc
    b['fst'] = None if font == 'SANS' else font
    return b
check('5 họ font có sẵn của Android: SANS/BOLD/SERIF/MONO/ITALIC', FONT_NAMES == ['SANS', 'BOLD', 'SERIF', 'MONO', 'ITALIC'])
check('khoảng cỡ chữ [0.6, 2.0]', (FMIN, FMAX) == (0.6, 2.0))
check('bubble cũ (null/null) -> cỡ 1.0 và font SANS = hành vi cũ 100%', scale_of(B('a')) == 1.0 and font_of(None) == 'SANS')
check('tên font lạ/hỏng -> SANS, không lỗi', font_of('COMIC_SANS') == 'SANS' and font_of('') == 'SANS')
check('giá trị cỡ ngoài khoảng bị kẹp; NaN -> 1.0', scale_of({'fs': 9.0}) == FMAX and scale_of({'fs': 0.0}) == FMIN and scale_of({'fs': float('nan')}) == 1.0)
check('withFont: giá trị mặc định (1.0, SANS) lưu về null (không đóng dấu tuỳ chỉnh vô ích)', with_font(B('a'), 1.0, 'SANS')['fs'] is None and with_font(B('a'), 1.004, 'SANS')['fst'] is None)
w = with_font(B('a'), 1.5, 'ITALIC')
check('withFont: giữ đúng cỡ 1.5 và font ITALIC', w['fs'] == 1.5 and w['fst'] == 'ITALIC' and scale_of(w) == 1.5 and font_of(w['fst']) == 'ITALIC')
check('withFont không đụng vị trí/đuôi của bubble', all(w[k] == B('a')[k] for k in ('x', 'y', 'w', 'tx', 'ty')))
random.seed(7); bad = 0
for _ in range(400):
    sc = random.uniform(-1, 4); f = random.choice(FONT_NAMES)
    r = with_font(B('r'), sc, f)
    bad += not (FMIN <= scale_of(r) <= FMAX and font_of(r['fst']) == f)
check('400 ca ngẫu nhiên: cỡ luôn trong [0.6,2.0] và font round-trip đúng', bad == 0)
MODELS = rd('model', 'Models.kt')
check('Models.kt: Bubble.fontScale/fontStyle là Float?/String? mặc định null (Gson không chạy default Kotlin)',
      'val fontScale: Float? = null' in MODELS and 'val fontStyle: String? = null' in MODELS)
EXP = rd('pipeline', 'ExportEngine.kt')
check('ExportEngine: cỡ chữ nhân BubbleOps.scaleOf(bubble) và typeface theo fontOf(bubble.fontStyle)',
      '* BubbleOps.scaleOf(bubble)' in EXP and 'typeface = typefaceFor(BubbleOps.fontOf(bubble.fontStyle))' in EXP)
check('ExportEngine: SANS ánh xạ Typeface.DEFAULT (đúng hành vi cũ) và mọi họ font đều có nhánh',
      'BubbleOps.BubbleFont.SANS -> Typeface.DEFAULT' in EXP and all(('BubbleOps.BubbleFont.' + n + ' ->') in EXP for n in FONT_NAMES))
PP = rd('ui', 'PostProcessingScreen.kt')
check('màn sửa bubble: có thanh cỡ chữ + chọn font + lưu qua withFont, đều có dấu ?',
      'LabelWithHelp("Cỡ chữ", "bubbleFontScale")' in PP and 'HelpDot("bubbleFont")' in PP and 'BubbleOps.withFont(' in PP and 'helpKey = "bubbleTail"' in PP)
print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
