#!/usr/bin/env python3
"""mục 273 — ĐỘ PHỦ ở quy mô UNet SD1.5 ĐẦY ĐỦ cho tools/lora_to_mnn_spec.py, thay cho `lora_attach_branch --list` trên unet.mnn thật (không có file).

Sinh DANH SÁCH MODULE của UNet2DConditionModel SD1.5 từ chính quy tắc dựng của diffusers (block_out_channels 320/640/1280/1280, 2 lớp/khối, 8 đầu chú ý,
cross-attn 768, proj_in/proj_out là Conv 1x1) và dựng:
  (a) danh sách op theo ĐÚNG quy ước tên đã thấy trên mnnconvert 3.6.1 thật ở mục 269 (`<đường/dẫn>/<Loại>_output_0[__matmul_converted]`);
  (b) LoRA kohya "LierLa" chuẩn (mọi Linear/Conv1x1 của Transformer2DModel) -> PHẢI ra 192 module UNet (con số quen thuộc của LoRA SD1.5) và khớp 100% op;
  (c) LoRA C3Lier (thêm conv 3x3 resnet/downsampler/upsampler) -> khớp 100%;
  (d) các lỗi có chủ đích (khoá lạ, sai kích thước) vẫn bị bắt ở quy mô đầy đủ.
KHÔNG chứng minh: tên op thật trên UNet SD1.5 CỦA DỰ ÁN (chỉ chứng minh công cụ đúng KHI tên op theo quy ước đã kiểm ở 269) và UNet SD1.5 thật có đúng kích thước này.
"""
import json, os, struct, subprocess, sys, tempfile
import numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOL = os.path.join(ROOT, 'tools', 'lora_to_mnn_spec.py')
fails = []
def check(c, n, d=''):
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + str(d)[:400]) if (d and not c) else ''))
    if not c: fails.append(n)

# ───── kiến trúc SD1.5 (diffusers UNet2DConditionModel) ─────
BOC = [320, 640, 1280, 1280]; LPB = 2; CROSS = 768
def inventory():
    """-> list[(kind, path, in, out, k, bias)] kind: 'xconv' (Conv 3x3/1x1) | 'lin' (Linear); path dạng 'down_blocks.0/resnets.0/conv1'."""
    mods = []
    def resnet(p, cin, cout):
        mods.append(('conv', f'{p}/conv1', cin, cout, 3, True)); mods.append(('conv', f'{p}/conv2', cout, cout, 3, True))
        mods.append(('lin', f'{p}/time_emb_proj', 1280, cout, 1, True))
        if cin != cout: mods.append(('conv', f'{p}/conv_shortcut', cin, cout, 1, True))
    def attn(p, ch):
        mods.append(('conv', f'{p}/proj_in', ch, ch, 1, True)); mods.append(('conv', f'{p}/proj_out', ch, ch, 1, True))
        t = f'{p}/transformer_blocks.0'
        for a, kv in (('attn1', ch), ('attn2', CROSS)):
            mods.append(('lin', f'{t}/{a}/to_q', ch, ch, 1, False)); mods.append(('lin', f'{t}/{a}/to_k', kv, ch, 1, False))
            mods.append(('lin', f'{t}/{a}/to_v', kv, ch, 1, False)); mods.append(('lin', f'{t}/{a}/to_out.0', ch, ch, 1, True))
        mods.append(('lin', f'{t}/ff/net.0.proj', ch, ch * 8, 1, True)); mods.append(('lin', f'{t}/ff/net.2', ch * 4, ch, 1, True))
    mods.append(('conv', 'conv_in', 4, BOC[0], 3, True))
    out_c = BOC[0]
    for i, oc in enumerate(BOC):
        ic = out_c; out_c = oc; last = i == len(BOC) - 1
        for j in range(LPB):
            resnet(f'down_blocks.{i}/resnets.{j}', ic if j == 0 else oc, oc)
            if not last: attn(f'down_blocks.{i}/attentions.{j}', oc)
        if not last: mods.append(('conv', f'down_blocks.{i}/downsamplers.0/conv', oc, oc, 3, True))
    resnet('mid_block/resnets.0', BOC[-1], BOC[-1]); attn('mid_block/attentions.0', BOC[-1]); resnet('mid_block/resnets.1', BOC[-1], BOC[-1])
    rev = list(reversed(BOC)); prev = rev[0]
    for i, oc in enumerate(rev):
        ic = rev[min(i + 1, len(rev) - 1)]; last = i == len(rev) - 1
        for j in range(LPB + 1):
            skip = ic if j == LPB else oc
            rin = prev if j == 0 else oc
            resnet(f'up_blocks.{i}/resnets.{j}', rin + skip, oc)
            if i > 0: attn(f'up_blocks.{i}/attentions.{j}', oc)
        prev = oc
        if not last: mods.append(('conv', f'up_blocks.{i}/upsamplers.0/conv', oc, oc, 3, True))
    mods.append(('conv', 'conv_out', BOC[0], 4, 3, True))
    return mods

def opname(kind, path, bias, variant):
    if kind == 'conv': return f'/{path}/Conv_output_0'
    if variant == 0: return f'/{path}/Add_output_0' if bias else f'/{path}/MatMul_output_0__matmul_converted'
    return f'/{path}/MatMul'  # quy ước tên cũ (probe/test mục 268)

def ops_text(mods, variant):
    lines = []
    for n, (kind, path, i, o, k, bias) in enumerate(mods):
        if path == 'conv_out': name = 'out_sample'  # mục 269: op cuối bị đổi tên thành tên đầu ra của đồ thị
        else: name = opname(kind, path, bias, variant)
        lines.append('%4d  %-18s name=%s  out=%s  in=%d out=%d k=%dx%d group=1\n' % (10 + n, 'Convolution', name, name + '_o', i, o, k, k))
    return ''.join(lines) + '-- %d op (Convolution/Depthwise/ConvInt8/MatMul/InnerProduct) trong 2300 op\n' % len(lines)

def flat(path): return path.replace('/', '_').replace('.', '_')

def write_st(path, tensors):
    hdr, blobs, off = {}, [], 0
    for k, a in tensors.items():
        b = np.ascontiguousarray(a, dtype=np.float32).astype('<f4').tobytes()
        hdr[k] = {'dtype': 'F32', 'shape': list(a.shape), 'data_offsets': [off, off + len(b)]}; off += len(b); blobs.append(b)
    h = json.dumps(hdr).encode(); h += b' ' * ((8 - len(h) % 8) % 8)
    open(path, 'wb').write(struct.pack('<Q', len(h)) + h + b''.join(blobs))

def kohya_lora(mods, select, rank=4, bad=None):
    rng = np.random.default_rng(7); t = {}; n = 0
    for kind, path, i, o, k, bias in mods:
        if not select(kind, path, k): continue
        key = 'lora_unet_' + flat(path); n += 1
        four = k > 1 or kind == 'conv'
        t[key + '.lora_down.weight'] = (rng.integers(-8, 9, size=(rank, i, k, k) if four else (rank, i)) / 8.0).astype(np.float32)
        t[key + '.lora_up.weight'] = (rng.integers(-8, 9, size=(o, rank, 1, 1) if four else (o, rank)) / 8.0).astype(np.float32)
        t[key + '.alpha'] = np.array(float(rank), dtype=np.float32)
    if bad: bad(t)
    return t, n

def run_tool(lora, ops, out, extra=()):
    r = subprocess.run([sys.executable, TOOL, '--lora', lora, '--ops', ops, '--out', out, *extra], capture_output=True, text=True, timeout=240)
    return r.returncode, r.stdout + r.stderr

mods = inventory()
n_tx = sum(1 for m in mods if '/attentions.' in '/' + m[1] and ('transformer_blocks' in m[1] or m[1].endswith(('proj_in', 'proj_out'))))
check(n_tx == 192, 'kiến trúc SD1.5 dựng ra đúng 192 module Linear/Conv1x1 của Transformer2DModel (16 khối x 12)', n_tx)
check(sum(1 for m in mods if m[1].endswith('transformer_blocks.0/attn2/to_k') and m[2] == 768) == 16, '16 khối cross-attn, to_k nhận 768 chiều từ CLIP')
check(sum(1 for m in mods if '/resnets.' in '/' + m[1] and m[1].endswith('conv1')) == 22, '22 khối resnet (8 xuống + 2 giữa + 12 lên)')

with tempfile.TemporaryDirectory() as tmp:
    for variant in (0, 1):
        ops_p = os.path.join(tmp, f'ops{variant}.txt'); open(ops_p, 'w').write(ops_text(mods, variant))
        tag = 'tên op kiểu mục 269 (Add/MatMul_converted/Conv_output_0)' if variant == 0 else 'tên op kiểu cũ (/MatMul, /Conv_output_0)'
        # (b) LierLa chuẩn: Linear + Conv1x1 trong Transformer2DModel
        sel = lambda kind, path, k: ('transformer_blocks' in path) or path.endswith(('proj_in', 'proj_out'))
        t, n = kohya_lora(mods, sel); lp = os.path.join(tmp, 'lierla.safetensors'); write_st(lp, t)
        rc, txt = run_tool(lp, ops_p, os.path.join(tmp, f'o_l{variant}'))
        check(n == 192, 'LoRA LierLa mô phỏng có 192 module', n)
        check(rc == 0, f'LierLa 192/192 khớp, mã thoát 0 — {tag}', txt[-700:])
        spec = os.path.join(tmp, f'o_l{variant}', 'spec.txt')
        body = [l for l in open(spec).read().splitlines() if l.strip() and not l.lstrip().startswith('#')] if os.path.exists(spec) else []
        check(len(body) == 192, f'spec.txt có đúng 192 dòng gắn nhánh — {tag}', len(body))
        # (c) C3Lier: thêm conv 3x3 + shortcut
        sel3 = lambda kind, path, k: sel(kind, path, k) or (kind == 'conv' and path not in ('conv_in', 'conv_out'))
        t3, n3 = kohya_lora(mods, sel3); lp3 = os.path.join(tmp, 'c3.safetensors'); write_st(lp3, t3)
        rc3, txt3 = run_tool(lp3, ops_p, os.path.join(tmp, f'o_c{variant}'))
        check(rc3 == 0, f'C3Lier ({n3} module gồm conv 3x3) khớp 100%, mã thoát 0 — {tag}', txt3[-700:])
    # (d) lỗi có chủ đích ở quy mô đầy đủ (dùng danh sách op kiểu 0)
    ops_p = os.path.join(tmp, 'ops0.txt')
    t, n = kohya_lora(mods, sel, bad=lambda tt: tt.update({'lora_unet_down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_q.lora_down.weight': np.zeros((4, 999), np.float32)}))
    lp = os.path.join(tmp, 'badshape.safetensors'); write_st(lp, t)
    rc, txt = run_tool(lp, ops_p, os.path.join(tmp, 'o_bad'))
    check(rc == 3, 'một module sai kích thước giữa 192 module -> mã thoát 3 (không gắn thiếu mà báo thành công)', (rc, txt[-400:]))
    t, n = kohya_lora(mods, sel, bad=lambda tt: tt.update({'lora_unet_up_blocks_9_attentions_0_proj_in.lora_down.weight': np.zeros((4, 8), np.float32), 'lora_unet_up_blocks_9_attentions_0_proj_in.lora_up.weight': np.zeros((8, 4), np.float32)}))
    lp = os.path.join(tmp, 'unknown.safetensors'); write_st(lp, t)
    rc, txt = run_tool(lp, ops_p, os.path.join(tmp, 'o_unk'))
    check(rc == 3, 'một khoá không có op tương ứng giữa 192 module -> mã thoát 3', (rc, txt[-400:]))
    rc, txt = run_tool(lp, ops_p, os.path.join(tmp, 'o_unk2'), ('--allow-unmatched',))
    check(rc == 0, '--allow-unmatched chấp nhận có chủ đích (mã thoát 0)', (rc, txt[-400:]))
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
