#!/usr/bin/env python3
"""Mô phỏng Python của BubbleEngine.placeWithSpeakers() và ExportEngine.computeTail()
(mục 228 TECHNICAL_STATUS.md).

KHÔNG phải test của chính code Kotlin (sandbox không có kotlinc): chép lại
NGUYÊN công thức để kiểm chứng phần hình học — né mặt, thứ tự đọc, đuôi trỏ
đúng người, bubble nằm trong ảnh. Sửa Kotlin thì sửa lại file này.
"""
import math

FACE_R = 0.09


def est_h(text, w):
    cpl = max(8, int(w / 0.026))
    lines = min(8, max(1, (len(text) + cpl - 1) // cpl))
    return min(0.40, 0.045 + lines * 0.036)


def overlap(a, b):
    ox = max(0, min(a[2], b[2]) - max(a[0], b[0]))
    oy = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    return ox * oy


def place(dialogues, heads, w=0.42):
    face_boxes = [(x - FACE_R, y - FACE_R, x + FACE_R, y + FACE_R) for x, y in heads.values()]
    placed, out, prev_cy = [], [], -1.0
    for name, text, typ in dialogues:
        h = est_h(text, w)
        head = heads.get(name)
        if head is None:
            for k, v in heads.items():
                if k.lower() == name.lower():
                    head = v
        if typ == 'NARRATION' or head is None:
            cands = [(0.03, 0.02), (0.55, 0.02), (0.03, 0.98 - h), (0.55, 0.98 - h), (0.05, 0.30), (0.53, 0.30)]
        else:
            hx, hy = head
            cands = [(hx - w / 2, hy - h - 0.12), (hx - w + 0.05, hy - h - 0.10), (hx - 0.05, hy - h - 0.10),
                     (hx + 0.10, hy - h / 2), (hx - 0.10 - w, hy - h / 2), (hx - w / 2, hy + 0.14)]
        best, best_cost = None, 1e30
        for cx, cy in cands:
            x = min(max(cx, 0.02), max(0.98 - w, 0.02))
            y = min(max(cy, 0.02), max(0.98 - h, 0.02))
            r = (x, y, x + w, y + h)
            cost = 0.0
            for f in face_boxes:
                cost += 1000 * overlap(r, f) / (FACE_R * FACE_R * 4)
            for p in placed:
                cost += 300 * overlap(r, p) / (w * h)
            if head is not None and typ != 'NARRATION':
                cost += 5 * math.hypot((r[0] + r[2]) / 2 - head[0], (r[1] + r[3]) / 2 - head[1])
            ccy = (r[1] + r[3]) / 2
            if prev_cy >= 0:
                cost += 2 * max(0, prev_cy - ccy)
            if cost < best_cost:
                best_cost, best = cost, r
        placed.append(best)
        prev_cy = (best[1] + best[3]) / 2
        has_tail = head is not None and typ != 'NARRATION'
        out.append(dict(name=name, rect=best,
                        tail=(head[0], min(head[1] + 0.03, 0.98)) if has_tail else None))
    return out


def compute_tail(rect, tx, ty, half_base, shrink):
    l, t, r, b = rect
    margin = half_base * 1.6
    if ty > b:
        edge = 0
    elif ty < t:
        edge = 1
    elif tx < l:
        edge = 2
    elif tx > r:
        edge = 3
    else:
        return None
    clamp = lambda v, lo, hi: max(lo, min(v, hi))
    if edge == 0:
        bx, by, nx, ny = clamp(tx, l + margin, r - margin), b, 0, 1
    elif edge == 1:
        bx, by, nx, ny = clamp(tx, l + margin, r - margin), t, 0, -1
    elif edge == 2:
        bx, by, nx, ny = l, clamp(ty, t + margin, b - margin), -1, 0
    else:
        bx, by, nx, ny = r, clamp(ty, t + margin, b - margin), 1, 0
    dx, dy = tx - bx, ty - by
    dist = math.hypot(dx, dy)
    if dist < 1e-3:
        return None
    tip_d = max(dist - shrink, half_base * 1.2)
    return dict(edge=edge, base=(bx, by), tip=(bx + dx / dist * tip_d, by + dy / dist * tip_d), n=(nx, ny))


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    return cond


def main():
    ok = True
    heads = {"An": (0.30, 0.45), "Binh": (0.70, 0.40)}
    dl = [("An", "Buông ra ngay! Tôi đã nói là không muốn đánh nhau nữa.", "SPEECH"),
          ("Binh", "Đừng hòng!", "SHOUT"),
          ("An", "…", "THOUGHT")]
    res = place(dl, heads)
    faces = [(x - FACE_R, y - FACE_R, x + FACE_R, y + FACE_R) for x, y in heads.values()]

    ok &= check("mọi bubble nằm trong ảnh", all(0 <= r['rect'][0] and r['rect'][2] <= 1 and 0 <= r['rect'][1] and r['rect'][3] <= 1 for r in res))
    ok &= check("không bubble nào che mặt ai", all(overlap(r['rect'], f) == 0 for r in res for f in faces))
    ok &= check("các bubble không chồng nhau", all(overlap(res[i]['rect'], res[j]['rect']) == 0 for i in range(len(res)) for j in range(i + 1, len(res))))
    ok &= check("tail của An trỏ về đầu An", res[0]['tail'][0] == 0.30)
    ok &= check("tail của Binh trỏ về đầu Binh", res[1]['tail'][0] == 0.70)
    ok &= check("thứ tự đọc: bubble sau không cao hơn bubble trước quá 0.1", all(
        (res[i + 1]['rect'][1] + res[i + 1]['rect'][3]) / 2 >= (res[i]['rect'][1] + res[i]['rect'][3]) / 2 - 0.10 for i in range(len(res) - 1)))
    print("   vị trí:", [tuple(round(v, 2) for v in r['rect']) for r in res])

    # Người nói không có trong heads -> vẫn đặt, không tail.
    r2 = place([("Ai đó", "Xin chào", "SPEECH")], heads)
    ok &= check("người nói lạ -> không tail", r2[0]['tail'] is None)

    # Tên khác hoa/thường vẫn khớp.
    r3 = place([("an", "Ừ", "SPEECH")], heads)
    ok &= check("khớp tên không phân biệt hoa thường", r3[0]['tail'] is not None)

    # NARRATION: ở mép, không tail.
    r4 = place([("", "Đêm hôm đó...", "NARRATION")], heads)
    ok &= check("narration ở mép ảnh và không tail", r4[0]['tail'] is None and (r4[0]['rect'][1] < 0.1 or r4[0]['rect'][3] > 0.9))

    # Không có heads -> hàm vẫn chạy.
    r5 = place([("An", "Hi", "SPEECH")], {})
    ok &= check("heads rỗng -> vẫn đặt được", len(r5) == 1)

    # Nhiều bubble (6) trong ảnh nhỏ: không lỗi, trong ảnh.
    many = [("An" if i % 2 == 0 else "Binh", "Lời thoại số %d khá dài để chiếm nhiều dòng trong bubble" % i, "SPEECH") for i in range(6)]
    r6 = place(many, heads)
    ok &= check("6 bubble vẫn trong ảnh", all(0 <= r['rect'][0] and r['rect'][2] <= 1 and 0 <= r['rect'][1] and r['rect'][3] <= 1 for r in r6))

    # Tail hình học.
    rect = (0.10, 0.10, 0.52, 0.22)
    t = compute_tail(rect, 0.30, 0.45, 0.01, 0.02)
    ok &= check("mục tiêu dưới bubble -> đuôi ở cạnh dưới", t is not None and t['edge'] == 0 and abs(t['base'][1] - 0.22) < 1e-9)
    ok &= check("đầu đuôi dừng ngắn hơn mục tiêu", t is not None and t['tip'][1] < 0.45)
    ok &= check("mục tiêu trong bubble -> không đuôi", compute_tail(rect, 0.3, 0.15, 0.01, 0.02) is None)
    t2 = compute_tail(rect, 0.80, 0.16, 0.01, 0.02)
    ok &= check("mục tiêu bên phải -> đuôi ở cạnh phải", t2 is not None and t2['edge'] == 3)
    t3 = compute_tail(rect, 0.30, 0.02, 0.01, 0.02)
    ok &= check("mục tiêu phía trên -> đuôi ở cạnh trên", t3 is not None and t3['edge'] == 1)
    t4 = compute_tail(rect, 0.05, 0.16, 0.01, 0.02)
    ok &= check("mục tiêu bên trái -> đuôi ở cạnh trái", t4 is not None and t4['edge'] == 2)

    print("\nKẾT QUẢ:", "TẤT CẢ ĐẠT" if ok else "CÓ LỖI")
    raise SystemExit(0 if ok else 1)


if __name__ == "__main__":
    main()
