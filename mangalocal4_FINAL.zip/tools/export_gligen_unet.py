"""
export_gligen_unet.py — Xuất 1 bản UNet SD1.5 đã có sẵn GLIGEN (Grounded
Language-to-Image Generation, Li et al., CVPR 2023) sang ONNX, để
prepare_models.yml convert tiếp sang .mnn.

TẠI SAO FILE NÀY (mục 222 → mục 223 TECHNICAL_STATUS.md — user chỉ ra
ĐÚNG: vấn đề không chỉ là "độ sâu" mà là "sự HỢP LÝ giữa CÁC LOẠI vật thể"
— vd cây phải cao hơn người, tường thành phải đúng cỡ. Đã `web_search`
xác nhận: SD1.5/SDXL KHÔNG đáng tin cậy để tự "hiểu" quan hệ này từ CHỮ
khi cảnh có nhiều vật thể — HRS-Bench benchmark đo được độ chính xác GẦN
0 ở cảnh phức tạp; gốc rễ nằm ở DỮ LIỆU huấn luyện (paper CoMPaSS), không
sửa được chỉ bằng prompt tốt hơn).

GLIGEN giải ĐÚNG vấn đề này bằng cách KHÁC HẲN: thay vì hy vọng model tự
hiểu chữ "cây cao hơn người", GLIGEN ÉP TỶ LỆ BẰNG HÌNH HỌC TƯỜNG MINH —
mỗi vật thể được gán 1 bounding box thật (toạ độ [0,1]) + 1 nhãn chữ, hộp
to hơn = vật to hơn, không cần model "hiểu" gì cả.

NGUỒN ĐÃ TRA CỨU (qua `web_search`/`web_fetch`, không đoán):
  - Paper gốc: "GLIGEN: Open-Set Grounded Text-to-Image Generation"
    (arxiv.org/abs/2301.07093, CVPR 2023, ĐH Wisconsin-Madison + Columbia
    + Microsoft).
  - Cơ chế: thêm 1 lớp "gated self-attention" (`GatedSelfAttentionDense`,
    xác nhận qua chính source `diffusers/models/attention.py`, nhiều bản
    sao độc lập trên HuggingFace khớp nhau) chèn GIỮA self-attention và
    cross-attention ở MỌI Transformer block của UNet — ĐÓNG BĂNG toàn bộ
    trọng số SD gốc, chỉ lớp mới này được train. KHÔNG PHẢI kiến trúc lạ
    — cùng tinh thần "plug-in, đóng băng gốc" như ControlNet/IP-Adapter
    dự án đã dùng.
  - Tài liệu diffusers chính thức xác nhận `UNet2DConditionModel` (khi
    tải từ checkpoint GLIGEN) tự có thêm submodule `self.position_net`
    (lớp "grounding tokenizer": mã hoá box + nhãn chữ -> token đưa vào
    gated self-attention) và TỰ GỌI nó bên trong `forward()` khi
    `cross_attention_kwargs` có key `"gligen"` — xác nhận trực tiếp từ 1
    dòng diff thật của source diffusers:
        cross_attention_kwargs["gligen"] = {"objs": self.position_net(**gligen_args)}
    Nghĩa là: KHÔNG cần export riêng 1 "model mã hoá box" như
    ip_image_encoder.mnn — gọi `unet(...)` với đúng
    `cross_attention_kwargs={"gligen": {...}}` là ĐỦ, mọi thứ (mã hoá box
    + gated attention) chạy TRONG 1 lượt `forward()`, script này chỉ cần
    bọc `forward()` đó lại để trace 1 LẦN — ĐÚNG mẫu hình mọi
    `AugmentedUNet*` khác trong dự án này.
  - Checkpoint CHÍNH THỨC (tổ chức `gligen`/`masterful` trên HuggingFace,
    trang tài liệu diffusers liệt kê rõ): `masterful/gligen-1-4-generation-text-box`
    — bản "generation" (sinh ảnh mới từ đầu + có vật thể theo box, ĐÚNG
    nhu cầu MangaLocal — sinh panel MỚI, không phải sửa ảnh có sẵn) dùng
    UNet SD 1.4 (tương thích kiến trúc họ SD1.5 dự án đang dùng). Có bản
    "inpainting" (`masterful/gligen-1-4-inpainting-text-box`) để chèn vật
    thể vào ẢNH CÓ SẴN — CHƯA dùng ở đây (xem GIỚI HẠN THẬT, có thể hợp
    với hướng "vẽ trực tiếp lên ảnh neo bối cảnh" sau này nhưng CHƯA thiết
    kế).
  - `positive_len`/`feature_type="text-only"` (khi `attention_type="gated"`,
    đúng biến thể "generation-text-box") xác nhận: `positive_embeddings`
    truyền vào mỗi vật thể là EMBEDDING VĂN BẢN (CLIP text encoder — CÙNG
    encoder SD1.5 đã dùng cho prompt chính, KHÔNG phải encoder ảnh riêng),
    không phải embedding ảnh — khớp đúng nhu cầu "nhãn chữ + hộp" của
    Scene.objectBoxes (mục 222/223 Models.kt), không cần ảnh tham chiếu.

=== mục 224 — ĐÃ FETCH ĐƯỢC THẬT source + config, KHÔNG CẦN checkpoint đầy đủ ===
User hỏi đúng trọng tâm: "SD1.5/SDXL chả lẽ không có kiến trúc CHUNG, sao
mỗi checkpoint phải tải về mới viết được?" — ĐÚNG, và đã tự sửa cách làm:
kiến trúc (`PositionNet`, `GatedSelfAttentionDense`) định nghĩa 1 LẦN
trong chính SOURCE CODE thư viện `diffusers` (dùng chung cho MỌI checkpoint
cùng họ, không phải thứ phải "tải checkpoint về mới biết") — đã
`web_fetch` được TRỰC TIẾP source thật:
  github.com/huggingface/diffusers/blob/main/src/diffusers/models/embeddings.py
xác nhận VERBATIM `PositionNet.forward(self, boxes, masks, positive_embeddings)`:
  xyxy_embedding = self.fourier_embedder(boxes)          # Fourier 8 tần số
  positive_embeddings = positive_embeddings*masks + (1-masks)*positive_null   # null HỌC ĐƯỢC, không phải zero
  xyxy_embedding = xyxy_embedding*masks + (1-masks)*xyxy_null
  objs = self.linears(cat([positive_embeddings, xyxy_embedding], dim=-1))
— khớp CHÍNH XÁC thiết kế wrapper bên dưới (boxes/masks/positive_embeddings
3 input riêng). Quan trọng: `masks=0` dùng embedding NULL ĐÃ HỌC (không
phải "0 là an toàn" như đoán ban đầu, nhưng KHÔNG đổi thiết kế — giá trị
boxes/positive_embeddings ở slot masks=0 vẫn KHÔNG được đọc tới, chỉ khác
ở CHỖ THAY THẾ, không ảnh hưởng cách gọi).

Đã `web_fetch` TRỰC TIẾP `config.json` thật của UNet trong chính checkpoint
`masterful/gligen-1-4-generation-text-box` (chỉ 772 byte — file cấu hình
nhỏ, KHÁC HẲN 2-4GB trọng số, hoàn toàn tải được qua `web_fetch` dù không
tải nổi cả checkpoint) — xác nhận SỐ THẬT:
  "attention_type": "gated", "cross_attention_dim": 768, "sample_size": 64
`cross_attention_dim=768` CHÍNH LÀ `positive_len` (quy ước chuẩn của
GLIGEN: token "positive" phải cùng không gian embedding với cross-attention
văn bản chính, vì cả 2 cộng gộp qua gated self-attention) — **positive_len=768
giờ đã XÁC NHẬN THẬT, không còn là suy luận "text-only nên chắc vậy"**.

Bài học rút ra (áp dụng luôn cho lần sau): trước khi kết luận "cần tải
checkpoint đầy đủ mới viết được", THỬ `web_fetch` trực tiếp
`config.json`/file kiến trúc nhỏ trên HuggingFace TRƯỚC — thường đủ để
xác nhận shape/tham số mà KHÔNG cần tải hàng GB trọng số.
=============================================================================

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_gligen_unet.py --output_dir ./exported_gligen

============================== GIỚI HẠN THẬT ==============================
1. **CHƯA build-test bằng thực thi thật** — sandbox phiên viết file này
   không có mạng để tự chạy `from_pretrained(...)` + `torch.onnx.export()`
   thật (chỉ `web_fetch` được TEXT/JSON nhỏ — source code, config.json —
   KHÔNG tải được checkpoint nhị phân GB). NHƯNG mức tin cậy đã tăng đáng
   kể so với bản đầu (mục 223): `positive_len=768` giờ XÁC NHẬN THẬT qua
   `config.json` thật (không còn là suy luận), và cơ chế `PositionNet`
   xác nhận qua VERBATIM source thật (không còn là mô tả gián tiếp) — xem
   "mục 224" ở trên. Vẫn CHƯA ở mức mục 97 (tự pip-install + chạy qua mắt
   mình), nhưng cao hơn hẳn mức "tài liệu mô tả chức năng" trước đó.
2. `max_objs=30` vẫn lấy từ số công bố trong PAPER GỐC (không phải config
   riêng của checkpoint — số này KHÔNG nằm trong `config.json` của UNet,
   nó là hằng số Python cố định lúc author viết code gốc) — script tự dò
   lại qua `probe_position_net_shapes()` để XÁC NHẬN 768 khớp (dừng lỗi
   rõ ràng nếu không khớp), nhưng KHÔNG dò được max_objs bằng cách tương
   tự (không có tensor nào trong `position_net` phụ thuộc trực tiếp số
   này để suy ngược) — vẫn là điểm cần tự kiểm tra thêm nếu có checkpoint
   thật trong tay.
3. **KHÔNG dùng "Scheduled Sampling"** (`gligen_scheduled_sampling_beta`
   — cơ chế TẮT gated-attention ở phần cuối các bước khử nhiễu để tăng
   chất lượng ảnh, mặc định 0.3 trong pipeline chính thức) — dùng LUÔN
   BẬT cho mọi bước (tương đương `gligen_scheduled_sampling_beta=1.0`,
   ĐÚNG giá trị 2 ví dụ chính thức trong tài liệu diffusers dùng, không
   phải giá trị tự nghĩ) để đơn giản hoá lần export đầu — có thể ảnh
   hưởng chất lượng ảnh so với dùng scheduled sampling thật, CHƯA đo được.
4. **File này CHỈ export ONNX** — KHÔNG có native wrapper (.cpp), KHÔNG
   nối JNI/Kotlin, KHÔNG quyết định cách encode `Scene.objectBoxes` thành
   tensor đúng format model mong đợi (việc đó cần biết CHÍNH XÁC cấu trúc
   `gligen_args` thật — CHƯA soi được, xem "VIỆC CÒN LẠI" mục 223
   TECHNICAL_STATUS.md).
5. Model gốc train trên COCO — 80 loại vật thể phổ biến (cây, nhà, xe,
   người, đồ nội thất...) khớp tốt với nhu cầu "cây/nhà/tường" của user,
   nhưng KHÔNG đảm bảo hiểu mọi danh từ tiếng Việt LLM có thể sinh ra
   (Qwen2.5-3B viết prompt tiếng Anh cho model vẽ, xem LLMParser.kt — vẫn
   cần dịch nhãn sang tiếng Anh, giống mọi phần prompt khác của dự án).
6. Đây LÀ kiến trúc MỚI HOÀN TOÀN với dự án (gated self-attention chèn
   vào MỌI block UNet) — khác "thêm 1 cross-attention IP-Adapter" hay
   "thêm 1 input scale" đã làm ở mục 217-219. Độ rủi ro cao hơn các phần
   đó, dù cơ chế đã được nghiên cứu/công bố rộng (CVPR 2023, không phải
   tự nghĩ) VÀ giờ đã xác nhận qua source/config thật (mục 224).
=============================================================================
"""
import argparse
import os

import torch
import torch.nn as nn
from diffusers import StableDiffusionGLIGENPipeline


class AugmentedUNetGligen(nn.Module):
    """Bọc UNet đã có GLIGEN thành 1 module để export ONNX 1 lần — mirror
    ĐÚNG mẫu hình `AugmentedUNet` (export_ipa_controlnet_unet.py): tự
    `unet.position_net` (đã có sẵn trong checkpoint GLIGEN, KHÔNG viết
    lại) tự chạy BÊN TRONG `unet.forward()` khi `cross_attention_kwargs`
    có key "gligen" — xem docstring đầu file cho nguồn xác nhận.

    mục 226 TECHNICAL_STATUS.md — with_character_slot=True: THÊM (không
    thay) 1 input `ip_image_embeds` — user chỉ ra ĐÚNG: cộng đồng (ComfyUI,
    paper InteractDiffusion "pluggable" trên nền GLIGEN) đã xác nhận GLIGEN
    (gated self-attention, chèn TRƯỚC cross-attention) và IP-Adapter (thêm
    trọng số riêng NGAY TRONG cross-attention qua `to_k_ip`/`to_v_ip`) tác
    động lên 2 PHẦN KHÁC NHAU của cùng 1 transformer block — không xung
    đột cấu trúc. `pipe.load_ip_adapter()` (mixin CHUNG của mọi pipeline
    diffusers, KHÔNG ràng buộc với `attention_type` của UNet) gọi ĐƯỢC
    trên CHÍNH pipe GLIGEN đã tải — xác nhận qua source thật
    `IPAdapterMixin.load_ip_adapter()` (mục 226, web_fetch). Cách feed
    `added_cond_kwargs={"image_embeds":[...]}` mirror Y HỆT
    `export_ipa_controlnet_unet.py` (mục 97 — ĐÃ verify thật lúc đó, xem
    "PHẦN TẠO TÁC DỤNG THẬT" ở đây và giữ NGUYÊN không đổi vì đến từ nguồn
    tin cậy cao hơn phần GLIGEN mới thêm).
    """

    def __init__(self, unet, with_character_slot=False):
        super().__init__()
        self.unet = unet
        self.with_character_slot = with_character_slot

    def forward(self, sample, timestep, encoder_hidden_states,
                gligen_boxes, gligen_positive_embeddings, gligen_masks,
                # mục 226 — CHỈ có mặt trong đồ thị ONNX khi with_character_slot=True
                # lúc TRACE (giống hệt cách location_ip_embeds/location_scale
                # mục 219 chỉ traced có điều kiện) — main() bên dưới chỉ đưa
                # vào example_inputs khi bật cờ.
                ip_image_embeds=None):
        kwargs = dict(
            cross_attention_kwargs={
                "gligen": {
                    "boxes": gligen_boxes,
                    "positive_embeddings": gligen_positive_embeddings,
                    "masks": gligen_masks,
                }
            },
            return_dict=False,
        )
        if self.with_character_slot:
            # Y HỆT export_ipa_controlnet_unet.py — list bọc 1 phần tử vì
            # diffusers hỗ trợ nhiều IP-Adapter cùng lúc, ở đây dùng đúng 1.
            kwargs["added_cond_kwargs"] = {"image_embeds": [ip_image_embeds]}
        noise_pred = self.unet(sample, timestep, encoder_hidden_states=encoder_hidden_states, **kwargs)[0]
        return noise_pred


# mục 224 TECHNICAL_STATUS.md — ĐÃ XÁC NHẬN THẬT qua config.json thật của
# chính checkpoint (`cross_attention_dim: 768`, web_fetch trực tiếp, xem
# docstring đầu file) — KHÔNG còn là suy luận. Vẫn dò lại lúc chạy (dưới)
# để BÁO LỖI SỚM nếu ai đó đổi sang checkpoint GLIGEN khác có config khác,
# thay vì âm thầm export sai shape.
CONFIRMED_POSITIVE_LEN = 768


def probe_position_net_shapes(unet):
    """XÁC NHẬN `positive_len` của `unet.position_net` đã tải khớp đúng
    768 (đã confirm thật qua config.json, xem CONFIRMED_POSITIVE_LEN) —
    KHÔNG chỉ dò mù rồi tin theo, mà dò RỒI ĐỐI CHIẾU, dừng lỗi rõ ràng
    nếu checkpoint đang dùng khác 768 (vd đổi sang checkpoint GLIGEN khác
    của bên thứ 3 với config khác) thay vì âm thầm export sai.
    """
    pn = getattr(unet, "position_net", None)
    if pn is None:
        raise RuntimeError(
            "unet.position_net không tồn tại — checkpoint tải về có thể "
            "KHÔNG phải bản GLIGEN thật, hoặc diffusers đã đổi cấu trúc "
            "nội bộ so với lúc viết script này. DỪNG LỖI thay vì đoán bừa "
            "shape — tự đọc lại source diffusers thật trước khi sửa script này."
        )
    positive_len = getattr(pn, "positive_len", None)
    if positive_len is None:
        # Vài phiên bản diffusers có thể lưu dưới tên khác — thử suy ra từ
        # chính lớp Linear đầu tiên của position_net (nhận positive_len làm
        # input dim) thay vì bỏ cuộc ngay.
        for m in pn.modules():
            if isinstance(m, torch.nn.Linear):
                positive_len = m.in_features
                break
    if positive_len is None:
        raise RuntimeError(
            "Không dò được 'positive_len' từ unet.position_net qua cả 2 "
            "cách đã thử (thuộc tính trực tiếp, suy ra từ Linear đầu tiên) "
            "— DỪNG LỖI, cần tự đọc lại source PositionNet thật trước khi "
            "viết tiếp, không đoán bừa số này (ảnh hưởng trực tiếp shape "
            "input positive_embeddings)."
        )
    positive_len = int(positive_len)
    if positive_len != CONFIRMED_POSITIVE_LEN:
        raise RuntimeError(
            f"positive_len thật ({positive_len}) KHÁC giá trị đã xác nhận qua "
            f"config.json chính thức ({CONFIRMED_POSITIVE_LEN}) — checkpoint đang "
            "dùng có thể không phải masterful/gligen-1-4-generation-text-box, "
            "hoặc HuggingFace đã đổi config sau khi mục 224 TECHNICAL_STATUS.md "
            "viết. DỪNG LỖI thay vì âm thầm export sai shape — kiểm tra lại "
            "config.json thật của checkpoint đang dùng (--checkpoint) trước khi "
            "tiếp tục."
        )
    return positive_len


def probe_ip_adapter_embed_shape(pipe, device):
    """Mục 226 — mirror Y HỆT `probe_ip_adapter_embed_shape()` của
    export_ipa_controlnet_unet.py (mục 97, ĐÃ verify thật lúc đó): tự dò
    shape thật của image_embeds bằng 1 lần chạy thử với ảnh giả (toàn màu
    xám), thay vì đoán con số. Dùng cùng `pipe.prepare_ip_adapter_image_embeds`
    — có sẵn trên pipe GLIGEN vì IPAdapterMixin là mixin chung, xem docstring
    AugmentedUNetGligen."""
    from PIL import Image

    dummy_image = Image.new("RGB", (224, 224), color=(128, 128, 128))
    with torch.no_grad():
        embeds = pipe.prepare_ip_adapter_image_embeds(
            ip_adapter_image=[dummy_image],
            ip_adapter_image_embeds=None,
            device=device,
            num_images_per_prompt=1,
            do_classifier_free_guidance=False,
        )
    embed_tensor = embeds[0]
    print(f"[probe] image_embeds shape THẬT (dò được, không đoán): {tuple(embed_tensor.shape)}")
    return embed_tensor


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", default="masterful/gligen-1-4-generation-text-box",
                         help="Checkpoint GLIGEN CHINH THUC tren HuggingFace (xem docstring dau file). "
                              "KHONG doi sang checkpoint 'inpainting' o day - kien truc input khac (co them anh nen).")
    parser.add_argument("--max_objs", type=int, default=30,
                         help="So vat the toi da/anh - 30 la con so cong bo trong paper goc, CHUA tu xac nhan qua checkpoint that (xem GIOI HAN THAT).")
    parser.add_argument("--image_size", type=int, default=512, help="SD 1.4/1.5 mac dinh 512x512, chia het 64.")
    # mục 226 TECHNICAL_STATUS.md — user chỉ ra ĐÚNG: giới hạn "GLIGEN không
    # giữ được nhân vật" chỉ tồn tại khi KHÔNG tra cứu cách cộng đồng giải
    # quyết. Tra cứu thật: ComfyUI tách GLIGEN (conditioning) khỏi IPAdapter
    # (model patch) — ghép được cùng lúc; paper InteractDiffusion tự nhận
    # "pluggable" trên nền GLIGEN; IPAdapterMixin.load_ip_adapter() là mixin
    # chung không ràng buộc attention_type. Mặc định TẮT (giữ nguyên hành vi
    # cũ) — bật cố ý qua cờ này, tên file xuất ra thêm hậu tố "_char".
    parser.add_argument("--with_character_slot", action="store_true",
                         help="Nap THEM IP-Adapter len CUNG unet GLIGEN - cho 1 NHAN VAT chinh giu danh tinh nhat quan TRONG CUNG panel co vat the nen can dung ty le. Xem muc 226 TECHNICAL_STATUS.md.")
    parser.add_argument("--ip_adapter_repo", default="h94/IP-Adapter",
                         help="Giong het export_ipa_controlnet_unet.py, chi dung khi --with_character_slot.")
    parser.add_argument("--ip_adapter_weight", default="ip-adapter_sd15.bin",
                         help="Giong het export_ipa_controlnet_unet.py, chi dung khi --with_character_slot.")
    parser.add_argument("--ip_scale", type=float, default=0.8,
                         help="Scale IP-Adapter DONG BANG luc export (khong co input runtime - khac export_ipa_controlnet_unet.py co ip_static_scale/decay; xem GIOI HAN THAT muc 226). Mac dinh 0.8 khop GenerationSettings.consistencyStrength; diffusers mac dinh 1.0 de ep qua manh len prompt chu. Chi dung khi --with_character_slot.")
    parser.add_argument("--output_dir", default="./exported_gligen")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device

    print(f"Đang tải {args.checkpoint} qua StableDiffusionGLIGENPipeline (cần mạng lần đầu)...")
    pipe = StableDiffusionGLIGENPipeline.from_pretrained(args.checkpoint)
    pipe.to(device)

    ip_image_embeds_example = None
    if args.with_character_slot:
        # mục 226 — gọi TRÊN CHÍNH pipe GLIGEN đã tải (IPAdapterMixin là mixin
        # chung, không ràng buộc attention_type của unet — xem docstring
        # AugmentedUNetGligen). Y HỆT cách export_ipa_controlnet_unet.py gọi.
        print(f"Đang nạp THÊM IP-Adapter ({args.ip_adapter_repo}) lên unet GLIGEN...")
        pipe.load_ip_adapter(args.ip_adapter_repo, subfolder="models", weight_name=args.ip_adapter_weight)
        # Đóng băng scale TRƯỚC khi trace (mirror cách export_ipa_controlnet_mask_unet_sdxl.py
        # làm với --char_scales, mục 178) — không có input runtime nào cho scale
        # ở model này (xem GIỚI HẠN THẬT mục 226).
        pipe.set_ip_adapter_scale(args.ip_scale)
        ip_image_embeds_example = probe_ip_adapter_embed_shape(pipe, device)

    unet = pipe.unet.eval()

    positive_len = probe_position_net_shapes(unet)
    print(f"Đã dò được positive_len={positive_len} thật từ unet.position_net (KHÔNG hardcode).")

    latent_size = args.image_size // 8
    cross_attention_dim = unet.config.cross_attention_dim
    example_sample = torch.randn(1, 4, latent_size, latent_size, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_encoder_hidden_states = torch.randn(1, 77, cross_attention_dim, device=device)
    # gligen_boxes: [batch, max_objs, 4], format [xmin,ymin,xmax,ymax] chuẩn
    # hoá [0,1] — ĐÚNG format `gligen_boxes` của StableDiffusionGLIGENPipeline
    # (xác nhận qua tài liệu chính thức), CŨNG là format Scene.objectBoxes
    # (Models.kt mục 222/223) đã dùng — không cần chuyển đổi thêm ở Kotlin.
    example_boxes = torch.rand(1, args.max_objs, 4, device=device)
    example_positive_embeddings = torch.randn(1, args.max_objs, positive_len, device=device)
    # gligen_masks: 1.0 = slot có vật thể thật, 0.0 = slot đệm (padding) —
    # suy luận từ cách GLIGEN dùng "masks" phổ biến trong các cơ chế
    # grounding có số lượng token thay đổi (giống attention_mask thông
    # thường) — CHƯA tự xác nhận 100% qua source thật (xem GIỚI HẠN THẬT).
    example_masks = torch.ones(1, args.max_objs, device=device)

    augmented = AugmentedUNetGligen(unet, with_character_slot=args.with_character_slot).to(device).eval()

    example_inputs = (example_sample, example_timestep, example_encoder_hidden_states,
                      example_boxes, example_positive_embeddings, example_masks)
    input_names = ["sample", "timestep", "encoder_hidden_states",
                   "gligen_boxes", "gligen_positive_embeddings", "gligen_masks"]
    if args.with_character_slot:
        # mục 226 — 2 dòng này là chỗ DUY NHẤT input thứ 7 xuất hiện trong
        # đồ thị ONNX: torch.onnx.export dựa đúng vào tuple example này (không
        # phải điều kiện runtime) — cùng cơ chế mục 219 đã dùng cho
        # location_ip_embeds/location_scale.
        example_inputs = example_inputs + (ip_image_embeds_example,)
        input_names = input_names + ["ip_image_embeds"]

    char_suffix = "_char" if args.with_character_slot else ""
    onnx_name = f"unet_gligen{char_suffix}.onnx"
    onnx_path = os.path.join(args.output_dir, onnx_name)
    print(f"Đang export ONNX -> {onnx_path}...")
    with torch.no_grad():
        # mục 97/217 đợt 1 TECHNICAL_STATUS.md — dynamo=False, xem lý do đầy
        # đủ ở các script export khác (torch >=2.9 đổi exporter mặc định).
        torch.onnx.export(
            augmented,
            example_inputs,
            onnx_path,
            input_names=input_names,
            output_names=["out_sample"],
            opset_version=17,
            dynamo=False,
        )

    print(f"\nXong: {onnx_path}")
    print(f"max_objs dùng lúc export (CỐ ĐỊNH, không dynamic_axes — đúng quy ước dự án): {args.max_objs}")
    print(f"positive_len (dò thật): {positive_len}")
    if args.with_character_slot:
        print(f"ip_image_embeds shape (dò thật): {tuple(ip_image_embeds_example.shape)}")
        print("NHẮC: ip_image_encoder.mnn (encode ảnh nhân vật -> embeds) DÙNG CHUNG với "
              "export_ipa_controlnet_unet.py — cùng checkpoint IP-Adapter nên cùng encoder, "
              "KHÔNG cần export thêm encoder mới cho model này.")
    print("\nBƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, onnx_name.replace('.onnx', '.mnn'))} --bizCode biz")
    print("\nQUAN TRỌNG — đọc GIỚI HẠN THẬT ở đầu file trước khi coi đây là 'xong':")
    print("CHƯA có native wrapper, CHƯA nối JNI/Kotlin, CHƯA có cách encode Scene.objectBoxes")
    print("thành đúng tensor 'gligen_positive_embeddings' (cần CHẠY text encoder CLIP cho")
    print("từng nhãn 'label' — xem VIỆC CÒN LẠI, mục 223 TECHNICAL_STATUS.md).")


if __name__ == "__main__":
    main()
