#!/usr/bin/env python3
"""mục 266 — kiểm NỐI DÂY TĨNH của API miễn phí (ảnh nền địa điểm, ảnh phác nhân vật, giám khảo ảnh qua API, thử lại 429) trên MÃ NGUỒN THẬT.

Vì sao tĩnh: UI Compose, MainViewModel và MangaPipeline không biên dịch được ở sandbox (không có Android SDK/Compose) — phần LÕI đã có test biên dịch thật
(test_free_image_api, test_http_retry, test_openai_json) và phần mạng được kiểm kiểu bằng stub (test_glue_typecheck). Test này canh những gì còn lại: đã NỐI chưa, tham số có khớp
giữa nơi gọi và nơi định nghĩa không, hành vi mặc định có còn nguyên không, khoá API có lọt vào nhật ký không.
KHÔNG chứng minh: build Android thành công, giao diện hiển thị đúng, hay API thật chấp nhận yêu cầu. Kèm thử phá mã (cố ý gỡ từng mối nối, bộ kiểm phải bắt được).
"""
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/')
def rd(rel): return open(os.path.join(P, rel), encoding='utf-8').read()
FILES = ['model/Models.kt', 'pipeline/FreeImageApi.kt', 'pipeline/FreeImageClient.kt', 'pipeline/ExternalLlmClient.kt', 'pipeline/HttpRetryExec.kt', 'pipeline/MangaPipeline.kt',
         'pipeline/VisionJudge.kt', 'ui/MainViewModel.kt', 'ui/LocationsScreen.kt', 'ui/CharactersScreen.kt', 'ui/SettingsScreen.kt', 'ui/ImageSourceDialog.kt']
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + str(d)[:300]) if (d and not c) else '')); ok &= bool(c)

def func_body(src, header_regex, span=6000):
    """Thân hàm bắt đầu từ header, kết thúc ở dấu } khớp với { đầu tiên sau header (ghép ngoặc nhọn) — KHÔNG kéo sang hàm kế bên.
    Không thấy -> chuỗi rỗng (các kiểm tra dựa vào nó sẽ FAIL chứ không đậu giả)."""
    m = re.search(header_regex, src)
    if not m: return ''
    i = src.find('{', m.end())
    if i < 0: return ''
    depth = 0
    for j in range(i, len(src)):
        c = src[j]
        if c == '{': depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0: return src[m.start():j + 1]
    return ''

def field_has_password(src, anchor):
    """Ô nhập chứa `anchor` (đoạn copy(...) của nó) phải có PasswordVisualTransformation trước ô nhập kế tiếp."""
    i = src.find(anchor)
    if i < 0: return False
    j = src.find('OutlinedTextField(', i + 1)
    seg = src[i: j if j > 0 else i + 900]
    return 'PasswordVisualTransformation' in seg

def run_checks(F):
    """Trả danh sách (tên kiểm tra, đạt?, chi tiết)."""
    R = []
    def add(n, c, d=''): R.append((n, bool(c), d))
    MD, API, CL, EL, EX, MP, VJ, VM, LS, CS, SS, DLG = (F[k] for k in FILES)

    # --- mặc định/hợp đồng dữ liệu
    m1 = re.search(r'const val CF_DEFAULT_MODEL = "([^"]+)"', API); m2 = re.search(r'data class FreeImageConfig\(.*?val cfModel: String = "([^"]+)"', MD, re.S)
    add('cfModel mặc định trong Models.kt == FreeImageApi.CF_DEFAULT_MODEL', m1 and m2 and m1.group(1) == m2.group(1), (m1 and m1.group(1), m2 and m2.group(1)))
    add('GenerationSettings có freeImage và visionJudgeApi (mặc định TẮT: ExternalLlmConfig() có enabled=false)',
        'val freeImage: FreeImageConfig = FreeImageConfig()' in MD and 'val visionJudgeApi: ExternalLlmConfig = ExternalLlmConfig()' in MD
        and re.search(r'data class ExternalLlmConfig\(\s*val enabled: Boolean = false', MD) is not None)
    add('ImageSource.CONFIGURED là nguồn mặc định ở mọi hàm (hành vi cũ giữ nguyên khi người dùng không chọn API)',
        MP.count('source: ImageSource = ImageSource.CONFIGURED') >= 2 and VM.count('ImageSource = ImageSource.CONFIGURED') >= 2)

    # --- UI -> ViewModel -> Pipeline: LOCATION
    add('LocationsScreen: nút "Tạo ảnh nền" mở ImageSourceDialog và gọi vm.generateLocationBackground(loc, src)',
        'ImageSourceDialog(' in LS and re.search(r'vm\.generateLocationBackground\(\s*loc\s*,\s*src\s*\)', LS) is not None and 'import com.mangalocal.pipeline.ImageSource' in LS)
    add('LocationsScreen: nút khoá khi đang tạo (locationBgBusy)', 'vm.locationBgBusy.collectAsState()' in LS and 'enabled = bgBusyId == null' in LS)
    vm_loc = func_body(VM, r'fun generateLocationBackground\(')
    add('MainViewModel.generateLocationBackground gọi pipeline.generateLocationBackground, lưu qua saveLocationAnchor, luôn nhả cờ bận (finally)',
        'pipeline.generateLocationBackground(location, story.worldRules, _settings.value, tmpDir, source)' in vm_loc and 'storyManager.saveLocationAnchor(story.id, location.id' in vm_loc
        and 'finally' in vm_loc and '_locationBgBusy.value = null' in vm_loc)
    add('MangaPipeline.generateLocationBackground tồn tại, nguồn API đi qua generateFreeImages với prompt KHÔNG NGƯỜI',
        re.search(r'suspend fun generateLocationBackground\(\s*location: Location, worldRules: String, settings: GenerationSettings, outDir: File, source: ImageSource', MP) is not None
        and 'FreeImageApi.locationPrompt(' in MP
        and re.search(r'generateFreeImages\(\s*source, settings, desc, FreeImageApi\.NO_PEOPLE_NEGATIVE', func_body(MP, r'suspend fun generateLocationBackground\(')) is not None)

    # --- UI -> ViewModel -> Pipeline: CHARACTER anchors
    add('CharactersScreen: 4 bản nháp chọn nguồn rồi gọi vm.generateAnchorCandidates(character, source = src)',
        'ImageSourceDialog(' in CS and re.search(r'vm\.generateAnchorCandidates\(character, source = src\)', CS) is not None and 'import com.mangalocal.pipeline.ImageSource' in CS)
    add('CharactersScreen: bản ngoại hình mới chọn nguồn rồi gọi vm.generateAnchorVersionCandidates(..., source = src)',
        re.search(r'vm\.generateAnchorVersionCandidates\(character, pv\.first, pv\.second, pv\.third, source = src\)', CS) is not None and 'pendingVersion' in CS)
    add('ViewModel nhớ nguồn đã chọn để "Sinh lại 4 bản khác" dùng lại (không bắt chọn lại, không rơi về mặc định)',
        '_lastAnchorSource = source' in VM and 'source: ImageSource = _lastAnchorSource' in VM and '_versionApprovalSource = source' in VM and 'source: ImageSource = _versionApprovalSource' in VM)
    add('ViewModel truyền source xuống pipeline cho cả hai luồng',
        'outDir, count, source)' in VM and re.search(r'story\.worldRules, _settings\.value, outDir, count, source\s*\)', VM) is not None)
    for fn in ('regenerateAnchorCandidates', 'generateAnchorVersionCandidates'):
        body = func_body(MP, r'suspend fun ' + fn + r'\(')
        add(f'MangaPipeline.{fn}: nhánh API đứng TRƯỚC nhánh cũ và dùng generateFreeImages; nhánh cũ (translateStagePrompt) còn nguyên',
            'if (source.freeProvider() != null)' in body and 'generateFreeImages(' in body and body.index('generateFreeImages(') < body.index('translateStagePrompt') and 'translateStagePrompt' in body)
    gen = func_body(MP, r'private suspend fun generateFreeImages\(')
    add('generateFreeImages: nghỉ giữa các lần theo minIntervalMs, lưu PNG, không nuốt lỗi (không có catch)',
        'FreeImageApi.minIntervalMs(' in gen and 'delay(gap)' in gen and 'saveFreeImageAsPng(' in gen and 'catch' not in gen)

    # --- Cài đặt
    for fld in ('cfAccountId', 'cfApiToken', 'cfModel', 'pollinationsKey'):
        add(f'SettingsScreen có ô nhập freeImage.{fld}', f'freeImage.copy({fld} = it)' in SS)
    for anchor in ('freeImage.copy(cfApiToken = it)', 'freeImage.copy(pollinationsKey = it)', 'visionJudgeApi.copy(apiKey = it)'):
        add(f'Ô {anchor.split("(")[1].split(" ")[0]} che ký tự (PasswordVisualTransformation)', field_has_password(SS, anchor))
    add('Giám khảo ảnh qua API: Checkbox + Base URL/API key/model trong Cài đặt',
        'visionJudgeApi.copy(enabled = it)' in SS and 'visionJudgeApi.copy(baseUrl = it)' in SS and 'visionJudgeApi.copy(apiKey = it)' in SS and 'visionJudgeApi.copy(modelName = it)' in SS)
    add('Cài đặt KHÔNG thêm Switch/Slider trần (test_param_help cấm) cho phần mới', not re.search(r'(?<![A-Za-z])Switch\(', SS))

    # --- Giám khảo ảnh qua API
    vj = func_body(MP, r'private fun visionJudgeReasonsViaApi\(')
    add('Giám khảo API: bỏ thẻ <img>đường_dẫn</img> trước khi gửi (đường dẫn nội bộ không rời máy) và gửi ảnh qua generateWithImage',
        'VisionJudge.stripImageTag(prompt)' in vj and 'client.generateWithImageBlocking(' in vj and 'MAX_ANSWER_TOKENS_API' in vj)
    add('MangaPipeline KHÔNG dùng runBlocking (tools/test_face_identity.py cấm trong luồng suspend; giám khảo API dùng bản chặn thuần executeBlocking)', 'runBlocking' not in MP)
    add('ExternalLlmClient có bản chặn generateWithImageBlocking dùng HttpRetryExec.executeBlocking; HttpRetryExec có cả execute lẫn executeBlocking',
        'fun generateWithImageBlocking(' in EL and 'HttpRetryExec.executeBlocking(client, chatRequest(body))' in EL and 'suspend fun execute(' in EX and 'fun executeBlocking(' in EX)
    add('Giám khảo API: lỗi KHÔNG làm hỏng sinh ảnh (catch Throwable -> vlmApiFailed = true, trả rỗng) và cờ được đặt lại mỗi lượt sinh',
        'catch (e: Throwable)' in vj and 'vlmApiFailed = true' in vj and 'vlmKeepAlive = true; vlmFailedDir = null; vlmApiFailed = false' in MP)
    add('visionJudgeReasons: API ưu tiên hơn model trên máy và nhánh cũ (thư mục model) còn nguyên',
        re.search(r'if \(settings\.visionJudgeApi\.enabled\) \{', MP) is not None and 'settings.visionJudgeModelDir.trim()' in MP and 'NativeBridge.llamaGenerate(h, prompt, VisionJudge.MAX_ANSWER_TOKENS, 0f)' in MP)
    add('Kết luận giám khảo dùng CHUNG một hàm (verdictToReasons) cho cả hai nhánh', MP.count('verdictToReasons(verdict, panel, expectedPeople, askContact, settings, detectedCount)') == 2)

    # --- Thử lại 429 + bí mật
    add('ExternalLlmClient dùng HttpRetryExec (thử lại 429) và OpenAiChatJson, không còn org.json',
        'HttpRetryExec.execute(client, chatRequest(jsonBody))' in EL and 'OpenAiChatJson.extractContent(' in EL and 'org.json' not in EL)
    add('FreeImageClient dùng HttpRetryExec', 'HttpRetryExec.execute(' in CL)
    add('HttpRetryExec: lỗi mạng giữa chừng đặt code = NETWORK_ERROR (không coi là thành công với thân rỗng)', 'code = HttpRetryPolicy.NETWORK_ERROR' in func_body(EX, r'catch \(e: IOException\)', 300))
    leak = []
    for name, src in (('MangaPipeline', MP), ('FreeImageClient', CL), ('ExternalLlmClient', EL), ('HttpRetryExec', EX), ('MainViewModel', VM)):
        for m in re.finditer(r'\blog\(([^\n]*)\)|Log\.[dievw]\(([^\n]*)\)|println\(([^\n]*)\)', src):
            line = m.group(0)
            if re.search(r'cfApiToken|pollinationsKey|apiKey|Authorization|creds\.|\.freeImage\b|visionJudgeApi\.apiKey', line): leak.append((name, line[:100]))
    add('Không dòng nhật ký nào in khoá/token/creds', not leak, leak)
    add('Header Authorization chỉ xuất hiện ở nơi dựng yêu cầu (FreeImageApi.buildRequest / ExternalLlmClient), không rải rác', 'Authorization' not in MP and 'Authorization' not in VM)
    return R

SRC = {k: rd(k) for k in FILES}
res = run_checks(SRC)
for n, c, d in res: check(n, c, d)
base_fail = [n for n, c, d in res if not c]

# ---- thử phá mã: gỡ từng mối nối trên BẢN CHÉP TRONG BỘ NHỚ; bộ kiểm phải bắt
def mut(key, old, new, name):
    return (name, key, old, new)
MUTS = [
    mut('ui/LocationsScreen.kt', 'vm.generateLocationBackground(loc, src)', 'vm.generateLocationBackground(loc, ImageSource.CONFIGURED)', 'LocationsScreen bỏ qua nguồn người dùng chọn'),
    mut('ui/LocationsScreen.kt', 'enabled = bgBusyId == null,', '', 'LocationsScreen không khoá nút khi đang tạo'),
    mut('ui/CharactersScreen.kt', 'vm.generateAnchorCandidates(character, source = src)', 'vm.generateAnchorCandidates(character)', 'CharactersScreen không truyền nguồn cho 4 bản nháp'),
    mut('ui/CharactersScreen.kt', 'pv.first, pv.second, pv.third, source = src)', 'pv.first, pv.second, pv.third)', 'CharactersScreen không truyền nguồn cho bản ngoại hình'),
    mut('ui/MainViewModel.kt', 'source: ImageSource = _lastAnchorSource', 'source: ImageSource = ImageSource.CONFIGURED', '"Sinh lại 4 bản khác" rơi về nguồn mặc định'),
    mut('ui/MainViewModel.kt', '_locationBgBusy.value = null', '', 'ViewModel không nhả cờ bận (nút khoá vĩnh viễn)'),
    mut('ui/MainViewModel.kt', 'java.io.File(path).copyTo(dest, overwrite = true)\n                    storyManager.saveLocationAnchor(story.id, location.id', 'java.io.File(path).copyTo(dest, overwrite = true)\n                    storyManager.saveLocationAnchorX(story.id, location.id', 'ViewModel không lưu ảnh neo bối cảnh'),
    mut('pipeline/MangaPipeline.kt', 'FreeImageApi.NO_PEOPLE_NEGATIVE, 1024, 768', 'FreeImageApi.CHARACTER_NEGATIVE, 1024, 768', 'ảnh nền dùng âm bản nhân vật (người lọt vào nền)'),
    mut('pipeline/MangaPipeline.kt', 'if (i > 0 && gap > 0L) delay(gap)', '', 'bỏ khoảng nghỉ giữa các lần gọi (dính giới hạn Pollinations)'),
    mut('pipeline/MangaPipeline.kt', 'VisionJudge.stripImageTag(prompt)', 'prompt', 'giám khảo API gửi cả đường dẫn nội bộ ra ngoài'),
    mut('pipeline/MangaPipeline.kt', 'client.generateWithImageBlocking(VisionJudge.stripImageTag(prompt)', 'runBlocking { client.generateWithImageBlocking(VisionJudge.stripImageTag(prompt)', 'giám khảo API quay lại dùng runBlocking (vi phạm quy tắc test_face_identity)'),
    mut('pipeline/ExternalLlmClient.kt', 'HttpRetryExec.executeBlocking(client, chatRequest(body))', 'HttpRetryExec.executeBlocking(client, chatRequest(body), maxAttempts = 1)', 'bản chặn không thử lại (maxAttempts = 1)'),
    mut('pipeline/MangaPipeline.kt', 'vlmApiFailed = false   // mục 259', '   // mục 259', 'cờ lỗi giám khảo API không đặt lại mỗi lượt'),
    mut('pipeline/MangaPipeline.kt', '        if (settings.visionJudgeApi.enabled) {\n            if (expectedPeople <= 0 || vlmApiFailed) return emptyList()', '        if (false) {\n            if (expectedPeople <= 0 || vlmApiFailed) return emptyList()', 'giám khảo API không bao giờ được gọi'),
    mut('pipeline/MangaPipeline.kt', '    ): List<String> {\n        val provider = source.freeProvider() ?: throw IllegalArgumentException("Nguồn ${source.name} không phải API miễn phí")', '    ): List<String> {\n        try { val provider = source.freeProvider() ?: throw IllegalArgumentException("Nguồn ${source.name} không phải API miễn phí") } catch (e: Exception) { return emptyList() }\n        val provider = source.freeProvider()!!', 'generateFreeImages nuốt lỗi (người dùng không biết lý do)'),
    mut('pipeline/ExternalLlmClient.kt', 'HttpRetryExec.execute(client, chatRequest(jsonBody))', 'HttpResult(200, null, ByteArray(0))', 'ExternalLlmClient quay lại không thử lại 429'),
    mut('pipeline/HttpRetryExec.kt', 'code = HttpRetryPolicy.NETWORK_ERROR   //', 'val unused = 0   //', 'lỗi giữa chừng khi đọc thân bị coi là thành công'),
    mut('pipeline/FreeImageClient.kt', 'HttpRetryExec.execute(client, { toRequest(spec) }, onWait = onWait)', 'HttpResult(200, null, ByteArray(0))', 'FreeImageClient không gọi mạng/không thử lại'),
    mut('pipeline/MangaPipeline.kt', 'log("  ⏳ ${provider.label}: $it")', 'log("  ⏳ ${provider.label} ${creds.cfApiToken}: $it")', 'nhật ký in token Cloudflare'),
    mut('ui/SettingsScreen.kt', 'visionJudgeApi.copy(apiKey = it)', 'visionJudgeApi.copy(baseUrl = it)', 'ô API key giám khảo ghi nhầm vào Base URL'),
    mut('model/Models.kt', 'val cfModel: String = "@cf/black-forest-labs/flux-1-schnell"', 'val cfModel: String = "@cf/black-forest-labs/flux-1-schnell-x"', 'mặc định model Cloudflare lệch với FreeImageApi'),
    mut('ui/SettingsScreen.kt', 'label = { Text("Cloudflare API Token (quyền Workers AI)") },\n                        singleLine = true, modifier = Modifier.fillMaxWidth(),\n                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()', 'label = { Text("Cloudflare API Token (quyền Workers AI)") },\n                        singleLine = true, modifier = Modifier.fillMaxWidth()', 'token Cloudflare hiện rõ trên màn hình'),
]
killed = ran = 0
for name, key, old, new in MUTS:
    if SRC[key].count(old) != 1:
        check(f'đột biến có điểm cắm duy nhất: {name}', False, f'{SRC[key].count(old)} chỗ'); continue
    F2 = dict(SRC); F2[key] = SRC[key].replace(old, new)
    r2 = run_checks(F2); ran += 1
    fails = [n for n, c, d in r2 if not c]
    caught = bool(set(fails) - set(base_fail))
    check(f'đột biến "{name}" bị bắt', caught)
    killed += caught
check(f'thử phá mã: {killed}/{ran} đột biến bị bắt', ran > 0 and killed == ran)
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
