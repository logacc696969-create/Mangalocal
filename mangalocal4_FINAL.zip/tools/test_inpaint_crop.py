#!/usr/bin/env python3
"""Mô phỏng Python (mục 237 TECHNICAL_STATUS.md) cho InpaintCompose.planCrop / remapSkeleton / blendInto
và phép ánh xạ toạ độ vùng -> crop -> dán lại trong MangaPipeline.inpaintRegionCropped().

Chép lại NGUYÊN công thức từ InpaintCompose.kt (không có kotlinc trong sandbox) nên kiểm chứng HÌNH HỌC và SỐ HỌC,
không phải biên dịch Kotlin. Quan trọng nhất là các bất biến: (1) crop luôn chứa trọn vùng và nằm trong ảnh,
(2) toạ độ khung xương sau remap trùng đúng pixel với toạ độ vùng sau ánh xạ, (3) dán lại KHÔNG đổi pixel ngoài mask.
Sửa Kotlin thì sửa lại file này."""
import random
try:
    import numpy as np
except ImportError:
    np = None

def plan_crop(rect, W, H, target, pad=1.6, min_side=192, min_gain=1.35):
    l, t, r, b = rect
    if W <= 0 or H <= 0 or target <= 0 or r - l <= 0 or b - t <= 0: return None
    max_side = min(W, H)
    side = int(max(r - l, b - t) * pad)
    side = max(side, min_side); side = min(side, max_side)
    if target / side < min_gain: return None
    cx, cy = (l + r) // 2, (t + b) // 2
    left = min(max(cx - side // 2, 0), W - side); top = min(max(cy - side // 2, 0), H - side)
    if l < left or r > left + side or t < top or b > top + side: return None
    return (left, top, left + side, top + side)

def remap(sk, W, H, left, top, side):
    out = list(sk)
    for i in range(0, len(out) - 3, 4):
        out[i] = (sk[i] * W - left) / side
        out[i + 1] = (sk[i + 1] * H - top) / side
    return out

def check(n, c):
    print(('PASS ' if c else 'FAIL ') + n); return c

def main():
    ok = True
    # --- planCrop ---
    c = plan_crop((100, 100, 220, 220), 512, 512, 512)
    ok &= check('vùng 120px trên panel 512 -> có crop', c is not None)
    ok &= check('crop vuông, trong ảnh', c and (c[2]-c[0]) == (c[3]-c[1]) and c[0] >= 0 and c[1] >= 0 and c[2] <= 512 and c[3] <= 512)
    ok &= check('crop chứa trọn vùng', c and c[0] <= 100 and c[1] <= 100 and c[2] >= 220 and c[3] >= 220)
    ok &= check('hệ số phóng >= 1.35', c and 512 / (c[2]-c[0]) >= 1.35)
    ok &= check('vùng lớn 300px -> không crop (lợi ít)', plan_crop((100, 100, 400, 400), 512, 512, 512) is None)
    ok &= check('vùng sát góc trái-trên vẫn crop hợp lệ', (lambda r: r and r[0] == 0 and r[1] == 0)(plan_crop((0, 0, 60, 60), 512, 512, 512)))
    ok &= check('vùng sát góc phải-dưới vẫn trong ảnh', (lambda r: r and r[2] <= 512 and r[3] <= 512 and r[2] == 512)(plan_crop((460, 460, 512, 512), 512, 512, 512)))
    ok &= check('SDXL 1024: vùng 200px -> có crop', plan_crop((300, 300, 500, 500), 1024, 1024, 1024) is not None)
    ok &= check('rect rỗng -> null', plan_crop((10, 10, 10, 50), 512, 512, 512) is None)
    ok &= check('ảnh nhỏ hơn minSide: side kẹp theo ảnh, không vượt', (lambda r: r is None or (r[2]-r[0]) <= 160)(plan_crop((10, 10, 60, 60), 160, 160, 512)))
    ok &= check('panel không vuông 512x768: crop vẫn trong ảnh', (lambda r: r and r[3] <= 768 and r[2] <= 512)(plan_crop((200, 600, 330, 740), 512, 768, 512)))
    rnd = random.Random(7); good = True; n_crop = 0
    for _ in range(3000):
        W = rnd.choice([512, 768, 1024]); H = rnd.choice([512, 768, 1024])
        w = rnd.randint(20, 400); h = rnd.randint(20, 400)
        l = rnd.randint(0, max(0, W - w)); t = rnd.randint(0, max(0, H - h))
        rect = (l, t, min(W, l + w), min(H, t + h)); tgt = min(W, H, 768) // 8 * 8
        r = plan_crop(rect, W, H, tgt)
        if r is None: continue
        n_crop += 1
        s = r[2] - r[0]
        good &= (s == r[3] - r[1]) and r[0] >= 0 and r[1] >= 0 and r[2] <= W and r[3] <= H \
                and r[0] <= rect[0] and r[1] <= rect[1] and r[2] >= rect[2] and r[3] >= rect[3] and tgt / s >= 1.35 - 1e-9
    ok &= check(f'3000 ca ngẫu nhiên: mọi crop hợp lệ (có {n_crop} crop)', good and n_crop > 100)

    # --- remap khung xương trùng pixel với ánh xạ vùng ---
    W = H = 512; crop = plan_crop((150, 200, 270, 320), W, H, 512); left, top, _, _ = crop; side = crop[2] - crop[0]; f = 512 / side
    sk = [220 / W, 260 / H, 0.0, 1.0]
    sk2 = remap(sk, W, H, left, top, side)
    px_from_sk = (sk2[0] * 512, sk2[1] * 512)
    px_from_rect = ((220 - left) * f, (260 - top) * f)
    ok &= check('điểm khung xương sau remap trùng pixel ánh xạ từ toạ độ ảnh', abs(px_from_sk[0] - px_from_rect[0]) < 1e-3 and abs(px_from_sk[1] - px_from_rect[1]) < 1e-3)
    ok &= check('z và visible giữ nguyên khi remap', sk2[2] == 0.0 and sk2[3] == 1.0)

    # --- blend: pixel ngoài mask KHÔNG đổi, trong mask hoà theo m ---
    if np is None:
        print('(bỏ qua test numpy: không có numpy)')
    else:
        rng = np.random.default_rng(1)
        base = rng.integers(0, 256, (200, 200, 3), dtype=np.uint8)
        side = 80; patch = np.full((side, side, 3), 255, np.uint8)
        mask = np.zeros((side, side), np.uint8); mask[20:60, 20:60] = 255; mask[30:50, 30:50] = 255
        mask[20:60, 20:24] = 128  # biên mềm
        L, T = 50, 60
        out = base.astype(np.int32).copy()
        sub = out[T:T+side, L:L+side]
        m = mask.astype(np.int32)[..., None]
        sub[:] = (sub * (255 - m) + patch.astype(np.int32) * m) // 255
        out = out.astype(np.uint8)
        outside = np.ones((200, 200), bool); outside[T:T+side, L:L+side] = False
        ok &= check('dán lại: pixel ngoài vùng crop không đổi', np.array_equal(out[outside], base[outside]))
        mz = np.zeros((200, 200), bool); mz[T:T+side, L:L+side] = (mask == 0)
        ok &= check('dán lại: pixel trong crop nhưng ngoài mask không đổi', np.array_equal(out[mz], base[mz]))
        full = np.zeros((200, 200), bool); full[T+30:T+50, L+30:L+50] = True
        ok &= check('dán lại: lõi mask trắng = patch', bool((out[full] == 255).all()))
        soft = out[T+25, L+21].astype(int); b0 = base[T+25, L+21].astype(int)
        ok &= check('dán lại: biên mềm nằm giữa gốc và patch', bool(((soft >= np.minimum(b0, 255)) & (soft <= 255)).all()) and not np.array_equal(soft, b0))

    print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'); raise SystemExit(0 if ok else 1)

if __name__ == '__main__':
    main()
