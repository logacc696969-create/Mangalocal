#!/usr/bin/env python3
# mục 281 — BIÊN DỊCH và CHẠY mã Kotlin thật (tools/kotlin_tests/BundledModelsTest.kt) cho BundledModels (chép model đóng trong APK ra thư mục model, "chép nếu chưa có"),
# kèm phép phá mã. Không có kotlinc thì BỎ QUA và nói rõ. Phần nối dây (assets, Gradle, giao diện) ở test_blazepose_wiring.py; model trong assets chạy đúng ở test_blazepose_lift.py.
import os, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline/BundledModels.kt'); TST = os.path.join(ROOT, 'tools/kotlin_tests/BundledModelsTest.kt')
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)
kc = next((c for c in (os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/tools/kotlinc/bin/kotlinc', '/home/claude/work/kotlinc/bin/kotlinc') if c and os.path.exists(c)), None)
if not kc: print('BỎ QUA: không có kotlinc (đặt KOTLINC=/đường/dẫn/kotlinc, bản 1.9.x).'); sys.exit(0)
def run(src_path):
    with tempfile.TemporaryDirectory() as td:
        jar = os.path.join(td, 't.jar')
        r = subprocess.run([kc, '-nowarn', TST, src_path, '-include-runtime', '-d', jar], capture_output=True, text=True)
        if r.returncode != 0: return None
        return subprocess.run(['java', '-Dstdout.encoding=UTF-8', '-jar', jar], capture_output=True, text=True).stdout
o = run(SRC)
check(o is not None, 'biên dịch BundledModels.kt + test')
if o is not None:
    bad = [l for l in o.splitlines() if l.startswith('FAIL')]; n = sum(1 for l in o.splitlines() if l.startswith('PASS'))
    for l in bad: print(l)
    check(not bad and n >= 10 and 'ĐẠT (' in o, f'mã Kotlin thật: {n} phép kiểm đạt, {len(bad)} lỗi')
src = open(SRC, encoding='utf-8').read()
muts = [
    ('ghi đè model của người dùng', 'names.any { File(dir, it).exists() }) return 0', 'false) return 0'),
    ('bỏ tệp tạm .part: không dọn khi lỗi', 'try { tmp.delete() } catch (_: Exception) {}', ''),
    ('chấp nhận tệp rỗng', 'tmp.length() > 0L && tmp.renameTo(dst)', 'tmp.renameTo(dst)'),
    ('ném lại lỗi thay vì bỏ qua', 'try { tmp.delete() } catch (_: Exception) {}', 'throw e'),
    ('đếm sai số tệp đã chép', 'copied++', 'copied += 2'),
    ('không tạo thư mục', 'if (!dir.isDirectory && !dir.mkdirs()) return 0', ''),
]
caught = 0
for name, old, new in muts:
    assert old in src, name
    with tempfile.TemporaryDirectory() as td:
        mp = os.path.join(td, 'BundledModels.kt'); open(mp, 'w', encoding='utf-8').write(src.replace(old, new, 1)); out = run(mp)
    bad = out is None or 'ĐẠT (' not in out or any(l.startswith('FAIL') for l in out.splitlines())   # sập giữa chừng (không in dòng ĐẠT) cũng là hỏng
    caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name)
check(caught == len(muts), f'đột biến: {caught}/{len(muts)} bị bắt')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
