#!/usr/bin/env python3
"""Mô phỏng Python của ContactDetector.kt (mục 227 + sửa bố cục ở mục 231 TECHNICAL_STATUS.md).

BỐ CỤC THẬT: 18 khớp × (x, y, z, visible 0/1) — khớp với MangaPipeline.resolveSkeletonData()
và struct Keypoint native. Bản đầu của file này dùng (x, y, conf, z) SAI nên các test "đạt"
mà không chứng minh gì về code thật.


KHÔNG phải test của chính code Kotlin — sandbox không có kotlinc. Đây là bản
chép lại NGUYÊN CÔNG THỨC sang Python để kiểm chứng phần hình học (ngưỡng,
thứ tự ưu tiên, khử trùng, chặn số vùng) với các tình huống dựng tay, đúng
quy trình mục 113/118 đã dùng. Nếu sửa ContactDetector.kt, sửa lại file này.
"""
import math

FPP = 18 * 4
VIS = 0.5
Z_TOL_FRACTION, Z_MEANINGFUL = 0.5, 0.02
TORSO_PAD = 0.15
HAND_NEAR_NECK, HAND_NEAR_HEAD, HEAD_NEAR_HEAD, LEG_NEAR_HIP = 0.55, 0.70, 0.60, 0.50
MIN_HALF, HALF_PER_BODY, DEDUP_IOU = 0.05, 0.40, 0.35


def build_body(data, idx):
    base = idx * FPP
    if base + FPP > len(data):
        return None
    j = [(data[base + k * 4], data[base + k * 4 + 1], data[base + k * 4 + 2], data[base + k * 4 + 3]) for k in range(18)]
    vis = lambda p: p[3] > VIS
    rsh, lsh, rhip, lhip = j[2], j[5], j[8], j[11]
    if not all(vis(p) for p in (rsh, lsh, rhip, lhip)):
        return None
    xs = [rsh[0], lsh[0], rhip[0], lhip[0]]
    ys = [rsh[1], lsh[1], rhip[1], lhip[1]]
    bw = (max(xs) - min(xs)) * TORSO_PAD
    bh = (max(ys) - min(ys)) * TORSO_PAD
    shoulder_w = math.hypot(rsh[0] - lsh[0], rsh[1] - lsh[1])
    torso_h = abs((rhip[1] + lhip[1]) / 2 - (rsh[1] + lsh[1]) / 2)
    size = max(0.05, (shoulder_w + torso_h) / 2)
    head = [j[i] for i in (0, 14, 15, 16, 17) if vis(j[i])]
    has_head = bool(head)
    hx = sum(p[0] for p in head) / len(head) if head else j[1][0]
    hy = sum(p[1] for p in head) / len(head) if head else j[1][1]
    z_torso = (rsh[2] + lsh[2] + rhip[2] + lhip[2]) / 4
    z_head = sum(p[2] for p in head) / len(head) if head else j[1][2]
    return dict(idx=idx, z_torso=z_torso, z_head=z_head, j=j, tl=min(xs) - bw, tt=min(ys) - bh, tr=max(xs) + bw, tb=max(ys) + bh,
                size=size, hx=hx, hy=hy, has_head=has_head or vis(j[1]))


def in_torso(b, p):
    return b['tl'] <= p[0] <= b['tr'] and b['tt'] <= p[1] <= b['tb']


def region(cx, cy, ex, ey, half, w, h):
    m = min(w, h)
    hp = half * m
    l, r, t, b = cx * w - hp, cx * w + hp, cy * h - hp, cy * h + hp
    if ex is not None:
        l = min(l, ex * w - hp * 0.6); r = max(r, ex * w + hp * 0.6)
        t = min(t, ey * h - hp * 0.6); b = max(b, ey * h + hp * 0.6)
    cl = lambda v, hi: max(0, min(int(v), hi))
    return (cl(l, w), cl(t, h), cl(r, w), cl(b, h))


def iou(a, b):
    l, t, r, bo = max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])
    if r <= l or bo <= t:
        return 0.0
    inter = (r - l) * (bo - t)
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return 0.0 if union <= 0 else inter / union


def detect(data, n_expected, w, h, existing=(), max_regions=4, sensitivity=1.0):
    if n_expected < 2 or not data:
        return []
    sens = min(1.5, max(0.5, sensitivity))  # mục 257 — cùng kẹp với bản Kotlin
    n = min(n_expected, len(data) // FPP)
    if n < 2:
        return []
    bodies = [b for b in (build_body(data, i) for i in range(n)) if b]
    if len(bodies) < 2:
        return []
    zs = [p[2] for b in bodies for p in b['j'] if p[3] > VIS]
    z_range = (max(zs) - min(zs)) if zs else 0.0
    use_z = z_range > Z_MEANINGFUL
    z_ok = lambda jz, tz: (not use_z) or abs(jz - tz) <= Z_TOL_FRACTION * z_range
    raw, order = [], 0
    for a in bodies:
        for b in bodies:
            if a['idx'] == b['idx']:
                continue
            half = max(MIN_HALF, HALF_PER_BODY * a['size'])
            for wi in (4, 7):
                wr = a['j'][wi]
                if wr[3] <= VIS or not b['has_head']:
                    continue
                neck = b['j'][1]
                d_neck = math.hypot(wr[0] - neck[0], wr[1] - neck[1]) / b['size'] if neck[3] > VIS else 1e30
                d_head = math.hypot(wr[0] - b['hx'], wr[1] - b['hy']) / b['size']
                if (d_neck < (HAND_NEAR_NECK * sens) or d_head < (HAND_NEAR_HEAD * sens)) and z_ok(wr[2], b['z_head']):
                    raw.append((dict(rect=region(wr[0], wr[1], b['hx'], b['hy'], half, w, h), kind='hand_at_head_neck',
                                     actor=a['idx'], target=b['idx'], pri=0), min(d_neck, d_head), order)); order += 1
            nose = a['j'][0]
            if nose[3] > VIS and b['has_head']:
                d = math.hypot(nose[0] - b['hx'], nose[1] - b['hy']) / b['size']
                if (d < (HEAD_NEAR_HEAD * sens) or in_torso(b, nose)) and z_ok(nose[2], b['z_head']):
                    raw.append((dict(rect=region(nose[0], nose[1], b['hx'], b['hy'], half, w, h), kind='head_contact',
                                     actor=a['idx'], target=b['idx'], pri=0), d, order)); order += 1
            hmx = (b['j'][8][0] + b['j'][11][0]) / 2
            hmy = (b['j'][8][1] + b['j'][11][1]) / 2
            for ki in (9, 12):
                k = a['j'][ki]
                if k[3] <= VIS:
                    continue
                d = math.hypot(k[0] - hmx, k[1] - hmy) / b['size']
                if (in_torso(b, k) or d < (LEG_NEAR_HIP * sens)) and z_ok(k[2], b['z_torso']):
                    raw.append((dict(rect=region(k[0], k[1], None, None, half, w, h), kind='knee_on_body',
                                     actor=a['idx'], target=b['idx'], pri=1), d, order)); order += 1
            for ai in (10, 13):
                f = a['j'][ai]
                if f[3] > VIS and in_torso(b, f) and z_ok(f[2], b['z_torso']):
                    raw.append((dict(rect=region(f[0], f[1], None, None, half, w, h), kind='foot_on_body',
                                     actor=a['idx'], target=b['idx'], pri=1), 0.0, order)); order += 1
            for ei in (3, 6):
                e = a['j'][ei]
                if e[3] > VIS and in_torso(b, e) and z_ok(e[2], b['z_torso']):
                    raw.append((dict(rect=region(e[0], e[1], None, None, half, w, h), kind='elbow_on_body',
                                     actor=a['idx'], target=b['idx'], pri=2), 0.0, order)); order += 1
    ok = [r for r in raw if r[0]['rect'][2] - r[0]['rect'][0] > 0 and r[0]['rect'][3] - r[0]['rect'][1] > 0]
    ok.sort(key=lambda r: (r[0]['pri'], r[1], r[2]))
    kept = []
    for c, _, _ in ok:
        if len(kept) >= max_regions:
            break
        if any(iou(e, c['rect']) > DEDUP_IOU for e in existing):
            continue
        if any(iou(k['rect'], c['rect']) > DEDUP_IOU for k in kept):
            continue
        kept.append(c)
    return kept


def person(cx, top, scale=1.0, overrides=None, z=0.0, z_over=None):
    """Người đứng thẳng chuẩn hoá: đầu ở top, thân cao ~0.45*scale. Trả 72 float."""
    s = scale
    pts = {
        0: (cx, top), 1: (cx, top + 0.08 * s),
        2: (cx - 0.07 * s, top + 0.10 * s), 5: (cx + 0.07 * s, top + 0.10 * s),
        3: (cx - 0.10 * s, top + 0.22 * s), 6: (cx + 0.10 * s, top + 0.22 * s),
        4: (cx - 0.11 * s, top + 0.33 * s), 7: (cx + 0.11 * s, top + 0.33 * s),
        8: (cx - 0.04 * s, top + 0.32 * s), 11: (cx + 0.04 * s, top + 0.32 * s),
        9: (cx - 0.04 * s, top + 0.48 * s), 12: (cx + 0.04 * s, top + 0.48 * s),
        10: (cx - 0.04 * s, top + 0.64 * s), 13: (cx + 0.04 * s, top + 0.64 * s),
        14: (cx - 0.01 * s, top - 0.01 * s), 15: (cx + 0.01 * s, top - 0.01 * s),
        16: (cx - 0.02 * s, top), 17: (cx + 0.02 * s, top),
    }
    if overrides:
        pts.update(overrides)
    out = []
    for i in range(18):
        x, y = pts[i]
        zi = (z_over or {}).get(i, z)
        out += [x, y, zi, 1.0]   # (x, y, z, visible)
    return out


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    return cond


def main():
    W = H = 1000
    ok = True

    # 1. Hai người đứng xa nhau: không có tiếp xúc.
    d = person(0.2, 0.1) + person(0.8, 0.1)
    ok &= check("xa nhau -> 0 vùng", detect(d, 2, W, H) == [])

    # 2. A đặt cổ tay phải lên cổ B (khoá cổ) -> hand_at_head_neck, ưu tiên 0.
    b = person(0.6, 0.1)
    neck_b = (0.6, 0.18)
    a = person(0.4, 0.1, overrides={4: (neck_b[0] - 0.02, neck_b[1] + 0.01)})
    r = detect(a + b, 2, W, H)
    ok &= check("khoá cổ -> có hand_at_head_neck", any(x['kind'] == 'hand_at_head_neck' and x['actor'] == 0 for x in r))
    ok &= check("khoá cổ -> đứng đầu danh sách (ưu tiên 0)", bool(r) and r[0]['pri'] == 0)

    # 3. A đưa đầu gối phải vào bụng B -> knee_on_body.
    b = person(0.6, 0.1)
    a = person(0.4, 0.1, overrides={9: (0.6, 0.30)})
    r = detect(a + b, 2, W, H)
    ok &= check("gối vào bụng -> knee_on_body", any(x['kind'] == 'knee_on_body' and x['actor'] == 0 for x in r))

    # 4. A đá: mắt cá vào ngực B -> foot_on_body.
    a = person(0.4, 0.1, overrides={10: (0.6, 0.27)})
    r = detect(a + b, 2, W, H)
    ok &= check("đá vào ngực -> foot_on_body", any(x['kind'] == 'foot_on_body' for x in r))

    # 5. A ghì khuỷu vào ngực B -> elbow_on_body.
    a = person(0.4, 0.1, overrides={3: (0.6, 0.26)})
    r = detect(a + b, 2, W, H)
    ok &= check("khuỷu vào ngực -> elbow_on_body", any(x['kind'] == 'elbow_on_body' for x in r))

    # 6. Khử trùng với vùng đã có: đặt existing trùng vùng knee -> không thêm.
    a = person(0.4, 0.1, overrides={9: (0.6, 0.30)})
    r0 = detect(a + b, 2, W, H)
    knee = [x for x in r0 if x['kind'] == 'knee_on_body'][0]['rect']
    r1 = detect(a + b, 2, W, H, existing=[knee])
    ok &= check("vùng trùng existing bị loại", all(x['kind'] != 'knee_on_body' or iou(x['rect'], knee) <= DEDUP_IOU for x in r1))

    # 7. Chặn số vùng.
    a = person(0.4, 0.1, overrides={9: (0.6, 0.30), 12: (0.58, 0.45), 10: (0.62, 0.27), 3: (0.55, 0.20)})
    r = detect(a + b, 2, W, H, max_regions=2)
    ok &= check("max_regions=2 -> tối đa 2 vùng", len(r) <= 2)

    # 8. mục 257 — độ nhạy (sensitivity): mặc định 1.0 không đổi kết quả; tăng thì KHÔNG mất vùng nào, giảm thì không thêm vùng nào.
    import itertools
    b8 = person(0.6, 0.1)
    flips_up = flips_down = 0; mono = True; clamp_ok = True
    grid = [(x / 40.0, y / 40.0) for x, y in itertools.product(range(8, 32), range(2, 30))]
    for (hx, hy) in grid:
        a8 = person(0.4, 0.1, overrides={4: (hx, hy)})
        def kinds(sv):
            return {(x['kind'], x['actor']) for x in detect(a8 + b8, 2, W, H, max_regions=8, sensitivity=sv)
                    if x['kind'] == 'hand_at_head_neck'}
        lo, mid, hi = kinds(0.5), kinds(1.0), kinds(1.5)
        mono &= lo <= mid <= hi
        flips_down += (lo != mid); flips_up += (mid != hi)
        clamp_ok &= (kinds(0.0) == lo) and (kinds(9.0) == hi)
    ok &= check("độ nhạy: 0.5 ⊆ 1.0 ⊆ 1.5 trên lưới vị trí tay (đơn điệu)", mono)
    ok &= check("độ nhạy: có vị trí tay mà 0.5 bỏ lỡ nhưng 1.0 bắt được (hạ độ nhạy có tác dụng thật)", flips_down > 0)
    ok &= check("độ nhạy: có vị trí tay mà 1.0 bỏ lỡ nhưng 1.5 bắt được (tăng độ nhạy có tác dụng thật)", flips_up > 0)
    ok &= check("độ nhạy: giá trị ngoài [0.5,1.5] bị kẹp (0.0 như 0.5; 9.0 như 1.5)", clamp_ok)
    base = person(0.4, 0.1, overrides={9: (0.6, 0.30)})
    ok &= check("độ nhạy mặc định 1.0 trùng kết quả gọi không tham số", detect(base + b8, 2, W, H) == detect(base + b8, 2, W, H, sensitivity=1.0))
    kt = open(__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.dirname(__import__('os').path.abspath(__file__))),
              'app/src/main/java/com/mangalocal/pipeline/ContactDetector.kt'), encoding='utf-8').read()
    det = kt[kt.index('fun detect('):kt.index('fun promptFor(')]
    ok &= check("Kotlin: 4 khoảng cách chạm đều nhân `sens` trong detect, kẹp [0.5,1.5]",
                all(('(Thresholds.' + v + ' * sens)') in det for v in ['HAND_NEAR_NECK', 'HAND_NEAR_HEAD', 'HEAD_NEAR_HEAD', 'LEG_NEAR_HIP'])
                and 'sensitivity.coerceIn(0.5f, 1.5f)' in det)
    pp = open(__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.dirname(__import__('os').path.abspath(__file__))),
              'app/src/main/java/com/mangalocal/pipeline/MangaPipeline.kt'), encoding='utf-8').read()
    ok &= check("nối dây: MangaPipeline truyền settings.contactSensitivity vào ContactDetector.detect", 'sensitivity = settings?.contactSensitivity ?: 1f' in pp)

    # 8. Thiếu khớp hông/vai -> bỏ qua người đó, không lỗi.
    bad = list(person(0.4, 0.1))
    for k in (2, 5, 8, 11):
        bad[k * 4 + 3] = 0.0
    ok &= check("thiếu khớp thân -> 0 vùng, không lỗi", detect(bad + person(0.6, 0.1), 2, W, H) == [])

    # 9. 3 người hỗn chiến: không vượt max_regions, mọi rect nằm trong ảnh.
    p1 = person(0.30, 0.1, overrides={4: (0.5, 0.19), 9: (0.5, 0.31)})
    p2 = person(0.50, 0.1)
    p3 = person(0.70, 0.1, overrides={10: (0.52, 0.27), 3: (0.5, 0.25)})
    r = detect(p1 + p2 + p3, 3, W, H, max_regions=4)
    ok &= check("3 người: <=4 vùng và trong ảnh", len(r) <= 4 and all(0 <= x['rect'][0] <= x['rect'][2] <= W and 0 <= x['rect'][1] <= x['rect'][3] <= H for x in r))
    print("   3 người ->", [(x['kind'], x['actor'], x['target']) for x in r])

    # 10. z=0 (đa số template): kết quả PHẢI như bố cục thật, không bị coi là "không thấy khớp".
    b0 = person(0.6, 0.1); a0 = person(0.4, 0.1, overrides={9: (0.6, 0.30)})
    ok &= check("z=0 vẫn dò được (bug đọc z làm conf đã sửa)", len(detect(a0 + b0, 2, W, H)) >= 1)

    # 11. Có chênh z thật: gối của A ở XA B (z khác nhiều) -> không tính là chạm.
    a_far = person(0.4, 0.1, z=0.0, overrides={9: (0.6, 0.30)}, z_over={9: 1.0})
    b_near = person(0.6, 0.1, z=0.0)
    r = detect(a_far + b_near, 2, W, H)
    ok &= check("gối cách B xa về z -> loại", all(x['kind'] != 'knee_on_body' for x in r))
    # 12. Có chênh z nhưng gối cùng độ sâu với thân B -> vẫn chạm.
    a_same = person(0.4, 0.1, z=0.0, overrides={9: (0.6, 0.30)}, z_over={0: 1.0})  # chỉ mũi xa, gối cùng z thân B
    r = detect(a_same + b_near, 2, W, H)
    ok &= check("gối cùng z thân B (dù cảnh có z) -> giữ", any(x['kind'] == 'knee_on_body' for x in r))

    print("\nKẾT QUẢ:", "TẤT CẢ ĐẠT" if ok else "CÓ LỖI")
    raise SystemExit(0 if ok else 1)


if __name__ == "__main__":
    main()
