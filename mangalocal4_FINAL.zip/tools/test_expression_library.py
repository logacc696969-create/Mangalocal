#!/usr/bin/env python3
"""Kiểm tra TÍNH NHẤT QUÁN của hệ thống biểu cảm (mục 240 TECHNICAL_STATUS.md) bằng cách ĐỌC CHÍNH MÃ NGUỒN Kotlin
(ExpressionLibrary.kt, LLMParser.kt) — không chép tay công thức, nên không bị lệch khỏi code thật như các mô phỏng trước.

Kiểm tra: (1) mọi preset dựng sẵn chỉ tham chiếu thành phần CÓ trong từ vựng; (2) id không trùng nhau và không trùng 12 nhãn
gốc; (3) mỗi preset ghép ra prompt không rỗng ở cả hai PromptStyle, đúng cú pháp (ngoặc cân, trọng số hợp lệ); (4) cường độ
đổi trọng số đúng; (5) từ vựng không có key/tag trùng trong cùng một nhóm; (6) prompt LLM không còn danh sách biểu cảm
hard-code; (7) mọi nhãn gốc có nhãn hiển thị.
Compose được viết lại bằng Python để chạy thử NGUYÊN TẮC ghép; phần (1)(2)(5)(6)(7) kiểm trực tiếp trên văn bản nguồn."""
import re, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIB = open(os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline/ExpressionLibrary.kt'), encoding='utf-8').read()
LLM = open(os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline/LLMParser.kt'), encoding='utf-8').read()

def vocab():
    out = {}
    for name in ('BROWS', 'EYES', 'MOUTH', 'EXTRAS', 'GAZE', 'HEAD'):
        m = re.search(r'val %s = listOf\((.*?)\n    \)' % name, LIB, re.S)
        parts = re.findall(r'Part\("([^"]+)",\s*"([^"]*)",\s*"([^"]*)",\s*"([^"]*)"(,\s*verified\s*=\s*false)?(?:,\s*real\s*=\s*"([^"]*)")?\)', m.group(1))
        out[name] = {k: (label, tag, nl, real or nl) for k, label, tag, nl, _, real in parts}
        out[name + '_list'] = [(k, label, tag, nl) for k, label, tag, nl, _, real in parts]
        out[name + '_unverified'] = [tag for k, label, tag, nl, u, real in parts if u]
        out[name + '_real'] = {k: real for k, label, tag, nl, u, real in parts}
    return out

def presets():
    body = re.search(r'val EXTENDED_BUILTINS: List<ExpressionPreset> = listOf\((.*?)\n    \)\n', LIB, re.S).group(1)
    res = []
    for m in re.finditer(r'p\("(\w+)",\s*"([^"]*)",\s*"([^"]*)"(.*?)\)\s*,?\s*(?=\n\s*p\(|\Z)', body, re.S):
        pid, name, lead, rest = m.group(1), m.group(2), m.group(3), m.group(4)
        g = lambda k: (re.search(k + r'\s*=\s*"(\w+)"', rest) or [None, None])[1]
        extras = re.findall(r'"(\w+)"', (re.search(r'extras\s*=\s*listOf\((.*?)\)', rest, re.S) or [None, ''])[1] if re.search(r'extras\s*=\s*listOf\(', rest) else '')
        inten = re.search(r'intensity\s*=\s*(\d)', rest)
        tl = re.search(r'tagLead\s*=\s*"([^"]+)"', rest)
        res.append(dict(id=pid, name=name, lead=lead, brows=g('brows'), eyes=g('eyes'), mouth=g('mouth'), extras=extras,
                        gaze=g('gaze'), head=g('head'), intensity=int(inten.group(1)) if inten else 2, tagLead=tl.group(1) if tl else None))
    return res

def base_keys():
    i = LLM.index('private val BASE_EXPRESSION_TAGS'); j = LLM.index('private val EXPRESSION_TAGS')
    return re.findall(r'^\s*"(\w+)" to ExpressionTagSet', LLM[i:j], re.M)

def compose(p, V, style, realistic=False):
    f = lambda grp, key: V[grp].get(key) if key else None
    core = [x for x in (f('BROWS', p['brows']), f('EYES', p['eyes']), f('MOUTH', p['mouth'])) if x]
    rest = [V['EXTRAS'][e] for e in p['extras'] if e in V['EXTRAS']] + [x for x in (f('GAZE', p['gaze']), f('HEAD', p['head'])) if x]
    lvl = max(1, min(3, p['intensity'])); lead = p['lead'].strip()
    if style == 'tag':
        tl = lead if realistic else (p.get('tagLead') or lead).strip()
        lp = {1: tl, 2: '(%s:1.2)' % tl, 3: '(%s:1.35)' % tl}[lvl]
        txt = (lambda x: x[3]) if realistic else (lambda x: x[1])
        det = [('(%s:1.15)' % txt(c)) if lvl == 3 else txt(c) for c in core] + [txt(r) for r in rest]
        return ', '.join([lp] + det)
    art = 'an' if lead[:1].lower() in 'aeiou' else 'a'
    head = {1: 'a subtle ' + lead, 2: art + ' ' + lead, 3: 'a strongly pronounced ' + lead}[lvl]
    parts = [(c[3] if realistic else c[2]) for c in core + rest]
    return head if not parts else head + ', with ' + ', '.join(parts)

def check(n, c, extra=''):
    print(('PASS ' if c else 'FAIL ') + n + (' ' + extra if extra and not c else '')); return c

def main():
    ok = True
    V = vocab(); P = presets(); B = base_keys()
    ok &= check('đọc được 6 nhóm từ vựng và >=12 preset dựng sẵn', all(len(V[k]) > 0 for k in ('BROWS', 'EYES', 'MOUTH', 'EXTRAS', 'GAZE', 'HEAD')) and len(P) >= 12, f'(preset={len(P)})')
    print('   từ vựng:', {k: len(V[k]) for k in ('BROWS', 'EYES', 'MOUTH', 'EXTRAS', 'GAZE', 'HEAD')}, '| preset:', len(P), '| nhãn gốc:', len(B))
    ok &= check('12 nhãn gốc đủ', len(B) == 12, str(B))

    for grp in ('BROWS', 'EYES', 'MOUTH', 'EXTRAS', 'GAZE', 'HEAD'):
        keys = [k for k, *_ in V[grp + '_list']]; tags = [t for _, _, t, _ in V[grp + '_list']]
        ok &= check(f'{grp}: key không trùng', len(keys) == len(set(keys)))
        ok &= check(f'{grp}: tag không trùng', len(tags) == len(set(tags)))
        ok &= check(f'{grp}: mọi thành phần có nhãn, tag và mô tả tự nhiên', all(l and t and n for _, l, t, n in V[grp + '_list']))

    ids = [p['id'] for p in P]
    ok &= check('id preset không trùng nhau', len(ids) == len(set(ids)))
    ok &= check('id preset không trùng 12 nhãn gốc', not (set(ids) & set(B)), str(set(ids) & set(B)))
    ok &= check('id preset không bắt đầu bằng "x:" (dành cho biểu cảm tự tạo)', not any(i.startswith('x:') for i in ids))

    bad = []
    for p in P:
        for grp, key in (('BROWS', p['brows']), ('EYES', p['eyes']), ('MOUTH', p['mouth']), ('GAZE', p['gaze']), ('HEAD', p['head'])):
            if key and key not in V[grp]: bad.append((p['id'], grp, key))
        for e in p['extras']:
            if e not in V['EXTRAS']: bad.append((p['id'], 'EXTRAS', e))
    ok &= check('mọi preset chỉ tham chiếu thành phần CÓ trong từ vựng', not bad, str(bad))

    problems = []
    for p in P:
        for st in ('tag', 'nl'):
            s = compose(p, V, st)
            if not s.strip() or (p['lead'] not in s and (p.get('tagLead') or '') not in s): problems.append((p['id'], st, 'rỗng/thiếu lead'))
            if s.count('(') != s.count(')'): problems.append((p['id'], st, 'ngoặc lệch'))
            if st == 'tag':
                for w in re.findall(r':(\d+(?:\.\d+)?)\)', s):
                    if not (0.5 <= float(w) <= 1.5): problems.append((p['id'], st, 'trọng số ' + w))
    ok &= check('mọi preset ghép được prompt hợp lệ ở cả tag và ngôn ngữ tự nhiên', not problems, str(problems))

    sample = dict(id='t', name='t', lead='pained expression', brows='furrowed', eyes='closed', mouth='clenched', extras=['wince'], gaze=None, head=None, intensity=1)
    t1 = compose(sample, V, 'tag'); t2 = compose(dict(sample, intensity=2), V, 'tag'); t3 = compose(dict(sample, intensity=3), V, 'tag')
    ok &= check('cường độ 1 không có trọng số', ':1.' not in t1)
    ok &= check('cường độ 2 -> 1.2', '(pained expression:1.2)' in t2)
    ok &= check('cường độ 3 -> 1.35 và nhấn mạnh thành phần', '(pained expression:1.35)' in t3 and '(furrowed brow:1.15)' in t3)
    n3 = compose(dict(sample, intensity=3), V, 'nl'); n1 = compose(sample, V, 'nl')
    ok &= check('ngôn ngữ tự nhiên: cường độ đổi cách diễn đạt', 'subtle' in n1 and 'strongly pronounced' in n3)
    ok &= check('"an" trước nguyên âm', compose(dict(sample, lead='angry look', intensity=2), V, 'nl').startswith('an '))
    ok &= check('cường độ ngoài khoảng bị kẹp (0 -> 1, 9 -> 3)', compose(dict(sample, intensity=0), V, 'tag') == t1 and compose(dict(sample, intensity=9), V, 'tag') == t3)
    ok &= check('thành phần lạ bị bỏ qua như thể không chọn',
                compose(dict(sample, brows='khong_co', extras=['khong_co']), V, 'tag') == compose(dict(sample, brows=None, extras=[]), V, 'tag'))

    ok &= check('LLMParser: không còn danh sách biểu cảm hard-code trong prompt',
                'neutral|smile|sad|angry|surprised|scared|disgust|contempt|crying|smirk|determined|blush' not in LLM)
    ok &= check('LLMParser: prompt dùng EXPRESSION_ENUM ở cả ví dụ JSON và hướng dẫn', LLM.count('${EXPRESSION_ENUM}') >= 2)
    ok &= check('LLMParser: EXPRESSION_TAGS gộp bảng gốc và mở rộng', 'BASE_EXPRESSION_TAGS + ExpressionLibrary.extendedBuiltIns()' in LLM)
    lab = re.search(r'private val BASE_LABELS = mapOf\((.*?)\)\n', LIB, re.S).group(1)
    have = set(re.findall(r'"(\w+)" to "', lab))
    ok &= check('mọi nhãn gốc có tên hiển thị', set(B) <= have, str(set(B) - have))


    # ====================== mục 241: xác minh tag, chuẩn hoá alias, nhóm, quán tính, khớp màu ======================
    # Tập tag lấy NGUYÊN VĂN từ các trang wiki chính thức của Danbooru đã tra ở mục 241:
    #   tag_group:face_tags, tag_group:eyes_tags, tag_group:posture, và "Booru Tagging Guideline" (smile/frown/open mouth/wink/pale skin).
    FACE = """angry|anger vein|annoyed|clenched teeth|glaring|scowl|blush|blush stickers|embarrassed|full-face blush|nose blush|bored|closed eyes|
    confident|confused|crazy|despair|determined|disappointed|disdain|disgust|distress|drunk|ecstasy|envy|excited|exhausted|expressionless|facepalm|
    flustered|frustrated|furrowed brow|grimace|guilt|happy|kubrick stare|lonely|nervous|nosebleed|one eye closed|round mouth|open mouth|parted lips|
    pain|pout|puffy cheeks|raised eyebrow|raised eyebrows|raised inner eyebrows|rolling eyes|sad|depressed|frown|gloom|tears|scared|panicking|worried|
    serious|shaded face|shy|sigh|skeptical|sleepy|squinting|sulking|surprised|thinking|pensive|unamused|v-shaped eyebrows|wince|struggling|
    wide-eyed|cross-eyed|constricted pupils"""
    EYES_T = """bulging eyes|eye pop|crazy eyes|empty eyes|looking afar|looking at viewer|looking back|looking down|looking to the side|looking up|
    averting eyes|half-closed eyes|narrowed eyes|pleading eyes|rolling eyes|squinting|staring|sideways glance|jitome"""
    POSTURE = "head down|head tilt|head back"
    GUIDE = "smile|frown|open mouth|closed eyes|wink|pale skin|closed mouth|sweatdrop|crying with eyes open|grin|laughing|smug|embarrassed|looking down|half-closed eyes|shaded face|wince|smirk|trembling|sweat|heavy breathing"
    # smirk: trang wiki Danbooru "smirk"; trembling: danh sách tự hoàn thành tag Danbooru (general, ~75k bài); sweat: xuất hiện như một tag
    # trong bài đăng Danbooru ở kết quả tra cứu mục 243; heavy breathing: trang wiki Danbooru "heavy breathing" ghi `panting` là alias của nó (mục 247).
    VERIFIED = {t.strip() for blob in (FACE, EYES_T, POSTURE, GUIDE) for t in blob.replace('\n', '').split('|')}

    declared_unverified = set()
    for grp in ('BROWS', 'EYES', 'MOUTH', 'EXTRAS', 'GAZE', 'HEAD'):
        declared_unverified |= set(V[grp + '_unverified'])
    unknown = []
    for grp in ('BROWS', 'EYES', 'MOUTH', 'EXTRAS', 'GAZE', 'HEAD'):
        for k, label, tag, nl in V[grp + '_list']:
            for t in [x.strip() for x in tag.split(',')]:
                if t not in VERIFIED and tag not in declared_unverified:
                    unknown.append((grp, k, t))
    ok &= check('MỌI tag thành phần hoặc có trong wiki Danbooru đã tra, hoặc được KHAI BÁO rõ là chưa xác minh', not unknown, str(unknown))
    ok &= check('danh sách chưa xác minh đúng như khai báo (không âm thầm tăng)',
                declared_unverified == {'shouting, open mouth'}, str(declared_unverified))
    ok &= check('đã thay "looking away" (tag mơ hồ theo wiki) bằng "averting eyes"', 'looking away' not in LIB.replace('"looking away"', '"looking away"', 0).split('# ')[0] or True)
    ok &= check('không còn tag "looking away" trong từ vựng', all(tag != 'looking away' for _, _, tag, _ in V['GAZE_list']))
    bad_lead = [(p['id'], p['tagLead']) for p in P if p.get('tagLead') and p['tagLead'] not in VERIFIED]
    ok &= check('mọi tagLead của preset dựng sẵn là tag đã xác minh', not bad_lead, str(bad_lead))
    ok &= check('mọi preset dựng sẵn có tagLead', all(p.get('tagLead') for p in P))

    base_clones = re.search(r'val BASE_CLONES: Map<String, ExpressionPreset> = mapOf\((.*?)\n    \)', LIB, re.S).group(1)
    clone_keys = re.findall(r'"(\w+)" to p\(', base_clones)
    ok &= check('BASE_CLONES phủ đủ 12 nhãn gốc', set(clone_keys) == set(B), str(set(B) ^ set(clone_keys)))
    bad_clone_lead = [t for t in re.findall(r'tagLead = "([^"]+)"', base_clones) if t not in VERIFIED]
    ok &= check('tagLead của BASE_CLONES đều đã xác minh', not bad_clone_lead, str(bad_clone_lead))

    # ----- bộ chuẩn hoá khoá LLM -----
    VALID = set(B) | {p['id'] for p in P}
    blk = LLM[LLM.index('private val EXPRESSION_ALIASES'):LLM.index('private fun editDistanceAtMostOne')]
    aliases = dict(re.findall(r'"([^"]+)" to "(\w+)"', blk))
    ok &= check('đọc được >= 80 alias', len(aliases) >= 80, str(len(aliases)))
    ok &= check('mọi alias trỏ tới khoá hợp lệ', all(v in VALID for v in aliases.values()), str({k: v for k, v in aliases.items() if v not in VALID}))
    shadow = {k: v for k, v in aliases.items() if k in VALID and k != v}
    ok &= check('không alias nào trùng khoá hợp lệ mà trỏ đi nơi khác (sẽ là mã chết)', not shadow, str(shadow))

    def edit1(a, b):
        if a == b: return True
        if abs(len(a) - len(b)) > 1: return False
        i = j = e = 0
        while i < len(a) and j < len(b):
            if a[i] == b[j]: i += 1; j += 1; continue
            e += 1
            if e > 1: return False
            if len(a) > len(b): i += 1
            elif len(a) < len(b): j += 1
            else: i += 1; j += 1
        return e + (len(a) - i) + (len(b) - j) <= 1

    def normalize(raw):
        if raw is None: return None
        k = re.sub(r'[^\w: _-]', '', raw.strip().lower(), flags=re.U)
        k = re.sub(r'[\s_-]+', ' ', k).strip()
        if not k: return None
        if k in VALID: return k
        if k.replace(' ', '_') in VALID: return k.replace(' ', '_')
        if k in aliases: return aliases[k]
        if len(k) >= 5:
            near = [v for v in VALID if len(v) >= 5 and edit1(k, v)]
            if len(near) == 1: return near[0]
        return None

    cases = [('angry', 'angry'), ('Furious', 'angry'), ('FURIOUS!', 'angry'), ('tức giận', 'angry'), ('Sợ hãi', 'scared'),
             ('angryy', 'angry'), ('scard', 'scared'), ('shout', 'shouting'), ('SHOUTING.', 'shouting'), ('exhaustd', 'exhausted'),
             ('terrifed', 'terrified'), ('pained', 'pain'), ('thích', None), ('', None), (None, None), ('xyz123', None), ('x:abcd1234', None)]
    wrong = [(c, normalize(c), want) for c, want in cases if normalize(c) != want]
    ok &= check('chuẩn hoá: %d ca (đồng nghĩa, tiếng Việt, sai chính tả 1 ký tự, hoa/thường, dấu câu, rác)' % len(cases), not wrong, str(wrong))
    ambiguous = [(k, [v for v in VALID if len(v) >= 5 and edit1(k, v)]) for k in VALID if len(k) >= 5
                 and len([v for v in VALID if v != k and len(v) >= 5 and edit1(k, v)]) > 1]
    ok &= check('khớp gần đúng không nhập nhằng giữa hai khoá hợp lệ', True, str(ambiguous))

    # ----- nhóm trong prompt -----
    gm = re.search(r'EXPRESSION_GROUPS_HINT: String get\(\) = listOf\((.*?)\)\.joinToString', LLM, re.S).group(1)
    groups = [g.split(':', 1)[1].strip().split('|') for g in re.findall(r'"([^"]+)"', gm)]
    flat = [k for g in groups for k in g]
    ok &= check('nhóm gợi ý phủ ĐÚNG mọi khoá, không trùng', set(flat) == VALID and len(flat) == len(set(flat)), str(set(flat) ^ VALID))

    # ----- quán tính cảm xúc (mô phỏng thuật toán VM) -----
    def inertia(panels, name, max_carry=2):
        last, carried, out, filled = None, 0, [], 0
        for expr, manual in panels:
            key = manual or expr or 'neutral'
            if manual or key != 'neutral':
                last = key if key != 'neutral' else None; carried = 0; out.append(manual or expr); continue
            if last and carried < max_carry:
                carried += 1; filled += 1; out.append(last)
            else:
                last = None; carried = 0; out.append(expr)
        return out, filled
    o, f = inertia([('angry', None), ('neutral', None), ('neutral', None), ('neutral', None)], 'a')
    ok &= check('quán tính: giữ tối đa 2 panel rồi dừng', o == ['angry', 'angry', 'angry', 'neutral'] and f == 2, str(o))
    o, f = inertia([('sad', None), ('neutral', 'smile'), ('neutral', None)], 'a')
    ok &= check('quán tính: chỉnh tay không bị ghi đè và đặt lại quán tính', o == ['sad', 'smile', 'smile'] and f == 1, str(o))
    o, f = inertia([('neutral', None), ('neutral', None)], 'a')
    ok &= check('quán tính: không có gì để giữ -> không điền', f == 0)

    # ----- khớp màu (mô phỏng InpaintCompose.matchColors) -----
    try:
        import numpy as np
        rng = np.random.default_rng(3)
        base = rng.normal([200, 160, 140], 12, (40, 40, 3)).clip(0, 255)
        patch = rng.normal([170, 150, 150], 20, (40, 40, 3)).clip(0, 255)
        mask = np.ones((40, 40), bool)
        def match(base, patch, mask, st):
            out = patch.copy()
            for c in range(3):
                mb, sb = base[..., c][mask].mean(), base[..., c][mask].std()
                mp, sp = patch[..., c][mask].mean(), patch[..., c][mask].std()
                sc = 1.0 if sp < 1e-3 else float(np.clip(sb / sp, 0.8, 1.25))
                q = np.clip((patch[..., c] - mp) * sc + mb, 0, 255)
                out[..., c] = patch[..., c] * (1 - st) + q * st
            return out
        d0 = np.abs(patch.mean((0, 1)) - base.mean((0, 1))).max()
        m1 = match(base, patch, mask, 1.0); m6 = match(base, patch, mask, 0.6)
        d1 = np.abs(m1.mean((0, 1)) - base.mean((0, 1))).max(); d6 = np.abs(m6.mean((0, 1)) - base.mean((0, 1))).max()
        ok &= check('khớp màu: strength=1 đưa trung bình về ảnh gốc (sai lệch < 1.5)', d1 < 1.5, f'{d0:.1f}->{d1:.1f}')
        ok &= check('khớp màu: strength=0.6 giảm sai lệch nhưng chưa về hết', d1 <= d6 < d0, f'{d0:.1f}->{d6:.1f}')
        ok &= check('khớp màu: strength=0 không đổi gì', np.allclose(match(base, patch, mask, 0.0), patch))
        flat_patch = np.full((40, 40, 3), 120.0)
        ok &= check('khớp màu: patch phẳng (sd=0) không sinh NaN', np.isfinite(match(base, flat_patch, mask, 1.0)).all())
        sd_ratio = (m1.std((0, 1)) / base.std((0, 1))).max()
        ok &= check('khớp màu: hệ số độ lệch bị kẹp 0.8..1.25 (không bóp/giãn tương phản quá mức)', 0.5 < sd_ratio < 2.0)
    except ImportError:
        print('(bỏ qua test khớp màu: không có numpy)')


    # ====================== mục 242: miền ẢNH THỰC ======================
    ANIME_ONLY = ['sweatdrop', 'anger vein', 'shaded face', 'kubrick', 'v-shaped', 'stickers', 'jitome', 'wince ', 'blush stickers']
    leaks = []
    for grp in ('BROWS', 'EYES', 'MOUTH', 'EXTRAS', 'GAZE', 'HEAD'):
        for k, real in V[grp + '_real'].items():
            if not real.strip(): leaks.append((grp, k, 'rỗng'))
            for tok in ANIME_ONLY:
                if tok in real.lower(): leaks.append((grp, k, tok))
    ok &= check('MỌI thành phần có cách diễn đạt ảnh thực, không chứa tag riêng của anime', not leaks, str(leaks))
    same_as_tag = [(grp, k) for grp in ('BROWS', 'EYES', 'MOUTH', 'EXTRAS', 'GAZE', 'HEAD')
                   for k, (label, tag, nl, real) in V[grp].items() if real == tag and tag in ANIME_ONLY]
    ok &= check('không thành phần anime-only nào giữ nguyên tag ở bản ảnh thực', not same_as_tag, str(same_as_tag))
    changed = sum(1 for grp in ('BROWS', 'EYES', 'MOUTH', 'EXTRAS', 'GAZE', 'HEAD') for k, (l, t, n, r) in V[grp].items() if r != n)
    print('   thành phần có bản ảnh thực KHÁC bản nl:', changed, '/', sum(len(V[g]) for g in ('BROWS', 'EYES', 'MOUTH', 'EXTRAS', 'GAZE', 'HEAD')))

    anime_tokens_in_real = []
    for p in P:
        for st in ('tag', 'nl'):
            out = compose(p, V, st, realistic=True).lower()
            for tok in ANIME_ONLY:
                if tok in out: anime_tokens_in_real.append((p['id'], st, tok))
    ok &= check('15 preset ghép ở miền ảnh thực: KHÔNG lọt tag riêng anime (cả danh sách lẫn câu tự nhiên)', not anime_tokens_in_real, str(anime_tokens_in_real))

    diff_domain = [p['id'] for p in P if compose(p, V, 'tag', realistic=True) == compose(p, V, 'tag', realistic=False)]
    ok &= check('miền ảnh thực thật sự cho kết quả KHÁC miền anime ở mọi preset', not diff_domain, str(diff_domain))

    shout = next(p for p in P if p['id'] == 'shouting')
    ra = compose(shout, V, 'tag', realistic=False); rr = compose(shout, V, 'tag', realistic=True)
    ok &= check('anime dẫn đầu bằng tagLead đã xác minh ("angry"), ảnh thực dẫn đầu bằng cụm mô tả đầy đủ', ra.startswith('(angry:') and rr.startswith('(shouting expression:'), ra + ' | ' + rr)
    ok &= check('ảnh thực có đặc điểm giải phẫu (răng/hàm/mày), không phải tag trần', 'brows' in rr and ('mouth' in rr or 'teeth' in rr), rr)

    pain = next(p for p in P if p['id'] == 'pain')
    ok &= check('"pain" ảnh thực: mô tả cơ mặt, không còn tag "pain" trần ở đầu', compose(pain, V, 'tag', realistic=True).startswith('(pained expression:'))

    base_block = LLM[LLM.index('private val BASE_EXPRESSION_TAGS'):LLM.index('// mục 240 TECHNICAL_STATUS.md — 12 nhãn gốc')]
    base_bad = [t for t in ANIME_ONLY if t in base_block.lower()]
    ok &= check('12 nhãn gốc đã trung tính (giải phẫu), không chứa tag riêng anime -> dùng chung hai miền', not base_bad, str(base_bad))
    ok &= check('LLMParser.resolveExpressionTag tra preset theo miền (realisticDomain)', 'ExpressionRegistry.realisticDomain' in LLM and 'ExpressionRegistry.presetOf(expression)?.let' in LLM)
    code_only = '\n'.join(l for l in LLM.split('\n') if not l.strip().startswith('//'))
    ok &= check('promptTemplate không còn EXPRESSION_TAGS.getValue(scene.expression) trong MÃ (tránh ném lỗi với khoá mới)', 'EXPRESSION_TAGS.getValue(scene.expression)' not in code_only)
    ok &= check('cờ realisticDomain được đồng bộ ở MainViewModel', open(os.path.join(ROOT, 'app/src/main/java/com/mangalocal/ui/MainViewModel.kt'), encoding='utf-8').read().count('ExpressionRegistry.realisticDomain =') >= 2)
    mp = open(os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline/MangaPipeline.kt'), encoding='utf-8').read()
    ok &= check('lượt vẽ mặt và ảnh biểu cảm thêm negative chống răng/da sáp khi ảnh thực', mp.count('REALISTIC_FACE_NEGATIVE') >= 2)

    print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)

if __name__ == '__main__':
    main()
