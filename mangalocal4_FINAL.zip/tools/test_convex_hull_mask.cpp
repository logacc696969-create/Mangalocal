// mục 202 TECHNICAL_STATUS.md — bộ test THẬT (biên dịch + chạy bằng g++
// trong sandbox viết code, KHÔNG phải Android NDK/MNN đầy đủ) cho thuật
// toán bao lồi (convex hull) + tô polygon mới thêm ở mục 201, dùng cho mask
// "trước-khi-có-ảnh" (mask N-nhân-vật/Regional-Mask) trong
// app/src/main/jni/ip_adapter.cpp.
//
// CÁCH DÙNG: nếu sửa lại convexHull()/fillConvexPolygon()/renderCharacterMask()
// trong ip_adapter.cpp, trích lại đúng đoạn code đó (KHÔNG gõ tay lại — copy
// nguyên văn, để test này luôn kiểm chứng ĐÚNG code thật đang chạy trong
// app, không phải 1 bản chép tay có thể lệch) dán đè vào giữa 2 dòng
// "BEGIN"/"END" bên dưới, biên dịch: `g++ -std=c++17 -Wall -Wextra -O0 -o
// test_convex_hull_mask test_convex_hull_mask.cpp && ./test_convex_hull_mask`
//
// GIỚI HẠN THẬT: test này CHỈ kiểm chứng đúng phần THUẬT TOÁN HÌNH HỌC
// thuần (không phụ thuộc MNN/JNI/Android) — KHÔNG thay thế được build-test
// thật trên thiết bị (không kiểm tra được tích hợp với phần còn lại của
// pipeline C++, không kiểm tra được hiệu năng thật, không kiểm tra được
// IPAdapterAttnProcessor có dùng mask này đúng cách hay không). Vẫn là
// bước kiểm chứng CÓ THẬT, tốt hơn hẳn "chưa build-test hoàn toàn" — đúng
// tinh thần "kiểm chứng bằng thực nghiệm thật" mà chính dự án này đã áp
// dụng từ mục 1 (Smooth Timestep Decay).
//
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <vector>

// ==== Type definitions copied EXACTLY from ip_adapter.cpp (line 67-68) ====
struct Keypoint { float x, y, z; bool visible; };
using Skeleton = std::array<Keypoint, 18>;

// ==== BEGIN: verbatim extraction from app/src/main/jni/ip_adapter.cpp lines 300-424 ====
inline std::vector<std::pair<float, float>> convexHull(std::vector<std::pair<float, float>> pts) {
    if (pts.size() < 3) return pts;
    std::sort(pts.begin(), pts.end());
    pts.erase(std::unique(pts.begin(), pts.end()), pts.end());
    if (pts.size() < 3) return pts;
    auto cross = [](const std::pair<float, float>& o, const std::pair<float, float>& a,
                     const std::pair<float, float>& b) {
        return (a.first - o.first) * (b.second - o.second) - (a.second - o.second) * (b.first - o.first);
    };
    std::vector<std::pair<float, float>> lower;
    for (auto& p : pts) {
        while (lower.size() >= 2 && cross(lower[lower.size() - 2], lower[lower.size() - 1], p) <= 0.f)
            lower.pop_back();
        lower.push_back(p);
    }
    std::vector<std::pair<float, float>> upper;
    for (auto it = pts.rbegin(); it != pts.rend(); ++it) {
        while (upper.size() >= 2 && cross(upper[upper.size() - 2], upper[upper.size() - 1], *it) <= 0.f)
            upper.pop_back();
        upper.push_back(*it);
    }
    lower.pop_back();
    upper.pop_back();
    lower.insert(lower.end(), upper.begin(), upper.end());
    return lower;
}

// mục 201 — tô đặc 1 đa giác LỒI bằng scanline (đơn giản hơn polygon bất kỳ
// vì lồi luôn cho ĐÚNG 1 khoảng [xMin,xMax] liên tục mỗi hàng y — không cần
// thuật toán even-odd/winding-number tổng quát cho polygon lõm/tự cắt).
// hullNorm: toạ độ CHUẨN HOÁ [0,1], TỰ nhân width/height bên trong.
inline void fillConvexPolygon(std::vector<uint8_t>& canvas, int width, int height,
                               const std::vector<std::pair<float, float>>& hullNorm) {
    if (hullNorm.size() < 3) return;
    std::vector<std::pair<float, float>> px;
    px.reserve(hullNorm.size());
    for (auto& p : hullNorm) px.emplace_back(p.first * width, p.second * height);
    float minYf = 1e9f, maxYf = -1e9f;
    for (auto& p : px) { minYf = std::min(minYf, p.second); maxYf = std::max(maxYf, p.second); }
    int y0 = std::max(0, (int)std::floor(minYf));
    int y1 = std::min(height - 1, (int)std::ceil(maxYf));
    size_t n = px.size();
    for (int y = y0; y <= y1; y++) {
        float yc = y + 0.5f;
        float xMin = 1e9f, xMax = -1e9f;
        bool any = false;
        for (size_t i = 0; i < n; i++) {
            const auto& a = px[i];
            const auto& b = px[(i + 1) % n];
            if ((a.second <= yc && b.second > yc) || (b.second <= yc && a.second > yc)) {
                float t = (yc - a.second) / (b.second - a.second);
                float xIntersect = a.first + t * (b.first - a.first);
                xMin = std::min(xMin, xIntersect);
                xMax = std::max(xMax, xIntersect);
                any = true;
            }
        }
        if (!any) continue;
        int px0 = std::max(0, (int)std::floor(xMin));
        int px1 = std::min(width - 1, (int)std::ceil(xMax));
        for (int x = px0; x <= px1; x++) canvas[(size_t)y * width + x] = 255;
    }
}

inline std::vector<uint8_t> renderCharacterMask(const std::vector<Skeleton>& people,
                                                 size_t personIndex, int width, int height) {
    std::vector<uint8_t> canvas((size_t)width * height, 0);  // 1 kênh, khác renderSkeletons/renderDepthHint (3 kênh)
    if (personIndex >= people.size()) return canvas;  // không có người này -> mask rỗng, IP-Adapter tương ứng không ảnh hưởng gì

    const Skeleton& s = people[personIndex];
    float minX = 1e9f, minY = 1e9f, maxX = -1e9f, maxY = -1e9f;
    bool any = false;
    std::vector<std::pair<float, float>> jointPts;
    for (auto& k : s) {
        if (!k.visible) continue;
        any = true;
        minX = std::min(minX, k.x); maxX = std::max(maxX, k.x);
        minY = std::min(minY, k.y); maxY = std::max(maxY, k.y);
        jointPts.emplace_back(k.x, k.y);
    }
    if (!any) return canvas;

    // Nới rộng biên 10% mỗi phía — tránh cắt cụt đúng ngay rìa khớp ngoài
    // cùng (tay/chân thường vượt ra ngoài bounding box của riêng các ĐIỂM
    // khớp một chút do có độ dày cơ thể thật).
    float marginX = (maxX - minX) * 0.10f + 0.02f;
    float marginY = (maxY - minY) * 0.10f + 0.02f;
    minX = std::clamp(minX - marginX, 0.f, 1.f);
    maxX = std::clamp(maxX + marginX, 0.f, 1.f);
    minY = std::clamp(minY - marginY, 0.f, 1.f);
    maxY = std::clamp(maxY + marginY, 0.f, 1.f);

    // mục 201 TECHNICAL_STATUS.md — bao lồi thay hình chữ nhật (đọc kỹ
    // GIỚI HẠN THẬT ở comment convexHull()/fillConvexPolygon() phía trên
    // trước khi tin đây là segmentation thật — vẫn CHỈ là hình học gần
    // đúng, không lõm được ở khoảng trống giữa các chi). Nới rộng 15% ra
    // ngoài từ TÂM bao lồi (cùng tinh thần margin 10-15% đã dùng cho hình
    // chữ nhật, không phải số tự bịa). Rơi về hình chữ nhật CŨ (biến
    // minX/maxX/minY/maxY đã tính sẵn ở trên) nếu bao lồi suy biến (<3
    // điểm — hiếm, vd toàn bộ khớp hợp lệ gần như thẳng hàng).
    auto hull = convexHull(jointPts);
    if (hull.size() >= 3) {
        float cx = 0.f, cy = 0.f;
        for (auto& p : hull) { cx += p.first; cy += p.second; }
        cx /= (float)hull.size(); cy /= (float)hull.size();
        std::vector<std::pair<float, float>> hullExpanded;
        hullExpanded.reserve(hull.size());
        for (auto& p : hull) {
            float ex = std::clamp(cx + (p.first - cx) * 1.15f, 0.f, 1.f);
            float ey = std::clamp(cy + (p.second - cy) * 1.15f, 0.f, 1.f);
            hullExpanded.emplace_back(ex, ey);
        }
        fillConvexPolygon(canvas, width, height, hullExpanded);
        return canvas;
    }

    // mục 161 (đợt 7) — width/height TÁCH RIÊNG (trước là 1 tham số `size`
    // vuông) — x theo width, y theo height, đúng trục.
    int px0 = (int)(minX * width), px1 = (int)(maxX * width);
    int py0 = (int)(minY * height), py1 = (int)(maxY * height);
    for (int y = std::max(0, py0); y < std::min(height, py1); y++)
        for (int x = std::max(0, px0); x < std::min(width, px1); x++)
            canvas[(size_t)y * width + x] = 255;
    return canvas;
}
// ==== END verbatim extraction ====

static void printMaskAscii(const std::vector<uint8_t>& canvas, int w, int h, int stepX, int stepY) {
    for (int y = 0; y < h; y += stepY) {
        for (int x = 0; x < w; x += stepX) {
            printf("%c", canvas[(size_t)y * w + x] ? '#' : '.');
        }
        printf("\n");
    }
}

static long countFilled(const std::vector<uint8_t>& canvas) {
    long c = 0;
    for (auto v : canvas) if (v) c++;
    return c;
}

int main() {
    int fails = 0;

    // ---- TEST 1: convexHull basic correctness (square + interior points) ----
    {
        std::vector<std::pair<float,float>> pts = {
            {0.f,0.f}, {1.f,0.f}, {1.f,1.f}, {0.f,1.f}, // 4 corners
            {0.5f,0.5f}, {0.3f,0.7f}, {0.6f,0.2f}        // interior, should be excluded
        };
        auto hull = convexHull(pts);
        printf("[TEST 1] convex hull of square+interior -> %zu points: ", hull.size());
        for (auto& p : hull) printf("(%.1f,%.1f) ", p.first, p.second);
        printf("\n");
        if (hull.size() != 4) { printf("  FAIL: expected 4 hull points (just the corners)\n"); fails++; }
        else printf("  PASS: exactly 4 corners kept, interior points correctly excluded\n");
    }

    // ---- TEST 2: degenerate collinear points ----
    {
        std::vector<std::pair<float,float>> pts = {{0.1f,0.1f},{0.2f,0.2f},{0.3f,0.3f},{0.4f,0.4f}};
        auto hull = convexHull(pts);
        printf("[TEST 2] convex hull of collinear points -> %zu points\n", hull.size());
        if (hull.size() >= 3) { printf("  FAIL: collinear points should NOT form a valid >=3-point convex polygon here (expect <3 due to zero-area cross products)\n"); fails++; }
        else printf("  PASS: correctly degenerates to <3 points (renderCharacterMask will fall back to rectangle)\n");
    }

    // ---- TEST 3: renderCharacterMask on a plausible standing person, T-pose-like ----
    {
        std::vector<Skeleton> people(1);
        for (auto& k : people[0]) { k.x = 0; k.y = 0; k.z = 0; k.visible = false; }
        // Rough COCO-18 layout for a standing person, normalized [0,1]
        // 0 nose,1 neck,2 Rshoulder,3 Relbow,4 Rwrist,5 Lshoulder,6 Lelbow,7 Lwrist,
        // 8 Rhip,9 Rknee,10 Rankle,11 Lhip,12 Lknee,13 Lankle,14 Reye,15 Leye,16 Rear,17 Lear
        struct J { int i; float x,y; };
        std::vector<J> js = {
            {0,0.50f,0.10f}, {1,0.50f,0.18f},
            {2,0.42f,0.20f}, {3,0.35f,0.32f}, {4,0.30f,0.44f},
            {5,0.58f,0.20f}, {6,0.65f,0.32f}, {7,0.70f,0.44f},
            {8,0.45f,0.55f}, {9,0.44f,0.72f}, {10,0.43f,0.90f},
            {11,0.55f,0.55f}, {12,0.56f,0.72f}, {13,0.57f,0.90f},
        };
        for (auto& j : js) { people[0][j.i].x = j.x; people[0][j.i].y = j.y; people[0][j.i].visible = true; }

        int W = 60, H = 60;
        auto mask = renderCharacterMask(people, 0, W, H);
        long filled = countFilled(mask);
        long total = (long)W * H;
        printf("[TEST 3] standing pose mask: %ld / %ld pixels filled (%.1f%%)\n", filled, total, 100.0*filled/total);
        printMaskAscii(mask, W, H, 2, 2);
        if (filled <= 0) { printf("  FAIL: mask completely empty for a valid standing pose\n"); fails++; }
        else if (filled >= total * 0.95) { printf("  FAIL: mask suspiciously covers almost the whole canvas\n"); fails++; }
        else printf("  PASS: mask is non-trivial and bounded, looks like a plausible body silhouette\n");
    }

    // ---- TEST 4: diagonal pose - hull area should be less than axis-aligned bbox area ----
    {
        std::vector<Skeleton> people(1);
        for (auto& k : people[0]) { k.x = 0; k.y = 0; k.z = 0; k.visible = false; }
        // A diagonal line of points from top-left to bottom-right, simulating a
        // person leaning/running diagonally across the frame.
        struct J { int i; float x,y; };
        std::vector<J> js = {
            {0,0.15f,0.10f}, {1,0.20f,0.15f},
            {2,0.25f,0.20f}, {3,0.30f,0.28f}, {4,0.35f,0.36f},
            {8,0.40f,0.45f}, {9,0.55f,0.60f}, {10,0.70f,0.75f},
            {11,0.45f,0.50f}, {12,0.60f,0.65f}, {13,0.75f,0.80f},
        };
        for (auto& j : js) { people[0][j.i].x = j.x; people[0][j.i].y = j.y; people[0][j.i].visible = true; }
        int W = 80, H = 80;
        auto mask = renderCharacterMask(people, 0, W, H);
        long filled = countFilled(mask);

        // Compute what the OLD rectangle-only approach would have covered, for comparison
        float minX=1e9f,minY=1e9f,maxX=-1e9f,maxY=-1e9f;
        for (auto& j : js) { minX=std::min(minX,j.x); maxX=std::max(maxX,j.x); minY=std::min(minY,j.y); maxY=std::max(maxY,j.y); }
        float mX = (maxX-minX)*0.10f+0.02f, mY=(maxY-minY)*0.10f+0.02f;
        float rl = std::max(0.f,minX-mX), rr = std::min(1.f,maxX+mX);
        float rt = std::max(0.f,minY-mY), rb = std::min(1.f,maxY+mY);
        long bboxPixels = (long)((rr-rl)*W) * (long)((rb-rt)*H);

        printf("[TEST 4] diagonal pose: hull-filled=%ld px, old-rectangle-equivalent=%ld px\n", filled, bboxPixels);
        if (filled >= bboxPixels) { printf("  FAIL: hull should cover LESS area than the old axis-aligned rectangle for a diagonal pose\n"); fails++; }
        else printf("  PASS: hull is tighter than rectangle for diagonal pose (%.0f%% of rectangle area) - confirms the intended benefit\n", 100.0*filled/bboxPixels);
    }

    // ---- TEST 5: no visible keypoints -> must return all-zero canvas, no crash ----
    {
        std::vector<Skeleton> people(1);
        for (auto& k : people[0]) { k.x=0;k.y=0;k.z=0;k.visible=false; }
        auto mask = renderCharacterMask(people, 0, 32, 32);
        long filled = countFilled(mask);
        printf("[TEST 5] no visible keypoints -> filled=%ld (expect 0)\n", filled);
        if (filled != 0) { printf("  FAIL: expected empty mask\n"); fails++; }
        else printf("  PASS\n");
    }

    // ---- TEST 6: out-of-bounds personIndex -> must return all-zero canvas, no crash ----
    {
        std::vector<Skeleton> people(1);
        auto mask = renderCharacterMask(people, 5, 32, 32);
        long filled = countFilled(mask);
        printf("[TEST 6] out-of-bounds personIndex -> filled=%ld (expect 0, no crash)\n", filled);
        if (filled != 0) { printf("  FAIL\n"); fails++; }
        else printf("  PASS\n");
    }

    printf("\n===== %s (%d failing assertion group(s)) =====\n", fails==0 ? "ALL TESTS PASSED" : "SOME TESTS FAILED", fails);
    return fails == 0 ? 0 : 1;
}
