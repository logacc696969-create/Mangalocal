#!/usr/bin/env python3
"""mục 262 — kiểm thử `sd_engine/MemInfo.hpp` (phân tích /proc để đo RAM) và `sd_engine/MaskBlend.hpp` (chỉ số timestep khi trộn mask) bằng C++ THẬT
(g++ -Wall -Wextra -Werror, ASan+UBSan), đối chiếu tham chiếu Python độc lập, fuzz, mô phỏng bộ lấy mẫu và thử phá mã (đột biến PHẢI biên dịch được).
KHÔNG chứng minh: ảnh vẽ lại đẹp hơn khi bật cờ; RAM thật của UNet trên máy thật (chỉ chứng minh phần phân tích số đúng và cờ nối đúng).
"""
import os, re, random, shutil, struct, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JNI = os.path.join(ROOT, 'app/src/main/jni'); KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
HDR = os.path.join(JNI, 'sd_engine')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + d) if (d and not c) else '')); ok &= bool(c)

CPP = r'''
#include "MemInfo.hpp"
#include "MaskBlend.hpp"
#include <cstdio>
#include <cstring>
#include <vector>
#include <sys/mman.h>
// in = bytes; out = bytes
static std::string rd(FILE* f) { std::string s; char b[4096]; size_t n; while ((n = fread(b, 1, sizeof b, f)) > 0) s.append(b, n); return s; }
int main(int argc, char** argv) {
  if (argc < 4) return 2;
  std::string cmd = argv[1];
  FILE* f = fopen(argv[2], "rb"); if (!f) return 3;
  std::string in = rd(f); fclose(f);
  std::string out;
  if (cmd == "kb") {            // in = key\0text
    size_t z = in.find('\0'); std::string key = in.substr(0, z), text = in.substr(z + 1);
    long long v = mem_info::parseKb(text, key); out.assign((char*)&v, 8);
  } else if (cmd == "delta") {  // in = int64 a, int64 b
    long long a, b; memcpy(&a, in.data(), 8); memcpy(&b, in.data() + 8, 8);
    long long v = mem_info::deltaKb(a, b); out.assign((char*)&v, 8);
  } else if (cmd == "fmt") {    // in = int64
    long long a; memcpy(&a, in.data(), 8); out = mem_info::fmtMb(a);
  } else if (cmd == "live") {
    void* m = mmap(nullptr, 64u << 20, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (m != MAP_FAILED) { memset(m, 1, 64u << 20); munmap(m, 64u << 20); }   // chạm 64 MB rồi trả OS: VmHWM (đỉnh) vọt lên, VmRSS (hiện tại) xuống lại
    long long r = mem_info::rssKb(), p = mem_info::pssKb(), h = mem_info::readSelfKb("/proc/self/status", "VmHWM");
    out.assign((char*)&r, 8); out.append((char*)&p, 8); out.append((char*)&h, 8);
  } else if (cmd == "idx") {    // in = int32 n, int32 matched
    int n, m; memcpy(&n, in.data(), 4); memcpy(&m, in.data() + 4, 4);
    for (int i = 0; i < n; ++i) { int v = maskBlendTimestepIndex(i, n, m != 0); out.append((char*)&v, 4); }
  } else if (cmd == "flag") {   // cờ mặc định
    int v = g_mask_blend_matched.load() ? 1 : 0; out.assign((char*)&v, 4);
    g_mask_blend_matched.store(true); int w = g_mask_blend_matched.load() ? 1 : 0; out.append((char*)&w, 4);
  }
  FILE* g = fopen(argv[3], "wb"); fwrite(out.data(), 1, out.size(), g); fclose(g);
  return 0;
}
'''
def build(hdr, tmp, tag):
    src = os.path.join(tmp, f'{tag}.cpp'); exe = os.path.join(tmp, tag); open(src, 'w').write(CPP)
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-g', '-Wall', '-Wextra', '-Werror', '-fsanitize=address,undefined', '-fno-sanitize-recover=undefined',
                        '-I', hdr, '-I', HDR, src, '-o', exe], capture_output=True, text=True)
    return exe, r
def run(exe, tmp, cmd, payload):
    fi = os.path.join(tmp, 'in.bin'); fo = os.path.join(tmp, 'out.bin'); open(fi, 'wb').write(payload)
    r = subprocess.run([exe, cmd, fi, fo], capture_output=True, text=True)
    return open(fo, 'rb').read() if r.returncode == 0 else None

def ref_kb(text, key):
    for line in text.split('\n'):
        if line.startswith(key + ':'):
            m = re.match(r'[ \t]*(\d+)', line[len(key) + 1:])
            if not m: return -1
            v = int(m.group(1))
            return v if v <= (1 << 40) else -1
    return -1

STATUS = "Name:\tcom.mangalocal\nUmask:\t0077\nState:\tS (sleeping)\nVmPeak:\t 9876543 kB\nVmSize:\t 9000000 kB\nVmHWM:\t  812345 kB\nVmRSS:\t  778899 kB\nRssAnon:\t  123456 kB\nThreads:\t42\n"
ROLL = "Rss:                 812345 kB\nPss:                 700001 kB\nPss_Anon:            111111 kB\nPss_File:            222222 kB\nShared_Clean:          5000 kB\n"

def suite(exe, tmp, quiet=False):
    bad = 0
    def chk(n, c, d=''):
        nonlocal bad
        if not c: bad += 1
        if not quiet: check(n, c, d)
    def kb(key, text):
        o = run(exe, tmp, 'kb', key.encode() + b'\0' + text.encode())
        return None if o is None else struct.unpack('<q', o)[0]
    chk('VmRSS đọc đúng từ mẫu /proc/self/status', kb('VmRSS', STATUS) == 778899)
    chk('Pss KHÔNG nhầm với Pss_Anon (khớp chính xác khoá + dấu hai chấm)', kb('Pss', ROLL) == 700001 and kb('Pss_Anon', ROLL) == 111111)
    chk('Pss_Anon đứng TRƯỚC Pss vẫn đọc đúng Pss', kb('Pss', "Pss_Anon:  5 kB\nPss:  7 kB\n") == 7)
    chk('khoá "Rss" không khớp "RssAnon" hay "VmRSS"', kb('Rss', STATUS) == -1 and kb('Rss', ROLL) == 812345)
    chk('thiếu khoá -> -1', kb('VmSwap', STATUS) == -1)
    chk('văn bản rỗng -> -1', kb('VmRSS', '') == -1)
    chk('khoá chỉ có ở GIỮA dòng (không đầu dòng) -> -1', kb('VmRSS', 'x VmRSS: 5 kB\n') == -1)
    chk('không có chữ số -> -1', kb('VmRSS', 'VmRSS:\t kB\n') == -1)
    chk('dòng cuối không có xuống dòng vẫn đọc được', kb('VmRSS', 'VmRSS: 42 kB') == 42)
    chk('giá trị tràn (> 2^40) -> -1, không sập', kb('VmRSS', 'VmRSS: 99999999999999999999999 kB\n') == -1)
    chk('giá trị 0 hợp lệ -> 0 (khác với -1 = không đọc được)', kb('VmRSS', 'VmRSS: 0 kB\n') == 0)
    chk('chỉ lấy dòng KHỚP ĐẦU TIÊN', kb('VmRSS', 'VmRSS: 1 kB\nVmRSS: 2 kB\n') == 1)
    rng = random.Random(262); keys = ['VmRSS', 'Pss', 'Rss', 'VmHWM', 'Pss_Anon', 'X']
    mism = 0
    for _ in range(600):
        lines = []
        for _ in range(rng.randint(0, 8)):
            k = rng.choice(keys + ['Pss_File', 'Foo'])
            sep = rng.choice([':', ':', ': ', ':\t', '', ' '])
            val = rng.choice(['12', '  345', '\t6789', '', 'abc', '0', '1099511627776', '1099511627777'])
            tail = rng.choice([' kB', '', ' mB'])
            pre = rng.choice(['', '', '', ' ', 'x'])
            lines.append(pre + k + sep + val + tail)
        text = '\n'.join(lines) + rng.choice(['', '\n'])
        key = rng.choice(keys)
        if kb(key, text) != ref_kb(text, key): mism += 1
    chk('fuzz 600 văn bản /proc ngẫu nhiên khớp tham chiếu Python', mism == 0, f'{mism} lệch')
    d = lambda a, b: struct.unpack('<q', run(exe, tmp, 'delta', struct.pack('<qq', a, b)))[0]
    chk('deltaKb: chênh lệch bình thường', d(100, 350) == 250 and d(500, 100) == -400)
    chk('deltaKb: một mốc không đọc được (-1) -> -1 (KHÔNG ra số âm giả)', d(-1, 500) == -1 and d(500, -1) == -1 and d(-1, -1) == -1)
    f = lambda a: run(exe, tmp, 'fmt', struct.pack('<q', a)).decode()
    chk('fmtMb: 1024 kB -> "1.0 MB"; 0 -> "0.0 MB"; -1 -> "n/a"', f(1024) == '1.0 MB' and f(0) == '0.0 MB' and f(-1) == 'n/a' and f(1536) == '1.5 MB')
    live = run(exe, tmp, 'live', b'')
    r, p, h = struct.unpack('<qqq', live)
    chk('đọc RSS thật của chính tiến trình thử: hợp lý (> 500 kB, < 10 GB)', 500 < r < 10_000_000, str(r))
    chk('rssKb là RSS HIỆN TẠI chứ không phải đỉnh VmHWM (chạm 64 MB rồi trả: đỉnh cao hơn RSS > 30 MB)', h - r > 30_000, f'rss={r} hwm={h}')
    chk('PSS hoặc đọc được (>0) hoặc -1 (n/a) — không bao giờ rác', p == -1 or p > 0, str(p))
    # ---- MaskBlend ----
    def idx(n, m):
        o = run(exe, tmp, 'idx', struct.pack('<ii', n, int(m)))
        return list(struct.unpack(f'<{n}i', o))
    allok_off = all(idx(n, False) == list(range(n)) for n in range(1, 61))
    chk('cờ TẮT: chỉ số = i với mọi n (hành vi cũ GIỮ NGUYÊN)', allok_off)
    allok_on = all(idx(n, True) == list(range(1, n)) + [-1] for n in range(1, 61))
    chk('cờ BẬT: i+1, bước cuối = -1 (ảnh sạch), với n = 1..60', allok_on)
    # mô phỏng bộ lấy mẫu: sau bước i latent ở mức ts[i+1] (bước cuối: 0). Chỉ số khớp phải cho ĐÚNG mức đó.
    sim_ok = True; old_off = True
    for n in (1, 2, 5, 20, 30, 50):
        ts = [int(999 - k * 999 / max(n - 1, 1)) for k in range(n)]
        after = [ts[i + 1] if i + 1 < n else 0 for i in range(n)]
        lvl = lambda j: (ts[j] if 0 <= j < n else (0 if j == -1 else None))   # chỉ số ngoài biên -> None (không khớp), KHÔNG ném lỗi
        for i_, j in enumerate(idx(n, True)):
            sim_ok &= (lvl(j) == after[i_])
        for i_, j in enumerate(idx(n, False)):
            u = lvl(j)
            old_off &= (u is not None) and (u >= after[i_]) and (n == 1 or i_ == n - 1 or u > after[i_])
    chk('mô phỏng bộ lấy mẫu: cờ bật thêm nhiễu ĐÚNG mức của latent sau bước ở MỌI bước', sim_ok)
    chk('mô phỏng: cờ tắt (mã cũ) luôn thêm nhiễu CAO HƠN mức latent sau bước — đúng cái lệch đã tra cứu', old_off)
    fl = struct.unpack('<ii', run(exe, tmp, 'flag', b''))
    chk('cờ g_mask_blend_matched mặc định TẮT và đặt được', fl == (0, 1))
    return bad

tmp = tempfile.mkdtemp()
exe, r = build(HDR, tmp, 'real')
check('MemInfo.hpp + MaskBlend.hpp biên dịch sạch (-Wall -Wextra -Werror, ASan+UBSan)', r.returncode == 0, r.stderr[-600:])
if r.returncode == 0:
    check('bộ kiểm trên header THẬT: 0 lỗi', suite(exe, tmp) == 0)
    sm = open(os.path.join(HDR, 'MemInfo.hpp'), encoding='utf-8').read(); sb = open(os.path.join(HDR, 'MaskBlend.hpp'), encoding='utf-8').read()
    muts = [
        ('MemInfo', 'bỏ kiểm dấu hai chấm sau khoá', "&& text[pos + key.size()] == ':'", ''),
        ('MemInfo', 'bỏ chốt tràn số', 'if (v > (1LL << 40)) return -1;', ''),
        ('MemInfo', 'không có chữ số vẫn trả 0', 'return any ? v : -1;', 'return (any || !any) ? v : -1;'),
        ('MemInfo', 'delta không xử lý -1', 'return (before < 0 || after < 0) ? -1 : after - before;', 'return after - before;'),
        ('MemInfo', 'fmtMb bỏ n/a', 'if (kb < 0) return "n/a";', ''),
        ('MemInfo', 'đọc VmHWM thay VmRSS', 'readSelfKb("/proc/self/status", "VmRSS")', 'readSelfKb("/proc/self/status", "VmHWM")'),
        ('MaskBlend', 'bước cuối vẫn i+1', 'return (i + 1 < n) ? i + 1 : -1;', 'return (n > 0) ? i + 1 : -1;'),
        ('MaskBlend', 'ranh giới lệch 1', '(i + 1 < n) ? i + 1 : -1', '(i + 1 <= n) ? i + 1 : -1'),
        ('MaskBlend', 'cờ bật vẫn trả i', 'return (i + 1 < n) ? i + 1 : -1;', 'return (i + 1 < n) ? i : -1;'),
        ('MaskBlend', 'cờ tắt đổi hành vi cũ', 'if (!matched) return i;', 'if (!matched) return i + 1 < n ? i + 1 : i;'),
        ('MaskBlend', 'cờ mặc định BẬT', 'inline std::atomic<bool> g_mask_blend_matched{false};', 'inline std::atomic<bool> g_mask_blend_matched{true};'),
    ]
    caught = 0
    lo, hi = (int(x) for x in os.environ.get('MUT_RANGE', '0:999').split(':'))
    for n, (which, name, old, new) in enumerate(muts):
        if not (lo <= n < hi): continue
        src = sm if which == 'MemInfo' else sb
        if old not in src: check(f'đột biến "{name}": mẫu có trong mã', False, 'mẫu không còn khớp'); continue
        md = os.path.join(tmp, f'dir{n}'); os.makedirs(md, exist_ok=True)
        for fn in ('MemInfo.hpp', 'MaskBlend.hpp'): shutil.copy(os.path.join(HDR, fn), md)
        fname = 'MemInfo.hpp' if which == 'MemInfo' else 'MaskBlend.hpp'
        open(os.path.join(md, fname), 'w', encoding='utf-8').write(src.replace(old, new, 1))
        mexe, mr = build(md, tmp, f'm{n}')
        if mr.returncode != 0: check(f'đột biến "{name}" phải BIÊN DỊCH được (nếu không thì "bị bắt" là vô nghĩa)', False, mr.stderr[-300:]); continue
        b = suite(mexe, tmp, quiet=True); check(f'đột biến "{name}" bị bộ kiểm bắt', b > 0); caught += b > 0
    sel = len([1 for n in range(len(muts)) if lo <= n < hi])
    check(f'thử phá mã: {caught}/{sel} đột biến bị bắt', caught == sel)

# ---- nối dây tĩnh ----
rd = lambda *p: open(os.path.join(*p), encoding='utf-8').read()
PL = rd(HDR, 'Pipeline.hpp'); P15 = rd(HDR, 'PipelineSd15Cpu.hpp'); JN = rd(JNI, 'mnn_diffusion_pipeline.cpp')
NB = rd(KT, 'pipeline/NativeBridge.kt'); MP = rd(KT, 'pipeline/MangaPipeline.kt'); ML = rd(KT, 'model/Models.kt'); ST = rd(KT, 'ui/SettingsScreen.kt')
check('Pipeline.hpp: nhánh mask dùng maskBlendTimestepIndex, t_idx < 0 -> ảnh gốc SẠCH (không add_noise)',
      'maskBlendTimestepIndex(i, (int)timesteps.size(), g_mask_blend_matched.load())' in PL and 'xt::xarray<float> orig_noised = original_latents;' in PL and 'if (t_idx >= 0) {' in PL)
check('Pipeline.hpp: cả DD lẫn trộn cứng dùng CÙNG orig_noised (một cờ ảnh hưởng cả hai, như đã ghi)', PL.count('orig_noised * (1.0f - dd_gate)') == 1 and PL.count('orig_noised * (1.0f - mask)') == 1)
check('Pipeline.hpp: nhánh ultrafix vẫn dùng timesteps(i+1) như cũ (không đụng)', 'xt::xarray<int> t_next = {(int)(timesteps(i + 1))};' in PL)
check('JNI + Kotlin external setMaskBlendMatched khớp', 'NativeBridge_setMaskBlendMatched' in JN and 'external fun setMaskBlendMatched(enabled: Boolean)' in NB)
check('Kotlin đặt cờ ở ĐỦ 3 điểm đặt cờ DD (generatePanels, regeneratePanel, điểm thứ ba)', MP.count('NativeBridge.setMaskBlendMatched(settings.inpaintMatchedNoise)') == 3 and MP.count('NativeBridge.setDifferentialDiffusion(settings.differentialInpaint)') == 3)
check('Models: inpaintMatchedNoise mặc định TẮT và có UI', 'val inpaintMatchedNoise: Boolean = false' in ML and 'helpKey = "inpaintMatchedNoise"' in ST)
check('PipelineSd15Cpu: log RAM trước/sau nạp từng UNet phụ và sau lượt chạy đầu; log thời gian CLIP riêng', 'mem_info::rssKb()' in P15 and 'logMemAfterRun(log_mem_after)' in P15 and P15.count('logMemAfterRun(log_mem_after);') == 2 and 'mất "' in P15)
shutil.rmtree(tmp, ignore_errors=True)
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
