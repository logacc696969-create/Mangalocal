#!/usr/bin/env python3
"""Kiểm tra mục 244 (ảnh làm khung hình cho model video). Hai phần:
 (A) ĐỌC TRỰC TIẾP mã nguồn Kotlin (VideoPrep.kt, MangaPipeline.kt...) để kiểm tính nhất quán dữ liệu/nối dây — không chép tay.
 (B) Mô phỏng Python của cropForAspect/readiness/buildPrompt (chép công thức, không có kotlinc) để kiểm HÌNH HỌC và LOGIC."""
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(p): return open(os.path.join(ROOT, p), encoding='utf-8').read()
VP = rd('app/src/main/java/com/mangalocal/pipeline/VideoPrep.kt')
MP = rd('app/src/main/java/com/mangalocal/pipeline/MangaPipeline.kt')
VM = rd('app/src/main/java/com/mangalocal/ui/MainViewModel.kt')
MD = rd('app/src/main/java/com/mangalocal/model/Models.kt')
UI = rd('app/src/main/java/com/mangalocal/ui/ExpressionStudioScreen.kt')
ST = rd('app/src/main/java/com/mangalocal/ui/SettingsScreen.kt')
PX = rd('app/src/main/java/com/mangalocal/pipeline/PublishExporter.kt')

def check(n, c, extra=''):
    print(('PASS ' if c else 'FAIL ') + n + (' ' + extra if extra and not c else '')); return c

# ---------- (A) nguồn Kotlin ----------
def targets():
    m = re.search(r'enum class VideoTarget\((.*?)\) \{(.*?)\n\}', VP, re.S)
    return re.findall(r'(\w+)\("([^"]*)",\s*(\d+),\s*(\d+)\)', m.group(2))

# Các độ phân giải ghi trong README FlashPortrait/Wan đã tra: 512x512, 480x832, 832x480, 720x720, 720x1280, 1280x720
SOURCED = {(512, 512), (480, 832), (832, 480), (720, 720), (720, 1280), (1280, 720)}

def crop_for_aspect(W, H, tw, th, keep):
    if W <= 0 or H <= 0: return (0, 0, max(W, 0), max(H, 0)), False
    if tw <= 0 or th <= 0: return (0, 0, W, H), True
    a = tw / th
    if W / H > a: ch = H; cw = min(W, int(round(H * a)))
    else: cw = W; ch = min(H, int(round(W / a)))
    valid = [k for k in keep if k[2] - k[0] > 0 and k[3] - k[1] > 0]
    if not valid: cx, cy = W / 2, H / 2
    else:
        cx = (min(k[0] for k in valid) + max(k[2] for k in valid)) / 2
        cy = (min(k[1] for k in valid) + max(k[3] for k in valid)) / 2
    left = max(0, min(int(round(cx - cw / 2)), W - cw)); top = max(0, min(int(round(cy - ch / 2)), H - ch))
    r = (left, top, left + cw, top + ch)
    return r, all(k[0] >= r[0] and k[2] <= r[2] and k[1] >= r[1] and k[3] <= r[3] for k in valid)

EMO = dict(re.findall(r'"(\w+)" to "([^"]+)"', VP[VP.index('private val EMOTION_WORDS'):VP.index('fun emotionWord')]))

def emotion_word(k): return EMO.get(k, 'a calm look') if k else 'a calm look'

def build_prompt(names, start, end, speakers, has_end, face_focus):
    parts = []
    for n in names[:3]:
        s, e = start.get(n), end.get(n)
        speaks = any(x.lower() == n.lower() for x in speakers)
        if has_end and e and e != (s or 'neutral'):
            line = f"{n}'s expression shifts from {emotion_word(s)} to {emotion_word(e)}, with a natural blink and a subtle head movement"
        elif s and s != 'neutral': line = f"{n} holds {emotion_word(s)} with subtle natural motion, blinking and slow breathing"
        else: line = f"{n} stays calm with natural blinking and slow breathing"
        if speaks: line += f", lips moving naturally as {n} speaks"
        parts.append(line)
    cam = "the camera makes a slow gentle push-in toward the face" if face_focus else "the camera stays mostly static with a very slight drift"
    out = '. '.join(parts) + '. ' + cam[0].upper() + cam[1:] + ', calm natural pace.'
    if has_end: out += ' Start exactly from the first image and end exactly at the last image.'
    return out

def main():
    ok = True
    T = targets()
    ok &= check('VideoTarget có KEEP và 6 khung đích', len(T) == 7 and T[0][0] == 'KEEP', str(T))
    dims = {(int(w), int(h)) for k, l, w, h in T if k != 'KEEP'}
    ok &= check('6 khung đích khớp ĐÚNG danh sách độ phân giải trong README FlashPortrait/Wan đã tra', dims == SOURCED, str(dims ^ SOURCED))
    ok &= check('mọi khung đích có kích thước chia hết cho 16 (yêu cầu thường gặp của Wan)', all(w % 16 == 0 and h % 16 == 0 for w, h in dims))

    neg = re.search(r'NEGATIVE_PROMPT =\s*"([^"]+)"', VP).group(1)
    sourced_neg = ['morphing', 'warping', 'distortion', 'flickering', 'jittering', 'face deformation', 'body distortion', 'changing identity']
    ok &= check('negative prompt chứa đủ 8 cụm đã tra trong hướng dẫn Wan 2.2 (VEED)', all(t in neg for t in sourced_neg))

    bp_src = VP[VP.index('fun buildPrompt'):]
    ok &= check('prompt video là câu văn mô tả chuyển động, không có cú pháp trọng số tag "(x:1.2)"', not re.search(r'\([^()\n"]*:\d(\.\d+)?\)', bp_src))
    ok &= check('gói video dùng ảnh SẠCH: không gọi renderPanelWithBubbles trong exportVideoPack',
                'renderPanelWithBubbles' not in MP[MP.index('suspend fun exportVideoPack'):MP.index('// mục 243 — chuỗi prompt biểu cảm')])
    ok &= check('khung kết dùng tryExpressionFacePass với chỉ số tạm riêng 8000+ (không ghi đè ảnh chính)', 'workIndex = work' in MP and '8000 + panel.index' in MP)
    ok &= check('tryExpressionFacePass có tham số forced và workIndex', 'forced: Map<String, String>? = null' in MP and 'workIndex: Int = panel.index' in MP)
    ok &= check('Models: PanelOverrideSettings có videoEndExpressions/videoEndFramePath; settings có exportVideoPack/videoPackTarget',
                all(x in MD for x in ('videoEndExpressions', 'videoEndFramePath', 'exportVideoPack', 'videoPackTarget')))
    ok &= check('exportChapter gọi exportVideoPack khi extras.videoPack', 'extras.videoPack && extras.story != null' in MP)
    ok &= check('ViewModel truyền videoPack/videoTarget vào ExportExtras', 'videoPack = st.exportVideoPack' in VM and 'val videoPack: Boolean' in PX)
    ok &= check('UI: tab "Kiểm tra & biến thể" được đăng ký và có VideoReadyTab (đã đổi nhãn: ứng dụng tạo ảnh, không tạo video)',
                '"Kiểm tra & biến thể"' in UI and 'private fun VideoReadyTab' in UI and '"Làm video"' not in UI)
    ok &= check('Settings: công tắc gói video', 'settings.exportVideoPack' in ST)
    ok &= check('UI không gọi hàm tự bịa (clickableNoRipple...)', 'clickableNoRipple' not in UI)
    # Mọi hàm công khai của ViewModel thuộc hệ thống biểu cảm/video PHẢI được giao diện gọi tới (không để hàm mồ côi).
    vm_funcs = re.findall(r'^    fun (\w+)\(', VM[VM.index('mục 240 TECHNICAL_STATUS.md — HỆ THỐNG BIỂU CẢM TẬP TRUNG'):], re.M)
    own = ['saveExpressionPreset', 'deleteExpressionPreset', 'generateExpressionAnchor', 'generateExpressionAnchors', 'deleteExpressionAnchor',
           'setPanelCharacterExpression', 'clearAllPanelExpressionOverrides', 'fillExpressionInertia', 'compareExpressionVocab', 'clearExpressionCompare',
           'planExpressionArcWithLlm', 'undoExpressionPlan', 'analyzeVideoReadiness', 'setPanelVideoEndExpression', 'generatePanelVideoEndFrame', 'clearPanelVideoEndFrame']
    UI_ALL = UI + ST + rd('app/src/main/java/com/mangalocal/ui/GalleryReviewScreen.kt')
    orphans = [f for f in own if ('vm.' + f + '(') not in UI_ALL]
    ok &= check('không còn hàm ViewModel mồ côi (mọi hàm biểu cảm/video đều có chỗ gọi trong UI)', not orphans, str(orphans))

    # ---------- mục 245: giữ danh tính + nạp model cho luồng theo yêu cầu ----------
    IP = rd('app/src/main/java/com/mangalocal/pipeline/ImagePipeline.kt')
    NB = rd('app/src/main/java/com/mangalocal/pipeline/NativeBridge.kt')
    decl = NB[NB.index('external fun sdImg2ImgWithReferenceAndPose'):]
    decl = decl[:decl.index('Boolean')]
    declared = set(re.findall(r'(\w+)\s*:\s*[\w?]+', decl))
    fn = IP[IP.index('suspend fun inpaintWithIdentity'):]
    fn = fn[:fn.index('suspend fun generatePanel(')]
    call = fn[fn.index('NativeBridge.sdImg2ImgWithReferenceAndPose('):]
    named = set(re.findall(r'(\w+)\s*=\s*(?!=)', call))
    ok &= check('inpaintWithIdentity: mọi tham số đặt tên đều có trong khai báo NativeBridge (chống lỗi tên tham số)', named <= declared, str(named - declared))
    ok &= check('inpaintWithIdentity ghi ra outFile riêng và ném lỗi khi native trả false', 'outFile.absolutePath' in fn and 'throw RuntimeException' in fn)
    ok &= check('ImagePipeline có isAugmentedLoaded()', 'fun isAugmentedLoaded() = sdAugmentedCtx != 0L' in IP)
    rc = MP[MP.index('private suspend fun inpaintRegionCropped'):]
    rc = rc[:rc.index('// mục 237 — dán pixel gốc ngoài mask cho lượt vẽ cả khung')]
    ok &= check('inpaintRegionCropped: có đường giữ danh tính, chỉ khi augmented đã nạp, và vẫn còn img2imgFix làm đường dự phòng',
                'identityRefPath' in rc and 'isAugmentedLoaded()' in rc and 'imagePipeline.inpaintWithIdentity' in rc and 'imagePipeline.img2imgFix(' in rc)
    ok &= check('đường giữ danh tính bắt lỗi và rơi về img2img thường (không làm hỏng lượt vẽ)', 'catch (ex: Exception)' in rc[rc.index('inpaintWithIdentity'):rc.index('inpaintWithIdentity') + 900])
    fp = MP[MP.index('private suspend fun tryExpressionFacePass'):]
    fp = fp[:fp.index('// mục 229 TECHNICAL_STATUS.md — HYBRID HẬU KỲ')]
    ok &= check('lượt vẽ mặt nạp model khi chưa nạp (img2imgFix không tự nạp) cho cả SD1.5 và SDXL', 'imagePipeline.loadSD(' in fp and 'imagePipeline.loadSDSdxl(' in fp and 'isSdLoaded()' in fp)
    ok &= check('lượt vẽ mặt truyền ảnh tham chiếu danh tính lấy từ getCharacterAnchor (ưu tiên ảnh đúng biểu cảm)',
                'val idRef = if (settings.expressionFaceIdentity)' in fp and 'expressionKey = key' in fp and 'identityRefPath = idRef' in fp)
    ga = MP[MP.index('suspend fun generateExpressionAnchorImage'):]
    ga = ga[:ga.index('// mục 238 TECHNICAL_STATUS.md — LƯỢT VẼ LẠI BIỂU CẢM TỪNG KHUÔN MẶT')]
    ok &= check('generateExpressionAnchorImage nhận story, nạp model SD trước khi vẽ và dùng chính ảnh anchor làm tham chiếu danh tính',
                'story: Story' in ga and 'imagePipeline.loadSD(' in ga and 'identityRefPath = if (settings.expressionFaceIdentity) srcPath' in ga)
    ok &= check('ViewModel không còn gọi generateExpressionAnchorImage theo chữ ký cũ (thiếu story)', 'generateExpressionAnchorImage(character, key' not in VM)
    ok &= check('Models: expressionFaceIdentity/expressionIdentityScale và UI có công tắc', 'expressionFaceIdentity' in MD and 'expressionIdentityScale' in MD and 'settings.expressionFaceIdentity' in ST)

    # ---------- (B) mô phỏng ----------
    r, all_in = crop_for_aspect(1024, 1024, 832, 480, [(400, 300, 600, 500)])
    ok &= check('cắt 16:9 từ ảnh vuông: đúng tỉ lệ (sai lệch < 1px) và trong ảnh', abs((r[2] - r[0]) / (r[3] - r[1]) - 832 / 480) < 0.01 * 832 / 480 and 0 <= r[0] and r[2] <= 1024 and 0 <= r[1] and r[3] <= 1024, str(r))
    ok &= check('cắt 16:9: giữ trọn vùng mặt', all_in)
    r, all_in = crop_for_aspect(1024, 1024, 480, 832, [(100, 600, 300, 800)])
    ok &= check('cắt 9:16 từ ảnh vuông: giữ mặt ở vùng thấp bên trái và vẫn trong ảnh', all_in and r[0] >= 0 and r[3] <= 1024)
    r, all_in = crop_for_aspect(1024, 1024, 832, 480, [(0, 0, 1024, 1024)])
    ok &= check('vùng giữ lớn hơn khung cắt -> containsAll=false (báo cắt mặt)', not all_in)
    r, all_in = crop_for_aspect(512, 768, 0, 0, [(10, 10, 50, 50)])
    ok &= check('KEEP (0x0): giữ nguyên toàn ảnh', r == (0, 0, 512, 768) and all_in)
    r, _ = crop_for_aspect(1280, 720, 832, 480, [])
    ok &= check('ảnh đã 16:9 và không có mặt: cắt toàn ảnh', r[2] - r[0] == 1280 or abs((r[2]-r[0])/(r[3]-r[1]) - 832/480) < 0.01)
    r, _ = crop_for_aspect(100, 100, 832, 480, [(0, 0, 10, 10)])
    ok &= check('ảnh rất nhỏ vẫn cho khung hợp lệ trong ảnh', r[0] >= 0 and r[2] <= 100 and r[3] <= 100)
    import random
    rnd = random.Random(5); good = True
    for _ in range(2000):
        W = rnd.choice([512, 768, 1024, 2048]); H = rnd.choice([512, 768, 1024, 2048]); tw, th = rnd.choice([(832, 480), (480, 832), (720, 720), (1280, 720)])
        keep = []
        for _k in range(rnd.randint(0, 3)):
            x = rnd.randint(0, W - 40); y = rnd.randint(0, H - 40); keep.append((x, y, min(W, x + rnd.randint(20, 300)), min(H, y + rnd.randint(20, 300))))
        r, a = crop_for_aspect(W, H, tw, th, keep)
        good &= 0 <= r[0] < r[2] <= W and 0 <= r[1] < r[3] <= H and abs((r[2] - r[0]) / (r[3] - r[1]) - tw / th) < 0.02
    ok &= check('2000 ca ngẫu nhiên: khung cắt luôn hợp lệ và đúng tỉ lệ', good)

    p = build_prompt(['An', 'Binh'], {'An': 'angry', 'Binh': 'scared'}, {'An': 'smile'}, {'An'}, True, True)
    ok &= check('khung kết: mô tả đổi biểu cảm của nhân vật có biểu cảm kết', "An's expression shifts from anger to a warm smile" in p, p)
    ok &= check('nhân vật không có biểu cảm kết: giữ biểu cảm đầu', 'Binh holds fear' in p)
    ok &= check('người đang nói: có chuyển động môi', 'lips moving naturally as An speaks' in p)
    ok &= check('có khung kết: kèm câu "Start exactly from the first image and end exactly at the last image"', p.endswith('Start exactly from the first image and end exactly at the last image.'))
    ok &= check('hành động chủ thể đứng ĐẦU câu, camera sau (khuyến nghị Wan 2.2)', p.index('An') < p.index('camera') or p.index('An') < p.lower().index('camera'))
    ok &= check('không mô tả ngoại hình (không có từ tóc/áo/màu)', not any(w in p.lower() for w in ('hair', 'shirt', 'dress', 'wearing')))
    p2 = build_prompt(['An'], {}, {}, set(), False, False)
    ok &= check('không biểu cảm, không khung kết: bình tĩnh + camera gần như tĩnh, không câu First/Last', 'stays calm' in p2 and 'mostly static' in p2 and 'first image' not in p2)
    p3 = build_prompt(['A', 'B', 'C', 'D', 'E'], {}, {}, set(), False, False)
    ok &= check('tối đa 3 nhân vật trong prompt (tránh prompt dài, làm động quá nhiều thứ)', 'D ' not in p3 and 'E ' not in p3)
    ok &= check('khoá không có trong bảng -> "a calm look"', emotion_word('khong_co') == 'a calm look' and emotion_word(None) == 'a calm look')
    ok &= check('bảng từ cảm xúc phủ 12 nhãn gốc + 15 biểu cảm mở rộng', len(EMO) >= 27, str(len(EMO)))

    print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)

if __name__ == '__main__':
    main()
