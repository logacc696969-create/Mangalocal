// mục 286 — thư viện JNI thử. Chèn PROXY vào JavaVM để ĐẾM Attach/Detach/GetEnv thật (và kết quả thật của JVM), rồi chạy hai mẫu: CŨ (nguyên văn khối 5 dòng đã bị thay) và MỚI (jni_progress.hpp).
#include <jni.h>
#include <atomic>
#include <thread>
#include "jni_progress.hpp"

static JavaVM* g_real = nullptr; static JNIInvokeInterface_ g_tbl; static JavaVM_ g_proxy;
static std::atomic<int> g_attach{0}, g_detach{0}, g_detachFailed{0}, g_getenv{0}; static std::atomic<long> g_drift{0};
// ĐO RÒ THAM CHIẾU CỤC BỘ trực tiếp: tạo một tham chiếu cục bộ TRƯỚC và một SAU vòng lặp; nếu mọi tham chiếu tạm đã được giải phóng thì tham chiếu sau nằm sát tham chiếu trước (ô kế tiếp), còn rò thì nhảy xa.
static long refDrift(JNIEnv* e, jobject a, jobject b) { (void)e; long d = (long)(reinterpret_cast<intptr_t>(b) - reinterpret_cast<intptr_t>(a)); return d < 0 ? -d : d; }
static jint JNICALL pAttach(JavaVM*, void** penv, void* args) { g_attach++; return g_real->AttachCurrentThread(penv, args); }
static jint JNICALL pDetach(JavaVM*) { g_detach++; jint r = g_real->DetachCurrentThread(); if (r != JNI_OK) g_detachFailed++; return r; }
static jint JNICALL pGetEnv(JavaVM*, void** env, jint v) { g_getenv++; return g_real->GetEnv(env, v); }
static JavaVM* proxyVm(JNIEnv* env) {
    if (!g_real) { env->GetJavaVM(&g_real); g_tbl = *g_real->functions; g_tbl.AttachCurrentThread = pAttach; g_tbl.DetachCurrentThread = pDetach; g_tbl.GetEnv = pGetEnv; g_proxy.functions = &g_tbl; }
    return &g_proxy;
}
extern "C" {
JNIEXPORT void JNICALL Java_Probe_resetCounts(JNIEnv* e, jclass) { proxyVm(e); g_attach = g_detach = g_detachFailed = g_getenv = 0; g_drift = 0; }
JNIEXPORT jintArray JNICALL Java_Probe_counts(JNIEnv* e, jclass) { jint v[5] = {g_attach, g_detach, g_detachFailed, g_getenv, (jint)g_drift}; jintArray a = e->NewIntArray(5); e->SetIntArrayRegion(a, 0, 5, v); return a; }

// MẪU CŨ — nguyên văn khối đã bị thay ở 14 chỗ (ip_adapter.cpp, mnn_diffusion_pipeline.cpp, …), đặt trong lambda ProgressCallback như thật
JNIEXPORT jint JNICALL Java_Probe_runOldPattern(JNIEnv* e, jclass, jobject cb, jint steps) {
    JavaVM* jvm = proxyVm(e); jobject cbGlobal = e->NewGlobalRef(cb);
    auto progress = [jvm, cbGlobal](int step, int total) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(reinterpret_cast<void**>(&env), nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };
    jobject pb = e->NewLocalRef(cb);
    for (int i = 1; i <= steps; i++) progress(i, steps);   // Pipeline::generate gọi progress đồng bộ trên luồng gọi JNI
    jobject pa = e->NewLocalRef(cb); g_drift = refDrift(e, pb, pa); e->DeleteLocalRef(pa); e->DeleteLocalRef(pb);
    e->DeleteGlobalRef(cbGlobal); return 0;
}
// MẪU MỚI trên luồng Java
JNIEXPORT jint JNICALL Java_Probe_runNewPattern(JNIEnv* e, jclass, jobject cb, jint steps) {
    JavaVM* jvm = proxyVm(e); jobject cbGlobal = e->NewGlobalRef(cb);
    auto progress = [jvm, cbGlobal](int step, int total) { if (!cbGlobal || !jvm) return; mangalocal::jniCallProgress(jvm, cbGlobal, step, total); };
    jobject pb = e->NewLocalRef(cb);
    for (int i = 1; i <= steps; i++) progress(i, steps);
    jobject pa = e->NewLocalRef(cb); g_drift = refDrift(e, pb, pa); e->DeleteLocalRef(pa); e->DeleteLocalRef(pb);
    e->DeleteGlobalRef(cbGlobal); return 0;
}
// MẪU MỚI trên luồng native thuần (chưa gắn JVM): phải Attach rồi Detach mỗi lần gọi
JNIEXPORT jint JNICALL Java_Probe_runNewOnNativeThread(JNIEnv* e, jclass, jobject cb, jint steps) {
    JavaVM* jvm = proxyVm(e); jobject cbGlobal = e->NewGlobalRef(cb);
    std::thread t([&] { for (int i = 1; i <= steps; i++) mangalocal::jniCallProgress(jvm, cbGlobal, i, steps); });
    t.join(); e->DeleteGlobalRef(cbGlobal); return 0;
}
}
