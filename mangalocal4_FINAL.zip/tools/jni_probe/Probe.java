// mục 286 — chương trình thử cho tools/test_jni_progress.py: so mẫu callback tiến trình CŨ (Attach/Detach mỗi step) với helper MỚI (jni_progress.hpp) trên JVM thật.
public class Probe {
    public interface Cb { void onProgress(int step, int total); }
    static native int runOldPattern(Cb cb, int steps);          // mẫu cũ, chạy trên luồng Java đang gọi JNI (đúng như Pipeline::generate)
    static native int runNewPattern(Cb cb, int steps);          // helper mới, cũng trên luồng Java
    static native int runNewOnNativeThread(Cb cb, int steps);   // helper mới, trên std::thread native chưa gắn vào JVM
    static native int[] counts();                                // {attach, detach, detachFailed, getEnv, refDrift}
    static native void resetCounts();

    static int delivered = 0, thrown = 0;
    public static void main(String[] a) {
        String mode = a[0]; int steps = Integer.parseInt(a[1]); boolean thr = a.length > 2 && a[2].equals("throw");
        Cb cb = (s, t) -> { delivered++; if (thr && s == 3) { thrown++; throw new RuntimeException("callback ném lỗi (step 3)"); } };
        resetCounts(); String err = "";
        int rc = -99;
        try {
            if (mode.equals("old")) rc = runOldPattern(cb, steps);
            else if (mode.equals("new")) rc = runNewPattern(cb, steps);
            else rc = runNewOnNativeThread(cb, steps);
        } catch (Throwable t) { err = t.getClass().getSimpleName(); }
        int[] c = counts();
        System.out.println("RESULT mode=" + mode + " rc=" + rc + " delivered=" + delivered + " thrown=" + thrown + " attach=" + c[0] + " detach=" + c[1] + " detachFailed=" + c[2] + " getenv=" + c[3] + " drift=" + c[4] + " escaped=" + err);
    }
}
