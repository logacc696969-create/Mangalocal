// mục 266 — STUB mô phỏng chữ ký OkHttp 4.x (chỉ phần dự án dùng) để kotlinc kiểm KIỂU/PHẠM VI cho mã kết nối mạng ngay tại sandbox (không có Android SDK/Maven).
// Chữ ký lấy từ OkHttp 4: Response.code/body(nullable)/header(name, default), Request.Builder.url/post/get/addHeader/build, OkHttpClient.Builder.*Timeout(Long, TimeUnit),
// MediaType.Companion.toMediaType, RequestBody.Companion.toRequestBody. KHÔNG thay CI: stub lệch thư viện thật thì kiểm tra này vô nghĩa — đối chiếu khi nâng phiên bản OkHttp.
package okhttp3

import java.util.concurrent.TimeUnit

class MediaType private constructor() {
    companion object {
        @JvmStatic fun String.toMediaType(): MediaType = MediaType()
    }
}

abstract class RequestBody {
    companion object {
        @JvmStatic fun String.toRequestBody(contentType: MediaType? = null): RequestBody = object : RequestBody() {}
        @JvmStatic fun ByteArray.toRequestBody(contentType: MediaType? = null): RequestBody = object : RequestBody() {}
    }
}

abstract class ResponseBody {
    abstract fun bytes(): ByteArray
    abstract fun string(): String
}

/**
 * KỊCH BẢN cho test hành vi (tools/test_http_retry_exec.py): mỗi lần OkHttpClient.newCall(...).execute() lấy phần tử kế tiếp của StubNet.script —
 * StubResp (phản hồi có mã/thân/header, có thể "đứt giữa chừng khi đọc thân") hoặc java.io.IOException (lỗi mạng khi kết nối). Hết kịch bản -> lỗi to để test không treo.
 */
class StubResp(val code: Int, val body: ByteArray = ByteArray(0), val headers: Map<String, String> = emptyMap(), val failOnRead: Boolean = false)

object StubNet {
    val script = java.util.ArrayDeque<Any>()
    var calls = 0
    fun reset() { script.clear(); calls = 0 }
}

class Response internal constructor(private val r: StubResp) : java.io.Closeable {
    val code: Int = r.code
    val isSuccessful: Boolean = r.code in 200..299
    val body: ResponseBody? = object : ResponseBody() {
        override fun bytes(): ByteArray {
            if (r.failOnRead) throw java.io.IOException("đứt kết nối giữa chừng khi đọc thân")
            return r.body
        }
        override fun string(): String = String(bytes(), Charsets.UTF_8)
    }
    fun header(name: String, defaultValue: String? = null): String? = r.headers[name] ?: defaultValue
    override fun close() {}
}

class Request private constructor() {
    class Builder {
        fun url(url: String): Builder = this
        fun post(body: RequestBody): Builder = this
        fun get(): Builder = this
        fun addHeader(name: String, value: String): Builder = this
        fun build(): Request = Request()
    }
}

interface Call {
    fun execute(): Response
}

class OkHttpClient {
    class Builder {
        fun connectTimeout(timeout: Long, unit: TimeUnit): Builder = this
        fun readTimeout(timeout: Long, unit: TimeUnit): Builder = this
        fun writeTimeout(timeout: Long, unit: TimeUnit): Builder = this
        fun build(): OkHttpClient = OkHttpClient()
    }
    fun newCall(request: Request): Call = object : Call {
        override fun execute(): Response {
            StubNet.calls++
            val next = StubNet.script.pollFirst() ?: throw IllegalStateException("StubNet: hết kịch bản (gọi nhiều hơn dự kiến)")
            if (next is java.io.IOException) throw next
            return Response(next as StubResp)
        }
    }
}
