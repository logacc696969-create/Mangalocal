// mục 266 — STUB kotlinx.coroutines (chỉ withContext/delay/Dispatchers.IO/CoroutineScope) với đúng dạng chữ ký thật: block có receiver CoroutineScope.
package kotlinx.coroutines

open class CoroutineDispatcher
object Dispatchers { val IO: CoroutineDispatcher = CoroutineDispatcher() }
class CoroutineScope
suspend fun <T> withContext(context: CoroutineDispatcher, block: suspend CoroutineScope.() -> T): T = CoroutineScope().block()
suspend fun delay(timeMillis: Long) {}
