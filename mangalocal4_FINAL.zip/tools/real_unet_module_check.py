#!/usr/bin/env python3
"""mục 283 — CHẠY THẬT `sd_engine/UnetModule.hpp` (UnetModuleSet) trên UNet diffusers THẬT (thu nhỏ) xuất bằng đúng đường của MNN, và so với torch.
Chuỗi: UNet diffusers thu nhỏ (attn1/attn2, GEGLU, resnet 3x3, time_emb_proj, down/upsample; 83 module Linear/Conv2d) -> torch.onnx.export (TorchScript, opset 17) -> `mnnconvert` THẬT
(trọng số NHÚNG trong .mnn như UNet của app, KHÔNG --saveExternalData) -> HAI LoRA kiểu kohya dựng từ TÊN MODULE TORCH (LoRA 1: toàn bộ 83 module; LoRA 2: ~một nửa module, rank/alpha khác)
-> tools/lora_to_mnn_spec.py -> `lora_attach_branch --strip-all-conv-weights` -> harness C++ (tools/mnn_probe/unet_module_real_unet.cpp) nạp UnetModuleSet THẬT trên MNN 3.6.1 THẬT và so với torch ĐÃ CỘNG THẲNG W + (alpha/rank)·B·A.
KHÔNG phải test mặc định (nặng: cần torch + diffusers + onnx + g++ + gói pip MNN==3.6.1 + mã nguồn MNN 3.6.1). Dựng môi trường (không cần GPU; torch CPU từ conda-forge vì bản PyPI là CUDA):
    micromamba create -n t -c conda-forge python=3.12 "pytorch=2.5.1=cpu_generic*" "numpy<2" onnx=1.17 diffusers=0.31 safetensors      (micromamba: github.com/mamba-org/micromamba-releases)
    pip install MNN==3.6.1   (vào python HỆ THỐNG — script gọi `mnnconvert` và liên kết _mnncengine*.so của nó; KHÔNG cần import MNN trong env torch)
    MNN_SRC=/đường/dẫn/MNN-3.6.1 /đường/env/t/bin/python tools/real_unet_module_check.py        # cần include/, schema/current/, 3rd_party/flatbuffers/include/
KHÔNG chứng minh: UNet SD1.5 kích thước đầy đủ (tên op của bản do bên thứ ba chuyển đổi có thể khác — chạy `--list` trên file đó), w8, OpenCL/NPU, RAM/tốc độ trên máy thật.
Mã thoát: 0 = đạt; 1 = không đạt; 2 = thiếu môi trường."""
import glob, json, os, shutil, subprocess, sys, tempfile, warnings
warnings.filterwarnings('ignore')
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, HERE)
from real_unet_lora_check import write_st, sh    # tái dùng hàm đã kiểm ở mục 269 (chỉ định nghĩa hàm, không chạy gì ở mức module)

def need_env():
    miss = []
    for m in ('torch', 'diffusers', 'onnx', 'numpy'):
        try: __import__(m)
        except Exception as e: miss.append(f'{m} ({type(e).__name__})')
    src = os.environ.get('MNN_SRC', '')
    for sub in ('include', 'schema/current', '3rd_party/flatbuffers/include'):
        if not os.path.isdir(os.path.join(src, sub)): miss.append(f'MNN_SRC/{sub}')
    mc = shutil.which('mnnconvert') or '/usr/local/bin/mnnconvert'
    if not os.path.exists(mc): miss.append('mnnconvert (pip install MNN==3.6.1 vào python hệ thống)')
    so = glob.glob('/usr/local/lib/python3*/dist-packages/_mnncengine*.so') + glob.glob('/usr/lib/python3*/site-packages/_mnncengine*.so') + glob.glob(os.path.expanduser('~/.local/lib/python3*/site-packages/_mnncengine*.so'))
    lp = glob.glob('/usr/lib/x86_64-linux-gnu/libpython3*.so')
    if not so: miss.append('_mnncengine*.so (gói pip MNN)')
    if not lp: miss.append('libpython3*.so')
    if not shutil.which('g++'): miss.append('g++')
    return miss, src, mc, (so[0] if so else ''), (lp[0] if lp else '')

def main():
    miss, src, mnnconvert, so, lp = need_env()
    if miss: print('THIẾU môi trường:', ', '.join(miss)); return 2
    import numpy as np, torch
    from diffusers import UNet2DConditionModel
    work = tempfile.mkdtemp(prefix='unet_module_'); ok = True
    def check(name, cond, detail=''):
        nonlocal ok
        print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + str(detail)[:400]) if (detail and not cond) else '')); ok &= bool(cond)
    env = dict(os.environ, LD_PRELOAD=lp)
    exe = os.path.join(work, 'lora_attach')
    rc, out = sh(['g++', '-std=c++17', '-O1', '-w', os.path.join(HERE, 'mnn_probe/lora_attach_branch.cpp'), '-I', os.path.join(src, 'include'), '-I', os.path.join(src, 'schema/current'), '-I', os.path.join(src, '3rd_party/flatbuffers/include'), '-o', exe])
    check('lora_attach_branch.cpp biên dịch với MNN thật', rc == 0, out[-300:])
    harness = os.path.join(work, 'harness')
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-w', '-D_GLIBCXX_USE_CXX11_ABI=0', f'-I{src}/include', f'-I{ROOT}/app/src/main/jni', os.path.join(HERE, 'mnn_probe/unet_module_real_unet.cpp'), '-o', harness, so,
                        '-Wl,--allow-shlib-undefined', '-Wl,-rpath,' + os.path.dirname(so), '-lpthread', '-ldl'], capture_output=True, text=True)
    check('harness (UnetModule.hpp THẬT) biên dịch + liên kết MNN thật', r.returncode == 0, r.stderr[-400:])
    if rc or r.returncode: return 1
    H, W, SEQ, CD, TS = 8, 8, 77, 24, 421
    def mk():
        return UNet2DConditionModel(sample_size=H, in_channels=4, out_channels=4, down_block_types=('CrossAttnDownBlock2D', 'DownBlock2D'), up_block_types=('UpBlock2D', 'CrossAttnUpBlock2D'),
                                    block_out_channels=(16, 32), layers_per_block=1, cross_attention_dim=CD, attention_head_dim=4, norm_num_groups=4).eval()
    torch.manual_seed(0); unet = mk()
    sample = torch.randn(2, 4, H, W); ts = torch.tensor([TS], dtype=torch.int32)
    e0, e1, e2 = torch.randn(2, SEQ, CD), torch.randn(2, SEQ, CD), torch.randn(2, SEQ, CD)
    with torch.no_grad():
        ref_base = unet(sample, ts, e0, return_dict=False)[0].numpy()
        torch.onnx.export(unet, (sample, ts, e0, False), os.path.join(work, 'model.onnx'), input_names=['sample', 'timestep', 'encoder_hidden_states'], output_names=['out_sample'], dynamic_axes=None, do_constant_folding=True, opset_version=17)
    mnn = os.path.join(work, 'base.mnn')
    W8 = os.environ.get('W8') == '1'   # W8=1: lượng tử hoá trọng số 8-bit (định dạng thực tế của model trong app) — trọng số nằm trong quanParameter, không phải weight float
    FP16 = os.environ.get('FP16') == '1'   # FP16=1: `--fp16` (trọng số nửa độ chính xác, cũng nằm trong quanParameter)
    rc, out = sh([mnnconvert, '-f', 'ONNX', '--modelFile', os.path.join(work, 'model.onnx'), '--MNNModel', mnn] + (['--weightQuantBits', '8'] if W8 else []) + (['--fp16'] if FP16 else []))
    check('mnnconvert chuyển UNet thành công (trọng số nhúng trong .mnn' + (', w8' if W8 else '') + (', fp16' if FP16 else '') + ')', rc == 0 and os.path.exists(mnn) and not os.path.exists(mnn + '.weight'), out[-300:])
    if rc: return 1
    rc, ops_txt = sh([exe, '--list', mnn]); open(os.path.join(work, 'ops.txt'), 'w', encoding='utf-8').write(ops_txt)
    mods = {n: m for n, m in unet.named_modules() if isinstance(m, (torch.nn.Linear, torch.nn.Conv2d))}
    check('UNet thật có 83 module Linear/Conv2d và MNN liệt kê ≥ 83 op Convolution', len(mods) == 83 and ops_txt.count('Convolution') >= 83, f'{len(mods)} module; {ops_txt.count("Convolution")} op')
    def make_lora(tag, seed, rank, pick):
        rng = np.random.default_rng(seed); tens = {}; merged = mk(); merged.load_state_dict(unet.state_dict()); mm = dict(merged.named_modules()); n = 0
        for i, (name, m) in enumerate(mods.items()):
            if not pick(i, name): continue
            Wt = m.weight.detach().numpy(); o_, i_ = Wt.shape[0], Wt.shape[1]; conv = Wt.ndim == 4
            A = (rng.standard_normal((rank, i_) + Wt.shape[2:]) * 0.2).astype('f4'); B = (rng.standard_normal((o_, rank) + ((1, 1) if conv else ())) * 0.2).astype('f4')
            alpha = float(rng.choice([2, 4, 8])); key = 'lora_unet_' + name.replace('.', '_')
            tens[key + '.lora_down.weight'], tens[key + '.lora_up.weight'], tens[key + '.alpha'] = A, B, np.array(alpha, dtype='f4')
            mm[name].weight.data += torch.from_numpy((alpha / rank * (B.reshape(o_, rank) @ A.reshape(rank, -1))).reshape(Wt.shape).astype('f4')); n += 1
        write_st(os.path.join(work, f'lora{tag}.safetensors'), tens); return merged, n
    m1, n1 = make_lora(1, 7, 4, lambda i, nm: True)
    m2, n2 = make_lora(2, 11, 3, lambda i, nm: i % 2 == 0)
    with torch.no_grad(): ref1 = m1(sample, ts, e1, return_dict=False)[0].numpy(); ref2 = m2(sample, ts, e2, return_dict=False)[0].numpy()
    for tag, n in ((1, n1), (2, n2)):
        mapper = [sys.executable, os.path.join(HERE, 'lora_to_mnn_spec.py'), '--lora', os.path.join(work, f'lora{tag}.safetensors'), '--ops', os.path.join(work, 'ops.txt'), '--out', os.path.join(work, f'spec{tag}'), '--map', 'conv_out=out_sample']
        rc, out = sh(mapper); check(f'ánh xạ LoRA {tag}: đủ {n} module', rc == 0 and f'khớp & ghi {n}' in out, out[-300:])
        if rc: return 1
        rc, out = sh([exe, mnn, os.path.join(work, f'spec{tag}', 'spec.txt'), os.path.join(work, f'lora{tag}.lora.mnn'), '--strip-all-conv-weights'])
        check(f'lora_attach_branch --strip-all-conv-weights: gắn {n} nhánh cho LoRA {tag}', rc == 0 and f'gắn {n} nhánh' in out, out[-300:])
        if rc: return 1
        # so với cờ CŨ (--strip-base-weights: chỉ tước conv CÓ nhánh): LoRA phủ một phần thì tệp module phải nhỏ hơn hẳn khi tước hết
        rc, out = sh([exe, mnn, os.path.join(work, f'spec{tag}', 'spec.txt'), os.path.join(work, f'lora{tag}_old.lora.mnn'), '--strip-base-weights'])
        sz_new, sz_old = os.path.getsize(os.path.join(work, f'lora{tag}.lora.mnn')), os.path.getsize(os.path.join(work, f'lora{tag}_old.lora.mnn'))
        print(f'  [kích thước module LoRA {tag}] --strip-all-conv-weights {sz_new} B | --strip-base-weights (cũ) {sz_old} B')
        if tag == 2: check('LoRA phủ một phần (42/83 module): tước hết conv không-nhánh làm tệp module nhỏ đi ≥ 20% so với cờ cũ (fp32 ~3 lần; w8 ít hơn vì trọng số nền đã nhỏ 4 lần)', sz_new * 5 <= sz_old * 4, f'{sz_new} vs {sz_old}')
    for tag in (1, 2):   # tệp LoRA ĐẦY ĐỦ (không tước) cùng lượng tử hoá: tham chiếu chứng minh việc tước trọng số không mất mát
        rc, out = sh([exe, mnn, os.path.join(work, f'spec{tag}', 'spec.txt'), os.path.join(work, f'lora{tag}_full.mnn')]); check(f'tệp LoRA {tag} ĐẦY ĐỦ (không tước) tạo được', rc == 0, out[-200:])
    data = os.path.join(work, 'data'); os.makedirs(data)
    for f in ('base.mnn', 'lora1.lora.mnn', 'lora2.lora.mnn', 'lora1_full.mnn', 'lora2_full.mnn'): shutil.copy(os.path.join(work, f), os.path.join(data, f))
    for nm, a in (('sample', sample.numpy()), ('enc0', e0.numpy()), ('enc1', e1.numpy()), ('enc2', e2.numpy()), ('ref_base', ref_base), ('ref1', ref1), ('ref2', ref2)):
        np.ascontiguousarray(a, dtype='<f4').tofile(os.path.join(data, nm + '.bin'))
    open(os.path.join(data, 'meta.txt'), 'w').write(f'{TS} {H} {W} {CD} {float(os.environ.get("UNET_TOL", "0.15" if W8 else ("5e-3" if FP16 else "5e-4")))}\n')
    r = subprocess.run([harness, 'run', data], capture_output=True, text=True, env=env, timeout=280)
    for l in r.stdout.splitlines():
        if l.startswith(('PASS', 'FAIL', '  [')): print(l[:300])
    nf = sum(1 for l in r.stdout.splitlines() if l.startswith('FAIL')); npass = sum(1 for l in r.stdout.splitlines() if l.startswith('PASS'))
    check(f'UnetModuleSet THẬT trên UNet diffusers THẬT: {npass} phép kiểm đạt, {nf} lỗi (rc={r.returncode})', r.returncode == 0 and nf == 0 and npass >= 12, r.stderr[-300:])
    if os.environ.get('KEEP'): print('  (giữ thư mục làm việc:', work, ')')
    else: shutil.rmtree(work, ignore_errors=True)
    print('\nKẾT QUẢ:', 'ĐẠT' if ok else 'CÓ LỖI'); return 0 if ok else 1

if __name__ == '__main__':
    sys.exit(main())
