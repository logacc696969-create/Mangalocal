#!/usr/bin/env python3
"""mục 251 — kiểm thử phía APP của: (1) bố cục tương tác InteractDiffusion → khung xương → render lại; (2) báo cáo kiểm biểu cảm/tỉ lệ của hoán đổi mặt.

Thuật toán thuần (InteractionLayout, đọc khối tEXt của PNG, tóm tắt báo cáo, shoulderNorm) được chép lại bằng Python; riêng đọc tEXt được chạy trên
PNG THẬT do Pillow ghi (cùng định dạng server nhúng). Phần Kotlin còn lại đối chiếu chuỗi nguồn + khớp giao thức với server. KHÔNG chạy được Kotlin/mạng ở đây;
CHƯA build-test.
"""
import io, json, math, os, re, struct, sys
from PIL import Image
from PIL.PngImagePlugin import PngInfo

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
KB = os.path.join(ROOT, 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(KB, *p), encoding='utf8').read()
IL, RP = rd('pipeline', 'InteractionLayout.kt'), rd('pipeline', 'RemotePostProcess.kt')
SV = open(os.path.join(ROOT, 'tools', 'remote_server', 'app.py'), encoding='utf8').read()

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

J = 18
MIN_VIS = int(re.search(r'const val MIN_VISIBLE_JOINTS = (\d+)', IL).group(1)); MIN_BOX = int(re.search(r'const val MIN_BOX_JOINTS = (\d+)', IL).group(1)); PAD = float(re.search(r'const val BOX_PAD = ([0-9.]+)f', IL).group(1))
STAND = [(0.50, 0.12), (0.50, 0.20), (0.42, 0.20), (0.38, 0.32), (0.36, 0.44), (0.58, 0.20), (0.62, 0.32), (0.64, 0.44),
         (0.45, 0.50), (0.45, 0.68), (0.45, 0.88), (0.55, 0.50), (0.55, 0.68), (0.55, 0.88), (0.48, 0.10), (0.52, 0.10), (0.46, 0.11), (0.54, 0.11)]
def person(cx=0.5, cy=0.5, scale=1.0, hide=()):
    return [(cx + (x - 0.5) * scale, cy + (y - 0.5) * scale, i not in hide) for i, (x, y) in enumerate(STAND)]

# ---------------- bản chép InteractionLayout ----------------
ACTIONS = {'embrace': 'hugging', 'kiss': 'kissing', 'combat': 'hitting'}
def person_box(p, pad=PAD):
    v = [(x, y) for x, y, vis in p if vis]
    if len(v) < MIN_BOX: return None
    cl = lambda t: max(0.0, min(1.0, t))
    b = (cl(min(x for x, _ in v) - pad), cl(min(y for _, y in v) - pad), cl(max(x for x, _ in v) + pad), cl(max(y for _, y in v) + pad))
    return b if b[2] > b[0] and b[3] > b[1] else None
def centroid(p):
    v = [(x, y) for x, y, vis in p if vis]
    return None if not v else (sum(a for a, _ in v) / len(v), sum(b for _, b in v) / len(v))
def greedy(t, d):
    c = []
    for ti, a in enumerate(t):
        ca = centroid(a)
        if ca is None: continue
        for di, b in enumerate(d):
            cb = centroid(b)
            if cb is None: continue
            c.append((math.hypot(ca[0] - cb[0], ca[1] - cb[1]), ti, di))
    c.sort(key=lambda z: z[0]); ut, ud, out = set(), set(), []
    for _, ti, di in c:
        if ti in ut or di in ud: continue
        ut.add(ti); ud.add(di); out.append((ti, di))
    return out
def enough(p): return sum(1 for _, _, v in p if v) >= MIN_VIS
def ordered(t, d):
    if not t: return None
    mp = dict(greedy(t, d))
    if len(mp) < len(t): return None
    out = [d[mp[i]] for i in range(len(t))]
    return out if all(enough(x) for x in out) else None
def flatten(ps):
    out = []
    for p in ps:
        for x, y, v in p: out += [x, y, 0.0, 1.0 if v else 0.0]
    return out
def valid(layout, n): return layout is not None and len(layout) > 0 and len(layout) % (J * 4) == 0 and len(layout) // (J * 4) == n
def from_skeleton(data):
    per = J * 4
    return [[(data[b + j * 4], data[b + j * 4 + 1], data[b + j * 4 + 3] > 0.5) for j in range(J)] for b in range(0, len(data), per)]

check('Kotlin: ánh xạ hành động khớp bản chép (embrace→hugging, kiss→kissing, combat→hitting) và HICO-DET có hug/kiss/hit với person',
      all(('"%s" to "%s"' % kv) in IL for kv in ACTIONS.items()) and (MIN_VIS, MIN_BOX, PAD) == (10, 3, 0.03))
check('prompt cố định tiếng Anh theo hành động; hành động lạ -> null (không áp dụng cho run/neutral)', '"two people $it, photo"' in IL and 'category?.let { ACTION_PHRASES[it] }' in IL)

A, B = person(0.30, 0.5, 0.8), person(0.70, 0.5, 0.8)
bx = person_box(A)
check('hộp người bao quanh mọi khớp thấy được, nới %.2f, nằm trong [0,1]' % PAD, bx is not None and bx[0] < min(x for x, _, _ in A) and bx[2] > max(x for x, _, _ in A) and all(0 <= v <= 1 for v in bx))
check('hộp sát mép bị kẹp vào [0,1]; < %d khớp thấy được -> null' % MIN_BOX, person_box(person(0.02, 0.02, 0.1))[0] == 0.0 and person_box(person(hide=tuple(range(1, 18)))) is None and person_box(person(hide=tuple(range(0, 16)))) is None)
check('hai hộp của hai người đứng cạnh nhau KHÁC nhau và hộp trái nằm bên trái', person_box(A)[0] < person_box(B)[0] and person_box(A)[2] < person_box(B)[2])
D_swapped = [B, A]
check('người dò được xếp đúng THỨ TỰ người của khung xương mẫu dù YOLO trả ngược', ordered([A, B], D_swapped) == [A, B])
check('thiếu một người trong ảnh bố cục -> null (không đoán)', ordered([A, B], [A]) is None)
check('người dò được quá ít khớp (< %d) -> null (không tin khung xương thiếu)' % MIN_VIS, ordered([A, B], [A, person(0.7, 0.5, 0.8, hide=tuple(range(0, 12)))]) is None)
check('mẫu rỗng -> null; dò thừa người (3) vẫn chọn đúng 2 người khớp nhất', ordered([], [A]) is None and ordered([A, B], [A, B, person(0.5, 0.5, 0.3)]) == [A, B])
flat = flatten([A, B])
check('làm phẳng: 2 người × 18 khớp × 4 float = 144; z = 0; visible = 0/1; đọc lại bằng bộ đọc khung xương của dự án ra đúng toạ độ', len(flat) == 144 and flat[2] == 0.0 and flat[3] == 1.0 and from_skeleton(flat)[1][5][:2] == B[5][:2])
flat_h = flatten([person(hide=(3,))])
check('khớp bị ẩn -> visible = 0', flat_h[3 * 4 + 3] == 0.0 and flat_h[2 * 4 + 3] == 1.0)
check('layout hợp lệ chỉ khi đúng bội 72 VÀ đúng số người; null/rỗng/sai số người -> không dùng', valid(flat, 2) and not valid(flat, 3) and not valid(flat[:70], 1) and not valid([], 2) and not valid(None, 2))
check('Kotlin: personBox khớp bản chép (đủ khớp, nới pad, kẹp [0,1], hộp hợp lệ)', 'if (n < MIN_BOX_JOINTS) return null' in IL and '(x1 - pad).coerceIn(0f, 1f)' in IL and '(y2 + pad).coerceIn(0f, 1f)' in IL and 'if (box[2] > box[0] && box[3] > box[1]) box else null' in IL)
check('Kotlin: ghép tham lam/ordered/flatten/isValid khớp bản chép', 'OutputVerifier.greedyMatch(template, detected).associate { it.first to it.second }' in IL and 'if (map.size < template.size) return null' in IL
      and 'out[o] = j.x; out[o + 1] = j.y; out[o + 2] = 0f; out[o + 3] = if (j.visible) 1f else 0f' in IL and 'layout.size % per == 0 && layout.size / per == expectedPersons' in IL and 'out.all { hasEnoughJoints(it) }' in IL)

# ---------------- đọc tEXt PNG ----------------
def png_text(b, key):
    if len(b) < 8 or b[:8] != b'\x89PNG\r\n\x1a\n': return None
    o = 8
    while o + 12 <= len(b):
        ln = struct.unpack_from('>i', b, o)[0]
        if ln < 0 or o + 12 + ln > len(b): return None
        t = b[o + 4:o + 8].decode('ascii', 'replace')
        if t == 'tEXt':
            data = b[o + 8:o + 8 + ln]; z = data.find(b'\x00')
            if z >= 0 and data[:z].decode('latin-1') == key: return data[z + 1:].decode('latin-1')
        if t == 'IEND': return None
        o += 12 + ln
    return None
def mkpng(texts):
    im = Image.new('RGB', (8, 8), (1, 2, 3)); info = PngInfo()
    for k, v in texts: info.add_text(k, v)
    buf = io.BytesIO(); im.save(buf, 'PNG', pnginfo=info if texts else None); return buf.getvalue()
rep = {'task': 'faceswap', 'faces': [{'id': 'An', 'status': 'swapped'}]}
png = mkpng([('mangalocal_report', json.dumps(rep, ensure_ascii=True))])
check('đọc đúng báo cáo JSON trong khối tEXt do Pillow ghi (cùng cách server nhúng)', json.loads(png_text(png, 'mangalocal_report')) == rep)
png2 = mkpng([('other', 'x'), ('mangalocal_report', '{"a":1}'), ('more', 'y')])
check('nhiều khối tEXt: chọn đúng khoá; khoá không có -> null', png_text(png2, 'mangalocal_report') == '{"a":1}' and png_text(png2, 'khong_co') is None)
check('PNG không có chữ / không phải PNG / rỗng / bị cắt giữa chừng -> null, không ngoại lệ', png_text(mkpng([]), 'mangalocal_report') is None and png_text(b'\xff\xd8\xff', 'k') is None and png_text(b'', 'k') is None and png_text(png[:60], 'mangalocal_report') is None)
bad = bytearray(png); struct.pack_into('>I', bad, 8, 0xFFFFFFF0)
check('độ dài khối hỏng (âm/vượt quá tệp) -> null, không vòng lặp vô hạn', png_text(bytes(bad), 'mangalocal_report') is None)
check('Kotlin: pngText khớp bản chép (chữ ký, độ dài BE, tEXt, từ khoá/ISO-8859-1, dừng ở IEND, chặn độ dài hỏng)', all(t in RP for t in ['if (!isPng(b)) return null', 'if (len < 0 || o + 12L + len > b.size) return null', 'type == "tEXt"', 'Charsets.ISO_8859_1', 'if (type == "IEND") return null', 'o += 12 + len']))
check('khoá báo cáo app ↔ server khớp: "mangalocal_report"', 'info.add_text("mangalocal_report"' in SV and 'pngText(cur, "mangalocal_report")' in rd('pipeline', 'MangaPipeline.kt'))

# ---------------- tóm tắt báo cáo ----------------
def summary(js):
    try:
        faces = json.loads(js).get('faces')
        if faces is None: return None
        notes, rev = [], False
        for i, f in enumerate(faces):
            fid = f.get('id', '#%d' % (i + 1)); st = f.get('status', '')
            if st == 'reverted': rev = True; notes.append('Hoán đổi mặt «%s» bị HOÀN NGUYÊN: %s' % (fid, f.get('reason', '')))
            elif st == 'restored': notes.append('Hoán đổi mặt «%s»: %s' % (fid, f.get('reason', '')))
            elif st == 'skipped': notes.append('Hoán đổi mặt «%s» bỏ qua: %s' % (fid, f.get('reason', '')))
            if 'flag' in f: notes.append('«%s»: ⚠ %s' % (fid, f['flag']))
            if 'note' in f: notes.append('«%s»: %s' % (fid, f['note']))
        return notes, rev
    except Exception: return None
full = json.dumps({'faces': [{'id': 'An', 'status': 'reverted', 'reason': 'vẫn lệch biểu cảm (mar)'}, {'id': 'Bình', 'status': 'restored', 'reason': 'đã khôi phục miệng/mắt gốc vì lệch ear', 'flag': 'tỉ lệ mặt/vai ngoài dải'},
                           {'id': 'Cúc', 'status': 'skipped', 'reason': 'mặt quay 70°'}, {'id': 'Dũng', 'status': 'swapped', 'note': 'không có landmark'}]}, ensure_ascii=True)
n, r = summary(full)
check('tóm tắt: hoàn nguyên -> hasRevert=true; khôi phục/bỏ qua/cảnh báo/ghi chú đều thành dòng tiếng Việt; "swapped" sạch không thêm dòng', r is True and len(n) == 5 and n[0].startswith('Hoán đổi mặt «An» bị HOÀN NGUYÊN') and any('«Bình»: ⚠' in x for x in n) and any('Cúc' in x and 'bỏ qua' in x for x in n))
check('chỉ toàn "swapped" -> không ghi chú, hasRevert=false; JSON hỏng / thiếu faces -> null', summary(json.dumps({'faces': [{'id': 'a', 'status': 'swapped'}]})) == ([], False) and summary('{hỏng') is None and summary('{}') is None)
check('Kotlin: tóm tắt khớp bản chép (các trạng thái, chuỗi thông báo, null khi lỗi)', all(t in RP for t in ['"reverted" -> { revert = true; notes.add("Hoán đổi mặt «$id» bị HOÀN NGUYÊN: ${f.optString("reason")}") }', '"restored" -> notes.add("Hoán đổi mặt «$id»: ${f.optString("reason")}")', '"skipped" -> notes.add("Hoán đổi mặt «$id» bỏ qua: ${f.optString("reason")}")', 'if (f.has("flag"))', 'if (f.has("note"))', 'optJSONArray("faces") ?: return null', 'catch (e: Exception) {\n            null']))
check('trạng thái server phát ra ⊆ trạng thái app xử lý: swapped/restored/reverted/skipped', all(('status="%s"' % x in SV.replace(' ', '') or ('"%s"' % x) in SV) for x in ('swapped', 'restored', 'reverted', 'skipped')))

# ---------------- shoulderNorm ----------------
def shoulder(j):
    if len(j) < J or not j[2][2] or not j[5][2]: return None
    w = abs(j[2][0] - j[5][0]); return w if w >= 0.02 else None
check('shoulderNorm: đủ hai vai -> |Δx|; thiếu vai hoặc < 0.02 -> null', abs(shoulder(A) - 0.8 * 0.16) < 1e-6 and shoulder(person(hide=(5,))) is None and shoulder(person(scale=0.05)) is None)
check('Kotlin: shoulderNorm khớp bản chép và được gửi cho server dưới khoá "shoulder_norm" (server đọc đúng khoá đó)', 'w >= 0.02f' in RP and 'put("shoulder_norm", it.toDouble())' in rd('pipeline', 'MangaPipeline.kt') and 't.get("shoulder_norm")' in SV)

# ---------------- nối dây Kotlin ----------------
MP, ML, ST, RC = rd('pipeline', 'MangaPipeline.kt'), rd('model', 'Models.kt'), rd('ui', 'SettingsScreen.kt'), rd('pipeline', 'RemoteGenerationClient.kt')
check('resolveSkeletonData: dùng layoutSkeleton khi hợp lệ (đúng số người) TRƯỚC khi đọc mẫu; cùng hàm cho mọi nơi gọi', 'scene.layoutSkeleton?.takeIf { InteractionLayout.isValidLayout(it, characterOrder.size) }?.let { return it.toFloatArray() }' in MP
      and MP.index('scene.layoutSkeleton?.takeIf') < MP.index('if (poseTemplate.isBlank()) return FloatArray(0)'))
j = MP.index('private suspend fun prepareInteractionLayouts'); PI = MP[j:MP.index('// mục 250 TECHNICAL_STATUS.md — vị trí ĐẦU từng nhân vật')]
check('prepareInteractionLayouts: thoát sớm khi tắt/Remote GPU tắt; chỉ panel ĐÚNG 2 nhân vật có hành động hỗ trợ và CHƯA có layout', 'if (!settings.remoteInteractLayout || !cfg.enabled) return panels' in PI and 'sc.characters.size != 2' in PI and 'phrase == null' in PI and '!sc.layoutSkeleton.isNullOrEmpty()' in PI)
check('prepareInteractionLayouts: hộp từ khung xương MẪU (chưa có layout), gọi tác vụ "interact" không kèm ảnh, kích thước theo cài đặt, seed theo chỉ số cảnh', 'tmpl.size != 2' in PI and 'runImageTask("interact", null' in PI and '"width" to settings.width, "height" to settings.height' in PI and '"seed" to sc.index.toLong()' in PI)
check('prepareInteractionLayouts: không dò đủ 2 người -> giữ khung xương mẫu; lỗi 1 panel không hỏng cả lượt; server không hỗ trợ -> dừng; lưu vào scene.layoutSkeleton', 'if (ordered == null)' in PI and 'dùng khung xương mẫu' in PI and 'catch (ex: RemoteGenerationClient.RemoteTaskException) {\n                stopped = true' in PI and 'sc.copy(layoutSkeleton = InteractionLayout.flatten(ordered).toList())' in PI and 'bmp.recycle()' in PI)
check('hook vào luồng sinh ảnh (runGeneration): panels = prepareInteractionLayouts(...) TRƯỚC vòng lặp panel', re.search(r'val panels = (planContinuityFill\()?prepareInteractionLayouts\(chapter\.panels, story, chapter\.chapterNumber, settings\)', MP) is not None and MP.index('prepareInteractionLayouts(chapter.panels') < MP.index('panels.forEach { panel ->', MP.index('prepareInteractionLayouts(chapter.panels')))  # mục 261: có thể bọc planContinuityFill (bố cục tương tác chạy TRƯỚC, rồi điền bối cảnh)
check('giao thức app ↔ server cho "interact": khoá interaction.{subject_phrase,object_phrase,action_phrase,subject_box,object_box}, prompt, width, height, seed khớp server',
      all(('put("%s"' % k) in PI for k in ('subject_phrase', 'object_phrase', 'action_phrase', 'subject_box', 'object_box')) and all(('it.get("%s"' % k) in SV or ('"%s"' % k) in SV for k in ('subject_phrase', 'object_phrase', 'action_phrase', 'subject_box', 'object_box'))
      and '"interact": _run_interact_sync' in SV and 'payload.get("width"' in SV and 'payload.get("seed"' in SV)
check('client: ảnh đầu vào TUỲ CHỌN (null cho interact) và chỉ gửi image_b64 khi có', 'imagePng: ByteArray?' in RC and 'if (imagePng != null) put("image_b64"' in RC)
check('Models: Scene.layoutSkeleton (List<Float>? = null) và cờ remoteInteractLayout mặc định TẮT', 'val layoutSkeleton: List<Float>? = null' in ML and 'val remoteInteractLayout: Boolean = false' in ML)
check('Cài đặt: công tắc + cảnh báo trust_remote_code/--interact-revision, giấy phép BSD, giới hạn YOLO', 'copy(remoteInteractLayout = it)' in ST and 'trust_remote_code' in ST and '--interact-revision' in ST and 'BSD' in ST and 'YOLO' in ST)
check('Gson: Scene có đủ giá trị mặc định nên bản lưu cũ (không có layoutSkeleton) đọc ra null', 'val layoutSkeleton: List<Float>? = null' in ML)

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
