"""
export_ipa_controlnet_depth_unet.py — BẢN MỞ RỘNG của
export_ipa_controlnet_unet.py: xuất UNet SD1.5 đã gộp sẵn IP-Adapter +
ControlNet-OpenPose + ControlNet-Depth (giải quyết "ai trước ai sau" khi
nhân vật đan vào nhau — mục 6.4/51 TECHNICAL_STATUS.md).

CHẠY TRÊN MÁY TÍNH (không phải điện thoại), cần Python + GPU khuyến khích.

KHÁC BIỆT DUY NHẤT so với bản gốc (export_ipa_controlnet_unet.py): thêm 1
ControlNetModel thứ 2 (depth), gộp residual của CẢ 2 ControlNet bằng đúng
cách StableDiffusionControlNetPipeline làm khi nhận list nhiều ControlNet
(MultiControlNetModel — xác nhận qua source diffusers: cộng dồn từng phần
tử down_block_res_samples + mid_block_res_sample của mỗi ControlNet trước
khi đưa vào UNet). KHÔNG tự nghĩ ra cách gộp mới — dùng đúng phép cộng mà
diffusers.pipelines.controlnet.multicontrolnet.MultiControlNetModel.forward()
làm, chỉ viết tay lại vì cần TRACE ONNX qua 1 module duy nhất (không tự
động trace được qua object Python thường của MultiControlNetModel theo
cách gọi pipeline thông thường).

Ảnh depth_hint gửi vào KHÔNG cần model ước lượng độ sâu riêng (MiDaS/Depth-
Anything) — phía app (ip_adapter.cpp, hàm renderDepthHint()) tự vẽ depth
THÔ từ toạ độ z sẵn có của khung xương (đã có cho ControlNet-Pose), không
phát sinh thêm model .mnn nào phải tải/chạy trên điện thoại. Ảnh depth_hint
mẫu dùng để export (random) chỉ để TRACE đúng shape — giá trị thật lúc
chạy do app tự vẽ và gửi vào.

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_depth_unet.py \\
        --base_model runwayml/stable-diffusion-v1-5 \\
        --output_dir ./exported_depth \\
        --image_size 512

Sau khi có .onnx, convert + đặt tên .mnn giống hệt hướng dẫn cuối script
export_ipa_controlnet_unet.py — QUAN TRỌNG: đặt tên file kết quả LÀ
"unet_ipa_controlnet.mnn" (giống hệt tên bản KHÔNG depth, KHÔNG có cơ chế
"pipeline mode" nào khác trong model_manifest.json để chọn — đã kiểm tra
lại code app trước khi viết dòng này). loadSDAugmented() phía app luôn tìm
đúng tên file cố định đó; ip_adapter.cpp (onBeforeUnetRun) tự phát hiện
input "depth_hint" có tồn tại trong file .mnn đó hay không và tự xử lý phù
hợp — bản này THAY THẾ (ghi đè) bản không-depth cho model đó, không chạy
song song 2 bản.
"""
import argparse
import os

import torch
import torch.nn as nn
from diffusers import ControlNetModel, StableDiffusionControlNetPipeline

# Tái dùng lại các hàm/class chưa đổi từ bản gốc — KHÔNG copy-paste trùng
# lặp logic đã có (probe shape, export image encoder), tránh 2 bản dễ lệch
# nhau khi 1 bên sửa mà quên sửa bên kia.
from export_ipa_controlnet_unet import probe_ip_adapter_embed_shape, export_image_encoder
from ip_adapter_decay import IpDecayState, wrap_unet_ip_adapter_processors


class AugmentedUNetDepth(nn.Module):
    """Giống AugmentedUNet (bản gốc) nhưng nhận THÊM 1 ControlNet (depth) —
    gộp residual của CẢ 2 ControlNet bằng phép CỘNG, đúng cách
    MultiControlNetModel.forward() làm trong diffusers thật (đã xác nhận
    qua source, không tự chế cách gộp mới)."""

    def __init__(self, unet, controlnet_pose, controlnet_depth, decay_state: IpDecayState):
        super().__init__()
        self.unet = unet
        self.controlnet_pose = controlnet_pose
        self.controlnet_depth = controlnet_depth
        # Xem ip_adapter_decay.py — đọc bởi attn processor đã bọc bên trong
        # self.unet, không đăng ký làm submodule (cố tình).
        self._decay_state = decay_state

    def forward(self, sample, timestep, encoder_hidden_states, control_hint, depth_hint, ip_image_embeds,
                pose_scale, depth_scale, depth_active_min_timestep, depth_ramp_width,
                ip_decay_floor, ip_decay_start_timestep, ip_static_scale):
        down1, mid1 = self.controlnet_pose(
            sample, timestep, encoder_hidden_states=encoder_hidden_states,
            controlnet_cond=control_hint, return_dict=False,
        )
        down2, mid2 = self.controlnet_depth(
            sample, timestep, encoder_hidden_states=encoder_hidden_states,
            controlnet_cond=depth_hint, return_dict=False,
        )
        # mục 81 TECHNICAL_STATUS.md — thay vì cộng đều 1:1 (gây "loãng" tín
        # hiệu khi 2 ControlNet giằng co nhau — đúng lo ngại nêu trong
        # bổ_sung_sd1_5.txt), dùng ĐÚNG 2 tham số diffusers thật đã xác nhận
        # qua tài liệu chính thức (StableDiffusionControlNetPipeline):
        #   - controlnet_conditioning_scale (per-controlnet, List[float])
        #   - control_guidance_start/end (per-controlnet, cửa sổ timestep)
        # Vì đây là ONNX graph TĨNH (không gọi lại pipeline Python mỗi bước
        # như runtime thật), 2 tham số trên được đưa vào làm SCALAR INPUT
        # runtime — app truyền giá trị khác nhau MỖI LẦN GỌI mà KHÔNG cần
        # export lại đồ thị. torch.where dùng được an toàn trong ONNX trace
        # (không phải Python if/else thay đổi cấu trúc đồ thị — chỉ là 1 op
        # Where tĩnh, MNNConvert hỗ trợ tốt op này, đã dùng ở nơi khác trong
        # dự án).
        #
        # Quy ước timestep: DDPM sampler chạy timestep từ CAO (~999, ảnh
        # còn nhiễu nhiều — early step) XUỐNG THẤP (~0, gần ảnh cuối — late
        # step). "control_guidance_end=0.7" (dừng ở 70% số step) tương
        # đương "chỉ còn tác dụng khi timestep >= (1-0.7)*999 ≈ 300" — XẤP
        # XỈ TUYẾN TÍNH, KHÔNG chính xác 100% với lịch trình scheduler thật
        # (linear/cosine khác nhau map timestep<->step% khác nhau chút ít),
        # đủ dùng cho mục đích "Depth chỉ dẫn dắt bố cục sớm, nhường Pose
        # làm sạch chi tiết cuối" — không cần chính xác tuyệt đối.
        # mục 146 TECHNICAL_STATUS.md — SỬA cổng nhị phân cứng (torch.where
        # bật/tắt đột ngột tại đúng 1 timestep) thành SUY GIẢM TUYẾN TÍNH
        # MƯỢT trên 1 cửa sổ nhỏ quanh ngưỡng. Lý do sửa (đã kiểm chứng bằng
        # lập luận toán học, không phải suy đoán): residual ControlNet-Depth
        # cộng thẳng vào `down_block_additional_residuals`/`mid_block_
        # additional_residual` của UNet — nếu giá trị này NHẢY từ full-scale
        # xuống 0 chỉ trong đúng 1 bước denoise, latent tensor bị "bẻ hướng"
        # đột ngột sang 1 vùng không gian khác ở step đó so với step liền kề
        # (2 step cạnh nhau đáng lẽ phải gần nhau về mặt gradient) — ĐÚNG cơ
        # chế mà bất kỳ hệ thống điều khiển/tín hiệu số nào cũng tránh cổng
        # nhị phân cứng cho 1 đại lượng cộng dồn liên tục, không cần thực
        # nghiệm riêng để biết đây là rủi ro thật (khác các claim "vật lý
        # silicon" khác trong cùng nguồn đề xuất — KHÔNG áp dụng, xem mục
        # 146 archive để biết vì sao bị coi là không đáng tin).
        #
        # `depth_ramp_width` (mới, tham số runtime) = độ rộng cửa sổ suy
        # giảm tính bằng đơn vị timestep, tính XUÔI TỪ `depth_active_min_
        # timestep` XUỐNG THẤP hơn (nhớ quy ước: timestep chạy CAO→THẤP qua
        # quá trình denoise, xem comment quy ước ở trên) — vd
        # `depth_active_min_timestep=300`, `depth_ramp_width=100` nghĩa là:
        # còn full scale khi timestep>=300, giảm tuyến tính từ 300 xuống
        # 200, bằng 0 khi timestep<=200. `depth_ramp_width=0` (mặc định cũ)
        # tương đương cổng cứng nguyên bản — tương thích ngược 100% nếu app
        # chưa kịp truyền tham số mới (xử lý chia-cho-0 bằng clamp min).
        safe_ramp_width = torch.clamp(depth_ramp_width, min=1e-3)
        depth_gate = torch.clamp(
            (timestep.float() - (depth_active_min_timestep - safe_ramp_width)) / safe_ramp_width,
            min=torch.zeros_like(depth_scale), max=torch.ones_like(depth_scale)
        )
        effective_depth_scale = depth_scale * depth_gate

        down_res = [d1 * pose_scale + d2 * effective_depth_scale for d1, d2 in zip(down1, down2)]
        mid_res = mid1 * pose_scale + mid2 * effective_depth_scale

        # Smooth Timestep Decay cho IP-Adapter — bản THẬT, scale OUTPUT của
        # attention (đúng ý nghĩa set_ip_adapter_scale()) qua attn processor
        # đã bọc trong self.unet (xem wrap_unet_ip_adapter_processors() ở
        # main() + tools/ip_adapter_decay.py cho cơ chế đầy đủ + GIỚI HẠN
        # THẬT). Công thức Y HỆT export_ipa_controlnet_unet.py — suy giảm
        # TUYẾN TÍNH MƯỢT (khác cổng cứng depth_gate ở trên), NHÂN THÊM
        # ip_static_scale (đóng gap "consistencyStrength chết" — mục 9,
        # xem chú thích đầy đủ trong export_ipa_controlnet_unet.py).
        safe_start = torch.clamp(ip_decay_start_timestep, min=1e-3)
        ramp = torch.clamp(timestep.float(), min=torch.zeros_like(safe_start), max=safe_start) / safe_start
        effective_ip_scale = ip_static_scale * (ip_decay_floor + (1.0 - ip_decay_floor) * ramp)
        self._decay_state.value = effective_ip_scale

        noise_pred = self.unet(
            sample, timestep, encoder_hidden_states=encoder_hidden_states,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            added_cond_kwargs={"image_embeds": [ip_image_embeds]},
            return_dict=False,
        )[0]
        return noise_pred


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="runwayml/stable-diffusion-v1-5")
    ap.add_argument("--controlnet_model", default="lllyasviel/control_v11p_sd15_openpose")
    # ControlNet-Depth chính chủ, cùng họ v1.1 với bản pose đã dùng (cùng
    # tác giả lllyasviel, cùng chuẩn train trên SD1.5) — xác nhận tồn tại
    # thật trên HuggingFace, không đoán tên repo.
    ap.add_argument("--depth_controlnet_model", default="lllyasviel/control_v11f1p_sd15_depth")
    ap.add_argument("--ip_adapter_repo", default="h94/IP-Adapter")
    ap.add_argument("--ip_adapter_weight", default="ip-adapter_sd15.bin")
    ap.add_argument("--output_dir", default="./exported_depth")
    ap.add_argument("--image_size", type=int, default=512)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_size = args.image_size // 8

    print("Đang tải ControlNet-OpenPose...")
    controlnet_pose = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)
    print("Đang tải ControlNet-Depth...")
    controlnet_depth = ControlNetModel.from_pretrained(args.depth_controlnet_model, torch_dtype=torch.float32)

    print("Đang tải base SD1.5 (dùng ControlNet pose làm chỗ gắn tạm cho pipeline — depth gộp thủ công bên dưới)...")
    pipe = StableDiffusionControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet_pose, torch_dtype=torch.float32, safety_checker=None
    )

    print(f"Đang nạp IP-Adapter ({args.ip_adapter_repo}/{args.ip_adapter_weight})...")
    pipe.load_ip_adapter(args.ip_adapter_repo, subfolder="models", weight_name=args.ip_adapter_weight)
    pipe.set_ip_adapter_scale(1.0)
    pipe.to(device)
    controlnet_pose.to(device)
    controlnet_depth.to(device)

    # Bọc attention processor thật để Smooth Timestep Decay tác động đúng
    # vào output attention — xem tools/ip_adapter_decay.py + GIỚI HẠN THẬT.
    decay_state = IpDecayState()
    n_wrapped = wrap_unet_ip_adapter_processors(pipe.unet, decay_state)
    if n_wrapped == 0:
        raise RuntimeError(
            "wrap_unet_ip_adapter_processors() không bọc được processor nào — "
            "xem cùng lỗi này trong export_ipa_controlnet_unet.py cho cách xử lý."
        )
    print(f"Đã bọc {n_wrapped} attention processor với Smooth Timestep Decay (IP-Adapter).")

    example_embeds = probe_ip_adapter_embed_shape(pipe, device)
    export_image_encoder(pipe, args.output_dir, device)

    print("Đang lắp AugmentedUNetDepth (UNet + ControlNet-Pose + ControlNet-Depth gộp)...")
    augmented = AugmentedUNetDepth(pipe.unet, controlnet_pose, controlnet_depth, decay_state).to(device).eval()

    example_sample = torch.randn(1, 4, latent_size, latent_size, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_encoder_hidden = torch.randn(1, 77, 768, device=device)
    example_control_hint = torch.randn(1, 3, args.image_size, args.image_size, device=device)
    example_depth_hint = torch.randn(1, 3, args.image_size, args.image_size, device=device)
    # mục 81 — 3 scalar mới, giá trị mẫu chỉ để TRACE đúng shape/dtype;
    # giá trị THẬT do app truyền mỗi lần gọi (xem GenerationSettings.
    # poseConditioningScale/depthConditioningScale/depthActiveMinTimestep).
    example_pose_scale = torch.tensor(1.0, device=device, dtype=torch.float32)
    example_depth_scale = torch.tensor(0.6, device=device, dtype=torch.float32)
    example_depth_min_timestep = torch.tensor(300.0, device=device, dtype=torch.float32)
    # mục 146 TECHNICAL_STATUS.md — độ rộng cửa sổ suy giảm mượt (đơn vị
    # timestep), thay cổng cứng cũ — mẫu = 100 (suy giảm tuyến tính trên
    # khoảng [200, 300] thay vì nhảy đột ngột tại đúng timestep 300). Giá
    # trị 0 tương đương hành vi cổng cứng cũ (tương thích ngược, xem clamp
    # trong forward()).
    example_depth_ramp_width = torch.tensor(100.0, device=device, dtype=torch.float32)
    # 2 scalar mới (Smooth Timestep Decay IP-Adapter) — mẫu = "không suy
    # giảm gì" (ip_decay_floor=1.0), giá trị THẬT do app truyền lúc chạy.
    example_ip_decay_floor = torch.tensor(1.0, device=device, dtype=torch.float32)
    example_ip_decay_start_timestep = torch.tensor(999.0, device=device, dtype=torch.float32)
    # ip_static_scale — đóng gap "consistencyStrength chết" (mục 9).
    example_ip_static_scale = torch.tensor(1.0, device=device, dtype=torch.float32)

    onnx_path = os.path.join(args.output_dir, "unet_ipa_controlnet_depth.onnx")
    print(f"Đang export ONNX -> {onnx_path} (có thể mất vài phút, model lớn hơn bản không depth)...")
    with torch.no_grad():
        torch.onnx.export(

            augmented,
            (example_sample, example_timestep, example_encoder_hidden,
             example_control_hint, example_depth_hint, example_embeds,
             example_pose_scale, example_depth_scale, example_depth_min_timestep, example_depth_ramp_width,
             example_ip_decay_floor, example_ip_decay_start_timestep, example_ip_static_scale),
            onnx_path,
            input_names=["sample", "timestep", "encoder_hidden_states",
                         "control_hint", "depth_hint", "ip_image_embeds",
                         "pose_scale", "depth_scale", "depth_active_min_timestep", "depth_ramp_width",
                         "ip_decay_floor", "ip_decay_start_timestep", "ip_static_scale"],
            output_names=["out_sample"],
            opset_version=17,
            do_constant_folding=True,
        
            dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
            # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
            # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
            # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
            # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
            # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
            # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
            # xác nhận hoạt động đúng bằng thực nghiệm.
        )

    print("\n=== XONG PHẦN ONNX ===")
    print(f"Shape ip_image_embeds thật đã dò được: {tuple(example_embeds.shape)}")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, 'unet_ipa_controlnet.mnn')} \\")
    print(f"      --bizCode biz")
    print(f"  MNNConvert -f ONNX --modelFile {os.path.join(args.output_dir, 'ip_image_encoder.onnx')} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, 'ip_image_encoder.mnn')} \\")
    print(f"      --bizCode biz")
    print("\nQUAN TRỌNG (đã kiểm tra lại code app, KHÔNG có 'pipeline mode' nào để")
    print("chọn trong model_manifest.json — loadSDAugmented() phía app LUÔN tìm")
    print("đúng tên file 'unet_ipa_controlnet.mnn' trong thư mục model, cố định):")
    print("  -> ĐẶT ĐÚNG TÊN FILE 'unet_ipa_controlnet.mnn' (giống hệt tên bản KHÔNG")
    print("     depth) khi copy vào thư mục model của nhân vật/model đó — ip_adapter.cpp")
    print("     (onBeforeUnetRun) tự phát hiện input 'depth_hint' có tồn tại trong")
    print("     đúng file .mnn đó hay không và tự xử lý phù hợp, KHÔNG cần cờ/chế độ")
    print("     nào khác phía app. Nói cách khác: model này THAY THẾ (ghi đè) bản")
    print("     unet_ipa_controlnet.mnn không-depth cho model đó, không chạy song song.")
    print(f"\nGhi lại số {example_embeds.shape[1]} (số token) và "
          f"{example_embeds.shape[2]} (chiều embedding) — cần khớp đúng trong "
          f"ip_adapter.cpp (hằng số IP_EMBED_TOKENS/IP_EMBED_DIM), y hệt bản gốc.")
    print("\nmục 81 TECHNICAL_STATUS.md — 3 input mới so với bản trước:")
    print("  'pose_scale' / 'depth_scale' / 'depth_active_min_timestep' — cho phép")
    print("  app CHỈNH tỉ trọng + cửa sổ timestep của từng ControlNet lúc CHẠY,")
    print("  không cần export lại. ip_adapter.cpp tự phát hiện 3 input này có tồn")
    print("  tại trong .mnn hay không (giống cách depth_hint đã tự phát hiện) —")
    print("  model .mnn CŨ (bản trước mục 81, không có 3 input này) vẫn tương")
    print("  thích ngược, app tự dùng hành vi cộng 1:1 cũ nếu thiếu.")
    print("\nmục 146 TECHNICAL_STATUS.md — thêm 1 input nữa: 'depth_ramp_width'")
    print("  (độ rộng cửa sổ suy giảm MƯỢT thay cổng nhị phân cứng — sửa 'sốc")
    print("  toán học' khi Depth tắt đột ngột). Model .mnn CŨ (không có input")
    print("  này) vẫn tương thích ngược — ip_adapter.cpp coi thiếu input này")
    print("  = ramp_width 0 = hành vi cổng cứng cũ, không crash.")
    print("\nBản này CÒN có thêm 2 input: 'ip_decay_floor' / 'ip_decay_start_timestep'")
    print("  (Smooth Timestep Decay cho IP-Adapter) — cùng nguyên tắc tương thích")
    print("  ngược (model cũ hơn không có 2 input này -> bỏ qua an toàn). Suy giảm")
    print("  ĐÚNG output attention (qua attn processor đã bọc — xem tools/")
    print("  ip_adapter_decay.py), không còn là xấp xỉ scale-input. GIỚI HẠN THẬT")
    print("  còn lại: phụ thuộc cấu trúc nội bộ diffusers (đã xác nhận 0.39.0) —")
    print("  nếu 0 processor bọc được, script đã dừng lỗi rõ ràng ở trên rồi.")


if __name__ == "__main__":
    main()
