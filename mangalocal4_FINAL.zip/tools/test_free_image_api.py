#!/usr/bin/env python3
"""mục 266 — kiểm thử `pipeline/FreeImageApi.kt` (lõi API ảnh MIỄN PHÍ: dựng yêu cầu, giải mã phản hồi, prompt) bằng kotlinc THẬT, đối chiếu với thư viện chuẩn Python
(base64, urllib.parse, json) và bản tham chiếu viết độc lập từ quy tắc.

Kiểm: (1) base64Decode == base64 của Python (chuẩn/URL-safe, thiếu '=', xen khoảng trắng, tiền tố data:) và từ chối ký tự lạ; (2) imageExt theo magic bytes (PNG/JPEG/WebP, ca suýt đúng);
(3) decode: PNG/JPEG thô (kể cả khi Content-Type sai), JSON Cloudflare {result:{image}}, {image}, OpenAI data[0].b64_json, data URL, lỗi {errors:[{code:3036}]} / {error:{message}},
base64 không phải ảnh, HTML, rỗng, JSON cụt; (4) buildRequest Cloudflare: URL/Authorization/thân JSON đúng từng họ model (flux-1-schnell / SDXL-Lightning / SDXL / model lạ), kích thước kẹp và chia hết 8,
seed không âm, từ chối Account ID/model có ký tự đường dẫn ('..', '/', khoảng trắng); Pollinations: URL có/không khoá, mã hoá phần trăm == urllib; (5) clampPrompt; (6) prompt nền KHÔNG NGƯỜI và prompt phác nhân vật.
Thử phá mã. KHÔNG chứng minh: endpoint thật chấp nhận đúng các tham số này (chưa gọi thử — sandbox không ra Internet; sai tên tham số sẽ báo 400 khi chạy thật), ảnh thật có đẹp/đúng ý.
Cần kotlinc (không có -> SKIP).
"""
import base64, json, os, random, shutil, subprocess, sys, tempfile, urllib.parse
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + str(d)[:500]) if (d and not c) else '')); ok &= bool(c)
def find():
    for c in [os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/work/kotlinc/bin/kotlinc', '/home/claude/tools_dl/kotlinc/bin/kotlinc']:
        if c and os.path.exists(c): return c
KOTLINC = find()
if not KOTLINC:
    print('SKIP: không có kotlinc'); sys.exit(0)
KLIB = os.path.join(os.path.dirname(os.path.dirname(KOTLINC)), 'lib', 'kotlin-stdlib.jar')

DRIVER = r'''
import com.mangalocal.pipeline.*
import java.io.File
fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
fun hs(s: String): String = hex(s.toByteArray(Charsets.UTF_8))
fun unhex(h: String): ByteArray = if (h == "-") ByteArray(0) else ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
fun us(h: String): String = String(unhex(h), Charsets.UTF_8)
fun creds(p: List<String>, o: Int) = FreeImageCreds(us(p[o]), us(p[o + 1]), us(p[o + 2]), us(p[o + 3]))
fun main(args: Array<String>) {
    val out = StringBuilder()
    for (line in File(args[0]).readLines()) {
        if (line.isEmpty()) continue
        val p = line.split("\t")
        when (p[0]) {
            "B64" -> out.append(try { "OK " + hex(FreeImageApi.base64Decode(us(p[1]))) } catch (e: IllegalArgumentException) { "ERR" }).append("\n")
            "EXT" -> out.append(FreeImageApi.imageExt(unhex(p[1])) ?: "null").append("\n")
            "DEC" -> {
                val d = FreeImageApi.decode(if (p[1] == "-") null else us(p[1]), unhex(p[2]))
                out.append(if (d.bytes != null) "IMG ${d.ext} ${hex(d.bytes)}" else "ERR ${hs(d.error ?: "")}").append("\n")
            }
            "REQ" -> {
                val prov = FreeImageProvider.valueOf(p[1])
                out.append(try {
                    val s = FreeImageApi.buildRequest(prov, us(p[2]), us(p[3]), p[4].toInt(), p[5].toInt(), p[6].toLong(), creds(p, 7))
                    "OK\t${s.method}\t${hs(s.url)}\t" + s.headers.joinToString(",") { hs(it.first) + ":" + hs(it.second) } + "\t" + (if (s.jsonBody == null) "-" else hs(s.jsonBody))
                } catch (e: IllegalArgumentException) { "ERR\t" + hs(e.message ?: "") }).append("\n")
            }
            "PROB" -> out.append(hs(FreeImageApi.problems(FreeImageProvider.valueOf(p[1]), creds(p, 2)).joinToString("|"))).append("\n")
            "CLAMP" -> out.append(hs(FreeImageApi.clampPrompt(us(p[2]), p[1].toInt()))).append("\n")
            "ENC" -> out.append(FreeImageApi.urlEncode(us(p[1]))).append("\n")
            "SEED" -> out.append(FreeImageApi.seedInt(p[1].toLong())).append("\n")
            "ENCB" -> out.append(FreeImageApi.base64Encode(unhex(p[1]))).append("\n")
            "SRC" -> out.append(ImageSource.valueOf(p[1]).freeProvider()?.name ?: "null").append("\n")
            "MINI" -> out.append(FreeImageApi.minIntervalMs(FreeImageProvider.valueOf(p[1]), FreeImageCreds("", "", "x", us(p[2])))).append("\n")
            "LOC" -> out.append(hs(FreeImageApi.locationPrompt(us(p[1]), if (p[2] == "NULL") null else us(p[2]), us(p[3]), us(p[4])))).append("\n")
            "CHR" -> out.append(hs(FreeImageApi.characterSketchPrompt(us(p[1]), us(p[2]), if (p[3] == "NULL") null else us(p[3])))).append("\n")
        }
    }
    File(args[1]).writeText(out.toString())
}
'''
def hx(b):
    if isinstance(b, str): b = b.encode('utf-8')
    return b.hex() if b else '-'
def unhx(h):
    if h == '-': return b''
    try: return bytes.fromhex(h)
    except Exception: return None
def ustr(h):
    b = unhx(h)
    try: return b.decode('utf-8') if b is not None else None
    except Exception: return None

# ---------- dữ liệu thử ----------
PNG = b'\x89PNG\r\n\x1a\n' + b'\x00\x00\x00\rIHDR' + os.urandom(20)
JPG = b'\xff\xd8\xff\xe0\x00\x10JFIF' + os.urandom(30)
WEBP = b'RIFF\x24\x00\x00\x00WEBPVP8 ' + os.urandom(20)
WAV = b'RIFF\x24\x00\x00\x00WAVEfmt ' + os.urandom(20)
rng = random.Random(266)
ACCT = 'a1b2c3d4e5f60718293a4b5c6d7e8f90'
TOK = 'tok_ABC-123'
MODELS = {'flux': '@cf/black-forest-labs/flux-1-schnell', 'light': '@cf/bytedance/stable-diffusion-xl-lightning',
          'sdxl': '@cf/stabilityai/stable-diffusion-xl-base-1.0', 'other': '@cf/meta/some-new-model'}
def b64(b, url=False): return (base64.urlsafe_b64encode(b) if url else base64.b64encode(b)).decode()

def ref_clamp(p, mx):
    t = ' '.join(p.split())
    if len(t) <= mx: return t
    cut = t[:mx]
    bnd = max(cut.rfind(' '), cut.rfind(','))
    if bnd > mx * 2 // 3: cut = cut[:bnd]
    return cut.rstrip(', ')
def ref_size(v): return (min(max(v, 256), 2048) // 8) * 8

B64_CASES = []   # (chuỗi vào, bytes mong đợi hoặc None = phải lỗi)
for n in list(range(0, 40)) + [100, 257, 1000]:
    raw = os.urandom(n)
    s = b64(raw)
    B64_CASES.append((s, raw)); B64_CASES.append((s.rstrip('='), raw)); B64_CASES.append((b64(raw, True), raw))
    B64_CASES.append((s[:7] + '\n ' + s[7:] + '\r\n', raw))
    B64_CASES.append(('data:image/png;base64,' + s, raw))
B64_CASES += [('ab!cd', None), ('é', None), ('a$b=', None)]

EXT_CASES = [(PNG, 'png'), (JPG, 'jpg'), (WEBP, 'webp'), (WAV, 'null'), (b'', 'null'), (b'\x89PNG', 'null'), (b'\xff\xd8', 'null'), (b'<html>', 'null'), (b'RIFF', 'null')]

def dec_cases():
    C = []   # (content-type, body, kind, extra)
    C.append(('text/html', PNG, 'IMG', ('png', PNG)))
    C.append(('image/jpeg', JPG, 'IMG', ('jpg', JPG)))
    C.append((None, WEBP, 'IMG', ('webp', WEBP)))
    for key, raw, ext in (('result.image', JPG, 'jpg'), ('image', PNG, 'png'), ('result.image_b64', PNG, 'png'), ('data0', JPG, 'jpg')):
        if key == 'result.image': j = {'result': {'image': b64(raw)}, 'success': True, 'errors': [], 'messages': []}
        elif key == 'image': j = {'image': b64(raw)}
        elif key == 'result.image_b64': j = {'result': {'image_b64': b64(raw)}}
        else: j = {'data': [{'b64_json': b64(raw)}]}
        C.append(('application/json', json.dumps(j).encode(), 'IMG', (ext, raw)))
    C.append(('application/json', json.dumps({'result': {'image': 'data:image/png;base64,' + b64(PNG)}}).encode(), 'IMG', ('png', PNG)))
    C.append(('application/json', json.dumps({'result': {'image': b64(PNG, True).rstrip('=')}}).encode(), 'IMG', ('png', PNG)))
    C.append(('application/json', json.dumps({'result': {}, 'success': False, 'errors': [{'code': 3036, 'message': 'You have used up your daily free allocation of 10,000 neurons'}]}).encode(), 'ERR', ['3036', 'daily free allocation']))
    C.append(('application/json', json.dumps({'errors': [{'message': 'AiError: bad input'}]}).encode(), 'ERR', ['AiError: bad input']))
    C.append(('application/json', json.dumps({'error': {'message': 'model not found'}}).encode(), 'ERR', ['model not found']))
    C.append(('application/json', json.dumps({'result': {'image': b64(b'not an image at all')}}).encode(), 'ERR', ['không phải ảnh']))
    C.append(('application/json', json.dumps({'result': {'foo': 1}}).encode(), 'ERR', ['không chứa ảnh']))
    C.append(('text/html', b'<html><body>502 Bad Gateway</body></html>', 'ERR', ['text/html', '502 Bad Gateway']))
    C.append((None, b'', 'ERR', ['?', '0 byte']))
    C.append(('application/json', b'{"result": {"image": "AAAA', 'ERR', ['không đọc được']))
    C.append(('application/json', b'[1,2]', 'ERR', ['không chứa ảnh']))
    return C
DEC = dec_cases()

def req_cases():
    C = []
    def add(prov, prompt, neg, w, h, seed, acct, tok, model, key):
        C.append((prov, prompt, neg, w, h, seed, acct, tok, model, key))
    long_prompt = ('một khu chợ nổi trên sông lúc bình minh, ' * 80)
    for mk, model in MODELS.items():
        add('CLOUDFLARE', 'A quiet harbour at dawn, "mist" & \\ slash\nnewline', 'people, text', 1024, 768, 12345, ACCT, TOK, model, '')
        add('CLOUDFLARE', 'nền', '', 100, 5000, 2**40 + 7, '  ' + ACCT + ' ', ' ' + TOK + ' ', ' ' + model + ' ', '')
        add('CLOUDFLARE', long_prompt, long_prompt, 777, 513, 0, ACCT, TOK, model, '')
    for bad_acct in ('', '  ', 'abc', 'a/b/c/d/e/f/g', '../../etc/x12345', 'acct with space 123456', ACCT + '?x=1', 'é' * 12):
        add('CLOUDFLARE', 'x', '', 512, 512, 1, bad_acct, TOK, MODELS['flux'], '')
    for bad_model in ('', 'flux', '@cf/only-one', '@cf/a/b/c', '@cf/../x/y', '@xx/a/b', '@cf/a b/c', '@cf/a/b?x=1', '@cf//b'):
        add('CLOUDFLARE', 'x', '', 512, 512, 1, ACCT, TOK, bad_model, '')
    add('CLOUDFLARE', 'x', '', 512, 512, 1, ACCT, '', MODELS['flux'], '')
    add('CLOUDFLARE', 'x', '', 512, 512, 1, ACCT, '   ', MODELS['flux'], '')
    for key in ('', 'sk_secret value/1?&'):
        add('POLLINATIONS', 'Chợ nổi trên sông, bình minh — sương mù', 'ignored', 1000, 600, 99, '', '', MODELS['flux'], key)
        add('POLLINATIONS', long_prompt, '', 2000, 2000, 5, '', '', MODELS['flux'], key)
        add('POLLINATIONS', '  ', '', 512, 512, 5, '', '', MODELS['flux'], key)
    return C
REQ = req_cases()

PROB_CASES = [('CLOUDFLARE', '', '', MODELS['flux'], 2), ('CLOUDFLARE', ACCT, '', MODELS['flux'], 1), ('CLOUDFLARE', ACCT, TOK, MODELS['flux'], 0), ('CLOUDFLARE', ACCT, TOK, 'bad', 1),
              ('CLOUDFLARE', 'x/y', TOK, MODELS['flux'], 1), ('POLLINATIONS', '', '', 'bad', 0)]
CLAMP_CASES = []
for _ in range(300):
    words = ' '.join(rng.choice(['alpha', 'béta', 'gamma,', 'delta', 'ệ', 'x']) + rng.choice(['', ',', ' ', '  ', '\n']) for _ in range(rng.randint(0, 120)))
    CLAMP_CASES.append((rng.choice([10, 50, 200, 600, 1800]), words))
ENC_CASES = [''.join(rng.choice('aZ09 -_.~!*\'();:@&=+$,/?#[]%é日🙂"<>\\') for _ in range(rng.randint(0, 20))) for _ in range(300)]
SEEDS = [0, 1, 2**31 - 1, 2**31, 2**32 + 5, 2**62, 123456789012, -1, -2**40]
ENCB_CASES = [os.urandom(n) for n in list(range(0, 40)) + [100, 255, 256, 257, 3000]]
SRC_CASES = [('CONFIGURED', 'null'), ('CLOUDFLARE', 'CLOUDFLARE'), ('POLLINATIONS', 'POLLINATIONS')]
MINI_CASES = [('POLLINATIONS', '', 15000), ('POLLINATIONS', '   ', 15000), ('POLLINATIONS', 'sk_x', 0), ('CLOUDFLARE', '', 0), ('CLOUDFLARE', 'k', 0)]
LOC_CASES = [('Chợ nổi Cái Răng', 'chụp ngang, cầu bên trái', 'anime style', 'thế giới thời Nguyễn'), ('Hành lang', None, '', ''), ('Mái nhà', '   ', ' ink ', ' ' + 'r' * 400)]
CHR_CASES = [('cô gái tóc bạc, mắt đỏ', 'manga style', None), ('thiếu niên', '', 'có sẹo trên má trái'), ('  lão già  ', ' ink ', '  ')]

def lines_for():
    L = []
    for s, _ in B64_CASES: L.append('B64\t' + hx(s))
    for b, _ in EXT_CASES: L.append('EXT\t' + hx(b))
    for ct, body, _, _ in DEC: L.append('DEC\t' + (hx(ct) if ct else '-') + '\t' + hx(body))
    for c in REQ: L.append('\t'.join(['REQ', c[0], hx(c[1]), hx(c[2]), str(c[3]), str(c[4]), str(c[5]), hx(c[6]), hx(c[7]), hx(c[8]), hx(c[9])]))
    for p in PROB_CASES: L.append('\t'.join(['PROB', p[0], hx(p[1]), hx(p[2]), hx(p[3]), '-']))
    for mx, t in CLAMP_CASES: L.append(f'CLAMP\t{mx}\t' + hx(t))
    for s in ENC_CASES: L.append('ENC\t' + hx(s))
    for s in SEEDS: L.append(f'SEED\t{s}')
    for b in ENCB_CASES: L.append('ENCB\t' + hx(b))
    for s, _ in SRC_CASES: L.append('SRC\t' + s)
    for pv, k_, _ in MINI_CASES: L.append('\t'.join(['MINI', pv, hx(k_)]))
    for n, f, st, w in LOC_CASES: L.append('\t'.join(['LOC', hx(n), 'NULL' if f is None else hx(f), hx(st), hx(w)]))
    for a, st, ch in CHR_CASES: L.append('\t'.join(['CHR', hx(a), hx(st), 'NULL' if ch is None else hx(ch)]))
    return L

def verify(res):
    errs = []; i = 0
    for s, want in B64_CASES:
        got = res[i]; i += 1
        if want is None:
            if got != 'ERR': errs.append(('b64-reject', s[:20], got[:20]))
        elif got != 'OK ' + want.hex(): errs.append(('b64', s[:30], got[:40]))
    for b, want in EXT_CASES:
        got = res[i]; i += 1
        if got != want: errs.append(('ext', b[:8], want, got))
    for ct, body, kind, extra in DEC:
        got = res[i]; i += 1
        if kind == 'IMG':
            if got != f'IMG {extra[0]} {extra[1].hex()}': errs.append(('dec-img', body[:30], got[:50]))
        else:
            msg = ustr(got[4:]) if got.startswith('ERR ') else None
            if msg is None or not all(k in msg for k in extra): errs.append(('dec-err', body[:40], got[:60], msg))
    for c in REQ:
        got = res[i].split('\t'); i += 1
        prov, prompt, neg, w, h, seed, acct, tok, model, key = c
        acct_t, tok_t, model_t = acct.strip(), tok.strip(), model.strip()
        valid = True
        if prov == 'CLOUDFLARE':
            import re
            valid = bool(re.fullmatch(r'[A-Za-z0-9]{8,64}', acct_t)) and bool(tok_t) and bool(re.fullmatch(r'@(cf|hf)/[A-Za-z0-9._-]+/[A-Za-z0-9._-]+', model_t))
        else:
            valid = bool(ref_clamp(prompt, 600))
        if not valid:
            if got[0] != 'ERR': errs.append(('req-should-reject', c[:3] + c[6:9], got[0]))
            continue
        if got[0] != 'OK': errs.append(('req-rejected', c[:3] + c[6:9], got[0], ustr(got[1]) if len(got) > 1 else '')); continue
        method, url, headers, body = got[1], ustr(got[2]), got[3], got[4]
        hd = {ustr(kv.split(':')[0]): ustr(kv.split(':')[1]) for kv in headers.split(',')}
        W, H = ref_size(w), ref_size(h)
        if prov == 'CLOUDFLARE':
            if method != 'POST' or url != f'https://api.cloudflare.com/client/v4/accounts/{acct_t}/ai/run/{model_t}': errs.append(('cf-url', url))
            if hd.get('Authorization') != f'Bearer {tok_t}' or hd.get('Content-Type') != 'application/json': errs.append(('cf-headers', hd))
            b = json.loads(ustr(body))
            p = ref_clamp(prompt, 1800); n = ref_clamp(neg, 1800); s31 = seed & 0x7FFFFFFF
            if 'flux-1-schnell' in model_t: want = {'prompt': p, 'steps': 4, 'seed': s31}
            elif 'lightning' in model_t:
                want = {'prompt': p}; 
                if n: want['negative_prompt'] = n
                want.update({'width': W, 'height': H, 'num_steps': 4, 'guidance': 2, 'seed': s31})
            elif 'stable-diffusion-xl' in model_t:
                want = {'prompt': p}
                if n: want['negative_prompt'] = n
                want.update({'width': W, 'height': H, 'num_steps': 20, 'guidance': 7.5, 'seed': s31})
            else: want = {'prompt': p}
            if b != want: errs.append(('cf-body', model_t, str(b)[:120], str(want)[:120]))
        else:
            if method != 'GET' or body != '-': errs.append(('pol-method', method, body[:10]))
            u = urllib.parse.urlsplit(url)
            kt = key.strip()
            host_ok = (u.netloc == 'image.pollinations.ai' and u.path.startswith('/prompt/')) if not kt else (u.netloc == 'gen.pollinations.ai' and u.path.startswith('/image/'))
            if not host_ok: errs.append(('pol-host', url[:80]))
            seg = urllib.parse.unquote(u.path.split('/', 2)[2])
            if seg != ref_clamp(prompt, 600): errs.append(('pol-prompt', seg[:50]))
            q = dict(urllib.parse.parse_qsl(u.query, keep_blank_values=True))
            wantq = {'model': 'flux', 'width': str(W), 'height': str(H), 'seed': str(seed & 0x7FFFFFFF), 'nologo': 'true'}   # mục 268: khoá KHÔNG nằm trong URL
            if q != wantq: errs.append(('pol-query', q, wantq))
            if 'key=' in url.lower(): errs.append(('pol-key-in-url', url[:80]))
            want_auth = f'Bearer {kt}' if kt else None
            if hd.get('Authorization') != want_auth: errs.append(('pol-auth', hd.get('Authorization'), want_auth))
    for pv, acct, tok, model, n_prob in PROB_CASES:
        got = ustr(res[i]); i += 1
        n = 0 if got == '' else len(got.split('|'))
        if n != n_prob: errs.append(('problems', pv, acct, tok, model, n, n_prob))
    for mx, t in CLAMP_CASES:
        got = ustr(res[i]); i += 1
        if got != ref_clamp(t, mx): errs.append(('clamp', mx, t[:30], (got or '')[:30]))
    for s in ENC_CASES:
        got = res[i]; i += 1
        if got != urllib.parse.quote(s, safe=''): errs.append(('enc', s, got))
    for s in SEEDS:
        got = res[i]; i += 1
        if got != str(s & 0x7FFFFFFF): errs.append(('seed', s, got))
    for b in ENCB_CASES:
        got = res[i]; i += 1
        if got != base64.b64encode(b).decode(): errs.append(('b64encode', len(b), got[:30]))
    for s, want in SRC_CASES:
        got = res[i]; i += 1
        if got != want: errs.append(('imagesource', s, got))
    for pv, k_, want in MINI_CASES:
        got = res[i]; i += 1
        if got != str(want): errs.append(('min-interval', pv, k_, got))
    for n, f, st, w in LOC_CASES:
        got = ustr(res[i]); i += 1
        low = (got or '').lower()
        if not (n.strip() in got and 'no people' in low and 'no characters' in low): errs.append(('loc-core', n, (got or '')[:80]))
        if f and f.strip() and ('camera and composition: ' + f.strip()) not in got: errs.append(('loc-framing', n))
        if (not f or not f.strip()) and 'camera and composition' in got: errs.append(('loc-framing-extra', n))
        if st.strip() and st.strip() not in got: errs.append(('loc-style', n))
        if w.strip() and ('setting: ' + w.strip()[:300]) not in got: errs.append(('loc-rules', n))
    for a, st, ch in CHR_CASES:
        got = ustr(res[i]); i += 1
        if not (a.strip() in got and 'one person only' in got): errs.append(('chr-core', a))
        if ch and ch.strip() and ('with this change: ' + ch.strip()) not in got: errs.append(('chr-change', a))
        if (not ch or not ch.strip()) and 'with this change' in got: errs.append(('chr-change-extra', a))
        if st.strip() and st.strip() not in got: errs.append(('chr-style', a))
    return errs

tmp = tempfile.mkdtemp()
def compile_(files, tag):
    d = os.path.join(tmp, tag); os.makedirs(d, exist_ok=True)
    open(os.path.join(d, 'Drv.kt'), 'w').write(DRIVER)
    jar = os.path.join(tmp, tag + '.jar')
    r = subprocess.run([KOTLINC] + files + [os.path.join(d, 'Drv.kt'), '-d', jar], capture_output=True, text=True)
    return jar, r
def run(jar, lines):
    fi = os.path.join(tmp, 'in.txt'); fo = os.path.join(tmp, 'out.txt')
    open(fi, 'w').write('\n'.join(lines) + '\n')
    r = subprocess.run(['java', '-cp', f'{jar}:{KLIB}', 'DrvKt', fi, fo], capture_output=True, text=True)
    if r.returncode != 0: return None, r.stderr[-500:]
    return open(fo, encoding='utf-8').read().split('\n')[:len(lines)], ''

FILES = ['MiniJson.kt', 'FreeImageApi.kt']
jar, r = compile_([os.path.join(KT, f) for f in FILES], 'orig')
check('FreeImageApi.kt + MiniJson.kt biên dịch bằng kotlinc thật', r.returncode == 0, r.stderr[-800:])
if r.returncode != 0:
    print('CÓ LỖI'); sys.exit(1)
L = lines_for()
res, err = run(jar, L)
check('chạy driver', res is not None, err)
errs = verify(res) if res else [('run', err)]
check(f'khớp tham chiếu độc lập: {len(B64_CASES)} base64, {len(EXT_CASES)} magic bytes, {len(DEC)} phản hồi, {len(REQ)} yêu cầu, {len(CLAMP_CASES)} clamp, {len(ENC_CASES)} mã hoá URL, prompt nền/nhân vật', not errs, errs[:3])
n_rej = sum(1 for c in REQ if c[0] == 'CLOUDFLARE' and not (len(c[6].strip()) >= 8 and c[6].strip().isalnum() and c[6].strip().isascii() and c[7].strip() and c[8].strip().startswith('@cf/') and c[8].strip().count('/') == 2 and ' ' not in c[8].strip()))
check(f'có ca bị từ chối vì thông tin xấu ({n_rej}) — chốt chống chèn đường dẫn/URL là có thật', n_rej >= 10, n_rej)

# ---------- thử phá mã ----------
base = open(os.path.join(KT, 'FreeImageApi.kt'), encoding='utf-8').read()
MUT = [
    ('Authorization thiếu "Bearer "', '"Authorization" to "Bearer ${c.cfApiToken.trim()}"', '"Authorization" to "${c.cfApiToken.trim()}"'),
    ('bỏ kiểm Account ID (chèn đường dẫn lọt qua)', 'else if (!ACCOUNT_RE.matches(c.cfAccountId.trim())) out.add(', 'else if (false) out.add('),
    ('bỏ kiểm tên model', 'if (!MODEL_RE.matches(c.cfModel.trim())) out.add(', 'if (false) out.add('),
    ('FLUX schnell không còn nhận diện (rơi về thân chỉ có prompt)', 'model.contains("flux-1-schnell") ->', 'model.contains("flux-1-schnellX") ->'),
    ('Lightning dùng 20 bước', '"num_steps\\":4,\\"guidance\\":2', '"num_steps\\":20,\\"guidance\\":2'),
    ('kích thước không chia hết 8', 'private fun clampSize(v: Int): Int = (v.coerceIn(256, 2048) / 8) * 8', 'private fun clampSize(v: Int): Int = v.coerceIn(256, 2048)'),
    ('seed âm lọt qua', 'fun seedInt(seed: Long): Int = (seed and 0x7FFFFFFFL).toInt()', 'fun seedInt(seed: Long): Int = seed.toInt()'),
    ('Pollinations luôn dùng host có khoá (kể cả khi khoá rỗng)', 'return if (key.isEmpty()) HttpSpec("GET", "https://image.pollinations.ai', 'return if (false) HttpSpec("GET", "https://image.pollinations.ai'),
    ('Pollinations: khoá quay lại URL (rò vào proxy/nhật ký)', '"https://gen.pollinations.ai/image/${urlEncode(p)}?$q", listOf("Authorization" to "Bearer $key", "Accept" to accept)', '"https://gen.pollinations.ai/image/${urlEncode(p)}?$q&key=${urlEncode(key)}", listOf("Accept" to accept)'),
    ('Pollinations: Authorization thiếu "Bearer "', '"Authorization" to "Bearer $key", "Accept" to accept', '"Authorization" to key, "Accept" to accept'),
    ('Pollinations không mã hoá khoảng trắng', "ch == '-' || ch == '_'", "ch == ' ' || ch == '-' || ch == '_'"),
    ('base64 không nhận URL-safe', "vals['-'.code] = 62; vals['_'.code] = 63", ''),
    ('base64 không bỏ khoảng trắng', "if (ch == '=' || ch == ' ' || ch == '\\n' || ch == '\\r' || ch == '\\t') continue", "if (ch == '=') continue"),
    ('base64 chấp nhận ký tự lạ', 'require(v >= 0) { "base64 có ký tự không hợp lệ" }', ''),
    ('PNG bị nhận nhầm là JPEG', "b[3] == 'G'.code.toByte()) return \"png\"", "b[3] == 'G'.code.toByte()) return \"jpg\""),
    ('decode không ưu tiên magic bytes', 'if (ext != null) return DecodedImage(body, ext, null)', ''),
    ('decode bỏ qua lỗi errors[] của Cloudflare', 'if (first != null) {', 'if (false) {'),
    ('decode không kiểm base64 ra ảnh thật', 'val e2 = imageExt(raw) ?: return DecodedImage(null, "", "Chuỗi base64 giải mã ra không phải ảnh (PNG/JPEG/WebP)")', 'val e2 = imageExt(raw) ?: "png"'),
    ('clampPrompt cắt cứng giữa chữ', 'return (if (boundary > max * 2 / 3) cut.substring(0, boundary) else cut).trimEnd(\',\', \' \')', 'return cut'),
    ('prompt nền không còn dặn "không người"', 'parts.add("empty scene with absolutely no people, no characters, no figures, no text")', 'parts.add("scene")'),
    ('prompt phác nhân vật bỏ "chỉ một người"', 'one person only, upper body,', 'upper body,'),
    ('base64Encode đệm sai (rem==2 thiếu dấu =)', ".append(B64_ALPHABET[(n shr 6) and 63]).append('=')", ".append(B64_ALPHABET[(n shr 6) and 63])"),
    ('ImageSource hoán đổi nhà cung cấp', 'CLOUDFLARE -> FreeImageProvider.CLOUDFLARE', 'CLOUDFLARE -> FreeImageProvider.POLLINATIONS'),
    ('Pollinations không khoá vẫn gọi dồn dập (khoảng nghỉ 0)', 'if (provider == FreeImageProvider.POLLINATIONS && c.pollinationsKey.isBlank()) 15_000L else 0L', '0L'),
    ('bỏ giới hạn độ dài prompt Cloudflare', 'val p = clampPrompt(prompt, MAX_PROMPT_CHARS)\n                val neg', 'val p = prompt\n                val neg'),
]
lo, hi = 0, len(MUT)
if os.environ.get('MUT_RANGE'):
    a, b = os.environ['MUT_RANGE'].split(':'); lo, hi = int(a), int(b)
killed = ran = 0
for i in range(lo, min(hi, len(MUT))):
    name, old, new = MUT[i]
    if base.count(old) != 1:
        check(f'đột biến {i} có điểm cắm duy nhất ({name})', False, f'{base.count(old)} chỗ'); continue
    md = os.path.join(tmp, f'src{i}'); os.makedirs(md, exist_ok=True)
    open(os.path.join(md, 'FreeImageApi.kt'), 'w', encoding='utf-8').write(base.replace(old, new))
    shutil.copy(os.path.join(KT, 'MiniJson.kt'), os.path.join(md, 'MiniJson.kt'))
    j, rr = compile_([os.path.join(md, 'FreeImageApi.kt'), os.path.join(md, 'MiniJson.kt')], f'mut{i}')
    if rr.returncode != 0:
        check(f'đột biến {i} biên dịch được ({name})', False, rr.stderr[-300:]); continue
    ran += 1
    res2, e2 = run(j, L)
    survived = res2 is not None and not verify(res2)
    check(f'đột biến "{name}" bị bộ kiểm bắt', not survived)
    killed += (not survived)
if ran: check(f'thử phá mã: {killed}/{ran} đột biến bị bắt', killed == ran)
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
