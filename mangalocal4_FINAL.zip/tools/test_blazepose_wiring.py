#!/usr/bin/env python3
# mục 280 — kiểm TĨNH "dây nối" của BlazePose (bài học 279.2: mô-đun không nối dây = không có): tên JNI ↔ external fun ↔ CMake ↔ PoseExtractor ↔ giao diện ↔ workflow xuất model ↔ hằng số
# hai phía (C++ và Kotlin) phải khớp nhau. Có phép phá mã. Phần CHẠY thật: tools/test_blazepose_lift.py (Kotlin + model thật) và tools/test_blazepose_native.py (wrapper C++ thật).
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(p): return open(os.path.join(ROOT, p), encoding='utf-8').read()
F = {k: rd(v) for k, v in {
    'cpp': 'app/src/main/jni/blazepose_wrapper.cpp', 'cmake': 'app/src/main/jni/CMakeLists.txt',
    'bridge': 'app/src/main/java/com/mangalocal/pipeline/NativeBridge.kt', 'est': 'app/src/main/java/com/mangalocal/pipeline/BlazePoseEstimator.kt',
    'lift': 'app/src/main/java/com/mangalocal/pipeline/BlazePoseLift.kt', 'pe': 'app/src/main/java/com/mangalocal/pipeline/PoseExtractor.kt',
    'ui': 'app/src/main/java/com/mangalocal/ui/PoseEditorScreen.kt', 'wf': '.github/workflows/export_blazepose.yml',
    'exp': 'tools/export_blazepose.py', 'tl': 'tools/test_blazepose_lift.py', 'bm': 'app/src/main/java/com/mangalocal/pipeline/BundledModels.kt',
    'gradle': 'app/build.gradle'}.items()}
import hashlib
PINS = dict((l.split()[1], l.split()[0]) for l in open(os.path.join(ROOT, 'tools/blazepose_assets.sha256'), encoding='utf-8') if l.strip())
def asset_sha(n):
    p = os.path.join(ROOT, 'app/src/main/assets/blazepose', n)
    return hashlib.sha256(open(p, 'rb').read()).hexdigest() if os.path.exists(p) else None
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)

def checks(f):
    r = []
    ext = dict(re.findall(r'external fun (blazePose\w+)\(([^)]*)\)(?::\s*(\w+))?', f['bridge']) and [(m[0], (m[1], m[2])) for m in re.findall(r'external fun (blazePose\w+)\(([^)]*)\)(?::\s*(\w+))?', f['bridge'])])
    r.append(('NativeBridge khai báo đủ blazePoseInit / blazePoseRun / blazePoseFree', set(ext) == {'blazePoseInit', 'blazePoseRun', 'blazePoseFree'}))
    jni = {n: sig for n, sig in re.findall(r'JNICALL\s*\n?\s*Java_com_mangalocal_pipeline_NativeBridge_(blazePose\w+)\(([^)]*)\)', f['cpp'])}
    r.append(('mỗi external fun có hàm JNI cùng tên trong blazepose_wrapper.cpp (đúng package com.mangalocal.pipeline.NativeBridge)', set(jni) == set(ext) and len(jni) == 3))
    r.append(('kiểu tham số khớp: Init(String)→Long, Run(Long, FloatArray)→FloatArray, Free(Long)',
              'jstring' in jni.get('blazePoseInit', '') and 'jlong' in jni.get('blazePoseRun', '') and 'jfloatArray' in jni.get('blazePoseRun', '') and 'jlong' in jni.get('blazePoseFree', '')
              and 'modelDir: String' in ext.get('blazePoseInit', ('', ''))[0] and ext.get('blazePoseInit', ('', ''))[1] == 'Long'
              and 'rgb256: FloatArray' in ext.get('blazePoseRun', ('', ''))[0] and ext.get('blazePoseRun', ('', ''))[1] == 'FloatArray'))
    r.append(('wrapper được liệt kê trong CMakeLists.txt', re.search(r'^\s*blazepose_wrapper\.cpp', f['cmake'], re.M) is not None))
    r.append(('wrapper chọn đầu ra theo SỐ PHẦN TỬ (1 / 195 / 117), CPU, đầu vào theo layout của chính tensor, trả mảng rỗng khi lỗi',
              all(k in f['cpp'] for k in ('n != 1 && n != kLandmarkFloats && n != kWorldFloats', 'MNN_FORWARD_CPU', 'MNN::Tensor hostIn(input, input->getDimensionType())', 'return result;'))))
    consts = {}
    for name, expr in re.findall(r'constexpr int (k\w+)\s*=\s*([^;]+);', f['cpp']):
        e = expr
        for k, v in consts.items(): e = re.sub(rf'\b{k}\b', str(v), e)
        if re.fullmatch(r'[0-9 *+]+', e.strip()): consts[name] = eval(e)      # chỉ số và * + (đã lọc), không có tên lạ
    nums = {k: consts.get(k) for k in ('kSize', 'kLandmarkFloats', 'kWorldFloats', 'kResultFloats')}
    kl = {'SIZE': int(re.search(r'const val SIZE = (\d+)', f['lift']).group(1))} if re.search(r'const val SIZE = (\d+)', f['lift']) else {}
    r.append(('hằng số C++ khớp Kotlin: 256, 39×5 = 195, 39×3 = 117, tổng 313 = BlazePoseLift.RESULT_FLOATS',
              nums == {'kSize': 256, 'kLandmarkFloats': 195, 'kWorldFloats': 117, 'kResultFloats': 313} and kl.get('SIZE') == 256 and 'const val RESULT_FLOATS = 1 + 39 * 5 + 39 * 3' in f['lift']))
    r.append(('BlazePoseEstimator không ném lỗi: try/catch Throwable, kiểm kích thước đầu ra, thiếu model → null; nạp thất bại chỉ thử MỘT lần',
              f['est'].count('catch (e: Throwable)') >= 2 and 'raw.size != BlazePoseLift.RESULT_FLOATS' in f['est'] and 'initTried' in f['est']))
    r.append(('PoseExtractor: extractFromImage ghép hộp ↔ người theo CÙNG thứ tự sắp xếp với resultToCoco18People', 'raw.sortedByDescending { (it.box[1] + it.box[3]) / 2 }' in f['pe'] and 'sortedByDescending { (it.box[1] + it.box[3]) / 2 }' in f['pe'].split('fun resultToCoco18People')[1][:600]))
    r.append(('PoseExtractor: có công tắc liftDepth, kiểm sortedRaw.size == people.size, bỏ qua khi thiếu model, ảnh quá lớn; z chỉ thêm (x, y giữ nguyên)',
              all(k in f['pe'] for k in ('@Volatile var liftDepth: Boolean = true', 'sortedRaw.size != people.size', '!blazePose.isReady()', '12_000_000L', 'blazePose.lift(px, w, h, p, sortedRaw[i].box)'))))
    r.append(('PoseExtractor.close() giải phóng cả BlazePose', 'blazePose.close()' in f['pe']))
    r.append(('Giao diện: công tắc 3D thật chỉ hiện khi có model; có hướng dẫn + nút kiểm tra lại khi thiếu; thông báo kết quả CHỈ cho ảnh (không cho video)',
              all(k in f['ui'] for k in ('val depthReady = remember(depthCheck, extractorKey)', 'if (depthReady) {', 'poseExtractor.liftDepth = liftDepthUi', 'Kiểm tra lại model 3D', '!mime.startsWith("video") && poseExtractor.liftDepth')) ))
    r.append(('Workflow: có bước giải nén zip, cài MNN, chạy tools/export_blazepose.py, tải artifact blazepose-mnn (if-no-files-found: error)',
              all(k in f['wf'] for k in ('Auto-unzip', "--exclude='.github'", 'pip install MNN numpy', 'python tools/export_blazepose.py blazepose_out', 'name: blazepose-mnn', 'if-no-files-found: error'))))
    shas = re.findall(r"'([0-9a-f]{64})'", f['exp']); shas2 = re.findall(r"'([0-9a-f]{64})'", f['tl'])
    r.append(('sha256 pin của model lite/full trong export_blazepose.py khớp test_blazepose_lift.py (lite) và script dừng khi khác', len(shas) == 2 and shas2[0] == shas[0] and 'KHÁC bản đã ghim' in f['exp']))
    r.append(('script xuất chuyển bằng --fp16 và tự kiểm hình dạng tensor (1,256,256,3) và đầu ra 1 / 117 / 195 phần tử', all(k in f['exp'] for k in ("'--fp16'", '(1, 256, 256, 3)', 'for need in (1, 117, 195)'))))
    r.append(('model đóng trong APK: assets/blazepose/ có đúng blazepose_lite.mnn và blazepose_full.mnn, sha256 khớp bản ghim tools/blazepose_assets.sha256 (phát hiện sửa/hỏng nhầm)',
              set(PINS) == {'blazepose_lite.mnn', 'blazepose_full.mnn'} and all(asset_sha(n) == PINS[n] and asset_sha(n) is not None for n in PINS)))
    r.append(("Gradle giữ noCompress 'mnn' (model nằm nguyên trong APK, không nén lại)", "noCompress 'mnn'" in f['gradle']))
    r.append(('tên tệp khớp 4 nơi: Kotlin (danh sách chép) ↔ C++ (tên wrapper nạp) ↔ assets ↔ script xuất',
              'listOf("blazepose_lite.mnn", "blazepose_full.mnn")' in f['est'] and 'blazepose_full.mnn' in f['cpp'] and 'blazepose_lite.mnn' in f['cpp']
              and "f'blazepose_{name}.mnn'" in f['exp'] and set(PINS) == {'blazepose_lite.mnn', 'blazepose_full.mnn'}))
    r.append(('đường asset khớp thư mục: PoseExtractor mở "blazepose/$name" (assets/blazepose/), lỗi mở → null', 'context.assets.open("blazepose/$name")' in f['pe'] and 'catch (e: Exception) { null }' in f['pe']))
    r.append(('BundledModels: không ghi đè (có tệp nào thì thôi), chép qua tệp .part rồi đổi tên, dọn tệp tạm khi lỗi, không ném lỗi',
              all(k in f['bm'] for k in ('names.any { File(dir, it).exists() }) return 0', '"$n.part"', 'tmp.renameTo(dst)', 'tmp.length() > 0L', 'catch (e: Exception)'))))
    r.append(('PoseExtractor chép model từ APK ở HAI chỗ: prepareBundledModels() (giao diện, luồng nền) và trong withRealDepth khi thiếu model (luồng trích); chỉ thử một lần',
              'fun prepareBundledModels(): Int = blazePose.copyBundledIfMissing()' in f['pe'] and 'if (liftDepth && !blazePose.isReady()) blazePose.copyBundledIfMissing()' in f['pe'] and 'bundledTried' in f['est']))
    r.append(('Giao diện: mở màn thì chép model từ APK trên Dispatchers.IO rồi kiểm lại, báo "tự chép" khi có chép',
              'LaunchedEffect(poseExtractor)' in f['ui'] and 'withContext(Dispatchers.IO) { poseExtractor.prepareBundledModels() }' in f['ui'] and 'Đã tự chép model 3D' in f['ui']))
    # mục 282: ảnh không vuông — z phải cùng đơn vị bề ngang với x (Pose3D), nên Estimator truyền aspect = rộng/cao ảnh nguồn và depthFor khớp trong đơn vị đẳng hướng
    r.append(('mục 282: BlazePoseEstimator.lift truyền aspect = w/h của ảnh nguồn cho depthFor (ảnh không vuông không lệch z)',
              'BlazePoseLift.depthFor(person, lifted, if (h > 0) w.toFloat() / h else 1f)' in f['est']))
    r.append(('mục 282: depthFor có tham số aspect (mặc định 1), từ chối aspect không hợp lệ, khớp s với x·aspect và quy z về bề ngang (s / aspect)',
              'fun depthFor(person: List<StoryManager.PoseKeypoint>, lifted: Lifted, aspect: Float = 1f)' in f['lift'] and '!(aspect > 0f) || aspect.isInfinite()' in f['lift']
              and '(person[i].x - hsx) * aspect * dwx' in f['lift'] and 'val sz = s / aspect' in f['lift'] and 'z = sz * (wz[i] - hwz)' in f['lift']))
    r.append(('mục 282: test tích hợp (model thật) gọi depthFor kèm aspect và cài đặt numpy độc lập cũng dùng aspect', 'w.toFloat() / h' in open(os.path.join(ROOT, 'tools/kotlin_tests/BlazePoseLiftIT.kt'), encoding='utf-8').read() and 'asp = Wi / Hi' in f['tl']))
    return r
for n, ok in checks(F): check(ok, n)

muts = [
    ('CMake bỏ wrapper', 'cmake', '    blazepose_wrapper.cpp', '    # blazepose_wrapper.cpp'),
    ('đổi tên hàm JNI Run', 'cpp', 'NativeBridge_blazePoseRun', 'NativeBridge_blazePoseRunX'),
    ('NativeBridge đổi kiểu trả Run', 'bridge', 'external fun blazePoseRun(ctx: Long, rgb256: FloatArray): FloatArray', 'external fun blazePoseRun(ctx: Long, rgb256: FloatArray): Int'),
    ('wrapper chọn đầu ra khác số phần tử', 'cpp', 'constexpr int kWorldFloats = 39 * 3;', 'constexpr int kWorldFloats = 39 * 4;'),
    ('Kotlin RESULT_FLOATS lệch', 'lift', 'const val RESULT_FLOATS = 1 + 39 * 5 + 39 * 3', 'const val RESULT_FLOATS = 1 + 39 * 5 + 33 * 3'),
    ('Estimator bỏ try/catch', 'est', 'catch (e: Throwable) { null }', 'catch (e: IllegalStateException) { null }'),
    ('extractor đổi thứ tự ghép', 'pe', 'raw.sortedByDescending { (it.box[1] + it.box[3]) / 2 }', 'raw.sortedBy { (it.box[1] + it.box[3]) / 2 }'),
    ('extractor bỏ kiểm số lượng', 'pe', 'sortedRaw.size != people.size || ', ''),
    ('close không giải phóng BlazePose', 'pe', '; blazePose.close() }', ' }'),
    ('UI bỏ công tắc', 'ui', 'poseExtractor.liftDepth = liftDepthUi; depthMsg = null', 'depthMsg = null'),
    ('UI báo kết quả cả cho video', 'ui', '!mime.startsWith("video") && poseExtractor.liftDepth', 'poseExtractor.liftDepth'),
    ('workflow bỏ bước giải nén', 'wf', 'Auto-unzip source', 'Bỏ qua giải nén'),
    ('workflow bỏ artifact', 'wf', 'name: blazepose-mnn', 'name: ket-qua'),
    ('export bỏ --fp16', 'exp', "'--fp16'", "'--noop'"),
    ('PoseExtractor mở sai thư mục asset', 'pe', 'context.assets.open("blazepose/$name")', 'context.assets.open("models/$name")'),
    ('Estimator đổi tên tệp chép', 'est', 'listOf("blazepose_lite.mnn", "blazepose_full.mnn")', 'listOf("blazepose_lite.mnn", "blazepose_big.mnn")'),
    ('BundledModels bỏ kiểm "đã có thì thôi"', 'bm', 'names.any { File(dir, it).exists() }) return 0', 'false) return 0'),
    ('BundledModels ghi thẳng, bỏ tệp tạm', 'bm', 'tmp.renameTo(dst)', 'true'),
    ('UI chép trên luồng chính', 'ui', 'withContext(Dispatchers.IO) { poseExtractor.prepareBundledModels() }', 'poseExtractor.prepareBundledModels()'),
    ('Gradle bỏ noCompress mnn', 'gradle', "noCompress 'mnn'", "noCompress 'bin'"),
    ('PoseExtractor bỏ chép khi thiếu ở luồng trích', 'pe', 'if (liftDepth && !blazePose.isReady()) blazePose.copyBundledIfMissing()', '// bỏ'),
    ('Estimator quên truyền aspect', 'est', 'BlazePoseLift.depthFor(person, lifted, if (h > 0) w.toFloat() / h else 1f)', 'BlazePoseLift.depthFor(person, lifted)'),
    ('depthFor không quy z về bề ngang', 'lift', 'val sz = s / aspect', 'val sz = s'),
    ('depthFor khớp s không nhân x với aspect', 'lift', '(person[i].x - hsx) * aspect * dwx', '(person[i].x - hsx) * dwx'),
    ('numpy độc lập bỏ aspect', 'tl', 'asp = Wi / Hi', 'asp = 1.0'),
    ('sha256 lite lệch giữa script và test', 'exp', "f17bfbecadb61c3be1baa8b8d851cc6619c870a87167b32848ad20db306b9d61", "f17bfbecadb61c3be1baa8b8d851cc6619c870a87167b32848ad20db306b9d62"),
]
caught = 0
for name, k, old, new in muts:
    assert old in F[k], name
    f2 = dict(F); f2[k] = F[k].replace(old, new, 1)
    try: bad = any(not ok for _, ok in checks(f2))
    except Exception: bad = True
    caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name)
check(caught == len(muts), f'đột biến: {caught}/{len(muts)} bị bắt')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
