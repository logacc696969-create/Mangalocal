#!/usr/bin/env python3
# mục 275 — kiểm TĨNH (không có kotlinc) các sửa sau ảnh chụp màn hình thật của người dùng: màn "Vẽ / sửa khung xương" không cuộn được, chỉ thấy 1 người, không thấy chỗ nhập
# ảnh/video, không thấy lối vào Bối cảnh; cùng hướng dẫn trong app. Cấu trúc mã + phép thử phá mã. Cảm giác thao tác thật CHƯA kiểm (cần máy).
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
def rd(p): return open(os.path.join(K, p), encoding='utf-8').read()
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)

def checks(pe, ch, st, comp, hp, act):
    r = []
    r.append(('cột chính CUỘN được (verticalScroll + rememberScrollState)', 'Column(Modifier.padding(padding).padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()))' in pe))
    r.append(('đủ import cho cuộn dọc/ngang', all(('import androidx.compose.foundation.' + n + '\n') in pe for n in ['verticalScroll', 'horizontalScroll', 'rememberScrollState'])))
    canvas = pe[pe.index('Canvas(\n'):pe.index('val w = size.width; val h = size.height')]
    r.append(('khung vẽ không còn detectDragGestures (nuốt mọi cú kéo 1 ngón)', 'detectDragGestures(' not in canvas))
    r.append(('kéo khớp: chạm ngoài khớp thì thoát SỚM, không nuốt sự kiện (cho trang cuộn)', 'val idx = closest ?: return@awaitEachGesture' in canvas))
    body = canvas[canvas.index('val idx = closest'):]
    r.append(('chỉ consume() SAU khi đã trúng khớp (trong vòng kéo)', body.count('change.consume()') == 1 and canvas.index('change.consume()') > canvas.index('val idx = closest')))
    r.append(('hai ngón thì nhường cho khối zoom/pan', 'if (event.changes.size >= 2) break' in canvas))
    r.append(('bán kính bắt khớp tính theo dp thật (hitRadiusPx)', 'd < hitRadiusPx' in canvas))
    r.append(('nút mở phần nhập ảnh/video/OpenPose có nhãn rõ', 'Nhập tư thế từ ảnh / video / OpenPose' in pe and 'var showImport by remember' in pe))
    r.append(('phần nhập nằm trong if (showImport) và được đóng ngoặc', 'if (showImport) {' in pe and '}  // hết showImport' in pe))
    r.append(('thiếu model: vẫn có nút chọn ảnh/video (mờ) + cách làm + nút Kiểm tra lại', 'Chọn ảnh / video từ thư viện (cần model)' in pe and 'Text("Kiểm tra lại model")' in pe and 'Cách làm: (1) GitHub' in pe))
    r.append(('Kiểm tra lại model tạo lại PoseExtractor (remember(extractorKey))', 'remember(extractorKey) { PoseExtractor(context, storyManager) }' in pe and 'DisposableEffect(poseExtractor)' in pe and 'extractorKey++' in pe))
    r.append(('nút Thêm/Xoá người có CHỮ, hàng cuộn ngang', 'Text("Thêm người"' in pe and 'Text("Xoá người ${activePerson + 1}"' in pe and 'Row(Modifier.horizontalScroll(rememberScrollState())' in pe))
    r.append(('ToolShortcuts có đủ 4 lối tắt tới đúng route', all(('nav.navigate("%s")' % x) in comp for x in ['locations', 'pose_editor', 'expression_studio', 'family'])))
    r.append(('ToolShortcuts dùng ở màn Nhân vật và màn chi tiết truyện', 'item { ToolShortcuts(nav) }' in ch and 'item { ToolShortcuts(nav) }' in st))
    r.append(('Trợ giúp trong app có mục Bối cảnh, Tư thế, API miễn phí/Thử gọi/hạn mức, Sao lưu', all(k in hp for k in ['7. Bối cảnh', '8. Tư thế', '9. API ảnh miễn phí', '10. Sao lưu', '11. Bố cục trang PDF', '12. Hoán đổi mặt', '13. GLIGEN', 'Kiểm tra lại model', 'Thử gọi'])))
    r.append(('các route đích tồn tại trong MainActivity', all(('composable("%s")' % x) in re.sub(r'\s+', ' ', act) or re.search(r'composable\("%s"\)' % x, act) for x in ['locations', 'pose_editor', 'expression_studio', 'family'])))
    return r

S = [rd('ui/PoseEditorScreen.kt'), rd('ui/CharactersScreen.kt'), rd('ui/StoryScreens.kt'), rd('ui/Components.kt'), rd('ui/HelpScreen.kt'), rd('MainActivity.kt')]
for n, ok in checks(*S): check(ok, n)
guide = open(os.path.join(ROOT, 'HUONG_DAN_SU_DUNG.md'), encoding='utf-8').read()
check('Cập nhật mục 275' in guide and 'Kiểm tra lại model' in guide and 'Lối tắt có chữ' in guide, 'HUONG_DAN_SU_DUNG.md có phần mục 275')
muts = [
 (0, 'bỏ verticalScroll', '.fillMaxSize().verticalScroll(rememberScrollState())', '.fillMaxSize()'),
 (0, 'nuốt mọi cú kéo (quay lại detectDragGestures)', 'val idx = closest ?: return@awaitEachGesture', 'detectDragGestures(onDrag = { _, _ -> }); val idx = closest ?: return@awaitEachGesture'),
 (0, 'không thoát sớm khi chạm ngoài khớp', 'val idx = closest ?: return@awaitEachGesture', 'val idx = closest ?: 0'),
 (0, 'không nhường hai ngón', 'if (event.changes.size >= 2) break', ''),
 (0, 'bỏ nút Kiểm tra lại model', 'Text("Kiểm tra lại model")', 'Text("Đóng")'),
 (0, 'extractor không tạo lại', 'remember(extractorKey) { PoseExtractor(context, storyManager) }', 'remember { PoseExtractor(context, storyManager) }'),
 (0, 'bỏ nhãn chữ Thêm người', 'Text("Thêm người"', 'Text(""'),
 (1, 'bỏ lối tắt ở màn Nhân vật', 'item { ToolShortcuts(nav) }  // mục 275', ''),
 (3, 'lối tắt Bối cảnh sai route', 'nav.navigate("locations")', 'nav.navigate("location")'),
 (4, 'Trợ giúp thiếu mục Tư thế', '8. Tư thế', '8. Khác'),
]
caught = 0
for idx, name, old, new in muts:
    assert old in S[idx], name
    m2 = list(S); m2[idx] = S[idx].replace(old, new, 1)
    try: bad = any(not ok for _, ok in checks(*m2))
    except Exception: bad = True
    caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name)
check(caught == len(muts), f'đột biến: {caught}/{len(muts)} bị bắt')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
