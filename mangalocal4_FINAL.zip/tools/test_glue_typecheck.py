#!/usr/bin/env python3
"""mục 266 — biên dịch KIỂM KIỂU/PHẠM VI các file kết nối mạng mới (HttpRetryExec, ExternalLlmClient, FreeImageClient) bằng kotlinc THẬT, với stub OkHttp/coroutines
(tools/kotlin_stubs/) và các data class cấu hình TRÍCH NGUYÊN VĂN từ Models.kt.

Vì sao có: sandbox không có Android SDK/Maven nên trước đây mã kết nối chỉ được biên dịch lần đầu trên CI — và lịch sử dự án (Build #112/#115/#117, mục 156–160)
cho thấy lỗi hay gặp chính là lỗi kiểu/phạm vi Kotlin. Stub mô phỏng đúng chữ ký OkHttp 4.x/coroutines phần dự án dùng.
Thử phá mã: 5 lỗi biên dịch điển hình cố ý chèn vào PHẢI làm kotlinc báo lỗi (nếu không thì bước kiểm này vô dụng).
KHÔNG chứng minh: build Gradle/Compose/Android thành công (UI, MangaPipeline, ViewModel vẫn chỉ biên dịch được trên CI); stub lệch OkHttp thật.
Cần kotlinc (không có -> SKIP).
"""
import os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline')
STUBS = os.path.join(ROOT, 'tools/kotlin_stubs')
MODELS = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/model/Models.kt')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + str(d)[:500]) if (d and not c) else '')); ok &= bool(c)
def find():
    for c in [os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/work/kotlinc/bin/kotlinc', '/home/claude/tools_dl/kotlinc/bin/kotlinc']:
        if c and os.path.exists(c): return c
KOTLINC = find()
if not KOTLINC:
    print('SKIP: không có kotlinc'); sys.exit(0)

tmp = tempfile.mkdtemp()
models_src = open(MODELS, encoding='utf-8').read()
def extract(name):
    m = re.search(r'^data class ' + name + r'\(.*?^\)', models_src, re.S | re.M)
    return m.group(0) if m else None
ext, free = extract('ExternalLlmConfig'), extract('FreeImageConfig')
check('trích được ExternalLlmConfig và FreeImageConfig nguyên văn từ Models.kt', bool(ext and free))
open(os.path.join(tmp, 'ModelStub.kt'), 'w', encoding='utf-8').write('package com.mangalocal.model\n\n' + ext + '\n\n' + free + '\n')

GLUE = ['MiniJson.kt', 'OpenAiChatJson.kt', 'HttpRetryPolicy.kt', 'HttpRetryExec.kt', 'FreeImageApi.kt', 'FreeImageClient.kt', 'ExternalLlmClient.kt']
def compile_(files, out):
    return subprocess.run([KOTLINC, '-nowarn'] + files + ['-d', out], capture_output=True, text=True)
base_files = [os.path.join(STUBS, 'okhttp3_stub.kt'), os.path.join(STUBS, 'coroutines_stub.kt'), os.path.join(tmp, 'ModelStub.kt')]
r = compile_(base_files + [os.path.join(KT, f) for f in GLUE], os.path.join(tmp, 'out'))
errs = [l for l in r.stderr.split('\n') if ': error:' in l]
check('7 file kết nối biên dịch SẠCH với stub (0 lỗi kiểu/phạm vi)', r.returncode == 0 and not errs, '\n'.join(errs[:6]) or r.stderr[-400:])
if r.returncode != 0:
    print('CÓ LỖI'); sys.exit(1)

def src(f): return open(os.path.join(KT, f), encoding='utf-8').read()
MUT = [
    ('FreeImageClient.kt', 'truyền Request thay vì lambda cho HttpRetryExec', 'HttpRetryExec.execute(client, { toRequest(spec) }, onWait = onWait)', 'HttpRetryExec.execute(client, toRequest(spec), onWait = onWait)'),
    ('ExternalLlmClient.kt', 'visionBody thiếu một tham số', 'OpenAiChatJson.visionBody(config.modelName, prompt, FreeImageApi.base64Encode(imageBytes), mime, maxTokens, temperature)', 'OpenAiChatJson.visionBody(config.modelName, prompt, FreeImageApi.base64Encode(imageBytes), mime, maxTokens)'),
    ('HttpRetryExec.kt', 'đọc thuộc tính không tồn tại của Decision.Retry', 'Step.Wait(decision.delayMs)', 'Step.Wait(decision.delay)'),
    ('FreeImageClient.kt', 'thiếu import FreeImageConfig', 'import com.mangalocal.model.FreeImageConfig\n', ''),
    ('ExternalLlmClient.kt', 'gán Int vào biến String (sai kiểu)', 'val url = config.baseUrl.trimEnd(\'/\') + "/chat/completions"', 'val url: String = 42'),
]
killed = 0
for i, (f, name, old, new) in enumerate(MUT):
    s = src(f)
    if s.count(old) != 1:
        check(f'đột biến {i} có điểm cắm duy nhất ({name})', False, f'{s.count(old)} chỗ'); continue
    md = os.path.join(tmp, f'm{i}'); os.makedirs(md)
    files = []
    for g in GLUE:
        p = os.path.join(md, g); open(p, 'w', encoding='utf-8').write(s.replace(old, new) if g == f else src(g)); files.append(p)
    rr = compile_(base_files + files, os.path.join(md, 'out'))
    bad = rr.returncode != 0
    check(f'lỗi biên dịch cố ý "{name}" bị kotlinc bắt', bad)
    killed += bad
check(f'thử phá mã: {killed}/{len(MUT)} lỗi biên dịch bị bắt', killed == len(MUT))
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
