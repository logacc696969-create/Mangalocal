// mục 285: đường đối chiếu (fullRun) và tiến trình con "không base" dùng CÙNG backend với UnetModuleSet (macro MANGALOCAL_UNET_FORWARD_TYPE, mặc định CPU) — trước đây cứng CPU nên khi ghi đè
// sang OpenCL phép kiểm "tước == đầy đủ" thực chất so OpenCL với CPU (khác biệt số học w8 giữa hai backend, KHÔNG phải do việc tước).
// mục 283 TECHNICAL_STATUS.md — CHẠY THẬT `sd_engine/UnetModule.hpp` (UnetModuleSet) trên MNN 3.6.1 THẬT. Trước đây (270.4) chỉ có MNN GIẢ (tools/mnn_mock) và kiểm kiểu (282.4).
//   gen <thư_mục> : sinh unet_base.mnn (UNet đồ chơi có ĐÚNG cổng SD1.5: sample{2,4,h,w} / timestep int{1} / encoder_hidden_states{2,77,D} -> out_sample{2,4,h,w}),
//                   các A/B + spec cho hai LoRA. Sau đó tools/test_unet_module_real.py chạy lora_attach_branch --strip-base-weights để ra lora1.lora.mnn, lora2.lora.mnn.
//   run <thư_mục> : nạp UnetModuleSet THẬT (base + 2 module), so với đáp án CPU thuần (double, độc lập MNN) cho từng biến thể, step() (Composite/Switch/vùng), kích thước
//                   động, lỗi đầu vào, base_is_variant, warm_start_base, và ĐỐI CHỨNG: module LoRA nạp KHÔNG base thì SAI (chứng minh việc chia sẻ trọng số là thứ làm nó đúng).
// Mạng đồ chơi (mô phỏng khối ResNet của UNet): c_in(1x1, 4->8) -> +điều kiện(enc, timestep) -> SiLU -> c_mid(3x3, 8->8) -> +c_in(dư) -> SiLU -> out_sample(1x1, 8->4).
// SiLU = x*sigmoid(x) bằng toán tử RỜI (không gộp vào conv — đúng như UNet SD, tránh bẫy relu gộp của 265.7).
// KHÔNG chứng minh: UNet SD thật (tên op thật, Linear->Conv hay MatMul — cần `--list` trên unet.mnn thật), w8, OpenCL/NPU, RAM thật của UNet ~1 GB.
#include <MNN/expr/Executor.hpp>
#include <MNN/expr/Expr.hpp>
#include <MNN/expr/ExprCreator.hpp>
#include <MNN/expr/Module.hpp>
#include <MNN/expr/NeuralNetWorkOp.hpp>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <random>
#include <string>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>

#include "sd_engine/UnetModule.hpp"

using namespace MNN::Express;

static const int CIN = 4, CM = 8, KSEQ = 77, D = 16;   // D = hidden_dim đồ chơi (SD1.5 thật 768)
static const int H0 = 6, W0 = 8;                        // kích thước latent lúc lưu đồ thị (module shapeMutable nên đổi được)
static const float kEmGain = 5.0f;                      // độ nhạy của điều kiện văn bản: đủ lớn để sai độ dài chuỗi (kSeqLen) làm đầu ra lệch rõ rệt

struct Net { std::vector<float> w_in, b_in, w_mid, b_mid, w_out, b_out; };
struct Target { const char* name; int in_kk, out, r; float scale; std::vector<float> A, B; };
struct Lora { std::vector<Target> t; };

static VARP buildNet(const Net& n) {
    auto s = _Input({2, CIN, H0, W0}, NCHW, halide_type_of<float>()); s->setName("sample");
    auto t = _Input({1}, NCHW, halide_type_of<int>()); t->setName("timestep");
    auto e = _Input({2, KSEQ, D}, NCHW, halide_type_of<float>()); e->setName("encoder_hidden_states");
    auto cin = _Conv(std::vector<float>(n.w_in), std::vector<float>(n.b_in), s, {CIN, CM}, {1, 1}, VALID); cin->setName("c_in");
    auto em = _Reshape(_ReduceMean(e, {1, 2}, false), {2, 1, 1, 1});
    auto tf = _Reshape(_Cast<float>(t), {1, 1, 1, 1});
    auto h1 = _Add(_Add(cin, _Multiply(em, _Scalar<float>(kEmGain))), _Multiply(tf, _Scalar<float>(0.01f)));
    auto a1 = _Multiply(h1, _Sigmoid(h1));
    auto cmid = _Conv(std::vector<float>(n.w_mid), std::vector<float>(n.b_mid), a1, {CM, CM}, {3, 3}, SAME); cmid->setName("c_mid");
    auto res = _Add(cmid, h1);
    auto a2 = _Multiply(res, _Sigmoid(res));
    auto out = _Conv(std::vector<float>(n.w_out), std::vector<float>(n.b_out), a2, {CM, CIN}, {1, 1}, VALID); out->setName("out_sample");
    return out;
}

// ---- tham chiếu CPU thuần (double), độc lập MNN ----
static std::vector<double> convRef(const std::vector<double>& in, int cin, int cout, int k, const std::vector<float>& w, const std::vector<float>& b, int H, int W) {
    std::vector<double> o((size_t)cout * H * W); int pad = k / 2;
    for (int oc = 0; oc < cout; ++oc) for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) {
        double acc = b[oc];
        for (int ic = 0; ic < cin; ++ic) for (int ky = 0; ky < k; ++ky) for (int kx = 0; kx < k; ++kx) {
            int iy = y + ky - pad, ix = x + kx - pad; if (iy < 0 || iy >= H || ix < 0 || ix >= W) continue;
            acc += (double)w[(((size_t)oc * cin + ic) * k + ky) * k + kx] * in[((size_t)ic * H + iy) * W + ix];
        }
        o[((size_t)oc * H + y) * W + x] = acc;
    }
    return o;
}
static double silu(double v) { return v / (1.0 + std::exp(-v)); }
static std::vector<float> forwardRef(const Net& n, const std::vector<float>& sample, int ts, const std::vector<float>& enc, int H, int W) {
    std::vector<float> out((size_t)2 * CIN * H * W);
    for (int b = 0; b < 2; ++b) {
        std::vector<double> x(sample.begin() + (size_t)b * CIN * H * W, sample.begin() + (size_t)(b + 1) * CIN * H * W);
        double em = 0; for (size_t i = 0; i < (size_t)KSEQ * D; ++i) em += enc[(size_t)b * KSEQ * D + i]; em /= (double)(KSEQ * D);
        auto h1 = convRef(x, CIN, CM, 1, n.w_in, n.b_in, H, W);
        for (auto& v : h1) v += (double)kEmGain * em + 0.01 * ts;
        std::vector<double> a1(h1.size()); for (size_t i = 0; i < h1.size(); ++i) a1[i] = silu(h1[i]);
        auto cm = convRef(a1, CM, CM, 3, n.w_mid, n.b_mid, H, W);
        std::vector<double> a2(cm.size()); for (size_t i = 0; i < cm.size(); ++i) a2[i] = silu(cm[i] + h1[i]);
        auto y = convRef(a2, CM, CIN, 1, n.w_out, n.b_out, H, W);
        for (size_t i = 0; i < y.size(); ++i) out[(size_t)b * CIN * H * W + i] = (float)y[i];
    }
    return out;
}
static void mergeInto(std::vector<float>& w, const Target& t) {   // W += scale * B * A   (A [r][in_kk], B [out][r])
    for (int o = 0; o < t.out; ++o) for (int r = 0; r < t.r; ++r) for (int j = 0; j < t.in_kk; ++j)
        w[(size_t)o * t.in_kk + j] += t.scale * t.B[(size_t)o * t.r + r] * t.A[(size_t)r * t.in_kk + j];
}
static Net withLora(const Net& base, const Lora& l) {
    Net n = base;
    for (const auto& t : l.t) {
        std::string nm = t.name;
        if (nm == "c_in") mergeInto(n.w_in, t); else if (nm == "c_mid") mergeInto(n.w_mid, t); else mergeInto(n.w_out, t);
    }
    return n;
}

static std::mt19937 g_rng(283);
static std::vector<float> rnd(size_t n, float sd = 0.3f) { std::normal_distribution<float> nd(0.f, sd); std::vector<float> v(n); for (auto& e : v) e = nd(g_rng); return v; }
struct All { Net base; Lora l1, l2; };
static All makeAll() {   // DETERMINISTIC: gen và run gọi cùng thứ tự => cùng số
    g_rng.seed(283);
    All a;
    a.base = Net{rnd((size_t)CM * CIN), rnd(CM), rnd((size_t)CM * CM * 9), rnd(CM), rnd((size_t)CIN * CM), rnd(CIN)};
    a.l1.t = {{"c_in", CIN, CM, 3, 0.7f, rnd((size_t)3 * CIN), rnd((size_t)CM * 3)},
              {"c_mid", CM * 9, CM, 2, 0.5f, rnd((size_t)2 * CM * 9), rnd((size_t)CM * 2)},
              {"out_sample", CM, CIN, 2, 1.3f, rnd((size_t)2 * CM), rnd((size_t)CIN * 2)}};
    a.l2.t = {{"c_mid", CM * 9, CM, 3, 0.9f, rnd((size_t)3 * CM * 9), rnd((size_t)CM * 3)},
              {"out_sample", CM, CIN, 2, 0.6f, rnd((size_t)2 * CM), rnd((size_t)CIN * 2)}};
    return a;
}
static void writeFloats(const std::string& p, const std::vector<float>& v) { std::ofstream f(p, std::ios::binary); f.write((const char*)v.data(), v.size() * sizeof(float)); }

static int gen(const std::string& d) {
    All a = makeAll();
    Variable::save({buildNet(a.base)}, (d + "/unet_base.mnn").c_str());
    int li = 1;
    for (const Lora* l : {&a.l1, &a.l2}) {
        std::ofstream sp(d + "/spec" + std::to_string(li) + ".txt");
        int ti = 0;
        for (const auto& t : l->t) {
            std::string A = d + "/L" + std::to_string(li) + "_" + std::to_string(ti) + "A.bin", B = d + "/L" + std::to_string(li) + "_" + std::to_string(ti) + "B.bin";
            writeFloats(A, t.A); writeFloats(B, t.B);
            sp << t.name << " " << t.r << " " << t.scale << " " << A << " " << B << "\n"; ++ti;
        }
        ++li;
    }
    std::printf("gen ok\n"); return 0;
}

static int g_pass = 0, g_fail = 0;
static void check(const std::string& n, bool c, const std::string& d = "") { std::printf("%s %s%s\n", c ? "PASS" : "FAIL", n.c_str(), (!c && !d.empty()) ? (" :: " + d).c_str() : ""); (c ? g_pass : g_fail)++; }
static double maxdiff(const std::vector<float>& a, const float* b) { double m = 0; for (size_t i = 0; i < a.size(); ++i) { if (!std::isfinite(b[i])) return 1e30; m = std::max(m, (double)std::fabs(a[i] - b[i])); } return m; }
static double maxabs(const std::vector<float>& a) { double m = 0; for (float v : a) m = std::max(m, (double)std::fabs(v)); return m; }
static std::vector<float> fullRun(const std::string& path, const std::vector<float>& sample, int ts, const std::vector<float>& enc, int H, int W, int Dd, bool& ok) {
    // chạy tệp LoRA ĐẦY ĐỦ (còn trọng số nền, KHÔNG base) bằng Module::load thường — tham chiếu "cùng lượng tử hoá" để chứng minh việc tước trọng số là KHÔNG mất mát
    ok = false; std::vector<float> out;
    MNN::ScheduleConfig sc; sc.type = MANGALOCAL_UNET_FORWARD_TYPE; sc.numThread = 2; MNN::BackendConfig bc; bc.memory = MNN::BackendConfig::Memory_Low; bc.power = MNN::BackendConfig::Power_High; sc.backendConfig = &bc;   // cùng cấu hình UnetModuleSet/app (Memory_Low bật lượng tử hoá động kích hoạt với w8)
    std::shared_ptr<Executor::RuntimeManager> rt(Executor::RuntimeManager::createRuntimeManager(sc)); Module::Config mc; mc.shapeMutable = true; mc.rearrange = true;
    std::shared_ptr<Module> m(Module::load({"sample", "timestep", "encoder_hidden_states"}, {"out_sample"}, path.c_str(), rt, &mc)); if (!m) return out;
    auto is = _Input({2, CIN, H, W}, NCHW, halide_type_of<float>()); auto it = _Input({1}, NCHW, halide_type_of<int>()); auto ie = _Input({2, KSEQ, Dd}, NCHW, halide_type_of<float>());
    std::memcpy(is->writeMap<float>(), sample.data(), sample.size() * 4); it->writeMap<int>()[0] = ts; std::memcpy(ie->writeMap<float>(), enc.data(), enc.size() * 4);
    auto outs = m->onForward({is, it, ie}); if (outs.empty() || outs[0].get() == nullptr) return out;
    auto y = _Convert(outs[0], NCHW); const float* p = y->readMap<float>(); if (!p) return out;
    out.assign(p, p + (size_t)2 * CIN * H * W); ok = true; return out;
}
static std::string fmt(double v) { char b[48]; std::snprintf(b, sizeof b, "%.3e", v); return b; }

static int run(const std::string& d) {
    All a = makeAll();
    const Net n1 = withLora(a.base, a.l1), n2 = withLora(a.base, a.l2);
    auto sample = rnd((size_t)2 * CIN * H0 * W0, 1.0f);
    auto enc1 = rnd((size_t)2 * KSEQ * D, 1.0f), enc2 = rnd((size_t)2 * KSEQ * D, 1.0f), enc0 = rnd((size_t)2 * KSEQ * D, 1.0f);
    const int ts = 421;
    auto refB = forwardRef(a.base, sample, ts, enc0, H0, W0), ref1 = forwardRef(n1, sample, ts, enc1, H0, W0), ref2 = forwardRef(n2, sample, ts, enc2, H0, W0);
    const std::string base = d + "/unet_base.mnn", l1 = d + "/lora1.lora.mnn", l2 = d + "/lora2.lora.mnn";
    // độ nhạy: LoRA phải thật sự đổi đầu ra (nếu không mọi phép so sánh dưới đây vô nghĩa)
    { std::vector<float> r1b = forwardRef(a.base, sample, ts, enc1, H0, W0); check("độ nhạy: LoRA 1 đổi đầu ra > 1e-2 so với nền", maxdiff(ref1, r1b.data()) > 1e-2, fmt(maxdiff(ref1, r1b.data()))); }
    double tol = 1e-5 * std::max(1.0, std::max(maxabs(ref1), maxabs(ref2)));   // ~2e-4; sai lệch thật ~1e-5 (float32 so với double)
    if (const char* e = std::getenv("UNET_TOL_ABS")) tol = std::atof(e);          // w8: nền lượng tử hoá 8-bit nên sai lệch so với đáp án double lớn hơn (nhiễu lượng tử, không phải lỗi)

    unet_module::UnetModuleSet set; std::string err;
    // ── lỗi đầu vào (trước khi nạp) ──
    check("nạp: thiếu đường dẫn nền → false + lý do", !set.load("", {l1}, 2, &err) && !err.empty());
    check("nạp: không có module LoRA → false", !set.load(base, {}, 2, &err));
    check("nạp: file nền không tồn tại → false", !set.load(d + "/khong_co.mnn", {l1}, 2, &err) && err.find("thiếu") != std::string::npos, err);
    check("nạp: file module không tồn tại → false", !set.load(base, {l1, d + "/khong_co.lora.mnn"}, 2, &err), err);
    {   // file hỏng (không phải .mnn)
        std::ofstream(d + "/rac.lora.mnn") << "đây không phải một mô hình MNN";
        check("nạp: file module hỏng → false, dọn sạch (loaded()=false)", !set.load(base, {d + "/rac.lora.mnn"}, 2, &err) && !set.loaded(), err);
    }
    // ── nạp thật: nền + 2 module ──
    bool ok = set.load(base, {l1, l2}, 2, &err);
    check("nạp UNet nền + 2 module LoRA (Module::load thật, base + rearrange)", ok && set.loaded() && set.count() == 2, err);
    check("UnetModuleSet đã cấu hình ĐÚNG loại backend được yêu cầu (forwardType() == MANGALOCAL_UNET_FORWARD_TYPE; mặc định CPU)", ok && set.forwardType() == (int)MANGALOCAL_UNET_FORWARD_TYPE, std::to_string(set.forwardType()));
    if (!ok) { std::printf("RESULT pass=%d fail=%d\n", g_pass, g_fail); return 1; }
    std::vector<float> o(ref1.size());
    check("runOne(0) = nền + LoRA 1 (so với CPU thuần)", set.runOne(0, H0, W0, D, ts, sample.data(), enc1.data(), o.data(), &err) && maxdiff(ref1, o.data()) < tol, err + " maxdiff=" + fmt(maxdiff(ref1, o.data())));
    std::printf("  [số đo] runOne(0): maxdiff=%s (tol %s)\n", fmt(maxdiff(ref1, o.data())).c_str(), fmt(tol).c_str());
    check("runOne(1) = nền + LoRA 2 (so với CPU thuần)", set.runOne(1, H0, W0, D, ts, sample.data(), enc2.data(), o.data(), &err) && maxdiff(ref2, o.data()) < tol, err + " maxdiff=" + fmt(maxdiff(ref2, o.data())));
    std::printf("  [số đo] runOne(1): maxdiff=%s\n", fmt(maxdiff(ref2, o.data())).c_str());
    { std::ifstream f1(d + "/lora1_full.mnn"); if (f1.good()) {   // tệp LoRA đầy đủ cùng lượng tử hoá có mặt (test_unet_module_real.py tạo) ⇒ chứng minh việc tước trọng số KHÔNG mất mát
        bool k1 = false, k2 = false; auto f1o = fullRun(d + "/lora1_full.mnn", sample, ts, enc1, H0, W0, D, k1), f2o = fullRun(d + "/lora2_full.mnn", sample, ts, enc2, H0, W0, D, k2);
        std::vector<float> a(ref1.size()), b(ref1.size()); bool r1k = set.runOne(0, H0, W0, D, ts, sample.data(), enc1.data(), a.data(), &err), r2k = set.runOne(1, H0, W0, D, ts, sample.data(), enc2.data(), b.data(), &err);
        double e1 = k1 && r1k ? maxdiff(f1o, a.data()) : 1e30, e2 = k2 && r2k ? maxdiff(f2o, b.data()) : 1e30;
        std::printf("  [số đo] module đã tước + base so với tệp LoRA đầy đủ cùng lượng tử hoá: %s | %s\n", fmt(e1).c_str(), fmt(e2).c_str());
        check("module ĐÃ TƯỚC trọng số nền + base == tệp LoRA ĐẦY ĐỦ cùng lượng tử hoá (≤ 1e-4): tước là KHÔNG mất mát", e1 <= 1e-4 && e2 <= 1e-4, fmt(e1) + " " + fmt(e2)); } }
    check("runOne(0) lặp lại lần 2 cho CÙNG kết quả (không rò trạng thái giữa các lần gọi)", set.runOne(0, H0, W0, D, ts, sample.data(), enc1.data(), o.data(), &err) && maxdiff(ref1, o.data()) < tol, err);
    check("runOne: chỉ số ngoài phạm vi → false", !set.runOne(2, H0, W0, D, ts, sample.data(), enc1.data(), o.data(), &err) && !err.empty());
    check("runOne: con trỏ null → false", !set.runOne(0, H0, W0, D, ts, nullptr, enc1.data(), o.data(), &err));
    check("runOne: kích thước không hợp lệ → false", !set.runOne(0, 0, W0, D, ts, sample.data(), enc1.data(), o.data(), &err));
    // ── đầu vào khác nhau cho từng biến thể (CLIP riêng) cho kết quả khác nhau: không nhầm biến thể ──
    { std::vector<float> oa(ref1.size()), ob(ref1.size());
      set.runOne(0, H0, W0, D, ts, sample.data(), enc1.data(), oa.data(), &err); set.runOne(1, H0, W0, D, ts, sample.data(), enc1.data(), ob.data(), &err);
      check("hai module LoRA cho đầu ra KHÁC nhau trên cùng đầu vào (không nhầm module)", maxdiff(oa, ob.data()) > 1e-2, fmt(maxdiff(oa, ob.data()))); }
    // ── kích thước động (shapeMutable): đổi h8, w8 giữa các lần gọi trên CÙNG module ──
    { const int h = 4, w = 5; auto s2 = rnd((size_t)2 * CIN * h * w, 1.0f); auto r = forwardRef(n1, s2, ts, enc1, h, w); std::vector<float> oo(r.size());
      check("kích thước động 4×5 (khác lúc lưu 6×8) vẫn đúng", set.runOne(0, h, w, D, ts, s2.data(), enc1.data(), oo.data(), &err) && maxdiff(r, oo.data()) < tol, err + " maxdiff=" + fmt(maxdiff(r, oo.data())));
      check("…rồi quay lại 6×8 vẫn đúng", set.runOne(0, H0, W0, D, ts, sample.data(), enc1.data(), o.data(), &err) && maxdiff(ref1, o.data()) < tol, err); }
    // ── timestep có tác dụng (không bị bỏ qua) ──
    { auto rt = forwardRef(n1, sample, 7, enc1, H0, W0); std::vector<float> oo(rt.size());
      check("timestep khác → đầu ra khác và khớp tham chiếu", set.runOne(0, H0, W0, D, 7, sample.data(), enc1.data(), oo.data(), &err) && maxdiff(rt, oo.data()) < tol && maxdiff(ref1, oo.data()) > 1e-3, err); }
    // ── step(): Composite (cả hai hoạt động), Switch, vùng ──
    const std::size_t n = ref1.size();
    { unet_module::StepParams p; p.step = 0; p.tau = 5; p.active_count = 2; p.h8 = H0; p.w8 = W0; p.hidden_dim = D; p.timestep = ts;
      std::vector<float> w = {1.0f, 0.5f}; p.weights = &w;
      auto act = lora_compose::activeSet(p.step, 2, p.tau, p.active_count);
      std::vector<const float*> ptr; for (int i : act) ptr.push_back(i == 0 ? ref1.data() : ref2.data());
      std::vector<float> exp(n); lora_compose::blend(ptr, lora_compose::factors(act, w), n, exp.data());
      std::vector<float> got(n); std::vector<const float*> encs = {enc1.data(), enc2.data()};
      check("step() Composite: trộn hai biến thể = blend(đáp án CPU thuần)", set.step(p, sample.data(), encs, got.data(), &err) && maxdiff(exp, got.data()) < tol && act.size() == 2, err + " maxdiff=" + fmt(maxdiff(exp, got.data())) + " act=" + std::to_string(act.size()));
      unet_module::StepParams q = p; q.step = 9; q.active_count = 1;   // Switch: sau tau chỉ một biến thể
      auto act2 = lora_compose::activeSet(q.step, 2, q.tau, q.active_count);
      std::vector<float> got2(n); bool s2 = set.step(q, sample.data(), encs, got2.data(), &err);
      const std::vector<float>& e2 = (act2.size() == 1 && act2[0] == 0) ? ref1 : ref2;
      check("step() Switch: một biến thể = đáp án CPU thuần của biến thể đó", s2 && act2.size() == 1 && maxdiff(e2, got2.data()) < tol, err);
      std::vector<const float*> badEncs = {enc1.data()};
      check("step(): số điều kiện văn bản ≠ số biến thể → false", !set.step(p, sample.data(), badEncs, got.data(), &err));
      // vùng (regional): trường hệ số từng pixel
      const std::size_t hw = (std::size_t)H0 * W0; std::vector<float> fld(2 * hw);
      for (int y = 0; y < H0; ++y) for (int x = 0; x < W0; ++x) { fld[(size_t)y * W0 + x] = x < W0 / 2 ? 1.f : 0.f; fld[hw + (size_t)y * W0 + x] = x < W0 / 2 ? 0.f : 1.f; }
      unet_module::StepParams rp = p; rp.regional_fields = fld.data();
      std::vector<const float*> fp = {fld.data(), fld.data() + hw}; std::vector<const float*> pp = {ref1.data(), ref2.data()};
      std::vector<float> exr(n), gotr(n); lora_compose::blendRegional(pp, fp, hw, (std::size_t)2 * CIN, exr.data());
      check("step() vùng: trái = LoRA 1, phải = LoRA 2 (blendRegional trên đáp án CPU thuần)", set.step(rp, sample.data(), encs, gotr.data(), &err) && maxdiff(exr, gotr.data()) < tol, err + " maxdiff=" + fmt(maxdiff(exr, gotr.data()))); }
    // ── warm_start_base (mặc định TẮT): bật lên cho cùng kết quả và chạy nền trước ──
    { unet_module::UnetModuleSet w; bool lw = w.load(base, {l1, l2}, 2, &err, false, true);
      check("warm_start_base=true: nạp được, chưa chạy nền", lw && w.warmStartBase() && !w.baseRan(), err);
      check("warm_start_base=true: lần chạy đầu cho cùng kết quả và đã chạy nền", w.runOne(0, H0, W0, D, ts, sample.data(), enc1.data(), o.data(), &err) && maxdiff(ref1, o.data()) < tol && w.baseRan(), err + " maxdiff=" + fmt(maxdiff(ref1, o.data()))); }
    check("warm_start_base mặc định TẮT: không chạy nền thừa", !set.warmStartBase() && !set.baseRan());
    // ── base_is_variant=true: biến thể 0 = nền thuần ──
    { unet_module::UnetModuleSet v; bool lv = v.load(base, {l1, l2}, 2, &err, true);
      check("base_is_variant=true: count = 1 + số module", lv && v.count() == 3 && v.baseIsVariant(), err);
      check("base_is_variant=true: biến thể 0 = nền THUẦN (không LoRA)", v.runOne(0, H0, W0, D, ts, sample.data(), enc0.data(), o.data(), &err) && maxdiff(refB, o.data()) < tol, err + " maxdiff=" + fmt(maxdiff(refB, o.data())));
      check("base_is_variant=true: biến thể 1 = LoRA 1, biến thể 2 = LoRA 2", v.runOne(1, H0, W0, D, ts, sample.data(), enc1.data(), o.data(), &err) && maxdiff(ref1, o.data()) < tol
            && v.runOne(2, H0, W0, D, ts, sample.data(), enc2.data(), o.data(), &err) && maxdiff(ref2, o.data()) < tol, err); }
    // ── release() an toàn, gọi nhiều lần; nạp lại được ──
    set.release(); set.release();
    check("release() hai lần an toàn; loaded()=false; count()=0", !set.loaded() && set.count() == 0);
    check("nạp lại sau release() chạy đúng", set.load(base, {l1, l2}, 2, &err) && set.runOne(1, H0, W0, D, ts, sample.data(), enc2.data(), o.data(), &err) && maxdiff(ref2, o.data()) < tol, err);
    check("runOne sau release() → false", (set.release(), !set.runOne(0, H0, W0, D, ts, sample.data(), enc1.data(), o.data(), &err)));
    // ── ĐỐI CHỨNG: module LoRA (đã tước trọng số nền) nạp KHÔNG base → không được cho kết quả đúng. Chạy trong TIẾN TRÌNH CON: với w8 MNN 3.6.1 chia cho 0 / SEGV khi tạo execution cho conv đã tước
    // buffer w8 thay vì báo lỗi như fp32; UnetModuleSet không bao giờ nạp kiểu này (luôn truyền base), nhưng bộ kiểm không được chết theo (mất cả đầu ra). ──
    {
        fflush(stdout); pid_t pid = fork();
        if (pid == 0) {
            alarm(90);   // mục 285: trên OpenCL + w8, module KHÔNG base TREO (không chết như CPU); SIGALRM biến treo thành "chết" để đối chứng kết thúc (đối chứng chỉ cần "không cho kết quả đúng")
            MNN::ScheduleConfig sc; sc.type = MANGALOCAL_UNET_FORWARD_TYPE; sc.numThread = 2; MNN::BackendConfig bc; bc.memory = MNN::BackendConfig::Memory_Low; bc.power = MNN::BackendConfig::Power_High; sc.backendConfig = &bc;
            std::shared_ptr<Executor::RuntimeManager> rt(Executor::RuntimeManager::createRuntimeManager(sc));
            Module::Config mc; mc.shapeMutable = true; mc.rearrange = true;
            std::shared_ptr<Module> m(Module::load({"sample", "timestep", "encoder_hidden_states"}, {"out_sample"}, l1.c_str(), rt, &mc)); double diff = 1e30;
            if (m) {
                auto is = _Input({2, CIN, H0, W0}, NCHW, halide_type_of<float>()); auto it = _Input({1}, NCHW, halide_type_of<int>()); auto ie = _Input({2, KSEQ, D}, NCHW, halide_type_of<float>());
                std::memcpy(is->writeMap<float>(), sample.data(), sample.size() * 4); it->writeMap<int>()[0] = ts; std::memcpy(ie->writeMap<float>(), enc1.data(), enc1.size() * 4);
                auto outs = m->onForward({is, it, ie});
                if (!(outs.empty() || outs[0].get() == nullptr)) { auto y = _Convert(outs[0], NCHW); const float* p = y->readMap<float>(); diff = p ? maxdiff(ref1, p) : 1e30; }
            }
            _exit(diff > 0.1 ? 0 : 1);   // 0 = "không cho kết quả đúng" (lỗi thực thi hoặc sai > 0,1)
        }
        int st = 0; waitpid(pid, &st, 0);
        const bool crashed = WIFSIGNALED(st), wrong = WIFEXITED(st) && WEXITSTATUS(st) == 0;
        std::printf("  [số đo] không base: %s\n", crashed ? ("tiến trình con CHẾT bởi tín hiệu " + std::to_string(WTERMSIG(st)) + " (MNN không xử lý được — chấp nhận cho đối chứng)").c_str() : (wrong ? "KHÔNG chạy được/sai (execution error)" : "CHO KẾT QUẢ ĐÚNG (!)"));
        check("ĐỐI CHỨNG: module LoRA nạp KHÔNG base không cho kết quả đúng (lỗi thực thi, sai > 0,1, hoặc MNN chết) — chia sẻ trọng số nền là bắt buộc", crashed || wrong);
    }
    std::printf("RESULT pass=%d fail=%d\n", g_pass, g_fail);
    return g_fail == 0 ? 0 : 1;
}

int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IOLBF, 0);   // giữ đầu ra nếu một phép kiểm làm tiến trình chết
    if (argc >= 3 && std::string(argv[1]) == "gen") return gen(argv[2]);
    if (argc >= 3 && std::string(argv[1]) == "run") return run(argv[2]);
    std::fprintf(stderr, "gen <dir> | run <dir>\n");
    return 2;
}
