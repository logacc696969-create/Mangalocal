// mục 288 — harness CHẠY THẬT mobile_sam_core.hpp (cùng mã app dùng) trên model MobileSAM thật. Dùng bởi tools/test_mobile_sam_core.py.
// Cách dùng: harness <enc.mnn> <dec.mnn> <anh.rgb(W*H*3 byte)> <W> <H> <clickX> <clickY> <mask_out.bin>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iterator>
#include "mobile_sam_core.hpp"
int main(int argc, char **argv) {
  if (argc < 9) { std::fprintf(stderr, "thiếu tham số\n"); return 2; }
  const int W = std::atoi(argv[4]), H = std::atoi(argv[5]);
  std::ifstream f(argv[3], std::ios::binary);
  std::vector<unsigned char> rgb((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  if ((long)rgb.size() != (long)W * H * 3) { std::fprintf(stderr, "kích thước .rgb sai: %zu\n", rgb.size()); return 3; }
  mobilesam::Engine eng; std::string err;
  if (!eng.load(argv[1], argv[2], 1, &err)) { std::printf("LOAD_FAIL %s\n", err.c_str()); return 4; }
  std::vector<unsigned char> mask; float iou = -1.f;
  auto t0 = std::chrono::steady_clock::now();
  if (!eng.clickToMask(rgb.data(), W, H, (float)std::atof(argv[6]), (float)std::atof(argv[7]), &mask, &err, &iou)) { std::printf("RUN_FAIL %s\n", err.c_str()); return 5; }
  double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::ofstream o(argv[8], std::ios::binary); o.write((const char *)mask.data(), mask.size());
  long area = 0; for (auto v : mask) area += (v != 0);
  std::printf("OK area=%ld iou_pred=%.4f sec=%.2f\n", area, iou, sec);
  return 0;
}
