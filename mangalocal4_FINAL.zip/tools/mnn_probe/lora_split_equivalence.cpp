// mục 264 — THỰC NGHIỆM trên MNN 3.6.1 thật: LoRA tách rời (nhánh conv_A -> conv_B -> ADD) với Module::Config::base.
// Câu hỏi: (1) đầu ra "tách rời" có bằng đầu ra "gộp trọng số" không? (2) config.base có THẬT SỰ dùng chung trọng số nền không
// (kiểm bằng cách đặt trọng số conv0 trong lora.mnn = 0: nếu sharing hoạt động thì kết quả vẫn dùng trọng số của module nền).
#include <MNN/expr/Expr.hpp>
#include <MNN/expr/ExprCreator.hpp>
#include <MNN/expr/Module.hpp>
#include <MNN/expr/Executor.hpp>
#include <MNN/expr/NeuralNetWorkOp.hpp>
#include <cmath>
#include <cstdio>
#include <random>
#include <vector>
using namespace MNN::Express;
static const int CIN = 16, COUT = 24, R = 4, H = 6, W = 6;

static VARP buildNet(const std::vector<float>& W0, const std::vector<float>& b0, const std::vector<float>* A, const std::vector<float>* B, float scale) {
    auto x = _Input({1, CIN, H, W}, NCHW, halide_type_of<float>()); x->setName("x");
    auto c0 = _Conv(std::vector<float>(W0), std::vector<float>(b0), x, {CIN, COUT}, {1, 1}, VALID);
    c0->setName("conv0");
    VARP out = c0;
    if (A && B) {
        auto la = _Conv(std::vector<float>(*A), std::vector<float>(R, 0.f), x, {CIN, R}, {1, 1}, VALID); la->setName("lora_a");
        std::vector<float> Bs(*B); for (auto& v : Bs) v *= scale;
        auto lb = _Conv(std::move(Bs), std::vector<float>(COUT, 0.f), la, {R, COUT}, {1, 1}, VALID); lb->setName("lora_b");
        out = _Add(c0, lb);
    }
    out->setName("out");
    return out;
}
static std::vector<float> runModule(Module* m, const std::vector<float>& xin) {
    auto in = _Input({1, CIN, H, W}, NCHW, halide_type_of<float>());
    ::memcpy(in->writeMap<float>(), xin.data(), xin.size() * sizeof(float));
    auto outs = m->onForward({in});
    auto y = _Convert(outs[0], NCHW);
    const float* p = y->readMap<float>();
    return std::vector<float>(p, p + COUT * H * W);
}
static double maxdiff(const std::vector<float>& a, const std::vector<float>& b) {
    double m = 0; for (size_t i = 0; i < a.size(); ++i) m = std::max(m, (double)std::fabs(a[i] - b[i])); return m;
}
int main() {
    std::mt19937 rng(264); std::normal_distribution<float> nd(0.f, 0.5f);
    std::vector<float> W0(COUT * CIN), b0(COUT), A(R * CIN), B(COUT * R), x(CIN * H * W);
    for (auto* v : {&W0, &b0, &A, &B, &x}) for (auto& e : *v) e = nd(rng);
    const float scale = 0.8f;
    // tham chiếu CPU thuần: y = (W0 + scale * B*A) x + b0
    std::vector<float> ref(COUT * H * W);
    for (int o = 0; o < COUT; ++o) for (int p = 0; p < H * W; ++p) {
        double acc = b0[o];
        for (int i = 0; i < CIN; ++i) {
            double w = W0[o * CIN + i]; for (int r = 0; r < R; ++r) w += (double)scale * B[o * R + r] * A[r * CIN + i];
            acc += w * x[i * H * W + p];
        }
        ref[o * H * W + p] = (float)acc;
    }
    std::vector<float> Wm(W0); for (int o = 0; o < COUT; ++o) for (int i = 0; i < CIN; ++i) for (int r = 0; r < R; ++r) Wm[o * CIN + i] += scale * B[o * R + r] * A[r * CIN + i];
    std::vector<float> Z(COUT * CIN, 0.f), Zb(COUT, 0.f);
    Variable::save({buildNet(W0, b0, nullptr, nullptr, 0)}, "base.mnn");
    Variable::save({buildNet(Wm, b0, nullptr, nullptr, 0)}, "merged.mnn");
    Variable::save({buildNet(Z, Zb, &A, &B, scale)}, "lora_zero.mnn");      // conv0 = 0 (garbage): chỉ đúng nếu trọng số nền được chia sẻ
    Variable::save({buildNet(W0, b0, &A, &B, scale)}, "lora_real.mnn");     // đối chứng: conv0 thật
    MNN::ScheduleConfig sc; sc.type = MNN_FORWARD_CPU; sc.numThread = 1; MNN::BackendConfig bc; sc.backendConfig = &bc;
    std::printf("%-34s %-10s %-9s  %s\n", "cấu hình", "shapeMut", "rearrange", "max|y - tham chiếu|");
    for (int sm = 0; sm < 2; ++sm) for (int ra = 0; ra < 2; ++ra) {
        std::shared_ptr<Executor::RuntimeManager> rt(Executor::RuntimeManager::createRuntimeManager(sc));
        Module::Config mc; mc.shapeMutable = sm; mc.rearrange = ra;
        std::shared_ptr<Module> base(Module::load({"x"}, {"out"}, "base.mnn", rt, &mc));
        std::shared_ptr<Module> merged(Module::load({"x"}, {"out"}, "merged.mnn", rt, &mc));
        Module::Config mb = mc; mb.base = base.get();
        std::shared_ptr<Module> zb(Module::load({"x"}, {"out"}, "lora_zero.mnn", rt, &mb));
        std::shared_ptr<Module> rb(Module::load({"x"}, {"out"}, "lora_real.mnn", rt, &mb));
        std::shared_ptr<Module> zn(Module::load({"x"}, {"out"}, "lora_zero.mnn", rt, &mc));
        auto yb = runModule(base.get(), x); (void)yb;   // chạy nền trước (như MNN-LLM)
        std::printf("%-34s %-10d %-9d  %.3e\n", "gộp trọng số (đối chứng)", sm, ra, maxdiff(runModule(merged.get(), x), ref));
        std::printf("%-34s %-10d %-9d  %.3e\n", "tách rời + base, conv0 trong file=0", sm, ra, maxdiff(runModule(zb.get(), x), ref));
        std::printf("%-34s %-10d %-9d  %.3e\n", "tách rời + base, conv0 thật", sm, ra, maxdiff(runModule(rb.get(), x), ref));
        std::printf("%-34s %-10d %-9d  %.3e\n", "tách rời KHÔNG base, conv0=0", sm, ra, maxdiff(runModule(zn.get(), x), ref));
    }
    return 0;
}
