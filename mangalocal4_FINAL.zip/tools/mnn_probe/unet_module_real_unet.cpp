// mục 283 — chạy UnetModuleSet THẬT (sd_engine/UnetModule.hpp) trên UNet diffusers THẬT (thu nhỏ: attn1/attn2, GEGLU, resnet 3x3, time_emb_proj, down/upsample) đã qua
// torch.onnx.export -> mnnconvert -> lora_attach_branch --strip-base-weights; so với đầu ra TORCH đã cộng thẳng W + (alpha/rank)·B·A. Điều khiển bởi tools/real_unet_module_check.py.
//   run <dir>: đọc base.mnn, lora1.lora.mnn, lora2.lora.mnn, sample.bin, enc0/1/2.bin, ref_base/ref1/ref2.bin, meta.txt (ts, h8, w8, hidden_dim)
#include <MNN/expr/Executor.hpp>
#include <MNN/expr/Expr.hpp>
#include <MNN/expr/ExprCreator.hpp>
#include <MNN/expr/Module.hpp>
#include <MNN/expr/NeuralNetWorkOp.hpp>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <string>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>
#include <sys/stat.h>
#include "sd_engine/UnetModule.hpp"
using namespace MNN::Express;
static std::vector<float> rd(const std::string& p) { std::ifstream f(p, std::ios::binary); f.seekg(0, std::ios::end); size_t n = (size_t)f.tellg() / 4; f.seekg(0); std::vector<float> v(n); f.read((char*)v.data(), n * 4); return v; }
static long fsize(const std::string& p) { struct stat st; return stat(p.c_str(), &st) == 0 ? (long)st.st_size : -1; }
static int g_pass = 0, g_fail = 0;
static void check(const std::string& n, bool c, const std::string& d = "") { std::printf("%s %s%s\n", c ? "PASS" : "FAIL", n.c_str(), (!c && !d.empty()) ? (" :: " + d).c_str() : ""); (c ? g_pass : g_fail)++; }
static double md(const std::vector<float>& a, const float* b) { double m = 0; for (size_t i = 0; i < a.size(); ++i) { if (!std::isfinite(b[i])) return 1e30; m = std::max(m, (double)std::fabs(a[i] - b[i])); } return m; }
static std::vector<float> fullRun(const std::string& path, const std::vector<float>& sample, int ts, const std::vector<float>& enc, int H, int W, int Dd, bool& ok) {
    // chạy tệp LoRA ĐẦY ĐỦ (còn trọng số nền, KHÔNG base) bằng Module::load thường — tham chiếu "cùng lượng tử hoá" để chứng minh việc tước trọng số là KHÔNG mất mát
    ok = false; std::vector<float> out;
    MNN::ScheduleConfig sc; sc.type = MNN_FORWARD_CPU; sc.numThread = 2; MNN::BackendConfig bc; bc.memory = MNN::BackendConfig::Memory_Low; bc.power = MNN::BackendConfig::Power_High; sc.backendConfig = &bc;   // cùng cấu hình UnetModuleSet/app (Memory_Low bật lượng tử hoá động kích hoạt với w8)
    std::shared_ptr<Executor::RuntimeManager> rt(Executor::RuntimeManager::createRuntimeManager(sc)); Module::Config mc; mc.shapeMutable = true; mc.rearrange = true;
    std::shared_ptr<Module> m(Module::load({"sample", "timestep", "encoder_hidden_states"}, {"out_sample"}, path.c_str(), rt, &mc)); if (!m) return out;
    auto is = _Input({2, 4, H, W}, NCHW, halide_type_of<float>()); auto it = _Input({1}, NCHW, halide_type_of<int>()); auto ie = _Input({2, 77, Dd}, NCHW, halide_type_of<float>());
    std::memcpy(is->writeMap<float>(), sample.data(), sample.size() * 4); it->writeMap<int>()[0] = ts; std::memcpy(ie->writeMap<float>(), enc.data(), enc.size() * 4);
    auto outs = m->onForward({is, it, ie}); if (outs.empty() || outs[0].get() == nullptr) return out;
    auto y = _Convert(outs[0], NCHW); const float* p = y->readMap<float>(); if (!p) return out;
    out.assign(p, p + (size_t)2 * 4 * H * W); ok = true; return out;
}
static std::string fe(double v) { char b[40]; std::snprintf(b, sizeof b, "%.3e", v); return b; }
int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IOLBF, 0);   // giữ đầu ra nếu một phép kiểm làm tiến trình chết
    if (argc < 3 || std::string(argv[1]) != "run") { std::fprintf(stderr, "run <dir>\n"); return 2; }
    const std::string d = argv[2];
    int ts = 0, h8 = 0, w8 = 0, hd = 0; double tolIn = 5e-4; { std::ifstream m(d + "/meta.txt"); m >> ts >> h8 >> w8 >> hd; if (!(m >> tolIn)) tolIn = 5e-4; }   // dung sai (w8 lớn hơn fp32)
    auto sample = rd(d + "/sample.bin"), e0 = rd(d + "/enc0.bin"), e1 = rd(d + "/enc1.bin"), e2 = rd(d + "/enc2.bin"), rb = rd(d + "/ref_base.bin"), r1 = rd(d + "/ref1.bin"), r2 = rd(d + "/ref2.bin");
    const std::string base = d + "/base.mnn", l1 = d + "/lora1.lora.mnn", l2 = d + "/lora2.lora.mnn";
    std::printf("  [kích thước tệp] nền %ld B | module LoRA 1 %ld B | module LoRA 2 %ld B\n", fsize(base), fsize(l1), fsize(l2));
    check("module LoRA (đã tước trọng số nền) NHỎ hơn UNet nền", fsize(l1) > 0 && fsize(l1) < fsize(base) && fsize(l2) < fsize(base));
    unet_module::UnetModuleSet set; std::string err;
    check("nạp UNet diffusers thật + 2 module LoRA", set.load(base, {l1, l2}, 2, &err) && set.count() == 2, err);
    std::vector<float> o(rb.size());
    check("kích thước tham chiếu = 2·4·h·w", rb.size() == (size_t)2 * 4 * h8 * w8 && r1.size() == rb.size() && r2.size() == rb.size());
    const double tol = tolIn;
    bool a = set.runOne(0, h8, w8, hd, ts, sample.data(), e1.data(), o.data(), &err); double d1 = md(r1, o.data());
    check("runOne(0) = nền + LoRA 1 khớp torch đã gộp W+ΔW (≤ dung sai)", a && d1 <= tol, err + " maxdiff=" + fe(d1));
    bool b = set.runOne(1, h8, w8, hd, ts, sample.data(), e2.data(), o.data(), &err); double d2 = md(r2, o.data());
    check("runOne(1) = nền + LoRA 2 khớp torch đã gộp W+ΔW (≤ dung sai)", b && d2 <= tol, err + " maxdiff=" + fe(d2));
    std::printf("  [số đo] LoRA 1 vs torch: %s | LoRA 2 vs torch: %s (mục 269, đường Interpreter-Python: 6,7e-5)\n", fe(d1).c_str(), fe(d2).c_str());
    { std::ifstream f1(d + "/lora1_full.mnn"); if (f1.good()) {
        bool k1 = false, k2 = false; auto f1o = fullRun(d + "/lora1_full.mnn", sample, ts, e1, h8, w8, hd, k1), f2o = fullRun(d + "/lora2_full.mnn", sample, ts, e2, h8, w8, hd, k2);
        std::vector<float> a(rb.size()), b2(rb.size()); bool r1k = set.runOne(0, h8, w8, hd, ts, sample.data(), e1.data(), a.data(), &err), r2k = set.runOne(1, h8, w8, hd, ts, sample.data(), e2.data(), b2.data(), &err);
        double x1 = k1 && r1k ? md(f1o, a.data()) : 1e30, x2 = k2 && r2k ? md(f2o, b2.data()) : 1e30;
        std::printf("  [số đo] module đã tước + base so với tệp LoRA đầy đủ cùng lượng tử hoá: %s | %s\n", fe(x1).c_str(), fe(x2).c_str());
        check("module ĐÃ TƯỚC + base == tệp LoRA ĐẦY ĐỦ cùng lượng tử hoá (≤ 1e-4): tước KHÔNG mất mát (kể cả w8)", x1 <= 1e-4 && x2 <= 1e-4, fe(x1) + " " + fe(x2)); } }
    double eff = 0; for (size_t i = 0; i < rb.size(); ++i) eff = std::max(eff, (double)std::fabs(r1[i] - rb[i]));
    check("đối chứng độ nhạy: LoRA 1 làm đầu ra torch đổi ≥ 0,05 so với nền", eff >= 0.05, fe(eff));
    set.runOne(0, h8, w8, hd, ts, sample.data(), e1.data(), o.data(), &err); check("kết quả KHÔNG trùng torch NỀN (module thật sự áp LoRA)", md(rb, o.data()) >= 0.05, fe(md(rb, o.data())));
    // step() Composite = blend của hai đầu ra torch
    { unet_module::StepParams p; p.step = 0; p.tau = 5; p.active_count = 2; p.h8 = h8; p.w8 = w8; p.hidden_dim = hd; p.timestep = ts;
      std::vector<float> w = {1.0f, 1.0f}; p.weights = &w; auto act = lora_compose::activeSet(p.step, 2, p.tau, p.active_count);
      std::vector<const float*> pp; for (int i : act) pp.push_back(i == 0 ? r1.data() : r2.data());
      std::vector<float> ex(rb.size()), got(rb.size()); lora_compose::blend(pp, lora_compose::factors(act, w), rb.size(), ex.data());
      std::vector<const float*> encs = {e1.data(), e2.data()};
      check("step() Composite trên UNet thật = blend(torch LoRA 1, torch LoRA 2)", set.step(p, sample.data(), encs, got.data(), &err) && act.size() == 2 && md(ex, got.data()) <= 2 * tol, err + " maxdiff=" + fe(md(ex, got.data()))); }
    // nền là biến thể: biến thể 0 = UNet nền thuần so với torch nền
    { unet_module::UnetModuleSet v; bool ok = v.load(base, {l1, l2}, 2, &err, true);
      check("base_is_variant: biến thể 0 = UNet nền THUẦN khớp torch nền", ok && v.runOne(0, h8, w8, hd, ts, sample.data(), e0.data(), o.data(), &err) && md(rb, o.data()) <= tol, err + " maxdiff=" + fe(md(rb, o.data())));
      check("base_is_variant: biến thể 1/2 = LoRA 1/2", v.runOne(1, h8, w8, hd, ts, sample.data(), e1.data(), o.data(), &err) && md(r1, o.data()) <= tol && v.runOne(2, h8, w8, hd, ts, sample.data(), e2.data(), o.data(), &err) && md(r2, o.data()) <= tol, err); }
    // lần chạy ĐẦU của module LoRA KHÔNG cần khởi động nền (xác nhận suy luận từ mã nguồn ở mục 272, trên MNN 3.6.1 CPU): nạp mới, chạy module 1 ngay
    { unet_module::UnetModuleSet f; bool ok = f.load(base, {l1, l2}, 2, &err);
      check("lần chạy ĐẦU (không khởi động nền): module LoRA 2 đúng ngay", ok && !f.baseRan() && f.runOne(1, h8, w8, hd, ts, sample.data(), e2.data(), o.data(), &err) && md(r2, o.data()) <= tol && !f.baseRan(), err + " maxdiff=" + fe(md(r2, o.data()))); }
    // ĐỐI CHỨNG: module LoRA nạp KHÔNG base không được cho kết quả đúng. Chạy trong TIẾN TRÌNH CON: với w8 MNN 3.6.1 chia cho 0 (SIGFPE) khi tạo execution cho conv đã tước buffer w8 thay vì báo lỗi
    // như fp32 — UnetModuleSet không bao giờ nạp kiểu này (luôn truyền base), nhưng bộ kiểm không được chết theo.
    { fflush(stdout); pid_t pid = fork();
      if (pid == 0) {
        MNN::ScheduleConfig sc; sc.type = MNN_FORWARD_CPU; sc.numThread = 2; MNN::BackendConfig bc; bc.memory = MNN::BackendConfig::Memory_Low; bc.power = MNN::BackendConfig::Power_High; sc.backendConfig = &bc;   // cùng cấu hình UnetModuleSet/app (Memory_Low bật lượng tử hoá động kích hoạt với w8)
        std::shared_ptr<Executor::RuntimeManager> rt(Executor::RuntimeManager::createRuntimeManager(sc)); Module::Config mc; mc.shapeMutable = true; mc.rearrange = true;
        std::shared_ptr<Module> m(Module::load({"sample", "timestep", "encoder_hidden_states"}, {"out_sample"}, l1.c_str(), rt, &mc)); double diff = 1e30;
        if (m) { auto is = _Input({2, 4, h8, w8}, NCHW, halide_type_of<float>()); auto it = _Input({1}, NCHW, halide_type_of<int>()); auto ie = _Input({2, 77, hd}, NCHW, halide_type_of<float>());
          std::memcpy(is->writeMap<float>(), sample.data(), sample.size() * 4); it->writeMap<int>()[0] = ts; std::memcpy(ie->writeMap<float>(), e1.data(), e1.size() * 4);
          auto outs = m->onForward({is, it, ie}); if (!(outs.empty() || outs[0].get() == nullptr)) { auto y = _Convert(outs[0], NCHW); const float* p = y->readMap<float>(); diff = p ? md(r1, p) : 1e30; } }
        _exit(diff > 0.05 ? 0 : 1);   // 0 = "không cho kết quả đúng" (lỗi thực thi hoặc sai)
      }
      int st = 0; waitpid(pid, &st, 0);
      bool crashed = WIFSIGNALED(st), wrong = WIFEXITED(st) && WEXITSTATUS(st) == 0;
      std::printf("  [số đo] module nạp KHÔNG base: %s\n", crashed ? ("tiến trình con CHẾT bởi tín hiệu " + std::to_string(WTERMSIG(st)) + " (MNN không xử lý được — chấp nhận cho đối chứng)").c_str() : (wrong ? "không cho kết quả đúng (lỗi thực thi hoặc sai)" : "CHO KẾT QUẢ ĐÚNG (!)"));
      check("ĐỐI CHỨNG: module LoRA nạp KHÔNG base không cho kết quả đúng (lỗi thực thi, sai, hoặc MNN chết)", crashed || wrong); }
    std::printf("RESULT pass=%d fail=%d\n", g_pass, g_fail);
    return g_fail == 0 ? 0 : 1;
}
