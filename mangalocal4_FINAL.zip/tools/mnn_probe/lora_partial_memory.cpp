// mục 283 — ĐO RAM THẬT (RSS) khi module LoRA chỉ gắn nhánh vào MỘT PHẦN conv (đúng tình huống LoRA kohya: thường chỉ Linear/conv 1x1 của khối transformer, KHÔNG gồm conv 3x3 của resnet).
// `lora_attach_branch --strip-base-weights` chỉ tước trọng số của conv CÓ nhánh (dòng `if (branch && opt.stripBase)`); conv KHÔNG nhánh vẫn mang trọng số trong tệp module.
// Câu hỏi: Module::Config::base + rearrange có CHIA SẺ trọng số của conv không-nhánh với nền, hay module nạp thêm một bản sao vào RAM?
//   gen <dir> : N conv 3x3 lớn (C kênh) c0..c{N-1}; spec CHỈ cho c0
//   run <dir> <base|nobase> : đo RSS sau: nền nạp+chạy, module nạp, module chạy
#include <MNN/expr/Executor.hpp>
#include <MNN/expr/Expr.hpp>
#include <MNN/expr/ExprCreator.hpp>
#include <MNN/expr/Module.hpp>
#include <MNN/expr/NeuralNetWorkOp.hpp>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <random>
#include <string>
#include <vector>
#include <sys/stat.h>
#ifdef __GLIBC__
#include <malloc.h>
#endif
using namespace MNN::Express;
static const int C = 768, N = 4, HW = 4;
static double rssMB() { std::ifstream f("/proc/self/status"); std::string l; while (std::getline(f, l)) if (l.rfind("VmRSS:", 0) == 0) return std::stod(l.substr(6)) / 1024.0; return -1; }
static long fsize(const std::string& p) { struct stat st; return stat(p.c_str(), &st) == 0 ? (long)st.st_size : -1; }
static VARP net() {
    std::mt19937 g(5); std::normal_distribution<float> nd(0.f, 0.02f);
    auto x = _Input({1, C, HW, HW}, NCHW, halide_type_of<float>()); x->setName("x"); VARP cur = x;
    for (int i = 0; i < N; ++i) { std::vector<float> w((size_t)C * C * 9), b(C); for (auto& v : w) v = nd(g); for (auto& v : b) v = nd(g);
        cur = _Conv(std::move(w), std::move(b), cur, {C, C}, {3, 3}, SAME); cur->setName("c" + std::to_string(i)); }
    return cur;
}
static void wf(const std::string& p, const std::vector<float>& v) { std::ofstream f(p, std::ios::binary); f.write((const char*)v.data(), v.size() * 4); }
int main(int argc, char** argv) {
    std::string mode = argc > 1 ? argv[1] : "", d = argc > 2 ? argv[2] : ".";
    // run <dir> <base|nobase> [tên_vào [tên_ra]]: mặc định x/c3 (mô hình do `gen` tạo); đặt tên khác để đo trên mô hình từ ONNX/mnnconvert (vd. w8)
    const std::string inName = argc > 4 ? argv[4] : "x", outName = argc > 5 ? argv[5] : "c3";
    if (mode == "gen") {
        Variable::save({net()}, (d + "/base.mnn").c_str());
        std::mt19937 g(9); std::normal_distribution<float> nd(0.f, 0.05f); int r = 4;
        std::vector<float> A((size_t)r * C * 9), B((size_t)C * r); for (auto& v : A) v = nd(g); for (auto& v : B) v = nd(g); wf(d + "/A.bin", A); wf(d + "/B.bin", B);
        std::ofstream(d + "/spec.txt") << "c0 4 1.0 " << d << "/A.bin " << d << "/B.bin\n"; std::printf("gen ok\n"); return 0;
    }
    bool useBase = std::string(argc > 3 ? argv[3] : "base") == "base";
    std::printf("RSS khởi đầu: %.1f MB (mỗi conv 3x3 %dx%d = %.1f MB float32)\n", rssMB(), C, C, (double)C * C * 9 * 4 / 1048576.0);
    std::printf("tệp: nền %ld B | module %ld B\n", fsize(d + "/base.mnn"), fsize(d + "/lora.lora.mnn"));
    MNN::ScheduleConfig sc; sc.type = MNN_FORWARD_CPU; sc.numThread = 2; MNN::BackendConfig bc; bc.memory = MNN::BackendConfig::Memory_Low; sc.backendConfig = &bc;
    std::shared_ptr<Executor::RuntimeManager> rt(Executor::RuntimeManager::createRuntimeManager(sc));
    Module::Config mc; mc.shapeMutable = true; mc.rearrange = true;
    double r0 = rssMB();
    std::shared_ptr<Module> base(Module::load({inName}, {outName}, (d + "/base.mnn").c_str(), rt, &mc));
    auto in = _Input({1, C, HW, HW}, NCHW, halide_type_of<float>()); std::memset(in->writeMap<float>(), 0, (size_t)C * HW * HW * 4);
    double r1 = rssMB(); { auto o = base->onForward({in}); auto t = _Convert(o[0], NCHW); (void)t->readMap<float>(); } double r2 = rssMB();
    std::printf("RSS: nạp nền %+.1f MB | chạy nền %+.1f MB  (nền cộng dồn: %.1f MB)\n", r1 - r0, r2 - r1, r2 - r0);
    Module::Config mb = mc; if (useBase) mb.base = base.get();
    double r3 = rssMB();
    std::shared_ptr<Module> lora(Module::load({inName}, {outName}, (d + "/lora.lora.mnn").c_str(), rt, &mb));
    double r4 = rssMB(); std::printf("RSS: nạp module (%s) %+.1f MB\n", useBase ? "có base" : "KHÔNG base", r4 - r3);
#ifdef __GLIBC__
    malloc_trim(0);   // trả lại trang rảnh cho hệ điều hành: phân biệt bộ đệm TẠM (đã giải phóng) với trọng số GIỮ LẠI thật
    double r4t = rssMB(); std::printf("RSS: sau malloc_trim(0) — nạp module còn lại %+.1f MB (phần giữ lại thật)\n", r4t - r3); r4 = r4t;
#endif
    if (lora) { auto o = lora->onForward({in}); if (!o.empty() && o[0].get()) { auto t = _Convert(o[0], NCHW); (void)t->readMap<float>(); } }
    double r5 = rssMB(); std::printf("RSS: chạy module %+.1f MB | module cộng dồn %+.1f MB | TỔNG so với trước khi nạp nền %+.1f MB\n", r5 - r4, r5 - r3, r5 - r0);
    return 0;
}
