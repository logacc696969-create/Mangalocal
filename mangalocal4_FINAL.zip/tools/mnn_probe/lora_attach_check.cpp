// mục 265 — chương trình thử cho tools/mnn_probe/lora_attach_branch.cpp (đồ thị MNN THẬT, không cần file model).
//   gen <thư_mục>   : sinh base.mnn, base_zero.mnn (cùng tên op, trọng số 0), các file A/B, spec, đầu vào và đầu ra tham chiếu TÍNH BẰNG CPU THUẦN
//   run <lora.mnn> <x.bin> <ref.bin> <shapeMutable> <rearrange> <base.mnn|->  : nạp module (có/không base) và in max|y - tham chiếu|
// Mạng đồ chơi (đủ các tình huống khó của UNet):
//   x -> c0 (1x1, 16->32) -+-> c1 (3x3 SAME, 32->32, relu GỘP sẵn) -> res = c1 + c0 -> out (1x1, 32->24)
//   * c0 có HAI chỗ dùng (c1 và res) -> kiểm việc đổi mọi chỗ dùng sang đầu ra ADD;
//   * c1 là conv 3x3 và có relu gộp -> kiểm LoRA-conv và việc tách hoạt hoá;
//   * "out" là đầu ra mạng -> kiểm tên đầu ra giữ nguyên.
#include <MNN/expr/Expr.hpp>
#include <MNN/expr/ExprCreator.hpp>
#include <MNN/expr/Module.hpp>
#include <MNN/expr/Executor.hpp>
#include <MNN/expr/NeuralNetWorkOp.hpp>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <random>
#include <string>
#include <vector>
using namespace MNN::Express;
static const int CIN = 16, CM = 32, COUT = 24, H = 8, W = 8;

struct Weights { std::vector<float> w0, b0, w1, b1, w2, b2; };

static VARP buildNet(const Weights& w) {
    auto x = _Input({1, CIN, H, W}, NCHW, halide_type_of<float>()); x->setName("x");
    auto c0 = _Conv(std::vector<float>(w.w0), std::vector<float>(w.b0), x, {CIN, CM}, {1, 1}, VALID); c0->setName("c0");
    auto c1 = _Conv(std::vector<float>(w.w1), std::vector<float>(w.b1), c0, {CM, CM}, {3, 3}, SAME, {1, 1}, {1, 1}, 1, {0, 0}, true, false); c1->setName("c1");
    auto res = _Add(c1, c0); res->setName("res");
    auto out = _Conv(std::vector<float>(w.w2), std::vector<float>(w.b2), res, {CM, COUT}, {1, 1}, VALID); out->setName("out");
    return out;
}

static std::vector<float> convRef(const std::vector<float>& in, int cin, int cout, int k, const std::vector<float>& w, const std::vector<float>& b, bool relu) {
    std::vector<float> o((size_t)cout * H * W);
    int pad = k / 2;
    for (int oc = 0; oc < cout; ++oc) for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) {
        double acc = b[oc];
        for (int ic = 0; ic < cin; ++ic) for (int ky = 0; ky < k; ++ky) for (int kx = 0; kx < k; ++kx) {
            int iy = y + ky - pad, ix = x + kx - pad;
            if (iy < 0 || iy >= H || ix < 0 || ix >= W) continue;
            acc += (double)w[(((size_t)oc * cin + ic) * k + ky) * k + kx] * in[((size_t)ic * H + iy) * W + ix];
        }
        float v = (float)acc; if (relu && v < 0) v = 0;
        o[((size_t)oc * H + y) * W + x] = v;
    }
    return o;
}
static std::vector<float> forwardRef(const std::vector<float>& x, const Weights& w) {
    auto y0 = convRef(x, CIN, CM, 1, w.w0, w.b0, false);
    auto y1 = convRef(y0, CM, CM, 3, w.w1, w.b1, true);
    for (size_t i = 0; i < y1.size(); ++i) y1[i] += y0[i];
    return convRef(y1, CM, COUT, 1, w.w2, w.b2, false);
}
static void writeFloats(const std::string& p, const std::vector<float>& v) { std::ofstream f(p, std::ios::binary); f.write((const char*)v.data(), v.size() * sizeof(float)); }
static std::vector<float> readFloats(const std::string& p) {
    std::ifstream f(p, std::ios::binary); f.seekg(0, std::ios::end); size_t n = (size_t)f.tellg() / sizeof(float); f.seekg(0);
    std::vector<float> v(n); f.read((char*)v.data(), n * sizeof(float)); return v;
}
// W += s * B*A   (A: [r][in*kk], B: [out][r])
static void merge(std::vector<float>& w, const std::vector<float>& A, const std::vector<float>& B, int r, int in_kk, int out, float s) {
    for (int o = 0; o < out; ++o) for (int r_ = 0; r_ < r; ++r_) for (int j = 0; j < in_kk; ++j) w[(size_t)o * in_kk + j] += s * B[(size_t)o * r + r_] * A[(size_t)r_ * in_kk + j];
}

static int gen(const std::string& d) {
    std::mt19937 rng(265); std::normal_distribution<float> nd(0.f, 0.3f);
    auto rnd = [&](size_t n) { std::vector<float> v(n); for (auto& e : v) e = nd(rng); return v; };
    Weights base{rnd((size_t)CM * CIN), rnd(CM), rnd((size_t)CM * CM * 9), rnd(CM), rnd((size_t)COUT * CM), rnd(COUT)};
    const int r0 = 4, r1 = 3, r2 = 2; const float s0 = 0.7f, s1 = 0.5f, s2 = 1.3f;
    auto A0 = rnd((size_t)r0 * CIN), B0 = rnd((size_t)CM * r0);
    auto A1 = rnd((size_t)r1 * CM * 9), B1 = rnd((size_t)CM * r1);
    auto A2 = rnd((size_t)r2 * CM), B2 = rnd((size_t)COUT * r2);
    auto x = rnd((size_t)CIN * H * W);
    writeFloats(d + "/A0.bin", A0); writeFloats(d + "/B0.bin", B0); writeFloats(d + "/A1.bin", A1); writeFloats(d + "/B1.bin", B1);
    writeFloats(d + "/A2.bin", A2); writeFloats(d + "/B2.bin", B2); writeFloats(d + "/x.bin", x);
    Weights full = base, c0c2 = base;
    merge(full.w0, A0, B0, r0, CIN, CM, s0); merge(full.w1, A1, B1, r1, CM * 9, CM, s1); merge(full.w2, A2, B2, r2, CM, COUT, s2);
    merge(c0c2.w0, A0, B0, r0, CIN, CM, s0); merge(c0c2.w2, A2, B2, r2, CM, COUT, s2);
    writeFloats(d + "/ref_base.bin", forwardRef(x, base)); writeFloats(d + "/ref_full.bin", forwardRef(x, full)); writeFloats(d + "/ref_c0c2.bin", forwardRef(x, c0c2));
    Weights zero{std::vector<float>(base.w0.size(), 0.f), std::vector<float>(base.b0.size(), 0.f), std::vector<float>(base.w1.size(), 0.f),
                 std::vector<float>(base.b1.size(), 0.f), std::vector<float>(base.w2.size(), 0.f), std::vector<float>(base.b2.size(), 0.f)};
    Variable::save({buildNet(base)}, (d + "/base.mnn").c_str());
    Variable::save({buildNet(zero)}, (d + "/base_zero.mnn").c_str());
    Variable::save({buildNet(full)}, (d + "/merged_full.mnn").c_str());
    {   // đồ thị có conv NHÓM (group=2) — công cụ phải từ chối
        auto gx = _Input({1, CIN, H, W}, NCHW, halide_type_of<float>()); gx->setName("x");
        auto g0 = _Conv(rnd((size_t)CIN * (CIN / 2) * 9), rnd(CIN), gx, {CIN, CIN}, {3, 3}, SAME, {1, 1}, {1, 1}, 2, {0, 0}, false, false); g0->setName("g0");
        Variable::save({g0}, (d + "/base_group.mnn").c_str());
    }
    std::ofstream sp1(d + "/spec_full.txt");
    sp1 << "# đủ ba nhánh\nc0 4 0.7 " << d << "/A0.bin " << d << "/B0.bin\nc1 3 0.5 " << d << "/A1.bin " << d << "/B1.bin\nout 2 1.3 " << d << "/A2.bin " << d << "/B2.bin\n";
    std::ofstream sp2(d + "/spec_c0c2.txt");
    sp2 << "c0 4 0.7 " << d << "/A0.bin " << d << "/B0.bin\nout 2 1.3 " << d << "/A2.bin " << d << "/B2.bin\n";
    std::ofstream sp4(d + "/spec_group.txt");
    sp4 << "g0 2 1.0 " << d << "/A0.bin " << d << "/B0.bin\n";
    std::ofstream sp3(d + "/spec_c1_only.txt");
    sp3 << "c1 3 0.5 " << d << "/A1.bin " << d << "/B1.bin\n";
    std::printf("gen ok\n");
    return 0;
}

static int run(int argc, char** argv) {
    if (argc < 8) { std::fprintf(stderr, "run <lora.mnn> <x.bin> <ref.bin> <shapeMutable> <rearrange> <base.mnn|->\n"); return 2; }
    std::string lora = argv[2], xb = argv[3], rb = argv[4], basef = argv[7];
    MNN::ScheduleConfig sc; sc.type = MNN_FORWARD_CPU; sc.numThread = 1; MNN::BackendConfig bc; sc.backendConfig = &bc;
    std::shared_ptr<Executor::RuntimeManager> rt(Executor::RuntimeManager::createRuntimeManager(sc));
    Module::Config mc; mc.shapeMutable = std::atoi(argv[5]) != 0; mc.rearrange = std::atoi(argv[6]) != 0;
    std::shared_ptr<Module> base;
    if (basef != "-") {
        base.reset(Module::load({"x"}, {"out"}, basef.c_str(), rt, &mc));
        if (!base) { std::printf("load_base=FAIL\n"); return 3; }
        mc.base = base.get();
    }
    std::shared_ptr<Module> m(Module::load({"x"}, {"out"}, lora.c_str(), rt, &mc));
    if (!m) { std::printf("load=FAIL\n"); return 3; }
    auto x = readFloats(xb), ref = readFloats(rb);
    auto in = _Input({1, CIN, H, W}, NCHW, halide_type_of<float>());
    std::memcpy(in->writeMap<float>(), x.data(), x.size() * sizeof(float));
    if (base) { auto yb = base->onForward({in}); auto t = _Convert(yb[0], NCHW); (void)t->readMap<float>(); }   // chạy nền trước (như MNN-LLM)
    auto outs = m->onForward({in});
    if (outs.empty()) { std::printf("forward=FAIL\n"); return 3; }
    auto y = _Convert(outs[0], NCHW);
    const float* p = y->readMap<float>();
    if (!p) { std::printf("forward=FAIL\n"); return 3; }
    double md = 0; bool nan = false;
    for (size_t i = 0; i < ref.size(); ++i) { if (!std::isfinite(p[i])) nan = true; md = std::max(md, (double)std::fabs(p[i] - ref[i])); }
    std::printf("maxdiff=%.3e nan=%d\n", md, nan ? 1 : 0);
    return 0;
}

int main(int argc, char** argv) {
    if (argc >= 3 && std::string(argv[1]) == "gen") return gen(argv[2]);
    if (argc >= 2 && std::string(argv[1]) == "run") return run(argc, argv);
    std::fprintf(stderr, "gen <dir> | run ...\n");
    return 2;
}
