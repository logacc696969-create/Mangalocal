# Thực nghiệm MNN: LoRA tách rời qua `Module::Config::base` (mục 264) và công cụ gắn nhánh LoRA (mục 265)

Hai chương trình nhỏ dùng MNN Express thật (không cần model). Chạy qua `tools/test_mnn_lora_split.py` (tự BỎ QUA nếu không có bản build MNN).

- `lora_split_equivalence.cpp`: nhánh LoRA `conv_A -> conv_B -> ADD` có bằng bản gộp trọng số không, và `config.base` có chia sẻ trọng số nền không
  (conv0 trong file LoRA cố ý đặt = 0: nếu sharing hoạt động thì kết quả vẫn đúng).
- `lora_split_memory.cpp`: RAM thêm của mỗi module LoRA khi có/không có `base`, `rearrange` true/false.

Dựng MNN (CPU, tĩnh, ~15 phút trên 1 lõi):
```
pip install cmake ninja
cmake -G Ninja <MNN-3.6.1> -DCMAKE_BUILD_TYPE=Release -DCMAKE_POLICY_VERSION_MINIMUM=3.5 -DMNN_BUILD_SHARED_LIBS=OFF -DMNN_BUILD_TOOLS=OFF \
  -DMNN_BUILD_DEMO=OFF -DMNN_BUILD_TEST=OFF -DMNN_BUILD_CONVERTER=OFF -DMNN_BUILD_BENCHMARK=OFF -DMNN_BUILD_QUANTOOLS=OFF -DMNN_AVX512=OFF \
  -DMNN_BUILD_LLM=OFF -DMNN_BUILD_DIFFUSION=OFF -DMNN_SEP_BUILD=OFF -DMNN_OPENCL=OFF -DMNN_VULKAN=OFF -DMNN_OPENGL=OFF -DMNN_METAL=OFF -DMNN_CUDA=OFF
ninja
export MNN_SRC=<MNN-3.6.1>  MNN_LIB=<build>/libMNN.a
```
Biên dịch tay: `g++ -std=c++17 -O1 X.cpp -I$MNN_SRC/include -Wl,--whole-archive $MNN_LIB -Wl,--no-whole-archive -lpthread -ldl`
(cần `--whole-archive` vì các op đăng ký bằng static initializer).

## Công cụ gắn nhánh LoRA (mục 265)
- `lora_attach_branch.cpp`: gắn `conv_A -> conv_B -> ADD` vào đồ thị MNN ở mức NetT (không đụng trọng số nền). `--list base.mnn` để xem conv; chạy không đối số để xem cách dùng. Xem đầu file về quy ước tên và BẪY relu gộp (`--emit-base`).
- `lora_attach_check.cpp`: sinh mô hình đồ chơi + tham chiếu CPU thuần, chạy module. Điều phối bởi `tools/test_mnn_lora_attach.py` (có phép thử phá mã; tự BỎ QUA nếu không có bản build MNN).
- Biên dịch công cụ cần thêm đường dẫn schema và flatbuffers: `-I $MNN_SRC/schema/current -I $MNN_SRC/3rd_party/flatbuffers/include` (ngoài `-I $MNN_SRC/include`).

## Module LoRA trong ứng dụng (mục 270)

`app/src/main/jni/sd_engine/UnetModule.hpp` chạy các module `*.lora.mnn` do `lora_attach_branch --strip-base-weights` tạo, bằng chính những lời gọi đã chạy thật trong `lora_split_equivalence.cpp` (`Module::Config{shapeMutable=true, rearrange=true, base}` + `Module::load` + `onForward`). Mặc định KHÔNG biên dịch; bật bằng workflow input `enable_lora_module` (hoặc `-Pmangalocal.enableLoraModule=true`). Tên file phải kết thúc bằng `.lora.mnn` — native nhận ra từ đuôi tên trong `extra_unets`. Nền phải là checkpoint THUẦN (không LoRA nhân vật). Kiểm logic bằng `tools/test_unet_module.py` (MNN giả — không chứng minh gì về MNN thật).
