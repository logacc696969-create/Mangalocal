// mục 265 TECHNICAL_STATUS.md — công cụ GẮN NHÁNH LoRA vào đồ thị MNN (bước (a) của mục 264.3), ở mức NetT (flatbuffers object API),
// cùng hướng với transformers/llm/export/utils/lora.py của MNN (đã đọc ở mục 264.5): với mỗi Convolution mục tiêu chèn
//     conv_A (A: r x in x kh x kw)  ->  conv_B (scale*B: out x r x 1 x 1)  ->  ADD với đầu ra conv gốc
// rồi đổi mọi nơi dùng đầu ra conv gốc sang đầu ra của ADD. Trọng số nền KHÔNG bị đụng tới (kể cả trọng số ngoài `external`).
//
// Dùng:
//   lora_attach_branch --list base.mnn                       liệt kê op Convolution (tên, kênh, kernel, nhóm, cờ) để lập bản đồ khoá LoRA -> tên op
//   lora_attach_branch base.mnn spec.txt out.mnn [--unfuse-activation] [--strip-base-weights] [--emit-base nền_tương_ứng.mnn]
// spec.txt, mỗi dòng (bỏ qua dòng trống và dòng bắt đầu bằng #):   <tên op | tên tensor đầu ra>  <rank>  <scale>  <A.bin>  <B.bin>
//   A.bin = float32 little-endian, r*in*kh*kw phần tử (thứ tự [r][in][kh][kw]); B.bin = out*r phần tử (thứ tự [out][r]).
//   scale = alpha/rank (nhân vào B ở đây, đúng như bản gộp trọng số: W' = W + scale*B*A).
//
// Quy ước đặt tên (QUAN TRỌNG): Module::Config::base khớp execution nền theo bộ ba (TÊN op, loại op, loại tham số) — đã đọc ở
// express/module/StaticModule.cpp (makeExecutionCacheKey). Vì vậy (1) công cụ giữ NGUYÊN tên các op nền; (2) op mới có tên duy nhất
// "lora::<tên op>::A|B|add|act" để không bao giờ trùng tên op nền (trùng tên sẽ nhân bản nhầm execution).
// Tensor: đầu ra ADD mang LẠI tên gốc của đầu ra conv (nên tên đầu ra mạng/tham chiếu theo tên vẫn đúng), đầu ra conv gốc đổi thành "<tên>/lora_base".
//
// BẪY ĐÃ ĐO (mục 265): với Module::Config::base, execution của conv nền được NHÂN BẢN theo tên op — kể cả hoạt hoá gộp (relu/relu6) của conv NỀN.
// Nếu conv nền có relu gộp, file LoRA phải tách relu ra khỏi conv (cộng nhánh TRƯỚC relu) nhưng execution nhân bản vẫn có relu bên trong -> relu áp hai lần/sai chỗ.
// Giải: dùng --emit-base để xuất đồ thị nền đã tách relu tương ứng và nạp module NỀN từ file đó. Conv không có hoạt hoá gộp (trường hợp thường gặp ở UNet SD:
// SiLU đứng sau GroupNorm chứ không gộp vào conv) không bị ảnh hưởng.
//
// GIỚI HẠN: chỉ OpType_Convolution (group = 1, không symmetricQuan/ConvInt8). Linear của transformer nếu bị chuyển thành MatMul/InnerProduct
// (thay vì Convolution 1x1) sẽ bị TỪ CHỐI kèm lý do — chưa biết UNet thật của dự án thuộc dạng nào (cần chạy --list trên unet.mnn thật).
// Conv kích thước 3x3: nhánh A dùng cùng kernel/stride/pad/dilate với conv gốc, B là 1x1 (đúng dạng LoRA-conv của kohya/diffusers).
// Chỉ kiểm trên mô hình đồ chơi (xem tools/test_mnn_lora_attach.py); CHƯA thử trên UNet thật.
#include "MNN_generated.h"
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <map>
#include <memory>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace MNN;

static bool readFile(const std::string& path, std::vector<char>& out) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    f.seekg(0, std::ios::end); size_t n = (size_t)f.tellg(); f.seekg(0);
    out.resize(n);
    if (n) f.read(out.data(), (std::streamsize)n);
    return (bool)f;
}
static bool readFloats(const std::string& path, size_t count, std::vector<float>& out, std::string& err) {
    std::vector<char> raw;
    if (!readFile(path, raw)) { err = "không đọc được " + path; return false; }
    if (raw.size() != count * sizeof(float)) {
        err = path + ": " + std::to_string(raw.size()) + " byte, cần " + std::to_string(count * sizeof(float)) + " (" + std::to_string(count) + " float32)";
        return false;
    }
    out.resize(count);
    std::memcpy(out.data(), raw.data(), raw.size());
    return true;
}

struct Spec { std::string target; int rank = 0; float scale = 1.f; std::string aPath, bPath; int line = 0; };

static bool parseSpec(const std::string& path, std::vector<Spec>& out, std::string& err) {
    std::ifstream f(path);
    if (!f) { err = "không đọc được spec " + path; return false; }
    std::string line; int ln = 0;
    while (std::getline(f, line)) {
        ++ln;
        size_t h = line.find('#'); if (h != std::string::npos) line.resize(h);
        std::istringstream is(line);
        Spec s; s.line = ln;
        if (!(is >> s.target)) continue;   // dòng trống
        if (!(is >> s.rank >> s.scale >> s.aPath >> s.bPath)) { err = "spec dòng " + std::to_string(ln) + ": cần <target> <rank> <scale> <A.bin> <B.bin>"; return false; }
        std::string extra; if (is >> extra) { err = "spec dòng " + std::to_string(ln) + ": thừa trường '" + extra + "'"; return false; }
        if (s.rank <= 0) { err = "spec dòng " + std::to_string(ln) + ": rank phải > 0"; return false; }
        if (!std::isfinite(s.scale)) { err = "spec dòng " + std::to_string(ln) + ": scale không hữu hạn"; return false; }
        out.push_back(s);
    }
    return true;
}

static std::string tensorNameOf(const NetT& net, int idx) {
    return (idx >= 0 && idx < (int)net.tensorName.size()) ? net.tensorName[idx] : std::string("?");
}

// tìm op theo TÊN OP; chỉ khi không op nào mang tên đó mới thử tên tensor đầu ra (sau khi gắn nhánh, tên gốc của đầu ra conv chuyển sang đầu ra ADD
// nên tên tensor có thể trùng tên op conv — ưu tiên tên op để tên đó luôn chỉ về đúng conv). Trùng nhiều op -> báo lỗi (không đoán).
static int findOp(const NetT& net, const std::string& target, std::string& err) {
    int found = -1, hits = 0;
    for (int i = 0; i < (int)net.oplists.size(); ++i) if (net.oplists[i]->name == target) { if (found < 0) found = i; ++hits; }
    if (hits == 0) {
        for (int i = 0; i < (int)net.oplists.size(); ++i)
            for (int o : net.oplists[i]->outputIndexes) if (tensorNameOf(net, o) == target) { if (found < 0 || found != i) { if (found < 0) found = i; ++hits; } break; }
    }
    if (hits == 0) { err = "không có op/tensor tên '" + target + "'"; return -1; }
    if (hits > 1) { err = "'" + target + "' khớp " + std::to_string(hits) + " op — không rõ chọn op nào"; return -1; }
    return found;
}

static int addTensor(NetT& net, const std::string& name) {
    net.tensorName.push_back(name);
    net.tensorNumber = (int)net.tensorName.size();
    return (int)net.tensorName.size() - 1;
}

static std::unique_ptr<OpT> makeConv(const std::string& name, int in, int out, int inIdx, int outIdx, const Convolution2DCommonT& like,
                                     bool likeGeometry, std::vector<float> weight, MNN_DATA_FORMAT fmt) {
    std::unique_ptr<OpT> op(new OpT);
    op->name = name; op->type = OpType_Convolution; op->defaultDimentionFormat = fmt;
    op->inputIndexes = {inIdx}; op->outputIndexes = {outIdx};
    std::unique_ptr<Convolution2DT> cv(new Convolution2DT);
    cv->common.reset(new Convolution2DCommonT);
    auto& c = *cv->common;
    c.inputCount = in; c.outputCount = out; c.group = 1; c.relu = false; c.relu6 = false; c.hasOutputShape = false;
    if (likeGeometry) {   // nhánh A: cùng hình học với conv gốc
        c.kernelX = like.kernelX; c.kernelY = like.kernelY; c.strideX = like.strideX; c.strideY = like.strideY;
        c.dilateX = like.dilateX; c.dilateY = like.dilateY; c.padX = like.padX; c.padY = like.padY;
        c.padMode = like.padMode; c.pads = like.pads;
    } else {              // nhánh B: 1x1
        c.kernelX = c.kernelY = 1; c.strideX = c.strideY = 1; c.dilateX = c.dilateY = 1; c.padX = c.padY = 0;
        c.padMode = PadMode_VALID;
    }
    cv->weight = std::move(weight);
    cv->bias.assign(out, 0.f);
    op->main.type = OpParameter_Convolution2D;
    op->main.value = cv.release();
    return op;
}

static std::string describeConv(const OpT& op) {
    const auto* cv = op.main.AsConvolution2D();
    if (!cv || !cv->common) return "(không có tham số)";
    const auto& c = *cv->common;
    std::ostringstream s;
    s << "in=" << c.inputCount << " out=" << c.outputCount << " k=" << c.kernelY << "x" << c.kernelX << " group=" << c.group;
    if (c.relu) s << " relu"; if (c.relu6) s << " relu6";
    if (cv->quanParameter) s << " quant(w8/..)";
    if (cv->symmetricQuan) s << " symmetricQuan";
    if (!cv->external.empty()) s << " external-weight";
    if (cv->weight.empty() && cv->external.empty() && !cv->quanParameter) s << " (trọng số rỗng)";
    return s.str();
}

static int listOps(const NetT& net) {
    int n = 0;
    for (int i = 0; i < (int)net.oplists.size(); ++i) {
        const OpT& op = *net.oplists[i];
        if (op.type != OpType_Convolution && op.type != OpType_ConvolutionDepthwise && op.type != OpType_ConvInt8 &&
            op.type != OpType_MatMul && op.type != OpType_InnerProduct) continue;
        std::string outName = op.outputIndexes.empty() ? "?" : tensorNameOf(net, op.outputIndexes[0]);
        std::printf("%4d  %-18s name=%s  out=%s  %s\n", i, EnumNameOpType(op.type), op.name.c_str(), outName.c_str(),
                    op.type == OpType_Convolution ? describeConv(op).c_str() : "(KHÔNG hỗ trợ gắn nhánh)");
        ++n;
    }
    std::printf("-- %d op (Convolution/Depthwise/ConvInt8/MatMul/InnerProduct) trong %d op\n", n, (int)net.oplists.size());
    return 0;
}

struct Options { bool unfuse = false; bool stripBase = false; std::string emitBase; };

static bool attach(NetT& net, const Spec& s, const Options& opt, std::string& err, bool branch = true) {
    int pos = findOp(net, s.target, err);
    if (pos < 0) return false;
    OpT* conv = net.oplists[pos].get();
    if (conv->type != OpType_Convolution) {
        err = std::string("'") + s.target + "' là " + EnumNameOpType(conv->type) + ", công cụ chỉ gắn được vào OpType_Convolution (xem --list)";
        return false;
    }
    auto* cv = conv->main.AsConvolution2D();
    if (!cv || !cv->common) { err = "'" + s.target + "' thiếu tham số Convolution2D"; return false; }
    Convolution2DCommonT& c = *cv->common;
    if (c.group != 1) { err = "'" + s.target + "': group=" + std::to_string(c.group) + " (conv nhóm/depthwise) — không hỗ trợ"; return false; }
    if (cv->symmetricQuan) { err = "'" + s.target + "': conv lượng tử hoá int8 đầy đủ (symmetricQuan) — không hỗ trợ"; return false; }
    if (conv->inputIndexes.empty() || conv->outputIndexes.size() != 1) { err = "'" + s.target + "': số đầu vào/ra bất thường"; return false; }
    const bool fused = c.relu || c.relu6;
    if (!branch && !fused) return true;   // --emit-base: conv không có hoạt hoá gộp thì đồ thị nền giữ nguyên
    if (fused && !opt.unfuse && branch) {
        err = "'" + s.target + "': conv có hoạt hoá gộp sẵn (" + std::string(c.relu ? "relu" : "relu6") +
              ") nên nhánh LoRA phải cộng TRƯỚC hoạt hoá — dùng --unfuse-activation để tách hoạt hoá thành op riêng";
        return false;
    }
    const int in = c.inputCount, out = c.outputCount, kk = c.kernelX * c.kernelY;
    if (in <= 0 || out <= 0 || kk <= 0) { err = "'" + s.target + "': kích thước conv không hợp lệ (in/out/kernel)"; return false; }
    std::vector<float> A, B;
    if (branch && !readFloats(s.aPath, (size_t)s.rank * in * kk, A, err)) { err = "'" + s.target + "' A: " + err; return false; }
    if (branch && !readFloats(s.bPath, (size_t)out * s.rank, B, err)) { err = "'" + s.target + "' B: " + err; return false; }
    for (float v : A) if (!std::isfinite(v)) { err = "'" + s.target + "': A chứa NaN/Inf"; return false; }
    for (float& v : B) { if (!std::isfinite(v)) { err = "'" + s.target + "': B chứa NaN/Inf"; return false; } v *= s.scale; }

    const std::string base = conv->name;
    const std::string nA = "lora::" + base + "::A", nB = "lora::" + base + "::B", nAdd = "lora::" + base + "::add", nAct = "lora::" + base + "::act";
    for (const auto& o : net.oplists) if (o->name == nA || o->name == nB || o->name == nAdd || o->name == nAct) { err = "'" + s.target + "': đã gắn nhánh (tên op lora::... đã có)"; return false; }

    const int convIn = conv->inputIndexes[0], convOut = conv->outputIndexes[0];
    const std::string origName = tensorNameOf(net, convOut);
    const MNN_DATA_FORMAT fmt = conv->defaultDimentionFormat;
    const bool wasRelu = c.relu;

    // tensor mới. Tên gốc chuyển sang đầu ra CUỐI (ADD, hoặc ACT nếu có tách hoạt hoá); đầu ra conv gốc đổi tên.
    // branch=false (--emit-base): chỉ tách hoạt hoá — conv(relu=false) -> ACT — để làm đồ thị NỀN khớp với file LoRA (xem bẫy ở đầu file / mục 265).
    int tA = -1, tB = -1, tSum = -1, tAct = -1;
    if (branch) { tA = addTensor(net, origName + "/lora_a"); tB = addTensor(net, origName + "/lora_b"); tSum = addTensor(net, origName); }
    if (fused) tAct = addTensor(net, origName);
    const int tFinal = fused ? tAct : tSum;
    net.tensorName[convOut] = origName + "/lora_base";
    if (branch && fused) net.tensorName[tSum] = origName + "/lora_sum";

    std::vector<std::unique_ptr<OpT>> added;
    if (branch) {
        added.push_back(makeConv(nA, in, s.rank, convIn, tA, c, true, std::move(A), fmt));
        added.push_back(makeConv(nB, s.rank, out, tA, tB, c, false, std::move(B), fmt));
        std::unique_ptr<OpT> add(new OpT);
        add->name = nAdd; add->type = OpType_BinaryOp; add->defaultDimentionFormat = fmt;
        add->inputIndexes = {convOut, tB}; add->outputIndexes = {tSum};
        std::unique_ptr<BinaryOpT> bo(new BinaryOpT);
        bo->opType = BinaryOpOperation_ADD; bo->T = DataType_DT_FLOAT; bo->activationType = 0;
        add->main.type = OpParameter_BinaryOp; add->main.value = bo.release();
        added.push_back(std::move(add));
    }
    if (fused) {
        c.relu = false; c.relu6 = false;
        std::unique_ptr<OpT> act(new OpT);
        act->name = nAct; act->defaultDimentionFormat = fmt;
        act->inputIndexes = {branch ? tSum : convOut}; act->outputIndexes = {tAct};
        if (wasRelu) {
            act->type = OpType_ReLU;
            std::unique_ptr<ReluT> r(new ReluT); r->slope = 0.f;
            act->main.type = OpParameter_Relu; act->main.value = r.release();
        } else {
            act->type = OpType_ReLU6;
            std::unique_ptr<Relu6T> r(new Relu6T); r->minValue = 0.f; r->maxValue = 6.f;
            act->main.type = OpParameter_Relu6; act->main.value = r.release();
        }
        added.push_back(std::move(act));
    }

    // Đổi mọi người dùng đầu ra conv gốc (trừ chính conv) sang đầu ra cuối. Duyệt TRƯỚC khi chèn để không đụng op mới.
    int rewired = 0;
    for (auto& o : net.oplists) {
        if (o.get() == conv) continue;
        for (int& idx : o->inputIndexes) if (idx == convOut) { idx = tFinal; ++rewired; }
    }
    // tên đầu ra mạng: vì đầu ra cuối mang lại tên gốc nên outputName không đổi.

    if (branch && opt.stripBase) { cv->weight.clear(); cv->weight.shrink_to_fit(); cv->bias.clear(); }

    size_t at = (size_t)pos + 1;
    for (auto& op : added) { net.oplists.insert(net.oplists.begin() + at, std::move(op)); ++at; }
    if (branch)
        std::printf("  gắn nhánh: %-40s in=%d out=%d k=%dx%d rank=%d scale=%g%s  (đổi %d chỗ dùng)\n", base.c_str(), in, out, c.kernelY, c.kernelX,
                    s.rank, s.scale, fused ? " [tách hoạt hoá]" : "", rewired);
    else
        std::printf("  đồ thị nền: %-40s tách hoạt hoá %s ra op riêng  (đổi %d chỗ dùng)\n", base.c_str(), wasRelu ? "relu" : "relu6", rewired);
    return true;
}

int main(int argc, char** argv) {
    if (argc >= 3 && std::string(argv[1]) == "--list") {
        std::vector<char> buf;
        if (!readFile(argv[2], buf)) { std::fprintf(stderr, "LỖI: không đọc được %s\n", argv[2]); return 2; }
        flatbuffers::Verifier v((const uint8_t*)buf.data(), buf.size());
        if (!VerifyNetBuffer(v)) { std::fprintf(stderr, "LỖI: %s không phải file MNN hợp lệ\n", argv[2]); return 2; }
        std::unique_ptr<NetT> net(GetNet(buf.data())->UnPack());
        return listOps(*net);
    }
    if (argc < 4) { std::fprintf(stderr, "dùng: %s --list base.mnn | %s base.mnn spec.txt out.mnn [--unfuse-activation] [--strip-base-weights] [--emit-base nền_tương_ứng.mnn]\n", argv[0], argv[0]); return 2; }
    Options opt;
    for (int i = 4; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--unfuse-activation") opt.unfuse = true;
        else if (a == "--strip-base-weights") opt.stripBase = true;
        else if (a == "--emit-base" && i + 1 < argc) opt.emitBase = argv[++i];
        else { std::fprintf(stderr, "LỖI: tuỳ chọn lạ '%s'\n", a.c_str()); return 2; }
    }
    std::vector<char> buf;
    if (!readFile(argv[1], buf)) { std::fprintf(stderr, "LỖI: không đọc được %s\n", argv[1]); return 2; }
    flatbuffers::Verifier ver((const uint8_t*)buf.data(), buf.size());
    if (!VerifyNetBuffer(ver)) { std::fprintf(stderr, "LỖI: %s không phải file MNN hợp lệ\n", argv[1]); return 2; }
    std::unique_ptr<NetT> net(GetNet(buf.data())->UnPack());
    if (!net->subgraphs.empty()) std::fprintf(stderr, "CẢNH BÁO: đồ thị có %d subgraph — công cụ chỉ sửa đồ thị chính\n", (int)net->subgraphs.size());

    std::vector<Spec> specs; std::string err;
    if (!parseSpec(argv[2], specs, err)) { std::fprintf(stderr, "LỖI: %s\n", err.c_str()); return 2; }
    if (specs.empty()) { std::fprintf(stderr, "LỖI: spec không có dòng nào\n"); return 2; }
    std::set<std::string> seen;
    for (const auto& s : specs) if (!seen.insert(s.target).second) { std::fprintf(stderr, "LỖI: spec dòng %d: '%s' xuất hiện hai lần\n", s.line, s.target.c_str()); return 2; }
    for (const auto& s : specs) {
        if (!attach(*net, s, opt, err)) { std::fprintf(stderr, "LỖI (spec dòng %d): %s\n", s.line, err.c_str()); return 2; }
    }
    flatbuffers::FlatBufferBuilder fbb;
    fbb.Finish(Net::Pack(fbb, net.get()));
    std::ofstream f(argv[3], std::ios::binary);
    if (!f) { std::fprintf(stderr, "LỖI: không ghi được %s\n", argv[3]); return 2; }
    f.write((const char*)fbb.GetBufferPointer(), (std::streamsize)fbb.GetSize());
    f.close();
    std::printf("OK: gắn %d nhánh, ghi %s (%zu byte)\n", (int)specs.size(), argv[3], (size_t)fbb.GetSize());
    if (!opt.emitBase.empty()) {
        // đồ thị NỀN tương ứng: cùng phép tách hoạt hoá nhưng KHÔNG có nhánh. Cần khi dùng Module::Config::base: execution nhân bản từ module nền
        // mang theo hoạt hoá gộp của conv nền, nên nếu nền còn relu gộp mà file LoRA đã tách relu ra thì relu bị áp TRƯỚC nhánh LoRA (sai kết quả).
        std::unique_ptr<NetT> bnet(GetNet(buf.data())->UnPack());
        Options bo; bo.unfuse = true;
        for (const auto& s : specs) if (!attach(*bnet, s, bo, err, false)) { std::fprintf(stderr, "LỖI (--emit-base, spec dòng %d): %s\n", s.line, err.c_str()); return 2; }
        flatbuffers::FlatBufferBuilder fb2;
        fb2.Finish(Net::Pack(fb2, bnet.get()));
        std::ofstream g(opt.emitBase, std::ios::binary);
        if (!g) { std::fprintf(stderr, "LỖI: không ghi được %s\n", opt.emitBase.c_str()); return 2; }
        g.write((const char*)fb2.GetBufferPointer(), (std::streamsize)fb2.GetSize());
        std::printf("OK: ghi đồ thị nền tương ứng %s (%zu byte)\n", opt.emitBase.c_str(), (size_t)fb2.GetSize());
    }
    return 0;
}
