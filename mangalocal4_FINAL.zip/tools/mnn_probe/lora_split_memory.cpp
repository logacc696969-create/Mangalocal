// mục 264 — đo RAM: base gồm L lớp conv1x1 CxC (trọng số lớn) + k module LoRA tách rời nạp với base. So rearrange=true/false và có/không base.
#include <MNN/expr/Expr.hpp>
#include <MNN/expr/ExprCreator.hpp>
#include <MNN/expr/Module.hpp>
#include <MNN/expr/Executor.hpp>
#include <MNN/expr/NeuralNetWorkOp.hpp>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <random>
#include <sstream>
#include <vector>
using namespace MNN::Express;
static const int C = 1024, L = 12, R = 8, HW = 4;
static double rssMB() { std::ifstream f("/proc/self/status"); std::string l; while (std::getline(f, l)) if (l.rfind("VmRSS:", 0) == 0) { std::istringstream s(l.substr(6)); double kb; s >> kb; return kb / 1024.0; } return -1; }
static VARP net(const std::vector<std::vector<float>>& Ws, bool lora, std::mt19937& rng) {
    auto x = _Input({1, C, HW, HW}, NCHW, halide_type_of<float>()); x->setName("x");
    VARP h = x; std::normal_distribution<float> nd(0.f, 0.02f);
    for (int l = 0; l < L; ++l) {
        auto c = _Conv(std::vector<float>(Ws[l]), std::vector<float>(C, 0.f), h, {C, C}, {1, 1}, VALID); c->setName("conv" + std::to_string(l));
        VARP o = c;
        if (lora) {
            std::vector<float> A(R * C), B(C * R); for (auto& v : A) v = nd(rng); for (auto& v : B) v = nd(rng);
            auto la = _Conv(std::move(A), std::vector<float>(R, 0.f), h, {C, R}, {1, 1}, VALID); la->setName("loraA" + std::to_string(l));
            auto lb = _Conv(std::move(B), std::vector<float>(C, 0.f), la, {R, C}, {1, 1}, VALID); lb->setName("loraB" + std::to_string(l));
            o = _Add(c, lb);
        }
        h = o;
    }
    h->setName("out");
    return h;
}
static void run(Module* m) { auto in = _Input({1, C, HW, HW}, NCHW, halide_type_of<float>()); ::memset(in->writeMap<float>(), 0, C * HW * HW * 4); auto o = m->onForward({in}); o[0]->readMap<float>(); }
int main() {
    std::mt19937 rng(7); std::normal_distribution<float> nd(0.f, 0.02f);
    std::vector<std::vector<float>> Ws(L, std::vector<float>((size_t)C * C)), Zs(L, std::vector<float>((size_t)C * C, 0.f));
    for (auto& w : Ws) for (auto& v : w) v = nd(rng);
    Variable::save({net(Ws, false, rng)}, "mbase.mnn");
    for (int k = 0; k < 3; ++k) Variable::save({net(Zs, true, rng)}, ("mlora" + std::to_string(k) + ".mnn").c_str());
    Ws.clear(); Ws.shrink_to_fit(); Zs.clear(); Zs.shrink_to_fit();
    std::printf("base = %d lớp conv %dx%d fp32 = %.0f MB trọng số\n", L, C, C, (double)L * C * C * 4 / 1048576.0);
    MNN::ScheduleConfig sc; sc.type = MNN_FORWARD_CPU; sc.numThread = 1; MNN::BackendConfig bc; sc.backendConfig = &bc;
    for (int mode = 0; mode < 3; ++mode) {   // 0: rearrange=true + base ; 1: rearrange=false + base ; 2: rearrange=true, KHÔNG base
        const bool ra = (mode != 1);
        std::shared_ptr<Executor::RuntimeManager> rt(Executor::RuntimeManager::createRuntimeManager(sc));
        Module::Config mc; mc.shapeMutable = false; mc.rearrange = ra;
        const double r0 = rssMB();
        std::shared_ptr<Module> base(Module::load({"x"}, {"out"}, "mbase.mnn", rt, &mc)); run(base.get());
        const double r1 = rssMB();
        std::vector<std::shared_ptr<Module>> ls; Module::Config mb = mc; if (mode != 2) mb.base = base.get();
        std::printf("[%s] rearrange=%d | nền: RSS +%.0f MB", mode == 0 ? "base+rearrange" : mode == 1 ? "base, rearrange=false" : "KHÔNG base", ra, r1 - r0);
        for (int k = 0; k < 3; ++k) {
            const double a = rssMB();
            ls.emplace_back(Module::load({"x"}, {"out"}, ("mlora" + std::to_string(k) + ".mnn").c_str(), rt, &mb)); run(ls.back().get());
            std::printf(" | LoRA %d: +%.0f MB", k, rssMB() - a);
        }
        std::printf("\n");
        ls.clear(); base.reset();
    }
    return 0;
}
