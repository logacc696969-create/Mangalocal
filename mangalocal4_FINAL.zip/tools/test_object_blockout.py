#!/usr/bin/env python3
"""mục 260 — kiểm thử KHỐI ĐỘ SÂU CHO VẬT THỂ (ObjectDepthBlockout.kt).

Điểm mạnh: bản đồ độ sâu "thật" được dựng bởi hàm C++ THẬT `pose_templates::renderDepthHint` (trích nguyên văn từ ip_adapter.cpp, biên dịch bằng g++),
rồi áp bản chép Python của ObjectDepthBlockout.apply lên chính bytes đó. Bản chép Python bám từng dòng Kotlin (Kotlin chưa biên dịch được ở sandbox).
KHÔNG chứng minh: ControlNet-Depth có biến mảng phẳng thành đúng vật thể hay không — cần ảnh thật.
"""
import os, re, subprocess, sys, tempfile, math
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/')
def rd(p): return open(J + p, encoding='utf-8').read()
KT, IMG, PIPE, MODELS, SET, HELP = rd('pipeline/ObjectDepthBlockout.kt'), rd('pipeline/ImagePipeline.kt'), rd('pipeline/MangaPipeline.kt'), rd('model/Models.kt'), rd('ui/SettingsScreen.kt'), rd('ui/ParamHelp.kt')
CPP = open(os.path.join(ROOT, 'app/src/main/jni/ip_adapter.cpp'), encoding='utf-8').read()
ok = True
def check(name, cond, detail=''):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + detail) if (detail and not cond) else ''))
    ok &= bool(cond)

LEVEL = int(re.search(r'const val LEVEL = (\d+)', KT).group(1))
FLOOR = int(float(re.search(r'constexpr float kDepthFloor = ([\d.]+)f;', CPP).group(1)))
check(f'LEVEL ({LEVEL}) < mức sàn người của renderDepthHint ({FLOOR}) đọc thẳng từ ip_adapter.cpp: vật thể luôn nằm SAU người', 0 < LEVEL < FLOOR)

MUT = set()
def apply(hint, size, boxes):
    if not boxes or size <= 0 or len(hint) != size * size * 3: return hint
    out = bytearray(hint)
    lv = LEVEL if 'level_high' not in MUT else FLOOR + 10
    def cl(v): return 0.0 if (isinstance(v, float) and math.isnan(v)) else min(max(v, 0.0), 1.0)
    for (xmin, ymin, xmax, ymax) in boxes:
        if not (xmax > xmin and ymax > ymin): continue
        if 'no_clamp' in MUT:
            x0, x1, y0, y1 = int(math.floor(xmin * size)), int(math.ceil(xmax * size)), int(math.floor(ymin * size)), int(math.ceil(ymax * size))
        else:
            x0 = min(max(int(math.floor(cl(xmin) * size)), 0), size); x1 = min(max(int(math.ceil(cl(xmax) * size)), 0), size)
            y0 = min(max(int(math.floor(cl(ymin) * size)), 0), size); y1 = min(max(int(math.ceil(cl(ymax) * size)), 0), size)
        if 'swap_xy' in MUT: x0, x1, y0, y1 = y0, y1, x0, x1
        if x1 <= x0 or y1 <= y0: continue
        for y in (range(y0, y1) if 'no_clamp' in MUT else range(max(y0, 0), min(y1, size))):
            for x in (range(x0, x1) if 'no_clamp' in MUT else range(max(x0, 0), min(x1, size))):
                i = (y * size + x) * 3
                if 'no_clamp' in MUT and (i < 0 or i + 2 >= len(out) or x < 0 or x >= size): raise IndexError('Kotlin: ArrayIndexOutOfBounds')
                if ('overwrite' in MUT) or out[i] < lv:
                    out[i] = out[i + 1] = out[i + 2] = lv
    return bytes(out)

# ---------- bản đồ độ sâu THẬT từ C++ ----------
HEADER = r"""#include <vector>
#include <array>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cmath>
namespace pose_templates {
struct Keypoint { float x, y, z; bool visible; };
using Skeleton = std::array<Keypoint, 18>;
const std::vector<std::pair<int,int>> kBonePairs = {
    {1,2},{1,5},{2,3},{3,4},{5,6},{6,7},{1,8},{8,9},{9,10},
    {1,11},{11,12},{12,13},{1,0},{0,14},{14,16},{0,15},{15,17}
};
"""
MAIN = r"""static pose_templates::Skeleton mk(float cx, float top, float z){
  pose_templates::Skeleton s{};
  auto set=[&](int i,float x,float y,float zz){ s[i]={x,y,zz,true}; };
  for(int i=0;i<18;i++) set(i,cx,top,z);
  set(1,cx,top+0.08f,z); set(2,cx-0.07f,top+0.10f,z); set(5,cx+0.07f,top+0.10f,z);
  set(3,cx-0.10f,top+0.22f,z); set(6,cx+0.10f,top+0.22f,z); set(4,cx-0.11f,top+0.33f,z); set(7,cx+0.11f,top+0.33f,z);
  set(8,cx-0.04f,top+0.32f,z); set(11,cx+0.04f,top+0.32f,z); set(9,cx-0.04f,top+0.48f,z); set(12,cx+0.04f,top+0.48f,z);
  set(10,cx-0.04f,top+0.64f,z); set(13,cx+0.04f,top+0.64f,z);
  return s;
}
int main(int argc, char** argv){
  const int W=512,H=512;
  pose_templates::Skeleton a = mk(0.35f,0.10f,1.0f), b = mk(0.62f,0.12f,0.0f);
  b[4] = {0.40f,0.30f,-0.3f,true};
  auto c = pose_templates::renderDepthHint({a,b}, W, H);
  FILE* f = fopen(argv[1], "wb"); fwrite(c.data(), 1, c.size(), f); fclose(f);
  return 0;
}
"""
def real_hint():
    i = CPP.index('inline std::vector<uint8_t> renderDepthHint(')
    j = CPP.index('// Multi-IP-Adapter CÓ MASK VÙNG')
    code = HEADER + CPP[i:j] + '\n}\n' + MAIN
    with tempfile.TemporaryDirectory() as d:
        cpp = os.path.join(d, 't.cpp'); exe = os.path.join(d, 't'); out = os.path.join(d, 'h.bin')
        open(cpp, 'w', encoding='utf-8').write(code)
        r = subprocess.run(['g++', '-std=c++17', '-O1', '-o', exe, cpp], capture_output=True, text=True)
        if r.returncode != 0: print(r.stderr); sys.exit(2)
        subprocess.run([exe, out], check=True)
        return open(out, 'rb').read()
H = real_hint(); S = 512
check('đã dựng bản đồ độ sâu thật bằng C++ (512x512x3)', len(H) == S * S * 3)
nz = sum(1 for k in range(0, len(H), 3) if H[k] != 0)
check('bản đồ thật có pixel người (đã đo được) và nền 0', 3000 < nz < S * S // 2 and H[0] == 0, str(nz))
check('mọi pixel người trong bản đồ thật >= mức sàn (cơ sở của quy ước LEVEL < sàn)', all(H[k] == 0 or H[k] >= FLOOR for k in range(0, len(H), 3)))

# hộp phủ lên cả người lẫn nền: x 0.2..0.75, y 0.25..0.9  + một hộp nhỏ ở góc
BOXES = [(0.2, 0.25, 0.75, 0.9), (0.85, 0.05, 0.99, 0.2)]
R = apply(H, S, BOXES)
check('kết quả cùng kích thước và KHÔNG sửa bản gốc (bản sao)', len(R) == len(H) and R is not H)
person_kept = all(R[k] == H[k] for k in range(0, len(H), 3) if H[k] >= FLOOR)
check('MỌI pixel người của bản đồ thật được giữ NGUYÊN (người không bao giờ bị vật thể xoá)', person_kept)
def inside(x, y):
    for (x0, y0, x1, y1) in BOXES:
        if math.floor(x0 * S) <= x < math.ceil(x1 * S) and math.floor(y0 * S) <= y < math.ceil(y1 * S): return True
    return False
bad_in = bad_out = 0
for y in range(S):
    for x in range(S):
        k = (y * S + x) * 3
        if inside(x, y):
            exp = H[k] if H[k] >= LEVEL else LEVEL
        else:
            exp = H[k]
        if not (R[k] == R[k + 1] == R[k + 2] == exp):
            if inside(x, y): bad_in += 1
            else: bad_out += 1
check('trong hộp: nền -> LEVEL, người giữ nguyên; ngoài hộp: không đổi pixel nào (3 kênh bằng nhau)', bad_in == 0 and bad_out == 0, f'in={bad_in} out={bad_out}')
n_filled = sum(1 for k in range(0, len(H), 3) if R[k] == LEVEL and H[k] == 0)
big = (math.ceil(0.75 * S) - math.floor(0.2 * S)) * (math.ceil(0.9 * S) - math.floor(0.25 * S))
check('mảng vật thể phủ đủ diện tích hộp trừ phần người đè lên (đo đếm pixel)', 0.5 * big < n_filled <= big + 2000, f'{n_filled} vs {big}')
check('idempotent: áp hai lần = áp một lần', apply(R, S, BOXES) == R)
check('thứ tự các hộp không đổi kết quả (cùng mức, phép "tối hơn thì tô")', apply(H, S, BOXES[::-1]) == R)

# ---------- ca biên ----------
check('không có hộp -> trả nguyên hint (không đổi hành vi cũ)', apply(H, S, []) is H)
check('sai kích thước hint -> trả nguyên (an toàn)', apply(H[:-3], S, BOXES) == H[:-3] and apply(H, 256, BOXES) is H)
Z = bytes(S * S * 3)
check('hộp suy biến (xmax<=xmin, ymax<=ymin) bị bỏ qua', apply(Z, S, [(0.5, 0.5, 0.5, 0.9), (0.2, 0.7, 0.6, 0.7), (0.9, 0.1, 0.2, 0.3)]) == Z)
r2 = apply(Z, S, [(-0.5, -0.5, 1.7, 0.1)])
check('toạ độ ngoài [0,1] được kẹp vào khung: tô đúng hàng 0..51 (ceil(0.1*512)=52), hàng 52 không tô, không tràn bộ nhớ',
      len(r2) == len(Z) and r2[0] == LEVEL and r2[(S * 51) * 3] == LEVEL and r2[(S * 52) * 3] == 0 and r2[(S * 51 + 511) * 3] == LEVEL)
check('NaN ở bất kỳ toạ độ nào: hộp bị bỏ qua hoàn toàn', all(apply(Z, S, [tuple(float('nan') if j == i else v for j, v in enumerate((0.1, 0.1, 0.5, 0.5)))]) == Z for i in range(4)))
check('hộp phủ toàn khung trên nền trống: mọi pixel = LEVEL', set(apply(Z, S, [(0, 0, 1, 1)])) == {LEVEL})

# ---------- nối dây (kiểm tĩnh) ----------
check('ImagePipeline.generatePanelTripleCombo có tham số objectBoxes (mặc định rỗng) và áp khối TRƯỚC kiểm kích thước',
      'objectBoxes: List<ObjectBox> = emptyList()' in IMG and
      IMG.index('ObjectDepthBlockout.apply(NativeBridge.renderDepthHintCanvas(skeletonData, controlSize), controlSize, objectBoxes)') < IMG.index('val safeDepthHint = if (depthHint.size == blankHint.size) depthHint else blankHint'))
sites = re.findall(r'objectBoxes = if \(settings\.objectDepthBlockout\) resolveObjectBoxes\(panel\.scene, panel\.overrideSettings\?\.objectBoxOverride\) else emptyList\(\)', PIPE)
check('cả 3 chỗ gọi generatePanelTripleCombo (2 ở generatePanels, 1 ở regeneratePanel) truyền hộp, chỉ khi bật cờ', len(sites) == 3 and PIPE.count('imagePipeline.generatePanelTripleCombo(') == 3, str(len(sites)))
check('Cài đặt: objectDepthBlockout mặc định TẮT', 'val objectDepthBlockout: Boolean = false' in MODELS)
check('Cài đặt: có công tắc HelpSwitch và mục trợ giúp (mặc định "Tắt")', 'HelpSwitch(helpKey = "objectDepthBlockout"' in SET and '"objectDepthBlockout" to e(' in HELP)
check('Kotlin: chỉ tô khi pixel TỐI HƠN LEVEL (không bao giờ xoá người)', '(out[i].toInt() and 0xFF) < LEVEL' in KT)
check('Kotlin: sai kích thước -> trả nguyên hint', 'hint.size != size * size * 3) return hint' in KT)
check('Kotlin: bỏ hộp suy biến/NaN trước khi đổi sang pixel', 'if (!(b.xmax > b.xmin && b.ymax > b.ymin)) continue' in KT)
check('Kotlin: kẹp [0,1] cả 4 toạ độ rồi kẹp theo size', all(f'b.{c}.coerceIn(0f, 1f)' in KT for c in ['xmin', 'xmax', 'ymin', 'ymax']))
check('ngoặc {} () [] cân bằng ở ObjectDepthBlockout.kt', all(KT.count(a) == KT.count(b) for a, b in ['{}', '()', '[]']))

# ---------- thử phá mã ----------
def detect(m):
    MUT.clear(); MUT.add(m)
    try:
        r = apply(H, S, BOXES)
        if r != R: return True
        z = apply(Z, S, [(-0.5, -0.5, 1.7, 0.1)])
        return z != r2
    except Exception: return True
    finally: MUT.clear()
muts = ['level_high', 'overwrite', 'no_clamp', 'swap_xy']
c = 0
for m in muts:
    d = detect(m); c += d; check(f'đột biến "{m}" bị bắt', d)
check(f'bắt đủ {len(muts)}/{len(muts)} đột biến', c == len(muts))

print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
