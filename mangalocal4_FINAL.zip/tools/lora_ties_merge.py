#!/usr/bin/env python3
"""lora_ties_merge.py — mục 249 TECHNICAL_STATUS.md.

Gộp NHIỀU LoRA nhân vật (định dạng kohya: `<module>.lora_down.weight`, `<module>.lora_up.weight`, `<module>.alpha`) thành MỘT file
LoRA bằng các phương pháp gộp trọng số KHÔNG cần huấn luyện, thay vì cộng thẳng:

  linear     : tổng có trọng số (đường cơ sở, y như cộng thẳng).
  ties       : TIES-Merging — (1) cắt, chỉ giữ `density` phần tử có độ lớn lớn nhất của mỗi LoRA; (2) bầu dấu cho từng phần tử theo
               tổng; (3) trung bình RỜI: chỉ lấy trung bình các LoRA ĐỒNG DẤU với dấu đã bầu (phần tử trái dấu bị bỏ).
  dare_ties  : DARE (bỏ ngẫu nhiên phần tử với xác suất 1-density rồi nhân lại 1/density) + bước bầu dấu/trung bình rời của TIES.
  dare_linear: DARE rồi cộng có trọng số.

Vì sao có: PDF/mục 248 — SDO và Gradient Fusion (chống rò danh tính giữa các LoRA) cần huấn luyện/can thiệp sâu nên bị loại; TIES/DARE là
hướng gộp không huấn luyện mà cộng đồng dùng. Mỗi LoRA được chuyển thành ΔW = (alpha/rank) · up @ down, gộp ΔW, rồi SVD cắt về hạng
`--rank` (mặc định = hạng lớn nhất của các đầu vào) để ra lại cặp up/down, alpha = rank.

DÙNG Ở ĐÂU: file kết quả dùng như MỘT LoRA (đặt vào `--loras-dir` của tools/remote_server rồi gửi `lora_id`) cho cảnh nhiều người ở
nhánh Remote GPU. ĐƯỜNG ON-DEVICE KHÔNG ĐỔI (ghép LoRA vẫn xảy ra trong native lúc convert — mục 28/55).

GIỚI HẠN THẬT (đọc kỹ):
  - Phần lớn bằng chứng cho TIES/DARE đến từ mô hình ngôn ngữ/thị giác; CHƯA có bằng chứng nào trong dự án này rằng nó giảm rò danh tính
    giữa hai LoRA nhân vật SD1.5. Cần thử: gộp hai LoRA, sinh ảnh hai người cùng seed, so với cộng thẳng.
  - Gộp ΔW rồi SVD cắt hạng làm MẤT thông tin nếu hạng đầu ra thấp hơn hạng thật của ΔW gộp.
  - Chỉ gộp các module có cùng hình dạng ở mọi LoRA có mặt; module khác hình dạng bị bỏ qua và in cảnh báo.
  - Phần số học được kiểm thử bằng dữ liệu tổng hợp (tools/test_lora_ties_merge.py); KHÔNG thử với LoRA thật.
Cách chạy:
  python tools/lora_ties_merge.py a.safetensors b.safetensors -o merged.safetensors --method ties --density 0.5 --weights 1 1
Cần: numpy, safetensors (chỉ nạp khi chạy CLI).
"""
import argparse
import math
import sys

import numpy as np

METHODS = ("linear", "ties", "dare_ties", "dare_linear")
DOWN, UP, ALPHA = ".lora_down.weight", ".lora_up.weight", ".alpha"


# ----------------------------------------------------------------------------- đọc / ghi định dạng kohya
def read_lora(tensors: dict) -> dict:
    """tensors: {khoá: ndarray}. Trả {module: (down, up, alpha)}; alpha = hạng nếu thiếu (quy ước kohya)."""
    mods = {}
    for k, v in tensors.items():
        if k.endswith(DOWN):
            mods.setdefault(k[: -len(DOWN)], {})["down"] = np.asarray(v, dtype=np.float32)
        elif k.endswith(UP):
            mods.setdefault(k[: -len(UP)], {})["up"] = np.asarray(v, dtype=np.float32)
        elif k.endswith(ALPHA):
            mods.setdefault(k[: -len(ALPHA)], {})["alpha"] = float(np.asarray(v).reshape(-1)[0])
    out = {}
    for m, d in mods.items():
        if "down" in d and "up" in d:
            rank = d["down"].shape[0]
            out[m] = (d["down"], d["up"], d.get("alpha", float(rank)))
    return out


def delta_of(down: np.ndarray, up: np.ndarray, alpha: float) -> np.ndarray:
    """ΔW dạng ma trận (out, in·k·k). Conv: down (r,in,k,k), up (out,r,1,1) -> làm phẳng."""
    r = down.shape[0]
    d2 = down.reshape(r, -1)
    u2 = up.reshape(up.shape[0], r)
    return (alpha / r) * (u2 @ d2)


def to_lora(delta: np.ndarray, rank: int, down_shape: tuple, up_shape: tuple):
    """SVD cắt hạng: trả (down, up) đúng hình dạng mẫu; alpha = hạng thực tế được dùng."""
    u, s, vt = np.linalg.svd(delta, full_matrices=False)
    r = max(1, min(rank, len(s)))
    root = np.sqrt(s[:r])
    up2 = u[:, :r] * root[None, :]
    down2 = root[:, None] * vt[:r, :]
    down = down2.reshape((r,) + tuple(down_shape[1:]))
    up = up2.reshape((up_shape[0], r) + tuple(up_shape[2:]))
    return down.astype(np.float32), up.astype(np.float32), r


# ----------------------------------------------------------------------------- lõi gộp
def trim_topk(d: np.ndarray, density: float) -> np.ndarray:
    """Giữ `density` phần tử có |giá trị| lớn nhất (hoà thì giữ thêm), còn lại về 0."""
    if density >= 1.0 or d.size == 0:
        return d.copy()
    a = np.abs(d).reshape(-1)
    k = max(1, int(math.ceil(density * a.size)))
    thr = np.partition(a, a.size - k)[a.size - k]
    if thr == 0.0:
        return np.where(np.abs(d) > 0, d, 0.0).astype(d.dtype)
    return np.where(np.abs(d) >= thr, d, 0.0).astype(d.dtype)


def dare_drop(d: np.ndarray, density: float, rng: np.random.Generator) -> np.ndarray:
    """Giữ mỗi phần tử với xác suất `density`, nhân 1/density phần giữ lại (kỳ vọng không đổi)."""
    if density >= 1.0:
        return d.copy()
    keep = rng.random(d.shape) < density
    return (d * keep / density).astype(d.dtype)


def elect_and_mean(deltas: list) -> np.ndarray:
    """Bầu dấu theo tổng rồi trung bình RỜI: chỉ các phần tử đồng dấu với dấu đã bầu được tính."""
    stack = np.stack(deltas)
    sgn = np.sign(stack.sum(axis=0))
    agree = (np.sign(stack) == sgn[None]) & (stack != 0)
    num = (stack * agree).sum(axis=0)
    cnt = agree.sum(axis=0)
    return num / np.maximum(cnt, 1)


def merge_deltas(deltas: list, weights: list, method: str = "ties", density: float = 0.5, seed: int = 0) -> np.ndarray:
    if method not in METHODS:
        raise ValueError("method phải là một trong %s" % (METHODS,))
    if not deltas:
        raise ValueError("không có ΔW để gộp")
    scaled = [d * w for d, w in zip(deltas, weights)]
    rng = np.random.default_rng(seed)
    if method == "linear":
        return np.sum(scaled, axis=0)
    if method == "ties":
        return elect_and_mean([trim_topk(d, density) for d in scaled])
    if method == "dare_ties":
        return elect_and_mean([dare_drop(d, density, rng) for d in scaled])
    return np.sum([dare_drop(d, density, rng) for d in scaled], axis=0)   # dare_linear


def merge_loras(loras: list, weights=None, method="ties", density=0.5, rank=None, seed=0, scale=1.0, warn=print) -> dict:
    """loras: danh sách kết quả read_lora(). Trả tensors kohya {khoá: ndarray}."""
    if not loras:
        raise ValueError("cần ít nhất 1 LoRA")
    weights = list(weights) if weights is not None else [1.0] * len(loras)
    if len(weights) != len(loras):
        raise ValueError("số trọng số (%d) khác số LoRA (%d)" % (len(weights), len(loras)))
    out_rank = rank or max(d.shape[0] for l in loras for (d, _, _) in l.values())
    out = {}
    skipped = 0
    for mod in sorted({m for l in loras for m in l}):
        present = [(i, l[mod]) for i, l in enumerate(loras) if mod in l]
        d0, u0, _a0 = present[0][1]
        shapes_ok = all(d.shape[1:] == d0.shape[1:] and u.shape[0] == u0.shape[0] and u.shape[2:] == u0.shape[2:]
                        for _, (d, u, _a) in present)
        if not shapes_ok:
            warn("CẢNH BÁO: module %s có hình dạng khác nhau giữa các LoRA — bỏ qua" % mod)
            skipped += 1
            continue
        deltas = [delta_of(d, u, a) for _, (d, u, a) in present]
        ws = [weights[i] for i, _ in present]
        merged = merge_deltas(deltas, ws, method, density, seed) * scale
        down, up, r = to_lora(merged, out_rank, d0.shape, u0.shape)
        out[mod + DOWN] = down
        out[mod + UP] = up
        out[mod + ALPHA] = np.array(float(r), dtype=np.float32)
    if not out:
        raise ValueError("không module nào được gộp (tên khoá/hình dạng không khớp?)")
    return out


def merge_files(paths: list, out_path: str, weights=None, method="ties", density=0.5, rank=None, seed=0, scale=1.0, loader=None, saver=None, warn=print):
    """Đọc/ghi qua `loader(path)->dict` / `saver(dict, path)`; mặc định dùng safetensors.numpy (nạp lười)."""
    if loader is None or saver is None:
        from safetensors.numpy import load_file, save_file   # noqa: chỉ cần khi chạy CLI
        loader = loader or load_file
        saver = saver or (lambda t, p: save_file(t, p))
    loras = [read_lora(loader(p)) for p in paths]
    for p, l in zip(paths, loras):
        if not l:
            raise ValueError("%s: không đọc được module LoRA kohya nào (khoá có dạng *.lora_down.weight?)" % p)
    merged = merge_loras(loras, weights, method, density, rank, seed, scale, warn)
    saver(merged, out_path)
    return merged


def main(argv=None):
    ap = argparse.ArgumentParser(description="Gộp nhiều LoRA nhân vật bằng TIES/DARE (xem docstring đầu file).")
    ap.add_argument("inputs", nargs="+", help="các file LoRA .safetensors (định dạng kohya)")
    ap.add_argument("-o", "--output", required=True)
    ap.add_argument("--method", choices=METHODS, default="ties")
    ap.add_argument("--density", type=float, default=0.5, help="phần giữ lại (0<d<=1) cho ties/dare")
    ap.add_argument("--weights", type=float, nargs="*", default=None, help="trọng số từng LoRA (mặc định 1 cho tất cả)")
    ap.add_argument("--rank", type=int, default=None, help="hạng LoRA đầu ra (mặc định = hạng lớn nhất đầu vào)")
    ap.add_argument("--scale", type=float, default=1.0, help="nhân thêm vào ΔW đã gộp")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args(argv)
    if not (0.0 < a.density <= 1.0):
        ap.error("--density phải trong (0, 1]")
    merged = merge_files(a.inputs, a.output, a.weights, a.method, a.density, a.rank, a.seed, a.scale)
    print("Đã gộp %d LoRA -> %s (%d module, phương pháp %s, density %.2f)" % (len(a.inputs), a.output, len(merged) // 3, a.method, a.density))
    return 0


if __name__ == "__main__":
    sys.exit(main())
