#!/usr/bin/env python3
"""mục 267 — canh MÃ HOÁ mọi tệp văn bản của dự án: phải là UTF-8 hợp lệ, không BOM, không ký tự thay thế U+FFFD.

Vì sao có: TECHNICAL_STATUS_SUMMARY.md trong zip giao ở mục 266 có 2 byte lạc (`BB 9F`) — chữ "ở" mất byte dẫn `E1` — nên không đọc được bằng UTF-8 (nhiều công cụ/trình soạn thảo sẽ báo
lỗi hoặc thay bằng ký tự lạ) và không ai phát hiện qua nhiều mục vì không test nào quét mã hoá. Thuần Python. Có thử phá mã: xoá một byte dẫn UTF-8 phải bị bắt.
KHÔNG chứng minh: nội dung đúng chính tả/ngữ nghĩa; tệp nhị phân (png/jar/zip) không được quét.
"""
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + str(d)[:300]) if (d and not c) else '')); ok &= bool(c)
EXT = ('.kt', '.md', '.py', '.yml', '.yaml', '.txt', '.xml', '.gradle', '.json', '.cpp', '.h', '.hpp', '.c', '.properties', '.sh', '.cmake', '.kts', '.pro', '.cfg', '.toml')
def problems(b):
    out = []
    try: t = b.decode('utf-8')
    except UnicodeDecodeError as e: return [f'UTF-8 hỏng tại byte {e.start}']
    if b.startswith(b'\xef\xbb\xbf'): out.append('có BOM')
    if '\ufffd' in t: out.append('có ký tự thay thế U+FFFD (mất chữ từ trước)')
    return out
# tự kiểm
good = 'Mở rộng'.encode('utf-8'); broken = good.replace(b'\xe1', b'', 1)
check('bộ kiểm: bắt được chữ "ở" mất byte dẫn E1 (đúng lỗi đã gặp)', problems(broken) != [] and problems(good) == [])
check('bộ kiểm: bắt BOM và U+FFFD', 'có BOM' in problems(b'\xef\xbb\xbfabc') and any('U+FFFD' in x for x in problems('a\ufffdb'.encode('utf-8'))))
n = 0; bad = []
for root, dirs, fs in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ('.git', 'build', '.gradle', '__pycache__', 'node_modules')]
    for f in fs:
        if not f.endswith(EXT): continue
        p = os.path.join(root, f); n += 1
        pr = problems(open(p, 'rb').read())
        if pr: bad.append((os.path.relpath(p, ROOT), pr))
check(f'mọi tệp văn bản ({n} tệp) là UTF-8 hợp lệ, không BOM, không U+FFFD', not bad, str(bad))
check('đã quét đủ nhiều tệp (không quét rỗng)', n >= 150, str(n))
print('\nKẾT QUẢ:', 'ĐẠT' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
