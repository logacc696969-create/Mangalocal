#!/usr/bin/env python3
"""mục 267 — kiểm thử `pipeline/SettingsStore.kt` (lưu bền cài đặt) bằng kotlinc THẬT + Gson 2.10.1 THẬT trên đúng lớp `GenerationSettings` của `Models.kt`.

Phần chạy thật (driver Kotlin trên JVM, thư mục tạm thật): lần mở đầu không có tệp; lưu rồi nạp lại bằng nhau trên đủ kiểu (Boolean/Int/Float/Long/String/enum/lồng nhau/List/Map);
FUZZ 400 cài đặt ngẫu nhiên khứ hồi đúng từng trường; khoá API: mặc định KHÔNG xuống đĩa, bật cờ mới ghi và CHỈ vào tệp riêng (marker bí mật không bao giờ xuất hiện trong tệp chính),
tắt cờ thì tệp bí mật bị xoá, tệp bí mật bị bỏ qua nếu cờ không bật; tệp hỏng/không phải đối tượng -> đổi tên .bad + dùng mặc định (KHÔNG ném ngoại lệ); tệp cũ thiếu khoá -> khoá thiếu lấy MẶC ĐỊNH
THẬT (không phải 0); sai kiểu (chuỗi vào Boolean mà Gson im lặng đọc thành false; 1.5 vào Int mà Gson im lặng cắt còn 1) -> giữ mặc định; số nguyên tràn Int -> chỉ bỏ khoá đó, giữ các khoá còn lại;
enum đổi tên -> mặc định chứ không phải null; không ghi lại y hệt; không để tệp tạm; reset xoá sạch.
Phần tĩnh: danh sách trường bí mật khớp Models.kt; nối dây ViewModel (nạp lúc tạo, lưu có debounce, áp lại ngưỡng nhiệt lúc khởi động, có reset); UI/ParamHelp/HDSD không còn nói "đóng app là mất".
KHÔNG chứng minh: ghi tệp thật trên Android (noBackupFilesDir có đúng bị loại khỏi Auto Backup), Compose hiển thị đúng — chỉ CI/máy thật biết.
Cần kotlinc + javac/java + gson (GSON_JAR=...); thiếu -> BỎ QUA phần chạy thật (phần tĩnh vẫn chạy).
"""
import os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + d) if (d and not c) else '')); ok &= bool(c)
def find(cands):
    for c in cands:
        if c and os.path.exists(c): return c
KOTLINC = find([os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/tools/kotlinc/bin/kotlinc', '/home/claude/work/kotlinc/bin/kotlinc'])
GSON = find([os.environ.get('GSON_JAR'), '/home/claude/tools/gson-2.10.1.jar', '/home/claude/work/gson-2.10.1.jar'])
JAVA = shutil.which('java')
rd = lambda p: open(os.path.join(KT, p), encoding='utf-8').read()

DRV = r'''
import com.google.gson.*
import com.mangalocal.model.*
import com.mangalocal.pipeline.SettingsStore
import java.io.File
import java.util.Random

val gson: Gson = GsonBuilder().create()
var seq = 0
lateinit var base: File
fun ok(n: String, c: Boolean, d: String = "") { println((if (c) "PASS " else "FAIL ") + n + (if (!c && d.isNotEmpty()) " :: $d" else "")) }
class Env(val root: File) {
    val dirMain = File(root, "files").apply { mkdirs() }
    val dirNb = File(root, "nobackup").apply { mkdirs() }
    val main = File(dirMain, SettingsStore.MAIN_NAME)
    val sec = File(dirNb, SettingsStore.SECRETS_NAME)
    fun store() = SettingsStore(main, sec)
}
fun fresh(): Env { val d = File(base, "e${seq++}"); d.mkdirs(); return Env(d) }
fun rd(f: File): String = if (f.exists()) f.readText() else ""   // tệp thiếu => chuỗi rỗng => phép kiểm thành FAIL có tên, không làm sập cả driver
fun defTree(): JsonObject = gson.toJsonTree(GenerationSettings()).asJsonObject
val D = GenerationSettings()
val MARKERS = listOf("SEC-llm-key", "SEC-vision-key", "SEC-cf-acct", "SEC-cf-token", "SEC-poll", "SEC-remote-token")
fun withSecrets(s: GenerationSettings, remember: Boolean) = s.copy(
    externalLlm = s.externalLlm.copy(apiKey = "SEC-llm-key"), visionJudgeApi = s.visionJudgeApi.copy(apiKey = "SEC-vision-key"),
    freeImage = s.freeImage.copy(cfAccountId = "SEC-cf-acct", cfApiToken = "SEC-cf-token", pollinationsKey = "SEC-poll"),
    remoteEndpoint = s.remoteEndpoint.copy(authToken = "SEC-remote-token"), rememberApiKeys = remember)
fun blank(s: GenerationSettings) = s.copy(
    externalLlm = s.externalLlm.copy(apiKey = ""), visionJudgeApi = s.visionJudgeApi.copy(apiKey = ""),
    freeImage = s.freeImage.copy(cfAccountId = "", cfApiToken = "", pollinationsKey = ""), remoteEndpoint = s.remoteEndpoint.copy(authToken = ""))
fun tree(s: GenerationSettings): JsonObject = gson.toJsonTree(s).asJsonObject
fun safeLoad(e: Env): Pair<Boolean, SettingsStore.Loaded?> = try { false to e.store().load() } catch (x: Throwable) { true to null }
fun fromTree(t: JsonObject): GenerationSettings = gson.fromJson(t, GenerationSettings::class.java)

fun main(args: Array<String>) {
    base = File(args[0]); base.mkdirs()

    // 1. lần mở đầu: không có tệp -> mặc định, không tạo tệp, không ghi chú
    run {
        val e = fresh(); val l = e.store().load()
        ok("1 không có tệp -> đúng mặc định", l.settings == D && l.notes.isEmpty() && !l.quarantined)
        ok("1b nạp không tạo tệp nào", !e.main.exists() && !e.sec.exists())
    }

    // 2. khứ hồi đủ kiểu
    run {
        val e = fresh()
        val s = D.copy(steps = 33, cfgScale = 6.25f, useOpenCL = !D.useOpenCL, sdModelId = "my_model", cancelTimeoutMs = 45_000L, thermalThreshold = 39,
            imageStyle = ImageStyle.values().last(), sdxlModelId = "sdxl_x",
            manualRoutingRules = listOf(ManualRoutingRule(value = "An", backend = GenerationBackend.REMOTE), ManualRoutingRule(value = "đêm", matchType = RoutingMatchType.KEYWORD, backend = GenerationBackend.LOCAL)),
            promptStyleOverrides = mapOf("realvis" to PromptStyle.NATURAL_LANGUAGE, "pony" to PromptStyle.TAG_BASED),
            externalLlm = D.externalLlm.copy(enabled = true, baseUrl = "https://x/v1", modelName = "m", timeoutSeconds = 90),
            remoteEndpoint = D.remoteEndpoint.copy(enabled = true, baseUrl = "https://r", timeoutSeconds = 300, pagScale = 2.5f, remoteModelType = RemoteModelType.SDXL))
        val st = e.store(); val err = st.save(s)
        ok("2 lưu thành công (không báo lỗi)", err == null, err ?: "")
        val l = e.store().load()
        ok("2b khứ hồi bằng nhau trên đủ kiểu (Int/Float/Boolean/Long/String/enum/String?/List/Map/lồng nhau)", l.settings == s, "khác: " + diff(s, l.settings))
        ok("2c khứ hồi sạch: không ghi chú", l.notes.isEmpty())
    }

    // 3. FUZZ khứ hồi
    run {
        val rnd = Random(20261027L); var bad = 0; var firstBad = ""
        for (it in 0 until 400) {
            val t = defTree(); mutate(t, rnd, 0.35)
            val s0 = fromTree(t).copy(rememberApiKeys = true)
            val e = fresh(); e.store().save(s0)
            val l = e.store().load()
            if (l.settings != s0) { bad++; if (firstBad.isEmpty()) firstBad = diff(s0, l.settings) }
            val e2 = fresh(); val s1 = s0.copy(rememberApiKeys = false); e2.store().save(s1)
            val l2 = e2.store().load()
            if (l2.settings != blank(s1)) { bad++; if (firstBad.isEmpty()) firstBad = "(không nhớ khoá) " + diff(blank(s1), l2.settings) }
        }
        ok("3 fuzz 400 cài đặt ngẫu nhiên khứ hồi đúng từng trường (cả nhớ khoá và không nhớ)", bad == 0, "$bad ca lệch, ví dụ: $firstBad")
    }

    // 4. khoá API: mặc định KHÔNG xuống đĩa
    run {
        val e = fresh(); val s = withSecrets(D.copy(steps = 25), false)
        e.store().save(s)
        val mainText = rd(e.main)
        ok("4 rememberApiKeys=false: không có tệp bí mật", !e.sec.exists())
        ok("4b rememberApiKeys=false: tệp chính không chứa marker bí mật nào", MARKERS.none { mainText.contains(it) }, MARKERS.filter { mainText.contains(it) }.toString())
        val l = e.store().load()
        ok("4c nạp lại: các khoá để trống, cài đặt khác giữ nguyên", l.settings == blank(s) && l.settings.steps == 25)
    }

    // 5. nhớ khoá: chỉ vào tệp riêng
    run {
        val e = fresh(); val s = withSecrets(D.copy(steps = 25), true)
        e.store().save(s)
        val mainText = rd(e.main); val secText = rd(e.sec)
        ok("5 rememberApiKeys=true: tệp chính vẫn KHÔNG chứa marker bí mật nào", MARKERS.none { mainText.contains(it) }, MARKERS.filter { mainText.contains(it) }.toString())
        ok("5b tệp bí mật chứa đủ 6 khoá", MARKERS.all { secText.contains(it) })
        ok("5c tệp bí mật KHÔNG chứa cài đặt thường", !secText.contains("steps") && !secText.contains("rememberApiKeys"))
        ok("5d nạp lại: bằng nhau hoàn toàn (kể cả khoá)", e.store().load().settings == s)
        ok("5e tệp chính và tệp bí mật là HAI tệp ở HAI thư mục khác nhau", e.main.parentFile != e.sec.parentFile && e.main.exists() && e.sec.exists())
    }

    // 6. tắt nhớ khoá -> xoá tệp bí mật ở lần lưu kế
    run {
        val e = fresh(); val st = e.store()
        st.save(withSecrets(D, true)); ok("6 (tiền đề) tệp bí mật có mặt", e.sec.exists())
        st.save(withSecrets(D, false))
        ok("6b tắt nhớ khoá -> tệp bí mật bị xoá", !e.sec.exists())
        ok("6c và nạp lại không còn khoá", e.store().load().settings == blank(withSecrets(D, false)))
    }

    // 7. tệp bí mật tồn tại nhưng cờ không bật -> bị bỏ qua khi nạp
    run {
        val e = fresh(); e.store().save(withSecrets(D, true))
        val t = JsonParser.parseString(e.main.readText()).asJsonObject; t.addProperty("rememberApiKeys", false); e.main.writeText(t.toString())
        val l = e.store().load()
        ok("7 cờ tắt trong tệp chính -> khoá trong tệp bí mật bị BỎ QUA", l.settings == blank(withSecrets(D, false)))
        ok("7b nạp không xoá tệp bí mật (việc xoá để lần lưu kế tiếp)", e.sec.exists())
    }

    // 8. không có khoá bí mật nào để nhớ -> không tạo tệp bí mật
    run {
        val e = fresh(); e.store().save(D.copy(rememberApiKeys = true, steps = 21))
        ok("8 nhớ khoá bật nhưng toàn khoá rỗng -> không tạo tệp bí mật", !e.sec.exists())
    }

    // 9. tệp chính hỏng
    for ((label, content) in listOf("rác" to "{{{ không phải json", "mảng" to "[1,2,3]", "rỗng" to "", "cắt dở" to "{\"steps\": 30, \"cfgSc")) {
        val e = fresh(); e.main.writeText(content)
        val (threw, l) = safeLoad(e)
        val good = !threw && l != null && l.settings == D
        ok("9 tệp chính hỏng ($label): không ném ngoại lệ và dùng mặc định", good)
        if (label != "rỗng") ok("9b ($label) tệp hỏng được đổi tên .bad và báo quarantined", l != null && l.quarantined && File(e.dirMain, SettingsStore.MAIN_NAME + ".bad").exists() && !e.main.exists())
    }

    // 10. tệp cũ thiếu khoá -> mặc định THẬT (không phải 0)
    run {
        val e = fresh(); e.main.writeText("{\"steps\": 30, \"externalLlm\": {\"baseUrl\": \"http://h\"}}")
        val l = e.store().load()
        ok("10 khoá có trong tệp được dùng", l.settings.steps == 30 && l.settings.externalLlm.baseUrl == "http://h")
        ok("10b khoá thiếu lấy mặc định thật (cfgScale=7, không phải 0; thermalThreshold=42)", l.settings.cfgScale == D.cfgScale && l.settings.thermalThreshold == D.thermalThreshold && D.cfgScale != 0f)
        ok("10c trường lồng nhau thiếu cũng lấy mặc định (timeoutSeconds=60, không phải 0)", l.settings.externalLlm.timeoutSeconds == D.externalLlm.timeoutSeconds && D.externalLlm.timeoutSeconds != 0)
        ok("10d phần còn lại bằng mặc định", l.settings == D.copy(steps = 30, externalLlm = D.externalLlm.copy(baseUrl = "http://h")))
    }

    // 11. khoá lạ + null bị bỏ qua
    run {
        val e = fresh(); e.main.writeText("{\"khoaDaXoa\": 5, \"steps\": null, \"cfgScale\": 5.5, \"_v\": 1}")
        val l = e.store().load()
        ok("11 khoá lạ và null không gây lỗi; khoá hợp lệ vẫn dùng", l.settings == D.copy(cfgScale = 5.5f))
    }

    // 12. sai kiểu: Gson im lặng chấp nhận nhưng SAI NGHĨA -> phải giữ mặc định
    run {
        val e = fresh(); e.main.writeText("{\"useOpenCL\": \"abc\", \"steps\": 1.5, \"sdModelId\": 42, \"panelCount\": \"7\", \"cfgScale\": \"x\", \"externalLlm\": 5, \"freeImage\": {\"cfModel\": 3}}")
        val l = e.store().load()
        ok("12 chuỗi vào Boolean (Gson đọc thành false) -> giữ mặc định", l.settings.useOpenCL == D.useOpenCL)
        ok("12b 1.5 vào Int (Gson cắt còn 1) -> giữ mặc định", l.settings.steps == D.steps, "steps=" + l.settings.steps)
        ok("12c số vào String, chuỗi vào Int/Float, số vào đối tượng -> giữ mặc định", l.settings.sdModelId == D.sdModelId && l.settings.panelCount == D.panelCount && l.settings.cfgScale == D.cfgScale && l.settings.externalLlm == D.externalLlm)
        ok("12d sai kiểu ở trường lồng nhau -> giữ mặc định của trường đó", l.settings.freeImage == D.freeImage)
        ok("12e và tất cả đều được ghi chú", listOf("useOpenCL", "steps", "sdModelId", "panelCount", "cfgScale", "externalLlm", "cfModel").count { k -> l.notes.any { it.contains(k) } } >= 6, l.notes.toString())
        ok("12f nạp trọn vẹn bằng mặc định", l.settings == D)
    }

    // 13. số nguyên tràn Int -> chỉ bỏ khoá đó
    run {
        val e = fresh(); e.main.writeText("{\"steps\": 99999999999, \"cfgScale\": 4.5, \"panelCount\": 9}")
        val l = e.store().load()
        ok("13 Int tràn: bỏ đúng khoá đó, GIỮ các khoá khác", l.settings.steps == D.steps && l.settings.cfgScale == 4.5f && l.settings.panelCount == 9, "steps=${l.settings.steps} cfg=${l.settings.cfgScale} panel=${l.settings.panelCount}")
        ok("13b có ghi chú về khoá bị bỏ", l.notes.any { it.contains("steps") })
    }

    // 13b2. Gson NÉM lỗi (mảng chứa phần tử sai cấu trúc; kiểm kiểu bằng chữ cho phép vì cùng là mảng) -> chỉ bỏ đúng khoá đó, giữ khoá khác
    run {
        val e = fresh(); e.main.writeText("{\"manualRoutingRules\": [5, \"x\"], \"steps\": 31, \"cfgScale\": 4.5}")
        val l = e.store().load()
        ok("13d mảng sai cấu trúc làm Gson ném lỗi: bỏ đúng khoá đó, GIỮ các khoá khác", l.settings.manualRoutingRules.isEmpty() && l.settings.steps == 31 && l.settings.cfgScale == 4.5f, "rules=${l.settings.manualRoutingRules} steps=${l.settings.steps}")
        ok("13e và có ghi chú nêu đúng khoá", l.notes.any { it.contains("manualRoutingRules") }, l.notes.toString())
    }

    // 13c. số thực nhiều chữ số do người dùng gõ tay: nhận, KHÔNG bị đánh oan là "Gson đổi nghĩa" (Float chỉ giữ ~7 chữ số)
    run {
        val e = fresh(); e.main.writeText("{\"cfgScale\": 5.123456789, \"steps\": 24}")
        val l = e.store().load()
        ok("13c số thực nhiều chữ số được nhận (Float làm tròn bình thường), không có ghi chú, khoá khác giữ", l.settings.cfgScale == 5.123456789f && l.settings.steps == 24 && l.notes.isEmpty(), "cfg=${l.settings.cfgScale} notes=${l.notes}")
    }

    // 14. enum đổi tên -> mặc định, không phải null
    run {
        val e = fresh(); e.main.writeText("{\"imageStyle\": \"KIEU_DA_BI_XOA\", \"steps\": 28, \"remoteEndpoint\": {\"remoteModelType\": \"MOI_BI_XOA\", \"baseUrl\": \"https://r\"}}")
        val l = e.store().load()
        // CHÚ Ý: `(x as Any?) != null` trên thuộc tính không-null bị kotlinc gấp thành hằng true => kiểm vô nghĩa. Dùng Objects.isNull (lời gọi Java, không gấp được) và gọi thật phương thức.
        ok("14 enum không còn tồn tại -> mặc định (KHÔNG null thật)", !java.util.Objects.isNull(l.settings.imageStyle) && l.settings.imageStyle == D.imageStyle)
        ok("14b enum lồng nhau cũng vậy, các khoá khác giữ", !java.util.Objects.isNull(l.settings.remoteEndpoint.remoteModelType) && l.settings.remoteEndpoint.remoteModelType == D.remoteEndpoint.remoteModelType && l.settings.remoteEndpoint.baseUrl == "https://r" && l.settings.steps == 28)
        ok("14c có ghi chú", l.notes.isNotEmpty())
        // và dùng được thật (gọi phương thức trên enum — NPE nếu là null; bắt lại để thành FAIL chứ không làm sập cả driver)
        val use1 = try { l.settings.imageStyle.stylePrompt.isNotEmpty() } catch (x: Throwable) { false }
        val use2 = try { l.settings.remoteEndpoint.remoteModelType.name.isNotEmpty() } catch (x: Throwable) { false }
        ok("14d dùng được: gọi thuộc tính/phương thức của cả hai enum đã nạp", use1 && use2)
    }

    // 14e. enum LỒNG NHAU đổi tên mà KHÔNG có khoá cấp cao nào hỏng. (Ở ca 14 có khoá cấp cao hỏng nên cây được nạp lại lần hai và việc đó vô tình chữa luôn
    //      enum lồng nhau — lớp cấu hình có hàm khởi tạo rỗng nên khoá thiếu lấy mặc định Kotlin — che mất việc fillMissing đệ quy có hoạt động hay không.)
    run {
        val e = fresh(); e.main.writeText("{\"remoteEndpoint\": {\"remoteModelType\": \"MOI_BI_XOA\", \"baseUrl\": \"https://q\"}}")
        val l = e.store().load()
        val use = try { l.settings.remoteEndpoint.remoteModelType.name.isNotEmpty() } catch (x: Throwable) { false }
        ok("14e enum lồng nhau đổi tên (không khoá cấp cao nào hỏng): vẫn về mặc định, không null, khoá khác giữ", !java.util.Objects.isNull(l.settings.remoteEndpoint.remoteModelType) && use && l.settings.remoteEndpoint.remoteModelType == D.remoteEndpoint.remoteModelType && l.settings.remoteEndpoint.baseUrl == "https://q")
    }

    // 15. Map/List: bản đã lưu thay hẳn
    run {
        val e = fresh(); val st = e.store()
        st.save(D.copy(promptStyleOverrides = mapOf("a" to PromptStyle.TAG_BASED, "b" to PromptStyle.NATURAL_LANGUAGE)))
        st.save(D.copy(promptStyleOverrides = mapOf("a" to PromptStyle.TAG_BASED)))
        ok("15 xoá một mục Map rồi lưu: nạp lại không sống lại mục đã xoá", e.store().load().settings.promptStyleOverrides == mapOf("a" to PromptStyle.TAG_BASED))
        st.save(D.copy(manualRoutingRules = emptyList()))
        ok("15b List rỗng sau khi từng có phần tử vẫn rỗng", e.store().load().settings.manualRoutingRules.isEmpty())
    }

    // 16. hàm overlay thuần: các quy tắc đã ghi
    run {
        fun j(s: String) = JsonParser.parseString(s)
        val o = SettingsStore.Companion
        ok("16 overlay: đối tượng KHÔNG rỗng được trộn từng khoá", o.overlay(j("{\"x\":1,\"y\":2}"), j("{\"x\":5}")) == j("{\"x\":5,\"y\":2}"))
        ok("16b overlay: đối tượng RỖNG (Map) bị thay hẳn", o.overlay(j("{}"), j("{\"a\":2}")) == j("{\"a\":2}"))
        ok("16c overlay: mảng thay hẳn", o.overlay(j("[1,2,3]"), j("[9]")) == j("[9]"))
        ok("16d overlay: null bị bỏ qua", o.overlay(j("5"), JsonNull.INSTANCE) == null)
        ok("16e overlay: Int mặc định không nhận số thực, Float mặc định nhận số nguyên", o.overlay(j("20"), j("1.5")) == null && o.overlay(j("7.0"), j("7")) != null)
        ok("16f overlay: số âm nguyên hợp lệ, '-' trơ trọi thì không", o.overlay(j("-3"), j("-4")) == j("-4"))
        ok("16g overlay: bool/chuỗi/số không đổi loại", o.overlay(j("true"), j("\"x\"")) == null && o.overlay(j("\"s\""), j("1")) == null && o.overlay(j("1"), j("true")) == null)
        ok("16h overlay: base vắng -> nhận nguyên", o.overlay(null, j("{\"k\":1}")) == j("{\"k\":1}"))
    }

    // 17. không ghi lại y hệt; không tạo tệp khi chưa đổi gì
    run {
        val e = fresh(); val st = e.store(); val l = st.load(); st.noteLoaded(l.settings)
        st.save(l.settings)
        ok("17 vừa nạp mặc định rồi lưu y hệt -> KHÔNG tạo tệp", !e.main.exists())
        st.save(l.settings.copy(steps = 22))
        ok("17b có thay đổi -> có tệp", e.main.exists())
        e.main.delete(); st.save(l.settings.copy(steps = 22))
        ok("17c lưu lại y hệt lần trước -> không ghi lại (đã chống ghi trùng)", !e.main.exists())
        st.save(l.settings.copy(steps = 23))
        ok("17d lại đổi -> ghi", e.main.exists() && e.store().load().settings.steps == 23)
    }

    // 18. ghi nguyên tử: không để lại tệp tạm
    run {
        val e = fresh(); val st = e.store(); st.save(withSecrets(D.copy(steps = 22), true)); st.save(withSecrets(D.copy(steps = 23), true))
        val names = (e.dirMain.list()!!.toList() + e.dirNb.list()!!.toList())
        ok("18 không còn tệp .tmp sau khi lưu", names.none { it.endsWith(".tmp") }, names.toString())
    }

    // 19. tệp bí mật hỏng
    run {
        val e = fresh(); e.store().save(withSecrets(D.copy(steps = 22), true)); e.sec.writeText("{{{")
        val (threw, l) = safeLoad(e)
        ok("19 tệp bí mật hỏng: không ném lỗi, cài đặt thường vẫn nạp, khoá để trống, có ghi chú", !threw && l != null && l.settings == blank(withSecrets(D.copy(steps = 22), true)) && l.notes.isNotEmpty())
    }

    // 20. reset
    run {
        val e = fresh(); val st = e.store(); st.save(withSecrets(D.copy(steps = 22), true)); e.main.writeText("{{{"); st.load()
        File(e.dirMain, SettingsStore.MAIN_NAME + ".tmp").writeText("x")
        val r = st.reset()
        ok("20 reset trả về mặc định", r == D)
        ok("20b reset xoá chính, bí mật, tạm và .bad", !e.main.exists() && !e.sec.exists() && !File(e.dirMain, SettingsStore.MAIN_NAME + ".bad").exists() && !File(e.dirMain, SettingsStore.MAIN_NAME + ".tmp").exists())
        st.save(withSecrets(D.copy(steps = 22), true))   // CÙNG cài đặt như trước reset: nếu bộ nhớ chống ghi trùng không bị xoá thì sẽ không ghi lại
        ok("20c sau reset, lưu lại CÙNG cài đặt như trước reset vẫn tạo lại cả hai tệp (bộ nhớ chống ghi trùng đã xoá)", e.main.exists() && e.sec.exists())
    }

    // 21. mọi đường bí mật của SECRET_PATHS tồn tại thật trong cây mặc định và là chuỗi
    run {
        val t = defTree(); var allOk = true; var why = ""
        for (p in SettingsStore.SECRET_PATHS) {
            var cur: JsonElement = t
            for (k in p) { cur = (if (cur.isJsonObject) cur.asJsonObject.get(k) else null) ?: run { allOk = false; why += p.joinToString(".") + " "; JsonNull.INSTANCE } }
            if (!cur.isJsonPrimitive || !cur.asJsonPrimitive.isString) { allOk = false; why += p.joinToString(".") + " " }
        }
        ok("21 mọi SECRET_PATHS trỏ tới một trường chuỗi có thật của GenerationSettings", allOk, why)
    }

    // 21b + 22. Danh sách mong đợi CỐ ĐỊNH (không đọc từ SECRET_PATHS — nếu không thì thiếu mục nào cũng không phát hiện được): từng đường, đặt riêng, chỉ được có trong tệp bí mật
    run {
        val EXPECTED = listOf(listOf("externalLlm", "apiKey"), listOf("visionJudgeApi", "apiKey"), listOf("freeImage", "cfAccountId"),
            listOf("freeImage", "cfApiToken"), listOf("freeImage", "pollinationsKey"), listOf("remoteEndpoint", "authToken"))
        ok("21b SECRET_PATHS khớp CHÍNH XÁC 6 đường mong đợi (không thiếu, không thừa)",
            SettingsStore.SECRET_PATHS.map { it.joinToString(".") }.toSet() == EXPECTED.map { it.joinToString(".") }.toSet() && SettingsStore.SECRET_PATHS.size == EXPECTED.size)
        for ((i, p) in EXPECTED.withIndex()) {
            val t = defTree()
            var cur = t; for (k in p.dropLast(1)) cur = cur.getAsJsonObject(k)
            cur.addProperty(p.last(), "ONLY-" + i)
            val s = fromTree(t).copy(rememberApiKeys = true)
            val e = fresh(); e.store().save(s)
            ok("22.$i đường '${p.joinToString(".")}' chỉ có trong tệp bí mật", !rd(e.main).contains("ONLY-$i") && rd(e.sec).contains("ONLY-$i"))
        }
    }
}

fun diff(a: GenerationSettings, b: GenerationSettings): String {
    val ta = tree(a); val tb = tree(b); val out = ArrayList<String>()
    fun walk(p: String, x: JsonElement?, y: JsonElement?) {
        if (x == null && y == null) return
        if (x != null && y != null && x.isJsonObject && y.isJsonObject) { for (k in (x.asJsonObject.keySet() + y.asJsonObject.keySet())) walk("$p.$k", x.asJsonObject.get(k), y.asJsonObject.get(k)); return }
        if (x != y) out.add("$p: $x != $y")
    }
    walk("", ta, tb)
    return out.take(4).joinToString("; ")
}

fun mutate(t: JsonObject, rnd: Random, prob: Double) {
    for (k in t.keySet().toList()) {
        val v = t.get(k)
        if (v.isJsonObject) { mutate(v.asJsonObject, rnd, prob); continue }
        if (!v.isJsonPrimitive || rnd.nextDouble() > prob) continue
        val p = v.asJsonPrimitive
        when {
            p.isBoolean -> t.addProperty(k, !p.asBoolean)
            p.isNumber -> {
                val txt = p.asString
                if (txt.all { it == '-' || it.isDigit() }) t.addProperty(k, (p.asLong % 1000) + rnd.nextInt(50))
                else t.addProperty(k, Math.round(p.asDouble * (0.5 + rnd.nextDouble()) * 1000.0) / 1000.0)
            }
            p.isString -> if (k != "imageStyle" && !k.endsWith("Type") && !k.endsWith("Tier") && k != "upscaleOption" && k != "routingMode" && k != "defaultBackend" && k != "securityTier" && k != "backend")
                t.addProperty(k, p.asString + "x" + rnd.nextInt(100))
        }
    }
}
'''

ENVK = dict(os.environ, JAVA_OPTS='-Xmx2g')
def kc(srcs, cp, out):
    """kotlinc -> (thành công, đuôi stderr)."""
    r = subprocess.run([KOTLINC] + srcs + ['-cp', cp, '-d', out], capture_output=True, text=True, env=ENVK)
    return r.returncode == 0, r.stderr[-700:]
def jrun(cp, work):
    """Chạy DrvKt -> (các dòng, lỗi)."""
    klib = os.path.join(os.path.dirname(os.path.dirname(KOTLINC)), 'lib', 'kotlin-stdlib.jar')
    o = subprocess.run([JAVA, '-cp', f'{cp}:{klib}:{GSON}', 'DrvKt', work], capture_output=True, text=True, timeout=180)
    if o.returncode != 0: return None, 'run: ' + (o.stderr or o.stdout)[-600:]
    return o.stdout.strip().split('\n'), ''

STORE = os.path.join(KT, 'pipeline/SettingsStore.kt'); MODELS = os.path.join(KT, 'model/Models.kt')

# ───────── Phần tĩnh ─────────
models = rd('model/Models.kt'); vm = rd('ui/MainViewModel.kt'); store = rd('pipeline/SettingsStore.kt')
settings_ui = rd('ui/SettingsScreen.kt'); phelp = rd('ui/ParamHelp.kt')
# (a) danh sách bí mật khớp Models.kt: mọi trường tên giống key/token/secret trong các lớp cấu hình lồng phải có trong SECRET_PATHS
cfg_fields = {}
for cls in ('ExternalLlmConfig', 'FreeImageConfig', 'RemoteEndpointConfig'):
    m = re.search(r'data class ' + cls + r'\((.*?)\n\)', models, re.S)
    cfg_fields[cls] = re.findall(r'^\s*val (\w+): String', m.group(1), re.M) if m else []
use = dict(re.findall(r'val (\w+): (ExternalLlmConfig|FreeImageConfig|RemoteEndpointConfig)\s*=', models))
secretish = re.compile(r'(?i)(key|token|secret|password|accountid)')
expected = set()
for prop, cls in use.items():
    for f in cfg_fields.get(cls, []):
        if secretish.search(f): expected.add(prop + '.' + f)
m = re.search(r'val SECRET_PATHS: List<List<String>> = listOf\((.*?)\n        \)', store, re.S)
declared = {'.'.join(re.findall(r'"(\w+)"', x)) for x in re.findall(r'listOf\(([^)]*)\)', m.group(1))} if m else set()
check('tĩnh: SECRET_PATHS == mọi trường chuỗi tên giống key/token/secret/accountId trong các lớp cấu hình lồng của Models.kt', declared == expected and len(expected) == 6, f'khai báo={sorted(declared)} mong đợi={sorted(expected)}')
check('tĩnh: có trường rememberApiKeys (Boolean, mặc định false) trong GenerationSettings', re.search(r'val rememberApiKeys: Boolean = false', models) is not None)
# (b)+(c) nối dây ViewModel / UI / trợ giúp — định nghĩa MỘT lần, dùng cho cả kiểm thật lẫn thử phá mã (mối nối gỡ ra PHẢI làm ít nhất một kiểm đỏ)
def wiring(vm, ui, ph):
    return {
        'ViewModel tạo SettingsStore với filesDir (tệp chính) và noBackupFilesDir (tệp bí mật)': re.search(r'SettingsStore\(\s*java\.io\.File\(app\.filesDir, SettingsStore\.MAIN_NAME\),\s*java\.io\.File\(app\.noBackupFilesDir, SettingsStore\.SECRETS_NAME\)', vm) is not None,
        '_settings khởi tạo từ cài đặt ĐÃ NẠP, không còn GenerationSettings() trần': 'MutableStateFlow(GenerationSettings())' not in vm and re.search(r'_settings\s*=\s*MutableStateFlow\(\s*loadedSettings\.settings\s*\)', vm) is not None,
        'noteLoaded được gọi ngay sau khi nạp (không ghi lại y hệt)': re.search(r'settingsStore\.load\(\)\.also\s*\{\s*settingsStore\.noteLoaded\(it\.settings\)', vm) is not None,
        'lưu có DEBOUNCE bằng collectLatest + delay, chạy trên Dispatchers.IO': re.search(r'_settings\.collectLatest\s*\{[^}]*kotlinx\.coroutines\.delay\(\d+\)[^}]*withContext\(Dispatchers\.IO\)[^}]*settingsStore\.save', vm, re.S) is not None,
        'init áp lại ngưỡng nhiệt từ cài đặt đã nạp (ThermalMonitor tạo với mặc định)': re.search(r'init \{.*?thermalMonitor\.updateThreshold\(_settings\.value\.thermalThreshold\)', vm, re.S) is not None,
        'có hàm resetSettings() gọi settingsStore.reset() và cập nhật _settings': re.search(r'fun resetSettings\(\)\s*\{[^}]*settingsStore\.reset\(\)[^}]*_settings\.value\s*=', vm, re.S) is not None,
        'tệp hỏng được báo cho người dùng qua _error': re.search(r'if \(loadedSettings\.quarantined\) _error\.value\s*=', vm) is not None,
        'Cài đặt có công tắc rememberApiKeys (HelpSwitch) nối vào cài đặt': re.search(r'HelpSwitch\(helpKey = "rememberApiKeys", checked = settings\.rememberApiKeys, onCheckedChange = \{ vm\.updateSettings \{ copy\(rememberApiKeys = it\) \} \}', ui) is not None,
        'nút khôi phục mặc định gọi vm.resetSettings()': 'vm.resetSettings()' in ui,
        'ParamHelp có mục rememberApiKeys với mặc định "Tắt"': re.search(r'"rememberApiKeys" to e\(\s*(?:"[^\n]*\n\s*){4}"Tắt",\s*"Không mã hoá', ph) is not None,
    }
W = wiring(vm, settings_ui, phelp)
for k, v in W.items(): check('tĩnh: ' + k, v)
wm = [
    ('bỏ noBackupFilesDir cho tệp bí mật', 'vm', 'java.io.File(app.noBackupFilesDir, SettingsStore.SECRETS_NAME)', 'java.io.File(app.filesDir, SettingsStore.SECRETS_NAME)'),
    ('_settings quay lại GenerationSettings() trần', 'vm', 'MutableStateFlow(loadedSettings.settings)', 'MutableStateFlow(GenerationSettings())'),
    ('bỏ noteLoaded', 'vm', 'settingsStore.noteLoaded(it.settings)', 'Unit'),
    ('bỏ debounce (delay)', 'vm', 'kotlinx.coroutines.delay(400)', 'Unit'),
    ('lưu trên luồng chính (bỏ Dispatchers.IO)', 'vm', 'withContext(Dispatchers.IO) { settingsStore.save(s) }', 'settingsStore.save(s)'),
    ('bỏ áp lại ngưỡng nhiệt ở init', 'vm', '        thermalMonitor.updateThreshold(_settings.value.thermalThreshold)\n        if (loadedSettings.notes', '        if (loadedSettings.notes'),
    ('resetSettings không gọi reset()', 'vm', 'val fresh = settingsStore.reset()', 'val fresh = GenerationSettings()'),
    ('bỏ báo tệp hỏng', 'vm', 'if (loadedSettings.quarantined) _error.value =', 'if (false) _error.value ='),
    ('công tắc không nối cài đặt', 'ui', 'onCheckedChange = { vm.updateSettings { copy(rememberApiKeys = it) } }', 'onCheckedChange = { }'),
    ('nút khôi phục không gọi resetSettings', 'ui', 'vm.resetSettings(); showResetConfirm = false', 'showResetConfirm = false'),
    ('ParamHelp mặc định sai', 'ph', '"Tắt",\n            "Không mã hoá', '"Bật",\n            "Không mã hoá'),
]
for name, which, a_, b_ in wm:
    src = {'vm': vm, 'ui': settings_ui, 'ph': phelp}[which]
    if a_ not in src: check(f'thử phá nối dây "{name}": mẫu có trong mã', False, 'không thấy mẫu'); continue
    mut = src.replace(a_, b_, 1)
    W2 = wiring(mut if which == 'vm' else vm, mut if which == 'ui' else settings_ui, mut if which == 'ph' else phelp)
    check(f'thử phá nối dây "{name}" bị bắt', not all(W2.values()))
stale = [p for p in ('ui/SettingsScreen.kt', 'ui/ParamHelp.kt', 'ui/HelpScreen.kt', 'model/Models.kt') if re.search(r'như mọi cài đặt hiện tại|chưa lưu cài đặt qua lần mở sau|app chưa lưu cài đặt|đóng app là mất \(', rd(p))]
check('tĩnh: không còn câu sai cũ "mọi cài đặt chỉ ở bộ nhớ / đóng app là mất" ở UI/trợ giúp/Models', not stale, str(stale))
hd = open(os.path.join(ROOT, 'HUONG_DAN_SU_DUNG.md'), encoding='utf-8').read()
check('tĩnh: HUONG_DAN_SU_DUNG.md: câu sai cũ "Thông tin đăng nhập chỉ nằm trong bộ nhớ" đã bỏ; có mục 7.0 và nút "Nhớ khoá API"', 'Thông tin đăng nhập chỉ nằm trong bộ nhớ' not in hd and '### 7.0. Cài đặt có được lưu không' in hd and 'Nhớ khoá API trên máy này' in hd)

# (d) tên trường phải ổn định giữa các bản build: SECRET_PATHS và khoá JSON đã lưu dựa vào tên trường thật. R8 đổi tên trường -> khoá lệch -> mất cài đặt VÀ khoá API có thể lọt vào tệp chính.
gradle = open(os.path.join(ROOT, 'app/build.gradle'), encoding='utf-8').read()
pro = open(os.path.join(ROOT, 'app/proguard-rules.pro'), encoding='utf-8').read()
minify_off = re.search(r'release\s*\{[^}]*minifyEnabled\s+false', gradle, re.S) is not None
keep_all = re.search(r'^-keep class com\.mangalocal\.\*\* \{ \*; \}', pro, re.M) is not None
check('tĩnh: tên trường GenerationSettings ổn định giữa các bản build (release không minify HOẶC proguard giữ nguyên com.mangalocal.**)', minify_off or keep_all, f'minify_off={minify_off} keep_all={keep_all}')

# ───────── Phần chạy thật ─────────
if os.environ.get('SETTINGS_TEST_STATIC_ONLY'):
    print('BỎ QUA phần chạy thật (SETTINGS_TEST_STATIC_ONLY=1) — chỉ chạy kiểm tĩnh')
elif not (KOTLINC and GSON and JAVA):
    print('SKIP phần chạy thật: thiếu kotlinc / gson jar / java')
else:
    import hashlib, json
    tmp = tempfile.mkdtemp()
    CACHE = os.environ.get('SETTINGS_TEST_CACHE')   # chỉ để chạy tiếp khi bị ngắt giữa chừng; mặc định KHÔNG dùng
    if CACHE: os.makedirs(CACHE, exist_ok=True)
    models_dir = os.path.join(tmp, 'models_out'); store_dir = os.path.join(tmp, 'store_out'); drv_jar = os.path.join(tmp, 'drv.jar')
    os.makedirs(os.path.join(tmp, 'drv'), exist_ok=True); drv_kt = os.path.join(tmp, 'drv', 'Drv.kt'); open(drv_kt, 'w', encoding='utf-8').write(DRV)
    s1, e1 = kc([MODELS], GSON, models_dir)
    s2, e2 = kc([STORE], f'{GSON}:{models_dir}', store_dir) if s1 else (False, 'bỏ qua')
    s3, e3 = kc([drv_kt], f'{GSON}:{models_dir}:{store_dir}', drv_jar) if s2 else (False, 'bỏ qua')
    check('Models.kt, SettingsStore.kt và driver biên dịch (kotlinc thật, Gson 2.10.1 thật)', s1 and s2 and s3, 'compile: ' + e1 + e2 + e3)
    if s1 and s2 and s3:
        base_cp = f'{drv_jar}:{store_dir}:{models_dir}'
        lines, err = jrun(base_cp, os.path.join(tmp, 'work_real'))
        check('driver chạy xong trên mã thật', lines is not None, err)
        if lines is not None:
            for l in lines:
                if l.startswith('PASS ') or l.startswith('FAIL '):
                    print(l); ok &= l.startswith('PASS ')
            nreal = sum(1 for l in lines if l[:4] in ('PASS', 'FAIL'))
            check('driver in đủ số phép kiểm (>= 60)', nreal >= 60, str(nreal))
            # ───────── Thử phá mã (mỗi đột biến PHẢI biên dịch được; sống sót = lỗ hổng của test) ─────────
            # Lớp đột biến đứng TRƯỚC trong classpath nên che lớp SettingsStore gốc; driver chỉ biên dịch một lần (mọi đột biến giữ nguyên chữ ký công khai).
            src = open(STORE, encoding='utf-8').read()
            MUTS = [
                ('bool: nhận mọi loại', 'bp.isBoolean -> if (sp.isBoolean) sp.deepCopy() else null', 'bp.isBoolean -> sp.deepCopy()'),
                ('số nguyên nhận số thực', 'isIntegralText(bp.asString) && !isIntegralText(sp.asString) -> null', 'false -> null'),
                ('chuỗi nhận mọi loại', 'bp.isString -> if (sp.isString) sp.deepCopy() else null', 'bp.isString -> sp.deepCopy()'),
                ('mảng không bao giờ lấy bản đã lưu', 'if (base.isJsonArray) return if (saved.isJsonArray) saved.deepCopy() else null', 'if (base.isJsonArray) return base.deepCopy()'),
                ('đối tượng lồng nhau: thay hẳn thay vì trộn', 'val out = b.deepCopy()\n                for ((k, v) in saved.asJsonObject.entrySet()) {', 'val out = JsonObject()\n                for ((k, v) in saved.asJsonObject.entrySet()) {'),
                ('base vắng: bỏ giá trị đã lưu', 'if (base == null || base.isJsonNull) return saved.deepCopy()', 'if (base == null || base.isJsonNull) return null'),
                ('fillMissing không bao giờ bù', 'fun fillMissing(def: JsonObject, got: JsonObject): Boolean {\n            var changed = false', 'fun fillMissing(def: JsonObject, got: JsonObject): Boolean {\n            if (def.size() >= 0) return false\n            var changed = false'),
                ('fillMissing không đệ quy', 'if (fillMissing(dv.asJsonObject, gv.asJsonObject)) changed = true', 'changed = changed'),
                ('bỏ lọc từng khoá khi Gson không đọc được', 'if (tryParse(cand) != null) safe.add(k, v.deepCopy())', 'if (true) safe.add(k, v.deepCopy())'),
                ('bỏ phát hiện Gson đổi nghĩa âm thầm (tràn/cắt)', 'findCoerced(merged, check0, "", coerced)', 'coerced.clear()'),
                ('so số thực quá chặt (đánh oan số nhiều chữ số)', 'Math.abs(x.toDouble() - y.toDouble()) <= 1e-6 * maxOf(1.0, Math.abs(x.toDouble()), Math.abs(y.toDouble()))', 'x.compareTo(y) == 0'),
                ('tệp bí mật ghi dù cờ tắt', 'if (s.rememberApiKeys && hasAnySecret(secrets)) {\n                val sText', 'if (hasAnySecret(secrets)) {\n                val sText'),
                ('tắt cờ không xoá tệp bí mật', 'if (secretsFile.exists()) secretsFile.delete()\n                lastSecretsText = null', 'lastSecretsText = null'),
                ('nạp bí mật dù cờ tắt', 'if (remember && secretsFile.isFile) {', 'if (secretsFile.isFile) {'),
                ('không đổi tên tệp hỏng', 'if (!f.renameTo(bad)) f.delete()', 'f.exists()'),
                ('không báo quarantined khi parse lỗi', 'quarantine(mainFile); quarantined = true\n                notes.add("${mainFile.name}: không đọc được', 'quarantine(mainFile)\n                notes.add("${mainFile.name}: không đọc được'),
                ('noteLoaded không ghi nhớ', 'lastMainText = gson.toJson(tree)\n        lastSecretsText = if', 'lastSecretsText = if'),
                ('luôn ghi tệp chính (không chống ghi trùng)', 'if (mainText != lastMainText) {', 'if (true) {'),
                ('reset không xoá .bad', ',\n            File(mainFile.parentFile, mainFile.name + ".bad"))) {', '\n            )) {'),
                ('reset không xoá bộ nhớ chống ghi trùng', 'lastMainText = null; lastSecretsText = null\n        return GenerationSettings()', 'return GenerationSettings()'),
                ('lưu bí mật vào tệp chính (không rút)', 'val secrets = extractSecrets(tree)\n            tree.addProperty(VERSION_KEY, FORMAT_VERSION)\n            val mainText', 'val secrets = JsonObject()\n            tree.addProperty(VERSION_KEY, FORMAT_VERSION)\n            val mainText'),
                ('rút bí mật: bỏ qua khoá cuối cùng', 'val v = parent.get(last) ?: continue\n                parent.remove(last)', 'val v = parent.get(last) ?: continue'),
                ('hasAnySecret luôn đúng', 'fun hasAnySecret(secrets: JsonObject): Boolean {', 'fun hasAnySecret(secrets: JsonObject): Boolean {\n            if (secrets.size() >= 0) return true'),
                ('bỏ ghi chú khoá bị bỏ qua', 'else notes.add("bỏ qua \'$k\': kiểu giá trị không khớp bản hiện tại")', ''),
            ] + [(f'SECRET_PATHS thiếu mục {i}', '            listOf("' + p_[0] + '", "' + p_[1] + '")', '') for i, p_ in enumerate([('externalLlm', 'apiKey'), ('visionJudgeApi', 'apiKey'), ('freeImage', 'cfAccountId'), ('freeImage', 'cfApiToken'), ('freeImage', 'pollinationsKey'), ('remoteEndpoint', 'authToken')])]
            caught = 0; total = 0; notcompile = []; survived = []; missing = []
            for i, (name, a_, b_) in enumerate(MUTS):
                if a_ not in src: missing.append(name); continue
                mut = src.replace(a_, b_, 1)
                if name.startswith('SECRET_PATHS thiếu'):   # bỏ một mục thì dọn dấu phẩy để còn biên dịch được
                    mut = re.sub(r',\n\s*,', ',\n', mut); mut = mut.replace('(\n,', '(\n').replace(',\n        )', '\n        )')
                key = hashlib.sha1((mut + DRV).encode('utf-8')).hexdigest()
                cf = os.path.join(CACHE, key + '.json') if CACHE else None
                if cf and os.path.exists(cf):
                    res = json.load(open(cf, encoding='utf-8'))
                else:
                    md = os.path.join(tmp, f'mut{i}'); os.makedirs(md, exist_ok=True)
                    mp = os.path.join(md, 'SettingsStore.kt'); open(mp, 'w', encoding='utf-8').write(mut)
                    mout = os.path.join(tmp, f'mut{i}_out')
                    cs, ce = kc([mp], f'{GSON}:{models_dir}', mout)
                    if not cs: res = {'status': 'nocompile', 'why': ce[-300:]}
                    else:
                        ml, me = jrun(f'{mout}:{base_cp}', os.path.join(tmp, f'mut{i}_work'))
                        if ml is None: res = {'status': 'caught', 'why': 'lỗi lúc chạy: ' + me[-200:]}   # khác biệt hành vi quan sát được
                        elif any(l.startswith('FAIL ') for l in ml) or sum(1 for l in ml if l[:4] in ('PASS', 'FAIL')) < nreal:
                            res = {'status': 'caught', 'why': next((l for l in ml if l.startswith('FAIL ')), 'thiếu phép kiểm')[:160]}
                        else: res = {'status': 'survived', 'why': ''}
                    if cf: json.dump(res, open(cf, 'w', encoding='utf-8'), ensure_ascii=False)
                total += 1
                print(f'  [{i + 1}/{len(MUTS)}] {res["status"]:9} {name}' + (f'  <- {res["why"][:90]}' if res['status'] == 'caught' else ''), flush=True)
                if res['status'] == 'nocompile': notcompile.append(name)
                elif res['status'] == 'caught': caught += 1
                else: survived.append(name)
            check('thử phá mã: mọi mẫu đột biến còn khớp mã nguồn (mã đổi thì phải cập nhật test)', not missing, str(missing))
            check('thử phá mã: mọi đột biến đều BIÊN DỊCH được (đột biến không biên dịch không tính là bắt)', not notcompile, str(notcompile))
            check(f'thử phá mã: {caught}/{total} đột biến bị bắt', not survived and caught == total and total >= 26, 'SỐNG SÓT: ' + str(survived))
    shutil.rmtree(tmp, ignore_errors=True)

print('\nKẾT QUẢ:', 'ĐẠT' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
