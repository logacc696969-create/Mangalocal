"""
pose_lora_merge.py — mục 119 TECHNICAL_STATUS.md, "Pose-Specific LoRA
Injection" (Composition LoRA). Merge 1 LoRA .safetensors ĐƯỢC TRAIN RIÊNG
cho bố cục/tư thế (vd train trên nhiều ảnh "2 người vật nhau", "2 người ôm
nhau" — KHÔNG phải LoRA nhân vật) trực tiếp vào trọng số UNet TRƯỚC khi
export, CHỈ áp vào down_blocks (đúng nguyên lý đã dùng ở lora_block_weight.py
— down_blocks ảnh hưởng bố cục/trang phục/nền, up_blocks+mid_block ảnh
hưởng chi tiết khuôn mặt/đặc trưng nhận dạng riêng từng người).

TẠI SAO CHỈ down_blocks (không phải cả UNet):
- Composition LoRA huấn luyện trên NHIỀU người khác nhau trong tư thế đó —
  nếu merge cả up_blocks/mid_block, đặc trưng khuôn mặt của NHỮNG NGƯỜI
  TRONG TẬP TRAIN LoRA đó có thể "tràn" vào, làm nhoè/lệch khuôn mặt nhân
  vật thật của user (đúng hiện tượng "Identity Bleeding" đã ghi trong
  lora_block_weight.py, cùng gốc nguyên lý, khác chiều: ở đây là bố cục
  TRUYỀN vào nhân vật, không phải nhân vật TRUYỀN vào nhau).
- Chỉ cần down_blocks vì đó là nơi quyết định BỐ CỤC/DÁNG NGƯỜI tổng thể
  (theo nguyên lý cộng đồng SD đã ghi nhận — không phải số liệu khoa học
  chính xác, cần tinh chỉnh thực nghiệm).

KHÁC BIỆT với lora_block_weight.py: file đó SCALE lại chính các layer của
1 LoRA nhân vật (chuẩn bị trước khi ghép NHIỀU LoRA nhân vật ở runtime/
on-device qua SafeTensor2MNN.hpp). File NÀY merge TRỰC TIẾP 1 LoRA bố cục
vào TRỌNG SỐ GỐC của UNet tại thời điểm EXPORT (Python, offline) — vĩnh
viễn "nướng" (bake) vào .mnn xuất ra, không phải merge động lúc chạy.

NGUYÊN LÝ MERGE (chuẩn LoRA, kohya_ss key naming — đã tra cứu khớp với quy
ước dùng trong SafeTensor2MNN.hpp/lora_block_weight.py của chính dự án):
    W' = W + (alpha / rank) * (lora_up @ lora_down) * user_scale
- alpha/rank đọc từ chính metadata trong file .safetensors nếu có (khoá
  "{prefix}.alpha"), mặc định = rank nếu thiếu (tương đương hệ số 1.0,
  đúng quy ước kohya khi alpha không được ghi kèm).
- user_scale: hệ số TỔNG do user tự chọn khi chạy tool này (mặc định 0.7 —
  KHÔNG phải 1.0, vì đây là merge TĨNH vĩnh viễn vào UNet dùng cho MỌI
  panel, không phải theo từng ảnh như IP-Adapter — cường độ cao dễ làm bố
  cục cứng nhắc, lặp lại y hệt giữa các panel dùng cùng model đã bake).

CHƯA BUILD-TEST — cần 1 file LoRA composition thật (user tự train qua
kohya_ss hoặc công cụ tương đương, KHÔNG có sẵn trong dự án) để chạy thử.
Logic name-mapping kohya->PyTorch module path đã tra cứu đúng quy ước
chuẩn (thay "." bằng "_", thêm tiền tố "lora_unet_") nhưng CHƯA xác nhận
khớp 100% với MỌI biến thể LoRA cộng đồng (một số tool train LoRA đặt tên
hơi khác, vd kèm ".processor" hoặc thứ tự block khác) — nếu chạy báo
"0 layer nào khớp", đó là dấu hiệu cần kiểm tra lại tên khoá thật trong
file .safetensors của bạn (dùng safetensors.safe_open để liệt kê khoá).

Cài đặt:
    pip install safetensors torch diffusers

Chạy (merge rồi lưu UNet đã bake, dùng thay --base_model cho các script
export_ipa_controlnet_*.py khác):
    python pose_lora_merge.py --base_model runwayml/stable-diffusion-v1-5 \\
        --pose_lora composition_combat.safetensors --scale 0.7 \\
        --output_dir ./unet_with_pose_lora
"""
import argparse
import os

import torch
from safetensors.torch import load_file


def build_kohya_key_to_module_map(unet: torch.nn.Module) -> dict:
    """Xây bảng tra XUÔI: với MỌI submodule có `.weight` (Linear/Conv2d —
    ứng viên hợp lệ cho LoRA) trong cây UNet thật, tính tên kohya TƯƠNG ỨNG
    của nó (thay "." bằng "_", thêm tiền tố "lora_unet_") rồi map ngược lại
    module đó. Đây là hướng AN TOÀN — chiều "path có dấu chấm" -> "tên nối
    gạch dưới" LUÔN không mơ hồ (chỉ cần str.replace), khác hẳn chiều NGƯỢC
    LẠI (chuỗi gạch dưới -> path) vốn KHÔNG THỂ giải mã đúng bằng regex đơn
    thuần khi tên thuộc tính PyTorch thật (vd "to_q", "attn1") CŨNG chứa
    dấu gạch dưới/số dính liền — bản đầu tiên của file này dùng regex đoán
    ranh giới token, đã tự phát hiện SAI qua test (vd "attn1_to_q" bị hiểu
    nhầm 1 cụm, "mid_block_attentions" không tách được vì không có số ở
    ranh giới) trước khi đưa vào dùng — viết lại bằng cách này để loại bỏ
    hoàn toàn kiểu đoán mù đó."""
    mapping = {}
    for name, module in unet.named_modules():
        if hasattr(module, "weight") and isinstance(module, (torch.nn.Linear, torch.nn.Conv2d)):
            kohya_key = "lora_unet_" + name.replace(".", "_")
            mapping[kohya_key] = module
    return mapping


def merge_pose_lora_into_unet(unet: torch.nn.Module, lora_path: str, scale: float = 0.7,
                               block_scope: str = "down_blocks") -> int:
    """Merge TRỰC TIẾP (in-place) vào trọng số unet. Trả về số layer đã
    merge thành công — GỌI NƠI DÙNG PHẢI TỰ KIỂM TRA > 0 (đúng khuôn mẫu
    n_wrapped==0 check đã dùng trong export_ipa_controlnet_unet.py, KHÔNG
    im lặng bỏ qua lỗi)."""
    tensors = load_file(lora_path)
    kohya_to_module = build_kohya_key_to_module_map(unet)

    # Gom cặp (lora_down, lora_up) theo tiền tố khoá chung, đúng quy ước
    # kohya_ss ".lora_down.weight" / ".lora_up.weight" / ".alpha" (KHỚP
    # ĐÚNG tên đã dùng trong SafeTensor2MNN.hpp của chính dự án — không tự
    # nghĩ ra quy ước khác).
    prefixes = set()
    for k in tensors:
        if k.endswith(".lora_down.weight"):
            prefixes.add(k[: -len(".lora_down.weight")])

    merged_count = 0
    skipped_wrong_scope = 0
    skipped_not_found = 0
    for prefix in prefixes:
        if block_scope not in prefix:
            skipped_wrong_scope += 1
            continue
        down_key = prefix + ".lora_down.weight"
        up_key = prefix + ".lora_up.weight"
        alpha_key = prefix + ".alpha"
        if up_key not in tensors:
            continue  # thiếu nửa cặp — file lỗi/không đầy đủ, bỏ qua an toàn

        target = kohya_to_module.get(prefix)
        if target is None:
            skipped_not_found += 1
            continue

        down = tensors[down_key].float()
        up = tensors[up_key].float()
        rank = down.shape[0]
        alpha = float(tensors[alpha_key]) if alpha_key in tensors else float(rank)
        effective_scale = (alpha / rank) * scale

        with torch.no_grad():
            base_weight = target.weight
            if down.dim() == 2:  # Linear layer (attention q/k/v/out)
                delta = (up @ down) * effective_scale
            else:  # Conv2d layer (down.shape = [rank, in_ch, kH, kW] hoặc tương tự)
                up2 = up.view(up.shape[0], up.shape[1])
                down2 = down.view(down.shape[0], -1)
                delta = (up2 @ down2).view(base_weight.shape) * effective_scale
            if delta.shape != base_weight.shape:
                skipped_not_found += 1
                continue
            base_weight.add_(delta.to(base_weight.dtype).to(base_weight.device))
        merged_count += 1

    print(f"pose_lora_merge: đã merge {merged_count} layer trong phạm vi '{block_scope}' "
          f"(bỏ qua {skipped_wrong_scope} layer ngoài phạm vi, {skipped_not_found} layer "
          f"không khớp tên module — nếu số này CAO BẤT THƯỜNG so với merged_count, "
          f"kiểm tra lại tên khoá thật trong file LoRA của bạn).")
    return merged_count


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="runwayml/stable-diffusion-v1-5")
    ap.add_argument("--pose_lora", required=True, help="Đường dẫn file .safetensors LoRA bố cục/tư thế")
    ap.add_argument("--scale", type=float, default=0.7,
                     help="Hệ số merge TỔNG (0-1+, mặc định 0.7 — merge TĨNH vĩnh viễn, không phải per-ảnh)")
    ap.add_argument("--block_scope", default="down_blocks",
                     help="Chỉ merge layer có tên khớp cụm này (mặc định down_blocks — bố cục, không phải nhận dạng)")
    ap.add_argument("--output_dir", default="./unet_with_pose_lora")
    args = ap.parse_args()

    from diffusers import StableDiffusionPipeline
    print(f"Đang tải base UNet từ {args.base_model}...")
    pipe = StableDiffusionPipeline.from_pretrained(args.base_model, torch_dtype=torch.float32, safety_checker=None)

    n = merge_pose_lora_into_unet(pipe.unet, args.pose_lora, scale=args.scale, block_scope=args.block_scope)
    if n == 0:
        raise RuntimeError(
            "merge_pose_lora_into_unet() không merge được layer nào — hoặc file LoRA sai "
            "định dạng (không phải kohya_ss chuẩn), hoặc --block_scope không khớp tên khoá "
            "thật trong file. KHÔNG bỏ qua lỗi này (im lặng bỏ qua sẽ export ra UNet KHÔNG "
            "có tác dụng gì từ pose LoRA mà không ai biết)."
        )

    os.makedirs(args.output_dir, exist_ok=True)
    pipe.unet.save_pretrained(os.path.join(args.output_dir, "unet"))
    print(f"Đã lưu UNet đã bake pose LoRA vào {args.output_dir}/unet — "
          f"dùng đường dẫn này thay cho --base_model gốc ở các script export_ipa_controlnet_*.py khác.")


if __name__ == "__main__":
    main()
