#!/usr/bin/env python3
# mục 271 — biểu ngữ "hết hạn mức MIỄN PHÍ trong ngày" (đóng giới hạn của 267.3). KIỂM TĨNH NỐI DÂY (không có kotlinc): một nguồn sự thật cho cụm từ nhận diện,
# thông báo bỏ cuộc của HttpRetryPolicy thật sự chứa cụm đó, log() đếm đúng, PipelineState có bộ đếm mặc định 0, UI hiện MỘT biểu ngữ khi > 0.
# Kèm mô phỏng thuần Python của phép đếm (chạy trên các thông báo dựng đúng như Kotlin) và phép thử phá mã.
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
def rd(rel): return open(os.path.join(K, rel), encoding='utf-8').read()
fails = []
def check(c, name):
    print(('PASS ' if c else 'FAIL ') + name)
    if not c: fails.append(name)

def static_checks(pol, models, mp, ui):
    r = []
    m = re.search(r'const val DAILY_QUOTA_MARKER = "([^"]+)"', pol)
    marker = m.group(1) if m else None
    r.append(('HttpRetryPolicy có hằng DAILY_QUOTA_MARKER', marker is not None))
    r.append(('thông báo bỏ cuộc hết hạn mức NGÀY dựng từ chính hằng đó (một nguồn sự thật)', 'Decision.GiveUp("Đã $DAILY_QUOTA_MARKER — thử lại vào ngày mai' in pol))
    r.append(('nhánh GiveUp hạn mức ngày chỉ khi 429 + isDailyQuotaExhausted', 'if (code == 429 && isDailyQuotaExhausted(body)) {\n            return Decision.GiveUp("Đã $DAILY_QUOTA_MARKER' in pol))
    r.append(('PipelineState.dailyQuotaHits: Int mặc định 0', re.search(r'val dailyQuotaHits: Int = 0\n\) \{', models) is not None))
    r.append(('log() đếm dòng chứa cụm nhận diện và cộng dồn', 'val quotaHit = if (msg.contains(HttpRetryPolicy.DAILY_QUOTA_MARKER)) 1 else 0' in mp and 'dailyQuotaHits = it.dailyQuotaHits + quotaHit' in mp))
    r.append(('log() vẫn ghi dòng log như cũ', 'log = it.log + LogEntry(time(), msg, lvl)' in mp))
    r.append(('UI: đúng MỘT biểu ngữ, chỉ khi dailyQuotaHits > 0', ui.count('state.dailyQuotaHits > 0) item {') == 1))
    r.append(('UI: biểu ngữ hiện số lần ghi nhận', '${state.dailyQuotaHits} lần ghi nhận' in ui))
    r.append(('bộ đếm được đặt lại mỗi lượt (PipelineState mới ở lúc bắt đầu chạy)', '_state.update { PipelineState(startTimeMs = startMs) }' in mp))
    # nơi nuốt lỗi LLM vẫn ghi ex.message qua log() (thông báo mang cụm nhận diện đi qua đó)
    r.append(('stagePromptFallback ghi ex.message qua log()', re.search(r'private fun stagePromptFallback\(stage: String, ex: Exception\) \{[^}]*log\([^)]*\$\{ex\.message\}', mp, re.S) is not None))
    r.append(('lỗi RuntimeException của HttpRetryExec nối lý do bỏ cuộc (chứa cụm nhận diện) vào thông báo', 'throw RuntimeException(HttpRetryPolicy.failureMessage(a.code, bodyText) + " — " + decision.reason)' in rd('pipeline/HttpRetryExec.kt')))
    return r, marker

def simulate(marker, messages):
    # bản Python của: hits += 1 nếu msg chứa marker (đúng như MangaPipeline.log)
    hits = 0
    for msg in messages: hits += 1 if marker in msg else 0
    return hits

POL, MODELS, MP, UI = rd('pipeline/HttpRetryPolicy.kt'), rd('model/Models.kt'), rd('pipeline/MangaPipeline.kt'), rd('ui/GeneratingScreen.kt')
res, marker = static_checks(POL, MODELS, MP, UI)
for n, ok in res: check(ok, n)
if marker:
    reason = f'Đã {marker} — thử lại vào ngày mai (hoặc chọn nhà cung cấp/nguồn khác)'
    thrown = 'Bị giới hạn tần suất/hạn mức (429): {"error":"quota"} — ' + reason   # như HttpRetryExec: failureMessage + " — " + reason
    swallowed = f'  ⚠ Dịch prompt cho bước upscale lỗi ({thrown}) — dùng lại prompt gốc của panel; kết quả bước này có thể kém hơn'
    check(marker in thrown and marker in swallowed, 'thông báo thật (ném lên và bị nuốt/ghi log) đều chứa cụm nhận diện')
    msgs = [swallowed] * 12 + ['✓ Panel 1 xong', 'Bị giới hạn tần suất (429): thử lại lần 2/4 sau 3 giây', '❌ Lỗi mạng (không kết nối được)']
    check(simulate(marker, msgs) == 12, 'mô phỏng: 12 cảnh báo cùng loại + 3 dòng khác -> bộ đếm = 12 (một biểu ngữ), không đếm 429 thường/lỗi mạng')
    check(simulate(marker, ['Bị giới hạn tần suất/hạn mức (429) — đã thử 4 lần vẫn lỗi']) == 0, '429 thường (chưa hết hạn mức ngày) KHÔNG bật biểu ngữ')

muts = [
 ('thông báo bỏ cuộc không dùng hằng', 'POL', 'Decision.GiveUp("Đã $DAILY_QUOTA_MARKER —', 'Decision.GiveUp("Đã hết hạn mức —'),
 ('log() không đếm', 'MP', 'dailyQuotaHits = it.dailyQuotaHits + quotaHit', 'dailyQuotaHits = it.dailyQuotaHits'),
 ('log() đếm mọi dòng', 'MP', 'if (msg.contains(HttpRetryPolicy.DAILY_QUOTA_MARKER)) 1 else 0', '1'),
 ('log() ngừng ghi dòng', 'MP', 'log = it.log + LogEntry(time(), msg, lvl)', 'log = it.log'),
 ('bộ đếm mặc định khác 0', 'MODELS', 'val dailyQuotaHits: Int = 0\n) {', 'val dailyQuotaHits: Int = 1\n) {'),
 ('UI hiện biểu ngữ vô điều kiện', 'UI', 'state.dailyQuotaHits > 0) item {', 'true) item {'),
 ('UI không hiện số lần', 'UI', '(${state.dailyQuotaHits} lần ghi nhận)', ''),
 ('stagePromptFallback bỏ ex.message', 'MP', 'Dịch prompt cho bước $stage lỗi (${ex.message})', 'Dịch prompt cho bước $stage lỗi'),
]
src = {'POL': POL, 'MODELS': MODELS, 'MP': MP, 'UI': UI}
caught = 0
for name, k, old, new in muts:
    assert old in src[k], name
    mm = dict(src); mm[k] = src[k].replace(old, new, 1)
    r2, _ = static_checks(mm['POL'], mm['MODELS'], mm['MP'], mm['UI'])
    bad = any(not ok for _, ok in r2); caught += bad
    print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name)
check(caught == len(muts), f'đột biến: {caught}/{len(muts)} bị bắt')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails))
sys.exit(1 if fails else 0)
