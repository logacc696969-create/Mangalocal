#!/usr/bin/env python3
"""mục 266 — kiểm HÀNH VI thật của vòng thử lại `HttpRetryExec` (cả biến thể suspend `execute` lẫn biến thể chặn `executeBlocking`) bằng kotlinc THẬT, với OkHttp GIẢ có kịch bản
(tools/kotlin_stubs/okhttp3_stub.kt: StubNet.script = danh sách phản hồi/IOException trả lần lượt). `test_http_retry` kiểm phần QUYẾT ĐỊNH (decide), `test_glue_typecheck` kiểm KIỂU; còn
vòng lặp ghép chúng lại — đếm lần thử, chờ đúng bao lâu, trả/ném đúng lúc, lỗi đứt giữa chừng khi đọc thân — chỉ được kiểm ở đây.

Mỗi kịch bản có kết quả mong đợi suy ra TAY từ quy tắc (không dịch từ Kotlin): số lần gọi, danh sách thời gian chờ (jitter = 0 nên tất định), mã/thân trả về hoặc đoạn thông báo ném. Hai biến thể phải cho
KẾT QUẢ GIỐNG HỆT. Thử phá mã: gỡ từng chốt của vòng lặp, bộ kiểm phải bắt.
KHÔNG chứng minh: hành vi của OkHttp thật (stub mô phỏng chữ ký), thời gian chờ thật (bộ chờ được tiêm vào để ghi lại thay vì ngủ). Cần kotlinc (không có -> SKIP).
"""
import os, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline')
STUBS = os.path.join(ROOT, 'tools/kotlin_stubs')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + str(d)[:500]) if (d and not c) else '')); ok &= bool(c)
def find():
    for c in [os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/work/kotlinc/bin/kotlinc', '/home/claude/tools_dl/kotlinc/bin/kotlinc']:
        if c and os.path.exists(c): return c
KOTLINC = find()
if not KOTLINC:
    print('SKIP: không có kotlinc'); sys.exit(0)
KLIB = os.path.join(os.path.dirname(os.path.dirname(KOTLINC)), 'lib', 'kotlin-stdlib.jar')

DRIVER = r'''
import com.mangalocal.pipeline.*
import kotlinx.coroutines.*
import okhttp3.*
import java.io.File
import kotlin.coroutines.*

fun hex(b: ByteArray): String = if (b.isEmpty()) "-" else b.joinToString("") { "%02x".format(it) }
fun unhex(h: String): ByteArray = if (h == "-") ByteArray(0) else ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

fun loadScript(items: List<String>) {
    StubNet.reset()
    for (it in items) {
        val p = it.split(":")
        when (p[0]) {
            "R" -> StubNet.script.add(StubResp(p[1].toInt(), unhex(p[3]), buildMap {
                if (p[2] != "-") put("Retry-After", p[2])
                if (p.size > 4 && p[4] != "-") put("Content-Type", p[4])
            }))
            "RD" -> StubNet.script.add(StubResp(p[1].toInt(), ByteArray(0), emptyMap(), failOnRead = true))
            "IO" -> StubNet.script.add(java.io.IOException("lỗi mạng giả " + p[1]))
        }
    }
}

fun fmt(r: Result<HttpResult>, waits: List<Long>, notes: Int): String {
    val head = r.fold(
        { "OK ${it.code} ${it.contentType ?: "?"} ${hex(it.body)}" },
        { "THROW " + hex((it.message ?: "").toByteArray(Charsets.UTF_8)) }
    )
    return head + "\t" + StubNet.calls + "\t" + waits.joinToString(",") + "\t" + notes
}

fun main(args: Array<String>) {
    val out = StringBuilder()
    val client = OkHttpClient.Builder().build()
    val req = { Request.Builder().url("http://x").get().build() }
    for (line in File(args[0]).readLines()) {
        if (line.isEmpty()) continue
        val p = line.split("\t")      // MODE \t maxAttempts \t item;item;...
        val mode = p[0]; val max = p[1].toInt(); val items = if (p.size > 2 && p[2].isNotEmpty()) p[2].split(";") else emptyList()
        loadScript(items)
        val waits = ArrayList<Long>(); var notes = 0
        val res: Result<HttpResult> = if (mode == "blocking") {
            runCatching { HttpRetryExec.executeBlocking(client, req, max, onWait = { notes++ }, sleeper = { waits.add(it) }, jitter = { 0.0 }) }
        } else {
            var rr: Result<HttpResult>? = null
            val block: suspend () -> HttpResult = { HttpRetryExec.execute(client, req, max, onWait = { notes++ }, sleeper = { waits.add(it) }, jitter = { 0.0 }) }
            block.startCoroutine(Continuation(EmptyCoroutineContext) { rr = it })
            rr ?: Result.failure(IllegalStateException("coroutine không hoàn tất"))
        }
        out.append(fmt(res, waits, notes)).append("\n")
    }
    File(args[1]).writeText(out.toString())
}
'''

def hx(s):
    b = s.encode('utf-8') if isinstance(s, str) else s
    return b.hex() if b else '-'
BODY_OK = '{"ok":true}'
DAILY = '{"success":false,"errors":[{"code":3036,"message":"You have used up your daily free allocation of 10,000 neurons"}]}'
# (tên, max, kịch bản, mong đợi)  mong đợi = ('OK', mã, ctype, thân) | ('THROW', [đoạn bắt buộc trong thông báo]) ; calls ; waits ; notes
SC = [
    ('thành công ngay', 4, [f'R:200:-:{hx(BODY_OK)}:application/json'], ('OK', 200, 'application/json', BODY_OK), 1, [], 0),
    ('429 Retry-After 0 rồi 200', 4, ['R:429:0:-', f'R:200:-:{hx(BODY_OK)}'], ('OK', 200, '?', BODY_OK), 2, [0], 1),
    ('429 rồi 503 rồi 200 (lùi cấp số, jitter 0)', 4, ['R:429:-:-', 'R:503:-:-', f'R:200:-:{hx(BODY_OK)}'], ('OK', 200, '?', BODY_OK), 3, [2000, 4000], 2),
    ('500 Retry-After 7 rồi 200 -> chờ đúng 7000', 4, ['R:500:7:-', f'R:200:-:{hx(BODY_OK)}'], ('OK', 200, '?', BODY_OK), 2, [7000], 1),
    ('401 -> trả về ngay, KHÔNG thử lại', 4, [f'R:401:-:{hx("bad key")}'], ('OK', 401, '?', 'bad key'), 1, [], 0),
    ('404 -> trả về ngay', 4, ['R:404:-:-'], ('OK', 404, '?', ''), 1, [], 0),
    ('429 hết hạn mức NGÀY -> ném ngay (không đốt hạn mức)', 4, [f'R:429:-:{hx(DAILY)}'], ('THROW', ['hết hạn mức', '429']), 1, [], 0),
    ('429 Retry-After 300 -> ném ngay (quá lâu)', 4, ['R:429:300:-'], ('THROW', ['quá lâu']), 1, [], 0),
    ('429 liên tục 4 lần -> ném sau đúng 4 lần, chờ 2000/4000/8000', 4, ['R:429:-:-'] * 4, ('THROW', ['đã thử 4 lần']), 4, [2000, 4000, 8000], 3),
    ('maxAttempts = 1 và 503 -> ném, không chờ', 1, ['R:503:-:-'], ('THROW', ['đã thử 1 lần']), 1, [], 0),
    ('lỗi mạng rồi 200', 4, ['IO:a', f'R:200:-:{hx(BODY_OK)}'], ('OK', 200, '?', BODY_OK), 2, [2000], 1),
    ('lỗi mạng 4 lần -> ném "Lỗi mạng"', 4, ['IO:a', 'IO:b', 'IO:c', 'IO:d'], ('THROW', ['Lỗi mạng', 'đã thử 4 lần']), 4, [2000, 4000, 8000], 3),
    ('ĐỨT GIỮA CHỪNG khi đọc thân (đã có mã 200) -> thử lại, KHÔNG coi là thành công với thân rỗng', 4, ['RD:200', f'R:200:-:{hx(BODY_OK)}'], ('OK', 200, '?', BODY_OK), 2, [2000], 1),
    ('thân 204 rỗng vẫn là thành công', 4, ['R:204:-:-'], ('OK', 204, '?', ''), 1, [], 0),
    ('429 daily KHÔNG kích hoạt khi thân chỉ là "per minute"', 4, ['R:429:-:' + hx('{"quotaId":"GenerateRequestsPerMinutePerProjectPerModel-FreeTier"}'), f'R:200:-:{hx(BODY_OK)}'], ('OK', 200, '?', BODY_OK), 2, [2000], 1),
]

def lines_for(mode):
    return [f'{mode}\t{mx}\t' + ';'.join(items) for _, mx, items, *_ in SC]

def verify(res_lines, mode):
    errs = []
    for (name, mx, items, exp, calls, waits, notes), line in zip(SC, res_lines):
        head, c, w, n = line.split('\t')
        ws = [int(x) for x in w.split(',')] if w else []
        if exp[0] == 'OK':
            _, code, ctype, body = exp
            parts = head.split(' ')
            want_body = hx(body)
            if not (parts[0] == 'OK' and int(parts[1]) == code and parts[3] == want_body and (ctype == '?' or parts[2] == ctype)): errs.append((mode, name, 'kết quả', head[:90]))
        else:
            if not head.startswith('THROW'): errs.append((mode, name, 'phải ném', head[:90])); continue
            msg = bytes.fromhex(head.split(' ', 1)[1]).decode('utf-8') if ' ' in head else ''
            if not all(k in msg for k in exp[1]): errs.append((mode, name, 'thông báo thiếu', msg[:120], exp[1]))
        if int(c) != calls: errs.append((mode, name, 'số lần gọi', c, calls))
        if ws != waits: errs.append((mode, name, 'thời gian chờ', ws, waits))
        if int(n) != notes: errs.append((mode, name, 'số lần onWait', n, notes))
    return errs

tmp = tempfile.mkdtemp()
def compile_(files, tag):
    d = os.path.join(tmp, tag); os.makedirs(d, exist_ok=True)
    open(os.path.join(d, 'Drv.kt'), 'w').write(DRIVER)
    jar = os.path.join(tmp, tag + '.jar')
    r = subprocess.run([KOTLINC, '-nowarn'] + files + [os.path.join(d, 'Drv.kt'), '-d', jar], capture_output=True, text=True)
    return jar, r
def run(jar, lines):
    fi = os.path.join(tmp, 'in.txt'); fo = os.path.join(tmp, 'out.txt')
    open(fi, 'w').write('\n'.join(lines) + '\n')
    r = subprocess.run(['java', '-cp', f'{jar}:{KLIB}', 'DrvKt', fi, fo], capture_output=True, text=True)
    if r.returncode != 0: return None, r.stderr[-500:]
    return open(fo, encoding='utf-8').read().split('\n')[:len(lines)], ''

SRC = ['MiniJson.kt', 'HttpRetryPolicy.kt', 'HttpRetryExec.kt']
STUB_FILES = [os.path.join(STUBS, 'okhttp3_stub.kt'), os.path.join(STUBS, 'coroutines_stub.kt')]
jar, r = compile_(STUB_FILES + [os.path.join(KT, f) for f in SRC], 'orig')
check('HttpRetryExec.kt biên dịch với OkHttp giả có kịch bản', r.returncode == 0, r.stderr[-700:])
if r.returncode != 0:
    print('CÓ LỖI'); sys.exit(1)
ALL = lines_for('blocking') + lines_for('suspend')
res, err = run(jar, ALL)
check('chạy driver', res is not None, err)
n = len(SC)
errs = (verify(res[:n], 'blocking') + verify(res[n:], 'suspend')) if res else [('run', err)]
check(f'{n} kịch bản × 2 biến thể (chặn / suspend): đúng số lần gọi, thời gian chờ, kết quả/thông báo, số lần onWait', not errs, errs[:4])
check('hai biến thể cho KẾT QUẢ GIỐNG HỆT nhau trên mọi kịch bản', res is not None and res[:n] == res[n:], [i for i in range(n) if res and res[i] != res[n + i]][:3])

# ---------- thử phá mã ----------
base = open(os.path.join(KT, 'HttpRetryExec.kt'), encoding='utf-8').read()
MUT = [
    ('lỗi đứt giữa chừng khi đọc thân bị coi là thành công', "code = HttpRetryPolicy.NETWORK_ERROR   // lỗi giữa chừng", "val unused = 0   // lỗi giữa chừng"),
    ('không tăng số lần thử (vòng lặp vô hạn trên cùng một lần)', 'sleeper(step.delayMs)\n                    attempt++\n                }\n            }\n        }\n    }\n\n    /** Như', 'sleeper(step.delayMs)\n                }\n            }\n        }\n    }\n\n    /** Như'),
    ('bỏ qua thời gian chờ chính sách (chờ 0)', 'Step.Wait(decision.delayMs)', 'Step.Wait(0L)'),
    ('lỗi tạm thời hết cách vẫn TRẢ về thay vì ném', 'if (!HttpRetryPolicy.isRetryable(a.code)) Step.Done(HttpResult(a.code, a.contentType, a.bytes))\n                else throw', 'if (true) Step.Done(HttpResult(a.code, a.contentType, a.bytes))\n                else throw'),
    ('lỗi vĩnh viễn (401) bị ném thay vì trả về', 'if (!HttpRetryPolicy.isRetryable(a.code)) Step.Done', 'if (false) Step.Done'),
    # (đột biến "chỉ coi 200 là thành công" là TƯƠNG ĐƯƠNG: mã 2xx khác 200 rơi xuống nhánh decide -> không đáng thử lại -> vẫn được trả nguyên vẹn; nên không đưa vào danh sách)
    ('thành công nhưng làm mất thân phản hồi', 'if (a.code in 200..299) return Step.Done(HttpResult(a.code, a.contentType, a.bytes))', 'if (a.code in 200..299) return Step.Done(HttpResult(a.code, a.contentType, ByteArray(0)))'),
    ('không truyền maxAttempts cho chính sách', 'HttpRetryPolicy.decide(a.code, a.retryAfter, bodyText, attempt, maxAttempts,', 'HttpRetryPolicy.decide(a.code, a.retryAfter, bodyText, attempt, 4,'),
    ('không gọi onWait', 'onWait(decision.reason)\n                Step.Wait', 'Step.Wait'),
    ('mất Retry-After (đọc nhầm header)', 'retryAfter = resp.header("Retry-After")', 'retryAfter = resp.header("Retry-After-X")'),
    ('mất Content-Type', 'contentType = resp.header("Content-Type")', 'contentType = null'),
    ('biến thể chặn không chờ theo bộ chờ được tiêm', 'sleeper: (Long) -> Unit = { Thread.sleep(it) },\n        jitter: () -> Double = { Math.random() }\n    ): HttpResult {\n        var attempt = 1\n        while (true) {\n            when (val step = nextStep(attemptOnce(client, build), attempt, maxAttempts, jitter(), onWait)) {\n                is Step.Done -> return step.result\n                is Step.Wait -> {\n                    sleeper(step.delayMs)', 'sleeper: (Long) -> Unit = { Thread.sleep(it) },\n        jitter: () -> Double = { Math.random() }\n    ): HttpResult {\n        var attempt = 1\n        while (true) {\n            when (val step = nextStep(attemptOnce(client, build), attempt, maxAttempts, jitter(), onWait)) {\n                is Step.Done -> return step.result\n                is Step.Wait -> {\n                    Thread.sleep(0)'),
]
lo, hi = 0, len(MUT)
if os.environ.get('MUT_RANGE'):
    a, b = os.environ['MUT_RANGE'].split(':'); lo, hi = int(a), int(b)
MUT_ROOT = os.path.join(ROOT, 'tools', '.mut_tmp_http_retry_exec')
import atexit
atexit.register(lambda: shutil.rmtree(MUT_ROOT, ignore_errors=True))
killed = ran = 0
for i in range(lo, min(hi, len(MUT))):
    name, old, new = MUT[i]
    if base.count(old) != 1:
        check(f'đột biến {i} có điểm cắm duy nhất ({name})', False, f'{base.count(old)} chỗ'); continue
    # LƯU Ý (đã đo, mục 266.8): kotlinc 1.9.10 SẬP ở bước hạ IR coroutine (AddContinuationLowering.retargetToSuspendView) khi bản sao của HttpRetryExec.kt nằm NGOÀI cây repo
    # (cả /tmp lẫn thư mục khác), kể cả bản KHÔNG đột biến; nằm TRONG repo (hoặc sửa tại chỗ) thì biên dịch bình thường. Nên bản đột biến đặt trong thư mục tạm của repo,
    # luôn dọn ở cuối (và khi thoát) để không lọt vào bản đóng gói.
    md = os.path.join(MUT_ROOT, f'm{i}'); os.makedirs(md, exist_ok=True)
    mutated = os.path.join(md, 'HttpRetryExec.kt')
    open(mutated, 'w', encoding='utf-8').write(base.replace(old, new))
    files = [os.path.join(KT, 'MiniJson.kt'), os.path.join(KT, 'HttpRetryPolicy.kt'), mutated]
    j, rr = compile_(STUB_FILES + files, f'mut{i}')
    if rr.returncode != 0:
        check(f'đột biến {i} biên dịch được ({name})', False, rr.stderr[-300:]); continue
    ran += 1
    res2, e2 = run(j, ALL)
    survived = res2 is not None and not (verify(res2[:n], 'blocking') + verify(res2[n:], 'suspend')) and res2[:n] == res2[n:]
    check(f'đột biến "{name}" bị bộ kiểm bắt', not survived)
    killed += (not survived)
shutil.rmtree(MUT_ROOT, ignore_errors=True)
check('thư mục đột biến tạm đã được dọn (không lọt vào bản đóng gói)', not os.path.exists(MUT_ROOT))
if ran: check(f'thử phá mã: {killed}/{ran} đột biến bị bắt', killed == ran)
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
