#!/usr/bin/env python3
"""mục 261 — kiểm thử `sd_engine/LoraCompose.hpp` (LoRA Switch / Composite) bằng C++ THẬT, đối chiếu CÔNG THỨC CỦA BÀI.

Bài: Zhong et al., Multi-LoRA Composition for Image Generation (arXiv 2402.16843), đọc toàn văn.
  (4)  i = floor(((t-1) mod (k*tau)) / tau) + 1                         -> LoRA Switch
  (5)  eps = (1/k) * sum_i w_i * [eps_i(z) + s*(eps_i(z,c) - eps_i(z))] -> LoRA Composite (w_i = 1)
Kiểm: lịch Switch khớp công thức (4) cho nhiều (k, tau, T); mỗi LoRA nhận ĐÚNG số bước; ca tay k=2,tau=5; Composite khớp công thức (5)
(trộn đầu ra batch [uncond,cond] rồi áp CFG == trung bình các điểm đã áp CFG — kiểm bằng đại số số học); tập con kết hợp (mục 5.1.2);
trọng số hỏng; giới hạn số UNet phụ; trạng thái toàn cục; nối dây Pipeline/JNI/Kotlin; THỬ PHÁ MÃ.
KHÔNG chứng minh: chất lượng ảnh (chưa chạy model thật), cũng không chứng minh MNN chạy được 2 UNet cùng lúc ở máy thật (chỉ biên dịch được).
"""
import os, re, struct, subprocess, sys, tempfile, shutil, math
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JNI = os.path.join(ROOT, 'app/src/main/jni')
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
ok = True
def check(name, cond, detail=''):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + detail) if (detail and not cond) else ''))
    ok &= bool(cond)

TEST_CPP = r'''
#include "LoraCompose.hpp"
#include <cstdio>
#include <cstdlib>
#include <string>
// cmd=plan : in = int32 k, tau, m, T, nw, float w[nw] -> out: với mỗi step 0..T-1: [n, idx..., fac...] (float)
// cmd=blend: in = int32 n, J, float fac[J], float outs[J*n] -> out n
// cmd=state: in = int32 act, tau, nextra, (mỗi path: int32 len, bytes), int32 nw, float w[nw] -> out [active, active_count, tau, nextra_kept, w...]
int main(int argc, char **argv) {
  if (argc < 4) return 2;
  std::string cmd = argv[1];
  FILE *f = std::fopen(argv[2], "rb"); if (!f) return 3;
  std::vector<float> out;
  auto rdi = [&](int &v) { return std::fread(&v, 4, 1, f) == 1; };
  if (cmd == "plan") {
    int k, tau, m, T, nw;
    if (!rdi(k) || !rdi(tau) || !rdi(m) || !rdi(T) || !rdi(nw)) return 4;
    std::vector<float> w(nw);
    if (nw && std::fread(w.data(), 4, nw, f) != (size_t)nw) return 5;
    for (int s = 0; s < T; ++s) {
      auto a = lora_compose::activeSet(s, k, tau, m);
      auto fc = lora_compose::factors(a, w);
      out.push_back((float)a.size());
      for (int i : a) out.push_back((float)i);
      for (float x : fc) out.push_back(x);
    }
  } else if (cmd == "blend") {
    int n, J;
    if (!rdi(n) || !rdi(J)) return 4;
    std::vector<float> fac(J), outs((size_t)J * n);
    if (std::fread(fac.data(), 4, J, f) != (size_t)J || std::fread(outs.data(), 4, outs.size(), f) != outs.size()) return 5;
    std::vector<const float *> p;
    for (int j = 0; j < J; ++j) p.push_back(outs.data() + (size_t)j * n);
    out.assign(n, 0.0f);
    lora_compose::blend(p, fac, (size_t)n, out.data());
  } else if (cmd == "state") {
    int act, tau, ne, nw;
    if (!rdi(act) || !rdi(tau) || !rdi(ne)) return 4;
    std::vector<std::string> paths;
    for (int i = 0; i < ne; ++i) { int len; if (!rdi(len)) return 4; std::string s(len, ' '); if (len && std::fread(&s[0], 1, len, f) != (size_t)len) return 5; paths.push_back(s); }
    if (!rdi(nw)) return 4;
    std::vector<float> w(nw);
    if (nw && std::fread(w.data(), 4, nw, f) != (size_t)nw) return 5;
    loraComposeSet(act, tau, paths, w);
    LoraComposeState st;
    bool a = lora_compose::snapshot(st);
    out.push_back(a ? 1.0f : 0.0f); out.push_back((float)st.active_count); out.push_back((float)st.tau); out.push_back((float)st.extra_unets.size());
    loraComposeClear();
    LoraComposeState st2;
    out.push_back(lora_compose::snapshot(st2) ? 1.0f : 0.0f);
  }
  else if (cmd == "fields") {
    int k, mw, mh, lw, lh, nw;
    if (!rdi(k) || !rdi(mw) || !rdi(mh) || !rdi(lw) || !rdi(lh) || !rdi(nw)) return 4;
    std::vector<float> w(nw), m((size_t)std::max(k, 0) * std::max(mw, 0) * std::max(mh, 0));
    if (nw && std::fread(w.data(), 4, nw, f) != (size_t)nw) return 5;
    if (!m.empty() && std::fread(m.data(), 4, m.size(), f) != m.size()) return 5;
    out = lora_compose::regionalFields(m, k, mw, mh, lw, lh, w);
  } else if (cmd == "blendr") {
    int hw, planes, J;
    if (!rdi(hw) || !rdi(planes) || !rdi(J)) return 4;
    std::vector<float> fl((size_t)J * hw), outs((size_t)J * planes * hw);
    if (std::fread(fl.data(), 4, fl.size(), f) != fl.size() || std::fread(outs.data(), 4, outs.size(), f) != outs.size()) return 5;
    std::vector<const float *> po, pf;
    for (int j = 0; j < J; ++j) { po.push_back(outs.data() + (size_t)j * planes * hw); pf.push_back(fl.data() + (size_t)j * hw); }
    out.assign((size_t)planes * hw, 0.0f);
    lora_compose::blendRegional(po, pf, (size_t)hw, (size_t)planes, out.data());
  } else if (cmd == "smasks") {
    int doc, k, w, h, n;
    if (!rdi(doc) || !rdi(k) || !rdi(w) || !rdi(h) || !rdi(n)) return 4;
    std::vector<float> m(n);
    if (n && std::fread(m.data(), 4, n, f) != (size_t)n) return 5;
    if (doc) loraComposeSet(1, 5, {"/a", "/b"}, {});
    loraComposeSetMasks(m.empty() ? nullptr : m.data(), k, w, h);
    auto peek = [&]() { std::lock_guard<std::mutex> lk(g_lora_compose_mutex); return g_lora_compose; };  // đọc TRỰC TIẾP, không qua snapshot
    LoraComposeState st = peek();
    out.push_back(st.active ? 1.0f : 0.0f); out.push_back((float)st.mask_k); out.push_back((float)st.mask_w); out.push_back((float)st.mask_h);
    out.push_back((float)st.masks.size()); out.push_back(st.masks.empty() ? -1.0f : st.masks[0]);
    loraComposeClear();
    LoraComposeState st2 = peek();
    out.push_back((st2.active || st2.mask_k || !st2.masks.empty()) ? 1.0f : 0.0f);
    loraComposeSetMasks(m.empty() ? nullptr : m.data(), k, w, h);  // sau clear: không được tự bật lại / không để lại mask mồ côi
    LoraComposeState st3 = peek();
    out.push_back((st3.active || st3.mask_k || !st3.masks.empty()) ? 1.0f : 0.0f);
  }
  else if (cmd == "sclips") {
    int doc, ne, nc;
    if (!rdi(doc) || !rdi(ne)) return 4;
    std::vector<std::string> paths, clips;
    for (int i = 0; i < ne; ++i) { int len; if (!rdi(len)) return 4; std::string x(len, ' '); if (len && std::fread(&x[0], 1, len, f) != (size_t)len) return 5; paths.push_back(x); }
    if (!rdi(nc)) return 4;
    for (int i = 0; i < nc; ++i) { int len; if (!rdi(len)) return 4; std::string x(len, ' '); if (len && std::fread(&x[0], 1, len, f) != (size_t)len) return 5; clips.push_back(x); }
    if (doc) loraComposeSet(1, 5, paths, {});
    loraComposeSetClips(clips);
    auto peek = [&]() { std::lock_guard<std::mutex> lk(g_lora_compose_mutex); return g_lora_compose; };
    LoraComposeState st = peek();
    out.push_back((float)st.extra_clips.size());
    out.push_back(st.extra_clips.size() > 0 ? (float)st.extra_clips[0].size() : -1.0f);
    out.push_back(st.extra_clips.size() > 1 ? (float)st.extra_clips[1].size() : -1.0f);
    loraComposeClear();
    out.push_back((float)peek().extra_clips.size());          // sau clear: 0
    loraComposeSetClips(clips);                                // sau clear: không được tự bật lại / để lại CLIP mồ côi
    out.push_back((float)peek().extra_clips.size());
  } else if (cmd == "condsrc") {
    int variant, n;
    if (!rdi(variant) || !rdi(n)) return 4;
    std::vector<bool> usable;
    for (int i = 0; i < n; ++i) { int v; if (!rdi(v)) return 4; usable.push_back(v != 0); }
    out.push_back((float)lora_compose::condSource(variant, usable));
  }
  std::fclose(f);
  FILE *g = std::fopen(argv[3], "wb"); if (!g) return 6;
  if (!out.empty()) std::fwrite(out.data(), 4, out.size(), g);
  std::fclose(g);
  return 0;
}
'''

def build(header_dir, tmp, tag):
    src = os.path.join(tmp, f'lc_{tag}.cpp'); exe = os.path.join(tmp, f'lc_{tag}')
    open(src, 'w').write(TEST_CPP)
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-g', '-Wall', '-Wextra', '-Werror', '-fsanitize=address,undefined',
                        '-fno-sanitize-recover=undefined', '-I', header_dir, '-I', os.path.join(JNI, 'sd_engine'), src, '-o', exe], capture_output=True, text=True)
    return exe, r

def run(exe, tmp, cmd, payload):
    fi = os.path.join(tmp, 'in.bin'); fo = os.path.join(tmp, 'out.bin')
    open(fi, 'wb').write(payload)
    r = subprocess.run([exe, cmd, fi, fo], capture_output=True, text=True)
    if r.returncode != 0: return None
    return np.fromfile(fo, dtype=np.float32)

def pk(*a):
    out = b''
    for x in a:
        out += struct.pack('<i', x) if isinstance(x, (int, np.integer)) else struct.pack('<f', x)
    return out

def parse_plan(o, T):
    steps, pos = [], 0
    for _ in range(T):
        n = int(o[pos]); pos += 1
        idx = [int(v) for v in o[pos:pos + n]]; pos += n
        fac = [float(v) for v in o[pos:pos + n]]; pos += n
        steps.append((idx, fac))
    return steps

def paper_switch(t, k, tau):  # công thức (4), t đếm từ 1, trả chỉ số 1..k
    return ((t - 1) % (k * tau)) // tau + 1

def suite(exe, tmp, quiet=False):
    bad = 0
    def chk(name, cond, detail=''):
        nonlocal bad
        if not cond: bad += 1
        if not quiet: check(name, cond, detail)
    # (4) khớp công thức bài cho nhiều cấu hình
    mism = 0; total = 0
    for k in (2, 3, 4):
        for tau in (1, 2, 3, 5, 7):
            T = 60
            o = run(exe, tmp, 'plan', pk(k, tau, 1, T, 0))
            if o is None: mism += 1; continue
            st = parse_plan(o, T)
            for t in range(1, T + 1):
                total += 1
                if st[t - 1][0] != [paper_switch(t, k, tau) - 1]: mism += 1
    chk(f'Switch (m=1) khớp công thức (4) của bài: {total} bước, k∈{{2,3,4}}, tau∈{{1,2,3,5,7}}', mism == 0, f'{mism} lệch')
    # ca tay: k=2, tau=5, 20 bước = A×5, B×5, A×5, B×5
    o = run(exe, tmp, 'plan', pk(2, 5, 1, 20, 0))
    seq = [s[0][0] for s in parse_plan(o, 20)] if o is not None else []
    chk('ca tay k=2,tau=5: AAAAA BBBBB AAAAA BBBBB', seq == [0]*5 + [1]*5 + [0]*5 + [1]*5, str(seq))
    # nhân vật đầu tiên bật TRƯỚC (bài: LoRA nhân vật đầu tiên cho kết quả tốt nhất)
    chk('LoRA số 0 (nhân vật đầu) luôn bật ở bước đầu tiên', all(parse_plan(run(exe, tmp, 'plan', pk(k, 5, 1, 1, 0)), 1)[0][0] == [0] for k in (2, 3, 4)))
    # công bằng: sau đúng 1 chu kỳ k*tau mỗi LoRA nhận đúng tau bước
    fair = True
    for k in (2, 3, 4):
        for tau in (1, 3, 5):
            o = run(exe, tmp, 'plan', pk(k, tau, 1, k * tau * 3, 0))
            cnt = np.bincount([s[0][0] for s in parse_plan(o, k * tau * 3)], minlength=k)
            fair &= bool(np.all(cnt == tau * 3))
    chk('mỗi LoRA nhận số bước bằng nhau qua các chu kỳ đầy đủ', fair)
    # Switch: hệ số 1
    o = run(exe, tmp, 'plan', pk(3, 5, 1, 10, 0))
    chk('Switch: hệ số trộn = 1', all(abs(f[0] - 1.0) < 1e-7 and len(f) == 1 for _, f in parse_plan(o, 10)))
    # Composite (m=k): mọi LoRA mỗi bước, hệ số 1/k khi w_i=1 (công thức 5)
    for k in (2, 3, 4):
        o = run(exe, tmp, 'plan', pk(k, 5, k, 12, 0))
        st = parse_plan(o, 12)
        chk(f'Composite k={k}: mọi bước dùng đủ {k} LoRA, hệ số 1/{k} (công thức 5, w_i=1)',
            all(sorted(i) == list(range(k)) and np.allclose(f, 1.0 / k, atol=1e-7) for i, f in st))
    # trọng số w_i: trung bình có trọng số, tổng hệ số = 1
    o = run(exe, tmp, 'plan', pk(3, 5, 3, 3, 3) + struct.pack('<3f', 1.0, 2.0, 1.0))
    f0 = parse_plan(o, 3)[0]
    ref = np.array([1, 2, 1], float); ref /= ref.sum()
    got = np.zeros(3)
    for i, v in zip(f0[0], f0[1]): got[i] = v
    chk('trọng số w=(1,2,1): hệ số = w/Σw, tổng = 1', np.allclose(got, ref, atol=1e-6) and abs(sum(f0[1]) - 1) < 1e-6)
    o = run(exe, tmp, 'plan', pk(2, 5, 2, 1, 2) + struct.pack('<2f', float('nan'), -3.0))
    f0 = parse_plan(o, 1)[0]
    chk('trọng số NaN/âm coi như 1 (không làm sụp nhiễu)', np.allclose(f0[1], [0.5, 0.5], atol=1e-6) and all(np.isfinite(f0[1])))
    # kết hợp (5.1.2): m=2 của k=3 -> 2 LoRA liên tiếp (vòng), mỗi LoRA xuất hiện đủ đều
    o = run(exe, tmp, 'plan', pk(3, 2, 2, 12, 0))
    st = parse_plan(o, 12)
    chk('kết hợp m=2,k=3: mỗi bước đúng 2 LoRA khác nhau, liên tiếp theo vòng', all(len(i) == 2 and i[0] != i[1] and (i[1] - i[0]) % 3 == 1 for i, _ in st))
    cnt = np.bincount([x for i, _ in st for x in i], minlength=3)
    chk('kết hợp m=2,k=3: mỗi LoRA được dùng như nhau', len(set(cnt.tolist())) == 1, str(cnt))
    chk('kết hợp: hệ số 1/m = 1/2', all(np.allclose(f, 0.5) for _, f in st))
    # biên: k=1, m ngoài khoảng, tau ngoài khoảng, step âm
    o = run(exe, tmp, 'plan', pk(1, 5, 3, 4, 0))
    chk('k=1 -> luôn chỉ UNet 0', o is not None and all(s[0] == [0] for s in parse_plan(o, 4)))
    o = run(exe, tmp, 'plan', pk(2, 0, 1, 6, 0))
    chk('tau=0 kẹp về 1 (không chia 0, đổi mỗi bước)', o is not None and [s[0][0] for s in parse_plan(o, 6)] == [0, 1, 0, 1, 0, 1])
    o = run(exe, tmp, 'plan', pk(2, 5, 99, 1, 0))
    chk('m > k kẹp về k', o is not None and sorted(parse_plan(o, 1)[0][0]) == [0, 1])
    o = run(exe, tmp, 'plan', pk(2, 5, -4, 1, 0))
    chk('m < 1 kẹp về 1', o is not None and len(parse_plan(o, 1)[0][0]) == 1)
    # (5) đại số: trộn batch [uncond,cond] rồi CFG == trung bình các điểm đã CFG
    rng = np.random.default_rng(2402)
    n = 200; J = 3; s = 7.0
    U = rng.normal(size=(J, n)).astype(np.float32); C = rng.normal(size=(J, n)).astype(np.float32)
    fac = np.full(J, 1.0 / J, np.float32)
    bu = run(exe, tmp, 'blend', pk(n, J) + fac.tobytes() + U.tobytes())
    bc = run(exe, tmp, 'blend', pk(n, J) + fac.tobytes() + C.tobytes())
    if bu is None or bc is None:
        chk('blend chạy được', False)
    else:
        mixed = bu + s * (bc - bu)
        paper = np.mean(U + s * (C - U), axis=0)  # công thức (5) với w_i = 1
        chk('Composite: CFG(trộn batch) == trung bình các điểm đã CFG (công thức 5)', np.allclose(mixed, paper, atol=1e-4), f'{np.max(np.abs(mixed - paper))}')
    fac = np.array([0.2, 0.5, 0.3], np.float32)
    X = rng.normal(size=(3, 64)).astype(np.float32)
    o = run(exe, tmp, 'blend', pk(64, 3) + fac.tobytes() + X.tobytes())
    chk('blend = Σ fac_j * out_j (khớp numpy)', o is not None and np.allclose(o, (fac[:, None] * X).sum(0), atol=1e-5))
    # trạng thái toàn cục
    def st_payload(act, tau, paths, w):
        b = pk(act, tau, len(paths))
        for p in paths:
            pb = p.encode(); b += pk(len(pb)) + pb
        return b + pk(len(w)) + struct.pack(f'<{len(w)}f', *w)
    o = run(exe, tmp, 'state', st_payload(2, 5, ['/a/unet.mnn', '/b/unet.mnn'], [1, 1, 1]))
    chk('đặt 2 UNet phụ: bật, activeCount=2, tau=5; xoá -> tắt', o is not None and list(o[:4]) == [1, 2, 5, 2] and o[4] == 0)
    o = run(exe, tmp, 'state', st_payload(9, 5, ['/a'], []))
    chk('activeCount > k kẹp về k (=2)', o is not None and o[1] == 2)
    o = run(exe, tmp, 'state', st_payload(0, 5, ['/a'], []))
    chk('activeCount < 1 kẹp về 1', o is not None and o[1] == 1)
    o = run(exe, tmp, 'state', st_payload(1, 5, [], []))
    chk('không có UNet phụ -> không bật', o is not None and o[0] == 0)
    o = run(exe, tmp, 'state', st_payload(1, 5, ['/a', ''], []))
    chk('có đường dẫn rỗng -> không bật (lời gọi hỏng)', o is not None and o[0] == 0)
    o = run(exe, tmp, 'state', st_payload(1, 5, ['/1', '/2', '/3', '/4', '/5'], []))
    chk('quá 3 UNet phụ bị cắt còn 3 (giới hạn RAM)', o is not None and o[3] == 3)
    o = run(exe, tmp, 'state', st_payload(1, 500, ['/a'], []))
    chk('tau quá lớn kẹp về 20', o is not None and o[2] == 20)

    # ---------- mục 261.11: Regional Composite ----------
    def ref_resize(src, w0, h0, w1, h1):
        src = np.clip(np.nan_to_num(src, nan=0.0), 0, 1).reshape(h0, w0).astype(np.float64)
        out = np.zeros((h1, w1))
        for y in range(h1):
            fy = (y + 0.5) * h0 / h1 - 0.5; y0 = int(np.floor(fy)); ty = fy - y0
            ya, yb = min(max(y0, 0), h0 - 1), min(max(y0 + 1, 0), h0 - 1)
            for x in range(w1):
                fx = (x + 0.5) * w0 / w1 - 0.5; x0 = int(np.floor(fx)); tx = fx - x0
                xa, xb = min(max(x0, 0), w0 - 1), min(max(x0 + 1, 0), w0 - 1)
                top = src[ya, xa] + (src[ya, xb] - src[ya, xa]) * tx; bot = src[yb, xa] + (src[yb, xb] - src[yb, xa]) * tx
                out[y, x] = top + (bot - top) * ty
        return np.clip(out, 0, 1)
    def ref_fields(masks, k, mw, mh, lw, lh, weights):
        ms = [ref_resize(masks[i * mw * mh:(i + 1) * mw * mh], mw, mh, lw, lh) for i in range(k)]
        ws = np.array([(weights[i] if i < len(weights) and weights[i] == weights[i] and 0 < weights[i] < 1e6 else 1.0) for i in range(k)], float)
        bg = ws / ws.sum()
        s_ = sum(ms); rest = np.where(s_ < 1, 1 - s_, 0.0); den = np.where(s_ > 1, s_, 1.0)
        return np.stack([(ms[i] + bg[i] * rest) / den for i in range(k)]).astype(np.float32).reshape(k, -1)
    def fields_call(masks, k, mw, mh, lw, lh, weights=()):
        return run(exe, tmp, 'fields', pk(k, mw, mh, lw, lh, len(weights)) + (struct.pack(f'<{len(weights)}f', *weights) if weights else b'') + np.asarray(masks, np.float32).tobytes())
    rng2 = np.random.default_rng(26111)
    worst = 0.0; sums_ok = True; nonneg = True; ncase = 0
    for (k, mw, mh, lw, lh) in [(2, 8, 8, 8, 8), (2, 16, 12, 8, 6), (3, 8, 8, 16, 16), (4, 6, 9, 5, 7), (2, 64, 64, 64, 64)]:
        for trial in range(4):
            masks = rng2.uniform(-0.2, 1.3, size=k * mw * mh).astype(np.float32)
            if trial == 1: masks[: mw * mh] = 0.0                                   # một vùng trống
            if trial == 2: masks[:] = np.where(rng2.uniform(size=masks.size) < 0.5, 0.0, 1.0)  # mask nhị phân, có chồng
            wts = [] if trial % 2 == 0 else [float(x) for x in rng2.uniform(0.5, 3.0, size=k)]
            o = fields_call(masks, k, mw, mh, lw, lh, wts)
            if o is None or o.size != k * lw * lh: sums_ok = False; continue
            F = o.reshape(k, -1); ncase += 1
            worst = max(worst, float(np.max(np.abs(F - ref_fields(masks, k, mw, mh, lw, lh, wts)))))
            sums_ok &= bool(np.allclose(F.sum(0), 1.0, atol=1e-5)); nonneg &= bool(F.min() >= -1e-7)
    chk(f'fields khớp numpy độc lập trên {ncase} ca (nhiều k, kích thước mask khác latent, có/không trọng số, mask ngoài [0,1])', worst < 2e-4 and ncase >= 18, f'worst={worst} ncase={ncase}')
    chk('fields: Σ_i f_i = 1 và f_i >= 0 ở MỌI pixel', sums_ok and nonneg)
    z = fields_call(np.zeros(2 * 16), 2, 4, 4, 4, 4)
    chk('không mask phủ pixel nào -> trung bình nền (0.5, 0.5) = Composite thường', z is not None and np.allclose(z, 0.5, atol=1e-6))
    zw = fields_call(np.zeros(2 * 16), 2, 4, 4, 4, 4, [1.0, 3.0])
    chk('không mask + trọng số (1,3) -> nền (0.25, 0.75)', zw is not None and np.allclose(zw.reshape(2, -1)[0], 0.25, atol=1e-6) and np.allclose(zw.reshape(2, -1)[1], 0.75, atol=1e-6))
    m1 = np.concatenate([np.ones(16), np.zeros(16)])
    o = fields_call(m1, 2, 4, 4, 4, 4)
    chk('mask 0 phủ kín, mask 1 trống -> f = (1, 0): pixel thuộc nhân vật 0 dùng hoàn toàn UNet 0', o is not None and np.allclose(o.reshape(2, -1)[0], 1.0, atol=1e-6) and np.allclose(o.reshape(2, -1)[1], 0.0, atol=1e-6))
    mo = np.concatenate([np.ones(16), np.ones(16)])
    o = fields_call(mo, 2, 4, 4, 4, 4)
    chk('hai mask cùng phủ kín (chồng nhau) -> f = (0.5, 0.5)', o is not None and np.allclose(o, 0.5, atol=1e-6))
    mp = np.concatenate([np.full(16, 0.4), np.zeros(16)])
    o = fields_call(mp, 2, 4, 4, 4, 4)
    chk('rìa mềm: mask (0.4, 0) -> f = (0.7, 0.3) (nội suy trơn giữa "thuộc vùng" và "trung bình", không nhảy cứng)', o is not None and np.allclose(o.reshape(2, -1)[0], 0.7, atol=1e-6) and np.allclose(o.reshape(2, -1)[1], 0.3, atol=1e-6))
    mv = np.concatenate([np.ones(16), np.zeros(16)]).astype(np.float32); mv[3] = np.nan
    o = fields_call(mv, 2, 4, 4, 4, 4)
    chk('mask có NaN không làm hỏng (hữu hạn, Σ=1)', o is not None and bool(np.all(np.isfinite(o))) and np.allclose(o.reshape(2, -1).sum(0), 1.0, atol=1e-5))
    chk('k < 2 hoặc sai độ dài mask -> rỗng (không sập)', run(exe, tmp, 'fields', pk(1, 4, 4, 4, 4, 0) + np.zeros(16, np.float32).tobytes()) is not None and run(exe, tmp, 'fields', pk(1, 4, 4, 4, 4, 0) + np.zeros(16, np.float32).tobytes()).size == 0)
    # blendRegional
    hw, planes, J = 30, 8, 3
    Fl = rng2.uniform(size=(J, hw)).astype(np.float32); Fl /= Fl.sum(0, keepdims=True)
    O = rng2.normal(size=(J, planes, hw)).astype(np.float32)
    o = run(exe, tmp, 'blendr', pk(hw, planes, J) + Fl.tobytes() + O.tobytes())
    ref = np.einsum('jp,jlp->lp', Fl, O)
    chk('blendRegional = Σ_j f_j(pixel) * out_j(plane,pixel) (khớp numpy, mọi plane batch×kênh)', o is not None and np.allclose(o.reshape(planes, hw), ref, atol=1e-5))
    Fu = np.full((J, hw), 1.0 / J, np.float32)
    o = run(exe, tmp, 'blendr', pk(hw, planes, J) + Fu.tobytes() + O.tobytes())
    mean = run(exe, tmp, 'blend', pk(hw * planes, J) + np.full(J, 1.0 / J, np.float32).tobytes() + O.tobytes())
    chk('trường đồng đều 1/k cho kết quả TRÙNG LoRA Composite thường (Regional là tổng quát hoá của Composite)', o is not None and mean is not None and np.allclose(o, mean, atol=1e-5))
    Fh = np.zeros((2, hw), np.float32); Fh[0, : hw // 2] = 1; Fh[1, hw // 2:] = 1
    O2 = rng2.normal(size=(2, planes, hw)).astype(np.float32)
    o = run(exe, tmp, 'blendr', pk(hw, planes, 2) + Fh.tobytes() + O2.tobytes())
    ok_half = o is not None and np.allclose(o.reshape(planes, hw)[:, : hw // 2], O2[0][:, : hw // 2], atol=1e-6) and np.allclose(o.reshape(planes, hw)[:, hw // 2:], O2[1][:, hw // 2:], atol=1e-6)
    chk('mask cứng nửa/nửa: nửa đầu lấy đúng UNet 0, nửa sau đúng UNet 1', ok_half)
    # CFG vẫn tuyến tính với trộn vùng: (trộn rồi CFG) == (CFG từng UNet rồi trộn) với trường theo pixel
    U = rng2.normal(size=(2, 4, hw)).astype(np.float32); C = rng2.normal(size=(2, 4, hw)).astype(np.float32)
    outs2 = np.stack([np.stack([U[j], C[j]]) for j in range(2)])           # (J=2, batch=2, 4, hw)
    o = run(exe, tmp, 'blendr', pk(hw, 8, 2) + Fh.tobytes() + outs2.reshape(2, 8, hw).tobytes())
    if o is not None:
        b2 = o.reshape(2, 4, hw); sc = 7.0
        mixed = b2[0] + sc * (b2[1] - b2[0])
        per = np.stack([outs2[j][0] + sc * (outs2[j][1] - outs2[j][0]) for j in range(2)])
        chk('trộn vùng rồi CFG == CFG từng UNet rồi trộn theo vùng (CFG tuyến tính nên đặt trước hay sau đều đúng)', np.allclose(mixed, np.einsum('jp,jcp->cp', Fh, per), atol=1e-4))
    else:
        chk('blendr CFG chạy được', False)
    # trạng thái toàn cục cho mask
    mk = np.concatenate([np.full(16, 1.7), np.full(16, -0.5)]).astype(np.float32)
    o = run(exe, tmp, 'smasks', pk(1, 2, 4, 4, 32) + mk.tobytes())
    chk('đặt mask khi compose đang bật: k=2, 4x4, 32 giá trị, kẹp [0,1] (1.7->1); xoá -> tắt; không tự bật lại', o is not None and list(o[:5]) == [1, 2, 4, 4, 32] and o[5] == 1.0 and o[6] == 0 and o[7] == 0, str(o))
    o = run(exe, tmp, 'smasks', pk(0, 2, 4, 4, 32) + mk.tobytes())
    chk('compose KHÔNG bật thì đặt mask bị bỏ (không rò trạng thái mồ côi)', o is not None and o[0] == 0 and o[1] == 0 and o[4] == 0, str(o))
    o = run(exe, tmp, 'smasks', pk(1, 1, 4, 4, 16) + mk[:16].tobytes())
    chk('k < 2 -> bỏ mask', o is not None and o[1] == 0 and o[4] == 0, str(o))
    o = run(exe, tmp, 'smasks', pk(1, 2, 0, 4, 0))
    chk('kích thước 0 -> bỏ mask', o is not None and o[1] == 0, str(o))

    # ---------- mục 261.14: CLIP riêng của từng LoRA ----------
    def sclips(doc, paths, clips):
        b = pk(doc, len(paths))
        for x in paths: xb = x.encode(); b += pk(len(xb)) + xb
        b += pk(len(clips))
        for x in clips: xb = x.encode(); b += pk(len(xb)) + xb
        return run(exe, tmp, 'sclips', b)
    o = sclips(1, ['/a/unet.mnn', '/b/unet.mnn'], ['/a/clip.mnn', ''])
    chk('đặt CLIP riêng (2 phụ: "/a/clip.mnn" và "" = dùng CLIP chính): giữ đúng độ dài từng phần tử; xoá -> 0; không tự bật lại', o is not None and list(o) == [2, 11, 0, 0, 0], str(o))
    o = sclips(1, ['/a/unet.mnn', '/b/unet.mnn'], ['/a/clip.mnn'])
    chk('số CLIP khác số UNet phụ -> bỏ hết (không gán lệch biến thể)', o is not None and o[0] == 0, str(o))
    o = sclips(0, ['/a/unet.mnn'], ['/a/clip.mnn'])
    chk('compose KHÔNG bật thì đặt CLIP bị bỏ (không rò trạng thái mồ côi)', o is not None and o[0] == 0, str(o))
    def condsrc(v, usable):
        return run(exe, tmp, 'condsrc', pk(v, len(usable)) + b''.join(pk(int(u)) for u in usable))
    cs = {(0, (1, 1)): -1, (1, (1, 0)): 0, (1, (1, 1)): 0, (2, (1, 0)): -1, (2, (1, 1)): 1, (3, (1, 1)): -1, (-1, (1, 1)): -1, (1, ()): -1}
    okc = all((lambda r: r is not None and int(r[0]) == want)(condsrc(v, u)) for (v, u), want in cs.items())
    chk('condSource: UNet chính -> điều kiện chính; phụ i -> điều kiện phụ i-1 nếu mã hoá được, không thì rơi về chính; ngoài khoảng -> chính', okc)
    return bad

tmp = tempfile.mkdtemp()
HDR = os.path.join(JNI, 'sd_engine')
exe, r = build(HDR, tmp, 'real')
check('LoraCompose.hpp biên dịch sạch (-Wall -Wextra -Werror, ASan+UBSan)', r.returncode == 0, r.stderr[-800:])
if r.returncode == 0:
    check('bộ kiểm chạy trên header THẬT: 0 lỗi', suite(exe, tmp) == 0)
    src = open(os.path.join(HDR, 'LoraCompose.hpp'), encoding='utf-8').read()
    mutants = [
        ('công thức 4 sai (mod k+tau thay vì k*tau)', 'return (step % (k * tau)) / tau;', 'return (step % (k + tau)) / tau;'),
        ('đổi mỗi bước (bỏ chia tau)', 'return (step % (k * tau)) / tau;', 'return step % k;'),
        ('đổi bậc: bắt đầu từ LoRA cuối', 'return (step % (k * tau)) / tau;', 'return k - 1 - (step % (k * tau)) / tau;'),
        ('Composite hệ số không chuẩn hoá', 'for (auto& v : f) v = (float)(v / sum);', ''),
        ('chuẩn hoá chia nhầm', 'for (auto& v : f) v = (float)(v / sum);', 'for (auto& v : f) v = (float)(v / (sum + 1.0));'),
        ('chấp nhận trọng số âm/NaN', 'if (cand == cand && cand > 0.0f && cand < 1e6f) w = cand;', 'w = cand;'),
        ('bỏ kẹp m trên', 'm = m < 1 ? 1 : (m > k ? k : m);', 'm = m < 1 ? 1 : m;'),
        ('tập con không quay vòng', 'out.push_back((first + j) % k);', 'out.push_back(first + j);'),
        ('blend dùng hệ số sai chỉ số', 'acc += fac[j] * outs[j][i];', 'acc += fac[0] * outs[j][i];'),
        ('không kẹp tau', 'inline int clampTau(int tau) { return tau < kMinTau ? kMinTau : (tau > kMaxTau ? kMaxTau : tau); }', 'inline int clampTau(int tau) { return tau; }'),
        ('không cắt số UNet phụ', 'extra_unets.begin() + std::min<std::size_t>(extra_unets.size(), lora_compose::kMaxExtras));', 'extra_unets.end());'),
        ('Regional: bỏ chuẩn hoá khi tổng mask > 1', 'const float denom = s > 1.0f ? s : 1.0f;', 'const float denom = 1.0f;'),
        ('Regional: nền không chia đều', '(m[(std::size_t)i][p] + bg[(std::size_t)i] * rest) / denom', '(m[(std::size_t)i][p] + 0.0f * bg[(std::size_t)i] * rest) / denom'),
        ('Regional: phần dư đảo dấu', 'const float rest = s < 1.0f ? 1.0f - s : 0.0f;', 'const float rest = s < 1.0f ? s : 0.0f;'),
        ('Regional: bỏ chuẩn hoá trọng số nền', 'for (auto& v : bg) v = (float)(v / bsum);', ''),
        ('blendRegional dùng trường sai biến thể', 'acc += fields[j][p] * outs[j][off + p];', 'acc += fields[0][p] * outs[j][off + p];'),
        ('blendRegional chỉ xử lý plane 0', 'acc += fields[j][p] * outs[j][off + p];', 'acc += fields[j][p] * outs[j][p];'),
        ('SetMasks không kẹp [0,1]', 'for (auto& v : g_lora_compose.masks) v = occ_cfg::clamp01(v);', ''),
        ('SetMasks không kiểm compose đang bật', 'if (!g_lora_compose.active || !masks ||', 'if (!masks ||'),
        ('condSource bỏ kiểm CLIP riêng dùng được', 'return (i < usable.size() && usable[i]) ? (int)i : -1;', 'return (i < usable.size()) ? (int)i : -1;'),
        ('condSource lệch chỉ số (variant thay vì variant-1)', 'const std::size_t i = (std::size_t)variant - 1;', 'const std::size_t i = (std::size_t)variant;'),
        ('SetClips không kiểm số lượng', 'if (!g_lora_compose.active || clips.size() != g_lora_compose.extra_unets.size()) return;', 'if (!g_lora_compose.active) return;'),
        ('SetClips gỡ ĐỒNG THỜI hai chốt (bật + số lượng; riêng chốt "bật" là tương đương vì compose tắt thì số UNet phụ cũng 0)', 'if (!g_lora_compose.active || clips.size() != g_lora_compose.extra_unets.size()) return;', ''),
        ('chấp nhận đường dẫn rỗng', 'if (p.empty()) return;  // đường dẫn rỗng = lời gọi hỏng -> không bật (an toàn)', '(void)p;'),
    ]
    caught = 0
    lo, hi = (int(x) for x in os.environ.get('MUT_RANGE', '0:999').split(':'))
    mutants = [m_ for k_, m_ in enumerate(mutants) if lo <= k_ < hi]
    for name, old, new in mutants:
        if old not in src:
            check(f'đột biến "{name}": mẫu có trong mã', False, 'mẫu không còn khớp — cập nhật test'); continue
        tag = 'mut_' + re.sub(r'\W', '_', name); md = os.path.join(tmp, tag); os.makedirs(md, exist_ok=True)
        open(os.path.join(md, 'LoraCompose.hpp'), 'w', encoding='utf-8').write(src.replace(old, new, 1))
        mexe, mr = build(md, tmp, tag)
        if mr.returncode != 0:
            check(f'đột biến "{name}" phải BIÊN DỊCH được (nếu không thì "bị bắt" là vô nghĩa)', False, mr.stderr[-300:]); continue
        b = suite(mexe, tmp, quiet=True)
        check(f'đột biến "{name}" bị bộ kiểm bắt', b > 0); caught += b > 0
    check(f'thử phá mã: {caught}/{len(mutants)} đột biến bị bắt', caught == len(mutants))

# ---- nối dây tĩnh ----
p15 = open(os.path.join(JNI, 'sd_engine/PipelineSd15Cpu.hpp'), encoding='utf-8').read()
pl15 = open(os.path.join(JNI, 'sd_engine/Pipeline.hpp'), encoding='utf-8').read()
check('PipelineSd15Cpu include LoraCompose.hpp', '#include "LoraCompose.hpp"' in p15)
check('đường cũ giữ nguyên khi không có biến thể phụ', 'if (compose_extras_.empty()) {' in p15 and 'runOneUnet(unet_interpreter_, unet_session_, req, latents_batch2, timestep, cond, out_batch2);' in p15)
check('chọn tập hoạt động bằng lora_compose::activeSet + trộn bằng blend/factors', 'lora_compose::activeSet(step_counter_' in p15 and 'lora_compose::blend(' in p15 and 'lora_compose::factors(' in p15)
check('bộ đếm bước được reset trong beginDenoise và tăng mỗi bước', 'step_counter_ = 0;' in p15 and '++step_counter_;' in p15)
check('biến thể phụ được giải phóng trong endDenoise (không rò RAM)', re.search(r'void endDenoise\(\) override \{[^}]*?releaseComposeExtras\(\);', p15) is not None)
check('nạp biến thể lỗi -> giải phóng hết + chạy UNet chính (không làm hỏng lượt sinh)', 'KHÔNG nạp được biến thể' in p15 and 'releaseComposeExtras();\n        return;' in p15)
check('hook onBeforeUnetRun nhận ĐÚNG session đang chạy (không phải session chính)', 'onBeforeUnetRun(interp, sess);' in p15)
check('Pipeline: Regional dùng regionalFields + blendRegional, hàng trường theo CHỈ SỐ biến thể (act[j])', 'lora_compose::regionalFields(st.masks' in p15 and 'lora_compose::blendRegional(' in p15 and 'compose_fields_.data() + (size_t)act[j] * hw' in p15)
check('Pipeline: mask sai k/độ dài -> tắt regional, chạy Switch/Composite thường (không làm hỏng lượt)', 'st.mask_k == kk' in p15 and 'mask vùng không hợp lệ' in p15 and 'compose_regional_ = false;' in p15)
check('Pipeline: regional chạy ĐỦ k UNet mỗi bước (activeCount = k)', 'compose_active_count_ = kk;' in p15)
check('Pipeline: nhánh không-regional vẫn dùng lora_compose::blend như trước', 'lora_compose::blend(ptrs, lora_compose::factors(act, compose_weights_), batch2_count, out_batch2);' in p15)
jn = open(os.path.join(JNI, 'mnn_diffusion_pipeline.cpp'), encoding='utf-8').read()
check('Pipeline: hook onConditioningReady chạy SAU encodePrompts (kể cả khi cache CLIP trúng cả hai phía)', re.search(r'Conditioning cond = encodePrompts\(req\);\s*onConditioningReady\(req\);', pl15) is not None)
check('PipelineSd15Cpu: CLIP riêng mã hoá bằng encodeTextWith(đường dẫn CLIP của biến thể) — KHÔNG đi qua cache đĩa', 'encodeTextWith(clip, processed, true, true, c);' in p15 and 'encodeTextWith(clip_path_, prompts' in p15)
check('PipelineSd15Cpu: mỗi UNet nhận điều kiện qua condFor(act[...]) ở CẢ nhánh 1 UNet lẫn nhánh trộn', p15.count('condFor(act[') == 2)
check('PipelineSd15Cpu: điều kiện phụ xoá ở endDenoise, KHÔNG ở releaseComposeExtras (vì beginDenoise gọi nó sau khi điều kiện đã tính)', re.search(r'void endDenoise\(\) override \{\s*compose_extra_conds_\.clear\(\);', p15) is not None and re.search(r'void releaseComposeExtras\(\) \{[^}]*?compose_extra_conds_', p15, re.S) is None)
check('PipelineSd15Cpu: lỗi mã hoá CLIP riêng -> dùng CLIP chính cho biến thể đó (không làm hỏng lượt)', 'dùng CLIP chính cho biến thể này' in p15)
check('JNI setLoraCompose/clearLoraCompose tồn tại', 'NativeBridge_setLoraCompose' in jn and 'NativeBridge_clearLoraCompose' in jn)
nb = open(os.path.join(KT, 'pipeline/NativeBridge.kt'), encoding='utf-8').read()
check('JNI + Kotlin external setLoraComposeClips khớp', 'NativeBridge_setLoraComposeClips' in jn and 'external fun setLoraComposeClips(clips: Array<String>)' in nb)
check('JNI + Kotlin external setLoraComposeMasks khớp', 'NativeBridge_setLoraComposeMasks' in jn and 'external fun setLoraComposeMasks(masks: FloatArray, k: Int, w: Int, h: Int)' in nb and 'GetArrayLength(jMasks) != (jsize)((long long)k * w * h)' in jn)
check('Kotlin external setLoraCompose/clearLoraCompose khớp JNI', 'external fun setLoraCompose(activeCount: Int, tau: Int, extraUnetPaths: Array<String>, weights: FloatArray)' in nb and 'external fun clearLoraCompose()' in nb)

shutil.rmtree(tmp, ignore_errors=True)
print('ALL OK' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
