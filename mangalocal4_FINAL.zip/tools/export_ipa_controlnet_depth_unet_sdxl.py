"""
export_ipa_controlnet_depth_unet_sdxl.py — mục 181 TECHNICAL_STATUS.md
(SDXL Phase 2f — VIỆC CUỐI trong 4 tính năng đã cam kết). Bản SDXL tương
đương export_ipa_controlnet_depth_unet.py (SD1.5, mục 51) — thêm
ControlNet-Depth-SDXL vào UNet augmented (mục 177) để giúp đoán đúng ai
đứng trước/sau khi 2 khung xương chồng lấn.

QUAN TRỌNG — GIỐNG HỆT export_ipa_controlnet_unet_sdxl.py: file kết quả
tên "unet_ipa_controlnet_sdxl.onnx"/".mnn" GIỐNG HỆT bản KHÔNG-depth (mục
177) — app tự dò input "depth_hint" có tồn tại hay không (xem
ip_adapter_sdxl.cpp), KHÔNG cần cờ chọn chế độ nào khác.

=== PHẠM VI CÓ CHỦ ĐÍCH — ĐƠN GIẢN HƠN BẢN SD1.5 (nhất quán mục 177/178/179/180) ===
KHÔNG có: Smooth Timestep Decay, pose_scale/depth_scale/depth_active_min_
timestep/depth_ramp_width (cân bằng 2 ControlNet, mục 81/146 ở SD1.5) — 2
residual CỘNG THẲNG 1:1 (đúng hành vi "model CŨ trước mục 81" mà chính
ip_adapter.cpp vẫn còn hỗ trợ tương thích ngược cho SD1.5). Nếu cộng 1:1
gây "loãng" tín hiệu như SD1.5 từng gặp, đó là việc của Phase 2g SAU, sau
khi bản đơn giản này build-test được.

ControlNet-Depth-SDXL: `diffusers/controlnet-depth-sdxl-1.0` — model
chính chủ do chính đội ngũ diffusers train và công bố (173+ likes trên
HuggingFace tại thời điểm tra cứu, mục 176) — không phải model tự chọn bừa.

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_depth_unet_sdxl.py --output_dir ./exported_sdxl_depth
"""
import argparse
import os

import torch
import torch.nn as nn
from diffusers import ControlNetModel, StableDiffusionXLControlNetPipeline

from export_ipa_controlnet_unet_sdxl import export_image_encoder, probe_ip_adapter_embed_shape


class AugmentedUnetDepthXL(nn.Module):
    """Giống AugmentedUnetXL (mục 177) nhưng nhận THÊM 1 ControlNet (depth)
    — gộp residual của CẢ 2 ControlNet bằng phép CỘNG (đúng cách
    MultiControlNetModel.forward() làm trong diffusers thật — đã xác nhận
    qua source khi viết export_ipa_controlnet_depth_unet.py bản SD1.5,
    không tự chế cách gộp mới). CẢ 2 ControlNet SDXL đều cần added_cond_kwargs
    riêng (xem điểm #4 docstring export_ipa_controlnet_unet_sdxl.py)."""

    def __init__(self, unet, controlnet_pose, controlnet_depth):
        super().__init__()
        self.unet = unet
        self.controlnet_pose = controlnet_pose
        self.controlnet_depth = controlnet_depth

    def forward(self, sample, timestep, encoder_hidden_states, text_embeds, time_ids,
                control_hint, depth_hint, ip_image_embeds):
        added_cond = {"text_embeds": text_embeds, "time_ids": time_ids}
        down1, mid1 = self.controlnet_pose(
            sample, timestep, encoder_hidden_states=encoder_hidden_states,
            controlnet_cond=control_hint, added_cond_kwargs=added_cond, return_dict=False,
        )
        down2, mid2 = self.controlnet_depth(
            sample, timestep, encoder_hidden_states=encoder_hidden_states,
            controlnet_cond=depth_hint, added_cond_kwargs=added_cond, return_dict=False,
        )
        down_res = [d1 + d2 for d1, d2 in zip(down1, down2)]
        mid_res = mid1 + mid2
        noise_pred = self.unet(
            sample, timestep, encoder_hidden_states=encoder_hidden_states,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            added_cond_kwargs={**added_cond, "image_embeds": [ip_image_embeds]},
            return_dict=False,
        )[0]
        return noise_pred


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="stabilityai/stable-diffusion-xl-base-1.0")
    ap.add_argument("--controlnet_model", default="thibaud/controlnet-openpose-sdxl-1.0")
    ap.add_argument("--depth_controlnet_model", default="diffusers/controlnet-depth-sdxl-1.0",
                     help="mục 181 TECHNICAL_STATUS.md — model chính chủ do team diffusers train/công bố.")
    ap.add_argument("--ip_adapter_repo", default="h94/IP-Adapter")
    ap.add_argument("--ip_adapter_weight", default="ip-adapter_sdxl.bin")
    ap.add_argument("--output_dir", default="./exported_sdxl_depth")
    ap.add_argument("--image_size", type=int, default=1024)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    if args.image_size % 64 != 0:
        raise ValueError(f"image_size phải chia hết cho 64 — nhận {args.image_size}")

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_size = args.image_size // 8

    print("Đang tải ControlNet-OpenPose-SDXL + ControlNet-Depth-SDXL...")
    controlnet_pose = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)
    controlnet_depth = ControlNetModel.from_pretrained(args.depth_controlnet_model, torch_dtype=torch.float32)

    print("Đang tải base SDXL (dùng ControlNet pose làm chỗ gắn tạm — depth gộp thủ công bên dưới)...")
    pipe = StableDiffusionXLControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet_pose, torch_dtype=torch.float32
    )
    print("Đang nạp IP-Adapter SDXL...")
    pipe.load_ip_adapter(args.ip_adapter_repo, subfolder="sdxl_models", weight_name=args.ip_adapter_weight)
    pipe.set_ip_adapter_scale(1.0)
    pipe.to(device)
    controlnet_pose.to(device)
    controlnet_depth.to(device)

    example_embeds = probe_ip_adapter_embed_shape(pipe, device)
    export_image_encoder(pipe, args.output_dir, device)

    print("Đang lắp AugmentedUnetDepthXL (UNet + ControlNet-Pose + ControlNet-Depth SDXL gộp)...")
    augmented = AugmentedUnetDepthXL(pipe.unet, controlnet_pose, controlnet_depth).to(device).eval()

    example_sample = torch.randn(1, 4, latent_size, latent_size, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_encoder_hidden = torch.randn(1, 77, 2048, device=device)
    example_text_embeds = torch.randn(1, 1280, device=device)
    example_time_ids = torch.tensor(
        [[args.image_size, args.image_size, 0, 0, args.image_size, args.image_size]],
        device=device, dtype=torch.float32)
    example_control_hint = torch.randn(1, 3, args.image_size, args.image_size, device=device)
    example_depth_hint = torch.randn(1, 3, args.image_size, args.image_size, device=device)

    # TÊN FILE GIỐNG HỆT bản không-depth (mục 177) — xem "QUAN TRỌNG" đầu file.
    onnx_path = os.path.join(args.output_dir, "unet_ipa_controlnet_sdxl_depth.onnx")
    print(f"Đang export ONNX -> {onnx_path} (model SDXL lớn + 2 ControlNet, có thể mất khá lâu)...")
    with torch.no_grad():
        torch.onnx.export(
            augmented,
            (example_sample, example_timestep, example_encoder_hidden, example_text_embeds,
             example_time_ids, example_control_hint, example_depth_hint, example_embeds),
            onnx_path,
            input_names=["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids",
                         "control_hint", "depth_hint", "ip_image_embeds"],
            output_names=["out_sample"],
            opset_version=17, do_constant_folding=True,
            dynamo=False,  # xem export_ipa_controlnet_unet_sdxl.py / mục 97 TECHNICAL_STATUS.md
        )

    print("\n=== XONG PHẦN ONNX ===")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter) — LƯU Ý đặt tên .mnn")
    print("GIỐNG HỆT bản không-depth khi copy vào máy (unet_ipa_controlnet_sdxl.mnn):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, 'unet_ipa_controlnet_sdxl.mnn')} --bizCode biz")
    print("\n(ip_image_encoder dùng CHUNG lệnh convert với bản không-depth, không cần export lại)")


if __name__ == "__main__":
    main()
