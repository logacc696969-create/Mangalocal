#!/usr/bin/env python3
"""mục 269 — KIỂM BIÊN DỊCH KOTLIN CỤC BỘ cho phần không-Compose của dự án (model/ + pipeline/ + ui/MainViewModel.kt), không cần Gradle/Android SDK đầy đủ.

Vì sao có: CI (`./gradlew :app:compileDebugKotlin`, bước "Kotlin preflight" của build.yml) là nơi DUY NHẤT từng biên dịch cả dự án; các mục 256–268 chưa qua CI. Hạng mục "Gradle/Compose
chỉ CI" ở mục 267/268 hoá ra chỉ đúng một phần: phần không-Compose biên dịch được cục bộ nếu có (1) kotlinc đúng phiên bản CI (1.9.x), (2) `android.jar` THẬT (lấy từ
github.com/Sable/android-platforms — tên miền GitHub được phép), (3) kotlinx-coroutines (bản đi kèm kotlinc là 1.5.0 nên thiếu `StateFlow.update`: đã bù bằng stub), (4) Gson.
Chỉ STUB những thư viện không lấy được (okhttp3, androidx.{lifecycle,core,documentfile}) — xem `tools/kotlin_preflight_stubs/`; stub chỉ đủ chữ ký để kiểm kiểu, KHÔNG có hành vi.

CÁCH DÙNG:  python3 tools/kotlin_preflight.py [--download] [--keep]
    KOTLINC=/đường/dẫn/kotlinc  ANDROID_JAR=/đường/dẫn/android.jar  GSON_JAR=/đường/dẫn/gson-2.10.1.jar   (tuỳ chọn; --download tự tải android.jar API 34, ~26 MB)
KHÔNG phủ: mọi tệp Compose (ui/*.kt trừ MainViewModel.kt, MainActivity), tài nguyên/R, AndroidManifest, JNI/C++, và hành vi lúc chạy. Một lần chạy ~2–3 phút trên 1 CPU.
Mã thoát: 0 = biên dịch sạch; 1 = có lỗi biên dịch; 2 = thiếu công cụ.
"""
import glob, os, re, shutil, subprocess, sys, tempfile, urllib.request
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
STUBS = os.path.join(ROOT, 'tools/kotlin_preflight_stubs')
ANDROID_URL = 'https://raw.githubusercontent.com/Sable/android-platforms/master/android-34/android.jar'

def find(cands):
    for c in cands:
        if c and os.path.exists(c): return c

def main(argv):
    kotlinc = find([os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/tools/kotlinc/bin/kotlinc', '/home/claude/work/kotlinc/bin/kotlinc'])
    gson = find([os.environ.get('GSON_JAR'), '/home/claude/tools/gson-2.10.1.jar', '/home/claude/work/gson-2.10.1.jar'])
    android = find([os.environ.get('ANDROID_JAR'), os.path.join(ROOT, 'tools/.cache/android34.jar'), '/home/claude/work/real/android34.jar'])
    if not kotlinc or not gson:
        print('THIẾU kotlinc hoặc gson jar (đặt KOTLINC / GSON_JAR).'); return 2
    if not android:
        if '--download' not in argv:
            print('THIẾU android.jar (đặt ANDROID_JAR hoặc chạy với --download).'); return 2
        os.makedirs(os.path.join(ROOT, 'tools/.cache'), exist_ok=True)
        android = os.path.join(ROOT, 'tools/.cache/android34.jar')
        print('Đang tải android.jar API 34 …'); urllib.request.urlretrieve(ANDROID_URL, android)
    coroutines = os.path.join(os.path.dirname(os.path.dirname(kotlinc)), 'lib', 'kotlinx-coroutines-core-jvm.jar')
    if not os.path.exists(coroutines):
        print('THIẾU kotlinx-coroutines-core-jvm.jar trong thư mục lib của kotlinc.'); return 2
    srcs = sorted(glob.glob(SRC + '/model/*.kt') + glob.glob(SRC + '/pipeline/*.kt') + [SRC + '/ui/MainViewModel.kt'] + glob.glob(STUBS + '/*.kt'))
    out = tempfile.mkdtemp()
    env = dict(os.environ, JAVA_OPTS='-Xmx2500m')
    r = subprocess.run([kotlinc] + srcs + ['-cp', f'{android}:{coroutines}:{gson}', '-d', out], capture_output=True, text=True, env=env)
    log = (r.stdout or '') + (r.stderr or '')
    errs = re.findall(r'^(\S+\.kt):(\d+):(\d+): error: (.*)$', log, re.M)
    warns = len(re.findall(r': warning:', log))
    ncls = sum(len(f) for _, _, f in os.walk(out))
    if '--keep' not in argv: shutil.rmtree(out, ignore_errors=True)
    print(f'{len(srcs)} tệp Kotlin; lỗi: {len(errs)}; cảnh báo: {warns}; tệp sinh ra: {ncls}')
    for f, l, c, m in errs[:30]:
        print(f'  {os.path.relpath(f, ROOT)}:{l}:{c}: {m[:160]}')
    if r.returncode != 0 and not errs:
        print(log[-800:])
    return 0 if (r.returncode == 0 and not errs) else 1

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
