#!/usr/bin/env python3
# mục 279 — BIÊN DỊCH và CHẠY mã Kotlin thật (tools/kotlin_tests/Pose3DTest.kt: Pose3D = biến đổi cả người 2D, dựng độ sâu Taylor, camera orbit; 60+ phép kiểm) nếu có kotlinc;
# không có thì chỉ kiểm tĩnh phần nối dây giao diện (và nói rõ). Đột biến (--mut): phá mã nguồn có chủ đích, chạy lại, phải có kiểm FAIL (mỗi đột biến = một lần biên dịch ~20–40 giây).
# Cách dùng: python3 tools/test_pose3d.py [--mut]   (POSE3D_MUT_WORKERS=N để chạy N đột biến song song — cần ~1,5 GB RAM mỗi luồng)
import os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
P3D = os.path.join(K, 'pipeline/Pose3D.kt'); TBL = os.path.join(K, 'model/AgeBodyTable.kt'); TDIR = os.path.join(ROOT, 'tools/kotlin_tests')
UI = os.path.join(K, 'ui/PoseEditorScreen.kt')
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)

def find_kotlinc():
    for c in (os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/tools/kotlinc/bin/kotlinc', '/home/claude/work/kotlinc/bin/kotlinc'):
        if c and os.path.exists(c): return c
def run_kotlin(p3d_path=P3D):
    with tempfile.TemporaryDirectory() as td:
        jar = os.path.join(td, 't.jar')
        r = subprocess.run([find_kotlinc(), '-nowarn', os.path.join(TDIR, 'StubStoryManager.kt'), os.path.join(TDIR, 'Pose3DTest.kt'), TBL, p3d_path, '-include-runtime', '-d', jar], capture_output=True, text=True)
        if r.returncode != 0: return None, r.stderr[-1500:]
        o = subprocess.run(['java', '-Dstdout.encoding=UTF-8', '-jar', jar], capture_output=True, text=True)
        return o.stdout, o.stderr

# (A) tĩnh: nối dây giao diện (chạy luôn, không cần kotlinc)
ui = open(UI, encoding='utf-8').read() if os.path.exists(UI) else ''
def static(ui):
    return [
        ('UI: có thẻ "vị trí & góc nhìn" nằm SAU khung vẽ và TRƯỚC thẻ tỷ lệ theo tuổi', 'MlLabel("vị trí & góc nhìn")' in ui and 0 < ui.index('Reset zoom') < ui.index('MlLabel("vị trí & góc nhìn")') < ui.index('MlLabel("tỷ lệ cơ thể theo tuổi")')),
        ('UI: nút dời / phóng thu / xoay phẳng / lật / về giữa gọi Pose3D', all(k in ui for k in ('Pose3D.translateGroup(', 'Pose3D.scaleGroup(', 'Pose3D.rollGroup(', 'Pose3D.mirrorGroup(', 'Pose3D.centerGroup(', 'Pose3D.fitInside('))),
        ('UI: thanh trượt yaw/pitch gọi Pose3D.orbit với giới hạn của Pose3D', 'Pose3D.orbit(' in ui and 'valueRange = -Pose3D.MAX_YAW..Pose3D.MAX_YAW' in ui and 'valueRange = -Pose3D.MAX_PITCH..Pose3D.MAX_PITCH' in ui),
        ('UI: chip lật chiều sâu từng chi (tay P/T, chân P/T, thân)', all(k in ui for k in ('Pose3D.FLIP_R_ARM', 'Pose3D.FLIP_L_ARM', 'Pose3D.FLIP_R_LEG', 'Pose3D.FLIP_L_LEG', 'Pose3D.FLIP_TORSO'))),
        ('UI: chế độ kéo cả người trong cử chỉ một ngón', 'dragWhole' in ui and 'if (dragWhole) {' in ui and 'Pose3D.translateGroup(people, scopeIdx()' in ui),
        ('UI: có Hoàn tác cho các biến đổi và đặt nhãn góc nhìn theo estimateAngle', 'poseUndo' in ui and 'poseExtractor.estimateAngle(' in ui),
        ('UI: nói rõ giới hạn (độ sâu đoán, lật chi, tối đa ±90°/±45°)', 'ĐOÁN' in ui and '±90°' in ui),
        ('UI: chế độ an toàn mặc định — đoán độ sâu tay/chân là chip thử nghiệm TẮT, truyền vào orbit', 'var guessLimbDepth by remember { mutableStateOf(false) }' in ui and 'limbDepth = guessLimbDepth' in ui and 'Đoán độ sâu tay/chân (thử nghiệm)' in ui and 'MẶC ĐỊNH chỉ xoay THÂN và ĐẦU' in ui),
        ('UI: chốt góc mặc định bỏ z đoán (flattenDepth), chỉ người chưa có z thật; chip Giữ z mặc định TẮT', 'var keepDepth by remember { mutableStateOf(false) }' in ui and 'Pose3D.flattenDepth(p)' in ui and '!Pose3D.hasDepth(base[i])' in ui and 'if (!keepDepth && base != null)' not in ui and 'val flattened = !keepDepth && base != null' in ui),
        ('UI: chip lật chi chỉ hiện khi đang đoán chi', 'if (guessLimbDepth) {\n                            FilterChip(selected = (fl and Pose3D.FLIP_R_ARM)' in ui),
    ]
for n, ok in static(ui): check(ok, n)

# (A2) ngưỡng z của Pose3D phải BẰNG ngưỡng ContactDetector dùng để coi "có độ sâu" (trước mục 279: 0,03 vs 0,02 — lệch)
import re as _re
_cd = open(os.path.join(K, 'pipeline/ContactDetector.kt'), encoding='utf-8').read(); _p3 = open(P3D, encoding='utf-8').read()
_m1 = _re.search(r'const val Z_MEANINGFUL = ([0-9.]+)f', _cd); _m2 = _re.search(r'const val Z_MEANINGFUL = ([0-9.]+)f', _p3)
check(bool(_m1 and _m2 and _m1.group(1) == _m2.group(1)), f'Pose3D.Z_MEANINGFUL ({_m2.group(1) if _m2 else "?"}) = ContactDetector.Thresholds.Z_MEANINGFUL ({_m1.group(1) if _m1 else "?"})')
check('Z_MEANINGFUL' in _p3 and '>= 0.03f' not in _p3, 'hasDepth dùng hằng số Z_MEANINGFUL, không còn số 0,03 riêng')

kc = find_kotlinc()
if not kc:
    print('BỎ QUA phần chạy Kotlin: không có kotlinc (đặt KOTLINC=/đường/dẫn/kotlinc, bản 1.9.x — github.com/JetBrains/kotlin/releases).')
else:
    out, err = run_kotlin()
    check(out is not None, 'biên dịch Pose3D + AgeBodyTable + test bằng kotlinc' + ('' if out is not None else '\n' + err))
    if out is not None:
        n_pass = sum(1 for l in out.splitlines() if l.startswith('PASS')); bad = [l for l in out.splitlines() if l.startswith('FAIL')]
        for l in bad: print(l)
        check(not bad and n_pass >= 80, f'mã Kotlin thật: {n_pass} phép kiểm đạt, {len(bad)} lỗi')
    if '--mut' in sys.argv:
        src = open(P3D, encoding='utf-8').read()
        muts = [
            ('lật trái-phải không hoán đổi nhãn', 'for ((a, b) in MIRROR_PAIRS) { out[a] = m[b]; out[b] = m[a] }', ''),
            ('xoay phẳng ngược chiều', 'x = pv.first + (dx * c - dy * s) / aspect, y = pv.second + (dx * s + dy * c)', 'x = pv.first + (dx * c + dy * s) / aspect, y = pv.second + (-dx * s + dy * c)'),
            ('camera yaw ngược dấu', 'val rX = cps; val rY = 0f; val rZ = sps', 'val rX = cps; val rY = 0f; val rZ = -sps'),
            ('camera pitch ngược dấu', 'val dX = sph * sps; val dY = cph; val dZ = -sph * cps', 'val dX = sph * sps; val dY = cph; val dZ = sph * cps'),
            ('hướng nhìn z ngược dấu', 'val nz = fX * px + fY * py + fZ * pz', 'val nz = -(fX * px + fY * py + fZ * pz)'),
            ('tỷ lệ s lấy các đoạn NGẮN nhất', 'val kept = ratios.filter { it <= 2f * median }.sortedDescending()', 'val kept = ratios.filter { it <= 2f * median }.sorted()'),
            ('dấu mặc định cẳng chân phải đảo', 'Bone(9, 10, fr.shank, FLIP_R_LEG, +1)', 'Bone(9, 10, fr.shank, FLIP_R_LEG, -1)'),
            ('chi không được gán độ sâu', 'z[b.b] = z[b.a] + sg * dz(len(b.a, b.b), b.l)', 'z[b.b] = z[b.a]'),
            ('bỏ đổi đơn vị theo aspect khi lưu z', 'out[i] = person[i].copy(z = z[i] / aspect)', 'out[i] = person[i].copy(z = z[i])'),
            ('hasDepth coi khung phẳng là có độ sâu', '(zs.max() - zs.min()) >= Z_MEANINGFUL', '(zs.max() - zs.min()) >= 0f'),
            ('bỏ biên chống nhiễu (người đứng thẳng bị bịa độ sâu giả)', '@JvmField var noiseMargin = 0.03f', '@JvmField var noiseMargin = 0f'),
            ('bỏ qua limbDepth (luôn đoán độ sâu chi)', 'if (!limbDepth) return 0f; ', ''),
            ('mặc định đoán cả chi (không còn an toàn)', 'flips: Int = 0, limbDepth: Boolean = false', 'flips: Int = 0, limbDepth: Boolean = true'),
            ('flattenDepth không bỏ z', 'if (p.all { it.z == 0f }) p else p.map { it.copy(z = 0f) }.toMutableList()', 'p'),
            ('orbit không đưa khớp về trong khung', 'return fitInside(rotated)', 'return rotated'),
            ('dời không chặn mép', 'val ddx = dx.coerceIn(min(0f, -minX), max(0f, 1f - maxX))', 'val ddx = dx'),
            ('phóng to không chặn mép', 'f = min(f, max(lim, 1f))', 'f = f'),
            ('xoay thân quanh trục dọc bị bỏ', 'theta = full * t', 'theta = 0.0'),
        ]
        for name, old, new in muts: assert old in src, name
        sl = os.environ.get('POSE3D_MUT_SLICE')   # "a:b" — chỉ chạy đột biến [a, b) (chia nhỏ khi môi trường dọn tiến trình nền hoặc giới hạn thời gian mỗi lệnh)
        if sl:
            a, b = (int(x) for x in sl.split(':')); muts = muts[a:b]
            print(f'(chỉ chạy lát đột biến {a}:{b} / tổng {len(muts)} trong lát)')
        def one(m):
            name, old, new = m
            with tempfile.TemporaryDirectory() as td:
                mp = os.path.join(td, 'Pose3D.kt'); open(mp, 'w', encoding='utf-8').write(src.replace(old, new, 1))
                o, e = run_kotlin(mp)
            return name, (o is None or any(l.startswith('FAIL') for l in o.splitlines()))
        workers = int(os.environ.get('POSE3D_MUT_WORKERS', '1'))   # mặc định 1: mỗi kotlinc ngốn ~1–1,5 GB RAM; máy 4 GB chạy 3 cái song song sẽ bị dọn tiến trình
        with ThreadPoolExecutor(max_workers=workers) as ex: res = list(ex.map(one, muts))
        for name, bad in res: print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name)
        caught = sum(b for _, b in res)
        check(caught == len(muts), f'đột biến: {caught}/{len(muts)} bị bắt')
    else:
        print('(bỏ qua đột biến — chạy với --mut để kiểm)')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
