"""
export_ipa_controlnet_regional_unet_sdxl.py — mục 179 TECHNICAL_STATUS.md
(SDXL Phase 2d). Bản SDXL tương đương export_ipa_controlnet_regional_unet.py
(SD1.5, mục 56/69) — ĐỌC DOCSTRING FILE ĐÓ TRƯỚC, cơ chế cốt lõi
(hook_regional_attn2 — monkey-patch MỌI module attn2, chạy attention TOÀN
ẢNH N lần rồi GHÉP CỘT) giữ NGUYÊN VẸN, không suy diễn lại — hàm
hook_regional_attn2() dưới đây COPY GẦN NHƯ NGUYÊN VĂN vì nó chỉ thao tác
trên `attn.to_q/to_k/to_v/to_out/heads` — API tầng `diffusers.models.
attention_processor.Attention` DÙNG CHUNG cho cả SD1.5 và SDXL, không có
gì SD1.5-specific.

=== PHẦN THÊM CHO SDXL (KHÁC SD1.5 — đã xác nhận qua tra cứu mục 176/177) ===
ControlNet SDXL VÀ UNet SDXL đều bắt buộc `added_cond_kwargs={"text_embeds":
..., "time_ids": ...}`. Batch=2 (uncond, cond) GIỐNG HỆT lý do đã nêu ở bản
SD1.5 (native runtime luôn gọi UNet batch=2, xem PipelineSdxlCpu.hpp).
`text_embeds`/`time_ids` là điều kiện TOÀN CỤC (không phải per-token cross-
attention) — SIMPLIFICATION có chủ đích, ghi rõ KHÔNG giấu: dùng pooled
embedding của VÙNG 0 làm placeholder cho vế cond (giống hệt cách bản SD1.5
dùng `region_embeds[0:1]` làm placeholder cho encoder_hidden_states của
ControlNet — lý do tương tự: các giá trị này ảnh hưởng tới điều kiện
KHÔNG-GIAN/PHONG-CÁCH TOÀN CỤC, không phải nội dung từng vùng, nên dùng 1
vùng đại diện là chấp nhận được ở bản ĐẦU TIÊN này — CHƯA thử nghiệm xem
có lệch phong cách tổng thể hay không, ghi vào "CHƯA LÀM" cuối file).

=== PHẠM VI — GIỐNG HỆT GIỚI HẠN BẢN SD1.5 (mục 56/69), CỘNG THÊM GIỚI HẠN SDXL ===
- CHỈ cột dọc, CHỈ ảnh vuông, negative dùng chung, N cố định lúc export —
  y hệt bản SD1.5, không nới lỏng gì thêm.
- Batch=2 CHƯA xác nhận chạy thật cho CẢ SD1.5 lẫn SDXL (mục 56 tự ghi rõ
  "CHƯA ĐƯỢC XÁC NHẬN CHẠY THẬT... chỉ là suy luận hợp lý") — bản SDXL này
  KẾ THỪA NGUYÊN rủi ro đó, KHÔNG giảm được.
- text_embeds/time_ids dùng placeholder vùng 0 (xem trên) — rủi ro MỚI
  riêng của bản SDXL, SD1.5 không có vì không cần 2 input này.

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_regional_unet_sdxl.py \\
        --num_regions 2 --output_dir ./exported_sdxl_regional
"""
import argparse
import math
import os

import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers import ControlNetModel, StableDiffusionXLControlNetPipeline


def hook_regional_attn2(unet: nn.Module, num_regions: int):
    """COPY GẦN NHƯ NGUYÊN VĂN từ export_ipa_controlnet_regional_unet.py
    (SD1.5) — xem docstring đầy đủ ở đó. Không có gì SDXL-specific trong
    hàm này (chỉ thao tác Q/K/V/to_out generic của lớp Attention)."""
    state = {"uncond": None, "regions": None}

    def make_forward(attn: nn.Module):
        def forward(hidden_states, encoder_hidden_states=None, attention_mask=None, temb=None, **kw):
            residual = hidden_states
            if attn.spatial_norm is not None:
                hidden_states = attn.spatial_norm(hidden_states, temb)
            input_ndim = hidden_states.ndim
            if input_ndim == 4:
                b, c, h4, w4 = hidden_states.shape
                hidden_states = hidden_states.view(b, c, h4 * w4).transpose(1, 2)

            seq_len = hidden_states.shape[1]
            side = int(round(math.sqrt(seq_len)))

            uncond_hs = hidden_states[0:1]
            cond_hs = hidden_states[1:2]

            def run_attn(hs, enc_hs):
                q = attn.to_q(hs)
                k = attn.to_k(enc_hs)
                v = attn.to_v(enc_hs)
                inner_dim = k.shape[-1]
                head_dim = inner_dim // attn.heads
                q = q.view(hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                k = k.view(enc_hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                v = v.view(enc_hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                out = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0, is_causal=False)
                out = out.transpose(1, 2).reshape(hs.shape[0], -1, attn.heads * head_dim).to(q.dtype)
                out = attn.to_out[0](out)
                out = attn.to_out[1](out)
                return out

            uncond_out = run_attn(uncond_hs, state["uncond"])
            region_outs = [run_attn(cond_hs, state["regions"][i:i + 1]) for i in range(num_regions)]

            spliced = torch.zeros_like(region_outs[0])
            spliced_2d = spliced.view(1, side, side, -1)
            for i, out in enumerate(region_outs):
                lo = int(side * i / num_regions)
                hi = int(side * (i + 1) / num_regions)
                out_2d = out.view(1, side, side, -1)
                spliced_2d[:, :, lo:hi, :] = out_2d[:, :, lo:hi, :]
            cond_out = spliced_2d.view(1, seq_len, -1)

            hidden_states = torch.cat([uncond_out, cond_out], dim=0)

            if input_ndim == 4:
                hidden_states = hidden_states.transpose(-1, -2).reshape(b, c, h4, w4)
            if attn.residual_connection:
                hidden_states = hidden_states + residual
            hidden_states = hidden_states / attn.rescale_output_factor
            return hidden_states
        return forward

    for name, module in unet.named_modules():
        if "attn2" in name and module.__class__.__name__ == "Attention":
            module.forward = make_forward(module)

    def set_regional_state(uncond_embeds, region_embeds):
        state["uncond"] = uncond_embeds
        state["regions"] = region_embeds

    return set_regional_state


class AugmentedUNetRegionalXL(nn.Module):
    """UNet SDXL + ControlNet-SDXL + Regional Prompting (N cột). Khác bản
    SD1.5: thêm text_embeds/time_ids (bắt buộc cho CẢ controlnet lẫn unet
    SDXL, xem docstring đầu file) — dùng pooled embedding VÙNG 0 làm
    placeholder cho vế cond (simplification có chủ đích, xem docstring)."""

    def __init__(self, unet, controlnet, num_regions):
        super().__init__()
        self.unet = unet
        self.controlnet = controlnet
        self.set_state = hook_regional_attn2(unet, num_regions)

    def forward(self, sample, timestep, uncond_embeds, region_embeds,
                uncond_pooled, region_pooled, time_ids, control_hint):
        # text_embeds batch=2: [uncond_pooled, region_pooled[0]] — vùng 0
        # làm đại diện cho vế cond (xem docstring — placeholder có chủ đích).
        text_embeds_b2 = torch.cat([uncond_pooled, region_pooled[0:1]], dim=0)
        added_cond = {"text_embeds": text_embeds_b2, "time_ids": time_ids}

        cn_encoder_hidden = torch.cat([uncond_embeds, region_embeds[0:1]], dim=0)
        down_res, mid_res = self.controlnet(
            sample, timestep, encoder_hidden_states=cn_encoder_hidden,
            controlnet_cond=control_hint, added_cond_kwargs=added_cond, return_dict=False,
        )
        self.set_state(uncond_embeds, region_embeds)
        placeholder_encoder_hidden = torch.cat([uncond_embeds, uncond_embeds], dim=0)
        noise_pred = self.unet(
            sample, timestep, encoder_hidden_states=placeholder_encoder_hidden,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            added_cond_kwargs=added_cond,
            return_dict=False,
        )[0]
        return noise_pred


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="stabilityai/stable-diffusion-xl-base-1.0")
    ap.add_argument("--controlnet_model", default="thibaud/controlnet-openpose-sdxl-1.0")
    ap.add_argument("--num_regions", type=int, default=2, help="So cot doc chia deu tu trai sang phai (>=2)")
    ap.add_argument("--output_dir", default="./exported_sdxl_regional")
    ap.add_argument("--image_size", type=int, default=1024, help="PHAI la anh VUONG (xem GIOI HAN THAT o dau file)")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    if args.num_regions < 2:
        raise ValueError("num_regions phai >= 2")
    if args.image_size % 64 != 0:
        raise ValueError(f"image_size phải chia hết cho 64 — nhận {args.image_size}")

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_size = args.image_size // 8

    print("Đang tải ControlNet-OpenPose-SDXL...")
    controlnet = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)
    print("Đang tải base SDXL + gắn ControlNet...")
    pipe = StableDiffusionXLControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet, torch_dtype=torch.float32
    ).to(device)

    print(f"Đang gắn hook Regional Prompting SDXL ({args.num_regions} cột)...")
    augmented = AugmentedUNetRegionalXL(pipe.unet, pipe.controlnet, args.num_regions).to(device).eval()

    # Dò shape encoder_hidden_states + pooled THẬT — SDXL dùng CẢ 2 text
    # encoder (tokenizer/tokenizer_2, text_encoder/text_encoder_2), nối
    # hidden_states 768+1280=2048, pooled CHỈ lấy từ text_encoder_2 (bigG)
    # — ĐÚNG cơ chế đã xác nhận ở export_sdxl_base.py/PipelineSdxlCpu.hpp.
    with torch.no_grad():
        ids1 = pipe.tokenizer(["a photo"], padding="max_length", max_length=pipe.tokenizer.model_max_length,
                               truncation=True, return_tensors="pt").input_ids.to(device)
        ids2 = pipe.tokenizer_2(["a photo"], padding="max_length", max_length=pipe.tokenizer_2.model_max_length,
                                 truncation=True, return_tensors="pt").input_ids.to(device)
        out1 = pipe.text_encoder(ids1, output_hidden_states=True)
        out2 = pipe.text_encoder_2(ids2, output_hidden_states=True)
        probe_hidden = torch.cat([out1.hidden_states[-2], out2.hidden_states[-2]], dim=-1)
        probe_pooled = out2[0]
    print(f"[probe] encoder_hidden_states 1 prompt shape THẬT: {tuple(probe_hidden.shape)}")
    print(f"[probe] pooled (text_embeds) 1 prompt shape THẬT: {tuple(probe_pooled.shape)}")

    example_sample = torch.randn(2, 4, latent_size, latent_size, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_uncond = torch.randn_like(probe_hidden)
    example_regions = torch.randn(args.num_regions, *probe_hidden.shape[1:], device=device)
    example_uncond_pooled = torch.randn_like(probe_pooled)
    example_region_pooled = torch.randn(args.num_regions, *probe_pooled.shape[1:], device=device)
    example_time_ids = torch.tensor(
        [[args.image_size, args.image_size, 0, 0, args.image_size, args.image_size]] * 2,
        device=device, dtype=torch.float32)
    example_control_hint = torch.randn(2, 3, args.image_size, args.image_size, device=device)

    onnx_name = f"unet_regional_controlnet_sdxl_{args.num_regions}col.onnx"
    mnn_name = f"unet_regional_controlnet_sdxl_{args.num_regions}col.mnn"
    onnx_path = os.path.join(args.output_dir, onnx_name)
    print(f"Đang export ONNX -> {onnx_path} (model SDXL lớn, có thể mất nhiều phút)...")
    with torch.no_grad():
        torch.onnx.export(
            augmented,
            (example_sample, example_timestep, example_uncond, example_regions,
             example_uncond_pooled, example_region_pooled, example_time_ids, example_control_hint),
            onnx_path,
            input_names=["sample", "timestep", "uncond_encoder_hidden_states",
                         "region_encoder_hidden_states", "uncond_text_embeds",
                         "region_text_embeds", "time_ids", "control_hint"],
            output_names=["out_sample"],
            opset_version=17, do_constant_folding=True,
            dynamo=False,  # xem export_ipa_controlnet_unet_sdxl.py / mục 97 TECHNICAL_STATUS.md
        )

    print("\n=== XONG PHẦN ONNX ===")
    print(f"Shape uncond_encoder_hidden_states: {tuple(example_uncond.shape)}")
    print(f"Shape region_encoder_hidden_states ({args.num_regions} vùng): {tuple(example_regions.shape)}")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, mnn_name)} --bizCode biz")
    print(f"\nQUAN TRỌNG: model CỐ ĐỊNH cho ĐÚNG {args.num_regions} cột VÀ ảnh VUÔNG "
          f"{args.image_size}x{args.image_size} — sai sẽ hỏng ÂM THẦM, không crash.")
    print("\n=== CHƯA LÀM / GIỚI HẠN THẬT CHƯA GIẢI QUYẾT ===")
    print("- text_embeds/time_ids vế cond dùng placeholder VÙNG 0 (không phải trộn/trung bình N vùng)")
    print("  — CHƯA thử nghiệm xem có gây lệch phong cách tổng thể về phía vùng 0 hay không.")
    print("- Batch=2 (native runtime) CHƯA xác nhận chạy thật cho CẢ SD1.5 lẫn SDXL (mục 56).")
    print("- Không tương thích Mask N-nhân-vật/Triple-Combo (2 kỹ thuật song song, không gộp).")


if __name__ == "__main__":
    main()
