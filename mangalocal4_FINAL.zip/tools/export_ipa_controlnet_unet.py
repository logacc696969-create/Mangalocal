"""
export_ipa_controlnet_unet.py — Xuất 1 bản UNet SD1.5 đã gộp sẵn
IP-Adapter (giữ nhân vật) + ControlNet-OpenPose (giữ tư thế) thành ONNX,
rồi convert sang .mnn để MangaLocal dùng.

CHẠY TRÊN MÁY TÍNH (không phải điện thoại), cần Python + GPU khuyến khích
(chạy CPU vẫn được, chỉ chậm hơn — đây là việc làm 1 LẦN, không phải lúc
sinh ảnh).

API dùng trong script này đều là API CHÍNH THỨC của `diffusers`, đã xác
nhận qua tài liệu/source thật (không đoán):
  - ControlNetModel, StableDiffusionControlNetPipeline
  - UNet2DConditionModel.forward(..., down_block_additional_residuals,
    mid_block_additional_residual, added_cond_kwargs) — xác nhận từ chính
    source code diffusers (unet_2d_condition.py)
  - pipe.load_ip_adapter(...) — xác nhận từ tài liệu chính thức HuggingFace

ĐIỀU CHƯA KIỂM CHỨNG (tự dò lúc chạy, KHÔNG hardcode để tránh sai):
  - Shape chính xác của image_embeds do IP-Adapter image_proj_model sinh
    ra (tài liệu không nêu con số cụ thể cho SD1.5) — script này TỰ chạy
    thử 1 lần để lấy đúng shape thật, không đoán số.

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_unet.py \
        --base_model runwayml/stable-diffusion-v1-5 \
        --output_dir ./exported \
        --image_size 512
"""
import argparse
import os

import numpy as np
import torch
import torch.nn as nn
from diffusers import ControlNetModel, StableDiffusionControlNetPipeline

from ip_adapter_decay import IpDecayState, wrap_unet_ip_adapter_processors
from pose_lora_merge import merge_pose_lora_into_unet


class AugmentedUNet(nn.Module):
    """Bọc UNet + ControlNet thành 1 module duy nhất để export ONNX 1 lần.

    KHÔNG tự viết lại toán học của UNet/ControlNet — chỉ gọi đúng API thật
    của diffusers (forward() có sẵn), nối kết quả ControlNet vào UNet đúng
    theo cách StableDiffusionControlNetPipeline làm nội bộ (xem
    down_block_additional_residuals/mid_block_additional_residual trong
    source diffusers, đã xác nhận thật).
    """

    def __init__(self, unet, controlnet, decay_state: IpDecayState):
        super().__init__()
        self.unet = unet
        self.controlnet = controlnet
        # Xem ip_adapter_decay.py — object này được unet.attn_processors
        # (đã bọc bởi wrap_unet_ip_adapter_processors() ở main()) đọc trực
        # tiếp, KHÔNG đăng ký làm submodule (cố tình, xem docstring
        # IpDecayState) nên không xuất hiện trong self.unet.state_dict().
        self._decay_state = decay_state

    def forward(self, sample, timestep, encoder_hidden_states, control_hint, ip_image_embeds,
                ip_decay_floor, ip_decay_start_timestep, ip_static_scale):
        down_res, mid_res = self.controlnet(
            sample,
            timestep,
            encoder_hidden_states=encoder_hidden_states,
            controlnet_cond=control_hint,
            return_dict=False,
        )

        # "Smooth Timestep Decay" cho IP-Adapter — bản THẬT, scale OUTPUT
        # của attention (đúng ý nghĩa pipe.set_ip_adapter_scale()), thực
        # hiện qua DecayedIPAdapterAttnProcessor2_0 đã gắn vào self.unet ở
        # main() (xem tools/ip_adapter_decay.py cho toàn bộ cơ chế + GIỚI
        # HẠN THẬT còn lại — quan trọng nhất: phụ thuộc cấu trúc nội bộ
        # diffusers 0.39.0, cần đối chiếu lại nếu CI cài bản khác).
        #
        # Công thức (SUY GIẢM TUYẾN TÍNH MƯỢT — khác cổng cứng torch.where
        # của depth_gate trong export_ipa_controlnet_depth_unet.py):
        #   ramp = clamp(timestep, 0, ip_decay_start_timestep) / ip_decay_start_timestep
        #   effective_scale = ip_static_scale * (ip_decay_floor + (1 - ip_decay_floor) * ramp)
        # ramp=1.0 (embeds giữ nguyên) khi timestep >= ip_decay_start_timestep,
        # giảm DẦN về ip_decay_floor khi timestep tiến về 0 (cuối sinh ảnh).
        # Mặc định ip_decay_floor=1.0 -> phần decay luôn =1.0 -> TƯƠNG THÍCH
        # NGƯỢC hoàn toàn khi caller không đổi gì.
        #
        # ip_static_scale — ĐÓNG GAP THẬT ghi từ mục 9 TECHNICAL_STATUS.md:
        # slider "Mức độ nhất quán" (GenerationSettings.consistencyStrength,
        # có UI từ trước nhưng CHƯA BAO GIỜ có tác dụng vì
        # pipe.set_ip_adapter_scale() là hằng số Python đóng băng lúc export,
        # không đổi được lúc chạy — đúng như comment cũ trong
        # SettingsScreen.kt đã tự ghi rõ cách sửa: "phải thêm ip_scale làm
        # input runtime của UNet lúc export lại"). Dùng LUÔN cơ chế
        # attention processor đã bọc (mục 97) thay vì tạo cơ chế mới —
        # consistencyStrength giờ là 1 TẦNG NHÂN riêng, độc lập với decay
        # theo timestep (không thay thế nó): =1.0 (mặc định slider) giữ
        # nguyên hành vi decay tính riêng ở trên; giảm xuống làm YẾU IP-
        # Adapter ĐỀU trong suốt quá trình (khác decay chỉ yếu dần cuối step).
        safe_start = torch.clamp(ip_decay_start_timestep, min=1e-3)
        ramp = torch.clamp(timestep.float(), min=torch.zeros_like(safe_start), max=safe_start) / safe_start
        effective_ip_scale = ip_static_scale * (ip_decay_floor + (1.0 - ip_decay_floor) * ramp)
        # Gán NGAY TRƯỚC khi gọi self.unet(...) — mọi processor đã bọc bên
        # trong sẽ đọc đúng giá trị này trong LƯỢT forward() hiện tại (xem
        # "CÁCH HOẠT ĐỘNG" trong ip_adapter_decay.py).
        self._decay_state.value = effective_ip_scale

        noise_pred = self.unet(
            sample,
            timestep,
            encoder_hidden_states=encoder_hidden_states,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            # image_embeds bọc trong list vì diffusers hỗ trợ nhiều IP-Adapter
            # cùng lúc (list of tensors) — dùng 1 phần tử ở đây. KHÔNG scale
            # embeds ở đây nữa (khác bản trước) — decay đã áp dụng ĐÚNG chỗ
            # bên trong attention processor, embeds giữ nguyên 100%.
            added_cond_kwargs={"image_embeds": [ip_image_embeds]},
            return_dict=False,
        )[0]
        return noise_pred


def probe_ip_adapter_embed_shape(pipe, device):
    """Tự dò shape thật của image_embeds bằng 1 lần chạy thử với ảnh giả
    (toàn màu xám), thay vì đoán con số — tránh lặp lỗi 'hardcode chưa
    kiểm chứng' đã rút kinh nghiệm trong dự án này."""
    from PIL import Image

    dummy_image = Image.new("RGB", (224, 224), color=(128, 128, 128))
    with torch.no_grad():
        embeds = pipe.prepare_ip_adapter_image_embeds(
            ip_adapter_image=[dummy_image],
            ip_adapter_image_embeds=None,
            device=device,
            num_images_per_prompt=1,
            do_classifier_free_guidance=False,
        )
    # prepare_ip_adapter_image_embeds trả về list (1 phần tử mỗi IP-Adapter)
    embed_tensor = embeds[0]
    print(f"[probe] image_embeds shape THẬT (dò được, không đoán): {tuple(embed_tensor.shape)}")
    return embed_tensor


class ImageEncoderForExport(nn.Module):
    """Bọc CLIP image encoder + lớp projection của IP-Adapter thành 1 module
    độc lập — để chạy trên điện thoại (encode ảnh nhân vật -> image_embeds)
    mà không cần mang theo toàn bộ pipeline. Dùng đúng 2 thành phần thật
    (pipe.image_encoder, pipe.unet.encoder_hid_proj.image_projection_layers[0])
    đã xác nhận qua tài liệu chính thức diffusers, không tự viết lại toán học
    CLIP hay projection."""

    def __init__(self, image_encoder, image_projection_layer):
        super().__init__()
        self.image_encoder = image_encoder
        self.image_projection_layer = image_projection_layer

    def forward(self, pixel_values):
        # output_hidden_states=True cho biến thể "Plus" (patch embeddings);
        # bản ip-adapter_sd15.bin thường (không phải Plus) dùng embedding
        # gộp (pooler_output) — dùng hidden_states[-2] là lựa chọn phổ biến
        # nhất trong cộng đồng cho tương thích rộng, NHƯNNG đây là điểm cần
        # đối chiếu lại với đúng loại checkpoint bạn dùng (ip-adapter thường
        # vs ip-adapter-plus) nếu ảnh ra không giống nhân vật tham chiếu.
        outputs = self.image_encoder(pixel_values, output_hidden_states=True)
        image_embeds = outputs.image_embeds  # CLIPVisionModelWithProjection output chuẩn
        projected = self.image_projection_layer(image_embeds)
        return projected


def export_image_encoder(pipe, output_dir, device):
    print("Đang export CLIP image encoder + projection riêng (ip_image_encoder.onnx)...")
    image_proj_layer = pipe.unet.encoder_hid_proj.image_projection_layers[0]
    encoder_module = ImageEncoderForExport(pipe.image_encoder, image_proj_layer).to(device).eval()

    example_pixels = torch.randn(1, 3, 224, 224, device=device)  # kích thước chuẩn CLIP ViT
    onnx_path = os.path.join(output_dir, "ip_image_encoder.onnx")
    with torch.no_grad():
        output = encoder_module(example_pixels)
        torch.onnx.export(

            encoder_module, example_pixels, onnx_path,
            input_names=["pixel_values"], output_names=["image_embeds"],
            opset_version=17, do_constant_folding=True,
        
            dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
            # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
            # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
            # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
            # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
            # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
            # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
            # xác nhận hoạt động đúng bằng thực nghiệm.
        )
    print(f"  -> {onnx_path}, output shape: {tuple(output.shape)}")
    return output


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="runwayml/stable-diffusion-v1-5")
    ap.add_argument("--controlnet_model", default="lllyasviel/control_v11p_sd15_openpose")
    ap.add_argument("--ip_adapter_repo", default="h94/IP-Adapter")
    ap.add_argument("--ip_adapter_weight", default="ip-adapter_sd15.bin")
    ap.add_argument("--output_dir", default="./exported")
    ap.add_argument("--image_size", type=int, default=None,
                     help="LƯU Ý: đặt CẢ width VÀ height bằng giá trị này (chỉ dùng cho ảnh vuông, tương thích ngược). Ưu tiên dùng --width/--height nếu cần ảnh không vuông.")
    ap.add_argument("--width", type=int, default=512, help="Phải chia hết cho 64 (VAE 8x + UNet giảm thêm 8x = 64x thật; mục 161 đợt 7 TECHNICAL_STATUS.md)")
    ap.add_argument("--height", type=int, default=512, help="Phải chia hết cho 64 (VAE 8x + UNet giảm thêm 8x = 64x thật; mục 161 đợt 7 TECHNICAL_STATUS.md)")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    # mục 119 TECHNICAL_STATUS.md — Pose-Specific LoRA Injection, tuỳ chọn
    ap.add_argument("--pose_lora", default="",
                     help="Đường dẫn .safetensors LoRA bố cục/tư thế (tuỳ chọn) — merge TĨNH "
                          "vào down_blocks TRƯỚC khi wrap IP-Adapter, xem tools/pose_lora_merge.py")
    ap.add_argument("--pose_lora_scale", type=float, default=0.7)
    args = ap.parse_args()
    # mục 161 (đợt 5) — tương thích ngược: --image_size (cũ, vuông) nếu có
    # truyền sẽ GHI ĐÈ width/height (khớp đúng mọi lệnh gọi HIỆN CÓ trong
    # prepare_models.yml/docstring — KHÔNG đổi hành vi cũ). Không truyền
    # --image_size -> dùng --width/--height (mặc định 512/512 = giống hệt
    # cũ nếu không ai đổi gì).
    if args.image_size is not None:
        args.width = args.height = args.image_size
    if args.width % 64 != 0 or args.height % 64 != 0:
        # mục 161 (đợt 7) — tra cứu web xác nhận cần chia hết 64, không
        # phải 8 (xem comment đầy đủ trong export_sd15_base.py — bug thật
        # đã báo cáo: huggingface/diffusers issue #255).
        raise ValueError(f"width/height phải chia hết cho 64 (không phải 8 — UNet có thêm 3 tầng downsample nội bộ ngoài VAE) — nhận {args.width}x{args.height}")

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_h, latent_w = args.height // 8, args.width // 8

    print("Đang tải ControlNet-OpenPose...")
    controlnet = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)

    print("Đang tải base SD1.5 + gắn ControlNet...")
    pipe = StableDiffusionControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet, torch_dtype=torch.float32, safety_checker=None
    )

    # mục 119 TECHNICAL_STATUS.md — Pose-Specific LoRA Injection: merge
    # TĨNH vào down_blocks NGAY SAU khi tải base UNet, TRƯỚC khi nạp
    # IP-Adapter (thứ tự quan trọng — merge trước để trọng số bố cục đã
    # "nướng" cứng vào UNet trước khi attention processor bị bọc lại cho
    # Smooth Timestep Decay, tránh 2 cơ chế đụng nhau lúc export).
    if args.pose_lora:
        print(f"Đang merge Pose LoRA ({args.pose_lora}, scale={args.pose_lora_scale}, "
              f"chỉ down_blocks)...")
        n_pose_merged = merge_pose_lora_into_unet(
            pipe.unet, args.pose_lora, scale=args.pose_lora_scale, block_scope="down_blocks"
        )
        if n_pose_merged == 0:
            raise RuntimeError(
                "merge_pose_lora_into_unet() không merge được layer nào — xem "
                "tools/pose_lora_merge.py để debug (có thể do --pose_lora sai định "
                "dạng, hoặc bản diffusers cài trong môi trường này đặt tên module "
                "UNet khác so với lúc viết script)."
            )

    print(f"Đang nạp IP-Adapter ({args.ip_adapter_repo}/{args.ip_adapter_weight})...")
    pipe.load_ip_adapter(args.ip_adapter_repo, subfolder="models", weight_name=args.ip_adapter_weight)
    pipe.set_ip_adapter_scale(1.0)  # scale TĨNH mặc định (per-adapter) — Smooth Timestep Decay (runtime,
    # theo timestep) là tầng khác, nhân THÊM vào trên tầng tĩnh này — xem ip_adapter_decay.py.
    pipe.to(device)

    # Bọc attention processor thật của UNet để Smooth Timestep Decay tác
    # động ĐÚNG vào output attention (không phải xấp xỉ scale-input) — xem
    # tools/ip_adapter_decay.py cho toàn bộ cơ chế + GIỚI HẠN THẬT.
    decay_state = IpDecayState()
    n_wrapped = wrap_unet_ip_adapter_processors(pipe.unet, decay_state)
    if n_wrapped == 0:
        raise RuntimeError(
            "wrap_unet_ip_adapter_processors() không bọc được processor nào — "
            "hoặc pipe.load_ip_adapter() chưa chạy đúng, hoặc bản diffusers cài "
            "trong môi trường này đã đổi tên/cấu trúc IPAdapterAttnProcessor2_0. "
            "KHÔNG bỏ qua lỗi này (im lặng bỏ qua sẽ khiến ip_decay_floor/"
            "ip_decay_start_timestep không có tác dụng gì mà không ai biết) — "
            "xem GIỚI HẠN THẬT trong tools/ip_adapter_decay.py để tra lại."
        )
    print(f"Đã bọc {n_wrapped} attention processor với Smooth Timestep Decay (IP-Adapter).")

    # Dò shape thật của image_embeds — KHÔNG đoán.
    example_embeds = probe_ip_adapter_embed_shape(pipe, device)

    # Export riêng CLIP image encoder để dùng lúc runtime (encode ảnh nhân
    # vật tham chiếu trên điện thoại).
    export_image_encoder(pipe, args.output_dir, device)

    print("Đang lắp AugmentedUNet (UNet + ControlNet gộp)...")
    augmented = AugmentedUNet(pipe.unet, pipe.controlnet, decay_state).to(device).eval()

    # Input mẫu để trace ONNX — dùng đúng shape thật sẽ dùng lúc infer.
    example_sample = torch.randn(1, 4, latent_h, latent_w, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_encoder_hidden = torch.randn(1, 77, 768, device=device)  # CLIP SD1.5, xác nhận qua TextEncoder.hpp đã port
    example_control_hint = torch.randn(1, 3, args.height, args.width, device=device)
    # 2 scalar mới (Smooth Timestep Decay IP-Adapter, xem forward() ở trên)
    # — giá trị mẫu 1.0/999.0 chỉ để TRACE đúng shape/dtype, tương đương
    # "không suy giảm gì" (ip_decay_floor=1.0). Giá trị THẬT do app truyền
    # mỗi lần gọi (GenerationSettings.ipDecayFloor/ipDecayStartTimestep).
    example_ip_decay_floor = torch.tensor(1.0, device=device, dtype=torch.float32)
    example_ip_decay_start_timestep = torch.tensor(999.0, device=device, dtype=torch.float32)
    # ip_static_scale — đóng gap "consistencyStrength chết" (mục 9, xem
    # forward()). Mẫu 1.0 = giữ nguyên cường độ IP-Adapter gốc (hành vi cũ).
    example_ip_static_scale = torch.tensor(1.0, device=device, dtype=torch.float32)

    onnx_path = os.path.join(args.output_dir, "unet_ipa_controlnet.onnx")
    print(f"Đang export ONNX -> {onnx_path} (có thể mất vài phút)...")
    with torch.no_grad():
        torch.onnx.export(

            augmented,
            (example_sample, example_timestep, example_encoder_hidden, example_control_hint, example_embeds,
             example_ip_decay_floor, example_ip_decay_start_timestep, example_ip_static_scale),
            onnx_path,
            input_names=["sample", "timestep", "encoder_hidden_states", "control_hint", "ip_image_embeds",
                         "ip_decay_floor", "ip_decay_start_timestep", "ip_static_scale"],
            output_names=["out_sample"],
            opset_version=17,
            do_constant_folding=True,
            # KHÔNG dùng dynamic_axes — MNN trên điện thoại chạy nhanh hơn
            # với shape cố định; nếu cần nhiều size ảnh, export nhiều bản.
            dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
            # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
            # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
            # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
            # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
            # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
            # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
            # xác nhận hoạt động đúng bằng thực nghiệm. ĐẶC BIỆT QUAN TRỌNG cho
            # đúng lệnh gọi này — decay chỉ hoạt động đúng qua đường trace này.
        )

    print("\n=== XONG PHẦN ONNX ===")
    print(f"Shape ip_image_embeds thật đã dò được: {tuple(example_embeds.shape)}")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, 'unet_ipa_controlnet.mnn')} \\")
    print(f"      --bizCode biz")
    print(f"  MNNConvert -f ONNX --modelFile {os.path.join(args.output_dir, 'ip_image_encoder.onnx')} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, 'ip_image_encoder.mnn')} \\")
    print(f"      --bizCode biz")
    print("\nSau khi convert xong, đổi tên file .mnn kết quả thành 'unet.mnn' trong")
    print("thư mục model tương ứng, và dùng model_manifest.json với pipeline")
    print("'sd15_cpu_augmented' (xem ip_adapter.cpp phía MangaLocal).")
    print(f"\nQUAN TRỌNG: ghi lại số {example_embeds.shape[1]} (số token) và "
          f"{example_embeds.shape[2]} (chiều embedding) — cần khớp đúng trong "
          f"ip_adapter.cpp (hằng số IP_EMBED_TOKENS/IP_EMBED_DIM).")
    print("\nBản này có 2 input MỚI: 'ip_decay_floor' / 'ip_decay_start_timestep' (Smooth")
    print("Timestep Decay cho IP-Adapter) — model CŨ (export trước thay đổi này) không có")
    print("2 input này, ip_adapter.cpp tự phát hiện và bỏ qua an toàn (hành vi y hệt trước,")
    print("KHÔNG suy giảm). Bản này scale ĐÚNG output attention (qua attn processor đã bọc,")
    print("xem tools/ip_adapter_decay.py) — không còn là xấp xỉ scale-input như bản trước.")
    print("GIỚI HẠN THẬT còn lại: phụ thuộc cấu trúc nội bộ diffusers cài lúc export (đã xác")
    print("nhận khớp 0.39.0) — nếu 0 processor được bọc, script đã dừng lỗi rõ ràng ở trên,")
    print("không export ra model câm lặng sai. Vẫn CHƯA test A/B ảnh thật.")


if __name__ == "__main__":
    main()
