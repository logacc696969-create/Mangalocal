#!/usr/bin/env python3
"""mục 287 — TRẢ LỜI BẰNG SỐ ĐO: người CÙNG tuổi CÙNG giới có giống nhau không? CÙNG tuổi KHÁC giới có giống nhau không? Có phụ thuộc phát triển nhanh/chậm không?
Hai nguồn: (A) CDC 2000 stature-for-age (tham số LMS theo tháng, tools/data/cdc2000_stature_lms.txt) cho PHÂN TÁN chiều cao cùng tuổi và khoảng cách nam–nữ; (B) các bảng nam/nữ sẵn có của dự án (Schmid 2019,
NHANES III, Zivicnjak 2008) cho giả thuyết "lệch pha thời gian": đường cong của nữ tại tuổi a ≈ đường cong của nam tại tuổi a+δ khi mỗi số đo tính so với người lớn CÙNG giới. Thuần Python, không cần kotlinc."""
import math, os, sys
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data'); fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)
# ───── (A) CDC LMS ─────
T = {'M': {}, 'F': {}}
for l in open(os.path.join(D, 'cdc2000_stature_lms.txt'), encoding='utf-8'):
    if l.startswith('#') or not l.strip(): continue
    s, m, L, M, S = l.split(); T[s][float(m) / 12] = (float(L), float(M), float(S))
def lms(s, a):
    ks = sorted(T[s]); a = min(max(a, ks[0]), ks[-1])
    for i in range(len(ks) - 1):
        if ks[i] <= a <= ks[i + 1]:
            t = (a - ks[i]) / (ks[i + 1] - ks[i]); u, v = T[s][ks[i]], T[s][ks[i + 1]]; return tuple(u[k] + t * (v[k] - u[k]) for k in range(3))
def val(s, a, z): L, M, S = lms(s, a); return M * (1 + L * S * z) ** (1 / L) if L else M * math.exp(S * z)
sd = lambda s, a: (val(s, a, 1) - val(s, a, -1)) / 2; med = lambda s, a: val(s, a, 0); cv = lambda s, a: sd(s, a) / med(s, a)
slope = lambda s, a: med(s, a + .5) - med(s, a - .5)          # cm/năm
Phi = lambda x: .5 * (1 + math.erf(x / math.sqrt(2)))
dd = lambda a: (med('M', a) - med('F', a)) / math.sqrt((sd('M', a) ** 2 + sd('F', a) ** 2) / 2)   # chênh lệch nam−nữ tính theo SD gộp (Cohen d)
pgt = lambda a: Phi(-dd(a) / math.sqrt(2))                    # xác suất một bé GÁI cao hơn một bé TRAI ngẫu nhiên cùng tuổi
check(len(T['M']) == 217 and len(T['F']) == 217 and min(T['M']) == 2.0 and abs(max(T['M']) - 20.0) < 1e-9, 'fixture CDC: 217 hàng/giới, mỗi tháng từ 24 đến 240 (2 → 20 tuổi)')
ages = [a / 2 for a in range(4, 41)]
for s, name, sd_peak_lo, sd_peak_hi, sd20 in (('M', 'nam', 7.9, 8.2, 7.14), ('F', 'nữ', 7.3, 7.6, 6.47)):
    pk = max(ages, key=lambda a: sd(s, a)); cpk = max(ages, key=lambda a: cv(s, a))
    check(3.3 <= sd(s, 2) <= 3.7 and sd_peak_lo <= sd(s, pk) <= sd_peak_hi and abs(sd(s, 20) - sd20) < 0.1, f'{name}: SD chiều cao cùng tuổi tăng từ {sd(s,2):.1f} cm (2 tuổi) lên đỉnh {sd(s,pk):.1f} cm ({pk:.1f} tuổi) rồi {sd(s,20):.1f} cm (20 tuổi)')
    check(cv(s, cpk) >= 0.049 and cv(s, cpk) >= 1.2 * cv(s, 20) and 11 <= cpk <= 14, f'{name}: hệ số biến thiên đỉnh {cv(s,cpk)*100:.2f}% ở {cpk:.1f} tuổi so với {cv(s,20)*100:.2f}% người lớn (cao hơn ≥ 20%): dậy thì làm người cùng tuổi KHÁC NHAU hơn')
check(all(abs(dd(a)) <= 0.45 for a in (2, 3, 4, 5, 6, 7, 8, 9, 10)) and all(0.36 <= pgt(a) <= 0.52 for a in (2, 4, 6, 8, 10)), 'CÙNG TUỔI KHÁC GIỚI, dưới 11 tuổi: nam–nữ cách nhau ≤ 0,45 SD; xác suất một bé gái cao hơn một bé trai cùng tuổi = %s (gần tung đồng xu)' % ', '.join(f'{a}t {pgt(a)*100:.0f}%' for a in (4, 8, 10)))
check(all(dd(a) < 0 for a in (11.5, 12, 12.5)) and med('M', 12) - med('F', 12) < -1.5 and pgt(12) >= 0.55, f'11,5–12,5 tuổi: bé GÁI cao hơn bé trai (12 tuổi: {med("F",12)-med("M",12):.1f} cm, {pgt(12)*100:.0f}% cặp gái cao hơn) — nữ dậy thì sớm hơn')
check(dd(14) >= 0.4 and dd(15) >= 1.0 and 1.8 <= dd(18) <= 2.0 and pgt(18) <= 0.11, f'từ 14 tuổi nam vượt nhanh: 15 tuổi +{med("M",15)-med("F",15):.1f} cm ({dd(15):.2f} SD), 18 tuổi +{med("M",18)-med("F",18):.1f} cm ({dd(18):.2f} SD); chỉ {pgt(18)*100:.0f}% cặp gái cao hơn')
tm = {a: sd('M', a) / slope('M', a) for a in (8, 9, 10, 11, 12, 13, 14)}; tf = {a: sd('F', a) / slope('F', a) for a in (8, 9, 10, 11, 12)}
check(all(0.95 <= v <= 1.45 for v in tm.values()) and all(0.95 <= v <= 1.30 for v in tf.values()), f'"độ lệch nhịp tương đương" = SD ÷ tốc độ tăng chiều cao ≈ {min(tm.values()):.2f}–{max(tm.values()):.2f} năm (nam 8–14 tuổi), {min(tf.values()):.2f}–{max(tf.values()):.2f} năm (nữ 8–12): cỡ ±1 năm, khớp độ lệch tuổi đạt đỉnh tăng trưởng trong y văn')
check(slope('F', 15) < 1.5 and sd('F', 15) / slope('F', 15) > 3, 'ngoài dậy thì (tốc độ → 0) SD ÷ tốc độ vô nghĩa: biến thiên khi đó là KÍCH THƯỚC trưởng thành, không phải nhịp — cần HAI tham số (kích thước + nhịp)')
# ───── (B) giả thuyết lệch pha trên các bảng của dự án ─────
pub = {'M': {}, 'F': {}}
for l in open(os.path.join(D, 'schmid2019_tableA1.txt'), encoding='utf-8'):
    if l[0] in 'MF': p = l.split(); pub[p[0]][int(p[1])] = [float(x) for x in p[2:8]]
def parse(fn):
    o = {}
    for l in open(os.path.join(D, fn), encoding='utf-8'):
        if l.startswith('#') or not l.strip(): continue
        tb, sx, age, n, mean, sd_ = l.split(); o[(tb, sx, int(age))] = float(mean)
    return o
NH, ZV = parse('nhanes3_breadth_t53_t56.txt'), parse('zivicnjak2008_tables1_4.txt')
def interp(f, a):
    a = min(max(a, 6), 18); i = int(math.floor(a)); j = min(i + 1, 18); t = a - i; return f[i] * (1 - t) + f[j] * t
def fit(F, M):   # nữ(a) ≈ nam(a+δ), a ∈ 8..14; δ ∈ [0, 4] bước 0,05
    ag = range(8, 15); r0 = math.sqrt(sum((F[a] - M[a]) ** 2 for a in ag) / len(ag))
    r1, d = min((math.sqrt(sum((F[a] - interp(M, a + k / 20)) ** 2 for a in ag) / len(ag)), k / 20) for k in range(0, 81)); return d, r0, r1
prog = lambda c: (lambda s: {a: pub[s][a][c] * (pub[s][a][0] if c else 1) / (pub[s][18][c] * (pub[s][18][0] if c else 1)) for a in range(6, 19)})   # tiến độ so với người lớn CÙNG giới (cm tuyệt đối)
SER = {'chiều cao': prog(0)}
for nm, c in (('thân+đầu+cổ', 1), ('đùi', 2), ('cẳng chân', 3), ('cánh tay trên', 4), ('cẳng tay', 5)): SER[nm + ' (cm tuyệt đối)'] = prog(c)
for nm, src, tb in (('vai NHANES III', NH, 'T53'), ('vai Zivicnjak', ZV, 'T1'), ('hông NHANES III', NH, 'T56'), ('hông Zivicnjak', ZV, 'T4')):
    SER[nm] = (lambda src, tb: (lambda s: {a: src[(tb, s, a)] / src[(tb, s, 18)] for a in range(6, 19)}))(src, tb)
R = {nm: fit(f('F'), f('M')) for nm, f in SER.items()}
for nm, (d, r0, r1) in R.items(): print(f'  [số đo] {nm:30s} δ = {d:4.2f} năm; sai số chưa dịch {r0:.4f} → đã dịch {r1:.4f} (giảm {(1-r1/r0)*100:.0f}%)')
core = ['chiều cao', 'thân+đầu+cổ (cm tuyệt đối)', 'đùi (cm tuyệt đối)', 'cẳng chân (cm tuyệt đối)', 'cánh tay trên (cm tuyệt đối)', 'cẳng tay (cm tuyệt đối)']
check(all(1.4 <= R[n][0] <= 2.4 for n in core), f'chiều cao và MỌI đoạn chi: nữ(a) ≈ nam(a+δ), δ = {min(R[n][0] for n in core):.2f}–{max(R[n][0] for n in core):.2f} năm (cùng cỡ với chênh lệch tuổi đạt đỉnh tăng trưởng ~1,7–1,9 năm)')
check(all(R[n][2] <= 0.3 * R[n][1] for n in core), f'dịch pha giảm ≥ 70% sai số nam–nữ (khi tính so với người lớn CÙNG giới): khác biệt giới lúc dậy thì CHỦ YẾU là lệch nhịp, phần còn lại là kích thước trưởng thành khác nhau')
check(all(2.3 <= R[n][0] <= 3.1 for n in ('vai NHANES III', 'vai Zivicnjak')) and all(0.8 <= R[n][0] <= 1.5 for n in ('hông NHANES III', 'hông Zivicnjak')), 'bề ngang: vai nam muộn hơn nữ ≈ 2,6–2,8 năm, hông chỉ ≈ 1,1 năm — vai và hông KHÔNG cùng nhịp (khớp lý do tách hông ở 285)')
fr = lambda c: max(abs(pub['M'][a][c] - pub['F'][a][c]) for a in range(6, 19))
check(fr(1) <= 0.01 and fr(2) <= 0.02 and fr(3) <= 0.02 and fr(4) <= 0.006 and fr(5) <= 0.006, f'TỶ LỆ theo % chiều cao: nam và nữ cùng tuổi lệch nhau ≤ {max(fr(c) for c in range(1,6))*100:.1f}% chiều cao ở mọi tuổi 6–18 (thân {fr(1)*100:.1f}, đùi {fr(2)*100:.1f}, cẳng chân {fr(3)*100:.1f}, cánh tay {fr(4)*100:.1f}, cẳng tay {fr(5)*100:.1f}) — tỷ lệ gần như CHUNG cho hai giới; khác biệt chính là kích thước và nhịp')
print('\nĐẠT' if not fails else '\nTHẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
