#!/usr/bin/env python3
# mục 280 — CHẠY THẬT blazepose_wrapper.cpp trên máy chủ (không phải Android) và so từng số với tflite chuẩn trên ảnh người thật. Kiểm đúng chỗ rủi ro nhất của lớp native: layout tensor đầu vào (NHWC),
# chọn đầu ra theo số phần tử, sao chép. Cách làm: biên dịch tools/native_tests/blazepose_host_main.cpp (include thẳng wrapper) với stub jni.h/android/log.h của dự án và header MNN THẬT, liên kết với
# _mnncengine*.so của gói pip MNN (có xuất ký hiệu C++ của MNN; build ABI cũ nên dùng -D_GLIBCXX_USE_CXX11_ABI=0; cần nạp sẵn libpython).
# Cần: g++, thư mục header MNN ($MNN_INCLUDE = .../MNN/include, ví dụ `git clone --depth 1 --branch 3.6.1 --filter=blob:none --sparse https://github.com/alibaba/MNN && cd MNN && git sparse-checkout set include`),
#      pip MNN + numpy + Pillow + ai-edge-litert, và thư mục đệm của test_blazepose_lift.py ($BLAZEPOSE_DIR; có pose_landmark_lite.tflite, blazepose_lite.mnn, bus.jpg). Thiếu → BỎ QUA, nói rõ.
import glob, os, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE = os.environ.get('BLAZEPOSE_DIR', os.path.join(ROOT, 'tools', '.cache_blazepose'))
inc = os.environ.get('MNN_INCLUDE', '')
def skip(why): print('BỎ QUA test native: ' + why); sys.exit(0)
if not shutil.which('g++'): skip('không có g++')
if not os.path.isfile(os.path.join(inc, 'MNN', 'Interpreter.hpp')): skip('đặt MNN_INCLUDE=thư mục include của MNN 3.6.1')
try:
    import numpy as np, MNN
    from PIL import Image
    from ai_edge_litert.interpreter import Interpreter
except Exception as e: skip(f'thiếu thư viện Python ({e})')
need = [os.path.join(CACHE, n) for n in ('pose_landmark_lite.tflite', 'blazepose_lite.mnn', 'bus.jpg')]
if not all(os.path.exists(p) for p in need): skip('thiếu tệp trong BLAZEPOSE_DIR — chạy tools/test_blazepose_lift.py một lần để tải/chuyển')
so = glob.glob(os.path.join(os.path.dirname(MNN.__file__), '..', '_mnncengine*.so')) or glob.glob(os.path.join(os.path.dirname(os.path.dirname(MNN.__file__)), '_mnncengine*.so'))
lp = glob.glob('/usr/lib/x86_64-linux-gnu/libpython3*.so')
if not so or not lp: skip('không thấy _mnncengine*.so hoặc libpython (chỉ hỗ trợ Linux x86_64 với gói pip MNN)')
tmp = tempfile.mkdtemp(prefix='bpn_'); exe = os.path.join(tmp, 'bp_host')
r = subprocess.run(['g++', '-std=c++14', '-O1', '-D_GLIBCXX_USE_CXX11_ABI=0', f'-I{inc}', '-I' + os.path.join(ROOT, 'tools/stubs'), os.path.join(ROOT, 'tools/native_tests/blazepose_host_main.cpp'), '-o', exe, so[0],
                    '-Wl,--allow-shlib-undefined', '-Wl,-rpath,' + os.path.dirname(so[0]), '-lpthread', '-ldl'], capture_output=True, text=True)
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)
check(r.returncode == 0, 'biên dịch + liên kết blazepose_wrapper.cpp (header MNN thật) thành chương trình chạy được' + ('' if r.returncode == 0 else '\n' + r.stderr[-800:]))
if r.returncode == 0:
    mdir = os.path.join(tmp, 'model'); os.makedirs(mdir); shutil.copy(os.path.join(CACHE, 'blazepose_lite.mnn'), mdir)   # chỉ lite ⇒ wrapper nạp lite
    tfl = Interpreter(model_path=os.path.join(CACHE, 'pose_landmark_lite.tflite')); tfl.allocate_tensors()
    tin = tfl.get_input_details()[0]; touts = {d['name']: d for d in tfl.get_output_details()}
    bus = Image.open(os.path.join(CACHE, 'bus.jpg')).convert('RGB')
    env = dict(os.environ, LD_PRELOAD=lp[0])
    for nm, (x1, y1, x2, y2) in {'trai': (50, 398, 245, 904), 'giua': (222, 405, 345, 860)}.items():
        cx, cy, side = (x1 + x2) / 2, (y1 + y2) / 2, max(x2 - x1, y2 - y1) * 1.25; a = side / 256
        crop = np.asarray(bus.transform((256, 256), Image.AFFINE, (a, 0, cx - side / 2, 0, a, cy - side / 2), resample=Image.BILINEAR), dtype=np.float32) / 255.0
        cf = os.path.join(tmp, nm + '.f32'); of = os.path.join(tmp, nm + '.out'); crop.astype('<f4').tofile(cf)
        p = subprocess.run([exe, mdir, cf, of], capture_output=True, text=True, env=env)
        check(p.returncode == 0 and 'ok 313 float' in p.stdout, f'[{nm}] wrapper chạy, trả đủ 313 float' + ('' if p.returncode == 0 else f' (rc {p.returncode}: {p.stderr[-200:]})'))
        if p.returncode != 0: continue
        out = np.fromfile(of, dtype='<f4')
        tfl.set_tensor(tin['index'], crop[None]); tfl.invoke(); g = lambda n: tfl.get_tensor(touts[n]['index']).reshape(-1)
        d_flag = abs(out[0] - g('Identity_1')[0]); d_lm = np.abs(out[1:196] - g('Identity')).max(); d_w = np.abs(out[196:] - g('Identity_4')).max()
        check(d_flag < 1e-3 and d_lm < 0.01 and d_w < 1e-3, f'[{nm}] C++ wrapper = tflite chuẩn: |Δ cờ| {d_flag:.5f}, |Δ điểm ảnh| {d_lm:.4f} px, |Δ world| {d_w:.5f} m')
shutil.rmtree(tmp, ignore_errors=True)
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
