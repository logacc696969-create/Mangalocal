#!/usr/bin/env python3
"""mục 266 — canh LỆCH giữa `tools/remote_server/colab_remote_server.ipynb` (nhúng nguyên văn app.py) và `tools/remote_server/app.py`.

Bối cảnh: sau mục 248–250 app.py thêm 6 tác vụ nhưng notebook vẫn nhúng bản cũ (629 dòng so với 1425), dù ô Markdown ghi "giống hệt" — và không có
test nào phát hiện. Test này khoá cả hai chiều: (1) nội dung nhúng khớp app.py; (2) mọi import CẤP MODULE của app.py (chạy ngay lúc khởi động server) đều
được notebook `pip install` — nếu sau này ai thêm `import numpy` ở đầu app.py mà notebook không cài, Colab sẽ chết ngay khi khởi động.
Kèm thử phá mã: bộ kiểm phải bắt được lệch thật và KHÔNG báo lệch giả khi chỉ khác dấu xuống dòng cuối.
"""
import ast, importlib.util, json, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RS = os.path.join(ROOT, 'tools', 'remote_server')
spec = importlib.util.spec_from_file_location('sync_notebook', os.path.join(RS, 'sync_notebook.py'))
sn = importlib.util.module_from_spec(spec); spec.loader.exec_module(sn)
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + str(d)) if (d and not c) else '')); ok &= bool(c)

app = open(os.path.join(RS, 'app.py'), encoding='utf-8').read()
nb = json.load(open(os.path.join(RS, 'colab_remote_server.ipynb'), encoding='utf-8'))

# ---- (1) khớp nội dung
check('notebook có đúng 1 ô %%writefile app.py', sum(1 for c in nb['cells'] if c['cell_type'] == 'code' and ''.join(c['source']).lstrip().startswith('%%writefile app.py')) == 1)
emb = sn.embedded_text(nb)
check('nội dung nhúng KHỚP app.py (không lệch như trước mục 266: 629 so với 1425 dòng)', sn.is_synced(nb, app),
      f'nhúng {sn.normalise(emb).count(chr(10)) + 1} dòng, app.py {sn.normalise(app).count(chr(10)) + 1} dòng — chạy tools/remote_server/sync_notebook.py')
check('bản nhúng là Python hợp lệ (ast.parse)', bool(ast.parse(emb)))
for k in ('_TASK_HANDLERS', '_run_faceswap_sync', '_run_kontext_sync', '_run_handfix_sync', '_run_video_sync', '_run_interact_sync', 'pag_scale'):
    check(f'bản nhúng có {k} (tác vụ mới của mục 248–250)', k in emb)

# ---- (2) import cấp module phải được notebook cài
def module_imports(src):
    mods = set()
    for n in ast.parse(src).body:
        if isinstance(n, ast.Import): mods |= {a.name.split('.')[0] for a in n.names}
        elif isinstance(n, ast.ImportFrom) and n.module and n.level == 0: mods.add(n.module.split('.')[0])
    return mods - set(sys.stdlib_module_names)
PIP_NAME = {'PIL': 'pillow'}          # tên import != tên gói pip
def pip_lines(nbk):
    # CHỈ các dòng lệnh `!pip install` / `%pip install` ở ô code KHÁC ô nhúng app.py (docstring của app.py cũng có chữ "pip install" nhưng không phải lệnh cài)
    out = []
    for c in nbk['cells']:
        s = ''.join(c['source'])
        if c['cell_type'] != 'code' or s.lstrip().startswith('%%writefile'): continue
        out += [l for l in s.split('\n') if re.match(r'\s*[!%]pip\s+install', l)]
    return out
pip_text = '\n'.join(pip_lines(nb)).lower()
def missing(src):
    return sorted(m for m in module_imports(src) if PIP_NAME.get(m, m).lower() not in pip_text)
check('mọi import cấp module của app.py đều được notebook pip install', not missing(app), missing(app))
check('có lệnh pip install thật trong notebook (đối chứng cho bộ trích)', len(pip_lines(nb)) >= 2, pip_lines(nb))
check('đối chứng: bộ trích import thấy fastapi/uvicorn/PIL/cryptography', {'fastapi', 'uvicorn', 'PIL', 'cryptography'} <= module_imports(app), module_imports(app))

# ---- thử phá mã: bộ kiểm phải bắt lệch THẬT và không báo lệch GIẢ
def synced_with(mutated_app):
    return sn.is_synced(nb, mutated_app)
muts = [
    ('thêm một dòng vào app.py mà không đồng bộ', app + '\n# dòng mới\n'),
    ('đổi một ký tự trong app.py', app.replace('_TASK_HANDLERS', '_TASK_HANDLERZ', 1)),
    ('xoá một hàm tác vụ', app.replace('def _run_kontext_sync', 'def _run_kontext_sync_removed', 1)),
    ('khác khoảng trắng ở đầu dòng', app.replace('\n    task = payload.get("task")', '\n     task = payload.get("task")', 1)),
]
killed = 0
for name, m in muts:
    assert m != app, name
    bad = not synced_with(m)
    check(f'đột biến "{name}" bị bắt', bad); killed += bad
check('không báo lệch giả khi chỉ khác dấu xuống dòng cuối file', synced_with(app.rstrip('\n')) and synced_with(app.rstrip('\n') + '\n\n') is True)
check('không báo lệch giả với kiểu xuống dòng CRLF', synced_with(app.replace('\n', '\r\n')))
imp_mut = 'import numpy\n' + app
check('đột biến "thêm import numpy cấp module mà notebook không cài" bị bắt', missing(imp_mut) == ['numpy'], missing(imp_mut))
check('đột biến "import cục bộ trong hàm (lười)" KHÔNG bị báo nhầm', missing(app.replace('def _run_faceswap_sync', 'def _zz():\n    import numpy\n\n\ndef _run_faceswap_sync', 1)) == [])
check(f'thử phá mã: {killed}/{len(muts)} đột biến lệch bị bắt', killed == len(muts))
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
