#!/usr/bin/env python3
"""Xuất model nhận dạng khuôn mặt ArcFace (MobileFaceNet, insightface 'buffalo_s' / w600k_mbf.onnx) -> ONNX để mnnconvert.

mục 246 TECHNICAL_STATUS.md. Dùng làm THƯỚC ĐO DANH TÍNH (cosine giữa embedding hai khuôn mặt) cho "cổng danh tính" khi vẽ lại mặt/đổi biểu cảm.
Đây là thước đo cộng đồng dùng để đánh giá giữ danh tính (PuLID, InstantID, IP-Adapter FaceID đều báo cosine ArcFace/CurricularFace).

Đầu vào model: 112x112 RGB đã căn chỉnh 5 điểm, chuẩn hoá (x-127.5)/127.5, đầu ra embedding 512 chiều (cần L2-normalize).

GIỚI HẠN THẬT (chưa chạy thật — viết theo API insightface):
1. Script dựa vào việc `insightface.app.FaceAnalysis(name='buffalo_s')` tự tải bộ model về ~/.insightface/models/buffalo_s/ và bộ đó chứa
   w600k_mbf.onnx. Nếu insightface đổi tên file/bộ model, script báo rõ thay vì đoán.
2. ArcFace huấn luyện trên ẢNH THẬT: với nhân vật phong cách anime/tranh vẽ điểm giống kém tin cậy. Với mục tiêu ảnh siêu thực thì phù hợp.
3. Bản MNN chưa được thử với wrapper native.
"""
import argparse, glob, os, shutil, sys

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output_dir', default='./exported_arcface')
    args = ap.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    try:
        from insightface.app import FaceAnalysis  # noqa
    except Exception as e:
        print('Thiếu thư viện insightface/onnxruntime:', e); sys.exit(2)
    FaceAnalysis(name='buffalo_s', providers=['CPUExecutionProvider'])  # kích hoạt tải bộ model
    cands = glob.glob(os.path.expanduser('~/.insightface/models/buffalo_s/*w600k*.onnx'))
    if not cands:
        print('KHÔNG tìm thấy *w600k*.onnx trong ~/.insightface/models/buffalo_s — insightface có thể đã đổi bộ model.'); sys.exit(3)
    dst = os.path.join(args.output_dir, 'arcface_mbf.onnx')
    shutil.copy(cands[0], dst)
    try:
        import onnx
        m = onnx.load(dst)
        i = m.graph.input[0]
        dims = [d.dim_value or d.dim_param for d in i.type.tensor_type.shape.dim]
        print('input:', i.name, dims)
    except Exception as e:
        print('(không đọc được shape bằng onnx:', e, ')')
    print('OK ->', dst)

if __name__ == '__main__':
    main()
