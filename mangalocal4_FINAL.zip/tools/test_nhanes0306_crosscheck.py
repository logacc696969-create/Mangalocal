#!/usr/bin/env python3
"""mục 286 — KIỂM CHÉO ĐỘC LẬP bảng Schmid 2019 (6–18 tuổi) bằng NHANES 2003–2006 (NCHS NHSR số 10; tools/data/nhanes2003_2006_height_armlen.txt chép nguyên văn) và ghi lại các SỰ THẬT đo được
cho trẻ 2–5 tuổi và người lớn >18 tuổi mà mã CHƯA dùng (vì sao chưa dùng: xem TECHNICAL_STATUS.md mục 286). Thuần Python, không cần kotlinc."""
import os, sys
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data'); fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)
pub = {'M': {}, 'F': {}}
for l in open(os.path.join(D, 'schmid2019_tableA1.txt'), encoding='utf-8'):
    if l[0] in 'MF': p = l.split(); pub[p[0]][int(p[1])] = [float(x) for x in p[2:8]]
N = {}
for l in open(os.path.join(D, 'nhanes2003_2006_height_armlen.txt'), encoding='utf-8'):
    if l.startswith('#') or not l.strip(): continue
    t, s, a, v = l.split(); N[(t, s, a)] = float(v)
check(sum(1 for k in N if k[0] in ('T7', 'T24')) == 72 and sum(1 for k in N if k[0] in ('T9', 'T11', 'T25', 'T26')) == 28, 'fixture: 72 ô trẻ em (2 bảng × 2 giới × 18 tuổi) + 28 ô người lớn (4 bảng × 7 nhóm tuổi)')
# (1) chiều cao hai nguồn độc lập khớp
dh = {(s, a): (N[('T7', s, str(a))] / pub[s][a][0] - 1) * 100 for s in 'MF' for a in range(6, 19)}
check(max(abs(v) for v in dh.values()) <= 3.6, f'chiều cao NHANES 2003–06 so với bảng Schmid, 6–18 tuổi × 2 giới: lệch lớn nhất {max(abs(v) for v in dh.values()):.2f}% (≤ 3,6%) — hai nguồn độc lập đồng thuận')
# (2) cánh tay trên: định nghĩa mốc đo KHÁC nhau (NHANES: mỏm cùng vai sau → đỉnh mỏm khuỷu; Schmid: đoạn khớp–khớp) ⇒ NHANES dài hơn, và độ lệch ổn định theo tuổi
rat = {}; off = {}
for s in 'MF':
    for a in range(6, 19):
        h = N[('T7', s, str(a))]; sch = pub[s][a][4] * h        # đoạn Schmid quy ra cm trên chính cơ thể NHANES cùng tuổi (loại sai khác chiều cao giữa hai quần thể)
        rat[(s, a)] = N[('T24', s, str(a))] / sch; off[(s, a)] = N[('T24', s, str(a))] - sch
check(all(1.08 <= v <= 1.16 for v in rat.values()), f'cánh tay trên NHANES / Schmid ∈ [1,08; 1,16] ở mọi tuổi/giới (thực đo {min(rat.values()):.3f}–{max(rat.values()):.3f}): khác ĐỊNH NGHĨA mốc đo, KHÔNG phải sai số số liệu')
check(all(2.5 <= v <= 4.5 for v in off.values()), f'độ lệch tuyệt đối {min(off.values()):.2f}–{max(off.values()):.2f} cm (2,5–4,5 cm) ở mọi tuổi/giới — cỡ phần mỏm khuỷu + mỏm cùng vai nhô ra ngoài đoạn khớp–khớp')
# (3) HỆ QUẢ: không nối chuỗi tỷ lệ giữa hai nguồn. Ghi lại số đo thật 2–5 tuổi (NHANES) để dùng khi có đủ các đoạn khác.
ua_h = {(s, a): N[('T24', s, str(a))] / N[('T7', s, str(a))] for s in 'MF' for a in range(2, 20)}
check(all(abs(ua_h[(s, a)] / ua_h[(s, 6)] - 1) <= 0.03 for s in 'MF' for a in range(2, 6)), 'NHANES: cánh tay trên / chiều cao ở 2–5 tuổi trong ±3% giá trị 6 tuổi (0,204–0,208; gần hằng) — nhưng cùng mốc đo NHANES, KHÔNG dùng được trực tiếp cho đoạn khớp–khớp của Schmid')
check(all(('T36' not in k[0]) for k in N), 'nguồn KHÔNG có đùi/cẳng chân/cẳng tay/chiều cao ngồi cho 2–5 tuổi (đùi chỉ đo từ 8 tuổi) ⇒ không đủ dựng Segments cho trẻ 2–5 tuổi')
# (4) người lớn >18: đo thật thay cho khẳng định "≈1 cm/thập kỷ sau 30–40 tuổi" của 284.2
G = ['20-29', '30-39', '40-49', '50-59', '60-69', '70-79', '80+']
for s, th, tu in (('M', 'T11', 'T26'), ('F', 'T9', 'T25')):
    hr = [N[(th, s, g)] / N[(th, s, G[0])] for g in G]; ur = [N[(tu, s, g)] / N[(tu, s, G[0])] for g in G]
    check(all(0.99 <= x <= 1.01 for x in hr[1:4]), f'{s}: chiều cao 30–59 tuổi trong ±1% so với 20–29 ({[round(x, 3) for x in hr[1:4]]}) — KHÔNG có sụt ~1 cm/thập kỷ từ 30–40 tuổi như 284.2 từng viết')
    check(hr[4] >= hr[5] >= hr[6] and hr[5] <= 0.985 and hr[6] <= 0.97, f'{s}: sụt chiều cao chỉ rõ từ 60 tuổi: 70–79 → {hr[5]:.3f}, 80+ → {hr[6]:.3f} so với 20–29 (cắt ngang dân số: gồm cả hiệu ứng thế hệ)')
    check(all(0.975 <= x <= 1.025 for x in ur), f'{s}: chiều dài cánh tay trên KHÔNG đổi theo tuổi người lớn (±2,5%: {min(ur):.3f}–{max(ur):.3f}) ⇒ phần sụt chiều cao nằm ở thân/chân, không ở tay')
print('\nĐẠT' if not fails else '\nTHẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
