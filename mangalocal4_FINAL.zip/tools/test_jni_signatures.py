#!/usr/bin/env python3
"""mục 248 — kiểm tra chữ ký JNI MỨC THAM SỐ giữa NativeBridge.kt và các file .cpp.

Vì sao: audit cũ (mục 203/247) chỉ so TÊN hàm (63/63 khớp). Nhưng lệch SỐ LƯỢNG hoặc KIỂU tham số KHÔNG báo lỗi biên dịch —
nó sập (UnsatisfiedLinkError / sai bộ nhớ) lúc chạy, đúng loại lỗi chỉ lộ trên máy. Bộ này đọc cả hai phía (bỏ comment, tách
tham số ở dấu phẩy cấp ngoài cùng) rồi so từng vị trí theo bảng kiểu Kotlin -> JNI.

Giới hạn thật: không phân biệt `jobject` với các kiểu đối tượng cụ thể (Bitmap, callback) — chỉ yêu cầu cùng là đối tượng;
tham số mặc định của Kotlin (`= null`) không ảnh hưởng chữ ký JNI nên được bỏ qua. Không thay build/chạy thật.
"""
import glob, os, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
KT = open(os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline/NativeBridge.kt'), encoding='utf8', errors='replace').read()
CPPS = {f: open(f, encoding='utf8', errors='replace').read() for f in glob.glob(os.path.join(ROOT, 'app/src/main/jni/**/*.cpp'), recursive=True)}

def strip_comments(s):
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    return re.sub(r'//[^\n]*', '', s)

def split_top(s, sep=','):
    out, depth, cur = [], 0, ''
    for ch in s:
        if ch in '(<[{': depth += 1
        elif ch in ')>]}': depth -= 1
        if ch == sep and depth == 0: out.append(cur); cur = ''
        else: cur += ch
    if cur.strip(): out.append(cur)
    return [x.strip() for x in out if x.strip()]

KMAP = {'Int': 'jint', 'Long': 'jlong', 'Float': 'jfloat', 'Double': 'jdouble', 'Boolean': 'jboolean', 'String': 'jstring',
        'ByteArray': 'jbyteArray', 'FloatArray': 'jfloatArray', 'IntArray': 'jintArray', 'LongArray': 'jlongArray',
        'DoubleArray': 'jdoubleArray', 'Unit': 'void', 'Short': 'jshort'}
def k2j(t):
    t = t.strip().rstrip('?').strip()
    if t in KMAP: return KMAP[t]
    if t.startswith('Array<'): return 'jobjectArray'
    return 'jobject'           # Bitmap, callback, ...

# ---- Kotlin ----
kt = strip_comments(KT)
kfuns = {}
for m in re.finditer(r'external\s+fun\s+(\w+)\s*\(', kt):
    i = m.end(); depth = 1; j = i
    while depth:
        depth += {'(': 1, ')': -1}.get(kt[j], 0); j += 1
    params_src = kt[i:j - 1]
    rest = kt[j:j + 80]
    rm = re.match(r'\s*:\s*([\w<>?\[\], ]+?)\s*(?:\n|external|$)', rest)
    ret = rm.group(1).strip() if rm else 'Unit'
    params = []
    for p in split_top(params_src):
        # "name: Type = default"  -> Type
        pm = re.match(r'\w+\s*:\s*(.+?)(?:\s*=\s*.*)?$', p, re.S)
        params.append(k2j(pm.group(1)) if pm else '??')
    kfuns[m.group(1)] = (params, k2j(ret))

# ---- C++ ----
cfuns = {}
for f, src in CPPS.items():
    s = strip_comments(src)
    for m in re.finditer(r'(?:extern\s+"C"\s+)?JNIEXPORT\s+(\w+)\s+JNICALL\s+Java_com_mangalocal_pipeline_NativeBridge_(\w+)\s*\(', s):
        i = m.end(); depth = 1; j = i
        while depth:
            depth += {'(': 1, ')': -1}.get(s[j], 0); j += 1
        ps = split_top(s[i:j - 1])
        types = []
        for p in ps:
            p = re.sub(r'\bconst\b', '', p).strip()
            tm = re.match(r'(j\w+|JNIEnv\s*\*)', p)
            types.append(tm.group(1).replace(' ', '') if tm else '??')
        cfuns[m.group(2)] = (types[2:], m.group(1), os.path.relpath(f, ROOT), types[:2])

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

check('đọc được ≥ 60 hàm Kotlin và ≥ 60 hàm JNI C++ (parser không bỏ sót)', len(kfuns) >= 60 and len(cfuns) >= 60)
check('cùng tập tên hàm hai phía', set(kfuns) == set(cfuns))
bad = []
for n in sorted(set(kfuns) & set(cfuns)):
    kp, kr = kfuns[n]; cp, cr, f, head = cfuns[n]
    if head[0] != 'JNIEnv*' or head[1] not in ('jobject', 'jclass'): bad.append((n, 'đầu hàm', head))
    if len(kp) != len(cp): bad.append((n, 'SỐ tham số', 'Kotlin %d' % len(kp), 'C++ %d' % len(cp), f))
    else:
        for idx, (a, b) in enumerate(zip(kp, cp)):
            if a != b: bad.append((n, 'tham số #%d' % (idx + 1), 'Kotlin→%s' % a, 'C++ %s' % b, f))
    if kr != cr: bad.append((n, 'kiểu trả về', 'Kotlin→%s' % kr, 'C++ %s' % cr, f))
check('MỌI hàm: cùng số tham số, cùng kiểu từng tham số, cùng kiểu trả về (%d hàm)' % len(set(kfuns) & set(cfuns)), not bad)
for b in bad[:12]: print('   ', b)
check('hàm mới setDifferentialDiffusion được parser nhìn thấy: (jboolean) -> void', kfuns.get('setDifferentialDiffusion') == (['jboolean'], 'void') and cfuns['setDifferentialDiffusion'][:2] == (['jboolean'], 'void'))
check('hàm nhiều tham số nhất vẫn được so đủ (parser xử lý comment xen giữa tham số)', max(len(v[0]) for v in kfuns.values()) >= 15)

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
