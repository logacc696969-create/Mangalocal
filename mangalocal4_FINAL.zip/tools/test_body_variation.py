#!/usr/bin/env python3
"""mục 288 — kiểm `model/BodyVariation.kt` (triển khai 287.4: nhịp tempoYears + kích thước heightZ + nội suy tuổi phân số).

(1) Bảng CV_MALE/CV_FEMALE trong Kotlin khớp TỪNG SỐ (sai ≤ 5e-7) với cột S của bảng LMS CDC chép ở tools/data/cdc2000_stature_lms.txt tại tháng 72,84,…,216.
(2) BIÊN DỊCH + CHẠY mã Kotlin thật (tools/kotlin_tests/BodyVariationTest.kt, ~20 phép kiểm) cùng AgeBodyTable.kt nếu có kotlinc; không có -> BỎ QUA phần (2) và nói rõ.
(3) Phá mã (chỉ khi có --mut; mỗi lần = một lần biên dịch ~30 s): sửa mã nguồn có chủ đích, chạy lại, PHẢI có phép kiểm FAIL. `MUT_RANGE=lo:hi` để chạy từng khúc.
KHÔNG chứng minh: chưa nối vào UI/Character/BoneProportions (lớp tính toán độc lập); bảng LMS là dân số Mỹ; heightZ nhân đồng đều mọi độ dài.
"""
import os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
M = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/model')
BV, TBL = os.path.join(M, 'BodyVariation.kt'), os.path.join(M, 'AgeBodyTable.kt')
DRV = os.path.join(ROOT, 'tools/kotlin_tests/BodyVariationTest.kt')
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)

# (1) bảng CV = cột S của LMS
lms = {}
for l in open(os.path.join(ROOT, 'tools/data/cdc2000_stature_lms.txt'), encoding='utf-8'):
    if l[0] in 'MF' and not l.startswith('#'):
        s, mth, L, Mm, S = l.split(); lms[(s, int(mth))] = float(S)
src = open(BV, encoding='utf-8').read()
def kt_arr(name):
    m = re.search(r'private val ' + name + r' = floatArrayOf\((.*?)\)', src, re.S)
    return [float(x.strip().rstrip('f')) for x in m.group(1).split(',')]
for sx, name in (('M', 'CV_MALE'), ('F', 'CV_FEMALE')):
    a = kt_arr(name); exp = [lms[(sx, age * 12)] for age in range(6, 19)]
    check(len(a) == 13 and all(abs(x - y) <= 5e-7 for x, y in zip(a, exp)), f'{name}: 13 giá trị khớp cột S của LMS CDC tại 72,84,…,216 tháng (sai ≤ 5e-7)')
check('MAX_TEMPO_YEARS = 3f' in src and 'MAX_HEIGHT_Z = 3f' in src and 'GIỚI HẠN THẬT' in src, 'ghi rõ kẹp ±3 và giới hạn thật ngay trong mã')

# (2)+(3)
def find(c):
    for p in c:
        if p and os.path.exists(p): return p
KOTLINC = find([os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/tools/kotlinc/bin/kotlinc', '/home/claude/work/kotlinc/bin/kotlinc'])
if not KOTLINC or not shutil.which('java'):
    print('BỎ QUA phần chạy Kotlin thật: không có kotlinc/java (phần (1) đã chạy)')
    sys.exit(1 if fails else 0)
env = dict(os.environ, JAVA_OPTS='-Xmx2g')
def run_kotlin(bv_path, tag):
    d = tempfile.mkdtemp(); jar = os.path.join(d, 'bv.jar')
    r = subprocess.run([KOTLINC, bv_path, TBL, DRV, '-include-runtime', '-d', jar], capture_output=True, text=True, env=env)
    if r.returncode != 0: return 'COMPILE', r.stderr[-600:]
    r = subprocess.run(['java', '-jar', jar], capture_output=True, text=True)
    return ('OK' if r.returncode == 0 else 'FAIL'), r.stdout + r.stderr
st, out = run_kotlin(BV, 'gốc')
for l in out.splitlines():
    if l.startswith(('PASS', 'FAIL')): print(l)
    if l.startswith('FAIL'): fails.append(l)
check(st == 'OK' and 'TẤT CẢ ĐẠT' in out, 'driver Kotlin thật: TẤT CẢ ĐẠT (biên dịch + chạy)')
if st == 'COMPILE': print(out)

if '--mut' in sys.argv:
    MUTS = [
        ('bỏ nhân CV (1 + z thay vì 1 + z·CV)', 'return (1f + z * cv(age, sex)).coerceAtLeast(MIN_SCALE)', 'return (1f + z).coerceAtLeast(MIN_SCALE)'),
        ('bỏ kẹp tempo', 'tempoYears.coerceIn(-MAX_TEMPO_YEARS, MAX_TEMPO_YEARS)', 'tempoYears'),
        ('nhịp trừ thay vì cộng', 'return clampAge(age + t)', 'return clampAge(age - t)'),
        ('nội suy sai trọng số (w*w)', 'val w = c - lo', 'val w = (c - lo) * (c - lo)'),
        ('bỏ nhánh tuổi nguyên (luôn nội suy)', 'return if (w <= 0f || lo >= AgeBodyTable.MAX_AGE) Frac(lo, lo, 0f) else Frac(lo, lo + 1, w)', 'return Frac(lo, minOf(lo + 1, AgeBodyTable.MAX_AGE), w + 1e-4f)'),
        ('tráo bảng CV nam/nữ', 'BodySex.MALE -> CV_MALE[k]; BodySex.FEMALE -> CV_FEMALE[k]', 'BodySex.MALE -> CV_FEMALE[k]; BodySex.FEMALE -> CV_MALE[k]'),
        ('bỏ kẹp z', 'heightZ.coerceIn(-MAX_HEIGHT_Z, MAX_HEIGHT_Z)', 'heightZ'),
        ('NaN không được xử lý ở tuổi', 'if (age.isNaN()) AgeBodyTable.MIN_AGE.toFloat() else age.coerceIn', 'if (false) AgeBodyTable.MIN_AGE.toFloat() else age.coerceIn'),
    ]
    lo, hi = (int(x) for x in os.environ.get('MUT_RANGE', f'0:{len(MUTS)}').split(':'))
    for i, (name, a, b) in enumerate(MUTS[lo:hi], lo):
        if a not in src: check(False, f'phá mã [{name}]: không tìm thấy đoạn'); continue
        d = tempfile.mkdtemp(); p = os.path.join(d, 'BodyVariation.kt'); open(p, 'w', encoding='utf-8').write(src.replace(a, b, 1))
        st2, out2 = run_kotlin(p, name); caught = st2 in ('FAIL', 'COMPILE') and ('FAIL ' in out2 or st2 == 'COMPILE')
        check(caught, f'phá mã {i + 1}/{len(MUTS)} [{name}] bị bắt'); 
else:
    print('(bỏ qua phá mã — chạy với --mut; có 8, MUT_RANGE=lo:hi để chạy từng khúc)')
print('\nKẾT QUẢ:', 'CÓ LỖI %d' % len(fails) if fails else 'TẤT CẢ ĐẠT')
sys.exit(1 if fails else 0)
