#!/usr/bin/env python3
# mục 285 — GIỚI (nam/nữ) trong giải phẫu theo tuổi. Bốn lớp kiểm:
#  (1) Python tính ĐÁP ÁN ĐỘC LẬP (vai, hông, 8 tỷ lệ tuyệt đối, nam và nữ × 6–18 tuổi) từ ba tệp nguồn chép nguyên văn, không đọc mã Kotlin ngoài việc lấy chiều cao/đoạn từ chính bảng Schmid trong tools/data;
#  (2) "ĐÁP ÁN VÀNG": chương trình AgeGoldenDump.kt (biên dịch với mã MỚI) phải in ra ĐÚNG TỪNG BIT như mã TRƯỚC mục 285 (tools/data/age_body_unisex_golden.txt) — bằng chứng không chọn giới thì không đổi gì;
#  (3) chạy mã Kotlin thật (tools/kotlin_tests/AgeSexTest.kt) — Gson thật, CharacterLibrary thật, AgeBodyScaler thật;
#  (4) phá mã có chủ đích (--mut; MUT_RANGE=lo:hi để chạy từng khúc) — mỗi đột biến phải làm ít nhất một kiểm FAIL.
# Cần kotlinc 1.9.x (KOTLINC), Gson (GSON_JAR), android.jar (ANDROID_JAR). Thiếu thì BỎ QUA lớp (2)–(4) và nói rõ; lớp (1) luôn chạy.
import os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K = os.path.join(ROOT, 'app/src/main/java/com/mangalocal'); TD = os.path.join(ROOT, 'tools/kotlin_tests'); DATA = os.path.join(ROOT, 'tools/data')
TBL, SCL, MOD, LIB = (os.path.join(K, p) for p in ('model/AgeBodyTable.kt', 'pipeline/AgeBodyScaler.kt', 'model/Models.kt', 'pipeline/CharacterLibrary.kt'))
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)

# ───────────── (1) đáp án Python độc lập ─────────────
pub = {'M': {}, 'F': {}}
for l in open(os.path.join(DATA, 'schmid2019_tableA1.txt'), encoding='utf-8'):
    if l[0] in 'MF':
        p = l.split(); pub[p[0]][int(p[1])] = [float(x) for x in p[2:8]]
def parse(fn):
    o = {}
    for l in open(os.path.join(DATA, fn), encoding='utf-8'):
        if l.startswith('#') or not l.strip(): continue
        tb, sx, age, n, mean, sd = l.split(); o[(tb, sx, int(age))] = float(mean)
    return o
NH, ZV = parse('nhanes3_breadth_t53_t56.txt'), parse('zivicnjak2008_tables1_4.txt')
SERIES = [(NH, 'T53', 1.0, 'vai'), (NH, 'T56', 1.0, 'hông'), (ZV, 'T1', 0.1, 'vai'), (ZV, 'T4', 0.1, 'hông')]
def breadth(part, sx, a):   # trung bình các chuỗi của vai (hoặc hông), tuyệt đối so với người lớn TRUNG BÌNH nam–nữ của chính chuỗi
    vals = []
    for src, tb, sc, nm in SERIES:
        if nm != part: continue
        adult = (src[(tb, 'M', 18)] + src[(tb, 'F', 18)]) / 2 * sc
        vals.append(src[(tb, sx, a)] * sc / adult)
    return sum(vals) / len(vals)
H = lambda sx, a: pub[sx][a][0]
Hbar = lambda a: (H('M', a) + H('F', a)) / 2
hsz = lambda a: 1.0 if a >= 13 else 0.87 + (a - 6) / (13 - 6) * (1 - 0.87)
ADULT_FRAC = 0.245
def head_frac(a): return hsz(a) * (Hbar(18) / 7.5) / Hbar(a)            # ĐẦU theo QUY ƯỚC "N đầu": chỉ phụ thuộc tuổi (cố ý không theo giới)
def avgcol(a, c): return (pub['M'][a][c] + pub['F'][a][c]) / 2
def frac(sx, a):    # phần trăm chiều cao riêng; sx = 'M' | 'F' | None (trung bình)
    g = (lambda c: pub[sx][a][c]) if sx else (lambda c: avgcol(a, c)); hd = head_frac(a)
    return dict(head=hd, trunk=g(1) - hd, thigh=g(2), shank=g(3), ua=g(4), fa=g(5))
ref = frac(None, 18)       # MỐC: người lớn TRUNG BÌNH nam–nữ
exp_lines = []; EXP = {}
for sx in ('M', 'F'):
    for a in range(6, 19):
        sv, hv = breadth('vai', sx, a), breadth('hông', sx, a); h = H(sx, a)
        sf, hf = ADULT_FRAC * sv * Hbar(18) / h, ADULT_FRAC * hv * Hbar(18) / h
        c = frac(sx, a); R = lambda x, y: (x * h) / (y * Hbar(18))
        vals = [sv, hv, sf, hf, R(c['head'], ref['head']), R(c['trunk'], ref['trunk']), R(sf, ADULT_FRAC), R(c['thigh'], ref['thigh']), R(c['shank'], ref['shank']),
                R(c['ua'], ref['ua']), R(c['fa'], ref['fa']), R(hf, ADULT_FRAC)]
        EXP[(sx, a)] = vals; exp_lines.append(f'{sx} {a} ' + ' '.join(f'{v:.6f}' for v in vals))
exp_path = os.path.join(tempfile.gettempdir(), 'age_sex_expected.txt'); open(exp_path, 'w').write('\n'.join(exp_lines) + '\n'); os.environ['AGE_SEX_EXPECTED'] = exp_path
check(len(EXP) == 26 and all(len(v) == 12 for v in EXP.values()), 'đáp án độc lập: 26 ô (nam/nữ × 13 tuổi) × 12 đại lượng')
check(0.94 < EXP[('F', 18)][0] < 0.95 and 1.05 < EXP[('M', 18)][0] < 1.06, f'(Python độc lập) vai 18 tuổi so với trung bình: nữ {EXP[("F",18)][0]:.3f}, nam {EXP[("M",18)][0]:.3f}')
check(1.10 < EXP[('M', 18)][0] / EXP[('F', 18)][0] < 1.15 and all(0.98 < EXP[('M', a)][0] / EXP[('F', a)][0] < 1.03 for a in range(6, 13)), '(Python độc lập) vai nam/nữ: ≈1,12 lúc 18 tuổi, ≈1,0 dưới 13 tuổi — khớp ghi chép 284.2')
check(all(EXP[('M', a)][1] < EXP[('F', a)][1] for a in range(10, 15)), '(Python độc lập) hông nữ rộng hơn nam ở 10–14 tuổi')
check(all(abs(EXP[(s, a)][4] / (head_frac(a) * H(s, a) / (head_frac(18) * Hbar(18))) - 1) < 1e-9 for s in 'MF' for a in range(6, 19)), '(Python độc lập) ĐẦU theo giới chỉ do chiều cao riêng quyết định (phần-trăm-chiều-cao dùng chung theo tuổi)')

# ───────────── (2)–(4) cần kotlinc ─────────────
def find(env, names, extra=()):
    for c in [os.environ.get(env)] + [shutil.which(n) for n in names] + list(extra):
        if c and os.path.exists(c): return c
kc = find('KOTLINC', ['kotlinc'], ['/home/claude/tools/kotlinc/bin/kotlinc'])
gs = find('GSON_JAR', [], ['/home/claude/tools/gson-2.10.1.jar'])
aj = find('ANDROID_JAR', [], ['/home/claude/tools/android34.jar', os.path.join(ROOT, 'tools/.cache/android34.jar')])
if not (kc and gs and aj):
    print('BỎ QUA (2)–(4): cần kotlinc 1.9.x (KOTLINC), Gson (GSON_JAR), android.jar (ANDROID_JAR). Chỉ kiểm được (1).')
    print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)

CP = os.pathsep.join([gs, aj])
def compile_run(main_src, main_class, srcs, td, cp=CP):
    jar = os.path.join(td, 't.jar')
    r = subprocess.run([kc, '-nowarn', '-cp', cp, os.path.join(TD, 'StubStoryManager.kt'), os.path.join(TD, main_src)] + srcs + ['-include-runtime', '-d', jar], capture_output=True, text=True)
    if r.returncode != 0: return None, r.stderr[-1800:]
    o = subprocess.run(['java', '-Dstdout.encoding=UTF-8', '-cp', jar + os.pathsep + cp, main_class], capture_output=True, text=True)
    return o.stdout, o.stderr

# (2) đáp án vàng
def golden_expected():
    return [l.rstrip('\n') for l in open(os.path.join(DATA, 'age_body_unisex_golden.txt'), encoding='utf-8') if l.strip() and not l.startswith('#')]
with tempfile.TemporaryDirectory() as td:
    out, err = compile_run('AgeGoldenDump.kt', 'AgeGoldenDumpKt', [TBL, MOD], td)
    check(out is not None, 'biên dịch AgeGoldenDump với mã MỚI' + ('' if out is not None else '\n' + str(err)))
    if out is not None:
        got = [l for l in out.splitlines() if l.strip()]; exp = golden_expected()
        diff = [(i, a, b) for i, (a, b) in enumerate(zip(exp, got)) if a != b]
        check(len(got) == len(exp) == 74 and not diff, f'ĐÁP ÁN VÀNG: không chọn giới ⇒ {len(exp)} dòng hành vi (6–18 tuổi, kẹp ngoài khoảng, factors, forAge, số đầu, tag) GIỐNG HỆT TỪNG BIT mã trước mục 285 ({len(diff)} dòng lệch)')
        for i, a, b in diff[:3]: print('   lệch dòng', i, '\n   cũ:', a, '\n   mới:', b)

# (3) test Kotlin thật
SRCS = [TBL, SCL, MOD, LIB]
def run_sex(tbl=TBL, scl=SCL, mod=MOD, lib=LIB):
    with tempfile.TemporaryDirectory() as td:
        return compile_run('AgeSexTest.kt', 'AgeSexTestKt', [tbl, scl, mod, lib], td)
out, err = run_sex()
check(out is not None, 'biên dịch AgeBodyTable + AgeBodyScaler + Models + CharacterLibrary + AgeSexTest bằng kotlinc' + ('' if out is not None else '\n' + str(err)))
if out is not None:
    n_pass = sum(1 for l in out.splitlines() if l.startswith('PASS')); bad = [l for l in out.splitlines() if l.startswith('FAIL')]
    for l in bad: print(l)
    check(not bad and n_pass >= 40, f'mã Kotlin thật: {n_pass} phép kiểm đạt, {len(bad)} lỗi' + ('' if out.strip().endswith(')') or 'ĐẠT' in out else ' — ' + (err or '')[-300:]))

# (3b) nối dây: StoryManager PHẢI dùng Gson có InstanceCreator (ModelJson, mục 286; mục 285 chỉ đăng ký riêng Character) — nếu không, JSON cũ nạp ra null/0
SM = open(os.path.join(K, 'pipeline/StoryManager.kt'), encoding='utf-8').read(); MJ = open(os.path.join(K, 'model/ModelJson.kt'), encoding='utf-8').read()
check('private val gson: Gson = ModelJson.gson()' in SM and '.blank { Character.blankForGson() }' in MJ, 'nối dây: StoryManager.gson = ModelJson.gson(), trong đó Character đăng ký InstanceCreator { Character.blankForGson() }')

# (4) đột biến
MUTS = [
 ('giới: MALE đọc cột nữ', TBL, 'BodySex.MALE -> MALE[i][col]', 'BodySex.MALE -> FEMALE[i][col]'),
 ('giới: UNSPECIFIED không phải trung bình', TBL, 'BodySex.UNSPECIFIED -> avg(i, col)', 'BodySex.UNSPECIFIED -> MALE[i][col]'),
 ('bề ngang: MALE bị trung bình hoá', TBL, 'BodySex.MALE -> a[2 * k];', 'BodySex.MALE -> (a[2 * k] + a[2 * k + 1]) / 2f;'),
 ('bề ngang: nữ đọc cột nam', TBL, 'BodySex.FEMALE -> a[2 * k + 1];', 'BodySex.FEMALE -> a[2 * k];'),
 ('hông lấy chuỗi của vai', TBL, 'else (s[1] + s[3]) / 2f }', 'else (s[0] + s[2]) / 2f }'),
 ('vai lấy chuỗi của hông', TBL, 'else (s[0] + s[2]) / 2f }', 'else (s[1] + s[3]) / 2f }'),
 ('đầu theo chiều cao riêng của giới', TBL, 'val head = headSizeVsAdult(age) * (heightCm(ADULT_AGE) / 7.5f) / heightCm(age)', 'val head = headSizeVsAdult(age) * (heightCm(ADULT_AGE) / 7.5f) / heightCm(age, sex)'),
 ('heightFractions: hông = vai', TBL, 'hip = hipFraction(age, sex)', 'hip = shoulderFraction(age, sex)'),
 ('ratios: mốc người lớn theo giới', TBL, 'val c = heightFractions(age, sex); val a = heightFractions(ADULT_AGE)', 'val c = heightFractions(age, sex); val a = heightFractions(ADULT_AGE, sex)'),
 ('ratios: chiều cao mốc theo giới', TBL, 'val hc = heightCm(age, sex); val ha = heightCm(ADULT_AGE)', 'val hc = heightCm(age, sex); val ha = heightCm(ADULT_AGE, sex)'),
 ('factors: bỏ hệ số hông', TBL, 'b.forearm / a.forearm, b.hip / a.hip)', 'b.forearm / a.forearm)'),
 ('forAge: không điền hông riêng', MOD, 'hipWidthRatio = if (sex == BodySex.UNSPECIFIED) 0f else r.hip', 'hipWidthRatio = 0f'),
 ('forAge: bỏ qua giới', MOD, 'val r = AgeBodyTable.ratiosVsAdult(ageYears, sex)', 'val r = AgeBodyTable.ratiosVsAdult(ageYears)'),
 ('hipRatio không loại ∞', MOD, 'if (hipWidthRatio > 0f && hipWidthRatio.isFinite()) hipWidthRatio else widthRatio', 'if (hipWidthRatio > 0f) hipWidthRatio else widthRatio'),
 ('matchingAge bỏ qua giới', MOD, 'firstOrNull { this == forAge(it, sex) }', 'firstOrNull { this == forAge(it) }'),
 ('sexOrDefault không chống null', MOD, 'fun sexOrDefault(): BodySex = BodySex.safe(bodySex)', 'fun sexOrDefault(): BodySex = bodySex'),
 ('BodySex.parse không chống tên lạ', TBL, 'runCatching { valueOf(raw ?: "") }.getOrDefault(UNSPECIFIED)', 'valueOf(raw ?: "")'),
 ('AgeBodyScaler: hông dùng hệ số vai', SCL, 'val fHip = f.hip * norm', 'val fHip = f.shoulder * norm'),
 ('blankForGson: loraWeight 0 thay vì mặc định', MOD, 'fun blankForGson() = Character(id = "", name = "", anchorPrompt = "", seed = 0L)', 'fun blankForGson() = Character(id = "", name = "", anchorPrompt = "", seed = 0L, loraWeight = 0f)'),
 ('thư viện: không LƯU giới', LIB, 'bodySex = c.sexOrDefault().name,', ''),
 ('thư viện: không NẠP giới', LIB, 'bodySex = BodySex.parse(s.bodySex)', 'bodySex = BodySex.UNSPECIFIED'),
]
if '--mut' in sys.argv:
    lo, hi = (int(x) for x in os.environ.get('MUT_RANGE', '0:999').split(':')); sel = MUTS[lo:hi]; caught = 0
    for name, path, old, new in sel:
        text = open(path, encoding='utf-8').read(); assert text.count(old) == 1, f'mẫu đột biến không duy nhất/không có: {name} ({text.count(old)})'
        with tempfile.TemporaryDirectory() as td:
            mp = os.path.join(td, os.path.basename(path)); open(mp, 'w', encoding='utf-8').write(text.replace(old, new, 1))
            o, e = run_sex(tbl=mp if path == TBL else TBL, scl=mp if path == SCL else SCL, mod=mp if path == MOD else MOD, lib=mp if path == LIB else LIB)
            bad = o is None or any(l.startswith('FAIL') for l in o.splitlines()) or (o is not None and 'ĐẠT' not in o)
        caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name, flush=True)
    check(caught == len(sel), f'phá mã: {caught}/{len(sel)} đột biến bị bắt')
else:
    print(f'(bỏ qua đột biến — chạy với --mut; có {len(MUTS)} đột biến, MUT_RANGE=lo:hi để chạy từng khúc)')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
