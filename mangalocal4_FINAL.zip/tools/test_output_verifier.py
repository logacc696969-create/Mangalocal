#!/usr/bin/env python3
"""mục 248 — kiểm thử OutputVerifier (kiểm tra ảnh SAU sinh bằng dò lại tư thế).

Cách làm (nói thật giới hạn): sandbox KHÔNG có kotlinc, nên thuật toán được chép lại bằng Python; để bản chép không
"trôi" khỏi mã thật, ngưỡng được ĐỌC TRỰC TIẾP từ OutputVerifier.kt và test đối chiếu chuỗi nguồn (nối dây ở
MangaPipeline/Models/SettingsScreen). Test này chứng minh LOGIC đúng với dữ liệu tổng hợp; KHÔNG chứng minh YOLO dò đúng
trên ảnh thật, cũng không thay build CI.
"""
import math, os, re, sys

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(BASE, *p), encoding='utf8').read()
KT = rd('pipeline', 'OutputVerifier.kt')

def const(name):
    m = re.search(r'const val %s\s*=\s*([0-9.]+)f?' % name, KT)
    assert m, name
    return float(m.group(1)) if '.' in m.group(1) else int(m.group(1))

MIN_SHARED = const('MIN_SHARED_JOINTS'); MAX_MED = const('MAX_MEDIAN_ERROR'); MAX_SPREAD = const('MAX_SCALE_SPREAD')
S_MIN = const('SINGLE_SCALE_MIN'); S_MAX = const('SINGLE_SCALE_MAX'); MIN_SPAN = const('MIN_SPAN')
EXTRA = const('EXTRA_PERSONS_ALLOWED'); MIN_TORSO = const('MIN_TORSO')
JOINTS = 18

# ---------------- bản chép thuật toán ----------------
def targets_from_skeleton(data):
    per = JOINTS * 4
    if not data or len(data) % per: return []
    out = []
    for p in range(len(data) // per):
        b = p * per
        out.append([(data[b + j * 4], data[b + j * 4 + 1], data[b + j * 4 + 3] > 0.5) for j in range(JOINTS)])
    return out

def centroid(p):
    v = [(x, y) for x, y, vis in p if vis]
    return None if not v else (sum(a for a, _ in v) / len(v), sum(b for _, b in v) / len(v))

def torso(p):
    n, rh, lh = p[1], p[8], p[11]
    if n[2] and rh[2] and lh[2]:
        return math.hypot(n[0] - (rh[0] + lh[0]) / 2, n[1] - (rh[1] + lh[1]) / 2)
    ys = [y for _, y, vis in p if vis]
    return 0.0 if len(ys) < 2 else 0.35 * (max(ys) - min(ys))

def median(v):
    s = sorted(v); n = len(s)
    return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2

def greedy(targets, detected):
    c = []
    for ti, t in enumerate(targets):
        tc = centroid(t)
        if tc is None: continue
        for di, d in enumerate(detected):
            dc = centroid(d)
            if dc is None: continue
            c.append((math.hypot(tc[0] - dc[0], tc[1] - dc[1]), ti, di))
    c.sort(key=lambda z: z[0])
    ut, ud, out = set(), set(), []
    for _, ti, di in c:
        if ti in ut or di in ud: continue
        ut.add(ti); ud.add(di); out.append((ti, di))
    return out

def verify(targets, detected):
    reasons, exp = [], len(targets)
    if exp == 0: return True, [], [], 0, len(detected)
    if len(detected) < exp: reasons.append('thiếu')
    elif len(detected) > exp + EXTRA: reasons.append('thừa')
    matches = []
    for ti, di in greedy(targets, detected):
        t, d = targets[ti], detected[di]
        tor = torso(t); errs = []; tlo = dlo = 1e9; thi = dhi = -1e9
        for j in range(JOINTS):
            if not (t[j][2] and d[j][2]): continue
            if tor >= MIN_TORSO: errs.append(math.hypot(t[j][0] - d[j][0], t[j][1] - d[j][1]) / tor)
            tlo, thi = min(tlo, t[j][1]), max(thi, t[j][1]); dlo, dhi = min(dlo, d[j][1]), max(dhi, d[j][1])
        shared = len(errs) if tor >= MIN_TORSO else 0
        med = median(errs) if len(errs) >= MIN_SHARED else -1.0
        span = thi - tlo
        ratio = (dhi - dlo) / span if span >= MIN_SPAN and dhi >= dlo else -1.0
        matches.append((ti, di, med, ratio, shared))
        if med > MAX_MED: reasons.append('lệch tư thế #%d' % (ti + 1))
    rs = [m[3] for m in matches if m[3] > 0]
    if len(rs) >= 2:
        if max(rs) / min(rs) - 1 > MAX_SPREAD: reasons.append('tỉ lệ giữa người')
    elif len(rs) == 1:
        if rs[0] < S_MIN or rs[0] > S_MAX: reasons.append('kích thước 1 người')
    return not reasons, reasons, matches, exp, len(detected)

# ---------------- dữ liệu tổng hợp ----------------
STAND = [(0.50, 0.12), (0.50, 0.20), (0.42, 0.20), (0.38, 0.32), (0.36, 0.44), (0.58, 0.20), (0.62, 0.32), (0.64, 0.44),
         (0.45, 0.50), (0.45, 0.68), (0.45, 0.88), (0.55, 0.50), (0.55, 0.68), (0.55, 0.88),
         (0.48, 0.10), (0.52, 0.10), (0.46, 0.11), (0.54, 0.11)]

def person(cx=0.5, cy=0.5, scale=1.0, dx=0.0, dy=0.0, hide=()):
    out = []
    for j, (x, y) in enumerate(STAND):
        out.append((cx + (x - 0.5) * scale + dx, cy + (y - 0.5) * scale + dy, j not in hide))
    return out

def flat(people):
    f = []
    for p in people:
        for x, y, v in p: f += [x, y, 0.0, 1.0 if v else 0.0]
    return f

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

A = person(0.30, 0.5, 0.8); B = person(0.72, 0.5, 0.8)
T = targets_from_skeleton(flat([A, B]))
check('đọc khung xương 2 người đúng bố cục 18×4', len(T) == 2 and T[0][4][2] is True and abs(T[1][0][0] - B[0][0]) < 1e-6)
check('mảng không chia hết 72 hoặc rỗng -> không có người', targets_from_skeleton([0.0] * 71) == [] and targets_from_skeleton([]) == [])
check('không có khung xương -> đạt, không phạt', verify([], [A])[0])

r = verify(T, [A, B]); check('khớp hoàn hảo -> đạt, 0 lý do', r[0] and not r[1])
r = verify(T, [B, A]); check('thứ tự dò khác -> vẫn ghép đúng theo vị trí, đạt', r[0] and {(m[0], m[1]) for m in r[2]} == {(0, 1), (1, 0)})
r = verify(T, [A]); check('thiếu 1 người -> báo thiếu', not r[0] and 'thiếu' in r[1])
r = verify(T, []); check('dò được 0 người -> báo thiếu', not r[0] and r[4] == 0)
T1 = targets_from_skeleton(flat([A]))
check('thừa 1 người (≤ kỳ vọng+EXTRA) -> chấp nhận người nền', verify(T1, [A, B])[0] and EXTRA == 1)
check('thừa 2 người -> báo thừa', 'thừa' in verify(T1, [A, B, person(0.5, 0.5, 0.4)])[1])

torso_len = torso(A)
shift_small = person(0.30, 0.5, 0.8, dx=0.08 * torso_len)
shift_big = person(0.30, 0.5, 0.8, dx=0.9 * torso_len)
check('lệch nhỏ (0.08 thân) -> đạt', verify(T, [shift_small, B])[0])
check('lệch lớn (0.9 thân) -> báo lệch tư thế người #1', any('lệch tư thế #1' in x for x in verify(T, [shift_big, B])[1]))
check('lệch 0.30 thân < ngưỡng %.2f -> đạt' % MAX_MED, verify(T, [person(0.30, 0.5, 0.8, dx=0.30 * torso_len), B])[0])

big_b = person(0.72, 0.5, 0.8 * 1.6)
check('một người to hơn 1.6× người kia -> báo tỉ lệ giữa người', 'tỉ lệ giữa người' in verify(T, [A, big_b])[1])
both = [person(0.30, 0.5, 0.8 * 1.3), person(0.72, 0.5, 0.8 * 1.3)]
check('cả hai to đều 1.3× -> tỉ lệ giữa người giữ nguyên, không báo tỉ lệ', 'tỉ lệ giữa người' not in verify(T, both)[1])
check('1 người co còn 0.4× -> báo kích thước', 'kích thước 1 người' in verify(T1, [person(0.30, 0.5, 0.8 * 0.4)])[1])
check('1 người to 1.0× -> đạt', verify(T1, [A])[0])

hid = person(0.30, 0.5, 0.8, hide=tuple(range(0, 14)))
Th = targets_from_skeleton(flat([A]))
check('ảnh ra chỉ thấy %d khớp (< %d chung) -> KHÔNG kết luận lệch tư thế' % (4, MIN_SHARED), 'lệch tư thế #1' not in verify(Th, [person(0.30, 0.5, 0.8, dx=0.9, hide=tuple(range(0, 14)))])[1])
check('khung xương thiếu cổ/hông dùng thân dự phòng 0.35×chiều cao, không chia 0',
      torso(person(hide=(1, 8, 11))) > 0 and torso(person(hide=tuple(range(18)))) == 0.0)

# ---------------- đối chiếu NGUỒN Kotlin / nối dây ----------------
MP, MD, ST = rd('pipeline', 'MangaPipeline.kt'), rd('model', 'Models.kt'), rd('ui', 'SettingsScreen.kt')
check('Kotlin: bố cục 18 khớp × 4 float, cờ visible ở chỉ số +3', 'const val JOINTS = 18' in KT and 'const val FLOATS_PER_JOINT = 4' in KT and 'data[o + 3] > 0.5f' in KT)
check('Kotlin: chống chia cho 0 / người rỗng (MIN_TORSO, trả đạt khi không có đích)', 'torso >= Thresholds.MIN_TORSO' in KT and 'if (expected == 0) return Result(true' in KT)
DECISION_TOKENS = ['if (detected.size < expected) {', 'if (med > Thresholds.MAX_MEDIAN_ERROR) {', 'errs.size >= Thresholds.MIN_SHARED_JOINTS',
                   'r < Thresholds.SINGLE_SCALE_MIN || r > Thresholds.SINGLE_SCALE_MAX', 'tSpan >= Thresholds.MIN_SPAN',
                   'ratios.size >= 2', 'ratios.size == 1']
missing = [t for t in DECISION_TOKENS if t not in KT]
check('Kotlin: các điều kiện quyết định khớp bản chép (thiếu người, lệch tư thế, đủ khớp, tỉ lệ 1 người, span tối thiểu)', not missing)
if missing: print('   thiếu:', missing)
check('Kotlin: thừa người = detected > expected + EXTRA_PERSONS_ALLOWED', 'detected.size > expected + Thresholds.EXTRA_PERSONS_ALLOWED' in KT)
check('Kotlin: spread = max/min - 1 so MAX_SCALE_SPREAD', 'ratios.maxOrNull()!! / ratios.minOrNull()!! - 1f' in KT and 'spread > Thresholds.MAX_SCALE_SPREAD' in KT)
check('nối dây: verifyOutputPose gọi ở CẢ generatePanels và regeneratePanel', MP.count('verifyOutputPose(') == 3 and 'val outVerify = verifyOutputPose(rawPath' in MP and 'val outVerifyRegen = verifyOutputPose(rawPathFinished' in MP)
check('nối dây: kết quả gộp vào qualityGatePassed/Reasons (không ghi đè lý do cũ)', 'panelQualityGatePassed && (outVerify?.passed ?: true)' in MP and 'panelQualityGateReasons + (outVerify?.reasons' in MP and 'finalReasons + (outVerifyRegen?.reasons' in MP)
check('nối dây: tắt mặc định, thoát sớm khi cờ tắt hoặc YOLO chưa sẵn sàng', 'verifyOutputPose: Boolean = false' in MD and 'if (!settings.verifyOutputPose) return null' in MP and 'poseExtractor.isReady()' in MP)
check('nối dây: công tắc trong Cài đặt', 'settings.verifyOutputPose' in ST and 'copy(verifyOutputPose = it)' in ST)
check('nối dây: bitmap được recycle (finally), lỗi không làm hỏng sinh ảnh (try/catch trả null)', 'finally { bmp.recycle() }' in MP and 'Kiểm tra sau sinh lỗi (bỏ qua)' in MP)

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
