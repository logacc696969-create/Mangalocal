#!/usr/bin/env python3
# mục 270 — (1) BIÊN DỊCH THỬ cú pháp/kiểu của PipelineSd15Cpu.hpp ở CẢ HAI trạng thái cờ MANGALOCAL_LORA_MODULE trên KHUNG GIẢ (tools/mnn_mock/skeleton:
# Pipeline/MnnUtils/Interpreter giả vì sandbox không có xtensor/MNN); (2) kiểm tĩnh nối dây: cờ mặc định TẮT, chỉ pipeline SD1.5 thường bật module,
# đường cũ giữ nguyên khi không có .lora.mnn, không rơi về Interpreter với file .lora.mnn; (3) phép thử phá mã. Chỉ cần g++ + Python.
import os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JNI = os.path.join(ROOT, 'app/src/main/jni')
MOCK = os.path.join(ROOT, 'tools/mnn_mock')
fails = []
def check(c, name):
    print(('PASS ' if c else 'FAIL ') + name)
    if not c: fails.append(name)
def rd(p): return open(os.path.join(ROOT, p), encoding='utf-8').read()

PIPE = rd('app/src/main/jni/sd_engine/PipelineSd15Cpu.hpp')
CMAKE = rd('app/src/main/jni/CMakeLists.txt')
GRADLE = rd('app/build.gradle')
WF = rd('.github/workflows/build.yml')
MNNP = rd('app/src/main/jni/mnn_diffusion_pipeline.cpp')

def build_skeleton(tmp, pipe_text, flag):
    d = os.path.join(tmp, 'sk'); shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(os.path.join(JNI, 'sd_engine'), os.path.join(d, 'sd_engine'))
    open(os.path.join(d, 'sd_engine/PipelineSd15Cpu.hpp'), 'w', encoding='utf-8').write(pipe_text)
    shutil.copy(os.path.join(MOCK, 'skeleton/Pipeline.hpp'), os.path.join(d, 'sd_engine/Pipeline.hpp'))
    shutil.copy(os.path.join(MOCK, 'skeleton/MnnUtils.hpp'), os.path.join(d, 'sd_engine/MnnUtils.hpp'))
    os.makedirs(os.path.join(d, 'MNN/expr'), exist_ok=True)
    shutil.copy(os.path.join(MOCK, 'skeleton/Interpreter_full.hpp'), os.path.join(d, 'MNN/Interpreter.hpp'))
    for h in os.listdir(os.path.join(MOCK, 'MNN/expr')):
        shutil.copy(os.path.join(MOCK, 'MNN/expr', h), os.path.join(d, 'MNN/expr', h))
    shutil.copy(os.path.join(MOCK, 'skeleton/syn.cpp'), os.path.join(d, 'syn.cpp'))
    args = ['g++', '-std=c++17', '-fsyntax-only', '-I', d, os.path.join(d, 'syn.cpp')]
    if flag: args.insert(2, '-DMANGALOCAL_LORA_MODULE=1')
    return subprocess.run(args, capture_output=True, text=True)

def static_checks(pipe, cmake, gradle, wf, mnnp):
    out = []
    out.append(('cờ module mặc định OFF trong CMake', 'option(MANGALOCAL_ENABLE_LORA_MODULE' in cmake and re.search(r'option\(MANGALOCAL_ENABLE_LORA_MODULE "[^"]*" OFF\)', cmake) is not None))
    out.append(('CMake chỉ định nghĩa MANGALOCAL_LORA_MODULE khi cờ bật (toàn thư mục)', re.search(r'if\(MANGALOCAL_ENABLE_LORA_MODULE\)\s*add_compile_definitions\(MANGALOCAL_LORA_MODULE=1\)\s*endif\(\)', cmake) is not None))
    out.append(('Gradle chỉ bật khi -Pmangalocal.enableLoraModule=true', 'mangalocal.enableLoraModule' in gradle and '-DMANGALOCAL_ENABLE_LORA_MODULE=ON' in gradle))
    out.append(('workflow có input enable_lora_module mặc định false và truyền cờ', re.search(r'enable_lora_module:\s*\n\s*description:.*\n\s*default: false', wf) is not None and 'LORA_MODULE_GRADLE_ARGS' in wf and wf.count('$LORA_MODULE_GRADLE_ARGS \\\n') == 1))
    out.append(('mnn_diffusion_pipeline bật enableUnetModules(true) đúng 1 lần, trên sd15 thường', mnnp.count('enableUnetModules(true)') == 1 and re.search(r'sd15->enableUnetModules\(true\);[^\n]*\n\s*if \(!sd15->initialize\(\)\)', mnnp) is not None))
    out.append(('beginDenoise chặn đường Module trước khi tạo Interpreter chính', re.search(r'void beginDenoise\(const GenerationRequest &req\) override \{[^}]*modules_active_ = false;.*?if \(beginDenoiseWithModules\(req, st0\)\) return;.*?unet_interpreter_ = createMnnInterpreterMmap', pipe, re.S) is not None))
    out.append(('đường cũ setupComposeExtras chỉ chạy khi KHÔNG có .lora.mnn (không nạp file module như UNet đầy đủ)', 'if (lora_compose::snapshot(st) && lora_compose::moduleMode(st.extra_unets) == lora_compose::ModuleMode::None) setupComposeExtras(req, st);' in pipe and pipe.count('setupComposeExtras(req, st)') == 1))
    out.append(('runUnetStep rẽ sang đường Module khi modules_active_', re.search(r'if \(modules_active_\) \{[^}]*runUnetStepModules\(req, latents_batch2, timestep, cond, out_batch2\);\s*return;', pipe, re.S) is not None))
    out.append(('endDenoise hạ cờ + huỷ module ở CUỐI hàm (phần đầu giữ nguyên như mục 261)', re.search(r'void endDenoise\(\) override \{\s*compose_extra_conds_\.clear\(\);.*?unet_interpreter_ = nullptr;\s*//[^\n]*\n\s*modules_active_ = false;\s*#ifdef MANGALOCAL_LORA_MODULE\s*unet_modules_\.reset\(\);', pipe, re.S) is not None))
    out.append(('onConditioningReady không mã hoá CLIP riêng khi module không nạp được', 'moduleMode(st.extra_unets) != lora_compose::ModuleMode::None && !modules_active_) return;' in pipe))
    out.append(('mặc định unet_modules_allowed_ = false', 'bool unet_modules_allowed_ = false;' in pipe))
    out.append(('chỉ chạy CPU: từ chối khi require_npu', 'if (req.require_npu)' in pipe and 'đường module chỉ chạy CPU' in pipe))
    out.append(('từ chối lẫn UNet đầy đủ + module (Mixed)', 'ModuleMode::All) {' in pipe or 'moduleMode(st.extra_unets) != lora_compose::ModuleMode::All' in pipe))
    return out

with tempfile.TemporaryDirectory(prefix='pm_') as tmp:
    for flag in (False, True):
        r = build_skeleton(tmp, PIPE, flag)
        check(r.returncode == 0, f'biên dịch thử PipelineSd15Cpu.hpp trên khung giả, cờ {"BẬT" if flag else "TẮT"}')
        if r.returncode != 0: print(r.stderr[-2500:])
    for name, ok in static_checks(PIPE, CMAKE, GRADLE, WF, MNNP): check(ok, name)
    # lớp con KHÔNG được bật module
    others = []
    for f in os.listdir(JNI):
        if f.endswith('.cpp') and f != 'mnn_diffusion_pipeline.cpp':
            if 'enableUnetModules' in open(os.path.join(JNI, f), encoding='utf-8').read(): others.append(f)
    check(not others, 'không file nào khác bật enableUnetModules (lớp con có input phụ): ' + ','.join(others))
    # phép thử phá mã
    muts = [
      ('bỏ nhánh modules_active_ ở runUnetStep', 'PIPE', 'if (modules_active_) {  // mục 270', 'if (false) {  // mục 270'),
      ('đường cũ nạp cả file .lora.mnn', 'PIPE', ' && lora_compose::moduleMode(st.extra_unets) == lora_compose::ModuleMode::None) setupComposeExtras', ') setupComposeExtras'),
      ('endDenoise không huỷ module', 'PIPE', 'unet_modules_.reset();\n#endif\n  }\n\n  void releaseTransientModels', '#endif\n  }\n\n  void releaseTransientModels'),
      ('mặc định cho phép module', 'PIPE', 'bool unet_modules_allowed_ = false;', 'bool unet_modules_allowed_ = true;'),
      ('không kiểm kích thước điều kiện văn bản (lỗi biên dịch cố ý: tên sai)', 'PIPE_COMPILE', 'unet_modules_->step(p, latents_batch2, enc, out_batch2, &err)', 'unet_modules_->stepp(p, latents_batch2, enc, out_batch2, &err)'),
      ('CMake bật mặc định', 'CMAKE', 'a OFF)\nif(MANGALOCAL_ENABLE_LORA_MODULE)', None),
    ]
    caught = 0; n = 0
    for name, tgt, old, new in muts:
        if tgt == 'CMAKE':
            n += 1
            mc = re.sub(r'(option\(MANGALOCAL_ENABLE_LORA_MODULE "[^"]*") OFF\)', r'\1 ON)', CMAKE)
            ok = [x for x in static_checks(PIPE, mc, GRADLE, WF, MNNP) if not x[1]]
            bad = bool(ok); caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name); continue
        assert old in PIPE, (name, old)
        mp = PIPE.replace(old, new, 1); n += 1
        if tgt == 'PIPE_COMPILE':
            r = build_skeleton(tmp, mp, True); bad = r.returncode != 0
        else:
            bad = any(not x[1] for x in static_checks(mp, CMAKE, GRADLE, WF, MNNP))
        caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name)
    check(caught == n, f'đột biến: {caught}/{n} bị bắt')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails))
sys.exit(1 if fails else 0)
