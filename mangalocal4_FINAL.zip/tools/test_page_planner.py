#!/usr/bin/env python3
"""mục 248 — kiểm thử PageLayoutPlanner (PageTemplate.AUTO).

Giới hạn (nói thật): thuật toán chép lại bằng Python vì sandbox không có kotlinc; hằng số đọc từ nguồn Kotlin, và test
đối chiếu chuỗi nguồn + kiểm `when` trên enum có ĐỦ nhánh (lỗi biên dịch phổ biến khi thêm giá trị enum).
Chứng minh LOGIC lập trang; không chứng minh PDF đẹp, và không thay build CI.
"""
import os, random, re, sys

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(BASE, *p), encoding='utf8').read()
KT, PE = rd('pipeline', 'PageLayoutPlanner.kt'), rd('pipeline', 'PublishExporter.kt')
MIN_SPLASH = int(re.search(r'const val MIN_PANELS_FOR_SPLASH = (\d+)', KT).group(1))
CAP = {'SPLASH': 1, 'STACK_2': 2, 'ONE_PLUS_TWO': 3, 'GRID_2X2': 4, 'FOUR_KOMA': 4, 'AUTO': 2}

QUIET, NORMAL, HIGH = 'QUIET', 'NORMAL', 'HIGH'

def beat_of(cat, cam, n_dialogue):
    action = cat in ('combat', 'embrace', 'kiss')
    high = action or cam in ('extreme-close-up', 'wide-shot')
    quiet = (not high) and (cat is None or cat == 'neutral') and n_dialogue > 0 and cam in ('medium-shot', 'close-up')
    return (HIGH if high else QUIET if quiet else NORMAL), action

def plan(beats):
    n = len(beats); out = []
    climax = max((i for i, b in enumerate(beats) if b[1]), default=-1) if n >= MIN_SPLASH else -1
    i = 0
    while i < n:
        rem = n - i; w = beats[i][0]
        if i == climax and out: tpl, take = 'SPLASH', 1
        elif rem == 1: tpl, take = 'STACK_2', 1
        elif w == HIGH and rem >= 3: tpl, take = 'ONE_PLUS_TWO', 3
        elif w == QUIET and rem >= 4 and all(beats[i + k][0] != HIGH for k in (1, 2, 3)): tpl, take = 'GRID_2X2', 4
        else: tpl, take = 'STACK_2', 2
        if climax > i and climax < i + take: take = climax - i; tpl = 'STACK_2'
        out.append((tpl, i, take)); i += take
    return out

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

Q, N, H, A = (QUIET, False), (NORMAL, False), (HIGH, False), (HIGH, True)

check('rỗng -> không có trang', plan([]) == [])
check('1 panel -> 1 trang (ô trọn)', plan([N]) == [('STACK_2', 0, 1)])
check('8 panel yên tĩnh -> 2 trang lưới 2×2', [p[0] for p in plan([Q] * 8)] == ['GRID_2X2', 'GRID_2X2'])
check('5 panel thường -> 2+2+1', [(p[0], p[2]) for p in plan([N] * 5)] == [('STACK_2', 2), ('STACK_2', 2), ('STACK_2', 1)])
check('mở đầu bằng panel HIGH (còn ≥3) -> "1 rộng + 2 dưới"', plan([H, N, N, N])[0][:1] == ('ONE_PLUS_TWO',))
check('HIGH nhưng chỉ còn 2 panel -> 2 dọc, không ép', plan([N, H, N]) [0][0] == 'STACK_2')
check('lưới 2×2 bị chặn nếu 3 panel kế có HIGH -> không dùng lưới', plan([Q, N, H, N, N])[0][0] != 'GRID_2X2')
seq = [N, N, N, N, N, A, N]   # panel hành động cuối ở chỉ số 5, n=7 ≥ 6
p = plan(seq)
check('đỉnh điểm -> đúng 1 trang SPLASH, mở đầu một trang mới', sum(t == 'SPLASH' for t, _, _ in p) == 1 and any(t == 'SPLASH' and s == 5 for t, s, _ in p))
check('truyện ngắn (< %d panel) -> không có splash dù có hành động' % MIN_SPLASH, all(t != 'SPLASH' for t, _, _ in plan([N, A, N, N])))
check('đỉnh điểm ở panel đầu tiên -> không splash trang đầu', all(t != 'SPLASH' for t, _, _ in plan([A, N, N, N, N, N, N])))

# ---------- fuzz bất biến ----------
rng = random.Random(248)
bad = []
for trial in range(4000):
    n = rng.randint(0, 40)
    beats = [rng.choice([Q, N, H, A]) for _ in range(n)]
    p = plan(beats)
    cover = [k for _, s, c in p for k in range(s, s + c)]
    if cover != list(range(n)): bad.append(('phủ', trial)); continue
    if any(not (1 <= c <= CAP[t]) for t, s, c in p): bad.append(('sức chứa', trial))
    splash = [(t, s) for t, s, c in p if t == 'SPLASH']
    if len(splash) > 1: bad.append(('nhiều splash', trial))
    if splash and not (n >= MIN_SPLASH and beats[splash[0][1]][1] and splash[0][1] > 0): bad.append(('splash sai chỗ', trial))
    if splash and p[0][0] == 'SPLASH': bad.append(('splash trang đầu', trial))
    if plan(beats) != p: bad.append(('không xác định', trial))
    if len(p) < (n + 3) // 4: bad.append(('quá ít trang', trial))
    # climax luôn mở đầu trang nếu tồn tại
    if n >= MIN_SPLASH:
        cl = max((i for i, b in enumerate(beats) if b[1]), default=-1)
        if cl > 0 and not any(s == cl for _, s, _ in p): bad.append(('đỉnh điểm bị gói', trial))
check('fuzz 4000 chuỗi nhịp: phủ đúng 1 lần theo thứ tự, trong sức chứa, ≤1 splash đúng chỗ, xác định, đỉnh điểm mở trang', not bad)
if bad: print('   ví dụ lỗi:', bad[:5])

# ---------- beatOf ----------
check('beatOf: combat/embrace/kiss -> HIGH + action', all(beat_of(c, 'medium-shot', 1) == (HIGH, True) for c in ('combat', 'embrace', 'kiss')))
check('beatOf: cận cực độ / toàn cảnh -> HIGH nhưng KHÔNG phải ứng viên đỉnh điểm', beat_of(None, 'extreme-close-up', 0) == (HIGH, False) and beat_of('neutral', 'wide-shot', 2) == (HIGH, False))
check('beatOf: thoại + trung cảnh + không hành động -> QUIET', beat_of(None, 'medium-shot', 2) == (QUIET, False) and beat_of('neutral', 'close-up', 1) == (QUIET, False))
check('beatOf: không thoại -> NORMAL; góc overhead/low-angle -> NORMAL; run -> NORMAL',
      beat_of(None, 'medium-shot', 0)[0] == NORMAL and beat_of(None, 'overhead', 3)[0] == NORMAL and beat_of('run', 'medium-shot', 1)[0] == NORMAL)

# ---------- đối chiếu nguồn Kotlin ----------
enum = re.search(r'enum class PageTemplate\(.*?\) \{(.*?)\n\}', PE, re.S).group(1)
names = re.findall(r'^\s*([A-Z_0-9]+)\(', enum, re.M)
body = re.search(r'private fun cellsLeftToRight.*?\n    \}\n', PE, re.S).group(0)
branches = set(re.findall(r'PageTemplate\.([A-Z_0-9]+)\s*->', body))
check('Kotlin: `when` trong cellsLeftToRight có ĐỦ nhánh cho mọi giá trị enum %s (tránh lỗi biên dịch)' % sorted(names), set(names) == branches)
check('Kotlin: enum có AUTO', 'AUTO' in names)
check('Kotlin: exportPdf dùng bộ lập khi AUTO, giữ chunked cho mẫu khác', 'if (template == PageTemplate.AUTO) PageLayoutPlanner.planPanels(ok)' in PE and 'ok.chunked(template.panelsPerPage).map { template to it }' in PE)
check('Kotlin: mỗi trang dùng mẫu của CHÍNH trang đó (không dùng `template` chung) và tổng số trang = plan.size',
      'PageLayout.cells(pageTemplate, chunk.size, content, gutter, rtl)' in PE and 'PageLayout.contentRect(profile, idx + 1, plan.size, rtl)' in PE and 'pages.size' not in PE)
check('Kotlin: thuật toán khớp bản chép (các nhánh quyết định)',
      'i == climax && out.isNotEmpty()' in KT and 'b.weight == Weight.HIGH && remaining >= 3' in KT and 'b.weight == Weight.QUIET && remaining >= 4' in KT
      and '(1..3).all { beats[i + it].weight != Weight.HIGH }' in KT and 'if (climax > i && climax < i + take)' in KT and 'beats.indexOfLast { it.action }' in KT)
check('Kotlin: beatOf khớp bản chép', 'cat == "combat" || cat == "embrace" || cat == "kiss"' in KT and 'cam == "extreme-close-up" || cam == "wide-shot"' in KT
      and '(cam == "medium-shot" || cam == "close-up")' in KT and 'scene.dialogue.isNotEmpty()' in KT)
check('Kotlin: lựa chọn AUTO hiện ở Cài đặt (chip lặp qua values())', 'PageTemplate.values()' in rd('ui', 'SettingsScreen.kt'))

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
