#!/usr/bin/env python3
"""mục 288 — kiểm MobileSAM click-to-mask (mobile_sam_post.hpp / mobile_sam_core.hpp / mobile_sam_wrapper.cpp).

BỐI CẢNH: lần đầu chạy THẬT (export_mobilesam.py -> mnnconvert -> MNN 3.6.1 + ảnh thật) lộ 4 lỗi của wrapper cũ (xem đầu mobile_sam_post.hpp). Test này khoá cả 4.
  A. Thuật toán thuần (chỉ cần g++): letterbox HWC + hậu xử lý low_res_masks, đối chiếu với bản numpy ĐỘC LẬP (bilinear kiểu torch align_corners=False).
  B. Hợp đồng tĩnh: wrapper không còn dùng MNN::Interpreter; core dùng Module API, tensor 3 chiều, toạ độ nhân scale, điểm đệm -1, đầu ra low_res_masks.
  C. CHẠY THẬT (tuỳ chọn, cần $MOBILE_SAM_DIR chứa mobile_sam_encoder.mnn + mobile_sam_decoder.mnn, gói pip MNN==3.6.1, $MNN_SRC): nạp model thật qua mobile_sam_core.hpp,
     ảnh tổng hợp (đĩa sáng trên nền tối) ở 2 kích thước (nhỏ hơn VÀ lớn hơn 1024), click giữa đĩa => mask phải phủ đĩa (IoU > 0,85). Thiếu điều kiện => BỎ QUA nói rõ (không tính là đạt).
  D. Phép PHÁ MÃ trên chính header (bỏ -0.5, bỏ cắt vùng ảnh, bỏ nhân scale...): A/B phải đỏ.
KHÔNG chứng minh: tốc độ/RAM trên máy thật, OpenCL/NPU, ảnh người thật trên thiết bị (đã đo thủ công bus.jpg: IoU 0,973–0,983 so với PyTorch gốc, mục 288).
"""
import glob, os, re, shutil, struct, subprocess, sys, tempfile
import numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JNI = os.path.join(ROOT, 'app/src/main/jni')
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)
if not shutil.which('g++'):
    print('BỎ QUA test: không có g++'); sys.exit(0)
tmp = tempfile.mkdtemp()

# ---------- numpy tham chiếu độc lập: bilinear kiểu torch (align_corners=False, không antialias)
def bilinear(src, dh, dw):
    sh, sw = src.shape
    def idx(n_out, n_in):
        f = np.maximum((np.arange(n_out) + 0.5) * (n_in / n_out) - 0.5, 0.0)
        i0 = np.minimum(f.astype(np.int64), n_in - 1); i1 = np.minimum(i0 + 1, n_in - 1)
        return i0, i1, np.clip(f - i0, 0.0, 1.0)
    y0, y1, wy = idx(dh, sh); x0, x1, wx = idx(dw, sw)
    top = src[np.ix_(y0, x0)] * (1 - wx) + src[np.ix_(y0, x1)] * wx
    bot = src[np.ix_(y1, x0)] * (1 - wx) + src[np.ix_(y1, x1)] * wx
    return top * (1 - wy)[:, None] + bot * wy[:, None]
def ref_post(low, W, H):
    sc = 1024.0 / max(W, H); nw = max(1, int(W * sc)); nh = max(1, int(H * sc))
    up = bilinear(low.astype(np.float64), 1024, 1024)[:nh, :nw]
    return (bilinear(up, H, W) > 0)

def build_post(hdr_dir, exe):
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-w', f'-I{hdr_dir}', os.path.join(ROOT, 'tools/native_tests/mobile_sam_post_check.cpp'), '-o', exe], capture_output=True, text=True)
    return r.returncode == 0, r.stderr[-800:]
def run_post(exe, W, H, low):
    lf, of = os.path.join(tmp, 'low.f32'), os.path.join(tmp, 'out.u8'); low.astype('<f4').tofile(lf)
    r = subprocess.run([exe, 'post', str(W), str(H), lf, of], capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(of): return None
    m = np.fromfile(of, np.uint8); os.remove(of)
    return m.reshape(H, W) > 0 if m.size == W * H else None
def part_a(hdr_dir, exe, tag):
    ok, e = build_post(hdr_dir, exe)
    if not ok: print(e); return False
    rng = np.random.default_rng(288); good = True
    for (W, H) in ((810, 1080), (1920, 1080), (640, 640), (333, 777), (4000, 3000), (100, 60)):
        low = rng.standard_normal((256, 256))                 # KHÔNG làm mượt: biên mask dày đặc => nhạy với nửa-điểm-ảnh và vùng cắt
        got = run_post(exe, W, H, low)
        if got is None: print(f'  {tag}: chạy hỏng ở {W}x{H}'); good = False; continue
        mism = float((got != ref_post(low, W, H)).mean())
        if mism > 1e-4: print(f'  {tag}: {W}x{H} lệch {mism*100:.3f}% so với numpy'); good = False
    return good

# ---------- A
exe = os.path.join(tmp, 'post'); ok = part_a(JNI, exe, 'gốc')
check(ok, 'A1 hậu xử lý low_res -> mask khớp numpy độc lập (6 kích thước, ảnh dọc/ngang/vuông/rất lớn/nhỏ), lệch <= 0,01%')
# letterbox: kích thước, vị trí dán, pad đen, giá trị 0..255 giữ nguyên
rng = np.random.default_rng(7); okb = True
for (W, H) in ((810, 1080), (1920, 1080), (500, 500), (3000, 100)):
    rgb = rng.integers(0, 256, (H, W, 3), dtype=np.uint8); rf, of = os.path.join(tmp, 'a.rgb'), os.path.join(tmp, 'a.f32'); rgb.tofile(rf)
    r = subprocess.run([exe, 'lb', str(W), str(H), rf, of], capture_output=True, text=True)
    if r.returncode != 0: okb = False; continue
    nw, nh, sc = r.stdout.split(); nw, nh, sc = int(nw), int(nh), float(sc)
    a = np.fromfile(of, '<f4').reshape(1024, 1024, 3); es = 1024.0 / max(W, H)
    okb &= abs(sc - es) < 1e-6 and nw == max(1, int(W * es)) and nh == max(1, int(H * es)) and max(nw, nh) in (1024, 1023)
    okb &= bool((a[nh:] == 0).all() and (a[:, nw:] == 0).all())                 # phần pad đen
    okb &= bool(a.max() <= 255 and a.min() >= 0 and a[:nh, :nw].max() > 200)     # thang 0..255 (đồ thị tự chuẩn hoá — KHÔNG chia 255 ở đây)
    if nw > 200 and nh > 300:                                                    # láng giềng gần nhất, gốc trên-trái (dùng float32 y như C++: float scale; double làm lệch đúng ở biên làm tròn)
        s32 = np.float32(1024) / np.float32(max(W, H))
        for (py, px) in ((300, 200), (301, 203), (17, 5)):
            sy, sx = min(H - 1, int(np.float32(py) / s32)), min(W - 1, int(np.float32(px) / s32))
            okb &= bool((a[py, px] == rgb[sy, sx]).all())
check(okb, 'A2 letterboxHWC: scale, vùng dán trên-trái, pad đen, thang 0..255 giữ nguyên, đúng điểm nearest')

# ---------- B hợp đồng tĩnh
core = open(os.path.join(JNI, 'mobile_sam_core.hpp'), encoding='utf-8').read()
wrap = open(os.path.join(JNI, 'mobile_sam_wrapper.cpp'), encoding='utf-8').read()
code_wrap = re.sub(r'//[^\n]*', '', wrap)      # bỏ chú thích để chỉ xét mã
code_core = re.sub(r'//[^\n]*', '', core)
check('Interpreter' not in code_wrap and 'createSession' not in code_wrap and 'Session*' not in code_wrap, 'B1 wrapper KHÔNG còn dùng MNN::Interpreter/Session (decoder không tạo được session — đo thật)')
check(bool(re.search(r'Module::load\(\{"input_image"\}', code_core)) and bool(re.search(r'Module::load\(\{"image_embeddings", "point_coords", "point_labels", "mask_input", "has_mask_input", "orig_im_size"\}', code_core)), 'B2 core nạp encoder + decoder bằng Module::load với đúng tên cổng đã đo')
check('{kInput, kInput, 3}' in code_core and '{1, 3, kInput, kInput}' not in code_core, 'B3 encoder nhận tensor 3 chiều [1024,1024,3] (KHÔNG NCHW 4 chiều)')
check('"low_res_masks"' in code_core and '"masks"' not in code_core, 'B4 dùng low_res_masks, không dùng đầu ra masks đã lệch trong đồ thị')
check(bool(re.search(r'pp\[0\]\s*=\s*clickX\s*\*\s*lb\.scale', code_core)) and bool(re.search(r'pp\[1\]\s*=\s*clickY\s*\*\s*lb\.scale', code_core)), 'B5 toạ độ click nhân scale sang hệ 1024')
check(bool(re.search(r'pl\[0\]\s*=\s*1\.f;\s*pl\[1\]\s*=\s*-1\.f', code_core)), 'B6 có điểm đệm nhãn -1 sau điểm click')
check('letterboxHWC' in code_core and 'postprocessLowRes' in code_core and 'mobile_sam_core.hpp' in wrap and 'mobile_sam_wrapper.cpp' in open(os.path.join(JNI, 'CMakeLists.txt'), encoding='utf-8').read(), 'B7 wrapper dùng core; CMake vẫn biên dịch wrapper')

# ---------- C chạy thật
def part_c():
    mdir = os.environ.get('MOBILE_SAM_DIR', ''); src = os.environ.get('MNN_SRC', '/home/claude/work/tp/MNN')
    enc, dec = os.path.join(mdir, 'mobile_sam_encoder.mnn'), os.path.join(mdir, 'mobile_sam_decoder.mnn')
    if not (os.path.isfile(enc) and os.path.isfile(dec)):
        print('BỎ QUA C (chạy thật): không có $MOBILE_SAM_DIR/mobile_sam_{encoder,decoder}.mnn — tạo bằng: python tools/export_mobilesam.py --output_dir d && mnnconvert -f ONNX ... (xem prepare_models.yml)'); return None
    if not os.path.isfile(os.path.join(src, 'include/MNN/expr/Module.hpp')): print('BỎ QUA C: thiếu MNN_SRC/include'); return None
    try: import MNN
    except Exception: print('BỎ QUA C: chưa cài gói pip MNN==3.6.1'); return None
    so = glob.glob(os.path.join(os.path.dirname(os.path.dirname(MNN.__file__)), '_mnncengine*.so')); lp = glob.glob('/usr/lib/x86_64-linux-gnu/libpython3*.so')
    if not so or not lp: print('BỎ QUA C: không thấy _mnncengine*.so/libpython'); return None
    exe2 = os.path.join(tmp, 'real')
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-w', '-D_GLIBCXX_USE_CXX11_ABI=0', f'-I{src}/include', f'-I{JNI}', os.path.join(ROOT, 'tools/mnn_probe/mobile_sam_real_check.cpp'), '-o', exe2, so[0],
                        '-Wl,--allow-shlib-undefined', '-Wl,-rpath,' + os.path.dirname(so[0]), '-lpthread', '-ldl'], capture_output=True, text=True)
    check(r.returncode == 0, 'C0 mobile_sam_core.hpp THẬT biên dịch + liên kết với MNN 3.6.1 thật')
    if r.returncode != 0: print(r.stderr[-1200:]); return False
    env = dict(os.environ, LD_PRELOAD=lp[0]); allok = True
    for (W, H, rad) in ((400, 300, 70), (1500, 1200, 260)):            # nhỏ hơn 1024 (phải phóng) và lớn hơn 1024 (phải thu): hai nhánh scale khác nhau
        yy, xx = np.mgrid[0:H, 0:W]; cx, cy = W * 0.45, H * 0.55
        img = np.full((H, W, 3), 25, np.uint8); disc = (xx - cx) ** 2 + (yy - cy) ** 2 <= rad ** 2; img[disc] = (235, 225, 200)
        rf, mf = os.path.join(tmp, 'c.rgb'), os.path.join(tmp, 'c.mask'); img.tofile(rf)
        r = subprocess.run([exe2, enc, dec, rf, str(W), str(H), str(cx), str(cy), mf], capture_output=True, text=True, env=env, timeout=240)
        if r.returncode != 0 or not os.path.exists(mf): print(f'  chạy hỏng {W}x{H}: {r.stdout[-200:]}{r.stderr[-300:]}'); allok = False; continue
        m = np.fromfile(mf, np.uint8).reshape(H, W) > 0; iou = (m & disc).sum() / max((m | disc).sum(), 1)
        print(f'  C {W}x{H}: IoU(mask, đĩa)={iou:.3f}  {r.stdout.strip()}')
        allok &= bool(m[int(cy), int(cx)]) and iou > 0.85
    check(allok, 'C1 click giữa đĩa => mask phủ đĩa (IoU > 0,85) ở ảnh nhỏ và lớn hơn 1024, qua mã app THẬT trên model thật')
    return allok
part_c()

# ---------- D phá mã
def mutate(name, old, new):
    d = tempfile.mkdtemp(); shutil.copy(os.path.join(JNI, 'mobile_sam_post.hpp'), d); p = os.path.join(d, 'mobile_sam_post.hpp'); s = open(p, encoding='utf-8').read()
    if old not in s: check(False, f'D {name}: không tìm thấy đoạn để phá'); return
    open(p, 'w', encoding='utf-8').write(s.replace(old, new, 1)); ok = part_a(d, os.path.join(d, 'post'), 'phá'); check(not ok, f'D phá mã [{name}] bị A1 bắt (A1 phải đỏ)')
mutate('bỏ -0.5 (kiểu align_corners=True sai nửa điểm ảnh)', '(x + 0.5f) * rx - 0.5f', '(x + 0.5f) * rx')
mutate('bỏ cắt vùng chứa ảnh (dùng cả khung 1024)', 'lb.newH, lb.newW, full.data(), H, W', 'kInput, kInput, full.data(), H, W')
mutate('đảo trục dọc/ngang khi cắt', 'lb.newH, lb.newW, full.data(), H, W', 'lb.newW, lb.newH, full.data(), H, W')
mutate('ngưỡng sai (> 5 thay vì > 0)', 'full[i] > 0.f', 'full[i] > 5.f')

print(f'\n{"CÓ LỖI: " + str(len(fails)) + " phép kiểm hỏng" if fails else "TẤT CẢ ĐẠT"}')
sys.exit(1 if fails else 0)
