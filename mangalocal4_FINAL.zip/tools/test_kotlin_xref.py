#!/usr/bin/env python3
# mục 270 — test cho tools/kotlin_xref.py: (1) mã dự án hiện tại phải sạch; (2) dự án giả có 3 loại lỗi cố ý phải bị bắt; (3) mã đúng không bị báo nhầm.
import os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import kotlin_xref as K
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)

root = os.path.join(os.path.dirname(HERE), 'app/src/main/java/com/mangalocal')
files, probs = K.analyze(root)
check(len(files) > 50, f'quét {len(files)} tệp Kotlin của dự án')
check(not probs, 'dự án hiện tại: 0 nghi vấn ' + str(probs[:3]))

def mk(d, rel, text):
    p = os.path.join(d, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'w', encoding='utf-8').write(text)

with tempfile.TemporaryDirectory() as d:
    mk(d, 'ui/MainViewModel.kt', 'package com.mangalocal.ui\nclass MainViewModel {\n  fun save(a: Int) {}\n  val x = 1\n  var y = 2\n}\n')
    mk(d, 'model/M.kt', 'package com.mangalocal.model\ndata class Cfg(val aa: Int, val bb: String)\nfun helper(p: Int, q: String = "") {}\n')
    mk(d, 'ui/Good.kt', 'package com.mangalocal.ui\nimport com.mangalocal.model.Cfg\nimport com.mangalocal.model.helper\nfun Good(vm: MainViewModel) {\n  helper(p = 1, q = "a")\n  val c = Cfg(aa = 1, bb = "x")\n  vm.save(1); vm.x; vm.y\n  val s = "helper(zzz = 3) vm.nope"  // chuỗi/ghi chú không được tính\n}\n')
    files, probs = K.analyze(d)
    check(not probs, 'mã đúng (kể cả chuỗi/ghi chú trông giống lỗi) không bị báo nhầm ' + str(probs))
with tempfile.TemporaryDirectory() as d:
    mk(d, 'ui/MainViewModel.kt', 'package com.mangalocal.ui\nclass MainViewModel {\n  fun save(a: Int) {}\n}\n')
    mk(d, 'model/M.kt', 'package com.mangalocal.model\ndata class Cfg(val aa: Int)\nfun helper(p: Int) {}\n')
    mk(d, 'ui/Bad.kt', 'package com.mangalocal.ui\nimport com.mangalocal.model.Cfg\nimport com.mangalocal.model.Missing\nfun Bad(vm: MainViewModel) {\n  helper(pp = 1)\n  Cfg(aaa = 2)\n  vm.nothere()\n}\n')
    files, probs = K.analyze(d)
    kinds = sorted(set(p[0] for p in probs))
    check(kinds == ['import', 'namedarg', 'vm-member'], 'bắt đủ 3 loại lỗi cố ý: ' + str(kinds))
    check(any('helper(pp=)' in p[3] for p in probs) and any('Cfg(aaa=)' in p[3] for p in probs), 'bắt tham số có tên sai ở hàm và constructor')
    check(not any(p[0]=='balance' for p in probs), 'dự án giả đúng ngoặc không bị báo balance')
    check(any(p[3] == 'vm.nothere' for p in probs) and any(p[3].endswith('Missing') for p in probs), 'bắt vm.* thiếu và import không phân giải được')
with tempfile.TemporaryDirectory() as d:
    mk(d, 'ui/B1.kt', 'package com.mangalocal.ui\nfun A() {\n  val s = "}"  // chuỗi chứa ngoặc không tính\n  foo(1, 2\n}\n')
    mk(d, 'ui/B2.kt', 'package com.mangalocal.ui\nfun B() {\n  if (x) { y() }\n}\n}\n')
    mk(d, 'ui/B3.kt', 'package com.mangalocal.ui\nfun C() {\n  val t = "a ${x.map { it }} b"\n  val r = listOf(1)[0]\n}\n')
    files, probs = K.analyze(d)
    bal = sorted((p[1], p[2]) for p in probs if p[0] == 'balance')
    check(bal == [('ui/B1.kt', 4), ('ui/B2.kt', 5)] or [b[0] for b in bal] == ['ui/B1.kt', 'ui/B2.kt'], 'bắt thiếu ngoặc đóng và thừa ngoặc nhọn; chuỗi/mẫu chuỗi đúng ngoặc không bị báo: ' + str(bal))
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails))
sys.exit(1 if fails else 0)
