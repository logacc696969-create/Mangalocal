"""
export_ipa_controlnet_triple_combo_unet.py — Gộp CẢ 3 cơ chế điều kiện vào
1 UNet: Regional Prompting (prompt CHỮ riêng theo cột, xem
export_ipa_controlnet_regional_unet.py) + IP-Adapter (danh tính ẢNH nhân
vật riêng theo ĐÚNG cột đó) + ControlNet Pose+Depth (2 ControlNet cộng dồn
residual, xem export_ipa_controlnet_depth_unet.py).

CHẠY TRÊN MÁY TÍNH (không phải điện thoại), cần Python + GPU khuyến khích.

=== TẠI SAO CẦN FILE RIÊNG, KHÔNG "GHÉP THẲNG" 2 SCRIPT CÓ SẴN ===
`export_ipa_controlnet_regional_unet.py` monkey-patch THẲNG `forward()` của
mọi module `attn2` — cách này THAY THẾ HOÀN TOÀN cơ chế `attn.processor`
(API chính thức diffusers dùng cho IP-Adapter). Nghĩa là: nếu chỉ gọi
`pipe.load_ip_adapter()` rồi ĐÈ THÊM hook Regional Prompting lên trên như
2 script hiện có, `attn.processor` (nơi giữ toàn bộ logic + trọng số
`to_k_ip`/`to_v_ip` của IP-Adapter) SẼ KHÔNG BAO GIỜ được gọi nữa — danh
tính nhân vật biến mất hoàn toàn, không lỗi, không cảnh báo (silent no-op)
— đây là rủi ro kết hợp SAI mà 2 file gốc không tự cảnh báo được vì mỗi
file chỉ biết về chính nó.

Vì vậy file này viết 1 hook attn2 MỚI (`hook_triple_combo_attn2()`) — GỘP
TRỰC TIẾP 2 phần logic đã xác nhận thật:
  1. Phần chia cột theo prompt chữ — copy nguyên cấu trúc `run_attn()` +
     splice-theo-cột từ `export_ipa_controlnet_regional_unet.py`.
  2. Phần tính attention IP-Adapter (nhánh "không mask" — 1 ảnh nhân vật —
     của `DecayedIPAdapterAttnProcessor2_0.__call__`, xem
     `tools/ip_adapter_decay.py`) — copy nguyên logic SDPA + nhân
     `decay_state.value`, chỉ đổi input query từ "toàn ảnh" thành "đúng
     cột của nhân vật đó" (tái dùng CÙNG phép cắt cột với vế prompt chữ ở
     trên — xem "ĐƠN GIẢN HOÁ" bên dưới).
Không tự nghĩ ra công thức toán mới ở bước nào — chỉ tổ hợp lại 2 khối đã
kiểm chứng bằng thực nghiệm ở các file khác (xem CHANGELOG_smooth_decay_
expression.md mục 1 cho ip_decay, và docstring
export_ipa_controlnet_regional_unet.py cho phần splice cột).

=== ĐƠN GIẢN HOÁ — NÓI RÕ, KHÔNG PHẢI PORT ĐẦY ĐỦ "IP-ADAPTER MASKING" ===
`export_ipa_controlnet_mask_unet.py` (bản mask N-nhân-vật) dùng MASK NHỊ
PHÂN THẬT do app tự vẽ từ bounding box khung xương (ranh giới có thể là
hình chữ nhật bất kỳ, không nhất thiết thẳng cột). File NÀY không dùng
input mask riêng — TÁI SỬ DỤNG ĐÚNG phép chia N-cột-đều-nhau của Regional
Prompting làm luôn "mask" cho IP-Adapter: nhân vật ở cột i chỉ nhận danh
tính ẢNH của chính nó trong đúng dải cột i. Đánh đổi:
  - ƯU: không cần thêm input mask riêng (đỡ 1 tensor), đảm bảo prompt CHỮ
    và danh tính ẢNH của 1 nhân vật LUÔN khớp đúng cùng 1 vùng — không có
    trường hợp ăn 2 loại thông tin từ 2 vùng khác nhau như nếu ghép 2 mask
    độc lập không đồng bộ.
  - NHƯỢC: kế thừa NGUYÊN giới hạn của Regional Prompting — chỉ chia CỘT
    DỌC đều nhau, chỉ ảnh VUÔNG (xem docstring
    export_ipa_controlnet_regional_unet.py) — không hỗ trợ vùng bất kỳ
    hình dạng như bản mask thật. Nếu cần ranh giới vùng tự do (không phải
    cột thẳng đều), phải dùng export_ipa_controlnet_mask_unet.py (đánh đổi
    ngược lại: có mask tự do nhưng KHÔNG có Regional Prompting theo chữ).
  - to_k_ip/to_v_ip dùng 1 BỘ TRỌNG SỐ DUY NHẤT (1 IP-Adapter, giống cách
    export_ipa_controlnet_mask_unet.py làm — "1 IP-Adapter, N ảnh", KHÔNG
    phải "N IP-Adapter khác nhau") — áp dụng cho MỌI cột, chỉ khác nhau ở
    ảnh nhân vật (ip_hidden_states) đưa vào mỗi cột.

=== KHÔNG kết hợp thêm ip_adapter_masks (mask tự do) TRONG CÙNG BẢN NÀY ===
Cố tình KHÔNG nhận thêm input mask tự do song song với cột — sẽ làm forward()
phải hoà trộn 2 loại ranh giới vùng khác nguồn (cột cứng vs mask tự do),
rủi ro lệch nhau cao, chưa có cách kiểm chứng hợp lý trong sandbox này.

=== BATCH + TRACE ===
Giống hệt lý do trong export_ipa_controlnet_regional_unet.py: trace THẲNG
batch=2 ([uncond, cond]) — khớp đúng cách PipelineSd15Cpu.hpp gọi UNet thật
(1 lần, gộp sẵn cả 2 vế). Vế uncond CHỈ dùng prompt âm toàn ảnh, KHÔNG cộng
IP-Adapter (giống Regional Prompting gốc không chia vùng uncond) — đây là
ĐƠN GIẢN HOÁ CÓ CHỦ ĐÍCH, không phải sơ suất: cách CFG chuẩn của IP-Adapter
trong diễn giải phổ biến nhất là cộng identity vào CẢ 2 vế bằng nhau, bản
này KHÔNG làm vậy — có thể khiến độ ảnh hưởng danh tính thực tế yếu hơn kỳ
vọng so với set_ip_adapter_scale() dùng trong pipeline Python gốc. Ghi rõ ở
GIỚI HẠN THẬT bên dưới, chưa đo được mức chênh lệch thật (cần chạy A/B thật
mới biết).

ControlNet (Pose + Depth) không đụng gì tới attn2 — cộng residual y hệt
export_ipa_controlnet_depth_unet.py, dùng encoder_hidden_states PLACEHOLDER
(ghép [uncond, region 0]) làm cross-attention nội bộ của ControlNet — ĐÚNG
cách export_ipa_controlnet_regional_unet.py đã làm (ControlNet không có khái
niệm "vùng").

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_triple_combo_unet.py \\
        --base_model runwayml/stable-diffusion-v1-5 \\
        --num_regions 2 --output_dir ./exported_triple --image_size 512

GIỚI HẠN THẬT (đọc trước khi tin đây là "xong"):
  - CHƯA CHẠY THỬ THẬT — không GPU/model thật trong sandbox lúc viết file
    này. Chỉ xác nhận: cú pháp hợp lệ (py_compile), cấu trúc ghép ĐÚNG 2
    khối logic đã kiểm chứng ở 2 file khác (không phải suy đoán tay không
    nguồn nào). Đây là script PHỨC TẠP NHẤT trong dự án (3 cơ chế cùng lúc)
    — khả năng gặp lỗi "unsupported op"/shape mismatch lúc chạy thật CAO
    HƠN các script khác, chưa có cách nào giảm rủi ro này ngoài chạy thử.
  - IP-Adapter KHÔNG cộng vào vế uncond (xem "BATCH + TRACE" ở trên) — độ
    ảnh hưởng danh tính thật có thể khác (thường YẾU hơn) so với hành vi
    `pipe(...)` gốc của diffusers khi chạy pipeline Python bình thường.
  - Danh tính + prompt bị KHOÁ CHUNG 1 ranh giới cột cứng (xem "ĐƠN GIẢN
    HOÁ") — cảnh 2 nhân vật ôm/đan xen KHÔNG PHẢI trường hợp phù hợp (đúng
    ranh giới đứng chồng lấn thật, cột thẳng sẽ cắt sai) — dùng
    export_ipa_controlnet_mask_unet.py cho trường hợp đó, KHÔNG dùng bản
    này.
  - N cố định lúc export (num_regions == num_characters, đúng nguyên tắc
    không dynamic_axes toàn dự án) — đổi N phải export lại.
  - App (Kotlin/C++: MangaPipeline.kt, ip_adapter.cpp) CHƯA ĐƯỢC NỐI DÂY
    để gọi model này — file này CHỈ xuất được .onnx/.mnn, chưa có code
    phía app truyền đủ input mới (`region_encoder_hidden_states`,
    `region_ip_embeds`) hay chọn đúng model khi cảnh có N nhân vật cần cả
    3 cơ chế cùng lúc. Đây là việc RIÊNG, CHƯA làm ở đây (ghi trong
    "Việc còn lại" ở đuôi file này).
    ĐÍNH CHÍNH (mục 219 TECHNICAL_STATUS.md): dòng trên ĐÃ LỖI THỜI — đã
    được nối dây thật ở mục 151 (`triple_combo.cpp`, `MangaPipeline.kt`),
    giữ nguyên câu gốc ở đây làm "ảnh chụp" lịch sử, KHÔNG xoá (đúng quy
    ước dự án — sự thật hiện tại nằm ở TECHNICAL_STATUS.md, không sửa lại
    docstring cũ mỗi khi trạng thái đổi).

=== mục 219 (đợt 3 của "Location Anchor", tiếp mục 217/218) — with_location_slot ===
KHÁC HẲN cách mục 217/218 thêm slot bối cảnh cho Mc/SDXL (chỉ tham số hoá
thêm 1 nấc N->N+1 trong 1 danh sách CÓ SẴN) — file NÀY không có "danh
sách N phần tử độc lập" để thêm phần tử N+1 vào: Regional Prompting chia
CỘT là 1 phép CHIA HẾT toàn bộ ảnh cho N vùng (`lo=side*i/N`,
`hi=side*(i+1)/N`), không có "khoảng trống" nào còn lại để dành cho 1
"vùng bối cảnh" thêm — thêm hẳn 1 cột thứ N+1 sẽ CƯỚP diện tích của N cột
nhân vật hiện có (mỗi người bị thu hẹp lại), sai mục đích ("bối cảnh làm
NỀN đằng sau mọi người", không phải "bối cảnh chiếm 1 dải ảnh riêng").

Thiết kế dùng ở đây (KHÁC — đọc kỹ trước khi tin đây cùng mức tin cậy với
phần Mc/SDXL): thêm 1 lượt IP-Adapter tính trên TOÀN ẢNH (dùng q của
`cond_hs` TRƯỚC khi cắt cột — giống hệt cách mỗi vùng vốn đã tính q từ
`cond_hs` không đổi, xem `run_ip_attn`), rồi CỘNG THÊM (không thay thế)
kết quả này vào `cond_out` SAU KHI đã splice xong N cột như cũ — nghĩa là
mỗi nhân vật vẫn giữ NGUYÊN danh tính/prompt riêng đúng cột của họ, chỉ có
thêm 1 lớp ảnh hưởng bối cảnh phủ ĐỀU lên toàn khung hình.

GIỚI HẠN THẬT — QUAN TRỌNG: đây là công thức toán MỚI, không copy nguyên
từ diffusers hay từ chỗ khác trong dự án như phần còn lại của file này tự
nhận đã làm ("Không tự nghĩ ra công thức toán mới ở bước nào" — dòng ở
trên) — with_location_slot LÀ NGOẠI LỆ so với câu đó, cần nói thẳng để
không đánh lừa người đọc sau. Thiết kế dựa trên suy luận từ cấu trúc code
GỐC (`run_ip_attn` không đổi, chỉ đổi NƠI gọi + cách cộng kết quả), không
suy luận toán học từ đầu — nhưng CHƯA verify được bằng thực nghiệm thật
(không GPU/mạng đủ để re-run kiểu kiểm chứng ở mục 97/217đợt2) lúc viết.
Rủi ro sai cao hơn hẳn các phần khác — nếu ảnh ra bị lem màu/nhoè bất
thường khi bật `--with_location_slot`, nghi ngờ ĐẦU TIÊN nên là công thức
cộng này, không phải chỗ khác.
"""
import argparse
import os

import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers import ControlNetModel, StableDiffusionControlNetPipeline
from diffusers.models.attention_processor import IPAdapterAttnProcessor2_0

from ip_adapter_decay import IpDecayState


def hook_triple_combo_attn2(unet: nn.Module, num_regions: int, decay_state: IpDecayState,
                             with_location_slot: bool = False):
    """Monkey-patch forward() của mọi module attn2 — GỘP Regional Prompting
    (chữ, theo cột) + IP-Adapter (ảnh, ĐÚNG cột đó). Trước khi ghi đè
    forward, LẤY RA `to_k_ip[0]`/`to_v_ip[0]`/`scale[0]` từ
    `module.processor` GỐC (đã gắn bởi `pipe.load_ip_adapter()` — 1 adapter
    duy nhất, xem "ĐƠN GIẢN HOÁ" ở docstring đầu file) — TÁI SỬ DỤNG trọng
    số đã train, không copy giá trị/tạo mới.

    with_location_slot=True (mục 219): thêm 1 lượt IP-Adapter TOÀN ẢNH,
    cộng thêm (không thay cột nào) sau khi đã splice N cột — xem docstring
    đầu file mục "mục 219" cho lý do + GIỚI HẠN THẬT (công thức MỚI, chưa
    verify bằng thực nghiệm).
    """
    state = {"uncond": None, "regions": None, "ip_regions": None,
             "bg_ip": None, "location_scale": None}

    def make_forward(attn: nn.Module):
        base_processor = attn.processor
        if not isinstance(base_processor, IPAdapterAttnProcessor2_0):
            # Lớp attn2 này KHÔNG có IP-Adapter gắn (vd cross-attention ở
            # tầng không được load_ip_adapter() đụng tới) — CHỈ áp dụng
            # Regional Prompting (chữ), bỏ qua phần IP-Adapter cho đúng
            # lớp này. Không nên xảy ra với cấu trúc UNet2DConditionModel
            # chuẩn (mọi attn2 đều được gắn processor khi load_ip_adapter
            # chạy) — giữ nhánh này để KHÔNG crash nếu cấu trúc khác đi,
            # thay vì giả định mù.
            to_k_ip = None
            to_v_ip = None
            ip_static_scale = None
        else:
            to_k_ip = base_processor.to_k_ip[0]
            to_v_ip = base_processor.to_v_ip[0]
            ip_static_scale = base_processor.scale[0] if isinstance(base_processor.scale, list) \
                else base_processor.scale

        def forward(hidden_states, encoder_hidden_states=None, attention_mask=None, temb=None, **kw):
            residual = hidden_states
            if attn.spatial_norm is not None:
                hidden_states = attn.spatial_norm(hidden_states, temb)
            input_ndim = hidden_states.ndim
            if input_ndim == 4:
                b, c, h4, w4 = hidden_states.shape
                hidden_states = hidden_states.view(b, c, h4 * w4).transpose(1, 2)

            seq_len = hidden_states.shape[1]
            side = int(round(seq_len ** 0.5))  # ảnh vuông — xem giới hạn ở docstring

            uncond_hs = hidden_states[0:1]
            cond_hs = hidden_states[1:2]

            def run_text_attn(hs, enc_hs):
                q = attn.to_q(hs)
                k = attn.to_k(enc_hs)
                v = attn.to_v(enc_hs)
                inner_dim = k.shape[-1]
                head_dim = inner_dim // attn.heads
                q2 = q.view(hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                k2 = k.view(enc_hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                v2 = v.view(enc_hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                out = F.scaled_dot_product_attention(q2, k2, v2, dropout_p=0.0, is_causal=False)
                out = out.transpose(1, 2).reshape(hs.shape[0], -1, attn.heads * head_dim).to(q.dtype)
                out = attn.to_out[0](out)
                out = attn.to_out[1](out)
                return out, q, head_dim

            def run_ip_attn(q, head_dim, ip_hidden_states_1char):
                # Copy nguyên logic nhánh "không mask" của
                # DecayedIPAdapterAttnProcessor2_0.__call__ (tools/
                # ip_adapter_decay.py) — chỉ đổi query đầu vào từ "toàn
                # ảnh" thành query CỦA ĐÚNG CỘT (q truyền vào đây đã là q
                # tính từ cond_hs TOÀN ẢNH — xem cách gọi bên dưới, phép
                # "cắt cột" xảy ra ở bước splice cuối, GIỐNG HỆT cách vế
                # prompt chữ splice, để 2 vế đồng bộ đúng 1 ranh giới).
                ip_key = to_k_ip(ip_hidden_states_1char)
                ip_value = to_v_ip(ip_hidden_states_1char)
                ip_key = ip_key.view(q.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                ip_value = ip_value.view(q.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                q2 = q.view(q.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                ip_out = F.scaled_dot_product_attention(q2, ip_key, ip_value, dropout_p=0.0, is_causal=False)
                ip_out = ip_out.transpose(1, 2).reshape(q.shape[0], -1, attn.heads * head_dim).to(q.dtype)
                return ip_out

            # Vế uncond: CHỈ prompt âm toàn ảnh, KHÔNG cộng IP-Adapter — xem
            # "BATCH + TRACE" ở docstring đầu file cho lý do + giới hạn.
            uncond_out, _, _ = run_text_attn(uncond_hs, state["uncond"])

            # Vế cond: N vùng, MỖI vùng = text attention (toàn ảnh, đúng
            # prompt vùng đó) + IP-Adapter attention (toàn ảnh, đúng ảnh
            # nhân vật vùng đó) CỘNG LẠI trước khi splice — để identity và
            # prompt LUÔN khớp cùng 1 ranh giới cột khi cắt.
            region_combined = []
            for i in range(num_regions):
                text_out_i, q_full, head_dim = run_text_attn(cond_hs, state["regions"][i:i + 1])
                if to_k_ip is not None and state["ip_regions"] is not None:
                    ip_out_i = run_ip_attn(q_full, head_dim, state["ip_regions"][i:i + 1])
                    combined_i = text_out_i + ip_static_scale * decay_state.value * ip_out_i
                else:
                    combined_i = text_out_i
                region_combined.append(combined_i)

            spliced = torch.zeros_like(region_combined[0])
            spliced_2d = spliced.view(1, side, side, -1)
            for i, out in enumerate(region_combined):
                lo = int(side * i / num_regions)
                hi = int(side * (i + 1) / num_regions)
                out_2d = out.view(1, side, side, -1)
                spliced_2d[:, :, lo:hi, :] = out_2d[:, :, lo:hi, :]
            cond_out = spliced_2d.view(1, seq_len, -1)

            # mục 219 — slot bối cảnh, CỘNG THÊM (không thay cột nào) SAU
            # khi đã splice N cột xong. q dùng lại đúng cách mỗi vùng đã
            # dùng (attn.to_q(cond_hs) — không đổi theo vùng, xem
            # run_ip_attn/run_text_attn) — tính 1 LẦN áp cho TOÀN ẢNH, khác
            # hẳn vòng lặp per-region ở trên (không splice/cắt cột kết quả
            # này). KHÔNG nhân decay_state.value (khác ip_out_i của từng
            # nhân vật) — bối cảnh không có "biểu cảm" để nhường chỗ, xem
            # mục 217 đợt 1 TECHNICAL_STATUS.md cho lý do gốc của lựa chọn
            # này (đã áp dụng nhất quán cho Mc/SDXL).
            if with_location_slot and to_k_ip is not None and state["bg_ip"] is not None:
                q_bg = attn.to_q(cond_hs)
                bg_out = run_ip_attn(q_bg, head_dim, state["bg_ip"])
                cond_out = cond_out + state["location_scale"] * bg_out

            hidden_states = torch.cat([uncond_out, cond_out], dim=0)

            if input_ndim == 4:
                hidden_states = hidden_states.transpose(-1, -2).reshape(b, c, h4, w4)
            if attn.residual_connection:
                hidden_states = hidden_states + residual
            hidden_states = hidden_states / attn.rescale_output_factor
            return hidden_states
        return forward

    for name, module in unet.named_modules():
        if "attn2" in name and module.__class__.__name__ == "Attention":
            module.forward = make_forward(module)

    def set_state(uncond_embeds, region_embeds, ip_region_embeds, bg_ip_embeds=None, location_scale=None):
        state["uncond"] = uncond_embeds
        state["regions"] = region_embeds
        state["ip_regions"] = ip_region_embeds
        # mục 219 — chỉ có ý nghĩa khi with_location_slot=True (đọc ở
        # forward() — nhánh cộng bối cảnh tự kiểm tra with_location_slot
        # trước khi đụng tới 2 giá trị này, nên gán vô điều kiện ở đây vẫn
        # an toàn kể cả khi with_location_slot=False, chỉ đơn giản không
        # bao giờ được đọc tới).
        state["bg_ip"] = bg_ip_embeds
        state["location_scale"] = location_scale

    return set_state


class AugmentedUNetTripleCombo(nn.Module):
    """UNet + ControlNet-Pose + ControlNet-Depth + Regional Prompting (chữ)
    + IP-Adapter theo cột (ảnh) — xem docstring đầu file cho lý do gộp thủ
    công thay vì ghép 2 script có sẵn."""

    def __init__(self, unet, controlnet_pose, controlnet_depth, num_regions, decay_state: IpDecayState,
                 with_location_slot: bool = False):
        super().__init__()
        self.unet = unet
        self.controlnet_pose = controlnet_pose
        self.controlnet_depth = controlnet_depth
        self.with_location_slot = with_location_slot
        self.set_state = hook_triple_combo_attn2(unet, num_regions, decay_state, with_location_slot)
        self._decay_state = decay_state

    def forward(self, sample, timestep, uncond_embeds, region_embeds, ip_region_embeds,
                pose_hint, depth_hint, pose_scale, depth_scale,
                ip_decay_floor, ip_decay_start_timestep,
                # mục 219 TECHNICAL_STATUS.md — "Location Anchor" đợt 3.
                # CHỈ có mặt trong đồ thị ONNX khi with_location_slot=True
                # lúc TRACE (2 tham số này KHÔNG traced vào file KHÔNG có
                # hậu tố "_loc" — main() bên dưới chỉ đưa vào example_inputs
                # khi bật cờ, torch.onnx.export dựa đúng vào example đó để
                # quyết định input nào thật sự có trong đồ thị).
                location_ip_embeds=None, location_scale=None):
        # ControlNet: KHÔNG có khái niệm "vùng" — dùng placeholder
        # [uncond, region 0] làm cross-attention nội bộ, ĐÚNG cách
        # export_ipa_controlnet_regional_unet.py đã làm (xem docstring ở
        # đó cho lý do).
        cn_encoder_hidden = torch.cat([uncond_embeds, region_embeds[0:1]], dim=0)
        down_pose, mid_pose = self.controlnet_pose(
            sample, timestep, encoder_hidden_states=cn_encoder_hidden,
            controlnet_cond=pose_hint, return_dict=False,
        )
        down_depth, mid_depth = self.controlnet_depth(
            sample, timestep, encoder_hidden_states=cn_encoder_hidden,
            controlnet_cond=depth_hint, return_dict=False,
        )
        down_res = [p * pose_scale + d * depth_scale for p, d in zip(down_pose, down_depth)]
        mid_res = mid_pose * pose_scale + mid_depth * depth_scale

        # Smooth Timestep Decay IP-Adapter — công thức Y HỆT
        # export_ipa_controlnet_depth_unet.py (xem đó cho giải thích đầy
        # đủ), gán vào decay_state.value TRƯỚC khi self.set_state()/
        # self.unet() chạy để hook attn2 đọc được giá trị runtime.
        safe_start = torch.clamp(ip_decay_start_timestep, min=1e-3)
        ramp = torch.clamp(timestep.float(), min=torch.zeros_like(safe_start), max=safe_start) / safe_start
        self._decay_state.value = ip_decay_floor + (1.0 - ip_decay_floor) * ramp

        self.set_state(uncond_embeds, region_embeds, ip_region_embeds, location_ip_embeds, location_scale)
        # placeholder — bị hook attn2 ghi đè hoàn toàn (xem hook), vẫn cần
        # 1 tensor hợp lệ vì UNet2DConditionModel.forward() đọc shape của
        # nó ở vài chỗ KHÔNG phải attn2 (vd time embedding phụ nếu có).
        placeholder_encoder_hidden = torch.cat([uncond_embeds, uncond_embeds], dim=0)
        noise_pred = self.unet(
            sample, timestep, encoder_hidden_states=placeholder_encoder_hidden,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            return_dict=False,
        )[0]
        return noise_pred


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="runwayml/stable-diffusion-v1-5")
    ap.add_argument("--controlnet_model", default="lllyasviel/control_v11p_sd15_openpose")
    ap.add_argument("--depth_controlnet_model", default="lllyasviel/control_v11f1p_sd15_depth")
    ap.add_argument("--ip_adapter_repo", default="h94/IP-Adapter")
    ap.add_argument("--ip_adapter_weight", default="ip-adapter_sd15.bin")
    ap.add_argument("--num_regions", type=int, default=2,
                     help="So cot doc = so nhan vat (>=2, xem GIOI HAN THAT)")
    # mục 219 TECHNICAL_STATUS.md — "Location Anchor" đợt 3. KHÁC Mc/SDXL
    # (mục 217/218): location_scale ở đây là INPUT RUNTIME (traced tensor,
    # giống pose_scale/depth_scale) chứ KHÔNG đóng băng lúc export — vì
    # nhánh cộng bối cảnh (xem hook_triple_combo_attn2) tách biệt hẳn khỏi
    # cơ chế per-region scale tĩnh sẵn có, không có lý do phải đóng băng.
    ap.add_argument("--with_location_slot", action="store_true",
                     help="Them 1 luot IP-Adapter TOAN ANH cong THEM sau khi splice N cot - xem muc 219 TECHNICAL_STATUS.md (cong thuc MOI, chua verify thuc nghiem). Doi ten file xuat ra sang hau to '_loc'.")
    ap.add_argument("--output_dir", default="./exported_triple")
    ap.add_argument("--image_size", type=int, default=512, help="PHAI la anh VUONG")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    if args.num_regions < 2:
        raise ValueError("num_regions phai >= 2")

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_size = args.image_size // 8

    print("Đang tải ControlNet-OpenPose...")
    controlnet_pose = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)
    print("Đang tải ControlNet-Depth...")
    controlnet_depth = ControlNetModel.from_pretrained(args.depth_controlnet_model, torch_dtype=torch.float32)

    print("Đang tải base SD1.5 + IP-Adapter...")
    pipe = StableDiffusionControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet_pose, torch_dtype=torch.float32, safety_checker=None
    )
    pipe.load_ip_adapter(args.ip_adapter_repo, subfolder="models", weight_name=args.ip_adapter_weight)
    pipe.set_ip_adapter_scale(1.0)
    pipe.to(device)
    controlnet_pose.to(device)
    controlnet_depth.to(device)

    # Dò shape text embeds + ip image embeds THẬT (không đoán), đúng
    # nguyên tắc toàn dự án — xem export_ipa_controlnet_unet.py.
    with torch.no_grad():
        dummy_ids = pipe.tokenizer(["a photo"], padding="max_length",
                                    max_length=pipe.tokenizer.model_max_length,
                                    truncation=True, return_tensors="pt").input_ids.to(device)
        probe_text_embed = pipe.text_encoder(dummy_ids)[0]
        from PIL import Image
        dummy_image = Image.new("RGB", (224, 224), color=(128, 128, 128))
        probe_ip_embeds = pipe.prepare_ip_adapter_image_embeds(
            ip_adapter_image=[dummy_image], ip_adapter_image_embeds=None,
            device=device, num_images_per_prompt=1, do_classifier_free_guidance=False,
        )[0]
    print(f"[probe] text embeds shape: {tuple(probe_text_embed.shape)}")
    print(f"[probe] ip image embeds shape: {tuple(probe_ip_embeds.shape)}")

    decay_state = IpDecayState()
    print(f"Đang lắp AugmentedUNetTripleCombo ({args.num_regions} vùng" +
          (" + 1 lượt bối cảnh toàn ảnh" if args.with_location_slot else "") + ")...")
    augmented = AugmentedUNetTripleCombo(
        pipe.unet, controlnet_pose, controlnet_depth, args.num_regions, decay_state,
        with_location_slot=args.with_location_slot
    ).to(device).eval()

    example_sample = torch.randn(2, 4, latent_size, latent_size, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_uncond = torch.randn_like(probe_text_embed)
    example_regions = torch.randn(args.num_regions, *probe_text_embed.shape[1:], device=device)
    example_ip_regions = torch.randn(args.num_regions, *probe_ip_embeds.shape[1:], device=device)
    example_pose_hint = torch.randn(2, 3, args.image_size, args.image_size, device=device)
    example_depth_hint = torch.randn(2, 3, args.image_size, args.image_size, device=device)
    example_pose_scale = torch.tensor(1.0, device=device, dtype=torch.float32)
    example_depth_scale = torch.tensor(0.6, device=device, dtype=torch.float32)
    example_ip_decay_floor = torch.tensor(1.0, device=device, dtype=torch.float32)
    example_ip_decay_start = torch.tensor(999.0, device=device, dtype=torch.float32)

    # mục 219 — 2 input MỚI, CHỈ đưa vào tuple example khi bật cờ (xem
    # comment ở AugmentedUNetTripleCombo.forward()) — location_ip_embeds
    # CÙNG SHAPE với 1 phần tử của region_ip_embeds (1 ảnh, không phải N).
    example_inputs = (example_sample, example_timestep, example_uncond, example_regions, example_ip_regions,
                       example_pose_hint, example_depth_hint, example_pose_scale, example_depth_scale,
                       example_ip_decay_floor, example_ip_decay_start)
    input_names = ["sample", "timestep", "uncond_encoder_hidden_states",
                   "region_encoder_hidden_states", "region_ip_embeds",
                   "pose_hint", "depth_hint", "pose_scale", "depth_scale",
                   "ip_decay_floor", "ip_decay_start_timestep"]
    if args.with_location_slot:
        example_location_ip = torch.randn(1, *probe_ip_embeds.shape[1:], device=device)
        example_location_scale = torch.tensor(0.5, device=device, dtype=torch.float32)
        example_inputs = example_inputs + (example_location_ip, example_location_scale)
        input_names = input_names + ["location_ip_embeds", "location_scale"]

    loc_suffix = "_loc" if args.with_location_slot else ""
    onnx_name = f"unet_triple_combo_{args.num_regions}region{loc_suffix}.onnx"
    onnx_path = os.path.join(args.output_dir, onnx_name)
    print(f"Đang export ONNX -> {onnx_path} (model PHỨC TẠP NHẤT dự án, có thể mất khá lâu)...")
    with torch.no_grad():
        torch.onnx.export(
            augmented,
            example_inputs,
            onnx_path,
            input_names=input_names,
            output_names=["out_sample"],
            opset_version=17,
            do_constant_folding=True,
            dynamo=False,  # xem export_ipa_controlnet_unet.py cho lý do đầy đủ —
            # torch >=2.9 đổi exporter mặc định sang dynamo, cần onnxscript,
            # chưa kiểm chứng với cơ chế runtime-scalar dự án đang dùng.
        )

    print("\n=== XONG PHẦN ONNX ===")
    print(f"Shape region_encoder_hidden_states ({args.num_regions} vùng): {tuple(example_regions.shape)}")
    print(f"Shape region_ip_embeds ({args.num_regions} vùng): {tuple(example_ip_regions.shape)}")
    if args.with_location_slot:
        print(f"Shape location_ip_embeds (1 bối cảnh, cộng thêm toàn ảnh — mục 219): {tuple(example_location_ip.shape)}")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, onnx_name.replace('.onnx', '.mnn'))} --bizCode biz")
    print(f"\nQUAN TRỌNG: model CỐ ĐỊNH cho ĐÚNG {args.num_regions} vùng VÀ ảnh VUÔNG "
          f"{args.image_size}x{args.image_size} — xem GIỚI HẠN THẬT ở đầu file.")
    # ĐÍNH CHÍNH (mục 219): 3 dòng "VIỆC CÒN LẠI" gốc bên dưới đã LỖI THỜI
    # — app ĐÃ được nối dây thật từ mục 151 (triple_combo.cpp,
    # MangaPipeline.kt) và LLMParser.kt ĐÃ tách prompt theo từng nhân vật
    # từ trước đó — giữ nguyên làm "ảnh chụp" lịch sử (đúng quy ước dự án,
    # xem đính chính tương tự ở docstring đầu file), KHÔNG xoá.
    print("\n=== VIỆC CÒN LẠI (CHƯA làm ở file này, tính TẠI THỜI ĐIỂM VIẾT — xem đính chính mục 219 TECHNICAL_STATUS.md) ===")
    print("1. CHƯA chạy thử thật (cần GPU + thời gian) — rủi ro unsupported op cao nhất")
    print("   trong toàn bộ dự án do gộp 3 cơ chế cùng lúc.")
    print("2. App (Kotlin/C++) CHƯA nối dây gọi model này — cần thêm ở MangaPipeline.kt")
    print("   (chọn model này khi cảnh cần cả Regional Prompting + IP-Adapter + Depth)")
    print("   + ip_adapter.cpp (feed 2 input mới: region_encoder_hidden_states/region_ip_embeds,")
    print("   dựng từ N ảnh neo nhân vật + N đoạn prompt LLM tách theo nhân vật).")
    print("3. LLMParser.kt CHƯA tách prompt LLM theo TỪNG NHÂN VẬT (hiện sinh 1 prompt")
    print("   chung cho cả cảnh) — cần thêm field per-character prompt để có dữ liệu")
    print("   đưa vào region_encoder_hidden_states.")


if __name__ == "__main__":
    main()
