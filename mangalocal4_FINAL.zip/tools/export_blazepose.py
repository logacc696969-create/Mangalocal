#!/usr/bin/env python3
# mục 280 — xuất BlazePose GHUM 3D (MediaPipe Pose Landmark lite/full) sang MNN cho app: blazepose_lite.mnn (~2,8 MB) và blazepose_full.mnn (~6,4 MB).
# Nguồn: tflite trong google/mediapipe tag v0.8.10 (Apache-2.0), GHIM sha256 — nguồn đổi thì script dừng thay vì xuất model lạ. Chuyển bằng `mnnconvert -f TFLITE --fp16`
# (đã kiểm: fp16 cho kết quả y hệt tflite chuẩn — trọng số gốc đã là fp16). Sau khi xuất TỰ KIỂM: input [1,256,256,3] NHWC, ba đầu ra có 195 / 117 / 1 phần tử (đúng thứ blazepose_wrapper.cpp chọn
# theo số phần tử), chạy thử một lần trên ảnh xám.
# Dùng:  pip install MNN numpy   rồi   python3 tools/export_blazepose.py [thư_mục_ra=blazepose_out]
# Chép hai tệp .mnn vào thư mục model của app (cùng chỗ yolov8_pose.mnn: MangaLocal/yolo/). Chỉ cần lite; có full thì app ưu tiên full (chính xác hơn, ~2× chậm hơn).
import hashlib, os, shutil, subprocess, sys, urllib.request
SRC = {
    'lite': ('f17bfbecadb61c3be1baa8b8d851cc6619c870a87167b32848ad20db306b9d61',),
    'full': ('e9a5c5cb17f736fafd4c2ec1da3b3d331d6edbe8a0d32395855aeb2cdfd64b9f',),
}
URL = 'https://raw.githubusercontent.com/google/mediapipe/v0.8.10/mediapipe/modules/pose_landmark/pose_landmark_{}.tflite'
out = sys.argv[1] if len(sys.argv) > 1 else 'blazepose_out'
os.makedirs(out, exist_ok=True)
mc = shutil.which('mnnconvert')
if not mc: sys.exit('Thiếu mnnconvert (pip install MNN).')
import numpy as np, MNN
for name, (sha,) in SRC.items():
    tfl = os.path.join(out, f'pose_landmark_{name}.tflite'); mnn = os.path.join(out, f'blazepose_{name}.mnn')
    if not os.path.exists(tfl): urllib.request.urlretrieve(URL.format(name), tfl)
    got = hashlib.sha256(open(tfl, 'rb').read()).hexdigest()
    if got != sha: sys.exit(f'sha256 của pose_landmark_{name}.tflite = {got} KHÁC bản đã ghim {sha} — nguồn đã đổi, cần xem lại trước khi dùng.')
    r = subprocess.run([mc, '-f', 'TFLITE', '--modelFile', tfl, '--MNNModel', mnn, '--bizCode', 'mangalocal', '--fp16'], capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(mnn): sys.exit(f'mnnconvert lỗi ({name}): ' + (r.stdout + r.stderr)[-400:])
    net = MNN.Interpreter(mnn); sess = net.createSession(); inp = net.getSessionInput(sess)
    if tuple(inp.getShape()) != (1, 256, 256, 3): sys.exit(f'{name}: input {inp.getShape()} ≠ (1,256,256,3)')
    counts = sorted(int(np.prod(t.getShape())) for t in net.getSessionOutputAll(sess).values())
    for need in (1, 117, 195):
        if need not in counts: sys.exit(f'{name}: không có đầu ra {need} phần tử (có {counts}) — blazepose_wrapper.cpp chọn đầu ra theo số phần tử nên sẽ không chạy được')
    t = MNN.Tensor((1, 256, 256, 3), MNN.Halide_Type_Float, np.full((1, 256, 256, 3), 0.5, np.float32), MNN.Tensor_DimensionType_Tensorflow)
    inp.copyFrom(t); net.runSession(sess)
    print(f'blazepose_{name}.mnn: {os.path.getsize(mnn) / 1e6:.2f} MB, kiểm hình dạng và chạy thử OK (đầu ra {counts[:3]}…)')
print('XONG. Chép blazepose_lite.mnn (và tuỳ chọn blazepose_full.mnn) vào thư mục model của app (cùng chỗ yolov8_pose.mnn).')
