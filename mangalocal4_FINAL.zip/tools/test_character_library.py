#!/usr/bin/env python3
"""mục 248 — kiểm thử CharacterLibrary (thư viện nhân vật toàn cục).

Chạy thật: slug bỏ dấu tiếng Việt, tên thư mục/nhân vật không trùng, MÔ PHỎNG xuất/nhập bằng thư mục + JSON + sao chép
file thật (logic chép từ Kotlin), chặn xoá ngoài thư viện. KHÔNG chạy được Kotlin/Gson/Android thật (CHƯA build-test).
"""
import json, os, re, shutil, sys, tempfile, unicodedata, uuid

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
KB = os.path.join(ROOT, 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(KB, *p), encoding='utf8').read()
KT = rd('pipeline', 'CharacterLibrary.kt')

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

# ---------------- bản chép ----------------
def slug(name):
    d = unicodedata.normalize('NFD', name.strip().replace('đ', 'd').replace('Đ', 'D'))
    d = ''.join(c for c in d if unicodedata.category(c) != 'Mn')
    s = re.sub(r'[^a-z0-9]+', '_', d.lower()).strip('_')[:40].strip('_')
    return s or 'nhan_vat'

def unique_dir(name, existing):
    base = slug(name)
    if base not in existing: return base
    n = 2
    while '%s_%d' % (base, n) in existing: n += 1
    return '%s_%d' % (base, n)

def unique_name(name, existing):
    taken = {e.strip().lower() for e in existing}
    base = name.strip() or 'Nhân vật'
    if base.lower() not in taken: return base
    n = 2
    while ('%s (%d)' % (base, n)).lower() in taken: n += 1
    return '%s (%d)' % (base, n)

def safe_key(k): return re.sub(r'[^a-z0-9]+', '_', k.lower()).strip('_') or 'x'
def ext(p):
    e = os.path.splitext(p)[1][1:].lower()
    return e if e in ('png', 'jpg', 'jpeg', 'webp') else 'png'

def export(lib, c):
    os.makedirs(lib, exist_ok=True)
    d = unique_dir(c['name'], set(os.listdir(lib)))
    dd = os.path.join(lib, d); os.makedirs(dd)
    def copy_in(src, dest):
        if not src or not os.path.isfile(src): return None
        shutil.copyfile(src, os.path.join(dd, dest)); return dest
    anchor = copy_in(c.get('anchor'), 'anchor.' + ext(c['anchor'])) if c.get('anchor') else None
    torn = copy_in(c.get('torn'), 'torn.' + ext(c['torn'])) if c.get('torn') else None
    expr = {}
    for k, v in (c.get('expr') or {}).items():
        r = copy_in(v, 'expr_%s.%s' % (safe_key(k), ext(v)))
        if r: expr[k] = r
    st = dict(schema=1, name=c['name'], anchorPrompt=c['prompt'], seed=c['seed'], role=c.get('role', 'MAIN'), loraPath=c.get('lora'),
              anchorFile=anchor, tornFile=torn, expressionFiles=expr)
    json.dump(st, open(os.path.join(dd, 'character.json'), 'w', encoding='utf8'), ensure_ascii=False)
    return d

def import_from(lib, d, existing_names, anchors):
    dd = os.path.join(lib, d); f = os.path.join(dd, 'character.json')
    if not os.path.isfile(f): return None
    try: s = json.load(open(f, encoding='utf8'))
    except Exception: return None
    if not s.get('name', '').strip(): return None
    cid = str(uuid.uuid4()); os.makedirs(anchors, exist_ok=True)
    def copy_out(rel, tag):
        if not rel: return None
        src = os.path.join(dd, rel)
        if not os.path.isfile(src): return None
        dst = os.path.join(anchors, '%s_%s.%s' % (cid, tag, ext(rel))); shutil.copyfile(src, dst); return dst
    expr = {}
    for k, rel in (s.get('expressionFiles') or {}).items():
        r = copy_out(rel, 'expr_' + safe_key(k))
        if r: expr[k] = r
    role = s.get('role') if s.get('role') in ('MAIN', 'SUPPORTING', 'ONETIME') else 'MAIN'
    lora = s.get('loraPath') if s.get('loraPath') and os.path.isfile(s['loraPath']) else None
    return dict(id=cid, name=unique_name(s['name'], existing_names), prompt=s['anchorPrompt'], seed=s['seed'], role=role, lora=lora,
                anchor=copy_out(s.get('anchorFile'), 'anchor'), torn=copy_out(s.get('tornFile'), 'torn'), expr=expr or None)

def delete(lib, d):
    p = os.path.join(lib, d)
    if os.path.realpath(os.path.dirname(p)) != os.path.realpath(lib) or not os.path.isdir(p): return False
    shutil.rmtree(p); return True

# ---------------- slug / tên ----------------
check('slug bỏ dấu tiếng Việt, đ/Đ -> d', slug('Nguyễn Đức Anh') == 'nguyen_duc_anh' and slug('Đặng Thị Hoà') == 'dang_thi_hoa')
check('slug: ký tự lạ -> _, rút gọn, không bắt đầu/kết thúc bằng _', slug('  ***An--Bình!!  ') == 'an_binh')
check('slug: rỗng/toàn ký tự lạ -> "nhan_vat"; chữ Hán/Emoji không làm lỗi', slug('') == 'nhan_vat' and slug('😀😀') == 'nhan_vat' and slug('王小明') == 'nhan_vat')
check('slug dài bị cắt ≤ 40 và không kết thúc bằng _', len(slug('a' * 39 + ' ' + 'b' * 30)) <= 40 and not slug('a' * 39 + ' ' + 'b' * 30).endswith('_'))
check('thư mục không trùng: an, an_2, an_3', unique_dir('An', set()) == 'an' and unique_dir('An', {'an'}) == 'an_2' and unique_dir('An', {'an', 'an_2'}) == 'an_3')
check('hai tên khác nhau cùng slug (Bình / Binh) vẫn ra thư mục khác nhau', unique_dir('Binh', {slug('Bình')}) == 'binh_2')
check('tên nhân vật không trùng, không phân biệt hoa/thường: An -> An (2) -> An (3)', unique_name('An', {'an'}) == 'An (2)' and unique_name('An', {'An', 'an (2)'}) == 'An (3)' and unique_name('Lan', {'An'}) == 'Lan')
check('tên rỗng -> "Nhân vật"', unique_name('   ', set()) == 'Nhân vật')
check('khoá biểu cảm -> an toàn cho tên file', safe_key('Mắt Cười!') == 'm_t_c_i' or safe_key('Mắt Cười!').replace('_', '') != '' and '/' not in safe_key('a/b..c'))
check('phần mở rộng lạ -> png', ext('x.bmp') == 'png' and ext('a.JPG') == 'jpg' and ext('noext') == 'png')

# ---------------- mô phỏng xuất/nhập trên thư mục thật ----------------
tmp = tempfile.mkdtemp()
try:
    lib = os.path.join(tmp, 'character_library'); story_a = os.path.join(tmp, 'a_anchors'); story_b = os.path.join(tmp, 'b_anchors')
    os.makedirs(story_a)
    def mk(path, data=b'img'):
        open(path, 'wb').write(data); return path
    anchor = mk(os.path.join(story_a, 'raw.jpg'), b'ANCHOR'); torn = mk(os.path.join(story_a, 't.png'), b'TORN')
    e1 = mk(os.path.join(story_a, 'smile.png'), b'SMILE'); lora = mk(os.path.join(tmp, 'an.safetensors'), b'L')
    ch = dict(name='An', prompt='young woman', seed=4242, role='SUPPORTING', anchor=anchor, torn=torn, expr={'smile': e1, 'ghost': os.path.join(tmp, 'missing.png')}, lora=lora)
    d = export(lib, ch)
    check('xuất: tạo thư mục + character.json + ảnh sao chép (không tham chiếu)', d == 'an' and os.path.isfile(os.path.join(lib, 'an', 'character.json')) and os.path.isfile(os.path.join(lib, 'an', 'anchor.jpg')))
    st = json.load(open(os.path.join(lib, 'an', 'character.json'), encoding='utf8'))
    check('xuất: bỏ ảnh biểu cảm không tồn tại, giữ ảnh có thật', st['expressionFiles'] == {'smile': 'expr_smile.png'})
    check('xuất: KHÔNG ghi id của truyện gốc', 'id' not in st)
    os.remove(anchor); os.remove(torn)   # xoá truyện gốc -> mục thư viện vẫn còn đủ
    d2 = export(lib, dict(name='An', prompt='another', seed=1))
    check('xuất 2 nhân vật cùng tên -> thư mục an_2, mục đầu không bị ghi đè', d2 == 'an_2' and json.load(open(os.path.join(lib, 'an', 'character.json'), encoding='utf8'))['anchorPrompt'] == 'young woman')
    imp = import_from(lib, 'an', {'Bình'}, story_b)
    check('nhập: id MỚI, giữ prompt/seed/vai trò', imp and imp['id'] and imp['prompt'] == 'young woman' and imp['seed'] == 4242 and imp['role'] == 'SUPPORTING')
    check('nhập: ảnh được chép vào thư mục anchor của truyện mới, nội dung nguyên vẹn dù truyện gốc đã xoá', open(imp['anchor'], 'rb').read() == b'ANCHOR' and open(imp['torn'], 'rb').read() == b'TORN' and open(imp['expr']['smile'], 'rb').read() == b'SMILE')
    check('nhập: tên file mang id mới (không ghi đè anchor truyện khác)', os.path.basename(imp['anchor']).startswith(imp['id']))
    imp2 = import_from(lib, 'an', {'An'}, story_b)
    check('nhập vào truyện đã có "An" -> tên "An (2)", id khác lần trước, file không đè nhau', imp2['name'] == 'An (2)' and imp2['id'] != imp['id'] and imp2['anchor'] != imp['anchor'] and os.path.isfile(imp['anchor']))
    os.remove(lora)
    check('nhập: file LoRA không còn -> bỏ trường loraPath nhưng vẫn nhập phần còn lại', import_from(lib, 'an', set(), story_b)['lora'] is None)
    json.dump({'name': '', 'anchorPrompt': 'x', 'seed': 1}, open(os.path.join(lib, 'an_2', 'character.json'), 'w'))
    check('nhập: JSON thiếu tên -> null; thư mục không có json -> null', import_from(lib, 'an_2', set(), story_b) is None and import_from(lib, 'khong_co', set(), story_b) is None)
    open(os.path.join(lib, 'an_2', 'character.json'), 'w').write('{hỏng')
    check('nhập: JSON hỏng -> null, không ném lỗi', import_from(lib, 'an_2', set(), story_b) is None)
    st2 = json.load(open(os.path.join(lib, 'an', 'character.json'), encoding='utf8')); st2['role'] = 'KHONG_CO'; json.dump(st2, open(os.path.join(lib, 'an', 'character.json'), 'w', encoding='utf8'), ensure_ascii=False)
    check('nhập: vai trò lạ -> MAIN', import_from(lib, 'an', set(), story_b)['role'] == 'MAIN')
    check('xoá: chặn tên chứa ../ (không xoá ra ngoài thư viện)', delete(lib, '../a_anchors') is False and os.path.isdir(story_a) and delete(lib, 'an_2') is True and not os.path.exists(os.path.join(lib, 'an_2')))
finally:
    shutil.rmtree(tmp, ignore_errors=True)

# ---------------- đối chiếu nguồn Kotlin + nối dây ----------------
MD, VM, UI = rd('model', 'Models.kt'), rd('ui', 'MainViewModel.kt'), rd('ui', 'CharactersScreen.kt')
check('Kotlin: slug khớp bản chép (đ→d, NFD, bỏ \\p{Mn}, [^a-z0-9]+, cắt 40, nhan_vat)',
      "replace('đ', 'd').replace('Đ', 'D')" in KT and 'Normalizer.Form.NFD' in KT and '\\\\p{Mn}+' in KT and 'take(40).trim' in KT and '"nhan_vat"' in KT)
check('Kotlin: tên không trùng khớp bản chép', '"${base}_$n" in existing' in KT and '"$base ($n)".lowercase() in taken' in KT)
check('Kotlin: nhập tạo id MỚI và sao chép ảnh vào thư mục anchor truyện đích kèm id', 'UUID.randomUUID().toString()' in KT and '"${id}_$tag.${ext(rel)}"' in KT and 'src.copyTo(dst, overwrite = true)' in KT)
check('Kotlin: không lưu id gốc và không lưu phiên bản anchor theo chương', 'val id' not in KT.split('private class Stored(')[1].split(')')[0] and 'anchorVersions' not in KT.split('object CharacterLibrary')[1])
check('Kotlin: bỏ LoRA/embedding không còn tồn tại; vai trò lạ -> MAIN', 'takeIf { File(it).isFile }' in KT and 'getOrDefault(CharacterRole.MAIN)' in KT)
check('Kotlin: xoá chỉ trong thư viện (canonicalPath cha == thư viện)', 'd.parentFile?.canonicalPath == libDir.canonicalPath' in KT)
check('Kotlin: ghi/đọc lỗi KHÔNG ném lỗi (export/read bắt Exception)', KT.count('catch (e: Exception)') >= 2)
check('Kotlin: dùng đúng các trường của Character (tránh lỗi biên dịch do sai tên)',
      all(re.search(r'val %s\b' % f, MD) for f in ['tornAnchorImagePath', 'expressionAnchors', 'embeddingPath', 'embeddingTrigger', 'boneProportions', 'loraWeight', 'anchorImagePath']))
check('nối dây: ViewModel có đủ 4 hàm và dùng anchorsDir của truyện đích', all(x in VM for x in ['fun libraryEntries()', 'fun saveCharacterToLibrary(', 'fun importCharacterFromLibrary(', 'fun deleteLibraryEntry(']) and 'storyManager.anchorsDir(story.id)' in VM)
check('nối dây: nhập xong lưu nhân vật + làm mới truyện', 'storyManager.saveCharacter(story.id, ch)\n        refreshCurrentStory()' in VM)
check('nối dây: màn hình Nhân vật có nút mở thư viện và hộp thoại', 'showLibrary = true' in UI and 'CharacterLibraryDialog(chars = chars, vm = vm' in UI and 'private fun CharacterLibraryDialog' in UI)

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
