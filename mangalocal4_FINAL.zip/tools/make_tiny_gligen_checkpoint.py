#!/usr/bin/env python3
"""mục 288 — dựng checkpoint GLIGEN CỠ NHỎ, trọng số NGẪU NHIÊN (4,1 M tham số, kiến trúc đúng: attention_type="gated", cross_attention_dim=768 => positive_len=768,
tokenizer CLIP tối thiểu tự dựng) để chạy được tools/export_gligen_unet.py khi KHÔNG có mạng HuggingFace. Chỉ để kiểm đường xuất ONNX/MNN, KHÔNG sinh được ảnh có nghĩa.
Dùng:  python tools/make_tiny_gligen_checkpoint.py ./tiny_gligen
       python tools/export_gligen_unet.py --checkpoint ./tiny_gligen --image_size 64 --max_objs 4 --device cpu --output_dir ./out
Cần: torch, diffusers==0.30.3, transformers==4.44.2."""
import json, os, sys, torch, warnings; warnings.filterwarnings('ignore')
from diffusers import AutoencoderKL, UNet2DConditionModel, PNDMScheduler, StableDiffusionGLIGENPipeline
from transformers import CLIPTextConfig, CLIPTextModel, CLIPTokenizer
out=sys.argv[1]; os.makedirs(out+'/tokenizer',exist_ok=True); torch.manual_seed(0)
# tokenizer CLIP tối thiểu: 256 ký tự byte-level (+</w>) + 2 token đặc biệt, không merge
def b2u():
    bs=list(range(33,127))+list(range(161,173))+list(range(174,256)); cs=bs[:]; n=0
    for b in range(256):
        if b not in bs: bs.append(b); cs.append(256+n); n+=1
    return dict(zip(bs,[chr(c) for c in cs]))
chars=list(b2u().values()); vocab={}
for c in chars: vocab[c]=len(vocab)
for c in chars: vocab[c+'</w>']=len(vocab)
vocab['<|startoftext|>']=len(vocab); vocab['<|endoftext|>']=len(vocab)
json.dump(vocab,open(out+'/tokenizer/vocab.json','w')); open(out+'/tokenizer/merges.txt','w').write('#version: 0.2\n')
tok=CLIPTokenizer(out+'/tokenizer/vocab.json',out+'/tokenizer/merges.txt'); tok.save_pretrained(out+'/tokenizer')
te=CLIPTextModel(CLIPTextConfig(vocab_size=len(vocab),hidden_size=768,intermediate_size=64,num_hidden_layers=1,num_attention_heads=12,max_position_embeddings=77,projection_dim=768,bos_token_id=len(vocab)-2,eos_token_id=len(vocab)-1))
vae=AutoencoderKL(in_channels=3,out_channels=3,down_block_types=('DownEncoderBlock2D',)*2,up_block_types=('UpDecoderBlock2D',)*2,block_out_channels=(16,32),latent_channels=4,norm_num_groups=8,sample_size=32)
unet=UNet2DConditionModel(sample_size=8,in_channels=4,out_channels=4,down_block_types=('CrossAttnDownBlock2D','CrossAttnDownBlock2D','CrossAttnDownBlock2D','DownBlock2D'),up_block_types=('UpBlock2D','CrossAttnUpBlock2D','CrossAttnUpBlock2D','CrossAttnUpBlock2D'),block_out_channels=(32,32,64,64),layers_per_block=1,cross_attention_dim=768,attention_head_dim=8,norm_num_groups=8,attention_type='gated')
pipe=StableDiffusionGLIGENPipeline(vae=vae,text_encoder=te,tokenizer=tok,unet=unet,scheduler=PNDMScheduler(),safety_checker=None,feature_extractor=None,requires_safety_checker=False)
pipe.save_pretrained(out); print('tiny GLIGEN saved; unet params %.1fM'%(sum(p.numel() for p in unet.parameters())/1e6), 'has position_net', hasattr(unet,'position_net'))
