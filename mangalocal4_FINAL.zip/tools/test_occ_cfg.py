#!/usr/bin/env python3
"""mục 261 — kiểm thử `sd_engine/OccCfg.hpp` (OccCFG, PersonaCraft Eq.4) bằng C++ THẬT.

Biên dịch chương trình thử với g++ (-Wall -Wextra -Werror, ASan+UBSan), so TỪNG PHẦN TỬ với bản tham chiếu numpy viết độc lập từ công thức
    eps = uncond + (k_occ*M + k_base*(1-M)) * (cond - uncond)
(đọc toàn văn bài). Kiểm: M=0 trùng CFG thường, M=1 trùng CFG k_occ, nội suy tuyến tính, NaN/ngoài [0,1], đổi kích thước bản đồ, trạng thái
toàn cục (đặt/xoá/dữ liệu hỏng), nối dây vào Pipeline.hpp/JNI/Kotlin, và THỬ PHÁ MÃ (đột biến phải bị bắt).
KHÔNG chứng minh: ảnh có đẹp hơn không (chưa chạy model thật) — chỉ chứng minh phép tính đúng như định nghĩa.
"""
import os, re, struct, subprocess, sys, tempfile, shutil
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JNI = os.path.join(ROOT, 'app/src/main/jni')
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
ok = True
def check(name, cond, detail=''):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + detail) if (detail and not cond) else ''))
    ok &= bool(cond)

TEST_CPP = r'''
#include "OccCfg.hpp"
#include <cstdio>
#include <cstdlib>
#include <string>
// cmd=combine: in = int32 C, int32 hw, float base, float kocc, int32 hasmap, U(C*hw), T(C*hw), [map(hw)]  -> out C*hw
// cmd=resize : in = int32 w0,h0,w1,h1, src(w0*h0) -> out w1*h1
// cmd=state  : in = int32 w,h,lw,lh, float boost, int32 setfirst(1/0), map(w*h)  -> out: [active(float), boost, n, field...]
int main(int argc, char **argv) {
  if (argc < 4) return 2;
  std::string cmd = argv[1];
  FILE *f = std::fopen(argv[2], "rb"); if (!f) return 3;
  std::vector<float> out;
  if (cmd == "combine") {
    int C = 0, hw = 0, hasmap = 0; float base = 0, kocc = 0;
    if (std::fread(&C, 4, 1, f) != 1 || std::fread(&hw, 4, 1, f) != 1 || std::fread(&base, 4, 1, f) != 1 ||
        std::fread(&kocc, 4, 1, f) != 1 || std::fread(&hasmap, 4, 1, f) != 1) return 4;
    std::vector<float> U((size_t)C * hw), T((size_t)C * hw), M(hw), O((size_t)C * hw);
    if (std::fread(U.data(), 4, U.size(), f) != U.size() || std::fread(T.data(), 4, T.size(), f) != T.size()) return 5;
    if (hasmap && std::fread(M.data(), 4, M.size(), f) != M.size()) return 5;
    occ_cfg::combine(U.data(), T.data(), hasmap ? M.data() : nullptr, C, (size_t)hw, base, kocc, O.data());
    out = O;
  } else if (cmd == "resize") {
    int w0, h0, w1, h1;
    if (std::fread(&w0, 4, 1, f) != 1 || std::fread(&h0, 4, 1, f) != 1 || std::fread(&w1, 4, 1, f) != 1 || std::fread(&h1, 4, 1, f) != 1) return 4;
    std::vector<float> src((size_t)w0 * h0);
    if (!src.empty() && std::fread(src.data(), 4, src.size(), f) != src.size()) return 5;
    out = occ_cfg::resizeBilinear(src, w0, h0, w1, h1);
  } else if (cmd == "state") {
    int w, h, lw, lh, setfirst;
    float boost;
    if (std::fread(&w, 4, 1, f) != 1 || std::fread(&h, 4, 1, f) != 1 || std::fread(&lw, 4, 1, f) != 1 || std::fread(&lh, 4, 1, f) != 1 ||
        std::fread(&boost, 4, 1, f) != 1 || std::fread(&setfirst, 4, 1, f) != 1) return 4;
    std::vector<float> m((size_t)std::max(w, 0) * std::max(h, 0));
    if (setfirst && !m.empty() && std::fread(m.data(), 4, m.size(), f) != m.size()) return 5;
    if (setfirst) occCfgSet(m.empty() ? nullptr : m.data(), w, h, boost);
    std::vector<float> field; float b = 0;
    bool act = occ_cfg::fieldFor(lw, lh, field, b);
    out.push_back(act ? 1.0f : 0.0f); out.push_back(b); out.push_back((float)field.size());
    for (float v : field) out.push_back(v);
    std::vector<float> f1; float b1 = 0;
    out.push_back(occ_cfg::fieldFor(lw, lh, f1, b1) ? 1.0f : 0.0f);  // lần 2 sau khi đã tiêu thụ: phải 0 (áp đúng MỘT lượt)
    occCfgClear();
    std::vector<float> f2; float b2 = 0;
    out.push_back(occ_cfg::fieldFor(lw, lh, f2, b2) ? 1.0f : 0.0f);  // sau clear phải 0
  }
  else if (cmd == "reset") {
    int w, h, lw, lh;
    float boost;
    if (std::fread(&w, 4, 1, f) != 1 || std::fread(&h, 4, 1, f) != 1 || std::fread(&lw, 4, 1, f) != 1 || std::fread(&lh, 4, 1, f) != 1 ||
        std::fread(&boost, 4, 1, f) != 1) return 4;
    std::vector<float> m((size_t)w * h);
    if (std::fread(m.data(), 4, m.size(), f) != m.size()) return 5;
    occCfgSet(m.data(), w, h, boost);                       // hợp lệ
    std::vector<float> fl; float b = 0;
    out.push_back(occ_cfg::fieldFor(lw, lh, fl, b) ? 1.0f : 0.0f);   // phải 1
    occCfgSet(nullptr, 0, 0, boost);                        // dữ liệu hỏng
    out.push_back(occ_cfg::fieldFor(lw, lh, fl, b) ? 1.0f : 0.0f);   // phải 0 (không giữ bản đồ cũ)
    occCfgSet(m.data(), w, h, boost);
    occCfgSet(m.data(), 1 << 20, 1 << 20, boost);           // quá lớn
    out.push_back(occ_cfg::fieldFor(lw, lh, fl, b) ? 1.0f : 0.0f);   // phải 0
  }
  std::fclose(f);
  FILE *g = std::fopen(argv[3], "wb"); if (!g) return 6;
  if (!out.empty()) std::fwrite(out.data(), 4, out.size(), g);
  std::fclose(g);
  return 0;
}
'''

def build(header_dir, tmp, tag):
    src = os.path.join(tmp, f'occ_{tag}.cpp'); exe = os.path.join(tmp, f'occ_{tag}')
    open(src, 'w').write(TEST_CPP)
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-g', '-Wall', '-Wextra', '-Werror', '-fsanitize=address,undefined',
                        '-fno-sanitize-recover=undefined', '-I', header_dir, src, '-o', exe], capture_output=True, text=True)
    return exe, r

def run(exe, tmp, cmd, payload):
    fi = os.path.join(tmp, 'in.bin'); fo = os.path.join(tmp, 'out.bin')
    open(fi, 'wb').write(payload)
    r = subprocess.run([exe, cmd, fi, fo], capture_output=True, text=True)
    if r.returncode != 0:
        return None, r
    return np.fromfile(fo, dtype=np.float32), r

def pk(*a):
    out = b''
    for x in a:
        out += struct.pack('<i', x) if isinstance(x, (int, np.integer)) else struct.pack('<f', x)
    return out

def ref_combine(U, T, M, base, kocc):
    m = np.clip(np.nan_to_num(M, nan=0.0), 0, 1) if M is not None else 0.0
    k = base * (1 - m) + kocc * m
    return U + k * (T - U)

def ref_resize(src, w0, h0, w1, h1):
    src = np.clip(np.nan_to_num(src, nan=0.0), 0, 1).reshape(h0, w0).astype(np.float64)
    out = np.zeros((h1, w1))
    for y in range(h1):
        fy = (y + 0.5) * h0 / h1 - 0.5
        y0 = int(np.floor(fy)); ty = fy - y0
        ya, yb = min(max(y0, 0), h0 - 1), min(max(y0 + 1, 0), h0 - 1)
        for x in range(w1):
            fx = (x + 0.5) * w0 / w1 - 0.5
            x0 = int(np.floor(fx)); tx = fx - x0
            xa, xb = min(max(x0, 0), w0 - 1), min(max(x0 + 1, 0), w0 - 1)
            top = src[ya, xa] + (src[ya, xb] - src[ya, xa]) * tx
            bot = src[yb, xa] + (src[yb, xb] - src[yb, xa]) * tx
            out[y, x] = top + (bot - top) * ty
    return np.clip(out, 0, 1).astype(np.float32).ravel()

def suite(exe, tmp, quiet=False):
    """trả về số lỗi phát hiện (dùng cho cả bản thật lẫn đột biến)"""
    bad = 0
    rng = np.random.default_rng(261)
    def chk(name, cond, detail=''):
        nonlocal bad
        if not cond: bad += 1
        if not quiet: check(name, cond, detail)
    # combine ngẫu nhiên
    worst = 0.0
    for case in range(30):
        C = int(rng.integers(1, 5)); hw = int(rng.integers(1, 300))
        base = float(rng.uniform(1, 12)); kocc = float(rng.uniform(base, base * 2.2))
        U = rng.normal(size=C * hw).astype(np.float32); T = rng.normal(size=C * hw).astype(np.float32)
        M = rng.uniform(-0.3, 1.3, size=hw).astype(np.float32)
        o, r = run(exe, tmp, 'combine', pk(C, hw, base, kocc, 1) + U.tobytes() + T.tobytes() + M.tobytes())
        if o is None: chk(f'combine chạy được (ca {case})', False, r.stderr[-300:]); continue
        ref = ref_combine(U.reshape(C, hw), T.reshape(C, hw), M[None, :], base, kocc).ravel()
        worst = max(worst, float(np.max(np.abs(o - ref))))
    chk('combine khớp numpy 30 ca ngẫu nhiên (M ngoài [0,1] được kẹp)', worst < 1e-4, f'sai lệch lớn nhất {worst}')
    # M = 0 => CFG thường; M = 1 => CFG k_occ
    C, hw = 4, 64
    U = rng.normal(size=C * hw).astype(np.float32); T = rng.normal(size=C * hw).astype(np.float32)
    o0, _ = run(exe, tmp, 'combine', pk(C, hw, 7.5, 11.0, 1) + U.tobytes() + T.tobytes() + np.zeros(hw, np.float32).tobytes())
    chk('M=0 trùng CFG thường uncond+base*(txt-uncond)', o0 is not None and np.allclose(o0, U + 7.5 * (T - U), atol=1e-4))
    o1, _ = run(exe, tmp, 'combine', pk(C, hw, 7.5, 11.0, 1) + U.tobytes() + T.tobytes() + np.ones(hw, np.float32).tobytes())
    chk('M=1 trùng CFG k_occ', o1 is not None and np.allclose(o1, U + 11.0 * (T - U), atol=1e-4))
    om, _ = run(exe, tmp, 'combine', pk(C, hw, 7.5, 11.0, 1) + U.tobytes() + T.tobytes() + np.full(hw, 0.5, np.float32).tobytes())
    chk('M=0.5 nằm đúng giữa (k = 9.25)', om is not None and np.allclose(om, U + 9.25 * (T - U), atol=1e-4))
    on, _ = run(exe, tmp, 'combine', pk(C, hw, 7.5, 11.0, 0) + U.tobytes() + T.tobytes())
    chk('không có bản đồ -> CFG thường (an toàn)', on is not None and np.allclose(on, U + 7.5 * (T - U), atol=1e-4))
    # NaN trong bản đồ không làm hỏng đầu ra
    Mn = np.full(hw, np.nan, np.float32)
    ox, _ = run(exe, tmp, 'combine', pk(C, hw, 7.5, 11.0, 1) + U.tobytes() + T.tobytes() + Mn.tobytes())
    chk('M=NaN coi như 0 (đầu ra hữu hạn, = CFG thường)', ox is not None and np.all(np.isfinite(ox)) and np.allclose(ox, U + 7.5 * (T - U), atol=1e-4))
    # tính chất: vùng M=0 không đổi dù k_occ đổi (đây là mục đích của OccCFG: không làm bão hoà vùng ngoài)
    Mh = np.zeros(hw, np.float32); Mh[: hw // 2] = 1.0
    oa, _ = run(exe, tmp, 'combine', pk(C, hw, 7.5, 9.0, 1) + U.tobytes() + T.tobytes() + Mh.tobytes())
    ob, _ = run(exe, tmp, 'combine', pk(C, hw, 7.5, 14.0, 1) + U.tobytes() + T.tobytes() + Mh.tobytes())
    if oa is not None and ob is not None:
        A = oa.reshape(C, hw); B = ob.reshape(C, hw)
        chk('vùng M=0 KHÔNG phụ thuộc k_occ', np.allclose(A[:, hw // 2:], B[:, hw // 2:], atol=1e-6))
        chk('vùng M=1 có phụ thuộc k_occ', not np.allclose(A[:, : hw // 2], B[:, : hw // 2], atol=1e-3))
    else:
        chk('combine nửa/nửa chạy được', False)
    # resize
    worst = 0.0
    for (w0, h0, w1, h1) in [(64, 64, 64, 64), (8, 8, 16, 16), (16, 16, 8, 8), (7, 5, 13, 11), (64, 48, 96, 72), (1, 1, 5, 5), (5, 1, 3, 3)]:
        src = rng.uniform(-0.2, 1.2, size=w0 * h0).astype(np.float32)
        o, r = run(exe, tmp, 'resize', pk(w0, h0, w1, h1) + src.tobytes())
        if o is None: chk(f'resize {w0}x{h0}->{w1}x{h1} chạy được', False, r.stderr[-200:]); continue
        worst = max(worst, float(np.max(np.abs(o - ref_resize(src, w0, h0, w1, h1)))))
    chk('resize song tuyến khớp numpy 7 cấu hình (kể cả 1 điểm, 1 hàng)', worst < 1e-5, f'sai lệch {worst}')
    const = np.full(9 * 7, 0.37, np.float32)
    o, _ = run(exe, tmp, 'resize', pk(9, 7, 20, 13) + const.tobytes())
    chk('bản đồ hằng số giữ nguyên giá trị sau resize', o is not None and np.allclose(o, 0.37, atol=1e-6))
    o, _ = run(exe, tmp, 'resize', pk(0, 7, 4, 4))
    chk('kích thước 0 -> rỗng, không sập', o is not None and o.size == 0)
    o, _ = run(exe, tmp, 'resize', pk(3, 3, 4, 4) + np.zeros(5, np.float32).tobytes()[:0])
    # (payload thiếu dữ liệu: harness trả mã lỗi 5, không phải lỗi của header — bỏ qua)
    # trạng thái toàn cục
    m = rng.uniform(0, 1, size=16 * 16).astype(np.float32)
    o, r = run(exe, tmp, 'state', pk(16, 16, 16, 16, 1.5, 1) + m.tobytes())
    ok_state = o is not None and o[0] == 1.0 and abs(o[1] - 1.5) < 1e-6 and int(o[2]) == 256 and np.allclose(o[3:3 + 256], m, atol=1e-6) and o[3 + 256] == 0.0 and o[4 + 256] == 0.0
    chk('đặt -> lấy đúng bản đồ + boost; lấy lần 2 = tắt (áp đúng MỘT lượt); xoá -> tắt', ok_state)
    o, _ = run(exe, tmp, 'state', pk(16, 16, 16, 16, 9.0, 1) + m.tobytes())
    chk('boost > 2.5 bị kẹp về 2.5', o is not None and abs(o[1] - 2.5) < 1e-6)
    o, _ = run(exe, tmp, 'state', pk(16, 16, 16, 16, 0.2, 1) + m.tobytes())
    chk('boost < 1 bị kẹp về 1 (không bao giờ GIẢM CFG ở vùng chạm)', o is not None and abs(o[1] - 1.0) < 1e-6)
    o, _ = run(exe, tmp, 'state', pk(16, 16, 16, 16, float('nan'), 1) + m.tobytes())
    chk('boost NaN -> 1', o is not None and abs(o[1] - 1.0) < 1e-6)
    o, _ = run(exe, tmp, 'state', pk(0, 0, 8, 8, 1.4, 1))
    chk('bản đồ rỗng/kích thước 0 -> không bật', o is not None and o[0] == 0.0)
    o, _ = run(exe, tmp, 'state', pk(16, 16, 8, 8, 1.4, 1) + m.tobytes())
    chk('latent khác kích thước bản đồ -> tự resize về latent', o is not None and o[0] == 1.0 and int(o[2]) == 64)
    o, _ = run(exe, tmp, 'state', pk(16, 16, 8, 8, 1.4, 0))
    chk('chưa đặt gì -> tắt', o is not None and o[0] == 0.0)
    o, _ = run(exe, tmp, 'reset', pk(16, 16, 8, 8, 1.4) + m.tobytes())
    chk('đặt hợp lệ rồi đặt dữ liệu hỏng/quá lớn -> tắt hẳn, không giữ bản đồ cũ', o is not None and list(o) == [1.0, 0.0, 0.0])
    return bad

tmp = tempfile.mkdtemp()
HDR = os.path.join(JNI, 'sd_engine')
exe, r = build(HDR, tmp, 'real')
check('OccCfg.hpp biên dịch sạch (-Wall -Wextra -Werror, ASan+UBSan)', r.returncode == 0, r.stderr[-800:])
if r.returncode == 0:
    real_bad = suite(exe, tmp)
    check('bộ kiểm chạy trên header THẬT: 0 lỗi', real_bad == 0, str(real_bad))

    # ---- thử phá mã: mỗi đột biến PHẢI làm bộ kiểm thất bại ----
    src = open(os.path.join(HDR, 'OccCfg.hpp'), encoding='utf-8').read()
    mutants = [
        ('hoán base/k_occ', 'return base * (1.0f - mm) + k_occ * mm;', 'return base * mm + k_occ * (1.0f - mm);'),
        ('bỏ kẹp M', 'const float mm = clamp01(m);', 'const float mm = m;'),
        ('NaN không về 0', 'if (!(v == v)) return 0.0f;  // NaN -> 0', ''),
        ('đảo dấu (txt-uncond)', 'out[off + p] = uncond[off + p] + k * (txt[off + p] - uncond[off + p]);', 'out[off + p] = uncond[off + p] + k * (uncond[off + p] - txt[off + p]);'),
        ('bỏ kẹp boost dưới', 'return b < kMinBoost ? kMinBoost : (b > kMaxBoost ? kMaxBoost : b);', 'return b > kMaxBoost ? kMaxBoost : b;'),
        ('resize lệch nửa pixel', 'const float fy = ((float)y + 0.5f) * (float)h0 / (float)h1 - 0.5f;', 'const float fy = ((float)y) * (float)h0 / (float)h1;'),
        ('không tiêu thụ sau 1 lượt', 'if (consume) { g_occ_cfg.active = false; g_occ_cfg.map.clear(); }', 'if (consume) { (void)0; }'),
        ('bỏ chốt chặn kích thước quá lớn', '|| (long long)w * h > 4096LL * 4096LL)', ')'),
        ('map null vẫn nhân k_occ', 'const float k = map_hw ? scaleAt(base, k_occ, map_hw[p]) : base;', 'const float k = map_hw ? scaleAt(base, k_occ, map_hw[p]) : k_occ;'),
    ]
    caught = 0
    for name, old, new in mutants:
        if old not in src:
            check(f'đột biến "{name}": mẫu tìm thấy trong mã', False, 'mẫu không còn khớp — cập nhật test'); continue
        md = os.path.join(tmp, 'mut_' + re.sub(r'\W', '_', name)); os.makedirs(md, exist_ok=True)
        open(os.path.join(md, 'OccCfg.hpp'), 'w', encoding='utf-8').write(src.replace(old, new, 1))
        mexe, mr = build(md, tmp, 'mut_' + re.sub(r'\W', '_', name))
        if mr.returncode != 0:
            check(f'đột biến "{name}" phải BIÊN DỊCH được (nếu không thì "bị bắt" là vô nghĩa)', False, mr.stderr[-300:]); continue
        bad = suite(mexe, tmp, quiet=True)
        check(f'đột biến "{name}" bị bộ kiểm bắt', bad > 0)
        caught += bad > 0
    check(f'thử phá mã: {caught}/{len(mutants)} đột biến bị bắt', caught == len(mutants))

# ---- nối dây tĩnh ----
pl = open(os.path.join(JNI, 'sd_engine/Pipeline.hpp'), encoding='utf-8').read()
check('Pipeline.hpp include OccCfg.hpp', '#include "OccCfg.hpp"' in pl)
check('Pipeline.hpp gọi occ_cfg::fieldFor + occ_cfg::combine', 'occ_cfg::fieldFor(' in pl and 'occ_cfg::combine(' in pl)
check('không bỏ nhánh uncond khi OccCFG bật (skip_uncond && !occ_active)', re.search(r'skip_uncond\s*=\s*canSkipUncond\(\)\s*&&\s*\(req\.cfg == 1\.0f\)\s*&&\s*!occ_active', pl) is not None)
check('nhánh CFG thường vẫn còn (không đổi hành vi khi tắt)', 'noise_pred = xt::eval(uncond + req.cfg * (txt - uncond));' in pl)
check('OccCFG tắt khi ultrafix tiled', '!req.ultrafix && occ_cfg::fieldFor' in pl)
jn = open(os.path.join(JNI, 'mnn_diffusion_pipeline.cpp'), encoding='utf-8').read()
check('JNI setOccCfg/clearOccCfg tồn tại', 'NativeBridge_setOccCfg' in jn and 'NativeBridge_clearOccCfg' in jn)
check('JNI kiểm độ dài mảng trước khi dùng', 'GetArrayLength(jMap) != (jsize)((long long)w * h)' in jn)
nb = open(os.path.join(KT, 'pipeline/NativeBridge.kt'), encoding='utf-8').read()
check('Kotlin external setOccCfg/clearOccCfg khớp JNI', 'external fun setOccCfg(map: FloatArray, w: Int, h: Int, boost: Float)' in nb and 'external fun clearOccCfg()' in nb)

shutil.rmtree(tmp, ignore_errors=True)
print('ALL OK' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
