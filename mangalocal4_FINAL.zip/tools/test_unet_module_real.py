#!/usr/bin/env python3
"""mục 283 — CHẠY THẬT sd_engine/UnetModule.hpp (UnetModuleSet) trên MNN 3.6.1 THẬT (trước đây 270.4: chỉ MNN GIẢ + kiểm kiểu). Có cả lượt UNet w8 (định dạng thực tế của app) và phép đo RAM/kích thước khi LoRA chỉ phủ một phần conv.
Chuỗi thật: harness `gen` sinh UNet đồ chơi có ĐÚNG cổng SD1.5 (sample/timestep/encoder_hidden_states -> out_sample) -> tools/mnn_probe/lora_attach_branch
--strip-base-weights tạo 2 module *.lora.mnn -> harness `run` nạp UnetModuleSet THẬT và so từng biến thể / step() với đáp án CPU thuần (double, độc lập MNN).
Có phép PHÁ MÃ trên chính UnetModule.hpp (bỏ rearrange, bỏ base, đảo tên cổng, sai chỉ số biến thể…): bộ kiểm phải đỏ.
KHÔNG chứng minh: UNet SD thật (tên op thật; Linear -> Conv hay MatMul), w8, OpenCL/NPU, RAM ~1 GB thật, tốc độ trên máy thật.
Cần: g++, MNN nguồn 3.6.1 ($MNN_SRC, mặc định /home/claude/work/tp/MNN: có include/, schema/current, 3rd_party/flatbuffers) và gói pip MNN==3.6.1 (dùng _mnncengine*.so;
build ABI cũ ⇒ -D_GLIBCXX_USE_CXX11_ABI=0; cần LD_PRELOAD libpython). Thiếu → BỎ QUA (exit 0), nói rõ lý do.
"""
import glob, os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.environ.get('MNN_SRC', '/home/claude/work/tp/MNN')
def skip(why): print('BỎ QUA test thật:', why); sys.exit(0)
if not shutil.which('g++'): skip('không có g++')
for sub in ('include/MNN/expr/Module.hpp', 'schema/current/MNN_generated.h', '3rd_party/flatbuffers/include/flatbuffers/flatbuffers.h'):
    if not os.path.isfile(os.path.join(SRC, sub)): skip(f'thiếu {sub} trong MNN_SRC={SRC} (git clone --depth 1 --branch 3.6.1 https://github.com/alibaba/MNN)')
try:
    import MNN
except Exception:
    skip('chưa cài gói pip MNN==3.6.1')
so = glob.glob(os.path.join(os.path.dirname(os.path.dirname(MNN.__file__)), '_mnncengine*.so')) or glob.glob(os.path.join(os.path.dirname(MNN.__file__), '..', '_mnncengine*.so'))
lp = glob.glob('/usr/lib/x86_64-linux-gnu/libpython3*.so')
if not so or not lp: skip('không thấy _mnncengine*.so hoặc libpython (chỉ hỗ trợ Linux x86_64 với gói pip MNN)')
so, lp = so[0], lp[0]

fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)
tmp = tempfile.mkdtemp()
JNI = os.path.join(ROOT, 'app/src/main/jni'); HARN = os.path.join(ROOT, 'tools/mnn_probe/unet_module_real_check.cpp'); ATT = os.path.join(ROOT, 'tools/mnn_probe/lora_attach_branch.cpp')
env = dict(os.environ, LD_PRELOAD=lp)

def build_harness(exe, jni=JNI):
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-w', '-D_GLIBCXX_USE_CXX11_ABI=0', f'-I{SRC}/include', f'-I{jni}', HARN, '-o', exe, so, '-Wl,--allow-shlib-undefined',
                        '-Wl,-rpath,' + os.path.dirname(so), '-lpthread', '-ldl'], capture_output=True, text=True)
    return r.returncode == 0, r.stderr[-1200:]
def sh(args, timeout=240, cwd=None):
    r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, env=env, cwd=cwd or tmp)
    return r.returncode, r.stdout, r.stderr

ok1, e1 = build_harness(os.path.join(tmp, 'harness')); check(ok1, 'harness (UnetModule.hpp THẬT) biên dịch + liên kết với MNN 3.6.1 thật')
r = subprocess.run(['g++', '-std=c++17', '-O1', '-w', ATT, f'-I{SRC}/include', f'-I{SRC}/schema/current', f'-I{SRC}/3rd_party/flatbuffers/include', '-o', os.path.join(tmp, 'attach')], capture_output=True, text=True)
check(r.returncode == 0, 'lora_attach_branch biên dịch (schema + flatbuffers thật)')
if not ok1 or r.returncode != 0:
    print(e1, r.stderr[-800:]); print('CÓ LỖI'); sys.exit(1)
H, A = os.path.join(tmp, 'harness'), os.path.join(tmp, 'attach')

MNNCONVERT = shutil.which('mnnconvert') or '/usr/local/bin/mnnconvert'
def pipeline(harness, d, flag='--strip-all-conv-weights', w8=False, attach=None):
    """gen -> (w8: mnnconvert -f MNN --weightQuantBits 8) -> attach x2 (flag tước) + attach x2 ĐẦY ĐỦ (không tước, tham chiếu cùng lượng tử hoá) -> run; trả (rc, out)"""
    os.makedirs(d, exist_ok=True); AT = attach or A
    rc, out, err = sh([harness, 'gen', d]); 
    if rc != 0 or 'gen ok' not in out: return -1, 'gen lỗi: ' + out + err
    base = os.path.join(d, 'unet_base.mnn')
    if w8:
        shutil.copy(base, os.path.join(d, 'unet_base_f32.mnn'))
        rc, out, err = sh([MNNCONVERT, '-f', 'MNN', '--modelFile', os.path.join(d, 'unet_base_f32.mnn'), '--MNNModel', base, '--weightQuantBits', '8'])
        if rc != 0 or not os.path.exists(base): return -1, 'mnnconvert w8 lỗi: ' + out + err
    for i in (1, 2):
        rc, out, err = sh([AT, base, os.path.join(d, f'spec{i}.txt'), os.path.join(d, f'lora{i}.lora.mnn'), flag])
        if rc != 0: return -1, f'attach {i} lỗi: ' + out + err
        rc, out, err = sh([AT, base, os.path.join(d, f'spec{i}.txt'), os.path.join(d, f'lora{i}_full.mnn')])   # không tước: còn trọng số nền
        if rc != 0: return -1, f'attach đầy đủ {i} lỗi: ' + out + err
    e = dict(env); 
    if w8: e['UNET_TOL_ABS'] = '6.0'   # so với đáp án double: nhiễu lượng tử hoá 8-bit của mạng đồ chơi lớn; phép kiểm SẮC là "tước == đầy đủ cùng lượng tử hoá"
    r = subprocess.run([harness, 'run', d], capture_output=True, text=True, timeout=280, env=e)
    return r.returncode, r.stdout

# cờ CŨ (--strip-base-weights: chỉ tước conv CÓ nhánh) vẫn phải đúng; LoRA 2 của đồ chơi KHÔNG nhắm c_in nên c_in là conv không-nhánh
rc_old, out_old = pipeline(H, os.path.join(tmp, 'd_old'), '--strip-base-weights')
check(rc_old == 0 and 'FAIL ' not in out_old and len(re.findall(r'^PASS ', out_old, re.M)) >= 31, f'cờ cũ --strip-base-weights: {len(re.findall(r"^PASS ", out_old, re.M))} phép kiểm đạt (rc={rc_old})')
# cờ MỚI (mục 283): tước LUÔN conv không-nhánh — kết quả phải đúng như nhau
rc, out = pipeline(H, os.path.join(tmp, 'd0'))
npass = len(re.findall(r'^PASS ', out, re.M)); nfail = len(re.findall(r'^FAIL ', out, re.M))
for l in out.splitlines():
    if l.startswith('FAIL') or l.startswith('  [số đo]'): print(l)
check(rc == 0 and nfail == 0 and npass >= 31, f'UnetModuleSet THẬT trên MNN thật (cờ --strip-all-conv-weights): {npass} phép kiểm đạt, {nfail} lỗi (rc={rc})')
m = re.search(r'runOne\(0\): maxdiff=([0-9.e+-]+)', out)
check(bool(m) and float(m.group(1)) < 1e-4, f'sai lệch so với đáp án CPU thuần (double) < 1e-4: {m.group(1) if m else "?"}')
check(re.search(r'\[số đo\] không base: ', out) is not None, 'đối chứng "module LoRA không base" có số đo (chia sẻ trọng số là bắt buộc)')

# ── mục 283: UNet đã LƯỢNG TỬ HOÁ w8 (định dạng thực tế trong app): trọng số nằm trong quanParameter, bản công cụ trước bỏ sót nên module to bằng cả nền ──
rc8, out8 = pipeline(H, os.path.join(tmp, 'd_w8'), '--strip-all-conv-weights', w8=True)
np8 = len(re.findall(r'^PASS ', out8, re.M)); nf8 = len(re.findall(r'^FAIL ', out8, re.M))
for l in out8.splitlines():
    if l.startswith('FAIL') or 'tước + base so với' in l: print('  [w8]', l.strip())
check(rc8 == 0 and nf8 == 0 and np8 >= 32, f'UNet w8: UnetModuleSet THẬT: {np8} phép kiểm đạt, {nf8} lỗi (rc={rc8}) — gồm "module đã tước + base == tệp LoRA ĐẦY ĐỦ cùng lượng tử hoá (≤ 1e-4)"')
check('PASS module ĐÃ TƯỚC' in out8, 'w8: tước trọng số KHÔNG mất mát (so với tệp đầy đủ cùng lượng tử hoá)')
check('PASS module ĐÃ TƯỚC' in out, 'fp32: tước trọng số KHÔNG mất mát (so với tệp đầy đủ)')

# ── mục 283: ĐO RAM THẬT khi LoRA chỉ phủ MỘT PHẦN conv (tools/mnn_probe/lora_partial_memory.cpp) ──
PM = os.path.join(ROOT, 'tools/mnn_probe/lora_partial_memory.cpp'); pexe = os.path.join(tmp, 'pmem')
rp = subprocess.run(['g++', '-std=c++17', '-O1', '-w', '-D_GLIBCXX_USE_CXX11_ABI=0', f'-I{SRC}/include', PM, '-o', pexe, so, '-Wl,--allow-shlib-undefined', '-Wl,-rpath,' + os.path.dirname(so), '-lpthread', '-ldl'], capture_output=True, text=True)
check(rp.returncode == 0, 'lora_partial_memory.cpp biên dịch với MNN thật')
if rp.returncode == 0:
    pd = os.path.join(tmp, 'pm'); os.makedirs(pd)
    sh([pexe, 'gen', pd]); open(os.path.join(pd, 'spec.txt'), 'w').write(f'c0 4 1.0 {pd}/A.bin {pd}/B.bin\n')   # LoRA CHỈ nhắm c0 (3/4 conv không-nhánh)
    def mem(flag, mode):
        rc1, o1, e1 = sh([A, os.path.join(pd, 'base.mnn'), os.path.join(pd, 'spec.txt'), os.path.join(pd, 'lora.lora.mnn'), flag])
        rc2, o2, e2 = sh([pexe, 'run', pd, mode], timeout=120)
        m = re.search(r'sau malloc_trim\(0\) — nạp module còn lại ([+-][0-9.]+) MB', o2)
        return rc1 == 0 and rc2 == 0, os.path.getsize(os.path.join(pd, 'lora.lora.mnn')), (float(m.group(1)) if m else None)
    ok_o, sz_old, ram_old = mem('--strip-base-weights', 'base'); ok_n, sz_new, ram_new = mem('--strip-all-conv-weights', 'base'); ok_x, _, ram_nb = mem('--strip-base-weights', 'nobase')   # đối chứng dùng module kiểu CŨ (còn trọng số conv không-nhánh) nạp KHÔNG base; module đã tước hết thì không còn gì để sao chép (và không chạy được)
    print(f'  [đo thật, 4 conv 3x3 768 kênh ≈ 81 MB, LoRA chỉ nhắm c0] cờ cũ: tệp {sz_old/1048576:.1f} MB, RAM giữ lại {ram_old} MB | cờ mới: tệp {sz_new/1048576:.2f} MB, RAM giữ lại {ram_new} MB | module kiểu cũ nạp KHÔNG base: RAM giữ lại {ram_nb} MB')
    check(ok_o and ok_n and sz_old > 50 * 1048576 and sz_new < 1048576, f'cờ cũ để tệp module ~{sz_old/1048576:.0f} MB (còn trọng số conv không-nhánh); cờ mới còn {sz_new/1024:.0f} KB')
    if ram_old is not None and ram_new is not None and ram_nb is not None:
        check(ram_old < 30 and ram_new < 30, f'có base: module KHÔNG giữ thêm trọng số trong RAM dù LoRA chỉ phủ 1/4 conv (cờ cũ {ram_old} MB, cờ mới {ram_new} MB; sau malloc_trim)')
        check(ram_nb > 60, f'đối chứng: module kiểu cũ nạp KHÔNG base giữ bản sao trọng số conv không-nhánh trong RAM ({ram_nb} MB > 60) — chia sẻ trọng số (base + rearrange) là thứ tiết kiệm RAM')
    else: print('  (không có malloc_trim — bỏ qua phép đo RAM)')
    # cùng phép đo trên nền w8 (mnnconvert -f MNN --weightQuantBits 8): trọng số w8 nằm trong quanParameter — công cụ phải tước cả nó
    p8 = os.path.join(tmp, 'pm8'); os.makedirs(p8); shutil.copy(os.path.join(pd, 'A.bin'), p8); shutil.copy(os.path.join(pd, 'B.bin'), p8)
    r8, o8, e8 = sh([MNNCONVERT, '-f', 'MNN', '--modelFile', os.path.join(pd, 'base.mnn'), '--MNNModel', os.path.join(p8, 'base.mnn'), '--weightQuantBits', '8'])
    check(r8 == 0 and os.path.exists(os.path.join(p8, 'base.mnn')) and os.path.getsize(os.path.join(p8, 'base.mnn')) < 30 * 1048576, 'nền w8 tạo được (mnnconvert -f MNN --weightQuantBits 8), nhỏ hơn ~4 lần nền float32')
    if r8 == 0:
        open(os.path.join(p8, 'spec.txt'), 'w').write(f'c0 4 1.0 {p8}/A.bin {p8}/B.bin\n')
        def mem8(flag):
            rc1, _, _ = sh([A, os.path.join(p8, 'base.mnn'), os.path.join(p8, 'spec.txt'), os.path.join(p8, 'lora.lora.mnn'), flag])
            rc2, o2, _ = sh([pexe, 'run', p8, 'base'], timeout=120); m = re.search(r'sau malloc_trim\(0\) — nạp module còn lại ([+-][0-9.]+) MB', o2)
            return rc1 == 0 and rc2 == 0, os.path.getsize(os.path.join(p8, 'lora.lora.mnn')), (float(m.group(1)) if m else None)
        k1, s_old8, r_old8 = mem8('--strip-base-weights'); k2, s_new8, r_new8 = mem8('--strip-all-conv-weights')
        print(f'  [đo thật w8, LoRA chỉ nhắm c0] cờ cũ: tệp {s_old8/1048576:.1f} MB, RAM giữ lại {r_old8} MB | cờ mới: tệp {s_new8/1024:.0f} KB, RAM giữ lại {r_new8} MB')
        check(k1 and k2 and s_old8 > 10 * 1048576 and s_new8 < 1048576, f'w8: cờ cũ để module {s_old8/1048576:.0f} MB (còn buffer w8 của conv không-nhánh); cờ mới {s_new8/1024:.0f} KB — công cụ tước được quanParameter')
        if r_old8 is not None and r_new8 is not None: check(r_old8 < 30 and r_new8 < 30, f'w8: có base thì module KHÔNG giữ thêm trọng số trong RAM (cờ cũ {r_old8} MB, cờ mới {r_new8} MB)')

# ── phép phá mã trên CÔNG CỤ lora_attach_branch.cpp (các cải tiến mục 283) ──
atext = open(ATT, encoding='utf-8').read()
tmuts = [('quanParameter (buffer w8) không bị tước', 'cv->quanParameter->buffer.clear(); cv->quanParameter->buffer.shrink_to_fit();', '', 'w8'),
         ('--strip-all-conv-weights không tước conv KHÔNG nhánh', 'if (opt.stripAllConv) {', 'if (false) {', 'fp32'),
         ('tước cả conv lora::* (trọng số của chính module)', 'op->name.rfind("lora::", 0) == 0', 'false', 'pipeline')]
tcaught = 0
for i, (name, old_s, new_s, kind) in enumerate(tmuts):
    if old_s not in atext: print(f'  ?? không tìm thấy mẫu: {name}'); continue
    ap = os.path.join(tmp, f'att_m{i}.cpp'); open(ap, 'w', encoding='utf-8').write(atext.replace(old_s, new_s, 1)); aexe = os.path.join(tmp, f'att_m{i}')
    rb = subprocess.run(['g++', '-std=c++17', '-O1', '-w', ap, f'-I{SRC}/include', f'-I{SRC}/schema/current', f'-I{SRC}/3rd_party/flatbuffers/include', '-o', aexe], capture_output=True, text=True)
    if rb.returncode != 0: tcaught += 1; print('  BỊ BẮT (không biên dịch): ' + name); continue
    bad = False
    if kind in ('w8', 'fp32'):
        dd = p8 if kind == 'w8' else pd
        if os.path.exists(os.path.join(dd, 'base.mnn')):
            sh([aexe, os.path.join(dd, 'base.mnn'), os.path.join(dd, 'spec.txt'), os.path.join(dd, 'm.lora.mnn'), '--strip-all-conv-weights']); mp_ = os.path.join(dd, 'm.lora.mnn')
            bad = (not os.path.exists(mp_)) or os.path.getsize(mp_) > 1048576
    else:
        rcm, outm = pipeline(H, os.path.join(tmp, f'dt{i}'), '--strip-all-conv-weights', False, aexe); bad = rcm != 0 or 'FAIL' in outm
    tcaught += bad; print(('  BỊ BẮT' if bad else '  SỐNG SÓT') + ': ' + name)
check(tcaught == len(tmuts), f'phá mã công cụ: {tcaught}/{len(tmuts)} đột biến trên lora_attach_branch.cpp bị bắt')

# ── phép phá mã trên UnetModule.hpp ──
hp = os.path.join(JNI, 'sd_engine/UnetModule.hpp'); src = open(hp, encoding='utf-8').read()
muts = [
 ('rearrange=false (không chia sẻ trọng số nền)', 'mc.rearrange = true;', 'mc.rearrange = false;'),
 ('không gắn base cho module LoRA', 'mb.base = base_.get();', ''),
 ('đảo thứ tự tên cổng vào', '{"sample", "timestep", "encoder_hidden_states"}', '{"timestep", "sample", "encoder_hidden_states"}'),
 ('sai độ dài chuỗi văn bản (76)', 'constexpr int kSeqLen = 77;', 'constexpr int kSeqLen = 76;'),
 ('sai ánh xạ chỉ số biến thể khi nền là biến thể', 'loras_[base_is_variant_ ? idx - 1 : idx]', 'loras_[idx]'),
 ('tên đầu ra sai', '{"out_sample"}', '{"output"}'),
]
# ĐỘT BIẾN TƯƠNG ĐƯƠNG đã biết (KHÔNG đưa vào danh sách bắt): `shapeMutable = false` — trên CPU với MNN 3.6.1 và đồ thị đồ chơi này module vẫn chạy kích thước latent khác,
# nên không phân biệt được bằng đầu ra. Giữ shapeMutable = true theo MNN-LLM (264); hiệu ứng thật chỉ có thể thấy trên UNet thật/backend khác.

caught = 0; report = []
for i, (name, old, new) in enumerate(muts):
    if old not in src: report.append(f'  ?? không tìm thấy mẫu: {name}'); continue
    mj = os.path.join(tmp, f'jni_m{i}'); shutil.copytree(os.path.join(JNI, 'sd_engine'), os.path.join(mj, 'sd_engine'))
    open(os.path.join(mj, 'sd_engine/UnetModule.hpp'), 'w', encoding='utf-8').write(src.replace(old, new, 1))
    exe = os.path.join(tmp, f'h_m{i}'); okb, eb = build_harness(exe, mj)
    if not okb: caught += 1; report.append(f'  BỊ BẮT (không biên dịch): {name}'); continue
    rcm, outm = pipeline(exe, os.path.join(tmp, f'dm{i}'))
    bad = rcm != 0 or 'FAIL' in outm
    caught += bad; report.append(('  BỊ BẮT' if bad else '  SỐNG SÓT') + f': {name}')
print('\n'.join(report))
check(caught == len(muts), f'phá mã: {caught}/{len(muts)} đột biến trên UnetModule.hpp bị bắt')
shutil.rmtree(tmp, ignore_errors=True)
print('\nCÓ LỖI' if fails else '\nĐẠT'); sys.exit(1 if fails else 0)
