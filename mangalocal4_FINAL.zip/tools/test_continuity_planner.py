#!/usr/bin/env python3
"""mục 261 — kiểm thử `pipeline/ContinuityPlanner.kt` (bước LẬP kế hoạch liên tục kiểu CANVAS: điền bối cảnh bị bỏ trống) bằng kotlinc THẬT.

Đối chiếu với bản tham chiếu Python viết độc lập từ quy tắc: panel không khai bối cảnh, trong đoạn chỉ số LIÊN TIẾP, có bối cảnh gần nhất ở TRƯỚC và ở SAU
giống nhau (không phân biệt hoa/thường, khoảng trắng) -> gán tên NGUYÊN VĂN của panel trước. Fuzz 1500 truyện ngẫu nhiên (khoảng hở chỉ số, biến thể
hoa/thường, nhiều đoạn). Tính chất: sau khi điền, chạy lại không còn gì để điền (lũy đẳng) và ContinuityChecker không còn LOCATION_DRIFT; không bao giờ
sửa panel đã có bối cảnh; không bao giờ điền nhân vật/vật thể. Thử phá mã 5 đột biến CÓ Ý NGHĨA (các chốt trùng lặp với ContinuityChecker.check — so tên, ngưỡng 3 panel, chỉ-số-liên-tiếp — là phòng thủ chồng lớp nên gỡ riêng từng cái là đột biến tương đương, chỉ gỡ ĐỒNG THỜI mới quan sát được). Cần kotlinc (không có -> SKIP).
KHÔNG chứng minh: gán như vậy làm nền đỡ trôi ở ảnh thật; không chứng minh kịch bản thật hay bỏ trống đúng như giả định.
"""
import os, random, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + d) if (d and not c) else '')); ok &= bool(c)
def find():
    for c in [os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/work/kotlinc/bin/kotlinc']:
        if c and os.path.exists(c): return c
KOTLINC = find()
if not KOTLINC:
    print('SKIP: không có kotlinc'); sys.exit(0)
KLIB = os.path.join(os.path.dirname(os.path.dirname(KOTLINC)), 'lib', 'kotlin-stdlib.jar')

DRIVER = r'''
import com.mangalocal.pipeline.*
import java.io.File
fun main(args: Array<String>) {
    val out = StringBuilder()
    var cur = ArrayList<ContinuityChecker.Entry>()
    fun flush() {
        val fill = ContinuityPlanner.planLocationFill(cur)
        out.append(fill.entries.sortedBy { it.key }.joinToString(";") { "${it.key}=${it.value}" }).append("\n")
        // lũy đẳng + không còn LOCATION_DRIFT sau khi điền
        val applied = cur.map { e -> fill[e.panelIndex]?.let { ContinuityChecker.Entry(e.panelIndex, it, e.characters, e.objects) } ?: e }
        val again = ContinuityPlanner.planLocationFill(applied)
        val drift = ContinuityChecker.check(applied).count { it.kind == ContinuityChecker.Kind.LOCATION_DRIFT }
        out.append("IDEM ${again.size} ${drift}\n")
        // không đụng người/vật: so tập nhân vật/vật thể trước-sau
        val same = cur.zip(applied).all { (a, b) -> a.characters == b.characters && a.objects == b.objects && a.panelIndex == b.panelIndex }
        out.append("SAME $same\n")
        cur = ArrayList()
    }
    for (line in File(args[0]).readLines()) {
        if (line.isEmpty()) continue
        if (line == "---") { flush(); continue }
        val p = line.split("\t", limit = 4)
        cur.add(ContinuityChecker.Entry(p[0].toInt(), p[3], p[1].split(",").filter { it.isNotEmpty() }.toSet(), p[2].split(",").filter { it.isNotEmpty() }.toSet()))
    }
    File(args[1]).writeText(out.toString())
}
'''
def compile_(planner, tmp, tag):
    d = os.path.join(tmp, tag); os.makedirs(d, exist_ok=True)
    open(os.path.join(d, 'Drv.kt'), 'w').write(DRIVER)
    jar = os.path.join(tmp, tag + '.jar')
    r = subprocess.run([KOTLINC, os.path.join(KT, 'ContinuityChecker.kt'), planner, os.path.join(d, 'Drv.kt'), '-d', jar], capture_output=True, text=True)
    return jar, r
def run(jar, tmp, cases):
    fi = os.path.join(tmp, 'in.txt'); fo = os.path.join(tmp, 'out.txt')
    open(fi, 'w', encoding='utf-8').write(''.join('\n'.join(f'{i}\t{ch}\t{ob}\t{l}' for i, l, ch, ob in c) + '\n---\n' for c in cases))
    r = subprocess.run(['java', '-cp', f'{jar}:{KLIB}', 'DrvKt', fi, fo], capture_output=True, text=True)
    if r.returncode != 0: return None, r.stderr[-300:]
    return open(fo, encoding='utf-8').read().split('\n'), ''
def norm(s): return s.strip().lower()
def ref(case):
    es = sorted([(c[0], c[1]) for c in case], key=lambda x: x[0])
    out = {}
    runs = []; cur = [es[0]] if es else []
    for e in es[1:]:
        if e[0] == cur[-1][0] + 1: cur.append(e)
        else: runs.append(cur); cur = [e]
    if cur: runs.append(cur)
    if len(es) < 3: return {}
    for r in runs:
        for i, e in enumerate(r):
            if norm(e[1]) != '': continue
            p = i - 1
            while p >= 0 and norm(r[p][1]) == '': p -= 1
            q = i + 1
            while q < len(r) and norm(r[q][1]) == '': q += 1
            if p >= 0 and q < len(r) and norm(r[p][1]) == norm(r[q][1]): out[e[0]] = r[p][1].strip()
    return out
def parse(lines, n):
    res = []
    for k in range(n):
        m, idem, same = lines[3 * k], lines[3 * k + 1], lines[3 * k + 2]
        d = {}
        if m:
            for kv in m.split(';'):
                a, b = kv.split('=', 1); d[int(a)] = b
        res.append((d, idem, same))
    return res
def gen(rng):
    n = rng.randint(0, 12); idx = 0; case = []
    locs = ['Quán Cà Phê', 'quán cà phê ', 'Công viên', 'Phòng ngủ', ' PHÒNG NGỦ']
    for _ in range(n):
        idx += 1 if rng.random() < 0.85 else rng.randint(2, 3)
        ch = ','.join(sorted(rng.sample(['a', 'b', 'c'], rng.randint(0, 3))))
        ob = ','.join(sorted(rng.sample(['o', 'p'], rng.randint(0, 2))))
        case.append((idx, rng.choice(locs) if rng.random() < 0.55 else rng.choice(['', '  ']), ch, ob))
    return case
def suite(jar, tmp, quiet=False):
    bad = 0
    def chk(n, c, d=''):
        nonlocal bad
        if not c: bad += 1
        if not quiet: check(n, c, d)
    hand = [
        [(0, 'Quán'), (1, ''), (2, 'Quán')],
        [(0, 'Quán'), (1, ''), (2, 'Công viên')],
        [(0, 'Quán'), (1, ''), (3, 'Quán')],
        [(0, ''), (1, ''), (2, 'Quán')],
        [(0, 'Quán Cà Phê'), (1, ''), (2, ''), (3, 'quán cà phê')],
        [(0, 'A'), (1, '')],
        [(5, 'Phòng ngủ'), (6, '  '), (7, ' phòng ngủ ')],
    ]
    hand = [[(i, l, 'a', 'o') for i, l in c] for c in hand]
    o, e = run(jar, tmp, hand)
    if o is None: chk('chạy được', False, e); return bad
    res = parse(o, len(hand))
    chk('ca tay: điền khi hai bên cùng bối cảnh', res[0][0] == {1: 'Quán'})
    chk('ca tay: hai bên khác bối cảnh -> không điền', res[1][0] == {})
    chk('ca tay: khoảng hở chỉ số -> không điền (không bắc cầu qua panel thiếu)', res[2][0] == {})
    chk('ca tay: đầu truyện bỏ trống không có phía trước -> không điền', res[3][0] == {})
    chk('ca tay: nhiều panel trống liên tiếp giữa 2 panel cùng bối cảnh -> điền hết, tên NGUYÊN VĂN của panel trước',
        res[4][0] == {1: 'Quán Cà Phê', 2: 'Quán Cà Phê'}, str(res[4][0]))
    chk('ca tay: dưới 3 panel -> không điền', res[5][0] == {})
    chk('ca tay: khác hoa/thường + khoảng trắng vẫn coi cùng bối cảnh, gán tên đã trim của panel trước', res[6][0] == {6: 'Phòng ngủ'}, str(res[6][0]))
    rng = random.Random(261)
    cases = [gen(rng) for _ in range(1500)]
    o, e = run(jar, tmp, cases)
    if o is None: chk('fuzz chạy được', False, e); return bad
    res = parse(o, len(cases))
    mism = sum(1 for c, r in zip(cases, res) if r[0] != ref(c))
    chk('fuzz 1500 truyện: kết quả khớp tham chiếu Python từng panel', mism == 0, f'{mism} lệch')
    chk('fuzz: sau khi điền không còn gì để điền (lũy đẳng) và không còn LOCATION_DRIFT', all(r[1] == 'IDEM 0 0' for r in res), str([r[1] for r in res if r[1] != 'IDEM 0 0'][:2]))
    chk('fuzz: không bao giờ đổi nhân vật/vật thể/chỉ số', all(r[2] == 'SAME true' for r in res))
    chk('fuzz: không bao giờ điền panel ĐÃ có bối cảnh', all(all(norm({a: b for a, b, _, _ in c}.get(i, 'x')) == '' for i in r[0]) for c, r in zip(cases, res)))
    filled = sum(len(r[0]) for r in res)
    chk('fuzz đủ đa dạng (có ca điền, có ca không)', 50 < filled and sum(1 for r in res if not r[0]) > 100, f'filled={filled}')
    return bad
tmp = tempfile.mkdtemp()
PL = os.path.join(KT, 'ContinuityPlanner.kt')
jar, r = compile_(PL, tmp, 'real')
check('ContinuityPlanner.kt biên dịch bằng kotlinc thật', r.returncode == 0, r.stderr[-600:])
if r.returncode == 0:
    check('bộ kiểm trên mã THẬT: 0 lỗi', suite(jar, tmp) == 0)
    src = open(PL, encoding='utf-8').read()
    muts = [
        ('lấy tên panel SAU thay vì TRƯỚC', [('val loc = sorted[p].location.trim()', 'val loc = sorted[pos + 1].location.trim()')]),
        ('không trim tên', [('val loc = sorted[p].location.trim()', 'val loc = sorted[p].location')]),
        ('gán tên viết hoa', [('out[w.panelIndex] = found', 'out[w.panelIndex] = found.uppercase()')]),
        ('chỉ điền panel trống đầu tiên rồi dừng', [('out[w.panelIndex] = found', 'out[w.panelIndex] = found; break')]),
        ('điền cả cảnh báo nhân vật/vật thể VÀ bỏ so tên (gỡ đồng thời hai chốt trùng lặp)',
         [('it.kind == ContinuityChecker.Kind.LOCATION_DRIFT', 'true'), ('if (found != null && found.lowercase() == w.subject) out', 'if (found != null) out')]),
    ]
    caught = 0
    for n, (name, reps) in enumerate(muts):
        if any(o not in src for o, _ in reps): check(f'đột biến "{name}": mẫu có trong mã', False); continue
        msrc = src
        for o, nw in reps: msrc = msrc.replace(o, nw, 1)
        mp = os.path.join(tmp, f'm{n}.kt'); open(mp, 'w', encoding='utf-8').write(msrc)
        mj, mr = compile_(mp, tmp, f'm{n}')
        if mr.returncode != 0:
            check(f'đột biến "{name}" phải BIÊN DỊCH được (nếu không thì "bị bắt" là vô nghĩa)', False, mr.stderr[-300:]); continue
        hit = suite(mj, tmp, quiet=True) > 0
        check(f'đột biến "{name}" bị bắt', hit); caught += hit
    check(f'thử phá mã: {caught}/{len(muts)} đột biến bị bắt', caught == len(muts))
shutil.rmtree(tmp, ignore_errors=True)
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
