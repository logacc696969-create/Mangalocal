#!/usr/bin/env python3
"""mục 266 TECHNICAL_STATUS.md — đồng bộ `app.py` vào ô `%%writefile app.py` của `colab_remote_server.ipynb`.

Vì sao có script này: notebook nhúng NGUYÊN VĂN app.py (để chạy được từ trình duyệt điện thoại mà không cần upload file). Sau mục 248–250 app.py được thêm
PAG/interact/video/faceswap/handfix/kontext nhưng notebook vẫn nhúng bản cũ (629 dòng so với 1425 dòng) dù ô Markdown ghi "giống hệt" — chạy bằng notebook thì
app từ chối các tác vụ mới. Mỗi lần sửa app.py: chạy `python tools/remote_server/sync_notebook.py` (ghi lại ô) rồi `python tools/test_notebook_sync.py`.

  python tools/remote_server/sync_notebook.py            # ghi lại notebook cho khớp app.py
  python tools/remote_server/sync_notebook.py --check    # chỉ kiểm: thoát 1 nếu lệch (dùng trong test/CI)
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(HERE, 'app.py')
NB = os.path.join(HERE, 'colab_remote_server.ipynb')
MAGIC = '%%writefile app.py'


def find_cell(nb):
    """Chỉ số của ô code duy nhất bắt đầu bằng %%writefile app.py; lỗi nếu không có đúng một."""
    hits = [i for i, c in enumerate(nb['cells'])
            if c.get('cell_type') == 'code' and ''.join(c.get('source', [])).lstrip().startswith(MAGIC)]
    if len(hits) != 1:
        raise SystemExit(f'LỖI: cần đúng 1 ô "{MAGIC}", thấy {len(hits)}')
    return hits[0]


def embedded_text(nb):
    """Nội dung app.py đang nhúng (bỏ dòng magic), cùng quy ước xuống dòng với to_source()."""
    src = ''.join(nb['cells'][find_cell(nb)]['source'])
    first, _, rest = src.partition('\n')
    assert first.strip() == MAGIC, first
    return rest


def to_source(app_text):
    """Chuyển văn bản thành danh sách dòng `source` của ipynb (mỗi dòng giữ '\\n', dòng cuối không bắt buộc có)."""
    text = MAGIC + '\n' + app_text
    return text.splitlines(keepends=True)


def normalise(t):
    """So sánh bỏ khác biệt chỉ ở dấu xuống dòng cuối file (ipynb không giữ được '\\n' cuối của dòng cuối một cách ổn định)."""
    return t.replace('\r\n', '\n').rstrip('\n')


def is_synced(nb, app_text):
    return normalise(embedded_text(nb)) == normalise(app_text)


def main(argv):
    check = '--check' in argv
    app_text = open(APP, encoding='utf-8').read()
    nb = json.load(open(NB, encoding='utf-8'))
    if is_synced(nb, app_text):
        print('OK: notebook đã khớp app.py'); return 0
    if check:
        e = normalise(embedded_text(nb)).count('\n') + 1; a = normalise(app_text).count('\n') + 1
        print(f'LỆCH: notebook nhúng {e} dòng, app.py {a} dòng — chạy sync_notebook.py để ghi lại'); return 1
    nb['cells'][find_cell(nb)]['source'] = to_source(normalise(app_text) + '\n')
    with open(NB, 'w', encoding='utf-8') as f:
        json.dump(nb, f, ensure_ascii=False, indent=1); f.write('\n')
    nb2 = json.load(open(NB, encoding='utf-8'))
    assert is_synced(nb2, app_text), 'ghi xong vẫn lệch'
    print('ĐÃ GHI: notebook khớp app.py'); return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
