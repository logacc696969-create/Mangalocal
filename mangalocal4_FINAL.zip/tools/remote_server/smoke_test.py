#!/usr/bin/env python3
"""mục 255 — thử NHANH từng tác vụ của server từ xa (app.py) trên MỘT ảnh, từ máy bạn (không cần APK).

Dùng đúng giao thức mã hoá của app: GET /pubkey -> bọc khoá AES-256 bằng RSA-OAEP(SHA-256) -> payload JSON mã hoá AES-256-GCM
-> POST /generate -> giải mã PNG/MP4 trả về. In: fingerprint (để đối chiếu với màn hình server), thời gian, lỗi NGUYÊN VĂN của server
(vd "CUDA out of memory"), và báo cáo `mangalocal_report` nhúng trong PNG (faceswap). Lưu kết quả vào --out.

Cài:   pip install requests cryptography pillow
Chạy:  python smoke_test.py --url https://xxxx.trycloudflare.com --token MA_TOKEN --image panel.png \\
           --ref mat_nhan_vat.png --face-box 0.30,0.08,0.62,0.40 --tasks generate,faceswap,handfix,interact,kontext

Ghi chú:
  * --tasks mặc định: generate,faceswap,handfix,interact,kontext. `video` (SVD, nặng) chỉ chạy khi bạn nêu rõ.
  * faceswap cần --ref (ảnh mặt nhân vật) và --face-box (hộp mặt CHUẨN HOÁ x1,y1,x2,y2 trong ảnh --image; ước lượng bằng mắt là được,
    server ghép với mặt nó tự dò theo IoU). Thiếu một trong hai -> bỏ qua tác vụ này, KHÔNG coi là lỗi.
  * Mã thoát 0 nếu mọi tác vụ ĐÃ CHẠY đều thành công (tác vụ bị bỏ qua không tính); 1 nếu có tác vụ lỗi.
  * Script này chỉ là KHÁCH — không chứng minh chất lượng ảnh; nó cho bạn số liệu thật (thời gian, báo cáo, lỗi VRAM) để hiệu chỉnh.
"""
import argparse
import base64
import hashlib
import io
import json
import os
import sys
import time

import requests
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding as rsa_padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ALL_TASKS = ["generate", "faceswap", "handfix", "interact", "kontext", "video"]
DEFAULT_TASKS = ["generate", "faceswap", "handfix", "interact", "kontext"]


def fingerprint_display(der: bytes) -> str:
    """Cùng định dạng server in lúc khởi động: SHA-256 của DER, HOA, cách nhau bằng dấu hai chấm."""
    h = hashlib.sha256(der).hexdigest().upper()
    return ":".join(h[i:i + 2] for i in range(0, len(h), 2))


def b64_file(path: str) -> str:
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode()


def encrypt_request(public_key_der: bytes, payload: dict):
    """Trả (body_dict, aes_key). Khớp app.py generate(): RSA-OAEP(SHA256) bọc khoá, AES-256-GCM, IV 12 byte, không AAD."""
    pub = serialization.load_der_public_key(public_key_der)
    aes_key = AESGCM.generate_key(bit_length=256)
    iv = os.urandom(12)
    plaintext = json.dumps(payload).encode("utf-8")
    ciphertext = AESGCM(aes_key).encrypt(iv, plaintext, None)
    wrapped = pub.encrypt(
        aes_key,
        rsa_padding.OAEP(mgf=rsa_padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
    )
    body = {
        "wrapped_key_b64": base64.b64encode(wrapped).decode(),
        "iv_b64": base64.b64encode(iv).decode(),
        "ciphertext_b64": base64.b64encode(ciphertext).decode(),
    }
    return body, aes_key


def decrypt_response(resp_json: dict, aes_key: bytes) -> bytes:
    iv = base64.b64decode(resp_json["iv_b64"])
    ct = base64.b64decode(resp_json["ciphertext_b64"])
    return AESGCM(aes_key).decrypt(iv, ct, None)


def sniff_ext(data: bytes) -> str:
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if data[4:8] == b"ftyp":
        return "mp4"
    return "bin"


def png_report(data: bytes):
    """Đọc khối tEXt `mangalocal_report` (JSON) mà server nhúng vào PNG; None nếu không có/không đọc được."""
    try:
        from PIL import Image
        img = Image.open(io.BytesIO(data))
        txt = getattr(img, "text", None) or img.info
        raw = txt.get("mangalocal_report")
        return json.loads(raw) if raw else None
    except Exception:
        return None


def parse_box(s: str):
    try:
        v = [float(x) for x in s.split(",")]
    except ValueError:
        raise argparse.ArgumentTypeError("hộp phải dạng x1,y1,x2,y2 (số thực)")
    if len(v) != 4 or not all(0.0 <= x <= 1.0 for x in v) or v[2] <= v[0] or v[3] <= v[1]:
        raise argparse.ArgumentTypeError("hộp phải có 4 số trong [0,1] với x2>x1, y2>y1")
    return v


def build_payload(task: str, a, image_b64: str, ref_b64):
    """Trả (payload, lý_do_bỏ_qua). lý_do_bỏ_qua != None -> không chạy tác vụ này."""
    if task == "generate":
        return {"prompt": a.prompt, "negative_prompt": "lowres, bad anatomy, bad hands", "width": 512, "height": 512,
                "steps": a.steps, "cfg_scale": 7.0, "seed": a.seed}, None
    if image_b64 is None:
        return None, "thiếu --image"
    if task == "faceswap":
        if ref_b64 is None:
            return None, "thiếu --ref (ảnh mặt nhân vật)"
        if a.face_box is None:
            return None, "thiếu --face-box x1,y1,x2,y2 (chuẩn hoá)"
        return {"task": "faceswap", "image_b64": image_b64, "preserve": a.preserve,
                "targets": [{"id": 0, "box": a.face_box, "ref_b64": ref_b64}]}, None
    if task == "handfix":
        return {"task": "handfix", "image_b64": image_b64, "seed": a.seed, "strength": 0.75, "steps": a.steps,
                "prompt": a.prompt, "negative_prompt": "bad hands, extra fingers, missing fingers", "cfg_scale": 7.0}, None
    if task == "interact":
        return {"task": "interact", "prompt": a.prompt, "width": 512, "height": 512, "steps": 40, "seed": a.seed,
                "interaction": {"subject_phrase": "person", "object_phrase": "person", "action_phrase": a.action,
                                "subject_box": [0.05, 0.15, 0.55, 0.95], "object_box": [0.45, 0.15, 0.95, 0.95]}}, None
    if task == "kontext":
        p = {"task": "kontext", "image_b64": image_b64, "prompt": a.kontext_prompt, "steps": 28,
             "guidance_scale": 2.5, "seed": a.seed}
        if ref_b64 is not None:
            p["ref_b64"] = ref_b64
        return p, None
    if task == "video":
        return {"task": "video", "image_b64": image_b64, "num_frames": 14, "fps": 7, "seed": a.seed}, None
    return None, "tác vụ không biết"


def run_task(task, a, base, pub_der, headers, image_b64, ref_b64):
    """Trả dict kết quả: status ok|fail|skip, seconds, path, note."""
    payload, skip = build_payload(task, a, image_b64, ref_b64)
    if skip:
        return {"task": task, "status": "skip", "seconds": 0.0, "path": "", "note": skip}
    body, aes_key = encrypt_request(pub_der, payload)
    t0 = time.time()
    try:
        r = requests.post(base + "/generate", json=body, headers=headers, timeout=a.timeout)
    except requests.RequestException as e:
        return {"task": task, "status": "fail", "seconds": time.time() - t0, "path": "", "note": f"không gọi được server: {e}"}
    dt = time.time() - t0
    if r.status_code != 200:
        try:
            detail = r.json().get("detail", r.text)
        except Exception:
            detail = r.text
        return {"task": task, "status": "fail", "seconds": dt, "path": "", "note": f"HTTP {r.status_code}: {str(detail)[:500]}"}
    try:
        rj = r.json()
        data = decrypt_response(rj, aes_key)
    except Exception as e:
        return {"task": task, "status": "fail", "seconds": dt, "path": "", "note": f"giải mã phản hồi lỗi: {e}"}
    notes = []
    if task != "generate" and rj.get("task") != task:
        notes.append("CẢNH BÁO: phản hồi KHÔNG echo `task` — server CŨ chưa hiểu tác vụ này (nó có thể đã sinh ảnh ngẫu nhiên)")
    os.makedirs(a.out, exist_ok=True)
    path = os.path.join(a.out, f"{task}.{sniff_ext(data)}")
    with open(path, "wb") as f:
        f.write(data)
    rep = png_report(data) if path.endswith(".png") else None
    if rep is not None:
        notes.append("báo cáo: " + json.dumps(rep, ensure_ascii=False)[:1500])
    return {"task": task, "status": "ok", "seconds": dt, "path": path, "note": " | ".join(notes)}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Thử nhanh các tác vụ của MangaLocal remote server (mục 255).")
    ap.add_argument("--url", required=True, help="địa chỉ gốc server, vd https://xxxx.trycloudflare.com (không có /generate)")
    ap.add_argument("--token", required=True, help="--auth-token đã đặt khi chạy server")
    ap.add_argument("--image", help="ảnh panel để hậu kỳ (png/jpg)")
    ap.add_argument("--ref", help="ảnh mặt/nhân vật tham chiếu (faceswap bắt buộc; kontext tuỳ chọn)")
    ap.add_argument("--face-box", type=parse_box, help="hộp mặt chuẩn hoá x1,y1,x2,y2 trong --image (cho faceswap)")
    ap.add_argument("--tasks", default=",".join(DEFAULT_TASKS), help="danh sách, ngăn bởi dấu phẩy. Có: " + ",".join(ALL_TASKS))
    ap.add_argument("--out", default="smoke_out", help="thư mục lưu kết quả")
    ap.add_argument("--prompt", default="2 people hugging, manga style, detailed, best quality")
    ap.add_argument("--action", default="hug", help="hành động cho tác vụ interact (hug/kiss/hit...)")
    ap.add_argument("--kontext-prompt", default="change the background to a library, keep the characters exactly the same")
    ap.add_argument("--preserve", default="auto", choices=["auto", "mouth_eyes", "none"])
    ap.add_argument("--steps", type=int, default=25)
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--timeout", type=int, default=900, help="giây chờ mỗi tác vụ (lần đầu tải model có thể lâu)")
    ap.add_argument("--fingerprint", help="nếu đưa vào, hủy khi fingerprint server KHÁC (chống kẻ đứng giữa)")
    a = ap.parse_args(argv)

    tasks = [t.strip() for t in a.tasks.split(",") if t.strip()]
    bad = [t for t in tasks if t not in ALL_TASKS]
    if bad:
        print("Tác vụ không biết:", ", ".join(bad), "— hợp lệ:", ", ".join(ALL_TASKS))
        return 2
    base = a.url.rstrip("/")

    try:
        pk = requests.get(base + "/pubkey", timeout=60)
        pk.raise_for_status()
        pub_der = base64.b64decode(pk.json()["public_key_der_b64"])
    except Exception as e:
        print(f"Không lấy được /pubkey từ {base}: {e}")
        return 2
    fp = fingerprint_display(pub_der)
    print("Fingerprint server (ĐỐI CHIẾU với dòng in ở console server trước khi tin):")
    print("  " + fp)
    if a.fingerprint and a.fingerprint.strip().upper() != fp:
        print("Fingerprint KHÁC giá trị --fingerprint — DỪNG (có thể không phải server của bạn).")
        return 2

    image_b64 = b64_file(a.image) if a.image else None
    ref_b64 = b64_file(a.ref) if a.ref else None
    headers = {"Authorization": f"Bearer {a.token}"}

    results = []
    for t in tasks:
        print(f"\n=== {t} ===", flush=True)
        res = run_task(t, a, base, pub_der, headers, image_b64, ref_b64)
        results.append(res)
        tag = {"ok": "OK", "fail": "LỖI", "skip": "BỎ QUA"}[res["status"]]
        print(f"{tag}  ({res['seconds']:.1f}s)  {res['path']}")
        if res["note"]:
            print("  " + res["note"])

    print("\n" + "-" * 64)
    print(f"{'tác vụ':<10} {'kết quả':<8} {'giây':>7}  ghi chú")
    for r in results:
        tag = {"ok": "OK", "fail": "LỖI", "skip": "bỏ qua"}[r["status"]]
        note = (r["note"] or "").split(" | ")[0][:70]
        print(f"{r['task']:<10} {tag:<8} {r['seconds']:>7.1f}  {note}")
    ran = [r for r in results if r["status"] != "skip"]
    n_fail = sum(1 for r in ran if r["status"] == "fail")
    print(f"\nĐã chạy {len(ran)} tác vụ, lỗi {n_fail}. Kết quả ở thư mục: {a.out}")
    print("Gửi lại cho tôi: bảng trên + dòng 'báo cáo:' của faceswap + ảnh trong thư mục kết quả để hiệu chỉnh ngưỡng.")
    return 1 if n_fail else 0


if __name__ == "__main__":
    sys.exit(main())
