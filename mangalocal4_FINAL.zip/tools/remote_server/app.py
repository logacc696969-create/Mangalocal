"""
remote_server/app.py — Server tham chiếu chạy trên Colab (miễn phí) hoặc GPU
thuê ngoài (RunPod/Vast.ai/VPS riêng có GPU) để nhận request sinh ảnh từ app
MangaLocal (xem RemoteGenerationClient.kt phía app).

MÔ HÌNH BẢO MẬT — đọc kỹ trước khi chạy, đừng hiểu nhầm đây là "an toàn tuyệt đối":
  - Mã hoá hybrid RSA-OAEP (bọc AES key) + AES-256-GCM (payload thật) giữa APK
    và CHÍNH TIẾN TRÌNH PYTHON NÀY — độc lập với TLS, nên dù ngrok/Cloudflare
    Tunnel/ISP đứng giữa có đọc được gói HTTPS (vì họ terminate TLS ở edge của
    họ trước khi forward tiếp), nội dung bên trong (prompt, ảnh) vẫn là
    ciphertext đối với họ.
  - KHÔNG chống được chính chủ hạ tầng đang chạy tiến trình này (hạ tầng
    Google Colab, hoặc chủ máy vật lý bên dưới RunPod/Vast.ai) — lúc dòng
    code này chạy AESGCM.decrypt(...), RAM tiến trình chứa plaintext, ai có
    quyền truy cập hypervisor/VM đọc được. KHÔNG có cách nào phần mềm thuần
    ngăn được — xem TECHNICAL_STATUS.md mục 37 và giải thích trong hội thoại
    thiết kế (không phải vấn đề "tốc độ soi kịp hay không", là quyền truy cập
    hạ tầng vốn có của chủ máy). Chỉ Confidential-Computing GPU (TEE phần
    cứng) mới chống được điều này — server này CHƯA hỗ trợ CC.
  - Server KHÔNG ghi log nội dung (prompt/ảnh) — chỉ log kích thước/số bước.
    KHÔNG lưu file ảnh/prompt ra đĩa cho từng request (toàn bộ ảnh xử lý
    qua io.BytesIO trong RAM, không có lệnh .save() ra đĩa ở đâu cả). Các
    biến plaintext nhạy cảm (session key, payload giải mã, ảnh PNG trước
    khi mã lại) được ép về `bytearray` + ghi đè 0x00 TOÀN BỘ (không chỉ xoá
    tham chiếu) + `gc.collect()` ép thu hồi ngay, ngay khi dùng xong — xem
    `_zero_bytearray()`. Đây vẫn là BEST-EFFORT, không phải đảm bảo cứng:
    Python's str là immutable (prompt dạng text chỉ `del` được, không zero
    tại chỗ an toàn được), và các thư viện bên dưới (json/base64/
    cryptography) có thể tự tạo thêm bản sao tạm thời ngoài tầm kiểm soát
    của code này — xem chi tiết trong docstring `_zero_bytearray()`.
  - RSA keypair sinh MỚI mỗi lần chạy server, CHỈ ở RAM, không ghi đĩa —
    nghĩa là tắt server/đóng tunnel thì phải tạo lại + user phải đối chiếu
    fingerprint mới (TOFU lại từ đầu, xem RemoteGenerationClient.kt).

TÍNH NĂNG (mục 37→45 TECHNICAL_STATUS.md):
  - txt2img SD1.5 HOẶC SDXL (chọn được, xem "ĐỔI MODEL" bên dưới) — KHÔNG
    còn hardcode chỉ SD1.5 cho toàn server, vì GPU thuê mạnh hơn máy điện
    thoại nhiều, không có lý do gò vào đúng kiến trúc local dùng.
  - IP-Adapter (giữ nhất quán nhân vật qua ẢNH tham chiếu gửi kèm mỗi
    request — client gửi `reference_image_b64`).
  - ControlNet-Pose (giữ tư thế qua khung xương 18 điểm OpenPose COCO-18,
    client gửi `skeleton_data` — mảng float phẳng ĐÚNG format native gửi
    cho local, xem app/src/main/jni/ip_adapter.cpp
    `parseSkeletonsFromFloatArray`). Server tự vẽ lại khung xương bằng ĐÚNG
    bộ màu/cặp khớp nối chuẩn OpenPose mà native local dùng (kBonePairs/
    kBoneColors) — xem hàm `render_skeleton_image()`.
  - LoRA (`lora_id` — tên file KHÔNG kèm đuôi, server tìm
    `--loras-dir/<lora_id>.safetensors`). Nạp/gỡ ĐỘNG theo từng request
    (khác câu trước -> gỡ cũ, nạp mới) — không giữ tất cả LoRA trong VRAM
    cùng lúc. CHỈ áp dụng cho SD1.5 — LoRA train cho SD1.5 KHÔNG tương
    thích SDXL (kiến trúc UNet khác hẳn), server tự bỏ qua + log cảnh báo
    nếu nhận lora_id lúc đang ở SDXL.

ĐỔI MODEL (đọc kỹ — đây là phần user yêu cầu rõ, không phải chuyện nhỏ):
  Client gửi `model_id` (HuggingFace repo id hoặc path checkpoint trên máy
  chạy server) + `model_type` ("sd15" hoặc "sdxl") trong MỖI request — nhưng
  server CHỈ THỰC SỰ RELOAD khi giá trị này KHÁC lần trước (so trong
  `ensure_base_model()`). Nghĩa là: đổi model làm 1 LẦN trước khi bắt đầu
  generate 1 chương/truyện (đặt trong app > Cài đặt > Remote GPU TRƯỚC khi
  bấm Generate), các panel SAU ĐÓ trong cùng chương gửi CÙNG model_id thì
  server nhận ra giống hệt lần trước, KHÔNG reload lại (tốn vài chục giây
  tải cả UNet/VAE/CLIP/text-encoder), CHỈ reload khi thật sự đổi sang
  chương/nhân vật dùng model khác. `model_id` rỗng (client không gửi) =
  dùng đúng `--model` đặt lúc khởi động server (hành vi mặc định cũ).
  SDXL cần VRAM nhiều hơn SD1.5 đáng kể (~7-8GB fp16 so với ~2GB) — vẫn
  chạy được trên Colab free T4 (15GB) nhưng chậm hơn, cân nhắc trước khi
  chọn cho cả chương dài nhiều panel.

CHẠY:
  pip install -r requirements.txt
  python app.py --auth-token "chuoi-bi-mat-tu-dat-khong-chia-se" \
      --model runwayml/stable-diffusion-v1-5 \
      --loras-dir ./loras --controlnet-model lllyasviel/control_v11p_sd15_openpose \
      --ipadapter-repo h94/IP-Adapter --ipadapter-weight ip-adapter_sd15.bin \
      --controlnet-model-sdxl thibaud/controlnet-openpose-sdxl-1.0 \
      --ipadapter-weight-sdxl ip-adapter_sdxl.bin

Sau đó lộ endpoint ra ngoài:
  - Colab: dùng notebook colab_remote_server.ipynb đi kèm (tự động tunnel)
  - RunPod/Vast.ai/VPS riêng: mở port 8000 trực tiếp (đã có TLS+mã hoá ứng
    dụng nên không bắt buộc phải có HTTPS ở tầng ngoài, nhưng nên có thêm cho
    chắc — vd Caddy/nginx reverse proxy với cert Let's Encrypt).

Copy base URL + đúng auth-token đã đặt, dán vào app > Cài đặt > Remote GPU.
Bấm "Kiểm tra kết nối" trong app rồi ĐỐI CHIẾU fingerprint hiển thị với dòng
"Public key fingerprint" in ra ở terminal/log Colab bên dưới trước khi tin
tưởng gửi bất kỳ ảnh nào.
"""

import argparse
import asyncio
import base64
import ctypes
import gc
import hashlib
import io
import json
import os
import time
from typing import Optional

import uvicorn
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding as rsa_padding
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from fastapi import FastAPI, Header, HTTPException
from PIL import Image, ImageDraw
from pydantic import BaseModel

# ── Cấu hình từ CLI — KHÔNG hardcode auth token trong source, tự đặt lúc chạy ──
_arg_parser = argparse.ArgumentParser()
_arg_parser.add_argument("--auth-token", required=True,
    help="Bearer token app phải gửi kèm mỗi request — tự đặt 1 chuỗi ngẫu nhiên đủ dài, không chia sẻ công khai")
_arg_parser.add_argument("--model", default="runwayml/stable-diffusion-v1-5",
    help="Model MẶC ĐỊNH dùng khi app không gửi model_id — HuggingFace repo id hoặc path checkpoint local. Đổi được NGAY TỪ APP (Cài đặt > Remote GPU) mà không cần khởi động lại server, xem docstring 'ĐỔI MODEL' ở trên.")
_arg_parser.add_argument("--model-type", default="sd15", choices=["sd15", "sdxl"],
    help="Kiến trúc của --model ở trên (mặc định khi app không gửi model_type)")
_arg_parser.add_argument("--port", type=int, default=8000)
_arg_parser.add_argument("--host", default="0.0.0.0")
_arg_parser.add_argument("--loras-dir", default="./loras",
    help="Thư mục chứa file LoRA .safetensors (CHỈ áp dụng SD1.5) — ĐỒNG BỘ TRƯỚC từ MangaLocal/loras/ trên điện thoại (Google Drive mount khuyến nghị trên Colab, xem README.md)")
_arg_parser.add_argument("--controlnet-model", default="lllyasviel/control_v11p_sd15_openpose",
    help="ControlNet-Pose cho SD1.5 — chỉ nạp lúc có request cần pose")
_arg_parser.add_argument("--ipadapter-repo", default="h94/IP-Adapter",
    help="Repo HuggingFace chứa weight IP-Adapter (dùng chung cho cả 2 kiến trúc, khác subfolder/tên file)")
_arg_parser.add_argument("--ipadapter-weight", default="ip-adapter_sd15.bin",
    help="Tên file weight IP-Adapter cho SD1.5 trong repo trên")
_arg_parser.add_argument("--controlnet-model-sdxl", default="thibaud/controlnet-openpose-sdxl-1.0",
    help="ControlNet-Pose cho SDXL — KHÁC HẲN checkpoint SD1.5, không dùng chung được")
_arg_parser.add_argument("--ipadapter-weight-sdxl", default="ip-adapter_sdxl.bin",
    help="Tên file weight IP-Adapter cho SDXL (nằm trong subfolder sdxl_models/ của --ipadapter-repo)")
_arg_parser.add_argument("--max-queue-depth", type=int, default=3,
    help="Số request TỐI ĐA được xếp hàng chờ (kể cả request đang chạy) — quá số này server trả lỗi 429 ngay thay vì nhận thêm, tránh APK gửi dồn dập làm RAM/VRAM tăng không kiểm soát")
_arg_parser.add_argument("--min-request-interval", type=float, default=1.0,
    help="Khoảng cách tối thiểu (giây) giữa 2 lần BẮT ĐẦU chạy generate thật — chặn spam dồn dập ngay cả khi trong giới hạn hàng đợi")
_arg_parser.add_argument("--idle-cleanup-seconds", type=int, default=300,
    help="Sau chừng này giây KHÔNG có request nào, tự gỡ LoRA đang nạp + giải phóng VRAM cache — giảm tải tài nguyên lúc không ai dùng. 0 = tắt tính năng này.")
_arg_parser.add_argument("--max-uptime-hours", type=float, default=0.0,
    help="Tự đóng server sau chừng này giờ kể từ lúc khởi động — phòng trường hợp quên tắt, tránh giữ tài nguyên vô thời hạn không cần thiết. 0 = tắt (mặc định), chạy vô thời hạn như trước.")
args = _arg_parser.parse_args()

os.makedirs(args.loras_dir, exist_ok=True)

# ── RSA keypair ephemeral (xem docstring đầu file) ──────────────────────────
def _zero_bytearray(buf) -> None:
    """Ghi đè 0x00 lên TOÀN BỘ buffer trước khi del/để GC dọn — best-effort,
    CHỈ áp dụng được cho bytearray thật (mutable, có buffer protocol).

    GIỚI HẠN THẬT (đọc kỹ, đừng tưởng đây là xoá RAM tuyệt đối):
    - str và bytes trong Python là IMMUTABLE — không có cách an toàn nào
      ghi đè tại chỗ mà không có rủi ro làm hỏng interpreter (CPython có
      thể intern/cache chuỗi ngắn, ghi đè bừa qua ctypes có thể ảnh hưởng
      object KHÁC đang trỏ chung vùng nhớ). Vì vậy `prompt`/`negative_prompt`
      (str) chỉ `del` được, KHÔNG zero được — đây là giới hạn ngôn ngữ, gọi
      `del` xong vẫn phải chờ garbage collector thật sự thu hồi.
    - Ngay cả với bytearray zero được: các thư viện bên dưới (json, base64,
      cryptography...) có thể đã tự tạo thêm bản sao plaintext tạm thời
      trong lúc xử lý (vd base64.b64decode trả về bytes MỚI, không phải
      view lên buffer gốc) — những bản sao đó KHÔNG nằm trong tầm kiểm soát
      của code này, chỉ có thể chờ GC dọn tự nhiên.
    - gc.collect() ép Python thu hồi ngay lập tức các object không còn
      tham chiếu, NHƯNG không đảm bảo hệ điều hành/kernel zero hoá trang bộ
      nhớ vật lý đã giải phóng — trang đó có thể còn giữ dữ liệu cũ cho tới
      khi bị cấp phát lại và ghi đè bởi tiến trình khác.
    Tóm lại: đây là lớp phòng thủ BỔ SUNG hợp lý (giảm THỜI GIAN dữ liệu tồn
    tại ở dạng dễ đọc), KHÔNG phải giải pháp triệt để — threat model thật sự
    (chủ hạ tầng có quyền truy cập hypervisor) vẫn không bị chặn bởi kỹ
    thuật này, xem docstring đầu file.
    """
    if buf:
        ctypes.memset((ctypes.c_char * len(buf)).from_buffer(buf), 0, len(buf))


_private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
_public_key_der = _private_key.public_key().public_bytes(
    encoding=serialization.Encoding.DER,
    format=serialization.PublicFormat.SubjectPublicKeyInfo,
)
_fp_hex = hashlib.sha256(_public_key_der).hexdigest().upper()
_fingerprint_display = ":".join(_fp_hex[i:i + 2] for i in range(0, len(_fp_hex), 2))

print("=" * 72)
print("MangaLocal Remote Server — khởi động")
print(f"Model mặc định: {args.model} ({args.model_type})")
print(f"LoRA dir: {args.loras_dir}")
print("Public key fingerprint (đối chiếu với app TRƯỚC KHI tin tưởng):")
print(f"  {_fingerprint_display}")
print("=" * 72)

# ── OpenPose COCO-18 render — Y HỆT app/src/main/jni/ip_adapter.cpp ─────────
# (kBonePairs/kBoneColors) để ảnh điều kiện ControlNet-Pose khớp đúng convention
# model đã học, nhất quán với panel nào lỡ rơi về local render.
_BONE_PAIRS = [
    (1, 2), (1, 5), (2, 3), (3, 4), (5, 6), (6, 7), (1, 8), (8, 9), (9, 10),
    (1, 11), (11, 12), (12, 13), (1, 0), (0, 14), (14, 16), (0, 15), (15, 17),
]
_BONE_COLORS = [
    (255, 0, 0), (255, 85, 0), (255, 170, 0), (255, 255, 0), (170, 255, 0), (85, 255, 0),
    (0, 255, 0), (0, 255, 85), (0, 255, 170), (0, 255, 255), (0, 170, 255), (0, 85, 255),
    (0, 0, 255), (85, 0, 255), (170, 0, 255), (255, 0, 255), (255, 0, 170),
]


def render_skeleton_image(flat_data: list, size: int = 512) -> Image.Image:
    """flat_data: mảng float phẳng, mỗi người 18 khớp * 4 giá trị (x,y,z,visible)
    — ĐÚNG format Kotlin (PoseRetargeter) gửi cho native, xem
    parseSkeletonsFromFloatArray trong ip_adapter.cpp. Trả về ảnh RGB nền đen,
    khung xương vẽ đè lên (dùng làm ảnh điều kiện cho ControlNetModel)."""
    stride = 18 * 4
    n = len(flat_data)
    canvas = Image.new("RGB", (size, size), (0, 0, 0))
    if n <= 0 or n % stride != 0:
        return canvas
    draw = ImageDraw.Draw(canvas)
    num_people = n // stride
    people = []
    for p in range(num_people):
        kps = []
        for k in range(18):
            base = p * stride + k * 4
            kps.append((flat_data[base], flat_data[base + 1], flat_data[base + 2], flat_data[base + 3] > 0.5))
        people.append(kps)
    def avg_z(kps):
        vis = [z for (_, _, z, v) in kps if v]
        return sum(vis) / len(vis) if vis else 0.0
    people.sort(key=avg_z, reverse=True)  # xa vẽ trước, gần vẽ đè lên sau — giống native

    width_px = max(3, size // 100)
    for kps in people:
        for idx, (a, b) in enumerate(_BONE_PAIRS):
            xa, ya, _, va = kps[a]
            xb, yb, _, vb = kps[b]
            if not (va and vb):
                continue
            color = _BONE_COLORS[idx % len(_BONE_COLORS)]
            draw.line([(xa * size, ya * size), (xb * size, yb * size)], fill=color, width=width_px)
    return canvas


# ── Quản lý model ĐỘNG — đổi TRƯỚC khi bắt đầu 1 chương (không phải giữa
# panel), xem docstring "ĐỔI MODEL" đầu file. Không giữ nhiều checkpoint gốc
# cùng lúc trong VRAM (Colab free giới hạn) — đổi là GIẢI PHÓNG cái cũ trước.
_base_pipe = None
_cn_pipe = None
_current_model_id: Optional[str] = None
_current_model_type: Optional[str] = None
_ipadapter_loaded_on = set()   # id() của pipe object đã load IP-Adapter — reset lúc đổi model
_current_lora_id: Optional[str] = None
_current_lora_pipe_id: Optional[int] = None


def _torch_dtype():
    import torch
    return torch.float16 if torch.cuda.is_available() else torch.float32


def ensure_base_model(requested_model_id: Optional[str], requested_model_type: Optional[str]):
    """Load lại checkpoint gốc CHỈ KHI khác lần trước — gọi ở ĐẦU mỗi request,
    nhưng trong 1 chương/truyện thường mọi panel gửi CÙNG model_id nên hàm
    này gần như luôn no-op (rẻ), CHỈ thực sự tải lại lúc đổi sang
    chương/nhân vật dùng model khác — đúng ý "đổi trước khi bắt đầu công
    việc", không phải "đổi giữa chừng từng panel"."""
    global _base_pipe, _cn_pipe, _current_model_id, _current_model_type
    global _ipadapter_loaded_on, _current_lora_id, _current_lora_pipe_id

    model_id = requested_model_id or args.model
    model_type = (requested_model_type or args.model_type).lower()
    if model_type not in ("sd15", "sdxl"):
        print(f"[warn] model_type '{model_type}' không nhận diện được, dùng 'sd15'")
        model_type = "sd15"

    if _base_pipe is not None and model_id == _current_model_id and model_type == _current_model_type:
        return  # giống hệt lần trước — đa số các panel trong 1 chương rơi vào đây

    import torch
    print(f"Đổi model base: '{model_id}' ({model_type}) — có thể mất vài phút, "
          f"CHỈ xảy ra khi thật sự đổi model (đầu chương/nhân vật mới), không phải mỗi panel...")

    # Giải phóng model CŨ trước khi load model MỚI — không giữ 2 checkpoint
    # gốc cùng lúc trong VRAM (đặc biệt quan trọng nếu SDXL, ~7-8GB/checkpoint).
    if _base_pipe is not None:
        del _base_pipe
    if _cn_pipe is not None:
        del _cn_pipe
    _base_pipe = None
    _cn_pipe = None
    _ipadapter_loaded_on = set()
    _current_lora_id = None
    _current_lora_pipe_id = None
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    dtype = _torch_dtype()
    if model_type == "sdxl":
        from diffusers import StableDiffusionXLPipeline
        try:
            _base_pipe = StableDiffusionXLPipeline.from_pretrained(
                model_id, torch_dtype=dtype, variant="fp16" if dtype == torch.float16 else None,
                use_safetensors=True,
            )
        except Exception:
            # Không phải checkpoint nào cũng có variant "fp16" riêng — thử lại
            # không ép variant nếu lần đầu lỗi (vd finetune tự host không tách variant).
            _base_pipe = StableDiffusionXLPipeline.from_pretrained(model_id, torch_dtype=dtype)
    else:
        from diffusers import StableDiffusionPipeline
        _base_pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=dtype, safety_checker=None)

    _base_pipe = _base_pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    _current_model_id = model_id
    _current_model_type = model_type
    print(f"✓ Model base đã load: '{model_id}' ({model_type})")


def get_controlnet_pipe():
    """Build ControlNet-Pose pipe cho ĐÚNG kiến trúc đang active
    (_current_model_type) — dùng from_pipe() để chia sẻ UNet/VAE/CLIP với
    _base_pipe (đỡ tốn VRAM). Cache theo model hiện tại — reset về None mỗi
    lúc đổi model ở ensure_base_model(), nên không lo dùng nhầm ControlNet
    của kiến trúc cũ."""
    global _cn_pipe
    if _cn_pipe is not None:
        return _cn_pipe
    import torch
    if _current_model_type == "sdxl":
        from diffusers import ControlNetModel, StableDiffusionXLControlNetPipeline
        print(f"Đang load ControlNet-Pose SDXL ({args.controlnet_model_sdxl})...")
        controlnet = ControlNetModel.from_pretrained(args.controlnet_model_sdxl, torch_dtype=_torch_dtype())
        _cn_pipe = StableDiffusionXLControlNetPipeline.from_pipe(_base_pipe, controlnet=controlnet)
    else:
        from diffusers import ControlNetModel, StableDiffusionControlNetPipeline
        print(f"Đang load ControlNet-Pose SD1.5 ({args.controlnet_model})...")
        controlnet = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=_torch_dtype())
        _cn_pipe = StableDiffusionControlNetPipeline.from_pipe(_base_pipe, controlnet=controlnet)
    _cn_pipe = _cn_pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    print("✓ ControlNet-Pose đã load")
    return _cn_pipe


def ensure_ip_adapter(pipe):
    """Nạp IP-Adapter đúng kiến trúc đang active, lên ĐÚNG pipe object sẽ
    dùng để generate — chỉ 1 lần/pipe (idempotent qua _ipadapter_loaded_on)."""
    key = id(pipe)
    if key in _ipadapter_loaded_on:
        return
    if _current_model_type == "sdxl":
        print(f"Đang load IP-Adapter SDXL ({args.ipadapter_repo})...")
        pipe.load_ip_adapter(args.ipadapter_repo, subfolder="sdxl_models", weight_name=args.ipadapter_weight_sdxl)
    else:
        print(f"Đang load IP-Adapter SD1.5 ({args.ipadapter_repo})...")
        pipe.load_ip_adapter(args.ipadapter_repo, subfolder=None, weight_name=args.ipadapter_weight)
    _ipadapter_loaded_on.add(key)
    print("✓ IP-Adapter đã load")


def apply_lora(pipe, lora_id: Optional[str]):
    """Nạp/gỡ LoRA ĐỘNG theo từng request — CHỈ áp dụng SD1.5 (LoRA train
    cho SD1.5 không tương thích SDXL, kiến trúc UNet khác hẳn). KHÔNG giữ
    nhiều LoRA cùng lúc trong VRAM."""
    global _current_lora_id, _current_lora_pipe_id
    if _current_model_type == "sdxl":
        if lora_id:
            print(f"[warn] lora_id='{lora_id}' bị bỏ qua — đang ở SDXL, LoRA SD1.5 không tương thích")
        return
    if lora_id == _current_lora_id and id(pipe) == _current_lora_pipe_id:
        return  # đã đúng LoRA cần dùng rồi, khỏi làm lại (panel liên tiếp cùng nhân vật)
    if _current_lora_id is not None and _current_lora_pipe_id == id(pipe):
        try:
            pipe.unload_lora_weights()
        except Exception as e:
            print(f"[warn] unload_lora_weights lỗi (bỏ qua, tiếp tục nạp LoRA mới): {e}")
    if lora_id:
        lora_path = os.path.join(args.loras_dir, f"{lora_id}.safetensors")
        if not os.path.isfile(lora_path):
            raise HTTPException(status_code=400,
                detail=f"Không tìm thấy LoRA '{lora_id}' tại {lora_path} trên server — "
                       f"đồng bộ file .safetensors này lên {args.loras_dir}/ trước (xem README.md).")
        print(f"Đang nạp LoRA: {lora_id}")
        pipe.load_lora_weights(lora_path)
    _current_lora_id = lora_id
    _current_lora_pipe_id = id(pipe)


app = FastAPI(title="MangaLocal Remote Server")

# ── Hàng đợi + giới hạn tần suất — CHỐNG APK GỬI DỒN DẬP LÀM GPU/RAM 100% ──
# 2 lớp bảo vệ độc lập, cả 2 đều cần cho đúng ý "APK gửi cái nào mới làm cái
# đó, không dồn dập":
#   1. Hàng đợi CÓ GIỚI HẠN (_MAX_QUEUE_DEPTH request đang chờ+chạy) — vượt
#      quá thì trả lỗi 429 NGAY LẬP TỨC thay vì nhận vô hạn request rồi để
#      RAM tăng dần chờ xử lý (APK/BackendRouter phía Kotlin nên coi 429 là
#      tín hiệu "thử lại sau", KHÔNG phải lỗi cứng).
#   2. CHỈ 1 generate chạy GPU thật tại 1 thời điểm (asyncio.Semaphore(1)) —
#      tự nhiên đúng với 1 GPU vật lý (Colab/RunPod thường chỉ có 1 GPU),
#      tránh 2 request cùng lúc tranh VRAM gây OOM.
#   3. Khoảng cách tối thiểu giữa 2 lần BẮT ĐẦU generate thật
#      (--min-request-interval) — chặn spam ngay cả khi hàng đợi còn chỗ.
_MAX_QUEUE_DEPTH = args.max_queue_depth
_queue_depth = 0
_queue_depth_lock = asyncio.Lock()
_generation_semaphore = asyncio.Semaphore(1)
_last_generation_start = 0.0

# ── Dọn dẹp tài nguyên lúc rảnh + tự đóng sau thời lượng dài — QUẢN LÝ TÀI
# NGUYÊN TỐT, không phải kỹ thuật né tránh gì: giữ VRAM/LoRA nạp sẵn khi
# không ai dùng là lãng phí thật, và quên tắt server chạy vô thời hạn cũng
# là lãng phí thật — cả 2 đều đáng tự động xử lý bất kể chạy ở đâu.
_server_start_time = time.monotonic()
_last_activity_time = time.monotonic()  # cập nhật mỗi lần generate() xử lý xong


async def _maintenance_loop():
    """Task nền chạy suốt vòng đời server — kiểm tra định kỳ (mỗi 30 giây):
    (1) đã rảnh đủ lâu (--idle-cleanup-seconds) thì gỡ LoRA + giải phóng
    VRAM cache đang giữ không cần thiết; (2) đã chạy đủ lâu
    (--max-uptime-hours) thì tự đóng server gọn gàng. Cả 2 đều TẮT theo mặc
    định (idle-cleanup bật sẵn ở mức hợp lý 300s, uptime-limit tắt hẳn =
    0) — không tự ý thay đổi hành vi nếu user không đặt."""
    global _current_lora_id, _current_lora_pipe_id
    while True:
        await asyncio.sleep(30)
        now = time.monotonic()

        if args.idle_cleanup_seconds > 0 and (now - _last_activity_time) > args.idle_cleanup_seconds:
            if _current_lora_id is not None or _base_pipe is not None:
                try:
                    import torch
                    if _current_lora_id is not None and _base_pipe is not None:
                        print(f"[maintenance] Rảnh > {args.idle_cleanup_seconds}s — gỡ LoRA '{_current_lora_id}' đang giữ")
                        try:
                            _base_pipe.unload_lora_weights()
                        except Exception:
                            pass
                        _current_lora_id = None
                        _current_lora_pipe_id = None
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                    gc.collect()
                except Exception as e:
                    print(f"[maintenance] dọn dẹp lỗi (bỏ qua): {e}")
            # Đặt lại mốc để không lặp lại dọn dẹp mỗi 30s khi đã rảnh xong 1 lần
            _last_activity_time = now

        if args.max_uptime_hours > 0 and (now - _server_start_time) > args.max_uptime_hours * 3600:
            print(f"[maintenance] Đã chạy quá {args.max_uptime_hours} giờ (--max-uptime-hours) — tự đóng server. "
                  f"Chạy lại notebook/cell nếu cần tiếp tục (sẽ có URL/fingerprint MỚI, cập nhật lại trong app).")
            os._exit(0)  # thoát thẳng, đơn giản và chắc chắn hơn cố gọi uvicorn.Server.should_exit từ task nền


@app.on_event("startup")
async def _start_maintenance_task():
    asyncio.create_task(_maintenance_loop())


class GenerateRequest(BaseModel):
    wrapped_key_b64: str   # AES-256 key, đã bọc bằng RSA-OAEP public key của server
    iv_b64: str             # IV cho AES-GCM (chiều gửi lên)
    ciphertext_b64: str     # payload JSON đã mã hoá AES-GCM (xem field trong plaintext, docstring đầu file)


@app.get("/pubkey")
def pubkey():
    """App gọi 1 lần lúc bấm 'Kiểm tra kết nối' — lấy public key + tính fingerprint để user tự đối chiếu (TOFU)."""
    return {"public_key_der_b64": base64.b64encode(_public_key_der).decode()}


def _run_generation_sync(payload: dict) -> bytes:
    """Phần XỬ LÝ NẶNG (CPU/GPU-bound) — chạy trong thread executor riêng
    (xem generate() bên dưới) để không chặn event loop của các request khác
    (vd /pubkey vẫn phải trả lời nhanh dù đang có ảnh khác chạy dở). Trả về
    PNG bytes thẳng, KHÔNG mã hoá ở đây (mã hoá lại nằm ở generate(), chỗ có
    quyền truy cập aes_key)."""
    prompt = payload.get("prompt", "")
    negative_prompt = payload.get("negative_prompt", "")
    width = int(payload.get("width", 512))
    height = int(payload.get("height", 512))
    steps = int(payload.get("steps", 25))
    cfg_scale = float(payload.get("cfg_scale", 7.0))
    seed = payload.get("seed", -1)
    lora_id = payload.get("lora_id") or None
    reference_image_b64 = payload.get("reference_image_b64") or None
    skeleton_data = payload.get("skeleton_data") or None
    requested_model_id = payload.get("model_id") or None
    requested_model_type = payload.get("model_type") or None

    # KHÔNG log nội dung prompt/ảnh — chỉ log thông số không nhạy cảm
    print(f"[generate] model={requested_model_id or args.model} ({requested_model_type or args.model_type}), "
          f"{width}x{height}, {steps} steps, cfg={cfg_scale}, lora={lora_id or '(none)'}, "
          f"ip_adapter={'có' if reference_image_b64 else 'không'}, pose={'có' if skeleton_data else 'không'} — đang chạy...")

    ref_image = None
    try:
        # Đổi model NẾU khác lần trước (xem docstring ensure_base_model —
        # gần như luôn no-op trong cùng 1 chương, chỉ tải lại lúc thật sự đổi).
        ensure_base_model(requested_model_id, requested_model_type)

        use_pose = bool(skeleton_data)
        pipe = get_controlnet_pipe() if use_pose else _base_pipe

        if reference_image_b64:
            ensure_ip_adapter(pipe)
            ref_bytes = base64.b64decode(reference_image_b64)
            ref_image = Image.open(io.BytesIO(ref_bytes)).convert("RGB")

        apply_lora(pipe, lora_id)

        import torch
        generator = None
        if seed is not None and int(seed) >= 0:
            generator = torch.Generator(device=pipe.device).manual_seed(int(seed))

        gen_kwargs = dict(
            prompt=prompt, negative_prompt=negative_prompt,
            width=width, height=height,
            num_inference_steps=steps, guidance_scale=cfg_scale,
            generator=generator,
        )
        if ref_image is not None:
            gen_kwargs["ip_adapter_image"] = ref_image
        if use_pose:
            gen_kwargs["image"] = render_skeleton_image(skeleton_data, size=max(width, height))

        result = pipe(**gen_kwargs)
        image = result.images[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generate lỗi: {e}")
    finally:
        del prompt, negative_prompt
        if ref_image is not None:
            del ref_image
        # payload (dict) vẫn còn ở caller (generate()) lúc này nên del ở đây
        # chưa xoá hết mọi reference tới prompt/negative_prompt — chỉ thật
        # sự giải phóng được sau khi generate() cũng del payload (xem đó).
        # gc.collect() gọi lại lần nữa ở generate() mới có tác dụng đầy đủ.

    buf = io.BytesIO()
    image.save(buf, format="PNG")
    return buf.getvalue()


@app.post("/generate")
async def generate(req: GenerateRequest, authorization: Optional[str] = Header(None)):
    if authorization != f"Bearer {args.auth_token}":
        raise HTTPException(status_code=401, detail="Auth token sai hoặc thiếu")

    # 1. Mở khoá AES session key bằng RSA private key của server
    try:
        wrapped_key = bytearray(base64.b64decode(req.wrapped_key_b64))
        aes_key = bytearray(_private_key.decrypt(
            bytes(wrapped_key),
            rsa_padding.OAEP(
                mgf=rsa_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(), label=None,
            ),
        ))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Không giải mã được session key: {e}")

    # 2. Giải mã payload thật bằng AES-256-GCM
    try:
        iv = base64.b64decode(req.iv_b64)
        ciphertext = base64.b64decode(req.ciphertext_b64)
        plaintext = bytearray(AESGCM(bytes(aes_key)).decrypt(iv, ciphertext, None))
        payload = json.loads(bytes(plaintext).decode("utf-8"))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Không giải mã được payload (sai key hoặc dữ liệu hỏng): {e}")

    # 3. Xếp hàng CÓ GIỚI HẠN — vượt quá _MAX_QUEUE_DEPTH thì từ chối NGAY,
    #    không nhận thêm rồi để RAM dồn ứ chờ xử lý.
    global _queue_depth, _last_generation_start, _last_activity_time
    async with _queue_depth_lock:
        if _queue_depth >= _MAX_QUEUE_DEPTH:
            raise HTTPException(status_code=429,
                detail=f"Server đang xử lý/xếp hàng {_queue_depth} yêu cầu (giới hạn {_MAX_QUEUE_DEPTH}) — "
                       f"thử lại sau vài giây.")
        _queue_depth += 1

    try:
        # 4. Chỉ 1 generate chạy GPU thật tại 1 thời điểm — cái sau tự chờ
        #    (đúng 1 GPU vật lý), KHÔNG chạy song song gây tranh VRAM.
        async with _generation_semaphore:
            # 5. Giới hạn tần suất — đảm bảo khoảng cách tối thiểu giữa 2 lần
            #    BẮT ĐẦU generate thật, kể cả khi hàng đợi còn chỗ.
            now = time.monotonic()
            wait = args.min_request_interval - (now - _last_generation_start)
            if wait > 0:
                await asyncio.sleep(wait)
            _last_generation_start = time.monotonic()

            # 6. Phần nặng chạy trong thread executor — không chặn event loop
            #    (để /pubkey hay request khác đang xếp hàng vẫn phản hồi được).
            image_bytes = bytearray(await asyncio.get_event_loop().run_in_executor(
                None, _run_generation_sync, payload
            ))
            _last_activity_time = time.monotonic()  # đánh dấu vừa có hoạt động thật — reset đếm giờ rảnh cho _maintenance_loop
    finally:
        async with _queue_depth_lock:
            _queue_depth -= 1
        # Xoá dấu vết plaintext SỚM NHẤT có thể — zero byte thật (không chỉ
        # del) cho những gì là bytearray thật; payload (dict chứa str) chỉ
        # del được, str immutable không zero tại chỗ an toàn được (xem
        # docstring _zero_bytearray phía trên). gc.collect() ép thu hồi
        # ngay thay vì chờ GC generational bình thường (có thể trễ vài giây
        # tới vài phút tuỳ áp lực bộ nhớ).
        _zero_bytearray(plaintext)
        _zero_bytearray(wrapped_key)
        del payload, plaintext, wrapped_key
        gc.collect()

    # 7. Mã hoá lại ảnh PNG bằng CÙNG aes_key (đối xứng, IV MỚI cho chiều trả về —
    #    KHÔNG BAO GIỜ tái dùng IV với cùng 1 key trong AES-GCM)
    resp_iv = os.urandom(12)
    resp_ciphertext = AESGCM(bytes(aes_key)).encrypt(resp_iv, bytes(image_bytes), None)
    _zero_bytearray(image_bytes)
    _zero_bytearray(aes_key)
    del image_bytes, aes_key
    gc.collect()

    return {
        "iv_b64": base64.b64encode(resp_iv).decode(),
        "ciphertext_b64": base64.b64encode(resp_ciphertext).decode(),
    }


if __name__ == "__main__":
    uvicorn.run(app, host=args.host, port=args.port)
