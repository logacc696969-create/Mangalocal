"""
remote_server/app.py — Server tham chiếu chạy trên Colab (miễn phí) hoặc GPU
thuê ngoài (RunPod/Vast.ai/VPS riêng có GPU) để nhận request sinh ảnh từ app
MangaLocal (xem RemoteGenerationClient.kt phía app).

MÔ HÌNH BẢO MẬT — đọc kỹ trước khi chạy, đừng hiểu nhầm đây là "an toàn tuyệt đối":
  - Mã hoá hybrid RSA-OAEP (bọc AES key) + AES-256-GCM (payload thật) giữa APK
    và CHÍNH TIẾN TRÌNH PYTHON NÀY — độc lập với TLS, nên dù ngrok/Cloudflare
    Tunnel/ISP đứng giữa có đọc được gói HTTPS (vì họ terminate TLS ở edge của
    họ trước khi forward tiếp), nội dung bên trong (prompt, ảnh) vẫn là
    ciphertext đối với họ.
  - KHÔNG chống được chính chủ hạ tầng đang chạy tiến trình này (hạ tầng
    Google Colab, hoặc chủ máy vật lý bên dưới RunPod/Vast.ai) — lúc dòng
    code này chạy AESGCM.decrypt(...), RAM tiến trình chứa plaintext, ai có
    quyền truy cập hypervisor/VM đọc được. KHÔNG có cách nào phần mềm thuần
    ngăn được — xem TECHNICAL_STATUS.md mục 37 và giải thích trong hội thoại
    thiết kế (không phải vấn đề "tốc độ soi kịp hay không", là quyền truy cập
    hạ tầng vốn có của chủ máy). Chỉ Confidential-Computing GPU (TEE phần
    cứng) mới chống được điều này — server này CHƯA hỗ trợ CC.
  - Server KHÔNG ghi log nội dung (prompt/ảnh) — chỉ log kích thước/số bước.
    KHÔNG lưu file ảnh/prompt ra đĩa cho từng request (toàn bộ ảnh xử lý
    qua io.BytesIO trong RAM, không có lệnh .save() ra đĩa ở đâu cả). Các
    biến plaintext nhạy cảm (session key, payload giải mã, ảnh PNG trước
    khi mã lại) được ép về `bytearray` + ghi đè 0x00 TOÀN BỘ (không chỉ xoá
    tham chiếu) + `gc.collect()` ép thu hồi ngay, ngay khi dùng xong — xem
    `_zero_bytearray()`. Đây vẫn là BEST-EFFORT, không phải đảm bảo cứng:
    Python's str là immutable (prompt dạng text chỉ `del` được, không zero
    tại chỗ an toàn được), và các thư viện bên dưới (json/base64/
    cryptography) có thể tự tạo thêm bản sao tạm thời ngoài tầm kiểm soát
    của code này — xem chi tiết trong docstring `_zero_bytearray()`.
  - RSA keypair sinh MỚI mỗi lần chạy server, CHỈ ở RAM, không ghi đĩa —
    nghĩa là tắt server/đóng tunnel thì phải tạo lại + user phải đối chiếu
    fingerprint mới (TOFU lại từ đầu, xem RemoteGenerationClient.kt).

TÍNH NĂNG (mục 37→45 TECHNICAL_STATUS.md):
  - txt2img SD1.5 HOẶC SDXL (chọn được, xem "ĐỔI MODEL" bên dưới) — KHÔNG
    còn hardcode chỉ SD1.5 cho toàn server, vì GPU thuê mạnh hơn máy điện
    thoại nhiều, không có lý do gò vào đúng kiến trúc local dùng.
  - IP-Adapter (giữ nhất quán nhân vật qua ẢNH tham chiếu gửi kèm mỗi
    request — client gửi `reference_image_b64`).
  - ControlNet-Pose (giữ tư thế qua khung xương 18 điểm OpenPose COCO-18,
    client gửi `skeleton_data` — mảng float phẳng ĐÚNG format native gửi
    cho local, xem app/src/main/jni/ip_adapter.cpp
    `parseSkeletonsFromFloatArray`). Server tự vẽ lại khung xương bằng ĐÚNG
    bộ màu/cặp khớp nối chuẩn OpenPose mà native local dùng (kBonePairs/
    kBoneColors) — xem hàm `render_skeleton_image()`.
  - LoRA (`lora_id` — tên file KHÔNG kèm đuôi, server tìm
    `--loras-dir/<lora_id>.safetensors`). Nạp/gỡ ĐỘNG theo từng request
    (khác câu trước -> gỡ cũ, nạp mới) — không giữ tất cả LoRA trong VRAM
    cùng lúc. CHỈ áp dụng cho SD1.5 — LoRA train cho SD1.5 KHÔNG tương
    thích SDXL (kiến trúc UNet khác hẳn), server tự bỏ qua + log cảnh báo
    nếu nhận lora_id lúc đang ở SDXL.

ĐỔI MODEL (đọc kỹ — đây là phần user yêu cầu rõ, không phải chuyện nhỏ):
  Client gửi `model_id` (HuggingFace repo id hoặc path checkpoint trên máy
  chạy server) + `model_type` ("sd15" hoặc "sdxl") trong MỖI request — nhưng
  server CHỈ THỰC SỰ RELOAD khi giá trị này KHÁC lần trước (so trong
  `ensure_base_model()`). Nghĩa là: đổi model làm 1 LẦN trước khi bắt đầu
  generate 1 chương/truyện (đặt trong app > Cài đặt > Remote GPU TRƯỚC khi
  bấm Generate), các panel SAU ĐÓ trong cùng chương gửi CÙNG model_id thì
  server nhận ra giống hệt lần trước, KHÔNG reload lại (tốn vài chục giây
  tải cả UNet/VAE/CLIP/text-encoder), CHỈ reload khi thật sự đổi sang
  chương/nhân vật dùng model khác. `model_id` rỗng (client không gửi) =
  dùng đúng `--model` đặt lúc khởi động server (hành vi mặc định cũ).
  SDXL cần VRAM nhiều hơn SD1.5 đáng kể (~7-8GB fp16 so với ~2GB) — vẫn
  chạy được trên Colab free T4 (15GB) nhưng chậm hơn, cân nhắc trước khi
  chọn cho cả chương dài nhiều panel.

CHẠY:
  pip install -r requirements.txt
  python app.py --auth-token "chuoi-bi-mat-tu-dat-khong-chia-se" \
      --model runwayml/stable-diffusion-v1-5 \
      --loras-dir ./loras --controlnet-model lllyasviel/control_v11p_sd15_openpose \
      --ipadapter-repo h94/IP-Adapter --ipadapter-weight ip-adapter_sd15.bin \
      --controlnet-model-sdxl thibaud/controlnet-openpose-sdxl-1.0 \
      --ipadapter-weight-sdxl ip-adapter_sdxl.bin

Sau đó lộ endpoint ra ngoài:
  - Colab: dùng notebook colab_remote_server.ipynb đi kèm (tự động tunnel)
  - RunPod/Vast.ai/VPS riêng: mở port 8000 trực tiếp (đã có TLS+mã hoá ứng
    dụng nên không bắt buộc phải có HTTPS ở tầng ngoài, nhưng nên có thêm cho
    chắc — vd Caddy/nginx reverse proxy với cert Let's Encrypt).

Copy base URL + đúng auth-token đã đặt, dán vào app > Cài đặt > Remote GPU.
Bấm "Kiểm tra kết nối" trong app rồi ĐỐI CHIẾU fingerprint hiển thị với dòng
"Public key fingerprint" in ra ở terminal/log Colab bên dưới trước khi tin
tưởng gửi bất kỳ ảnh nào.
"""

import argparse
import asyncio
import base64
import ctypes
import gc
import hashlib
import io
import json
import os
import time
from typing import Optional

import uvicorn
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding as rsa_padding
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from fastapi import FastAPI, Header, HTTPException
from PIL import Image, ImageDraw
from pydantic import BaseModel

# ── Cấu hình từ CLI — KHÔNG hardcode auth token trong source, tự đặt lúc chạy ──
_arg_parser = argparse.ArgumentParser()
_arg_parser.add_argument("--auth-token", required=True,
    help="Bearer token app phải gửi kèm mỗi request — tự đặt 1 chuỗi ngẫu nhiên đủ dài, không chia sẻ công khai")
_arg_parser.add_argument("--model", default="runwayml/stable-diffusion-v1-5",
    help="Model MẶC ĐỊNH dùng khi app không gửi model_id — HuggingFace repo id hoặc path checkpoint local. Đổi được NGAY TỪ APP (Cài đặt > Remote GPU) mà không cần khởi động lại server, xem docstring 'ĐỔI MODEL' ở trên.")
_arg_parser.add_argument("--model-type", default="sd15", choices=["sd15", "sdxl"],
    help="Kiến trúc của --model ở trên (mặc định khi app không gửi model_type)")
_arg_parser.add_argument("--port", type=int, default=8000)
_arg_parser.add_argument("--host", default="0.0.0.0")
_arg_parser.add_argument("--loras-dir", default="./loras",
    help="Thư mục chứa file LoRA .safetensors (CHỈ áp dụng SD1.5) — ĐỒNG BỘ TRƯỚC từ MangaLocal/loras/ trên điện thoại (Google Drive mount khuyến nghị trên Colab, xem README.md)")
_arg_parser.add_argument("--controlnet-model", default="lllyasviel/control_v11p_sd15_openpose",
    help="ControlNet-Pose cho SD1.5 — chỉ nạp lúc có request cần pose")
_arg_parser.add_argument("--ipadapter-repo", default="h94/IP-Adapter",
    help="Repo HuggingFace chứa weight IP-Adapter (dùng chung cho cả 2 kiến trúc, khác subfolder/tên file)")
_arg_parser.add_argument("--ipadapter-weight", default="ip-adapter_sd15.bin",
    help="Tên file weight IP-Adapter cho SD1.5 trong repo trên")
_arg_parser.add_argument("--controlnet-model-sdxl", default="thibaud/controlnet-openpose-sdxl-1.0",
    help="ControlNet-Pose cho SDXL — KHÁC HẲN checkpoint SD1.5, không dùng chung được")
_arg_parser.add_argument("--ipadapter-weight-sdxl", default="ip-adapter_sdxl.bin",
    help="Tên file weight IP-Adapter cho SDXL (nằm trong subfolder sdxl_models/ của --ipadapter-repo)")
_arg_parser.add_argument("--max-queue-depth", type=int, default=3,
    help="Số request TỐI ĐA được xếp hàng chờ (kể cả request đang chạy) — quá số này server trả lỗi 429 ngay thay vì nhận thêm, tránh APK gửi dồn dập làm RAM/VRAM tăng không kiểm soát")
_arg_parser.add_argument("--min-request-interval", type=float, default=1.0,
    help="Khoảng cách tối thiểu (giây) giữa 2 lần BẮT ĐẦU chạy generate thật — chặn spam dồn dập ngay cả khi trong giới hạn hàng đợi")
_arg_parser.add_argument("--idle-cleanup-seconds", type=int, default=300,
    help="Sau chừng này giây KHÔNG có request nào, tự gỡ LoRA đang nạp + giải phóng VRAM cache — giảm tải tài nguyên lúc không ai dùng. 0 = tắt tính năng này.")
_arg_parser.add_argument("--max-uptime-hours", type=float, default=0.0,
    help="Tự đóng server sau chừng này giờ kể từ lúc khởi động — phòng trường hợp quên tắt, tránh giữ tài nguyên vô thời hạn không cần thiết. 0 = tắt (mặc định), chạy vô thời hạn như trước.")
_arg_parser.add_argument("--svd-model-id", default="stabilityai/stable-video-diffusion-img2vid-xt",
                         help="mục 249: model image-to-video (Stable Video Diffusion) cho payload task=video. KIỂM TRA giấy phép "
                              "của model trước khi dùng; có thể cần đăng nhập Hugging Face và chấp nhận điều khoản.")
_arg_parser.add_argument("--keep-svd", action="store_true",
                         help="mục 249: giữ pipeline video trong bộ nhớ giữa các request (nhanh hơn, nhưng chiếm RAM/VRAM). "
                              "Mặc định: tải mỗi lần và giải phóng ngay sau khi xong.")
_arg_parser.add_argument("--inswapper-path", default="",
                         help="mục 250: đường dẫn inswapper_128.onnx cho tác vụ faceswap. File này KHÔNG đi kèm insightface, phải tải riêng; "
                              "trọng số insightface chỉ cho nghiên cứu/phi thương mại — người dùng tự chịu trách nhiệm tuân thủ giấy phép.")
_arg_parser.add_argument("--handrefiner-cn-path", default="",
                         help="mục 250: đường dẫn control_sd15_inpaint_depth_hand_fp16.safetensors (HandRefiner). Để trống = tự tải từ "
                              "hr16/ControlNet-HandRefiner-pruned.")
_arg_parser.add_argument("--kontext-model-id", default="black-forest-labs/FLUX.1-Kontext-dev",
                         help="mục 250: model chỉnh ảnh cho tác vụ kontext (12 tỷ tham số, giấy phép PHI THƯƠNG MẠI, cần chấp nhận điều khoản "
                              "trên Hugging Face). Nạp 4-bit NF4 + offload CPU để vừa ~16 GB VRAM.")
_arg_parser.add_argument("--keep-kontext", action="store_true",
                         help="mục 250: giữ pipeline Kontext trong bộ nhớ giữa các request (mặc định: giải phóng sau mỗi request).")
_arg_parser.add_argument("--controlnet-aux-src", default="",
                         help="mục 251: thư mục `src` của repo Fannovel16/comfyui_controlnet_aux (chứa custom_controlnet_aux/mesh_graphormer). "
                              "Gói controlnet_aux trên PyPI KHÔNG có MeshGraphormerDetector — cần bản fork này cho tác vụ handfix.")
_arg_parser.add_argument("--interact-model-id", default="interactdiffusion/diffusers-v1-2",
                         help="mục 251: model InteractDiffusion (SD1.5 + GLIGEN-style, giấy phép BSD theo trang HF) cho tác vụ interact. "
                              "Nạp bằng trust_remote_code=True => chạy MÃ tải từ Hugging Face trên server của bạn.")
_arg_parser.add_argument("--interact-revision", default="",
                         help="mục 251: ghim commit của model InteractDiffusion (khuyến nghị khi dùng trust_remote_code).")
_arg_parser.add_argument("--keep-interact", action="store_true",
                         help="mục 251: giữ pipeline InteractDiffusion trong bộ nhớ giữa các request.")
args = _arg_parser.parse_args()

os.makedirs(args.loras_dir, exist_ok=True)

# ── RSA keypair ephemeral (xem docstring đầu file) ──────────────────────────
def _zero_bytearray(buf) -> None:
    """Ghi đè 0x00 lên TOÀN BỘ buffer trước khi del/để GC dọn — best-effort,
    CHỈ áp dụng được cho bytearray thật (mutable, có buffer protocol).

    GIỚI HẠN THẬT (đọc kỹ, đừng tưởng đây là xoá RAM tuyệt đối):
    - str và bytes trong Python là IMMUTABLE — không có cách an toàn nào
      ghi đè tại chỗ mà không có rủi ro làm hỏng interpreter (CPython có
      thể intern/cache chuỗi ngắn, ghi đè bừa qua ctypes có thể ảnh hưởng
      object KHÁC đang trỏ chung vùng nhớ). Vì vậy `prompt`/`negative_prompt`
      (str) chỉ `del` được, KHÔNG zero được — đây là giới hạn ngôn ngữ, gọi
      `del` xong vẫn phải chờ garbage collector thật sự thu hồi.
    - Ngay cả với bytearray zero được: các thư viện bên dưới (json, base64,
      cryptography...) có thể đã tự tạo thêm bản sao plaintext tạm thời
      trong lúc xử lý (vd base64.b64decode trả về bytes MỚI, không phải
      view lên buffer gốc) — những bản sao đó KHÔNG nằm trong tầm kiểm soát
      của code này, chỉ có thể chờ GC dọn tự nhiên.
    - gc.collect() ép Python thu hồi ngay lập tức các object không còn
      tham chiếu, NHƯNG không đảm bảo hệ điều hành/kernel zero hoá trang bộ
      nhớ vật lý đã giải phóng — trang đó có thể còn giữ dữ liệu cũ cho tới
      khi bị cấp phát lại và ghi đè bởi tiến trình khác.
    Tóm lại: đây là lớp phòng thủ BỔ SUNG hợp lý (giảm THỜI GIAN dữ liệu tồn
    tại ở dạng dễ đọc), KHÔNG phải giải pháp triệt để — threat model thật sự
    (chủ hạ tầng có quyền truy cập hypervisor) vẫn không bị chặn bởi kỹ
    thuật này, xem docstring đầu file.
    """
    if buf:
        ctypes.memset((ctypes.c_char * len(buf)).from_buffer(buf), 0, len(buf))


_private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
_public_key_der = _private_key.public_key().public_bytes(
    encoding=serialization.Encoding.DER,
    format=serialization.PublicFormat.SubjectPublicKeyInfo,
)
_fp_hex = hashlib.sha256(_public_key_der).hexdigest().upper()
_fingerprint_display = ":".join(_fp_hex[i:i + 2] for i in range(0, len(_fp_hex), 2))

print("=" * 72)
print("MangaLocal Remote Server — khởi động")
print(f"Model mặc định: {args.model} ({args.model_type})")
print(f"LoRA dir: {args.loras_dir}")
print("Public key fingerprint (đối chiếu với app TRƯỚC KHI tin tưởng):")
print(f"  {_fingerprint_display}")
print("=" * 72)

# ── OpenPose COCO-18 render — Y HỆT app/src/main/jni/ip_adapter.cpp ─────────
# (kBonePairs/kBoneColors) để ảnh điều kiện ControlNet-Pose khớp đúng convention
# model đã học, nhất quán với panel nào lỡ rơi về local render.
_BONE_PAIRS = [
    (1, 2), (1, 5), (2, 3), (3, 4), (5, 6), (6, 7), (1, 8), (8, 9), (9, 10),
    (1, 11), (11, 12), (12, 13), (1, 0), (0, 14), (14, 16), (0, 15), (15, 17),
]
_BONE_COLORS = [
    (255, 0, 0), (255, 85, 0), (255, 170, 0), (255, 255, 0), (170, 255, 0), (85, 255, 0),
    (0, 255, 0), (0, 255, 85), (0, 255, 170), (0, 255, 255), (0, 170, 255), (0, 85, 255),
    (0, 0, 255), (85, 0, 255), (170, 0, 255), (255, 0, 255), (255, 0, 170),
]


def render_skeleton_image(flat_data: list, size: int = 512) -> Image.Image:
    """flat_data: mảng float phẳng, mỗi người 18 khớp * 4 giá trị (x,y,z,visible)
    — ĐÚNG format Kotlin (PoseRetargeter) gửi cho native, xem
    parseSkeletonsFromFloatArray trong ip_adapter.cpp. Trả về ảnh RGB nền đen,
    khung xương vẽ đè lên (dùng làm ảnh điều kiện cho ControlNetModel)."""
    stride = 18 * 4
    n = len(flat_data)
    canvas = Image.new("RGB", (size, size), (0, 0, 0))
    if n <= 0 or n % stride != 0:
        return canvas
    draw = ImageDraw.Draw(canvas)
    num_people = n // stride
    people = []
    for p in range(num_people):
        kps = []
        for k in range(18):
            base = p * stride + k * 4
            kps.append((flat_data[base], flat_data[base + 1], flat_data[base + 2], flat_data[base + 3] > 0.5))
        people.append(kps)
    def avg_z(kps):
        vis = [z for (_, _, z, v) in kps if v]
        return sum(vis) / len(vis) if vis else 0.0
    people.sort(key=avg_z, reverse=True)  # xa vẽ trước, gần vẽ đè lên sau — giống native

    width_px = max(3, size // 100)
    for kps in people:
        for idx, (a, b) in enumerate(_BONE_PAIRS):
            xa, ya, _, va = kps[a]
            xb, yb, _, vb = kps[b]
            if not (va and vb):
                continue
            color = _BONE_COLORS[idx % len(_BONE_COLORS)]
            draw.line([(xa * size, ya * size), (xb * size, yb * size)], fill=color, width=width_px)
    return canvas


# ── Quản lý model ĐỘNG — đổi TRƯỚC khi bắt đầu 1 chương (không phải giữa
# panel), xem docstring "ĐỔI MODEL" đầu file. Không giữ nhiều checkpoint gốc
# cùng lúc trong VRAM (Colab free giới hạn) — đổi là GIẢI PHÓNG cái cũ trước.
_base_pipe = None
_cn_pipe = None
_current_model_id: Optional[str] = None
_current_model_type: Optional[str] = None
_ipadapter_loaded_on = set()   # id() của pipe object đã load IP-Adapter — reset lúc đổi model
_current_lora_id: Optional[str] = None
_current_lora_pipe_id: Optional[int] = None


def _torch_dtype():
    import torch
    return torch.float16 if torch.cuda.is_available() else torch.float32


def ensure_base_model(requested_model_id: Optional[str], requested_model_type: Optional[str]):
    """Load lại checkpoint gốc CHỈ KHI khác lần trước — gọi ở ĐẦU mỗi request,
    nhưng trong 1 chương/truyện thường mọi panel gửi CÙNG model_id nên hàm
    này gần như luôn no-op (rẻ), CHỈ thực sự tải lại lúc đổi sang
    chương/nhân vật dùng model khác — đúng ý "đổi trước khi bắt đầu công
    việc", không phải "đổi giữa chừng từng panel"."""
    global _base_pipe, _cn_pipe, _current_model_id, _current_model_type
    global _ipadapter_loaded_on, _current_lora_id, _current_lora_pipe_id

    model_id = requested_model_id or args.model
    model_type = (requested_model_type or args.model_type).lower()
    if model_type not in ("sd15", "sdxl"):
        print(f"[warn] model_type '{model_type}' không nhận diện được, dùng 'sd15'")
        model_type = "sd15"

    if _base_pipe is not None and model_id == _current_model_id and model_type == _current_model_type:
        return  # giống hệt lần trước — đa số các panel trong 1 chương rơi vào đây

    import torch
    print(f"Đổi model base: '{model_id}' ({model_type}) — có thể mất vài phút, "
          f"CHỈ xảy ra khi thật sự đổi model (đầu chương/nhân vật mới), không phải mỗi panel...")

    # Giải phóng model CŨ trước khi load model MỚI — không giữ 2 checkpoint
    # gốc cùng lúc trong VRAM (đặc biệt quan trọng nếu SDXL, ~7-8GB/checkpoint).
    if _base_pipe is not None:
        del _base_pipe
    if _cn_pipe is not None:
        del _cn_pipe
    _base_pipe = None
    _cn_pipe = None
    _ipadapter_loaded_on = set()
    _current_lora_id = None
    _current_lora_pipe_id = None
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    dtype = _torch_dtype()
    if model_type == "sdxl":
        from diffusers import StableDiffusionXLPipeline
        try:
            _base_pipe = StableDiffusionXLPipeline.from_pretrained(
                model_id, torch_dtype=dtype, variant="fp16" if dtype == torch.float16 else None,
                use_safetensors=True,
            )
        except Exception:
            # Không phải checkpoint nào cũng có variant "fp16" riêng — thử lại
            # không ép variant nếu lần đầu lỗi (vd finetune tự host không tách variant).
            _base_pipe = StableDiffusionXLPipeline.from_pretrained(model_id, torch_dtype=dtype)
    else:
        from diffusers import StableDiffusionPipeline
        _base_pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=dtype, safety_checker=None)

    _base_pipe = _base_pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    _current_model_id = model_id
    _current_model_type = model_type
    print(f"✓ Model base đã load: '{model_id}' ({model_type})")


def build_pag_pipe(pipe):
    """mục 248 — Perturbed-Attention Guidance (PAG) qua diffusers: `AutoPipelineForText2Image.from_pipe(pipe,
    enable_pag=True, pag_applied_layers=["mid"])` dùng CHUNG UNet/VAE/CLIP với `pipe` (không tải lại trọng số). Docs diffusers
    xác nhận API này, kể cả khi `pipe` là pipeline ControlNet; `pag_scale=0` = tắt.
    KHÔNG cache: IP-Adapter/LoRA được nạp lên `pipe` SAU khi pipeline PAG cũ được dựng thì pipeline cũ thiếu thành phần
    (image_encoder...) — dựng lại mỗi request rẻ vì chỉ gắn lại tham chiếu thành phần.
    Trả None nếu không dựng được -> caller chạy KHÔNG PAG (không làm hỏng request)."""
    try:
        from diffusers import AutoPipelineForText2Image
        return AutoPipelineForText2Image.from_pipe(pipe, enable_pag=True, pag_applied_layers=["mid"])
    except Exception as e:
        print(f"[warn] PAG không dựng được ({e}) — chạy KHÔNG PAG")
        return None


def get_controlnet_pipe():
    """Build ControlNet-Pose pipe cho ĐÚNG kiến trúc đang active
    (_current_model_type) — dùng from_pipe() để chia sẻ UNet/VAE/CLIP với
    _base_pipe (đỡ tốn VRAM). Cache theo model hiện tại — reset về None mỗi
    lúc đổi model ở ensure_base_model(), nên không lo dùng nhầm ControlNet
    của kiến trúc cũ."""
    global _cn_pipe
    if _cn_pipe is not None:
        return _cn_pipe
    import torch
    if _current_model_type == "sdxl":
        from diffusers import ControlNetModel, StableDiffusionXLControlNetPipeline
        print(f"Đang load ControlNet-Pose SDXL ({args.controlnet_model_sdxl})...")
        controlnet = ControlNetModel.from_pretrained(args.controlnet_model_sdxl, torch_dtype=_torch_dtype())
        _cn_pipe = StableDiffusionXLControlNetPipeline.from_pipe(_base_pipe, controlnet=controlnet)
    else:
        from diffusers import ControlNetModel, StableDiffusionControlNetPipeline
        print(f"Đang load ControlNet-Pose SD1.5 ({args.controlnet_model})...")
        controlnet = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=_torch_dtype())
        _cn_pipe = StableDiffusionControlNetPipeline.from_pipe(_base_pipe, controlnet=controlnet)
    _cn_pipe = _cn_pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    print("✓ ControlNet-Pose đã load")
    return _cn_pipe


def ensure_ip_adapter(pipe):
    """Nạp IP-Adapter đúng kiến trúc đang active, lên ĐÚNG pipe object sẽ
    dùng để generate — chỉ 1 lần/pipe (idempotent qua _ipadapter_loaded_on)."""
    key = id(pipe)
    if key in _ipadapter_loaded_on:
        return
    if _current_model_type == "sdxl":
        print(f"Đang load IP-Adapter SDXL ({args.ipadapter_repo})...")
        pipe.load_ip_adapter(args.ipadapter_repo, subfolder="sdxl_models", weight_name=args.ipadapter_weight_sdxl)
    else:
        print(f"Đang load IP-Adapter SD1.5 ({args.ipadapter_repo})...")
        pipe.load_ip_adapter(args.ipadapter_repo, subfolder=None, weight_name=args.ipadapter_weight)
    _ipadapter_loaded_on.add(key)
    print("✓ IP-Adapter đã load")


def apply_lora(pipe, lora_id: Optional[str]):
    """Nạp/gỡ LoRA ĐỘNG theo từng request — CHỈ áp dụng SD1.5 (LoRA train
    cho SD1.5 không tương thích SDXL, kiến trúc UNet khác hẳn). KHÔNG giữ
    nhiều LoRA cùng lúc trong VRAM."""
    global _current_lora_id, _current_lora_pipe_id
    if _current_model_type == "sdxl":
        if lora_id:
            print(f"[warn] lora_id='{lora_id}' bị bỏ qua — đang ở SDXL, LoRA SD1.5 không tương thích")
        return
    if lora_id == _current_lora_id and id(pipe) == _current_lora_pipe_id:
        return  # đã đúng LoRA cần dùng rồi, khỏi làm lại (panel liên tiếp cùng nhân vật)
    if _current_lora_id is not None and _current_lora_pipe_id == id(pipe):
        try:
            pipe.unload_lora_weights()
        except Exception as e:
            print(f"[warn] unload_lora_weights lỗi (bỏ qua, tiếp tục nạp LoRA mới): {e}")
    if lora_id:
        lora_path = os.path.join(args.loras_dir, f"{lora_id}.safetensors")
        if not os.path.isfile(lora_path):
            raise HTTPException(status_code=400,
                detail=f"Không tìm thấy LoRA '{lora_id}' tại {lora_path} trên server — "
                       f"đồng bộ file .safetensors này lên {args.loras_dir}/ trước (xem README.md).")
        print(f"Đang nạp LoRA: {lora_id}")
        pipe.load_lora_weights(lora_path)
    _current_lora_id = lora_id
    _current_lora_pipe_id = id(pipe)


app = FastAPI(title="MangaLocal Remote Server")

# ── Hàng đợi + giới hạn tần suất — CHỐNG APK GỬI DỒN DẬP LÀM GPU/RAM 100% ──
# 2 lớp bảo vệ độc lập, cả 2 đều cần cho đúng ý "APK gửi cái nào mới làm cái
# đó, không dồn dập":
#   1. Hàng đợi CÓ GIỚI HẠN (_MAX_QUEUE_DEPTH request đang chờ+chạy) — vượt
#      quá thì trả lỗi 429 NGAY LẬP TỨC thay vì nhận vô hạn request rồi để
#      RAM tăng dần chờ xử lý (APK/BackendRouter phía Kotlin nên coi 429 là
#      tín hiệu "thử lại sau", KHÔNG phải lỗi cứng).
#   2. CHỈ 1 generate chạy GPU thật tại 1 thời điểm (asyncio.Semaphore(1)) —
#      tự nhiên đúng với 1 GPU vật lý (Colab/RunPod thường chỉ có 1 GPU),
#      tránh 2 request cùng lúc tranh VRAM gây OOM.
#   3. Khoảng cách tối thiểu giữa 2 lần BẮT ĐẦU generate thật
#      (--min-request-interval) — chặn spam ngay cả khi hàng đợi còn chỗ.
_MAX_QUEUE_DEPTH = args.max_queue_depth
_queue_depth = 0
_queue_depth_lock = asyncio.Lock()
_generation_semaphore = asyncio.Semaphore(1)
_last_generation_start = 0.0

# ── Dọn dẹp tài nguyên lúc rảnh + tự đóng sau thời lượng dài — QUẢN LÝ TÀI
# NGUYÊN TỐT, không phải kỹ thuật né tránh gì: giữ VRAM/LoRA nạp sẵn khi
# không ai dùng là lãng phí thật, và quên tắt server chạy vô thời hạn cũng
# là lãng phí thật — cả 2 đều đáng tự động xử lý bất kể chạy ở đâu.
_server_start_time = time.monotonic()
_last_activity_time = time.monotonic()  # cập nhật mỗi lần generate() xử lý xong


async def _maintenance_loop():
    """Task nền chạy suốt vòng đời server — kiểm tra định kỳ (mỗi 30 giây):
    (1) đã rảnh đủ lâu (--idle-cleanup-seconds) thì gỡ LoRA + giải phóng
    VRAM cache đang giữ không cần thiết; (2) đã chạy đủ lâu
    (--max-uptime-hours) thì tự đóng server gọn gàng. Cả 2 đều TẮT theo mặc
    định (idle-cleanup bật sẵn ở mức hợp lý 300s, uptime-limit tắt hẳn =
    0) — không tự ý thay đổi hành vi nếu user không đặt."""
    global _current_lora_id, _current_lora_pipe_id
    while True:
        await asyncio.sleep(30)
        now = time.monotonic()

        if args.idle_cleanup_seconds > 0 and (now - _last_activity_time) > args.idle_cleanup_seconds:
            if _current_lora_id is not None or _base_pipe is not None:
                try:
                    import torch
                    if _current_lora_id is not None and _base_pipe is not None:
                        print(f"[maintenance] Rảnh > {args.idle_cleanup_seconds}s — gỡ LoRA '{_current_lora_id}' đang giữ")
                        try:
                            _base_pipe.unload_lora_weights()
                        except Exception:
                            pass
                        _current_lora_id = None
                        _current_lora_pipe_id = None
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                    gc.collect()
                except Exception as e:
                    print(f"[maintenance] dọn dẹp lỗi (bỏ qua): {e}")
            # Đặt lại mốc để không lặp lại dọn dẹp mỗi 30s khi đã rảnh xong 1 lần
            _last_activity_time = now

        if args.max_uptime_hours > 0 and (now - _server_start_time) > args.max_uptime_hours * 3600:
            print(f"[maintenance] Đã chạy quá {args.max_uptime_hours} giờ (--max-uptime-hours) — tự đóng server. "
                  f"Chạy lại notebook/cell nếu cần tiếp tục (sẽ có URL/fingerprint MỚI, cập nhật lại trong app).")
            os._exit(0)  # thoát thẳng, đơn giản và chắc chắn hơn cố gọi uvicorn.Server.should_exit từ task nền


@app.on_event("startup")
async def _start_maintenance_task():
    asyncio.create_task(_maintenance_loop())


class GenerateRequest(BaseModel):
    wrapped_key_b64: str   # AES-256 key, đã bọc bằng RSA-OAEP public key của server
    iv_b64: str             # IV cho AES-GCM (chiều gửi lên)
    ciphertext_b64: str     # payload JSON đã mã hoá AES-GCM (xem field trong plaintext, docstring đầu file)


@app.get("/pubkey")
def pubkey():
    """App gọi 1 lần lúc bấm 'Kiểm tra kết nối' — lấy public key + tính fingerprint để user tự đối chiếu (TOFU)."""
    return {"public_key_der_b64": base64.b64encode(_public_key_der).decode()}


_svd_pipe = None


def _run_video_sync(payload: dict) -> bytes:
    """mục 249 — ẢNH -> CLIP NGẮN (mp4) bằng Stable Video Diffusion qua diffusers (payload `task` = "video").

    Cách chạy theo tài liệu diffusers/cộng đồng đã tra cứu: fp16 + enable_model_cpu_offload() + decode_chunk_size nhỏ để vừa
    Colab T4 16 GB. Ảnh được ĐẶT VÀO khung 1024x576 giữ nguyên tỉ lệ (nền đen) — SVD huấn luyện ở độ phân giải này, KHÔNG cắt
    ảnh. Trả bytes mp4 (client kiểm tra 'ftyp').
    GIỚI HẠN THẬT: chưa chạy với GPU/diffusers thật ở đây (test chạy hàm này với diffusers GIẢ); mã hoá mp4 do
    `diffusers.utils.export_to_video` quyết định (cần thư viện video đi kèm); giấy phép model cần tự kiểm tra; một request có
    thể mất nhiều phút; chuyển động do model tự nghĩ — không điều khiển được bằng prompt."""
    import tempfile
    import torch
    from diffusers import StableVideoDiffusionPipeline
    from diffusers.utils import export_to_video

    global _svd_pipe
    image_b64 = payload.get("image_b64")
    if not image_b64:
        raise ValueError("task=video thiếu image_b64")
    num_frames = max(6, min(25, int(payload.get("num_frames", 14))))
    fps = max(3, min(30, int(payload.get("fps", 7))))
    motion = max(1, min(255, int(payload.get("motion_bucket_id", 127))))
    noise = max(0.0, min(1.0, float(payload.get("noise_aug_strength", 0.02))))
    decode_chunk = max(1, min(8, int(payload.get("decode_chunk_size", 2))))
    seed = payload.get("seed", -1)
    width = max(256, min(1024, int(payload.get("width", 1024)) // 8 * 8))
    height = max(256, min(1024, int(payload.get("height", 576)) // 8 * 8))

    src = Image.open(io.BytesIO(base64.b64decode(image_b64))).convert("RGB")
    scale = min(width / src.width, height / src.height)
    nw, nh = max(1, int(round(src.width * scale))), max(1, int(round(src.height * scale)))
    canvas = Image.new("RGB", (width, height), (0, 0, 0))
    canvas.paste(src.resize((nw, nh), Image.LANCZOS), ((width - nw) // 2, (height - nh) // 2))

    pipe = _svd_pipe
    if pipe is None:
        pipe = StableVideoDiffusionPipeline.from_pretrained(args.svd_model_id, torch_dtype=torch.float16, variant="fp16")
        pipe.enable_model_cpu_offload()
        if args.keep_svd:
            _svd_pipe = pipe
    try:
        generator = torch.manual_seed(int(seed)) if seed is not None and int(seed) >= 0 else None
        frames = pipe(canvas, decode_chunk_size=decode_chunk, num_frames=num_frames, fps=fps,
                      motion_bucket_id=motion, noise_aug_strength=noise, generator=generator).frames[0]
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "clip.mp4")
            export_to_video(frames, path, fps=fps)
            with open(path, "rb") as f:
                data = f.read()
    finally:
        if not args.keep_svd:
            _svd_pipe = None
            del pipe
            gc.collect()
            try:
                torch.cuda.empty_cache()
            except Exception:
                pass
    return data


# ============================================================================================================
# mục 250 — TÁC VỤ HẬU KỲ TRÊN SERVER (payload `task`): faceswap / handfix / kontext. Cùng đường mã hoá/hàng đợi với /generate;
# phản hồi có trường `task` (echo) để client phân biệt với server CŨ (server cũ gặp task lạ sẽ lặng lẽ sinh ảnh ngẫu nhiên).
# Mọi trọng số bên dưới có thể mang giấy phép PHI THƯƠNG MẠI (insightface/inswapper, FLUX.1 Kontext [dev]) — xem README.
# ============================================================================================================
def _decode_rgb(b64: str) -> Image.Image:
    return Image.open(io.BytesIO(base64.b64decode(b64))).convert("RGB")


def _png_bytes(img: Image.Image, report=None) -> bytes:
    """PNG; `report` (dict) được nhúng vào khối tEXt khoá "mangalocal_report" (JSON ASCII) để app đọc và hiển thị."""
    buf = io.BytesIO()
    if report is not None:
        import json
        from PIL.PngImagePlugin import PngInfo
        info = PngInfo()
        info.add_text("mangalocal_report", json.dumps(report, ensure_ascii=True, default=float))   # default=float: số numpy (float32...) không tự serialize
        img.save(buf, format="PNG", pnginfo=info)
    else:
        img.save(buf, format="PNG")
    return buf.getvalue()


def _box_iou(a, b) -> float:
    ix1, iy1, ix2, iy2 = max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])
    iw, ih = max(0.0, ix2 - ix1), max(0.0, iy2 - iy1)
    inter = iw * ih
    union = max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1]) + max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1]) - inter
    return inter / union if union > 0 else 0.0


def _assign_faces(face_boxes, target_boxes, min_iou: float = 0.05):
    """Ghép MỘT-MỘT mặt dò được với hộp đầu mong đợi, tham lam theo điểm giảm dần. Điểm = IoU, cộng 0.5 nếu TÂM mặt nằm trong hộp
    đích; IoU nhỏ hơn min_iou mà tâm vẫn nằm trong hộp thì cho điểm thấp (min_iou/2) thay vì loại. Trả [(chỉ số đích, chỉ số mặt)]."""
    cands = []
    for ti, tb in enumerate(target_boxes):
        for fi, fb in enumerate(face_boxes):
            iou = _box_iou(fb, tb)
            cx, cy = (fb[0] + fb[2]) / 2.0, (fb[1] + fb[3]) / 2.0
            inside = tb[0] <= cx <= tb[2] and tb[1] <= cy <= tb[3]
            if iou >= min_iou:
                score = iou + (0.5 if inside else 0.0)
            elif inside:
                score = min_iou / 2.0
            else:
                continue
            cands.append((score, ti, fi))
    cands.sort(key=lambda c: (-c[0], c[1], c[2]))
    used_t, used_f, out = set(), set(), []
    for _score, ti, fi in cands:
        if ti in used_t or fi in used_f:
            continue
        used_t.add(ti)
        used_f.add(fi)
        out.append((ti, fi))
    return out


# ---- mục 251: bảo vệ BIỂU CẢM và TỈ LỆ cho faceswap -------------------------------------------------------------------------
# Tra cứu (mục 251): inswapper_128 chỉ xuất mặt 128x128 rồi dán lại, KHÔNG có gì bảo đảm biểu cảm; cộng đồng chữa bằng mặt nạ vùng (giữ
# miệng/mắt gốc, kiểu FaceFusion "Box+Region") và khôi phục mặt; góc nghiêng lớn (~90°) hỏng. Ở đây: đo biểu cảm bằng landmark_3d_68
# (bố cục iBUG 68 chuẩn: mắt phải 36-41, mắt trái 42-47, lông mày 17-26, miệng ngoài 48-59, miệng trong 60-67) TRƯỚC và SAU khi hoán đổi;
# lệch quá ngưỡng -> khôi phục miệng/mắt/lông mày gốc rồi đo lại; vẫn lệch -> HOÀN NGUYÊN mặt đó. NGƯỠNG LÀ ƯỚC LƯỢNG, CHƯA hiệu chỉnh.
EXPR_TOL = {"ear": 0.07, "mar": 0.10, "mouth_w": 0.12, "brow": 0.10}
# mục 258 — che khuất & khôi phục mặt (cả hai TUỲ CHỌN, mặc định tắt). Ngưỡng là ƯỚC LƯỢNG chưa đo trên ảnh thật.
OCCLUSION_SKIP_FRACTION = 0.85   # mặt bị vật che (tay…) quá tỉ lệ diện tích hộp này -> bỏ qua hoán đổi (không còn mặt để thay)
RESTORE_STRENGTH_DEFAULT = 0.7   # trộn kết quả khôi phục mặt (GFPGAN) với ảnh hiện tại, 0..1
_gfpgan = None
PROPORTION_TOL = 0.12        # |bề rộng mặt sau / trước - 1|
CENTER_SHIFT_TOL = 0.08      # dịch tâm mặt / bề rộng mặt
HEAD_SHOULDER_BAND = (0.25, 0.60)   # bề rộng khung mặt / bề rộng vai (khung xương). ANSUR II: bizygomatic/biacromial ~0.35-0.37 -> dải rộng, chỉ CẢNH BÁO
YAW_MAX_DEG = 55.0           # mặt quay quá góc này: bỏ qua (cộng đồng: ~45° còn dùng được, ~90° hỏng)


def _ear(eye) -> float:
    import math
    d = lambda a, b: math.hypot(a[0] - b[0], a[1] - b[1])
    return (d(eye[1], eye[5]) + d(eye[2], eye[4])) / (2.0 * max(d(eye[0], eye[3]), 1e-6))


def _mar(lm) -> float:
    import math
    m = lm[60:68]
    d = lambda a, b: math.hypot(a[0] - b[0], a[1] - b[1])
    return (d(m[1], m[7]) + d(m[2], m[6]) + d(m[3], m[5])) / (3.0 * max(d(m[0], m[4]), 1e-6))


def _expression_metrics(lm) -> dict:
    import math
    import numpy as np
    lm = np.asarray(lm, dtype=float)
    re_, le_ = lm[36:42], lm[42:48]
    rc, lc = re_.mean(axis=0), le_.mean(axis=0)
    iod = max(math.hypot(rc[0] - lc[0], rc[1] - lc[1]), 1e-6)
    return {"ear_r": _ear(re_), "ear_l": _ear(le_), "mar": _mar(lm),
            "mouth_w": math.hypot(lm[48][0] - lm[54][0], lm[48][1] - lm[54][1]) / iod,
            "brow_r": float(rc[1] - lm[17:22, 1].mean()) / iod, "brow_l": float(lc[1] - lm[22:27, 1].mean()) / iod}


def _expression_deviation(a: dict, b: dict):
    dev = {"ear": max(abs(a["ear_r"] - b["ear_r"]), abs(a["ear_l"] - b["ear_l"])), "mar": abs(a["mar"] - b["mar"]),
           "mouth_w": abs(a["mouth_w"] - b["mouth_w"]), "brow": max(abs(a["brow_r"] - b["brow_r"]), abs(a["brow_l"] - b["brow_l"]))}
    return dev, [k for k, v in dev.items() if v > EXPR_TOL[k]]


def _convex_hull(points):
    pts = sorted(set((float(x), float(y)) for x, y in points))
    if len(pts) <= 2:
        return pts
    cross = lambda o, a, b: (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def _region_mask(size_wh, lm, face_w: float, grow: float = 0.12, feather: float = 0.08):
    """Mặt nạ mềm phủ MIỆNG + hai MẮT kèm lông mày (đa giác lồi từ landmark 68), nở thêm `grow`·bề rộng mặt, làm mờ `feather`·bề rộng mặt."""
    from PIL import ImageDraw, ImageFilter
    W, H = size_wh
    mask = Image.new("L", (W, H), 0)
    dr = ImageDraw.Draw(mask)
    for idx in (list(range(48, 60)), list(range(36, 42)) + list(range(17, 22)), list(range(42, 48)) + list(range(22, 27))):
        poly = _convex_hull([(lm[i][0], lm[i][1]) for i in idx])
        if len(poly) >= 3:
            dr.polygon(poly, fill=255)
    g = max(3, int(round(face_w * grow)))
    g = g if g % 2 == 1 else g + 1
    soft = mask.filter(ImageFilter.MaxFilter(g)).filter(ImageFilter.GaussianBlur(max(1.0, face_w * feather)))
    return soft.point(lambda v: min(255, int(v * 1.3)))   # tăng độ bão hoà: phần lõi miệng/mắt phải khôi phục ĐỦ (làm mờ thuần tuý chỉ đạt ~0.89), biên vẫn mềm


def _restore_regions(original_bgr, swapped_bgr, lm, face_w: float):
    import numpy as np
    H, W = original_bgr.shape[:2]
    m = np.asarray(_region_mask((W, H), lm, face_w), dtype=np.float32)[:, :, None] / 255.0
    out = original_bgr.astype(np.float32) * m + swapped_bgr.astype(np.float32) * (1.0 - m)
    return np.clip(out, 0, 255).astype(np.uint8)


def _lm68(face):
    import numpy as np
    lm = getattr(face, "landmark_3d_68", None)
    if lm is None:
        return None
    lm = np.asarray(lm, dtype=float)
    return lm[:, :2] if lm.ndim == 2 and lm.shape[0] >= 68 else None


def _best_face(faces, bbox, min_iou: float = 0.3):
    best, best_iou = None, 0.0
    for f in faces:
        v = _box_iou(tuple(float(x) for x in f.bbox[:4]), tuple(float(x) for x in bbox[:4]))
        if v > best_iou:
            best, best_iou = f, v
    return best if best_iou >= min_iou else None


_face_app = None
_face_swapper = None


def _get_face_tools():
    global _face_app, _face_swapper
    import insightface
    from insightface.app import FaceAnalysis
    if _face_app is None:
        fa = FaceAnalysis(name="buffalo_l", providers=["CUDAExecutionProvider", "CPUExecutionProvider"])
        fa.prepare(ctx_id=0, det_size=(640, 640))
        _face_app = fa
    if _face_swapper is None:
        path = args.inswapper_path
        if not path or not os.path.isfile(path):
            raise FileNotFoundError("Thiếu inswapper_128.onnx — tải riêng (giấy phép phi thương mại) rồi chạy server với "
                                    "--inswapper-path <đường dẫn>")
        _face_swapper = insightface.model_zoo.get_model(path, download=False, download_zip=False)
    return _face_app, _face_swapper


def _largest_face(app_, rgb_img: Image.Image):
    import numpy as np
    bgr = np.asarray(rgb_img)[:, :, ::-1].copy()
    faces = app_.get(bgr)
    if not faces and max(rgb_img.size) < 1024:      # mặt nhỏ trong ảnh neo toàn thân: thử lại phóng to 2x một lần
        big = rgb_img.resize((rgb_img.width * 2, rgb_img.height * 2), Image.LANCZOS)
        faces = app_.get(np.asarray(big)[:, :, ::-1].copy())
    if not faces:
        return None
    return max(faces, key=lambda f: (f.bbox[2] - f.bbox[0]) * (f.bbox[3] - f.bbox[1]))


def _occlusion_mask(w: int, h: int, occluders):
    """mục 258 — mặt nạ VẬT CHE 0..1 (1 = bị che -> GIỮ pixel gốc) từ danh sách đĩa chuẩn hoá [cx, cy, r]: cx theo bề rộng ảnh, cy theo
    chiều cao ảnh, r theo bề rộng ảnh. Viền mềm: đầy trong 0.8·r rồi giảm tuyến tính về 0 ở r. Mục hỏng (thiếu số, không hữu hạn, r<=0, sai kiểu)
    bị BỎ QUA thay vì làm hỏng cả ảnh; tối đa 16 đĩa. Không có/hỏng hết -> mặt nạ toàn 0 (không đổi gì)."""
    import math
    import numpy as np
    m = np.zeros((h, w), dtype=np.float32)
    if not occluders:
        return m
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    for o in list(occluders)[:16]:
        try:
            cx, cy, r = float(o[0]) * w, float(o[1]) * h, float(o[2]) * w
        except (TypeError, ValueError, IndexError, KeyError):
            continue
        if not (math.isfinite(cx) and math.isfinite(cy) and math.isfinite(r)) or r <= 0:
            continue
        d = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
        m = np.maximum(m, np.clip((r - d) / max(0.2 * r, 1e-6), 0.0, 1.0))
    return m


def _face_rect_mask(w: int, h: int, bboxes, pad: float = 0.25):
    """mục 258 — mặt nạ chữ nhật 0/1 phủ các hộp mặt nới thêm `pad` mỗi phía (kẹp trong ảnh). Dùng để chỉ áp che khuất/khôi phục QUANH mặt
    đã hoán đổi, không đụng phần còn lại của ảnh."""
    import numpy as np
    m = np.zeros((h, w), dtype=np.float32)
    for bb in bboxes:
        x1, y1, x2, y2 = [float(v) for v in bb[:4]]
        bw, bh = x2 - x1, y2 - y1
        xa, xb = max(0, int(x1 - pad * bw)), min(w, int(x2 + pad * bw) + 1)
        ya, yb = max(0, int(y1 - pad * bh)), min(h, int(y2 + pad * bh) + 1)
        if xb > xa and yb > ya:
            m[ya:yb, xa:xb] = 1.0
    return m


def _get_gfpgan():
    """mục 258 — nạp GFPGAN một lần (khôi phục chi tiết mặt). Cần `pip install gfpgan` và file trọng số, đường dẫn qua biến môi trường
    MANGALOCAL_GFPGAN_MODEL (vd GFPGANv1.4.pth). Thiếu cái nào -> lỗi RÕ RÀNG; tác vụ faceswap bắt lỗi này và vẫn trả ảnh hoán đổi KHÔNG khôi phục.
    GIỚI HẠN: chưa chạy với GFPGAN thật (test dùng bản GIẢ); kiểm tra giấy phép trọng số trước khi dùng thương mại."""
    global _gfpgan
    if _gfpgan is None:
        path = os.environ.get("MANGALOCAL_GFPGAN_MODEL", "")
        if not path or not os.path.isfile(path):
            raise FileNotFoundError("chưa đặt MANGALOCAL_GFPGAN_MODEL trỏ tới file trọng số GFPGAN (vd GFPGANv1.4.pth)")
        from gfpgan import GFPGANer
        _gfpgan = GFPGANer(model_path=path, upscale=1, arch="clean", channel_multiplier=2, bg_upsampler=None)
    return _gfpgan


def _run_faceswap_sync(payload: dict) -> bytes:
    """Hoán đổi mặt (insightface inswapper_128) CÓ BẢO VỆ: với mỗi `targets[i] = {id, box[x1,y1,x2,y2 chuẩn hoá], ref_b64, shoulder_norm?}`,
    ghép mặt dò được với hộp đầu rồi dán danh tính từ ảnh tham chiếu — rồi KIỂM: (1) bỏ qua mặt quay quá YAW_MAX_DEG; (2) đo biểu cảm
    (EAR/MAR/độ rộng miệng/lông mày) trước-sau bằng landmark 68; lệch -> khôi phục miệng/mắt gốc, vẫn lệch -> hoàn nguyên; (3) kích thước/vị
    trí mặt không được đổi quá PROPORTION_TOL/CENTER_SHIFT_TOL; (4) nếu có `shoulder_norm`, cảnh báo khi bề rộng mặt/vai ngoài dải nhân trắc.
    `preserve`: "auto" (mặc định) | "mouth_eyes" (luôn giữ miệng/mắt gốc) | "none" (tắt kiểm). Kết quả PNG kèm báo cáo JSON trong khối tEXt.
    Chỉ dùng cho NHÂN VẬT HƯ CẤU của người dùng. GIỚI HẠN: ngưỡng chưa hiệu chỉnh; chưa chạy với insightface thật (test dùng bản GIẢ)."""
    import numpy as np
    image_b64 = payload.get("image_b64")
    targets = payload.get("targets") or []
    if not image_b64:
        raise ValueError("task=faceswap thiếu image_b64")
    if not targets:
        raise ValueError("task=faceswap thiếu targets")
    preserve = payload.get("preserve", "auto")
    if preserve not in ("auto", "mouth_eyes", "none"):
        preserve = "auto"
    img = _decode_rgb(image_b64)
    W, H = img.size
    app_, swapper = _get_face_tools()
    result = np.asarray(img)[:, :, ::-1].copy()
    original = result.copy()                       # mục 258: để dán lại pixel gốc nơi bị che
    occ = _occlusion_mask(W, H, payload.get("occluders"))
    accepted = []                                  # mục 258: (entry, face, lm0, fw) của các mặt đã hoán đổi — dùng cho bước khôi phục
    faces = app_.get(result)
    fboxes = [tuple(float(v) for v in f.bbox[:4]) for f in faces]
    tboxes = []
    for t in targets:
        b = t.get("box") or []
        if len(b) != 4:
            raise ValueError("targets[].box phải có 4 số chuẩn hoá [x1,y1,x2,y2]")
        tboxes.append((float(b[0]) * W, float(b[1]) * H, float(b[2]) * W, float(b[3]) * H))
    pairs = _assign_faces(fboxes, tboxes)
    matched = {ti for ti, _ in pairs}
    report = []
    for ti in range(len(targets)):
        if ti not in matched:
            report.append({"id": targets[ti].get("id", ti), "status": "skipped", "reason": "không khớp mặt dò được nào"})
    src_cache = {}
    center = lambda bb: ((bb[0] + bb[2]) / 2.0, (bb[1] + bb[3]) / 2.0)

    def check(img_bgr, face, lm0, fw):
        after = _best_face(app_.get(img_bgr), face.bbox)
        if after is None:
            return None, "không dò lại được mặt sau khi hoán đổi"
        lm1 = _lm68(after)
        if lm1 is None:
            return None, "không có landmark sau khi hoán đổi"
        dev, bad = _expression_deviation(_expression_metrics(lm0), _expression_metrics(lm1))
        aw = float(after.bbox[2] - after.bbox[0])
        c0, c1 = center(face.bbox), center(after.bbox)
        shift = float(((c0[0] - c1[0]) ** 2 + (c0[1] - c1[1]) ** 2) ** 0.5 / max(fw, 1e-6))
        ratio = float(aw / max(fw, 1e-6))
        return {"dev": dev, "bad": bad, "ratio": ratio, "shift": shift,
                "prop_bad": abs(ratio - 1.0) > PROPORTION_TOL or shift > CENTER_SHIFT_TOL}, None

    for ti, fi in pairs:
        t, face = targets[ti], faces[fi]
        entry = {"id": t.get("id", ti)}
        report.append(entry)
        pose = getattr(face, "pose", None)
        if pose is not None and abs(float(pose[1])) > YAW_MAX_DEG:
            entry.update(status="skipped", reason="mặt quay %.0f° (> %.0f°)" % (abs(float(pose[1])), YAW_MAX_DEG))
            continue
        if occ.any():
            x1, y1, x2, y2 = [int(round(v)) for v in face.bbox[:4]]
            x1, x2, y1, y2 = max(0, x1), min(W, x2), max(0, y1), min(H, y2)
            if x2 > x1 and y2 > y1:
                frac = float(occ[y1:y2, x1:x2].mean())
                if frac > 0.01:
                    entry["occluded"] = round(frac, 3)
                if frac > OCCLUSION_SKIP_FRACTION:
                    entry.update(status="skipped", reason="mặt bị che %.0f%% (> %.0f%%) — không còn đủ mặt để hoán đổi" % (frac * 100, OCCLUSION_SKIP_FRACTION * 100))
                    continue
        if not t.get("ref_b64"):
            entry.update(status="skipped", reason="thiếu ảnh tham chiếu")
            continue
        key = t.get("id", ti)
        if key not in src_cache:
            src_cache[key] = _largest_face(app_, _decode_rgb(t["ref_b64"]))
        src = src_cache[key]
        if src is None:
            entry.update(status="skipped", reason="ảnh tham chiếu không có mặt")
            continue
        fw = float(face.bbox[2] - face.bbox[0])
        if t.get("shoulder_norm"):
            hs = fw / max(float(t["shoulder_norm"]) * W, 1e-6)
            entry["head_shoulder"] = round(hs, 3)
            if not (HEAD_SHOULDER_BAND[0] <= hs <= HEAD_SHOULDER_BAND[1]):
                entry["flag"] = "tỉ lệ mặt/vai ngoài dải nhân trắc %.2f-%.2f (đầu to/nhỏ bất thường so với thân?)" % HEAD_SHOULDER_BAND
        candidate = swapper.get(result, face, src, paste_back=True)
        lm0 = _lm68(face)
        if preserve == "none" or lm0 is None:
            result = candidate
            accepted.append((entry, face, lm0, fw))
            entry["status"] = "swapped"
            if lm0 is None and preserve != "none":
                entry["note"] = "không có landmark 68 — bỏ qua kiểm biểu cảm"
            continue
        res, err = check(candidate, face, lm0, fw)
        if err:
            entry.update(status="reverted", reason=err)
            continue
        entry.update(dev={k: round(v, 3) for k, v in res["dev"].items()}, size_ratio=round(res["ratio"], 3), center_shift=round(res["shift"], 3))
        if res["prop_bad"]:
            entry.update(status="reverted", reason="kích thước/vị trí mặt bị đổi (tỉ lệ %.2f, dịch %.2f)" % (res["ratio"], res["shift"]))
            continue
        if res["bad"] or preserve == "mouth_eyes":
            restored = _restore_regions(result, candidate, lm0, fw)
            res2, err2 = check(restored, face, lm0, fw)
            if err2 or res2["bad"] or res2["prop_bad"]:
                entry.update(status="reverted", reason="vẫn lệch biểu cảm (%s) sau khi khôi phục miệng/mắt gốc" % ",".join(res2["bad"] if res2 else ["?"]))
                continue
            result = restored
            accepted.append((entry, face, lm0, fw))
            entry.update(status="restored", reason="đã khôi phục miệng/mắt/lông mày gốc" + (" vì lệch " + ",".join(res["bad"]) if res["bad"] else " (preserve=mouth_eyes)"))
            continue
        result = candidate
        accepted.append((entry, face, lm0, fw))
        entry["status"] = "swapped"

    # mục 258 — (a) GIỮ pixel gốc nơi vật che (tay…) đè lên mặt: chỉ quanh các mặt đã hoán đổi; (b) khôi phục chi tiết mặt TUỲ CHỌN, có kiểm.
    if accepted and occ.any():
        M = (occ * _face_rect_mask(W, H, [a[1].bbox for a in accepted]))[:, :, None]
        if M.any():
            result = np.clip(original.astype(np.float32) * M + result.astype(np.float32) * (1.0 - M), 0, 255).round().astype(np.uint8)
    restore_note = None
    if accepted and payload.get("restore"):
        try:
            strength = min(1.0, max(0.0, float(payload.get("restore_strength", RESTORE_STRENGTH_DEFAULT))))
        except (TypeError, ValueError):
            strength = RESTORE_STRENGTH_DEFAULT
        try:
            restored_full = _get_gfpgan().enhance(result, has_aligned=False, only_center_face=False, paste_back=True)[2]
        except Exception as ex:  # thiếu gói/trọng số hoặc mô hình lỗi: giữ ảnh hoán đổi, ghi lý do
            restored_full, restore_note = None, "không khôi phục được mặt: %s" % ex
        if restored_full is not None and getattr(restored_full, "shape", None) != result.shape:
            restored_full, restore_note = None, "GFPGAN trả ảnh sai kích thước"
        if restored_full is not None:
            for entry, face, lm0, fw in accepted:
                w_ = (_face_rect_mask(W, H, [face.bbox], pad=0.15) * strength)[:, :, None]
                cand = np.clip(result.astype(np.float32) * (1.0 - w_) + restored_full.astype(np.float32) * w_, 0, 255).round().astype(np.uint8)
                if lm0 is not None and preserve != "none":
                    res, err = check(cand, face, lm0, fw)
                    if err or res["bad"] or res["prop_bad"]:
                        entry["restore"] = "bỏ: khôi phục làm lệch biểu cảm/kích thước"
                        continue
                result = cand
                entry["restore"] = "đã khôi phục (%.0f%%)" % (strength * 100)
    done = sum(1 for e in report if e.get("status") in ("swapped", "restored"))
    print(f"[faceswap] {len(faces)} mặt dò được, {len(targets)} đích: hoán đổi {done}, "
          f"hoàn nguyên {sum(1 for e in report if e.get('status') == 'reverted')}, bỏ qua {sum(1 for e in report if e.get('status') == 'skipped')}")
    return _png_bytes(Image.fromarray(np.ascontiguousarray(result[:, :, ::-1])), dict({"task": "faceswap", "faces": report}, **({"restore_note": restore_note} if restore_note else {})))


_hand_detector = None
_hand_cn = None


def _import_mesh_graphormer():
    """Tra cứu mục 251: gói controlnet_aux trên PyPI (0.0.10) KHÔNG có MeshGraphormerDetector; lớp này nằm trong bản fork
    Fannovel16/comfyui_controlnet_aux (package `custom_controlnet_aux`, repo cũ dùng `controlnet_aux`). Thử lần lượt các đường import."""
    import importlib
    import sys
    if args.controlnet_aux_src and args.controlnet_aux_src not in sys.path:
        sys.path.insert(0, args.controlnet_aux_src)
    last = None
    for mod in ("custom_controlnet_aux.mesh_graphormer", "controlnet_aux.mesh_graphormer", "controlnet_aux"):
        try:
            return getattr(importlib.import_module(mod), "MeshGraphormerDetector")
        except Exception as e:      # ImportError, AttributeError, lỗi phụ thuộc...
            last = e
    raise ImportError("Không import được MeshGraphormerDetector. Gói controlnet_aux trên PyPI KHÔNG có lớp này: clone "
                      "Fannovel16/comfyui_controlnet_aux, chạy server với --controlnet-aux-src <thư mục src>, và cài mediapipe, "
                      f"trimesh[easy], yacs. Lỗi cuối: {last}")


def _fit8(v) -> int:
    return max(64, (int(v) // 8) * 8)


def _run_handfix_sync(payload: dict) -> bytes:
    """Sửa tay bằng HandRefiner: MeshGraphormer (controlnet_aux) tìm tay -> dựng lưới tay -> bản đồ độ sâu + mask; rồi vẽ lại CHỈ vùng
    mask bằng SD1.5 + ControlNet depth-hand (hr16/ControlNet-HandRefiner-pruned, Apache-2.0) và dán lại có làm mờ biên. Cần model nền SD1.5.
    Không thấy tay -> trả nguyên ảnh. GIỚI HẠN: chưa chạy với GPU/controlnet_aux thật ở đây (test dùng module GIẢ); chữ ký gọi bộ phát hiện
    được lọc theo `inspect.signature` vì phiên bản controlnet_aux có thể khác; cộng đồng ghi nhận tay quá lớn/biến dạng nặng vẫn hỏng."""
    import inspect
    import numpy as np
    import torch
    from PIL import ImageFilter
    from diffusers import StableDiffusionControlNetInpaintPipeline, ControlNetModel
    global _hand_detector, _hand_cn
    image_b64 = payload.get("image_b64")
    if not image_b64:
        raise ValueError("task=handfix thiếu image_b64")
    ensure_base_model(payload.get("model_id") or None, payload.get("model_type") or "sd15")
    if _current_model_type != "sd15":
        raise ValueError("HandRefiner chỉ dùng được với model nền SD1.5 (ControlNet depth-hand huấn luyện cho SD1.5)")
    img = _decode_rgb(image_b64)
    W, H = img.size
    if _hand_detector is None:
        _hand_detector = _import_mesh_graphormer().from_pretrained("hr16/ControlNet-HandRefiner-pruned")
    call_kw = {"detect_resolution": 512, "mask_bbox_padding": 30, "output_type": "pil"}
    try:
        sig = inspect.signature(_hand_detector.__call__).parameters
        call_kw = {k: v for k, v in call_kw.items() if k in sig}
    except (TypeError, ValueError):
        pass
    res = _hand_detector(img, **call_kw)
    depth, mask = res[0], res[1]
    if not isinstance(depth, Image.Image):
        depth = Image.fromarray(np.asarray(depth))
    if not isinstance(mask, Image.Image):
        mask = Image.fromarray(np.asarray(mask))
    mask = mask.convert("L")
    if np.asarray(mask).max() == 0:
        print("[handfix] không tìm thấy tay — trả nguyên ảnh")
        return _png_bytes(img)
    if _hand_cn is None:
        path = args.handrefiner_cn_path
        if not path:
            from huggingface_hub import hf_hub_download
            path = hf_hub_download("hr16/ControlNet-HandRefiner-pruned", "control_sd15_inpaint_depth_hand_fp16.safetensors")
        _hand_cn = ControlNetModel.from_single_file(path, torch_dtype=_torch_dtype())
        _hand_cn.to("cuda" if torch.cuda.is_available() else "cpu")
    apply_lora(_base_pipe, None)
    pipe = StableDiffusionControlNetInpaintPipeline.from_pipe(_base_pipe, controlnet=_hand_cn)
    w8, h8 = _fit8(W), _fit8(H)
    seed = payload.get("seed", -1)
    generator = torch.Generator(device=_base_pipe.device).manual_seed(int(seed)) if seed is not None and int(seed) >= 0 else None
    strength = max(0.3, min(1.0, float(payload.get("strength", 0.75))))
    steps = max(10, min(50, int(payload.get("steps", 25))))
    out = pipe(
        prompt=payload.get("prompt") or "realistic human hand, five fingers, natural skin, detailed, anatomically correct",
        negative_prompt=payload.get("negative_prompt") or "extra fingers, missing fingers, fused fingers, deformed hand, blurry, lowres",
        image=img.resize((w8, h8), Image.LANCZOS), mask_image=mask.resize((w8, h8)), control_image=depth.convert("RGB").resize((w8, h8)),
        num_inference_steps=steps, guidance_scale=float(payload.get("cfg_scale", 7.0)), strength=strength,
        controlnet_conditioning_scale=1.0, generator=generator,
    ).images[0].resize((W, H), Image.LANCZOS)
    feather = mask.resize((W, H)).filter(ImageFilter.GaussianBlur(6))
    return _png_bytes(Image.composite(out, img, feather))


_interact_pipe = None


def _run_interact_sync(payload: dict) -> bytes:
    """InteractDiffusion (CVPR 2024; SD1.5 + gated self-attention kiểu GLIGEN, giấy phép BSD theo trang HF): sinh BỐ CỤC TƯƠNG TÁC (ôm/hôn/đánh)
    từ bộ ba chủ thể–hành động–đối tượng + hai hộp. Tên tham số lấy từ model card `interactdiffusion/diffusers-v1-2`:
    interactdiffusion_{subject,object,action}_phrases, interactdiffusion_{subject,object}_boxes, interactdiffusion_scheduled_sampling_beta.
    DÙNG LÀM ẢNH BỐ CỤC để app trích khung xương rồi RENDER LẠI bằng checkpoint/LoRA/IP-Adapter của dự án (không dùng làm ảnh cuối).
    Nạp bằng trust_remote_code=True => chạy mã tải từ Hugging Face (ghim --interact-revision). GIỚI HẠN: chưa chạy với model thật; từ vựng
    huấn luyện theo HICO-DET (có hug/kiss/hit với đối tượng person) — chưa kiểm model sinh tốt các loại này."""
    import torch
    from diffusers import DiffusionPipeline
    global _interact_pipe
    it = payload.get("interaction") or {}
    for k in ("subject_phrase", "object_phrase", "action_phrase"):
        if not str(it.get(k, "")).strip():
            raise ValueError(f"interaction.{k} thiếu")

    def box(name):
        b = it.get(name) or []
        if len(b) != 4 or not all(0.0 <= float(v) <= 1.0 for v in b) or float(b[2]) <= float(b[0]) or float(b[3]) <= float(b[1]):
            raise ValueError(f"interaction.{name} phải là [x1,y1,x2,y2] chuẩn hoá hợp lệ trong [0,1]")
        return [float(v) for v in b]

    sbox, obox = box("subject_box"), box("object_box")
    prompt = (payload.get("prompt") or "").strip() or "a photo of two people"
    w = max(256, min(768, _fit8(payload.get("width", 512))))
    h = max(256, min(768, _fit8(payload.get("height", 512))))
    steps = max(10, min(50, int(payload.get("steps", 40))))
    seed = payload.get("seed", -1)
    pipe = _interact_pipe
    if pipe is None:
        kw = {"trust_remote_code": True, "variant": "fp16", "torch_dtype": torch.float16}
        if args.interact_revision:
            kw["revision"] = args.interact_revision
        pipe = DiffusionPipeline.from_pretrained(args.interact_model_id, **kw)
        pipe.to("cuda" if torch.cuda.is_available() else "cpu")
        if args.keep_interact:
            _interact_pipe = pipe
    try:
        generator = torch.Generator(device="cpu").manual_seed(int(seed)) if seed is not None and int(seed) >= 0 else None
        call = dict(prompt=prompt,
                    interactdiffusion_subject_phrases=[str(it["subject_phrase"])], interactdiffusion_object_phrases=[str(it["object_phrase"])],
                    interactdiffusion_action_phrases=[str(it["action_phrase"])],
                    interactdiffusion_subject_boxes=[sbox], interactdiffusion_object_boxes=[obox],
                    interactdiffusion_scheduled_sampling_beta=1, output_type="pil", num_inference_steps=steps, generator=generator)
        try:
            out = pipe(height=h, width=w, **call)
        except TypeError:       # pipeline tuỳ biến có thể không nhận height/width -> dùng kích thước mặc định
            out = pipe(**call)
        img = out.images[0]
    finally:
        if not args.keep_interact:
            _interact_pipe = None
            del pipe
            gc.collect()
            try:
                torch.cuda.empty_cache()
            except Exception:
                pass
    if img.size != (w, h):
        img = img.resize((w, h), Image.LANCZOS)
    return _png_bytes(img)


_kontext_pipe = None


def _fit16(w: int, h: int, long_side: int = 1024):
    scale = min(1.0, long_side / float(max(w, h)))
    return max(16, int(round(w * scale)) // 16 * 16), max(16, int(round(h * scale)) // 16 * 16)


def _stitch_geometry(rw: int, rh: int, ref_w: int, ref_h: int):
    """Ghép ảnh tham chiếu bên PHẢI cảnh (cùng chiều cao rh). Trả (rộng ảnh tham chiếu sau đổi cỡ, tổng bề rộng, phần bề rộng của cảnh)."""
    rnw = max(16, int(round(ref_w * rh / float(ref_h))) // 16 * 16)
    return rnw, rw + rnw, rw / float(rw + rnw)


def _kontext_dtype():
    """Tra cứu mục 251: GPU Turing (T4, compute capability < 8) KHÔNG có bf16 phần cứng; diffusers có đường chạy FLUX bằng fp16 (cắt kích hoạt
    chống tràn) nên dùng fp16 trên GPU < 8.0, bf16 ở nơi khác (kể cả CPU). Kết quả fp16 có thể khác bf16."""
    import torch
    try:
        if torch.cuda.is_available() and torch.cuda.get_device_capability(0)[0] < 8:
            return torch.float16
    except Exception:
        pass
    return torch.bfloat16


def _load_kontext():
    import torch
    from diffusers import FluxKontextPipeline
    dtype = _kontext_dtype()
    kw = {"torch_dtype": dtype}
    try:
        from diffusers.quantizers import PipelineQuantizationConfig
        kw["quantization_config"] = PipelineQuantizationConfig(
            quant_backend="bitsandbytes_4bit",
            quant_kwargs={"load_in_4bit": True, "bnb_4bit_quant_type": "nf4", "bnb_4bit_compute_dtype": dtype},
            components_to_quantize=["transformer"])
    except Exception as e:
        print(f"[warn] không bật được nén 4-bit ({e}) — nạp đầy đủ, có thể hết VRAM")
    pipe = FluxKontextPipeline.from_pretrained(args.kontext_model_id, **kw)
    pipe.enable_model_cpu_offload()
    return pipe


def _run_kontext_sync(payload: dict) -> bytes:
    """FLUX.1 Kontext [dev]: chỉnh ảnh theo prompt, tuỳ chọn kèm ảnh tham chiếu (`ref_b64`, ghép bên phải cảnh rồi cắt lấy phần cảnh). Giấy phép
    PHI THƯƠNG MẠI. GIỚI HẠN: chưa chạy với GPU thật; bf16 trên T4 không có phần cứng hỗ trợ (có thể rất chậm); chất lượng giữ danh tính theo
    kiểu ghép ảnh CHƯA được kiểm chứng; kích thước kết quả có thể khác đầu vào nên được đổi lại cho khớp."""
    import torch
    global _kontext_pipe
    image_b64 = payload.get("image_b64")
    prompt = (payload.get("prompt") or "").strip()
    if not image_b64:
        raise ValueError("task=kontext thiếu image_b64")
    if not prompt:
        raise ValueError("task=kontext thiếu prompt")
    img = _decode_rgb(image_b64)
    W, H = img.size
    rw, rh = _fit16(W, H, 1024)
    work = img.resize((rw, rh), Image.LANCZOS)
    left = 1.0
    if payload.get("ref_b64"):
        ref = _decode_rgb(payload["ref_b64"])
        rnw, total, left = _stitch_geometry(rw, rh, ref.width, ref.height)
        canvas = Image.new("RGB", (total, rh))
        canvas.paste(work, (0, 0))
        canvas.paste(ref.resize((rnw, rh), Image.LANCZOS), (rw, 0))
        work = canvas
    steps = max(10, min(50, int(payload.get("steps", 28))))
    guidance = max(1.0, min(10.0, float(payload.get("guidance_scale", 2.5))))
    seed = payload.get("seed", -1)
    pipe = _kontext_pipe if _kontext_pipe is not None else _load_kontext()
    if args.keep_kontext:
        _kontext_pipe = pipe
    try:
        generator = torch.Generator(device="cpu").manual_seed(int(seed)) if seed is not None and int(seed) >= 0 else None
        out = pipe(image=work, prompt=prompt, guidance_scale=guidance, num_inference_steps=steps, generator=generator).images[0]
    finally:
        if not args.keep_kontext:
            _kontext_pipe = None
            del pipe
            gc.collect()
            try:
                torch.cuda.empty_cache()
            except Exception:
                pass
    if payload.get("ref_b64"):
        out = out.crop((0, 0, int(round(out.width * left)), out.height))
    return _png_bytes(out.resize((W, H), Image.LANCZOS))


_TASK_HANDLERS = {
    "interact": _run_interact_sync,
    "video": _run_video_sync,
    "faceswap": _run_faceswap_sync,
    "handfix": _run_handfix_sync,
    "kontext": _run_kontext_sync,
}


def _run_generation_sync(payload: dict) -> bytes:
    """Phần XỬ LÝ NẶNG (CPU/GPU-bound) — chạy trong thread executor riêng
    (xem generate() bên dưới) để không chặn event loop của các request khác
    (vd /pubkey vẫn phải trả lời nhanh dù đang có ảnh khác chạy dở). Trả về
    PNG bytes thẳng, KHÔNG mã hoá ở đây (mã hoá lại nằm ở generate(), chỗ có
    quyền truy cập aes_key)."""
    task = payload.get("task")
    if task:      # mục 249/250: tác vụ phụ (video/faceswap/handfix/kontext) dùng cùng đường mã hoá/hàng đợi
        handler = _TASK_HANDLERS.get(task)
        if handler is None:
            raise HTTPException(status_code=400, detail=f"Tác vụ không hỗ trợ: {task}")
        try:
            return handler(payload)
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Tác vụ {task} lỗi: {e}")
    prompt = payload.get("prompt", "")
    negative_prompt = payload.get("negative_prompt", "")
    width = int(payload.get("width", 512))
    height = int(payload.get("height", 512))
    steps = int(payload.get("steps", 25))
    cfg_scale = float(payload.get("cfg_scale", 7.0))
    seed = payload.get("seed", -1)
    lora_id = payload.get("lora_id") or None
    reference_image_b64 = payload.get("reference_image_b64") or None
    skeleton_data = payload.get("skeleton_data") or None
    requested_model_id = payload.get("model_id") or None
    requested_model_type = payload.get("model_type") or None
    try:
        pag_scale = max(0.0, min(10.0, float(payload.get("pag_scale", 0.0) or 0.0)))   # mục 248; 0 = tắt
    except (TypeError, ValueError):
        pag_scale = 0.0

    # KHÔNG log nội dung prompt/ảnh — chỉ log thông số không nhạy cảm
    print(f"[generate] model={requested_model_id or args.model} ({requested_model_type or args.model_type}), "
          f"{width}x{height}, {steps} steps, cfg={cfg_scale}, lora={lora_id or '(none)'}, "
          f"ip_adapter={'có' if reference_image_b64 else 'không'}, pose={'có' if skeleton_data else 'không'}, pag={pag_scale or 'tắt'} — đang chạy...")

    ref_image = None
    try:
        # Đổi model NẾU khác lần trước (xem docstring ensure_base_model —
        # gần như luôn no-op trong cùng 1 chương, chỉ tải lại lúc thật sự đổi).
        ensure_base_model(requested_model_id, requested_model_type)

        use_pose = bool(skeleton_data)
        pipe = get_controlnet_pipe() if use_pose else _base_pipe

        if reference_image_b64:
            ensure_ip_adapter(pipe)
            ref_bytes = base64.b64decode(reference_image_b64)
            ref_image = Image.open(io.BytesIO(ref_bytes)).convert("RGB")

        apply_lora(pipe, lora_id)

        import torch
        generator = None
        if seed is not None and int(seed) >= 0:
            generator = torch.Generator(device=pipe.device).manual_seed(int(seed))

        gen_kwargs = dict(
            prompt=prompt, negative_prompt=negative_prompt,
            width=width, height=height,
            num_inference_steps=steps, guidance_scale=cfg_scale,
            generator=generator,
        )
        if ref_image is not None:
            gen_kwargs["ip_adapter_image"] = ref_image
        if use_pose:
            gen_kwargs["image"] = render_skeleton_image(skeleton_data, size=max(width, height))

        run_pipe = pipe
        if pag_scale > 0:
            pag_pipe = build_pag_pipe(pipe)
            if pag_pipe is not None:
                run_pipe = pag_pipe
                gen_kwargs["pag_scale"] = pag_scale
        try:
            result = run_pipe(**gen_kwargs)
        except Exception as e:
            if run_pipe is pipe:
                raise
            # PAG lỗi lúc chạy (vd xung đột với IP-Adapter — CHƯA kiểm chứng) -> chạy lại KHÔNG PAG, cùng seed.
            print(f"[warn] PAG lỗi khi chạy ({e}) — chạy lại KHÔNG PAG")
            gen_kwargs.pop("pag_scale", None)
            if seed is not None and int(seed) >= 0:
                gen_kwargs["generator"] = torch.Generator(device=pipe.device).manual_seed(int(seed))
            result = pipe(**gen_kwargs)
        image = result.images[0]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generate lỗi: {e}")
    finally:
        del prompt, negative_prompt
        if ref_image is not None:
            del ref_image
        # payload (dict) vẫn còn ở caller (generate()) lúc này nên del ở đây
        # chưa xoá hết mọi reference tới prompt/negative_prompt — chỉ thật
        # sự giải phóng được sau khi generate() cũng del payload (xem đó).
        # gc.collect() gọi lại lần nữa ở generate() mới có tác dụng đầy đủ.

    buf = io.BytesIO()
    image.save(buf, format="PNG")
    return buf.getvalue()


@app.post("/generate")
async def generate(req: GenerateRequest, authorization: Optional[str] = Header(None)):
    if authorization != f"Bearer {args.auth_token}":
        raise HTTPException(status_code=401, detail="Auth token sai hoặc thiếu")

    # 1. Mở khoá AES session key bằng RSA private key của server
    try:
        wrapped_key = bytearray(base64.b64decode(req.wrapped_key_b64))
        aes_key = bytearray(_private_key.decrypt(
            bytes(wrapped_key),
            rsa_padding.OAEP(
                mgf=rsa_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(), label=None,
            ),
        ))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Không giải mã được session key: {e}")

    # 2. Giải mã payload thật bằng AES-256-GCM
    try:
        iv = base64.b64decode(req.iv_b64)
        ciphertext = base64.b64decode(req.ciphertext_b64)
        plaintext = bytearray(AESGCM(bytes(aes_key)).decrypt(iv, ciphertext, None))
        payload = json.loads(bytes(plaintext).decode("utf-8"))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Không giải mã được payload (sai key hoặc dữ liệu hỏng): {e}")
    task_echo = payload.get("task") if isinstance(payload.get("task"), str) else None   # mục 250: echo trong phản hồi

    # 3. Xếp hàng CÓ GIỚI HẠN — vượt quá _MAX_QUEUE_DEPTH thì từ chối NGAY,
    #    không nhận thêm rồi để RAM dồn ứ chờ xử lý.
    global _queue_depth, _last_generation_start, _last_activity_time
    async with _queue_depth_lock:
        if _queue_depth >= _MAX_QUEUE_DEPTH:
            raise HTTPException(status_code=429,
                detail=f"Server đang xử lý/xếp hàng {_queue_depth} yêu cầu (giới hạn {_MAX_QUEUE_DEPTH}) — "
                       f"thử lại sau vài giây.")
        _queue_depth += 1

    try:
        # 4. Chỉ 1 generate chạy GPU thật tại 1 thời điểm — cái sau tự chờ
        #    (đúng 1 GPU vật lý), KHÔNG chạy song song gây tranh VRAM.
        async with _generation_semaphore:
            # 5. Giới hạn tần suất — đảm bảo khoảng cách tối thiểu giữa 2 lần
            #    BẮT ĐẦU generate thật, kể cả khi hàng đợi còn chỗ.
            now = time.monotonic()
            wait = args.min_request_interval - (now - _last_generation_start)
            if wait > 0:
                await asyncio.sleep(wait)
            _last_generation_start = time.monotonic()

            # 6. Phần nặng chạy trong thread executor — không chặn event loop
            #    (để /pubkey hay request khác đang xếp hàng vẫn phản hồi được).
            image_bytes = bytearray(await asyncio.get_event_loop().run_in_executor(
                None, _run_generation_sync, payload
            ))
            _last_activity_time = time.monotonic()  # đánh dấu vừa có hoạt động thật — reset đếm giờ rảnh cho _maintenance_loop
    finally:
        async with _queue_depth_lock:
            _queue_depth -= 1
        # Xoá dấu vết plaintext SỚM NHẤT có thể — zero byte thật (không chỉ
        # del) cho những gì là bytearray thật; payload (dict chứa str) chỉ
        # del được, str immutable không zero tại chỗ an toàn được (xem
        # docstring _zero_bytearray phía trên). gc.collect() ép thu hồi
        # ngay thay vì chờ GC generational bình thường (có thể trễ vài giây
        # tới vài phút tuỳ áp lực bộ nhớ).
        _zero_bytearray(plaintext)
        _zero_bytearray(wrapped_key)
        del payload, plaintext, wrapped_key
        gc.collect()

    # 7. Mã hoá lại ảnh PNG bằng CÙNG aes_key (đối xứng, IV MỚI cho chiều trả về —
    #    KHÔNG BAO GIỜ tái dùng IV với cùng 1 key trong AES-GCM)
    resp_iv = os.urandom(12)
    resp_ciphertext = AESGCM(bytes(aes_key)).encrypt(resp_iv, bytes(image_bytes), None)
    _zero_bytearray(image_bytes)
    _zero_bytearray(aes_key)
    del image_bytes, aes_key
    gc.collect()

    resp = {
        "iv_b64": base64.b64encode(resp_iv).decode(),
        "ciphertext_b64": base64.b64encode(resp_ciphertext).decode(),
    }
    if task_echo:
        resp["task"] = task_echo     # client dùng để từ chối server CŨ không hiểu tác vụ (mục 250)
    return resp


if __name__ == "__main__":
    uvicorn.run(app, host=args.host, port=args.port)
