# Remote GPU server (tuỳ chọn — app mặc định vẫn 100% local)

Server tham chiếu để app MangaLocal gọi sinh ảnh trên GPU thuê ngoài, dùng
cho tính năng **Remote GPU** (Cài đặt > Remote GPU trong app). Xem
`app.py` (docstring đầu file) để hiểu đầy đủ mô hình bảo mật — tóm tắt:
mã hoá thật giữa app và server này (chống được bên trung gian mạng), nhưng
**không** chống được chính chủ hạ tầng GPU thuê (đây là giới hạn vật lý,
không phải thiếu sót có thể vá bằng code).

## 2 cách chạy

### A. Google Colab (miễn phí, dễ nhất — chạy được từ điện thoại, gần như 1-click)
Mở `colab_remote_server.ipynb` bằng Google Colab (colab.research.google.com
> File > Upload notebook). Chỉ 2 bước tay:
1. **Runtime > Change runtime type > GPU** (Colab không cho notebook tự đổi
   runtime của chính nó, bắt buộc làm tay).
2. **Runtime > Run all** — không cần đăng ký tài khoản gì (dùng Cloudflare
   Tunnel quick tunnel, không phải ngrok), auth token tự sinh ngẫu nhiên.

**Điều khoản Colab (đọc trước khi dựa vào cách này)**: FAQ chính thức của Colab cấm ở mọi runtime việc cung cấp dịch vụ web không liên quan đến tính toán tương tác
và việc tạo deepfake, và cấm thêm ở bản miễn phí việc bỏ qua giao diện notebook để dùng chủ yếu qua web UI — server API qua tunnel nằm sát nhóm này nên phiên có thể bị
ngắt không báo trước. Notebook cố ý KHÔNG cài thư viện cho tác vụ `faceswap`. Xem `TECHNICAL_STATUS.md` mục 266.

**Notebook nhúng nguyên văn `app.py`** — sau mỗi lần sửa `app.py` chạy `python tools/remote_server/sync_notebook.py` rồi `python tools/test_notebook_sync.py`
(bản nhúng từng lệch 629 so với 1425 dòng mà không ai biết).

**Hạn chế Colab free**: phiên có giới hạn thời gian, bị ngắt khi rảnh lâu,
GPU T4 chậm hơn RunPod/Vast.ai trả phí. Mỗi lần Run all lại = fingerprint +
URL + auth token đều đổi mới (RSA key và tunnel đều ephemeral) — phải copy
lại vào app.

### B. GPU thuê ngoài (RunPod / Vast.ai / VPS riêng có GPU — trả phí, ổn định hơn)
```bash
pip install -r requirements.txt
python app.py --auth-token "chuoi-bi-mat-cua-ban" --model runwayml/stable-diffusion-v1-5 \
    --loras-dir ./loras --controlnet-model lllyasviel/control_v11p_sd15_openpose \
    --ipadapter-repo h94/IP-Adapter --ipadapter-weight ip-adapter_sd15.bin
```
Mở port 8000 ra ngoài (tuỳ nhà cung cấp — RunPod có sẵn "expose port" trong
dashboard, Vast.ai tương tự, VPS riêng thì tự cấu hình firewall/reverse proxy).

## Đổi model (SD1.5 hoặc SDXL) — không cần khởi động lại server
Vào app > Cài đặt > Remote GPU > điền **"Model trên remote"** (HuggingFace
repo id, vd `stabilityai/stable-diffusion-xl-base-1.0` cho SDXL) + chọn
kiến trúc (SD15/SDXL) — đặt TRƯỚC khi bấm Generate cho cả chương. Server tự
nhận ra model khác lần trước và tự tải lại (mất vài phút, CHỈ 1 lần khi
thật đổi, không phải mỗi panel) — không cần sửa gì trên Colab, không mất
tunnel/fingerprint đang có. Để trống = dùng đúng model server khởi động sẵn
(`--model`/`MODEL_ID` trong notebook).

**SDXL vs SD1.5**: SDXL chất lượng cao hơn nhưng nặng hơn nhiều (~7-8GB
VRAM so với ~2GB) — vẫn chạy được trên Colab free T4 (15GB) nhưng chậm hơn
đáng kể. LoRA hiện có (train cho SD1.5) **KHÔNG dùng được với SDXL** —
server tự bỏ qua + log cảnh báo nếu bạn gán LoRA cho nhân vật mà đang chạy
SDXL.

## Hàng đợi + giới hạn tần suất (chống app gửi dồn dập)
Server tự giới hạn để tránh GPU/RAM tăng không kiểm soát nếu app gửi nhiều
panel liên tiếp quá nhanh:
- Tối đa `--max-queue-depth` (mặc định 3) request đang xử lý/chờ cùng lúc —
  vượt quá, server trả lỗi **429** ngay (app tự hiểu là "thử lại sau", tự
  đợi rồi gửi lại, không cần bạn làm gì).
- Chỉ **1 ảnh sinh thật tại 1 thời điểm** (đúng với 1 GPU vật lý) — request
  khác tự xếp hàng chờ, không tranh VRAM.
- Khoảng cách tối thiểu `--min-request-interval` giây (mặc định 1.0) giữa 2
  lần bắt đầu sinh ảnh thật, kể cả khi hàng đợi còn chỗ.

Chỉnh 2 giá trị này qua `MAX_QUEUE_DEPTH`/`MIN_REQUEST_INTERVAL` trong
notebook Colab nếu cần (vd tăng lên nếu máy khoẻ hơn, giảm xuống nếu Colab
free hay bị cảnh báo quá tải).

## Dọn dẹp tài nguyên lúc rảnh + tự đóng sau thời lượng dài
2 cơ chế bổ sung, cả hai đều nhằm **không giữ tài nguyên lãng phí khi
không cần** — không phải để né tránh gì:
- **`IDLE_CLEANUP_SECONDS`** (mặc định 300 = 5 phút): sau chừng này giây
  không có request nào, server tự gỡ LoRA đang giữ + giải phóng VRAM cache
  không dùng tới. Đặt `0` để tắt.
- **`MAX_UPTIME_HOURS`** (mặc định 0 = tắt): tự đóng server sau chừng này
  giờ kể từ lúc khởi động — phòng trường hợp quên tắt, để phiên chạy vô
  thời hạn không cần thiết. Chạy lại notebook nếu cần dùng tiếp (sẽ có
  URL/fingerprint MỚI, nhớ cập nhật lại trong app).

## Tunnel khác ngoài Cloudflare
Notebook đi kèm dùng Cloudflare Tunnel (`cloudflared`) — ổn định, miễn phí,
không cần tài khoản. **Pinggy** (`pinggy.io`) là lựa chọn thay thế hợp lệ
tương tự nếu Cloudflare Tunnel gặp sự cố — cũng là dịch vụ tunnel hợp pháp,
cách dùng tương tự (`ssh -p 443 -R0:localhost:8000 free.pinggy.io`), nhưng
notebook hiện KHÔNG tích hợp sẵn Pinggy — nếu cần đổi, thay bước gọi
`cloudflared` trong Cell 3 bằng lệnh SSH tunnel của Pinggy và parse URL trả
về tương ứng.

## Cấu hình trong app
Cài đặt > Remote GPU > điền **Base URL** (URL ngrok hoặc IP:port server) +
**Auth token** (đúng chuỗi đã đặt ở `--auth-token`) > bấm **"Kiểm tra kết
nối"** > đối chiếu fingerprint hiển thị với fingerprint in ra ở log server
lúc khởi động (dòng "Public key fingerprint") — khớp thì mới an toàn.

## Đưa LoRA lên server (Colab hoặc GPU thuê ngoài)
Server KHÔNG nhận file LoRA qua kênh mã hoá của app (file `.safetensors`
thường vài chục-hàng trăm MB, không hợp lý gửi lại mỗi lần sinh ảnh qua
mạng di động). Thay vào đó, đồng bộ file LoRA **1 lần** trước khi chạy:

- **Colab**: dùng Cell 2.5 trong `colab_remote_server.ipynb` — mount Google
  Drive, copy các file `.safetensors` (đúng file đã gán cho nhân vật trong
  app, xem màn hình "Nhân vật") vào 1 thư mục Drive, notebook tự trỏ
  `--loras-dir` vào đó.
- **RunPod/Vast.ai/VPS riêng**: copy file `.safetensors` trực tiếp vào thư
  mục truyền cho `--loras-dir` (scp/rsync/Drive tuỳ cách bạn quản lý máy đó).

Tên file (không kèm đuôi `.safetensors`) phải khớp CHÍNH XÁC với tên file
LoRA app dùng ở local — app tự gửi đúng tên này trong mỗi request panel có
nhân vật gán LoRA.

## Tính năng hiện tại (đã ngang bằng local — mục 40 TECHNICAL_STATUS.md)
- txt2img SD1.5 cơ bản.
- **IP-Adapter** (giữ nhất quán nhân vật) — app tự gửi ảnh anchor nhân vật
  kèm mỗi request, server tự load IP-Adapter khi cần.
- **ControlNet-Pose** (giữ tư thế) — app gửi khung xương 18 điểm (OpenPose
  COCO-18, cùng format với local), server tự vẽ lại thành ảnh điều kiện
  bằng ĐÚNG bộ màu/kết nối khớp mà native local dùng.
- **LoRA** — nạp/gỡ ĐỘNG theo từng request dựa trên nhân vật đang vẽ, không
  giữ tất cả LoRA trong VRAM cùng lúc (phù hợp giới hạn Colab free).
- Model gốc (checkpoint chính) vẫn CỐ ĐỊNH theo `--model` lúc khởi động server
  — đổi LoRA (nhẹ, nhanh) đã đủ tạo khác biệt giữa các nhân vật mà không cần
  đổi hẳn checkpoint gốc mỗi panel (đổi checkpoint tốn hàng chục giây, không
  hợp lý làm theo từng panel).

⚠️ **Chưa từng chạy thử thật trên Colab** — mới kiểm tra được code Python hợp
lệ cú pháp và logic tự soát lại đúng ý thiết kế. Bắt tay mã hoá RSA+AES giữa
Kotlin và Python, và toàn bộ luồng IP-Adapter/ControlNet/LoRA mới ở trên,
**chưa có ai xác nhận chạy thật thành công** — nên thử nghiệm cẩn thận, có
thể còn lỗi phát sinh khi chạy thật lần đầu.

## PAG (Perturbed-Attention Guidance) — mục 248 TECHNICAL_STATUS.md

Payload tuỳ chọn `pag_scale` (số thực; 0 hoặc vắng = tắt; server kẹp vào [0, 10]). Khi > 0 server dựng pipeline PAG bằng
`AutoPipelineForText2Image.from_pipe(pipe, enable_pag=True, pag_applied_layers=["mid"])` (dùng chung UNet/VAE/CLIP, không tải
lại trọng số) và truyền `pag_scale` khi gọi. Nếu không dựng được hoặc lỗi lúc chạy (chưa kiểm chứng cùng IP-Adapter/LoRA trên
Colab thật), server tự chạy lại KHÔNG PAG với cùng seed và ghi cảnh báo vào log. Phía app: Cài đặt > Remote GPU > PAG.
PAG thêm một nhánh tính toán mỗi bước nên chậm hơn.

## Tác vụ hậu kỳ trên server — mục 250 TECHNICAL_STATUS.md

Payload `task` (cùng đường mã hoá/hàng đợi với `/generate`; phản hồi có trường `task` echo để app từ chối server CŨ):

| `task` | Làm gì | Cần thêm | Giấy phép |
|---|---|---|---|
| `faceswap` | Ghép mặt dò được với hộp đầu từng nhân vật rồi hoán đổi danh tính từ ảnh neo (insightface `buffalo_l` + `inswapper_128`) | `pip install insightface onnxruntime-gpu`; tải riêng `inswapper_128.onnx`; chạy server với `--inswapper-path` | **PHI THƯƠNG MẠI** (trọng số insightface chỉ cho nghiên cứu) |
| `handfix` | HandRefiner: MeshGraphormer tìm tay → depth + mask → vẽ lại vùng tay bằng SD1.5 + ControlNet depth-hand | **Gói `controlnet_aux` trên PyPI KHÔNG có MeshGraphormerDetector.** Clone `Fannovel16/comfyui_controlnet_aux`, chạy server với `--controlnet-aux-src <thư mục src>`; cài `mediapipe`, `trimesh[easy]`, `yacs` (và nâng `protobuf`); model nền SD1.5; `--handrefiner-cn-path` (tuỳ chọn, mặc định tải `hr16/ControlNet-HandRefiner-pruned`) | Apache-2.0 (theo trang Hugging Face) |
| `interact` | InteractDiffusion: sinh ẢNH BỐ CỤC tương tác (hugging/kissing/hitting) từ hộp hai người; app trích khung xương rồi render lại bằng pipeline của dự án (mục 251) | `--interact-model-id` (mặc định `interactdiffusion/diffusers-v1-2`), `--interact-revision` (**nên ghim commit**: model nạp bằng `trust_remote_code=True` = chạy mã tải về), `--keep-interact` | BSD (theo trang Hugging Face) |
| `kontext` | FLUX.1 Kontext [dev]: chỉnh ảnh theo prompt, tuỳ chọn kèm ảnh tham chiếu ghép bên phải | `pip install -U diffusers bitsandbytes`; đăng nhập Hugging Face và chấp nhận điều khoản; `--kontext-model-id`, `--keep-kontext` | **PHI THƯƠNG MẠI** |
| `video` | Ảnh → clip (SVD), xem mục 249 | `--svd-model-id`, `--keep-svd` | tự kiểm tra |

**Giấy phép**: dùng cho dự án cá nhân thì ghi chú là đủ, nhưng không dùng kết quả của các tác vụ phi thương mại cho sản phẩm thương mại khi chưa kiểm tra điều khoản. `faceswap` chỉ dùng cho nhân vật hư cấu của bạn (ảnh neo do chính bạn tạo); không đưa ảnh người thật vào khi chưa có sự đồng ý của họ.
**Chưa kiểm chứng**: các tác vụ này mới được test với module GIẢ (xem `tools/test_remote_tasks.py`); chưa chạy trên GPU/trọng số thật. `kontext` chọn fp16 trên GPU compute capability < 8 (T4 không có bf16 phần cứng; kết quả có thể khác bf16) và bf16 nơi khác, nén NF4 4-bit.
**`faceswap` có bảo vệ (mục 251)**: đo biểu cảm bằng landmark 68 trước–sau, khôi phục miệng/mắt gốc hoặc hoàn nguyên nếu lệch; kiểm kích thước/vị trí mặt; bỏ qua mặt quay > 55°; báo cáo JSON nhúng trong khối `tEXt` của PNG. Tham số `preserve`: `auto` (mặc định) | `mouth_eyes` | `none`. Ngưỡng chưa hiệu chỉnh.



---

## Thử nhanh từng tác vụ (smoke test) — mục 255

Sau khi server chạy (`python app.py --auth-token ...` + URL tunnel), bạn có thể thử từng tác vụ trên MỘT ảnh ngay từ máy mình,
không cần APK, bằng `smoke_test.py` (dùng đúng giao thức mã hoá của app):

```
pip install requests cryptography pillow
python smoke_test.py --url https://xxxx.trycloudflare.com --token MA_TOKEN --image panel.png \
    --ref mat_nhan_vat.png --face-box 0.30,0.08,0.62,0.40 --tasks generate,faceswap,handfix,interact,kontext
```

- In **fingerprint** server (đối chiếu với dòng server in lúc khởi động; có thể ghim bằng `--fingerprint`), thời gian từng tác vụ, **lỗi nguyên văn**
  của server (vd `CUDA out of memory` khi `kontext` không vừa VRAM) và báo cáo `mangalocal_report` của `faceswap`.
- Kết quả lưu ở `smoke_out/` (`generate.png`, `faceswap.png`, `handfix.png`, `interact.png`, `kontext.png`, `video.mp4`).
- `faceswap` cần `--ref` và `--face-box` (hộp mặt chuẩn hoá x1,y1,x2,y2 trong `--image`); thiếu thì tác vụ bị BỎ QUA (không tính là lỗi).
  `video` (SVD, nặng) chỉ chạy khi bạn nêu rõ trong `--tasks`.
- Chỉ kiểm tra "server có chạy và trả gì", KHÔNG đánh giá chất lượng ảnh — bạn nhìn ảnh trong `smoke_out/` rồi gửi lại để hiệu chỉnh ngưỡng.
