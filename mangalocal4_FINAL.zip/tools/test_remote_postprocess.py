#!/usr/bin/env python3
"""mục 250 — kiểm thử phía APP của hậu kỳ trên server (faceswap / handfix / kontext).

Thuật toán thuần (`headBox`, `isPng`, tên file) được chép lại bằng Python; hằng số/điều kiện được đối chiếu chuỗi nguồn Kotlin, cùng với nối dây
(client → pipeline → ViewModel → Cài đặt) và cảnh báo giấy phép. KHÔNG chạy được Kotlin/mạng/server ở đây; phần SERVER được test riêng
(test_remote_tasks.py) bằng cách chạy thật hàm server với module giả. CHƯA build-test.
"""
import math, os, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
KB = os.path.join(ROOT, 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(KB, *p), encoding='utf8').read()
RP = rd('pipeline', 'RemotePostProcess.kt')

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

# ---------------- bản chép ----------------
def head_box(j):   # j: list 18 của (x, y, visible)
    if len(j) < 18: return None
    xs = [(j[i][0], j[i][1]) for i in (0, 14, 15, 16, 17) if j[i][2]]
    if not xs: return None
    cx, cy = sum(x for x, _ in xs) / len(xs), sum(y for _, y in xs) / len(xs)
    pair = lambda a, b: abs(j[a][0] - j[b][0]) if j[a][2] and j[b][2] else None
    s = pair(2, 5) * 0.55 if pair(2, 5) is not None else (pair(14, 15) * 3.2 if pair(14, 15) is not None else (pair(16, 17) * 1.6 if pair(16, 17) is not None else 0.14))
    s = max(0.06, min(0.35, s))
    cl = lambda v: max(0.0, min(1.0, v))
    x1, x2, y1, y2 = cl(cx - 0.6 * s), cl(cx + 0.6 * s), cl(cy - 0.75 * s), cl(cy + 0.75 * s)
    return (x1, y1, x2, y2) if x2 > x1 and y2 > y1 else None

STAND = [(0.50, 0.12), (0.50, 0.20), (0.42, 0.20), (0.38, 0.32), (0.36, 0.44), (0.58, 0.20), (0.62, 0.32), (0.64, 0.44),
         (0.45, 0.50), (0.45, 0.68), (0.45, 0.88), (0.55, 0.50), (0.55, 0.68), (0.55, 0.88),
         (0.48, 0.10), (0.52, 0.10), (0.46, 0.11), (0.54, 0.11)]
def person(cx=0.5, cy=0.5, scale=1.0, hide=()):
    return [(cx + (x - 0.5) * scale, cy + (y - 0.5) * scale, i not in hide) for i, (x, y) in enumerate(STAND)]

b = head_box(person())
check('đứng thẳng: hộp đầu bao quanh mũi/mắt/tai và nằm TRÊN vai', b is not None and b[0] < 0.5 < b[2] and b[1] < 0.12 < b[3] and b[3] < 0.2 + 0.1)
check('kích thước theo bề rộng vai: vai 0.16 -> s = 0.55 × 0.16 = 0.088 -> rộng 1.2·s = 0.1056, cao 1.5·s = 0.132', abs((b[2] - b[0]) - 0.1056) < 1e-6 and abs((b[3] - b[1]) - 0.132) < 1e-6)
b2 = head_box(person(scale=0.8))
check('người nhỏ hơn (xa hơn) 0.8× -> hộp nhỏ hơn tương ứng (0.8 × 0.1056)', (b2[2] - b2[0]) < (b[2] - b[0]) and abs((b2[2] - b2[0]) - 0.8 * 0.1056) < 1e-6)
check('không thấy vai -> dùng khoảng cách hai mắt × 3.2', abs((head_box(person(hide=(2, 5)))[2] - head_box(person(hide=(2, 5)))[0]) - 0.6 * 2 * (0.04 * 3.2)) < 1e-6)
check('không thấy vai và mắt -> dùng khoảng cách hai tai × 1.6', abs((head_box(person(hide=(2, 5, 14, 15)))[2] - head_box(person(hide=(2, 5, 14, 15)))[0]) - 1.2 * (0.08 * 1.6)) < 1e-6)
check('chỉ còn mũi -> kích thước mặc định 0.14', abs((head_box(person(hide=(2, 5, 14, 15, 16, 17)))[2] - head_box(person(hide=(2, 5, 14, 15, 16, 17)))[0]) - 1.2 * 0.14) < 1e-6)
check('không thấy khớp đầu nào -> null (không đoán bừa)', head_box(person(hide=(0, 14, 15, 16, 17))) is None)
def custom(shoulder_half, cx=0.5, cy=0.4):
    j = person(cx, cy, 0.3)
    j[2] = (cx - shoulder_half, cy + 0.05, True); j[5] = (cx + shoulder_half, cy + 0.05, True)
    return j
wide, narrow = head_box(custom(0.4)), head_box(custom(0.004))
check('kẹp kích thước [0.06, 0.35]: vai rộng bất thường (0.8) -> s=0.35, vai hẹp (0.008) -> s=0.06', abs((wide[2] - wide[0]) - 1.2 * 0.35) < 1e-6 and abs((narrow[2] - narrow[0]) - 1.2 * 0.06) < 1e-6)
check('đầu nằm NGOÀI ảnh (vd phóng quá lớn) -> hộp suy biến sau khi kẹp -> null thay vì hộp sai', head_box(person(scale=5.0)) is None)
edge = head_box(custom(0.04, cx=0.03, cy=0.2))   # đầu sát mép trái
check('hộp luôn nằm trong ảnh [0,1] kể cả người sát mép', all(0 <= v <= 1 for v in edge) and edge[2] > edge[0] and edge[3] > edge[1])
check('danh sách khớp ngắn hơn 18 -> null, không ngoại lệ', head_box(person()[:10]) is None)

PNG = b'\x89PNG\r\n\x1a\n' + b'\x00' * 8
is_png = lambda b: len(b) >= 8 and b[:8] == b'\x89PNG\r\n\x1a\n'
check('isPng: PNG đúng -> đúng; JPEG / mp4 / rỗng / ngắn -> sai', is_png(PNG) and not is_png(b'\xff\xd8\xff\xe0' + b'\x00' * 20) and not is_png(b'\x00\x00\x00\x18ftypmp42' + b'\x00' * 8) and not is_png(b'') and not is_png(b'\x89PNG'))
check('tên file kết quả: panel_NNN_srv.png, 1-based, không đè ảnh gốc', 'panel_%03d_srv.png'.format if False else ('panel_%03d_srv.png' % 1) == 'panel_001_srv.png' and '"panel_%03d_srv.png".format(panelIndex + 1)' in RP)

# ---------------- đối chiếu nguồn Kotlin ----------------
check('Kotlin: headBox khớp bản chép (khớp đầu, hệ số, kẹp, hộp ±0.6·s / ±0.75·s)',
      'intArrayOf(0, 14, 15, 16, 17)' in RP and 'pair(2, 5)?.times(0.55f)' in RP and 'pair(14, 15)?.times(3.2f)' in RP and 'pair(16, 17)?.times(1.6f)' in RP and '?: 0.14f).coerceIn(0.06f, 0.35f)' in RP
      and 'cx - 0.6f * s' in RP and 'cy - 0.75f * s' in RP and 'joints.size < OutputVerifier.JOINTS' in RP and 'if (n == 0) return null' in RP)
check('Kotlin: isPng đủ 8 byte chữ ký', all(t in RP for t in ['b.size >= 8', 'b[0] == 0x89.toByte()', "b[1] == 'P'.code.toByte()", "b[2] == 'N'.code.toByte()", "b[3] == 'G'.code.toByte()", 'b[4] == 0x0D.toByte()', 'b[5] == 0x0A.toByte()', 'b[6] == 0x1A.toByte()', 'b[7] == 0x0A.toByte()']))
check('giấy phép được ghi trong mã: phi thương mại (inswapper, Kontext), Apache-2.0 (HandRefiner), nhân vật hư cấu', 'PHI THƯƠNG MẠI' in RP and 'Apache-2.0' in RP and 'HƯ CẤU' in RP)

RC, MP, VM, ML, ST = rd('pipeline', 'RemoteGenerationClient.kt'), rd('pipeline', 'MangaPipeline.kt'), rd('ui', 'MainViewModel.kt'), rd('model', 'Models.kt'), rd('ui', 'SettingsScreen.kt')
i = RC.index('suspend fun runImageTask'); RT = RC[i:RC.index('private fun aesGcmEncrypt')]
check('client: runImageTask gửi task + image_b64 + phần phụ, cùng đường mã hoá và endpoint /generate', 'put("task", task)' in RT and 'put("image_b64"' in RT and 'extra.forEach' in RT and 'aesGcmEncrypt(aesKey' in RT and 'rsaOaepEncrypt(pubKey' in RT and '/generate' in RT)
check('client: TỪ CHỐI phản hồi không có echo task đúng (server cũ sẽ sinh ảnh rác) và không phải PNG', 'respJson.optString("task") != task' in RT and 'RemotePostProcess.isPng(bytes)' in RT)
check('client: lỗi cố định (RemoteTaskException) không thử lại; chỉ 429/lỗi mạng mới thử lại; thời hạn đọc dài', 'catch (ex: RemoteTaskException) {\n                throw ex' in RT and 'if (resp.code == 429)' in RT and 'RemotePostProcess.TASK_READ_TIMEOUT_S' in RT)
check('client: kiểm tra echo xảy ra TRƯỚC khi giải mã/nhận ảnh', RT.index('respJson.optString("task")') < RT.index('aesGcmDecrypt('))

j = MP.index('suspend fun remotePostProcess'); RPP = MP[j:MP.index('// mục 228 TECHNICAL_STATUS.md — vị trí ĐẦU')]
check('pipeline: thoát sớm khi Remote GPU tắt hoặc không công tắc nào bật (hành vi cũ giữ nguyên)', 'if (!cfg.enabled || !(doKontext || doHand || doSwap)) return@withContext chapter' in RPP)
check('pipeline: thứ tự Kontext → sửa tay → hoán đổi mặt', RPP.index('TASK_KONTEXT') < RPP.index('TASK_HANDFIX') < RPP.index('TASK_FACESWAP'))
check('pipeline: Kontext chỉ khi ĐÚNG 1 nhân vật có ảnh neo; faceswap chỉ khi có đích; ghi log lý do bỏ qua', 'if (targets.size == 1)' in RPP and 'if (targets.isNotEmpty())' in RPP and 'Kontext bỏ qua panel' in RPP and 'Hoán đổi mặt bỏ qua panel' in RPP)
check('pipeline: kết quả ghi ra file MỚI và gán upscaledPath; ảnh gốc imagePath không bị đụng', 'File(outDir, RemotePostProcess.panelFileName(panel.index))' in RPP and 'panel.copy(upscaledPath = out.absolutePath,' in RPP and 'imagePath =' not in RPP)
check('pipeline: lỗi một panel -> giữ ảnh cũ của panel đó; server không hỗ trợ -> dừng các panel còn lại', 'catch (ex: RemoteGenerationClient.RemoteTaskException) {\n                stopped = true' in RPP and 'giữ ảnh cũ' in RPP and 'if (stopped || src == null' in RPP)
check('pipeline: không ghi file/đổi panel khi chưa bước nào chạy (changed=false -> trả nguyên panel)', 'if (!changed) return@map panel' in RPP)
k = MP.index('private fun remoteTargetsForPanel'); RTP = MP[k:MP.index('suspend fun remotePostProcess')]
check('pipeline: hộp đầu lấy từ khung xương cùng cách xếp người ↔ nhân vật như lúc sinh ảnh (stableCharacterOrder), chỉ giữ nhân vật còn file ảnh neo', 'stableCharacterOrder(panel.scene.characters, story.characters)' in RTP and 'OutputVerifier.targetsFromSkeleton(sk)' in RTP and 'RemotePostProcess.headBox(people[i].joints)' in RTP and 'File(ref).isFile' in RTP)
check('pipeline: JSON gửi server đúng khoá id/box/ref_b64 (khớp server)', 'put("id", t.name)' in RPP and 'put("box"' in RPP and 'put("ref_b64"' in RPP and '"targets" to arr' in RPP and '"ref_b64" to b64(' in RPP and '"prompt" to RemotePostProcess.KONTEXT_PROMPT' in RPP)
SV = open(os.path.join(ROOT, 'tools', 'remote_server', 'app.py'), encoding='utf8').read()
check('khớp giao thức app ↔ server: khoá `targets[].{id,box,ref_b64}`, `prompt`, `ref_b64`, tên tác vụ', 't.get("box")' in SV and 't.get("ref_b64")' in SV and 't.get("id", ti)' in SV and 'payload.get("targets")' in SV and 'payload.get("ref_b64")' in SV and 'payload.get("prompt")' in SV
      and all(('"%s"' % n) in SV for n in ('faceswap', 'handfix', 'kontext')) and 'TASK_FACESWAP = "faceswap"' in RP and 'TASK_HANDFIX = "handfix"' in RP and 'TASK_KONTEXT = "kontext"' in RP)
check('hook ViewModel: chạy SAU upscaleApprovedPanels, trong khoá generationMutex, trước khi lưu chương', 'val upscaled0 = generationMutex.withLock { pipeline.upscaleApprovedPanels' in VM and 'pipeline.remotePostProcess(upscaled0, story, _settings.value, outDir)' in VM
      and VM.index('remotePostProcess(upscaled0') < VM.index('storyManager.saveChapter(upscaled)', VM.index('remotePostProcess(upscaled0')))
check('Models: ba cờ mặc định TẮT', all('val %s: Boolean = false' % f in ML for f in ('remoteFaceSwap', 'remoteHandFix', 'remoteKontext')))
check('Cài đặt: ba công tắc + cảnh báo "GIẤY PHÉP PHI THƯƠNG MẠI" cho hoán đổi mặt và Kontext, Apache-2.0 cho HandRefiner', all(('copy(%s = it)' % f) in ST for f in ('remoteFaceSwap', 'remoteHandFix', 'remoteKontext')) and ST.count('GIẤY PHÉP PHI THƯƠNG MẠI') >= 2 and 'Apache-2.0' in ST and '--inswapper-path' in ST)

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
