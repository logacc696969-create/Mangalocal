"""
export_midas_depth.py — Export MiDaS-small (ước lượng độ sâu ĐƠN ẢNH,
Intel ISL) sang ONNX, để prepare_models.yml convert tiếp sang .mnn (giống
quy ước export_yolo_pose.py/export_mobilesam.py — script Python chỉ lo
tới ONNX, mnnconvert nằm trong workflow YAML).

TẠI SAO FILE NÀY (mục 220 → mục 221 TECHNICAL_STATUS.md — user hỏi
"AI tạo video giải quyết tỷ lệ nhân vật/bối cảnh/góc máy thế nào"):

Đã `web_search` thật (không suy diễn) loạt paper/dự án camera-conditioned
video generation (CameraCtrl, MotionCtrl, CamCo, GEN3C, RealCamI2V, IDC-Net...)
— phát hiện: các dự án SOTA giải bài toán "camera-nhất quán" theo 2 hướng,
KHÔNG hướng nào là "tự suy luận calib camera từ hư không":
  1. Camera trajectory là INPUT TƯỜNG MINH do người dùng/hệ thống cung cấp
     (Plücker embedding của pose+intrinsics đã biết) — ĐÚNG tinh thần
     "annotation tường minh" mà `Scene.depthScale` (mục 121) và
     `Location.referenceFraming` (mục 220) đã chọn từ trước.
  2. Chạy 1 MODEL ƯỚC LƯỢNG ĐỘ SÂU ĐƠN ẢNH có sẵn (MiDaS/DPT — "off-the-shelf
     depth estimation model", xuất hiện lặp lại ở HẦU HẾT paper tra được:
     GEN3C, RealCamI2V, DaS, MVGenMaster) để dựng point-cloud/depth map
     TỪ ảnh gốc, rồi warp theo camera mong muốn. Nghiên cứu compositing
     (paper "INSPIRED" — object placement trong ảnh 2D) dùng ĐÚNG kỹ
     thuật này cho bài toán GẦN NHẤT với MangaLocal: "monocular depth
     estimation... for correct scale and placement" khi chèn 1 vật/người
     vào 1 ảnh nền có sẵn.

File này là NỀN MÓNG cho hướng #2 — dùng model depth ĐƠN ẢNH (không phải
model camera-trajectory phức tạp của paper video ở trên, những cái đó cần
input camera pose mà MangaLocal không có) chạy trên CHÍNH ảnh neo bối cảnh
(Location.anchorImagePath, mục 216/217) để ước lượng độ sâu THẬT của ảnh
đó — thay vì chỉ có ghi chú chữ thủ công (`referenceFraming`, mục 220).

TẠI SAO MIDAS-SMALL (đã tra cứu qua nhiều nguồn — trang PyTorch Hub chính
thức intel-isl/MiDaS, bản dịch tiếng Hàn chính thức pytorch.kr, nhiều
HuggingFace Spaces dùng lại y hệt cách gọi — KHÔNG đoán):
  - Model ước lượng độ sâu ĐƠN ẢNH lâu đời nhất/dùng lại nhiều nhất trong
    nghiên cứu (xuất hiện lặp lại làm "off-the-shelf" ở hầu hết paper tra
    ở trên) — rủi ro thấp hơn model mới/ít kiểm chứng.
  - Bản "small" (MiDaS v2.1 small, tên hub `MiDaS_small`) là bản CHÍNH
    THỨC tối ưu cho thiết bị di động — benchmark công bố ngay trong repo
    gốc: ~30 FPS trên iPhone 11 (so với 0.6 FPS của bản MiDaS v2 small cũ
    hơn) — ĐÚNG đối tượng "CPU-only, thiết bị di động" như MobileSAM (mục
    21) đã chọn.
  - Cách gọi CHÍNH THỨC, xác nhận khớp nhau qua NHIỀU nguồn độc lập (trang
    hub chính thức + ít nhất 4 HuggingFace Spaces khác nhau đều gọi y hệt):
      midas = torch.hub.load("intel-isl/MiDaS", "MiDaS_small")
      transform = torch.hub.load("intel-isl/MiDaS", "transforms").small_transform
    Input sau transform: RGB [1,3,256,256] (bản small dùng input 256x256,
    tên hub cũ ghi rõ "midas_v21_small_256"). Output: 1 kênh ĐỘ SÂU TƯƠNG
    ĐỐI (KHÔNG PHẢI mét thật — đây là "inverse relative depth", đúng bản
    chất monocular depth estimation không có hiệu chuẩn camera, xem GIỚI
    HẠN THẬT bên dưới) ở ĐÚNG resolution nội bộ model (cần
    `torch.nn.functional.interpolate` phóng lại về kích thước ảnh gốc ở
    bước XỬ LÝ SAU model — bước đó KHÔNG nằm trong graph ONNX này, xem
    GIỚI HẠN THẬT).

Cài đặt:
    pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
    pip install timm  # MiDaS backbone dùng timm, xác nhận qua chính trang hub

Chạy (tự tải qua torch.hub, cache vào ~/.cache/torch/hub):
    python export_midas_depth.py --output_dir ./exported_midas

============================== GIỚI HẠN THẬT ==============================
QUAN TRỌNG — ĐỌC KỸ TRƯỚC KHI DÙNG, nhất là trước khi nối vào app thật:

1. **CHƯA BUILD-TEST** — giống mọi script export mới thêm vào dự án này
   lúc mới viết (vd export_mobilesam.py mục 21) — CHƯA tự chạy
   `torch.hub.load()` thật (sandbox phiên này không có mạng để tải
   checkpoint, chỉ tra cứu được cách gọi qua `web_search`/`web_fetch`,
   KHÔNG như mục 97 từng pip-install-thật để đối chiếu). Cú pháp
   `torch.hub.load("intel-isl/MiDaS", "MiDaS_small")` xác nhận khớp nhau
   qua NHIỀU nguồn độc lập nên tự tin ở MỨC "nhiều nguồn đồng thuận",
   KHÔNG phải mức "đã tự chạy qua mắt mình" như mục 97.
2. **Giá trị mean/std chuẩn hoá ảnh CHÍNH XÁC của `small_transform`** CHƯA
   tự đọc được trực tiếp từ source `transforms.py` thật (chỉ tra được MÔ
   TẢ chức năng, không phải soi được đúng từng con số) — bên dưới dùng
   tạm chuẩn ImageNet phổ biến (mean=[0.485,0.456,0.406],
   std=[0.229,0.224,0.225], gắn với comment "CẦN ĐỐI CHIẾU LẠI") vì đây
   là chuẩn hầu hết backbone timm/torchvision pretrained trên ImageNet
   dùng (MiDaS backbone dùng timm) — HỢP LÝ nhưng CHƯA soi tận nguồn xác
   nhận 100% khớp. Ai chạy tay script này lần đầu nên tự
   `torch.hub.load("intel-isl/MiDaS", "transforms").small_transform` rồi
   in ra để đối chiếu lại đúng số trước khi tin.
3. **Output là ĐỘ SÂU TƯƠNG ĐỐI, không phải mét thật** — đây KHÔNG giải
   quyết được "thiếu hiệu chuẩn camera" mà mục 121/220 đã nêu (không biết
   tiêu cự/chiều cao đặt máy thật của ảnh neo) — chỉ cho biết "vùng A xa
   HAY gần hơn vùng B trong CÙNG 1 ảnh", KHÔNG cho ra tỷ lệ TUYỆT ĐỐI
   (vd "người cao 1m7 đứng ở đây sẽ cao bao nhiêu pixel"). Bài toán đó
   (ước lượng scale/placement tuyệt đối) là việc riêng, phức tạp hơn
   (xem paper "INSPIRED" ở trên — họ cộng thêm bước riêng ước lượng mặt
   phẳng/kích thước tham chiếu, KHÔNG chỉ chạy 1 model depth suông) —
   CHƯA thiết kế/làm ở đây.
4. **File này CHỈ export ONNX** — KHÔNG có native wrapper (.cpp), KHÔNG
   nối JNI/Kotlin, KHÔNG có bước xử lý-sau (interpolate về kích thước
   ảnh gốc, normalize hiển thị) — đó là bước NativeC++ riêng, cố tình
   CHƯA làm cùng lượt này (rủi ro cao hơn nếu viết native mù mà không có
   file .onnx thật để soi shape input/output — xem "VIỆC CÒN LẠI" ở mục
   221 TECHNICAL_STATUS.md).
5. Chưa quyết định cách DÙNG kết quả depth map trong pipeline sinh ảnh
   thật (vd: suy ra depthScale gợi ý cho từng nhân vật theo vị trí đứng
   dự kiến trong khung hình, hay dùng trực tiếp làm ControlNet-Depth hint
   thay cho canvas tổng hợp từ skeleton hiện tại) — CẦN BÀN THIẾT KẾ
   trước khi làm, không làm mù (đúng nguyên tắc mục 216 đã áp dụng cho
   "vật thể + vị trí tuyệt đối").
=============================================================================
"""
import argparse
import os


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output_dir", default="./exported_midas")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    import torch

    print("Đang tải MiDaS_small qua torch.hub (tự tải checkpoint pretrained "
          "nếu chưa có trong cache) — cần mạng lần chạy đầu tiên...")
    midas = torch.hub.load("intel-isl/MiDaS", "MiDaS_small")
    midas.eval()

    # Input cố định 256x256 — ĐÚNG shape small_transform tạo ra (tên hub cũ
    # "midas_v21_small_256" xác nhận số 256), khớp quy ước "shape cố định,
    # không dynamic_axes" xuyên suốt mọi script export trong dự án này.
    example_input = torch.randn(1, 3, 256, 256)

    onnx_path = os.path.join(args.output_dir, "midas_small_depth.onnx")
    print(f"Đang export ONNX -> {onnx_path}...")
    with torch.no_grad():
        # mục 97/217 đợt 1 TECHNICAL_STATUS.md — torch >=2.9 đổi exporter
        # mặc định sang nhánh dynamo (cần onnxscript, có thể lỗi ngay nếu
        # môi trường export không cài sẵn) — ghim dynamo=False tường minh,
        # AN TOÀN ở mọi version torch (tham số này tồn tại từ trước, chỉ
        # đổi giá trị MẶC ĐỊNH ở 2.9), đúng bài học đã áp dụng cho toàn bộ
        # 15 lệnh gọi torch.onnx.export() khác trong dự án.
        torch.onnx.export(
            midas,
            example_input,
            onnx_path,
            input_names=["image"],
            output_names=["depth"],
            opset_version=17,
            dynamo=False,
        )

    print(f"\nXong: {onnx_path}")
    print("Shape input ĐÃ DÙNG lúc export (cố định, không dynamic_axes):", tuple(example_input.shape))
    print("\nBƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter — file này")
    print("KHÔNG tự động trong prepare_models.yml, cần thêm bước riêng nếu muốn CI tự làm):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, 'midas_small_depth.mnn')} --bizCode biz")
    print("\nQUAN TRỌNG — đọc phần GIỚI HẠN THẬT ở đầu file trước khi coi đây là")
    print("bước đã 'xong' — CHƯA có native wrapper/tiền xử lý ảnh/hậu xử lý depth")
    print("map, CHƯA nối vào pipeline sinh ảnh thật. Xem mục 221 TECHNICAL_STATUS.md.")


if __name__ == "__main__":
    main()
