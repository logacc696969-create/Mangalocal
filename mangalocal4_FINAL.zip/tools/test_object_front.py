#!/usr/bin/env python3
"""mục 263 — kiểm thử vật thể "TRƯỚC người" trong khối độ sâu (`ObjectBox.front` + `ObjectDepthBlockout.applyFront`) bằng kotlinc THẬT.

Chạy Kotlin thật trên JVM (`data class ObjectBox` được TRÍCH NGUYÊN VĂN từ Models.kt), so TỪNG BYTE với bản tham chiếu Python viết độc lập từ đặc tả:
  lượt 1: hộp front=false vẽ mức LEVEL (36) lên pixel tối hơn (như cũ); lượt 2: hộp front=true — thống kê người từ ảnh chụp sau lượt 1; nếu hộp phủ > 60% tổng pixel người
  thì rơi về LEVEL, ngược lại mức = min(255, người sáng nhất trong hộp + 24) (không có người: 96); chỉ tô pixel tối hơn mức.
Fuzz 600 ảnh + ca tay + tính chất + thử phá mã (đột biến PHẢI biên dịch được). KHÔNG chứng minh: ControlNet-Depth vẽ ra đúng vật đứng trước người (cần ảnh thật).
Cần kotlinc (KOTLINC=...); không có -> BỎ QUA.
"""
import math, os, random, re, shutil, struct, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + d) if (d and not c) else '')); ok &= bool(c)
def find():
    for c in [os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/work/kotlinc/bin/kotlinc']:
        if c and os.path.exists(c): return c
KOTLINC = find()
SRC = os.path.join(KT, 'pipeline/ObjectDepthBlockout.kt')
MODELS = open(os.path.join(KT, 'model/Models.kt'), encoding='utf-8').read()
m = re.search(r'data class ObjectBox\((?:[^()]|\([^()]*\))*\)', MODELS, re.S)
SHIM = 'package com.mangalocal.model\n' + (m.group(0) if m else '')
DRV = r'''
import com.mangalocal.model.ObjectBox
import com.mangalocal.pipeline.ObjectDepthBlockout
import java.io.*
import java.nio.*
fun main(args: Array<String>) {
    val bb = ByteBuffer.wrap(File(args[0]).readBytes()).order(ByteOrder.LITTLE_ENDIAN)
    val nc = bb.int
    val out = ByteArrayOutputStream()
    repeat(nc) {
        val size = bb.int; val nb = bb.int
        val boxes = ArrayList<ObjectBox>()
        repeat(nb) { val a = bb.float; val b = bb.float; val c = bb.float; val d = bb.float; val f = bb.int; boxes.add(ObjectBox("x", a, b, c, d, f != 0)) }
        val hint = ByteArray(size * size * 3); bb.get(hint)
        out.write(ObjectDepthBlockout.apply(hint, size, boxes))
    }
    File(args[1]).writeBytes(out.toByteArray())
}
'''
LEVEL, FLOOR, MARGIN, FMIN, PCT = 36, 48, 24, 96, 60
def rect(b, size):
    xmin, ymin, xmax, ymax = b[:4]
    if not (xmax > xmin and ymax > ymin): return None   # NaN cũng rơi vào đây
    cl = lambda v: min(max(v, 0.0), 1.0)
    x0 = min(max(math.floor(cl(xmin) * size), 0), size); x1 = min(max(math.ceil(cl(xmax) * size), 0), size)
    y0 = min(max(math.floor(cl(ymin) * size), 0), size); y1 = min(max(math.ceil(cl(ymax) * size), 0), size)
    return None if (x1 <= x0 or y1 <= y0) else (x0, y0, x1, y1)
def ref(hint, size, boxes):
    if not boxes or size <= 0 or len(hint) != size * size * 3: return bytes(hint)
    out = bytearray(hint)
    def paint(r, level):
        for y in range(r[1], r[3]):
            for x in range(r[0], r[2]):
                i = (y * size + x) * 3
                if out[i] < level: out[i] = out[i + 1] = out[i + 2] = level
    for b in boxes:
        if b[4]: continue
        r = rect(b, size)
        if r: paint(r, LEVEL)
    fronts = [b for b in boxes if b[4]]
    if fronts:
        snap = bytes(out)
        total = sum(1 for i in range(size * size) if snap[i * 3] >= FLOOR)
        for b in fronts:
            r = rect(b, size)
            if not r: continue
            inb = 0; mx = 0
            for y in range(r[1], r[3]):
                for x in range(r[0], r[2]):
                    v = snap[(y * size + x) * 3]
                    if v >= FLOOR: inb += 1; mx = max(mx, v)
            too = total > 0 and inb * 100 > total * PCT
            level = LEVEL if too else (min(255, mx + MARGIN) if mx > 0 else FMIN)
            paint(r, level)
    return bytes(out)
def mk_hint(size, rng, persons=None):
    h = bytearray(size * size * 3)
    for p in (persons if persons is not None else [(rng.randint(0, size - 4), rng.randint(0, size - 4), rng.randint(3, size // 2), rng.randint(3, size // 2), rng.randint(48, 255)) for _ in range(rng.randint(0, 3))]):
        x0, y0, w, hh, v = p
        for y in range(y0, min(y0 + hh, size)):
            for x in range(x0, min(x0 + w, size)):
                vv = min(255, max(48, v + (x - x0)))
                i = (y * size + x) * 3; h[i] = h[i + 1] = h[i + 2] = vv
    return bytes(h)
def run(src_path, tmp, tag, cases):
    d = os.path.join(tmp, tag); os.makedirs(d, exist_ok=True)
    open(os.path.join(d, 'Drv.kt'), 'w').write(DRV); open(os.path.join(d, 'Shim.kt'), 'w').write(SHIM)
    jar = os.path.join(tmp, tag + '.jar')
    r = subprocess.run([KOTLINC, src_path, os.path.join(d, 'Shim.kt'), os.path.join(d, 'Drv.kt'), '-d', jar], capture_output=True, text=True)
    if r.returncode != 0: return None, 'compile: ' + r.stderr[-500:]
    fi = os.path.join(tmp, tag + '.in'); fo = os.path.join(tmp, tag + '.out')
    b = struct.pack('<i', len(cases))
    for size, boxes, hint in cases:
        b += struct.pack('<ii', size, len(boxes))
        for bx in boxes: b += struct.pack('<ffffi', bx[0], bx[1], bx[2], bx[3], int(bx[4]))
        b += hint
    open(fi, 'wb').write(b)
    klib = os.path.join(os.path.dirname(os.path.dirname(KOTLINC)), 'lib', 'kotlin-stdlib.jar')
    o = subprocess.run(['java', '-cp', f'{jar}:{klib}', 'DrvKt', fi, fo], capture_output=True, text=True)
    if o.returncode != 0: return None, 'run: ' + o.stderr[-300:]
    data = open(fo, 'rb').read(); outs = []; pos = 0
    for size, _, _ in cases: n = size * size * 3; outs.append(data[pos:pos + n]); pos += n
    return outs, ''
def gen_cases():
    rng = random.Random(263); size = 40; cases = []
    nan = float('nan')
    for _ in range(600):
        hint = mk_hint(size, rng)
        if rng.random() < 0.1:   # thỉnh thoảng có giá trị 1..47 để thử điều kiện "tối hơn mức"
            h = bytearray(hint)
            for _ in range(30):
                i = (rng.randint(0, size * size - 1)) * 3; v = rng.randint(1, 47); h[i] = h[i + 1] = h[i + 2] = v
            hint = bytes(h)
        boxes = []
        for _ in range(rng.randint(0, 4)):
            x0 = rng.uniform(-0.2, 1.0); y0 = rng.uniform(-0.2, 1.0)
            bx = [x0, y0, x0 + rng.uniform(-0.05, 0.9), y0 + rng.uniform(-0.05, 0.9), rng.random() < 0.55]
            if rng.random() < 0.03: bx[rng.randint(0, 3)] = nan
            boxes.append(tuple(bx))
        cases.append((size, boxes, hint))
    return cases
def hand_cases():
    size = 40; h = []; C = []
    # (a) hai người; hộp trước phủ người 1 (nhỏ) -> level = maxP + 24
    hint = mk_hint(size, None, [(2, 2, 6, 6, 100), (24, 24, 10, 10, 100)])
    C.append(('a', size, [(0.0, 0.0, 0.25, 0.25, True)], hint))
    # (b) chốt: hộp phủ 100% người duy nhất -> rơi về LEVEL (người giữ nguyên, nền trong hộp = 36)
    hint = mk_hint(size, None, [(10, 10, 8, 8, 120)])
    C.append(('b', size, [(0.2, 0.2, 0.6, 0.6, True)], hint))
    # (c) không có người trong hộp -> 96
    C.append(('c', size, [(0.0, 0.0, 0.3, 0.3, True)], mk_hint(size, None, [(30, 30, 8, 8, 100)])))
    # (d) người sáng 250 -> kẹp 255
    hint = mk_hint(size, None, [(2, 2, 5, 5, 250), (28, 28, 10, 10, 100)])
    C.append(('d', size, [(0.0, 0.0, 0.2, 0.2, True)], hint))
    # (e) front=false như cũ
    C.append(('e', size, [(0.0, 0.0, 0.3, 0.3, False)], mk_hint(size, None, [(2, 2, 5, 5, 120), (28, 28, 8, 8, 100)])))
    # (f) hai hộp trước chồng nhau: kết quả không phụ thuộc thứ tự
    hint = mk_hint(size, None, [(4, 4, 8, 8, 100), (26, 26, 8, 8, 100)])
    C.append(('f1', size, [(0.0, 0.0, 0.3, 0.3, True), (0.1, 0.1, 0.4, 0.4, True)], hint))
    C.append(('f2', size, [(0.1, 0.1, 0.4, 0.4, True), (0.0, 0.0, 0.3, 0.3, True)], hint))
    return C
def suite(src, tmp, tag, quiet=False):
    bad = 0
    def chk(n, c, d=''):
        nonlocal bad
        if not c: bad += 1
        if not quiet: check(n, c, d)
    cases = gen_cases(); hc = hand_cases()
    allc = cases + [(s, b, h) for _, s, b, h in hc]
    outs, err = run(src, tmp, tag, allc)
    if outs is None: chk('chạy được', False, err); return bad, err
    fz, hd = outs[:len(cases)], outs[len(cases):]
    mism = sum(1 for (s, b, h), o in zip(cases, fz) if o != ref(h, s, b))
    chk('fuzz 600 ảnh: Kotlin thật khớp tham chiếu Python TỪNG BYTE', mism == 0, f'{mism} lệch')
    nofront = [(c, o) for c, o in zip(cases, fz) if not any(bx[4] for bx in c[1])]
    chk(f'mọi hộp front=false ({len(nofront)} ca): kết quả = thuật toán CŨ (lượt "sau người")', len(nofront) > 100 and all(o == ref(c[2], c[0], c[1]) for c, o in nofront))
    outside = True
    for (s, b, h), o in zip(cases, fz):
        rs = [rect(bx, s) for bx in b]; rs = [r for r in rs if r]
        for y in range(s):
            for x in range(s):
                if not any(r[0] <= x < r[2] and r[1] <= y < r[3] for r in rs):
                    i = (y * s + x) * 3
                    if o[i:i + 3] != h[i:i + 3]: outside = False
        if not outside: break
    chk('pixel NGOÀI mọi hộp không bao giờ đổi', outside)
    H = {k: (s, b, h, o) for (k, s, b, h), o in zip(hc, hd)}
    s, b, h, o = H['a']
    mxa = max(h[(y * s + x) * 3] for y in range(0, 10) for x in range(0, 10) if h[(y * s + x) * 3] >= FLOOR)
    chk(f'(a) hộp trước phủ người nhỏ: pixel người trong hộp = min(255, sáng nhất {mxa} + 24) = {min(255, mxa + 24)} (che người đúng kiểu z-buffer); người ngoài hộp giữ nguyên', o[(3 * s + 3) * 3] == min(255, mxa + 24) and o[(30 * s + 30) * 3] == h[(30 * s + 30) * 3])
    s, b, h, o = H['b']
    ib = (s * 10 + 9) * 3; chk('(b) chốt che người: hộp phủ 100% người duy nhất -> nền trong hộp (ngoài người) rơi về 36 (KHÔNG bỏ hẳn hộp)', o[ib] == 36)
    chk('(b) pixel người giữ nguyên', o[(14 * s + 14) * 3] == h[(14 * s + 14) * 3])
    s, b, h, o = H['c']; chk('(c) không có người trong hộp -> mức 96', o[(5 * s + 5) * 3] == 96)
    s, b, h, o = H['d']; chk('(d) người sáng 250 -> kẹp 255 (không tràn byte)', o[(3 * s + 3) * 3] == 255)
    s, b, h, o = H['e']; chk('(e) front=false: nền = 36, người không bị đè', o[(10 * s + 10) * 3] == 36 and o[(3 * s + 3) * 3] == h[(3 * s + 3) * 3])
    chk('(f) hai hộp trước chồng nhau: kết quả KHÔNG phụ thuộc thứ tự hộp', H['f1'][3] == H['f2'][3])
    return bad, ''
if not KOTLINC:
    print('SKIP: không có kotlinc'); sys.exit(0)
tmp = tempfile.mkdtemp()
check('trích được data class ObjectBox từ Models.kt (có trường front mặc định false)', m is not None and 'val front: Boolean = false' in SHIM)
bad, err = suite(SRC, tmp, 'real')
check('bộ kiểm trên mã THẬT: 0 lỗi', bad == 0, err)
if bad == 0:
    src = open(SRC, encoding='utf-8').read()
    muts = [
        ('FRONT_MARGIN = 0', 'const val FRONT_MARGIN = 24', 'const val FRONT_MARGIN = 0'),
        ('PERSON_FLOOR = 0', 'const val PERSON_FLOOR = 48', 'const val PERSON_FLOOR = 0'),
        ('bỏ chốt che người', 'val tooMuch = totalPerson > 0 && inBox * 100 > totalPerson * MAX_PERSON_OCCLUSION_PCT', 'val tooMuch = false'),
        ('chốt đảo chiều', 'inBox * 100 > totalPerson * MAX_PERSON_OCCLUSION_PCT', 'inBox * 100 < totalPerson * MAX_PERSON_OCCLUSION_PCT'),
        ('lấy người TỐI nhất thay vì sáng nhất', 'if (v > maxP) maxP = v', 'if (maxP == 0 || v < maxP) maxP = v'),
        ('thống kê từ ảnh đang vẽ thay vì ảnh chụp', 'val v = snap[(y * size + x) * 3].toInt() and 0xFF', 'val v = out[(y * size + x) * 3].toInt() and 0xFF'),
        ('FRONT_MIN_LEVEL = 0', 'const val FRONT_MIN_LEVEL = 96', 'const val FRONT_MIN_LEVEL = 0'),
        ('chốt: bỏ hẳn hộp thay vì rơi về LEVEL', 'val level = if (tooMuch) LEVEL else', 'val level = if (tooMuch) 0 else'),
        ('bỏ hộp front', 'val fronts = boxes.filter { it.front }', 'val fronts = emptyList<ObjectBox>()'),
        ('bỏ kẹp 255', 'minOf(255, maxP + FRONT_MARGIN)', '(maxP + FRONT_MARGIN)'),
    ]
    lo, hi = (int(x) for x in os.environ.get('MUT_RANGE', '0:999').split(':'))
    caught = 0; sel = [(k, mm) for k, mm in enumerate(muts) if lo <= k < hi]
    for k, (name, old, new) in sel:
        if old not in src: check(f'đột biến "{name}": mẫu có trong mã', False, 'mẫu không còn khớp'); continue
        mp = os.path.join(tmp, f'm{k}.kt'); open(mp, 'w', encoding='utf-8').write(src.replace(old, new, 1))
        b2, e2 = suite(mp, tmp, f'm{k}', quiet=True)
        if e2.startswith('compile'): check(f'đột biến "{name}" phải BIÊN DỊCH được (nếu không thì "bị bắt" là vô nghĩa)', False, e2); continue
        hit = b2 > 0 or e2.startswith('run')
        check(f'đột biến "{name}" bị bắt', hit); caught += hit
    check(f'thử phá mã: {caught}/{len(sel)} đột biến bị bắt', caught == len(sel))
# ---- nối dây tĩnh ----
LP = open(os.path.join(KT, 'pipeline/LLMParser.kt'), encoding='utf-8').read(); OB = open(os.path.join(KT, 'pipeline/ObjectDepthBlockout.kt'), encoding='utf-8').read()
check('LLMParser đọc "front" (mặc định false) và prompt chỉ cho phép front khi văn bản nói rõ vật đứng TRƯỚC', 'b.optBoolean("front", false)' in LP and '"front":true' in LP and 'Never add "front":true for background objects' in LP)
check('ObjectDepthBlockout: hộp front bị bỏ khỏi lượt "sau người" và có chốt che người', 'if (b.front) continue' in OB and 'MAX_PERSON_OCCLUSION_PCT' in OB)
check('PERSON_FLOOR khớp kDepthFloor trong ip_adapter.cpp', int(re.search(r'const val PERSON_FLOOR = (\d+)', OB).group(1)) == int(float(re.search(r'constexpr float kDepthFloor = ([\d.]+)f;', open(os.path.join(ROOT, 'app/src/main/jni/ip_adapter.cpp'), encoding='utf-8').read()).group(1))))
shutil.rmtree(tmp, ignore_errors=True)
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
