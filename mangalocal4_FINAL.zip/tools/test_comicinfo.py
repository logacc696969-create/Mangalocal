#!/usr/bin/env python3
"""mục 249 — kiểm thử ComicInfoXml (ComicInfo.xml trong CBZ, cờ phải → trái).

Chạy thật: XML sinh ra được PHÂN TÍCH bằng bộ đọc XML của Python (đúng/sai cú pháp, escape, ký tự cấm) và đóng thành
file zip thật để kiểm vị trí/tên tệp. Phần Kotlin chỉ đối chiếu chuỗi nguồn (CHƯA build-test, chưa thử trình đọc truyện thật).
"""
import os, re, sys, zipfile, tempfile
import xml.etree.ElementTree as ET

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
KB = os.path.join(ROOT, 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(KB, *p), encoding='utf8').read()
KT = rd('pipeline', 'ComicInfoXml.kt')

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

# ---- bản chép ----
def valid(c):
    o = ord(c)
    return c in '\t\n\r' or 0x20 <= o <= 0xD7FF or 0xE000 <= o <= 0xFFFD or 0x10000 <= o   # Python: ký tự ngoài BMP là 1 phần tử
def escape(s):
    out = []
    for c in s:
        if not valid(c): continue
        out.append({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;'}.get(c, c))
    return ''.join(out)

def build(title, series, number, pages, lang, rtl):
    s = '<?xml version="1.0" encoding="utf-8"?>\n<ComicInfo>\n'
    if title.strip(): s += '  <Title>%s</Title>\n' % escape(title.strip())
    if series.strip(): s += '  <Series>%s</Series>\n' % escape(series.strip())
    if number is not None and number >= 0: s += '  <Number>%d</Number>\n' % number
    s += '  <PageCount>%d</PageCount>\n' % max(pages, 0)
    if lang and lang.strip(): s += '  <LanguageISO>%s</LanguageISO>\n' % escape(lang.strip())
    s += '  <Manga>%s</Manga>\n' % ('YesAndRightToLeft' if rtl else 'No')
    return s + '</ComicInfo>\n'

def parse(x): return ET.fromstring(x.encode('utf-8'))

# ---- XML ----
x = build('Chương 3: Đối đầu', 'Truyện Của Tôi', 3, 12, None, True)
r = parse(x)
check('XML hợp lệ, phần tử gốc là ComicInfo KHÔNG namespace', r.tag == 'ComicInfo' and '{' not in r.tag)
check('có khai báo XML UTF-8 ở dòng đầu', x.startswith('<?xml version="1.0" encoding="utf-8"?>'))
check('Title/Series/Number/PageCount đúng, tiếng Việt giữ nguyên', r.findtext('Title') == 'Chương 3: Đối đầu' and r.findtext('Series') == 'Truyện Của Tôi' and r.findtext('Number') == '3' and r.findtext('PageCount') == '12')
check('phải → trái: Manga = YesAndRightToLeft (đúng hoa/thường)', r.findtext('Manga') == 'YesAndRightToLeft')
check('trái → phải: Manga = No', parse(build('t', 's', 1, 1, None, False)).findtext('Manga') == 'No')
check('Manga chỉ nhận đúng 2 giá trị hợp lệ trong enum {Unknown,No,Yes,YesAndRightToLeft}', {parse(build('t', 's', 1, 1, None, v)).findtext('Manga') for v in (True, False)} <= {'Unknown', 'No', 'Yes', 'YesAndRightToLeft'})
bad = 'A & B <tag> "q" \'s\''
rb = parse(build(bad, bad, 1, 1, None, False))
check('ký tự đặc biệt & < > " \' được escape và đọc lại đúng nguyên văn', rb.findtext('Title') == bad and rb.findtext('Series') == bad)
rc = parse(build('a\x00b\x0bc\x1fd\ufffee', 's', 1, 1, None, False))
check('ký tự điều khiển cấm trong XML 1.0 (\\x00, \\x0b, \\x1f) bị loại -> XML vẫn hợp lệ', rc.findtext('Title') == 'abcde')   # \x00, \x0b, \x1f và U+FFFE đều bị loại
check('emoji ngoài BMP được giữ', parse(build('Hi 😀', 's', 1, 1, None, False)).findtext('Title') == 'Hi 😀')
check('title/series rỗng hoặc toàn khoảng trắng -> bỏ trường (không có thẻ rỗng)', parse(build('  ', '', 1, 1, None, False)).find('Title') is None and parse(build('  ', '', 1, 1, None, False)).find('Series') is None)
check('Number null hoặc âm -> bỏ trường; 0 -> giữ', parse(build('t', 's', None, 1, None, False)).find('Number') is None and parse(build('t', 's', -1, 1, None, False)).find('Number') is None and parse(build('t', 's', 0, 1, None, False)).findtext('Number') == '0')
check('PageCount âm -> 0; LanguageISO có thì ghi, trống thì bỏ', parse(build('t', 's', 1, -5, None, False)).findtext('PageCount') == '0' and parse(build('t', 's', 1, 1, 'vi', False)).findtext('LanguageISO') == 'vi' and parse(build('t', 's', 1, 1, '  ', False)).find('LanguageISO') is None)
check('mọi tổ hợp tham số đều cho XML phân tích được (fuzz 500)', all(ET.fromstring(build(''.join(chr(__import__('random').Random(i * 7 + k).randint(1, 0x2FFF)) for k in range(12)), 'S%d' % i, i % 5 - 1, i, 'vi' if i % 2 else None, i % 3 == 0).encode('utf-8')) is not None for i in range(500)))

# ---- đóng zip thật ----
tmp = tempfile.mkdtemp()
p = os.path.join(tmp, 't.cbz')
with zipfile.ZipFile(p, 'w') as z:
    z.writestr('ComicInfo.xml', build('T', 'S', 1, 2, None, True).encode('utf-8'))
    z.writestr('panel_001.jpg', b'x'); z.writestr('panel_002.jpg', b'y')
names = zipfile.ZipFile(p).namelist()
check('ComicInfo.xml nằm ở GỐC kho nén (không thư mục con), đúng hoa/thường, là mục đầu tiên', names[0] == 'ComicInfo.xml' and '/' not in names[0])
check('tên trang có đệm số 0 nên sắp xếp theo tên đúng thứ tự đọc', names[1:] == sorted(names[1:]))

# ---- đối chiếu nguồn Kotlin + nối dây ----
EE, MP, ST = rd('pipeline', 'ExportEngine.kt'), rd('pipeline', 'MangaPipeline.kt'), rd('ui', 'SettingsScreen.kt')
check('Kotlin: khai báo XML + gốc <ComicInfo> không namespace + enum đúng hoa/thường', '<?xml version=\\"1.0\\" encoding=\\"utf-8\\"?>' in KT and '<ComicInfo>\\n' in KT and 'if (rightToLeft) "YesAndRightToLeft" else "No"' in KT)
check('Kotlin: escape đủ 5 ký tự và lọc ký tự cấm', all(t in KT for t in ['"&amp;"', '"&lt;"', '"&gt;"', '"&quot;"', '"&apos;"']) and 'validXmlChar' in KT and "c in ' '..'\\uD7FF'" in KT and "c in '\\uE000'..'\\uFFFD'" in KT)
check('Kotlin: các trường bỏ khi rỗng/âm khớp bản chép', 'title.isNotBlank()' in KT and 'series.isNotBlank()' in KT and 'number != null && number >= 0' in KT and 'maxOf(pageCount, 0)' in KT and 'languageIso.isNullOrBlank()' in KT)
check('Kotlin: exportCbz ghi ComicInfo.xml TRƯỚC các trang, ở gốc, UTF-8, PageCount = số trang thật có ảnh',
      'zip.putNextEntry(ZipEntry("ComicInfo.xml"))' in EE and EE.index('ComicInfo.xml') < EE.index('panels.forEach { panel ->') and 'toByteArray(Charsets.UTF_8)' in EE and 'File(it).exists()' in EE
      and 'val pageCount = panels.count {' in EE and 'ComicInfoXml.build(title, series, chapterNumber, pageCount, null, rtl)' in EE)
check('Kotlin: tham số mới đều có mặc định (không phá lời gọi cũ) và thứ tự trang/tên trang giữ nguyên', 'rtl: Boolean = false, series: String = "", chapterNumber: Int? = null, title: String = ""' in EE and '"panel_%03d.jpg".format(panel.index + 1)' in EE)
check('nối dây: exportChapter truyền rtl/series/số chương/tên chương', 'rtl = extras.rightToLeft, series = storyTitle, chapterNumber = chapter.chapterNumber, title = chapter.title' in MP)
check('nối dây: nhãn công tắc cập nhật PDF + CBZ', 'Manga đọc phải → trái (PDF + CBZ)' in ST and 'ghi cờ phải → trái vào ComicInfo.xml' in ST)

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
