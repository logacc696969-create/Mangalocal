#!/usr/bin/env python3
"""mục 286 — JSON CŨ thiếu trường: các lớp mô hình có tham số bắt buộc ⇒ không có hàm tạo không đối số ⇒ Gson trần dựng bằng Unsafe và để trường vắng = null/0/false (KHÔNG lấy mặc định).
Phép đo (tools/kotlin_tests/GsonOldJsonProbe.kt, Gson THẬT, mã Models.kt THẬT): với 12 lớp được StoryManager lưu ra đĩa, dựng JSON rồi XOÁ TỪNG TRƯỜNG, nạp lại, so với BẢN TRỐNG (mặc định Kotlin +
giá trị trống không-null cho tham số bắt buộc; viết độc lập với ModelJson trong chính tệp probe). Gson trần làm hỏng 69/89 trường; ModelJson.gson() phải làm hỏng 0.
Kiểm thêm: StoryManager dùng ModelJson.gson(); mọi lớp trong probe được ModelJson đăng ký; phá mã (--mut): bỏ/đổi từng creator thì probe phải đỏ.
Cần kotlinc 1.9.x (KOTLINC), Gson (GSON_JAR), android.jar (ANDROID_JAR); thiếu → chỉ chạy phần kiểm tĩnh và nói rõ.  Dùng: python3 tools/test_gson_old_json.py [--mut]"""
import os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); K = os.path.join(ROOT, 'app/src/main/java/com/mangalocal'); TD = os.path.join(ROOT, 'tools/kotlin_tests')
MJ = os.path.join(K, 'model/ModelJson.kt'); TBL = os.path.join(K, 'model/AgeBodyTable.kt'); MOD = os.path.join(K, 'model/Models.kt')
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)
mj = open(MJ, encoding='utf-8').read(); sm = open(os.path.join(K, 'pipeline/StoryManager.kt'), encoding='utf-8').read(); probe_src = open(os.path.join(TD, 'GsonOldJsonProbe.kt'), encoding='utf-8').read()
check('private val gson: Gson = ModelJson.gson()' in sm, 'nối dây: StoryManager.gson = ModelJson.gson() (story.json, chapter.json, characters.json, addon_loras.json)')
classes = re.findall(r'^\s*Triple\("(\w+)"', probe_src, re.M)
reg = {c: (f'{c}.blankForGson()' in mj if c == 'Character' else (f'blank {{ {c}(' in mj or (c == 'Scene' and '.blank { blankScene() }' in mj))) for c in classes}
check(len(classes) == 13 and all(reg.values()), f'mọi lớp được đo ({len(classes)}) đều có InstanceCreator trong ModelJson' + ('' if all(reg.values()) else f': thiếu {[c for c, v in reg.items() if not v]}'))
# mọi data class có `val ... : List/String...` được StoryManager lưu: Story → characters/locations; Chapter → panels; Panel → bubbles/scene — bảo đảm lớp lồng nhau nằm trong danh sách
check(all(c in classes for c in ('Story', 'Chapter', 'Panel', 'Scene', 'Bubble', 'DialogueLine', 'ObjectBox', 'Location', 'CharacterAnchorVersion', 'AddonLora', 'PageSpec', 'Character', 'ConditioningPreset')), 'danh sách đo gồm mọi lớp lưu ra đĩa và lớp lồng bên trong (… + ConditioningPreset, tìm ra nhờ duyệt reflection)')

def find(env, extra):
    for c in [os.environ.get(env)] + extra:
        if c and os.path.exists(c): return c
kc = find('KOTLINC', [shutil.which('kotlinc') or '', '/home/claude/tools/kotlinc/bin/kotlinc']); gs = find('GSON_JAR', ['/home/claude/tools/gson-2.10.1.jar'])
aj = find('ANDROID_JAR', ['/home/claude/tools/android34.jar', os.path.join(ROOT, 'tools/.cache/android34.jar')])
if not (kc and gs and aj):
    print('BỎ QUA phần chạy Kotlin: cần kotlinc 1.9.x, Gson, android.jar'); print('ĐẠT' if not fails else 'THẤT BẠI'); sys.exit(1 if fails else 0)
CP = os.pathsep.join([gs, aj])
def build_run(mj_path, mode, td):
    jar = os.path.join(td, 'p.jar')
    if not os.path.exists(jar):
        r = subprocess.run([kc, '-nowarn', '-cp', CP, os.path.join(TD, 'StubStoryManager.kt'), os.path.join(TD, 'GsonOldJsonProbe.kt'), TBL, MOD, mj_path, '-include-runtime', '-d', jar], capture_output=True, text=True)
        if r.returncode != 0: return None, r.stderr[-1200:]
    o = subprocess.run(['java', '-Dstdout.encoding=UTF-8', '-cp', jar + os.pathsep + CP, 'GsonOldJsonProbeKt', mode], capture_output=True, text=True)
    return o, ''
def total(o):
    m = re.search(r'TỔNG: (\d+) / (\d+) trường', o.stdout); return (int(m.group(1)), int(m.group(2))) if m else (None, None)
with tempfile.TemporaryDirectory() as td:
    o, e = build_run(MJ, 'fixed', td); check(o is not None, 'biên dịch Models + ModelJson + probe bằng kotlinc' + ('' if o is not None else '\n' + e))
    if o is not None:
        mm = re.search(r'CHƯA ĐĂNG KÝ[^:]*: (\d+)', o.stdout); check(mm is not None and int(mm.group(1)) == 0, 'ĐỦ LỚP: duyệt đồ thị kiểu từ Character/Story/Chapter/AddonLora — KHÔNG còn lớp mô hình lồng bên trong nào thiếu hàm tạo không đối số mà chưa đăng ký' + ('' if mm and int(mm.group(1)) == 0 else ' :: ' + (re.search(r'CHƯA ĐĂNG KÝ.*', o.stdout).group(0) if re.search(r'CHƯA ĐĂNG KÝ.*', o.stdout) else '?')))
        bad, n = total(o); check(bad == 0 and n >= 80 and o.returncode == 0, f'ModelJson.gson(): {bad}/{n} trường không khôi phục đúng mặc định khi vắng trong JSON (13 lớp)')
        for l in o.stdout.splitlines():
            if 'KHÔNG khôi phục đúng mặc định' in l and not re.search(r': +0 ', l): print('   ', l[:200])
        # đối chứng: Gson trần trong CÙNG chương trình phải bị phép đo phát hiện (nếu không, phép đo vô nghĩa). Probe chạy nhánh "plain" bằng Gson() khi tham số != fixed.
        op, _ = build_run(MJ, 'plain', td); bad_p, n_p = total(op)
        check(bad_p is not None and bad_p >= 50, f'ĐỐI CHỨNG: Gson TRẦN làm hỏng {bad_p}/{n_p} trường (null ở kiểu không-null, 0/false thay mặc định) — phép đo phát hiện được hiểm hoạ')
MUTS = [
 ('bỏ creator của Panel', '.blank { Panel(index = 0, scene = blankScene(), prompt = "", negativePrompt = "") }\n', ''),
 ('bỏ creator của Story', '.blank { Story(id = "", title = "") }\n', ''),
 ('bỏ creator của Bubble', '.blank { Bubble(id = "", characterName = "", text = "") }\n', ''),
 ('bỏ creator của AddonLora', '.blank { AddonLora(id = "", displayName = "", fileName = "") }\n', ''),
 ('bỏ creator của Character', '.blank { Character.blankForGson() }\n', ''),
 ('bỏ creator của ConditioningPreset (phải bị bắt bởi kiểm "đủ lớp")', '.blank { ConditioningPreset(0f, 0f, 0f, 0f, 0f, 0f) }   // 6 tham số Float bắt buộc, không có mặc định theo thiết kế\n', ''),
 ('Chapter: style trống khác REALISTIC', 'style = ImageStyle.REALISTIC, panels = emptyList()) }', 'style = ImageStyle.MANGA, panels = emptyList()) }'),
 ('Scene trống có mô tả rác', 'private fun blankScene() = Scene(index = 0, description = "", ', 'private fun blankScene() = Scene(index = 0, description = "?", '),
]
if '--mut' in sys.argv:
    caught = 0
    for name, old, new in MUTS:
        assert mj.count(old) == 1, f'mẫu không duy nhất: {name} ({mj.count(old)})'
        with tempfile.TemporaryDirectory() as td:
            mp = os.path.join(td, 'ModelJson.kt'); open(mp, 'w', encoding='utf-8').write(mj.replace(old, new, 1))
            o, e = build_run(mp, 'fixed', td); bad = o is None or o.returncode != 0 or (total(o)[0] or 0) > 0
        caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name, flush=True)
    check(caught == len(MUTS), f'phá mã ModelJson: {caught}/{len(MUTS)} đột biến bị bắt')
else: print(f'(bỏ qua đột biến — chạy với --mut; có {len(MUTS)})')
print('\nĐẠT' if not fails else '\nTHẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
