"""
ip_adapter_decay.py — Bản THẬT của Smooth Timestep Decay cho IP-Adapter.

THAY THẾ cách làm XẤP XỈ trước đây (scale ip_image_embeds ở đầu vào
to_k_ip/to_v_ip, đổi cả temperature của softmax attention — xem mục 97
TECHNICAL_STATUS.md, phần "LẦN LÀM ĐẦU"). Bản này scale ĐÚNG chỗ
`pipe.set_ip_adapter_scale()` scale — tức là scale OUTPUT của attention,
sau khi đã tính attention xong — bằng cách COPY NGUYÊN VĂN logic thật của
`diffusers.models.attention_processor.IPAdapterAttnProcessor2_0.__call__`
(đã trích xuất trực tiếp từ package `diffusers==0.39.0` cài qua pip, KHÔNG
đoán/nhớ lại từ training data — xem lệnh trích xuất trong lịch sử làm
việc), rồi chỉ đổi ĐÚNG 2 dòng nhân `scale` cuối cùng thành nhân thêm
`decay_state.value` (tensor runtime, không phải hằng số Python).

CÁCH HOẠT ĐỘNG (vì sao trace ONNX vẫn bắt đúng dù không sửa forward() của
UNet2DConditionModel):
  1. `pipe.load_ip_adapter(...)` gắn 1 `IPAdapterAttnProcessor2_0` GỐC vào
     mỗi lớp cross-attention của UNet (nhiều lớp, không chỉ 1).
  2. `wrap_unet_ip_adapter_processors()` DUYỆT các processor gốc đó, bọc
     mỗi cái trong `DecayedIPAdapterAttnProcessor2_0` — TÁI SỬ DỤNG NGUYÊN
     `to_k_ip`/`to_v_ip`/`scale`/`num_tokens` đã train sẵn (không tạo mới,
     không copy giá trị — giữ tham chiếu thật), rồi gọi
     `unet.set_attn_processor(...)` (API CHÍNH THỨC của diffusers) để thay
     thế toàn bộ processor gốc bằng bản bọc.
  3. `IpDecayState` là 1 hộp chứa đơn giản, KHÔNG phải nn.Module con của
     UNet — chỉ giữ 1 thuộc tính `.value` (tensor). Ngay TRƯỚC khi gọi
     `self.unet(...)` trong `AugmentedUNet.forward()`, ta gán
     `decay_state.value = effective_ip_scale` (tensor tính từ timestep —
     xem công thức trong AugmentedUNet.forward()).
  4. Khi `self.unet(...)` chạy, MỖI processor bọc đọc `decay_state.value`
     (cùng 1 object, mọi processor trỏ chung) và nhân vào output attention
     — vì đây là 1 phép nhân tensor·tensor XẢY RA THẬT trong lượt forward()
     đang được trace, và `decay_state.value` có lineage bắt nguồn từ
     `timestep`/`ip_decay_floor`/`ip_decay_start_timestep` (đều là input
     của đồ thị) — trình trace (dùng trong `torch.onnx.export`) bắt đúng
     phép nhân này thành 1 node `Mul` phụ thuộc vào timestep, KHÔNG bị đóng
     băng thành hằng số. Đây là kỹ thuật chuẩn ("shared mutable container
     đọc trong forward, gán ngay trước lượt gọi") để tuồn 1 giá trị runtime
     vào 1 module con mà API public không có tham số cho việc đó — không
     phải hack không kiểm chứng được.

GIỚI HẠN THẬT (vẫn còn, đọc trước khi tin 100%):
  - Đã xác nhận đúng với diffusers 0.39.0 (bản pip cài lúc viết file này).
    tools/export_ipa_controlnet_unet.py KHÔNG ghim version diffusers cụ
    thể (`pip install diffusers` trần) — nếu lúc CI thật chạy, pip cài
    bản diffusers MỚI HƠN đã đổi cấu trúc `IPAdapterAttnProcessor2_0`
    (tên hàm, thứ tự tham số, logic mask...), `wrap_unet_ip_adapter_processors()`
    bên dưới sẽ lỗi RÕ RÀNG (AttributeError/TypeError khi gọi) chứ KHÔNG
    âm thầm sai — vì code copy gần như y hệt cấu trúc thật, không phải
    interface trừu tượng ổn định qua version. Nếu gặp lỗi này lúc build
    thật: mở lại package diffusers đã cài trong CI, tra `IPAdapterAttnProcessor2_0`
    thật, đối chiếu lại — KHÔNG đoán, làm đúng quy trình đã dùng để viết
    file này (pip install diffusers rồi đọc source thật).
  - CHƯA build-test, CHƯA chạy thử export thật (thiếu GPU/model thật trong
    sandbox) — chỉ xác nhận được: source copy khớp đúng bản cài, cấu trúc
    class hợp lệ về mặt cú pháp Python (đã chạy py_compile).
  - Chỉ xử lý cross-attention của UNet2DConditionModel qua
    `set_attn_processor()` — KHÔNG đổi gì trong ControlNetModel (ControlNet
    không dùng IP-Adapter attention processor, không liên quan).
  - Nhánh `ip_adapter_masks` (IP-Adapter mask nhiều nhân vật, mục 52b) CŨNG
    đã được nhân decay vào — mục 147 TECHNICAL_STATUS.md đã nối
    `export_ipa_controlnet_mask_unet.py` dùng ĐÚNG module này với decay
    RIÊNG TỪNG NHÂN VẬT (`.value` shape [N], xem docstring `IpDecayState`
    bên dưới) — không còn 1 scalar dùng chung cho mọi người nữa.
"""
import torch
import torch.nn.functional as F
from diffusers.models.attention_processor import IPAdapterAttnProcessor2_0


class IpDecayState:
    """Hộp chứa 1 tensor scale runtime, dùng chung giữa mọi attention
    processor đã bọc trong 1 UNet. KHÔNG đăng ký làm nn.Module/buffer —
    cố tình là 1 object Python trần để việc gán `.value` không đụng vào
    state_dict/device-placement machinery của PyTorch (chỉ cần đúng device/
    dtype tại thời điểm gán, xem AugmentedUNet.forward()).

    mục 147 TECHNICAL_STATUS.md — `.value` có 2 SHAPE khác nhau tuỳ pipeline
    gọi (không phải lỗi, cố ý — mỗi pipeline chỉ dùng ĐÚNG 1 nhánh của
    `DecayedIPAdapterAttnProcessor2_0.__call__` bên dưới):
      - Pipeline 1-nhân-vật (`export_ipa_controlnet_unet.py`/
        `export_ipa_controlnet_depth_unet.py`) — nhánh KHÔNG mask —
        `.value` là SCALAR (0-d tensor), dùng thẳng không index.
      - Pipeline N-nhân-vật (`export_ipa_controlnet_mask_unet.py`) — nhánh
        CÓ mask — `.value` là VECTOR 1-D shape [N], index `.value[i]` theo
        đúng nhân vật thứ i trong vòng lặp mask (Per-Instance Decay — đóng
        gap xác nhận ở mục 146: trước đây dùng chung 1 scalar cho mọi
        nhân vật dù có N mask riêng).
    """
    def __init__(self):
        self.value = torch.tensor(1.0)


class DecayedIPAdapterAttnProcessor2_0(torch.nn.Module):
    """Copy gần như nguyên văn `IPAdapterAttnProcessor2_0.__call__` của
    diffusers 0.39.0 (đã trích xuất source thật, xem docstring module).
    CHỈ khác 2 chỗ nhân `scale` cuối cùng (2 nhánh: có mask / không mask) —
    nhân thêm `self._decay_state.value` vào, giữ nguyên MỌI logic khác
    (multi-token, multi-adapter list, mask downsample...) y hệt bản gốc.

    KHÔNG tạo to_k_ip/to_v_ip MỚI — nhận thẳng processor GỐC đã có trọng số
    train sẵn (từ pipe.load_ip_adapter()) và TÁI SỬ DỤNG các nn.ModuleList
    đó (gán trực tiếp, không copy .state_dict()) để không mất trọng số.
    """

    def __init__(self, base_processor: IPAdapterAttnProcessor2_0, decay_state: IpDecayState):
        super().__init__()
        if not hasattr(F, "scaled_dot_product_attention"):
            raise ImportError(
                f"{self.__class__.__name__} requires PyTorch 2.0, to use it, please upgrade PyTorch to 2.0."
            )
        self.hidden_size = base_processor.hidden_size
        self.cross_attention_dim = base_processor.cross_attention_dim
        self.num_tokens = base_processor.num_tokens
        self.scale = base_processor.scale
        # Tái sử dụng NGUYÊN các lớp Linear đã train — không tạo mới.
        self.to_k_ip = base_processor.to_k_ip
        self.to_v_ip = base_processor.to_v_ip
        self._decay_state = decay_state

    def __call__(
        self,
        attn,
        hidden_states,
        encoder_hidden_states=None,
        attention_mask=None,
        temb=None,
        scale: float = 1.0,
        ip_adapter_masks=None,
    ):
        residual = hidden_states

        if encoder_hidden_states is not None:
            if isinstance(encoder_hidden_states, tuple):
                encoder_hidden_states, ip_hidden_states = encoder_hidden_states
            else:
                end_pos = encoder_hidden_states.shape[1] - self.num_tokens[0]
                encoder_hidden_states, ip_hidden_states = (
                    encoder_hidden_states[:, :end_pos, :],
                    [encoder_hidden_states[:, end_pos:, :]],
                )

        if attn.spatial_norm is not None:
            hidden_states = attn.spatial_norm(hidden_states, temb)

        input_ndim = hidden_states.ndim

        if input_ndim == 4:
            batch_size, channel, height, width = hidden_states.shape
            hidden_states = hidden_states.view(batch_size, channel, height * width).transpose(1, 2)

        batch_size, sequence_length, _ = (
            hidden_states.shape if encoder_hidden_states is None else encoder_hidden_states.shape
        )

        if attention_mask is not None:
            attention_mask = attn.prepare_attention_mask(attention_mask, sequence_length, batch_size)
            attention_mask = attention_mask.view(batch_size, attn.heads, -1, attention_mask.shape[-1])

        if attn.group_norm is not None:
            hidden_states = attn.group_norm(hidden_states.transpose(1, 2)).transpose(1, 2)

        query = attn.to_q(hidden_states)

        if encoder_hidden_states is None:
            encoder_hidden_states = hidden_states
        elif attn.norm_cross:
            encoder_hidden_states = attn.norm_encoder_hidden_states(encoder_hidden_states)

        key = attn.to_k(encoder_hidden_states)
        value = attn.to_v(encoder_hidden_states)

        inner_dim = key.shape[-1]
        head_dim = inner_dim // attn.heads

        query = query.view(batch_size, -1, attn.heads, head_dim).transpose(1, 2)
        key = key.view(batch_size, -1, attn.heads, head_dim).transpose(1, 2)
        value = value.view(batch_size, -1, attn.heads, head_dim).transpose(1, 2)

        hidden_states = F.scaled_dot_product_attention(
            query, key, value, attn_mask=attention_mask, dropout_p=0.0, is_causal=False
        )
        hidden_states = hidden_states.transpose(1, 2).reshape(batch_size, -1, attn.heads * head_dim)
        hidden_states = hidden_states.to(query.dtype)

        if ip_adapter_masks is not None:
            if not isinstance(ip_adapter_masks, list):
                ip_adapter_masks = list(ip_adapter_masks.unsqueeze(1))
            if not (len(ip_adapter_masks) == len(self.scale) == len(ip_hidden_states)):
                raise ValueError(
                    f"Length of ip_adapter_masks array ({len(ip_adapter_masks)}) must match "
                    f"length of self.scale array ({len(self.scale)}) and number of ip_hidden_states "
                    f"({len(ip_hidden_states)})"
                )
        else:
            ip_adapter_masks = [None] * len(self.scale)

        # Import cục bộ để tránh phụ thuộc cứng nếu module này được dùng
        # ngoài ngữ cảnh có sẵn diffusers đầy đủ (giống cách file gốc làm).
        from diffusers.models.attention_processor import IPAdapterMaskProcessor

        for current_ip_hidden_states, static_scale, to_k_ip, to_v_ip, mask in zip(
            ip_hidden_states, self.scale, self.to_k_ip, self.to_v_ip, ip_adapter_masks
        ):
            skip = False
            if isinstance(static_scale, list):
                if all(s == 0 for s in static_scale):
                    skip = True
            elif static_scale == 0:
                skip = True
            if not skip:
                if mask is not None:
                    if not isinstance(static_scale, list):
                        static_scale = [static_scale] * mask.shape[1]

                    current_num_images = mask.shape[1]
                    for i in range(current_num_images):
                        ip_key = to_k_ip(current_ip_hidden_states[:, i, :, :])
                        ip_value = to_v_ip(current_ip_hidden_states[:, i, :, :])

                        ip_key = ip_key.view(batch_size, -1, attn.heads, head_dim).transpose(1, 2)
                        ip_value = ip_value.view(batch_size, -1, attn.heads, head_dim).transpose(1, 2)

                        _current_ip_hidden_states = F.scaled_dot_product_attention(
                            query, ip_key, ip_value, attn_mask=None, dropout_p=0.0, is_causal=False
                        )
                        _current_ip_hidden_states = _current_ip_hidden_states.transpose(1, 2).reshape(
                            batch_size, -1, attn.heads * head_dim
                        )
                        _current_ip_hidden_states = _current_ip_hidden_states.to(query.dtype)

                        mask_downsample = IPAdapterMaskProcessor.downsample(
                            mask[:, i, :, :], batch_size,
                            _current_ip_hidden_states.shape[1], _current_ip_hidden_states.shape[2],
                        )
                        mask_downsample = mask_downsample.to(dtype=query.dtype, device=query.device)
                        # mục 147 TECHNICAL_STATUS.md — ĐÃ SỬA (trước đây
                        # `self._decay_state.value` là SCALAR DÙNG CHUNG cho
                        # mọi nhân vật — đóng gap "Per-Instance Decay" xác
                        # nhận thật ở mục 146). Giờ `.value` là tensor 1-D
                        # SHAPE [N] (N = số nhân vật, khớp `current_num_images`
                        # — xem AugmentedUNetMask.forward() trong
                        # export_ipa_controlnet_mask_unet.py) — lấy ĐÚNG
                        # phần tử [i] của nhân vật đang xử lý trong vòng lặp
                        # này, KHÔNG còn dùng chung 1 giá trị cho cả N người.
                        hidden_states = hidden_states + static_scale[i] * self._decay_state.value[i] * (
                            _current_ip_hidden_states * mask_downsample
                        )
                else:
                    ip_key = to_k_ip(current_ip_hidden_states)
                    ip_value = to_v_ip(current_ip_hidden_states)

                    ip_key = ip_key.view(batch_size, -1, attn.heads, head_dim).transpose(1, 2)
                    ip_value = ip_value.view(batch_size, -1, attn.heads, head_dim).transpose(1, 2)

                    current_ip_hidden_states = F.scaled_dot_product_attention(
                        query, ip_key, ip_value, attn_mask=None, dropout_p=0.0, is_causal=False
                    )
                    current_ip_hidden_states = current_ip_hidden_states.transpose(1, 2).reshape(
                        batch_size, -1, attn.heads * head_dim
                    )
                    current_ip_hidden_states = current_ip_hidden_states.to(query.dtype)

                    # <<< CHỖ DUY NHẤT ĐỔI (nhánh không mask, dùng cho
                    # đường 1-nhân-vật): nhân thêm decay_state.value — ĐÂY
                    # LÀ SCALE OUTPUT THẬT, đúng ý nghĩa set_ip_adapter_scale(),
                    # không phải xấp xỉ scale-input như bản trước.
                    hidden_states = hidden_states + static_scale * self._decay_state.value * current_ip_hidden_states

        hidden_states = attn.to_out[0](hidden_states)
        hidden_states = attn.to_out[1](hidden_states)

        if input_ndim == 4:
            hidden_states = hidden_states.transpose(-1, -2).reshape(batch_size, channel, height, width)

        if attn.residual_connection:
            hidden_states = hidden_states + residual

        hidden_states = hidden_states / attn.rescale_output_factor

        return hidden_states


def wrap_unet_ip_adapter_processors(unet, decay_state: IpDecayState) -> int:
    """Duyệt attn_processors thật của unet, bọc mọi IPAdapterAttnProcessor2_0
    tìm thấy bằng DecayedIPAdapterAttnProcessor2_0, rồi set lại qua API
    chính thức `unet.set_attn_processor()`. Trả về SỐ LƯỢNG processor đã
    bọc — gọi code PHẢI kiểm tra số này > 0 (nếu = 0, nghĩa là
    pipe.load_ip_adapter() chưa được gọi trước, hoặc cấu trúc diffusers đã
    đổi tên class — xem GIỚI HẠN THẬT ở đầu file, KHÔNG được im lặng bỏ qua).
    """
    new_processors = {}
    wrapped_count = 0
    for name, proc in unet.attn_processors.items():
        if isinstance(proc, IPAdapterAttnProcessor2_0):
            new_processors[name] = DecayedIPAdapterAttnProcessor2_0(proc, decay_state)
            wrapped_count += 1
        else:
            new_processors[name] = proc
    unet.set_attn_processor(new_processors)
    return wrapped_count
