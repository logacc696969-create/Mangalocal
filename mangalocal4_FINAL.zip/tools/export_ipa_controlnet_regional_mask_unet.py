"""
export_ipa_controlnet_regional_mask_unet.py — Regional Prompting với MASK
HÌNH DẠNG TUỲ Ý (không ép chia cột dọc đều) + ControlNet-Pose.

mục 172 TECHNICAL_STATUS.md — "Hướng A" user chọn tiếp sau khi tra cứu
cộng đồng (mục 171): kỹ thuật cộng đồng gọi là "Attention Couple"
(ComfyUI)/"Regional Prompter — Mask mode" (A1111, tác giả hako-mikan) —
KHÁC bản `export_ipa_controlnet_regional_unet.py` (mục 56/69) ở ĐÚNG 1
điểm cốt lõi: bản CŨ chia N CỘT DỌC ĐỀU NHAU, toạ độ cột là HẰNG SỐ nướng
sẵn lúc export (tính từ `num_regions` + `side` ngay trong Python trước
khi trace) — không có cách nào truyền mask khác lúc chạy thật mà không
export lại model khác. Bản NÀY nhận MASK làm INPUT ONNX THẬT (tensor,
không phải hằng số) — cho phép dùng mask theo đúng HÌNH DẠNG CƠ THỂ từng
người (từ `renderCharacterMask()` đã có sẵn ở `ip_adapter.cpp`, mục 51),
kể cả mask CHỒNG LẤN (2 người ôm/vật nhau, bbox giao nhau) — đúng vấn đề
"quần nhau, vật lộn" mà bản CỘT không xử lý được (chia cột cứng không hề
biết tới hình dạng người thật).

=== NGUỒN THẬT ĐÃ TRA (mục 171) — KHÔNG ĐOÁN ===
"Attention Couple" (ComfyUI, node af-fusion/laksjdjf) và "Regional
Prompter — Mask mode" (A1111 extension, hako-mikan) đều làm ĐÚNG 1 việc:
thay vì cắt theo lưới hình học cố định, dùng mask (vẽ tay hoặc suy từ
segmentation/pose) áp trực tiếp vào kết quả attention CỦA TỪNG VÙNG, cho
phép vùng chồng lấn/hình dạng bất kỳ. Tài liệu cộng đồng cũng ghi nhận rõ:
"nơi mask chồng lấn, vùng có trọng số MẠNH HƠN THẮNG HẲN" (không trộn
danh tính 2 vùng vào nhau) — bản NÀY áp dụng ĐÚNG nguyên tắc đó (argmax
cứng theo pixel, xem `run_attn_and_composite()` bên dưới), KHÔNG blend
mềm (blend mềm gây "ma" 2 mặt chồng lên nhau — đúng lỗi cộng đồng đã ghi
nhận là hạn chế thật của kỹ thuật này, KHÔNG PHẢI hạn chế riêng do bản
này viết ẩu).

=== KHÁC BIỆT KỸ THUẬT SO VỚI BẢN CỘT (đọc kỹ trước khi export) ===
1. THÊM input `region_masks` [num_regions, image_size, image_size] float32
   (0..1) — mask THẬT theo pixel, không phải hằng số cột. Downsample về
   đúng `side x side` của TỪNG layer attn2 bằng `F.interpolate(mode="nearest")`
   — traceable, cùng cách UNet vốn đã suy `side` từ `seq_len` (bản cột
   cũng làm y hệt, không phải kỹ thuật mới).
2. THÊM 1 "vùng nền" (background) — pixel KHÔNG thuộc mask nào (giá trị
   mask cả N vùng đều < ngưỡng) dùng `background_encoder_hidden_states`
   (prompt scene chung, KHÔNG phải nhân vật nào) thay vì bị bỏ trống —
   bản CỘT không cần vì chia cột phủ kín 100% ảnh, bản MASK thì KHÔNG (2
   người đứng giữa khung, 2 bên là hậu cảnh trống — cần ai đó "nhận" phần
   đó).
3. GHÉP kết quả bằng SO SÁNH CỨNG (argmax theo pixel, dùng `(best_idx==i)`
   từng vùng — KHÔNG dùng `F.one_hot` để tránh rủi ro tương thích phiên
   bản opset), KHÔNG blend alpha mềm — đúng lý do đã nêu ở trên.
4. VẪN giữ nguyên: chỉ ảnh VUÔNG (suy side=sqrt(seq_len), giới hạn CŨ,
   không phải giới hạn MỚI do bản này gây ra), vẫn trace batch=2 nguyên
   vẹn (lý do y hệt bản cột — xem file đó), vẫn KHÔNG chia vùng cho
   negative prompt, vẫn CỐ ĐỊNH N lúc export (không dynamic_axes).
5. KHÔNG kết hợp IP-Adapter (giữ nguyên quyết định mục 56: 2 kỹ thuật
   regional-PROMPT vs regional-ẢNH song song, không gộp — SONG bản MASK
   này về nguyên tắc dễ gộp IP-Adapter hơn bản CỘT vì đã có sẵn cơ chế
   mask thật/pixel — CHƯA làm ở đợt này, để việc riêng nếu cần).

=== GIỚI HẠN THẬT — CHƯA build-test (giống mọi export script khác) ===
- CHƯA chạy thử export thật (cần GPU, không có trong sandbox viết code
  này) — chỉ xác nhận `py_compile` sạch + đối chiếu logic tensor shape
  bằng tay (ghi rõ shape kỳ vọng ở mỗi bước, xem comment inline).
- Downsample mask bằng "nearest" ở layer sâu nhất (vd 8x8 hoặc 16x16 tại
  512x512) sẽ RẤT THÔ — 1 người chiếm vùng nhỏ trong khung có thể mất
  hẳn ở layer đó (toàn bộ mask của họ downsample về 0 pixel). Đây là
  giới hạn KIẾN TRÚC thật của kỹ thuật (không riêng bản này — bản CỘT
  cũng gặp y hệt ở layer sâu, cột hẹp có thể mất ở 8x8), KHÔNG có cách
  vá triệt để ngoài việc chấp nhận layer sâu nhất mất độ chính xác vùng
  (layer sâu vốn mang thông tin bố cục thô, layer nông mới quyết định
  chi tiết — ảnh hưởng thật nhưng không phải lỗi nghiêm trọng theo kinh
  nghiệm cộng đồng dùng kỹ thuật tương đương).
- Ngưỡng "có chủ" (threshold 0.5 cho pixel thuộc vùng nào) là số CHỌN
  HỢP LÝ, CHƯA tinh chỉnh bằng thực nghiệm ảnh thật.
- `renderCharacterMask()` phía C++ (nơi dự kiến dùng làm nguồn mask thật)
  vẫn là bounding-box (chưa SAM hoá như mục 168 đã làm cho Cascade) —
  việc áp SAM cho ĐÚNG hàm này là việc RIÊNG, chưa làm ở đợt này (đã ghi
  ở mục 170 mục "việc còn lại").

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_regional_mask_unet.py \\
        --base_model runwayml/stable-diffusion-v1-5 \\
        --num_regions 3 --output_dir ./exported_regional_mask --image_size 512
"""
import argparse
import math
import os

import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers import ControlNetModel, StableDiffusionControlNetPipeline


def hook_regional_mask_attn2(unet: nn.Module, num_regions: int):
    """Y HỆT cấu trúc `hook_regional_attn2()` của bản cột (đọc file đó
    trước nếu chưa quen) — CHỈ khác đúng phần ghép kết quả cuối (composite
    theo mask thật thay vì slice cột cứng). state["masks"] nhận tensor
    [num_regions, image_size, image_size] THẬT (gán mỗi lần forward qua
    set_regional_state(), không phải hằng số)."""
    state = {"uncond": None, "background": None, "regions": None, "masks": None, "image_size": None}

    def make_forward(attn: nn.Module):
        def forward(hidden_states, encoder_hidden_states=None, attention_mask=None, temb=None, **kw):
            residual = hidden_states
            if attn.spatial_norm is not None:
                hidden_states = attn.spatial_norm(hidden_states, temb)
            input_ndim = hidden_states.ndim
            if input_ndim == 4:
                b, c, h4, w4 = hidden_states.shape
                hidden_states = hidden_states.view(b, c, h4 * w4).transpose(1, 2)

            seq_len = hidden_states.shape[1]
            side = int(round(math.sqrt(seq_len)))  # ảnh vuông -> h=w=sqrt(seq_len) (giới hạn CŨ, không đổi)

            uncond_hs = hidden_states[0:1]
            cond_hs = hidden_states[1:2]

            def run_attn(hs, enc_hs):
                q = attn.to_q(hs)
                k = attn.to_k(enc_hs)
                v = attn.to_v(enc_hs)
                inner_dim = k.shape[-1]
                head_dim = inner_dim // attn.heads
                q = q.view(hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                k = k.view(enc_hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                v = v.view(enc_hs.shape[0], -1, attn.heads, head_dim).transpose(1, 2)
                out = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0, is_causal=False)
                out = out.transpose(1, 2).reshape(hs.shape[0], -1, attn.heads * head_dim).to(q.dtype)
                out = attn.to_out[0](out)
                out = attn.to_out[1](out)
                return out  # [1, seq_len, dim]

            uncond_out = run_attn(uncond_hs, state["uncond"])

            # Vế cond: background (1 lần) + N vùng nhân vật (N lần) — TOÀN
            # ẢNH mỗi lần, ĐÚNG nguyên tắc "attention đầy đủ rồi mới ghép"
            # (không cắt hidden_states trước khi vào attention) kế thừa từ
            # bản cột.
            background_out = run_attn(cond_hs, state["background"])
            region_outs = [run_attn(cond_hs, state["regions"][i:i + 1]) for i in range(num_regions)]

            # ---- Ghép theo MASK THẬT (khác bản cột từ đây) ----
            # state["masks"]: [num_regions, image_size, image_size] float32.
            # Downsample về đúng side x side của layer NÀY — "nearest" giữ
            # biên cứng (không làm mờ ranh giới vùng, tránh nội suy trộn
            # 2 vùng ở biên — xem GIỚI HẠN THẬT ở docstring đầu file).
            masks_ds = F.interpolate(
                state["masks"].unsqueeze(1),  # [num_regions, 1, H, W]
                size=(side, side), mode="nearest",
            ).squeeze(1)  # [num_regions, side, side]

            max_vals, best_idx = torch.max(masks_ds, dim=0)  # [side, side] mỗi cái
            has_owner = (max_vals > 0.5).view(1, side * side, 1).to(uncond_out.dtype)  # [1, seq_len, 1]
            best_idx_flat = best_idx.view(side * side)  # [seq_len], long

            # So sánh cứng (best_idx_flat == i) thay vì F.one_hot — tránh
            # phụ thuộc opset cho OneHot, cùng tinh thần "ít suy đoán nhất
            # có thể" của toàn dự án.
            cond_out = background_out * (1.0 - has_owner)
            for i, out in enumerate(region_outs):
                weight_i = (best_idx_flat == i).view(1, side * side, 1).to(out.dtype) * has_owner
                cond_out = cond_out + out * weight_i
            # ---- Hết phần khác biệt so với bản cột ----

            hidden_states = torch.cat([uncond_out, cond_out], dim=0)

            if input_ndim == 4:
                hidden_states = hidden_states.transpose(-1, -2).reshape(b, c, h4, w4)
            if attn.residual_connection:
                hidden_states = hidden_states + residual
            hidden_states = hidden_states / attn.rescale_output_factor
            return hidden_states
        return forward

    for name, module in unet.named_modules():
        if "attn2" in name and module.__class__.__name__ == "Attention":
            module.forward = make_forward(module)

    def set_regional_state(uncond_embeds, background_embeds, region_embeds, region_masks):
        state["uncond"] = uncond_embeds
        state["background"] = background_embeds
        state["regions"] = region_embeds
        state["masks"] = region_masks

    return set_regional_state


class AugmentedUNetRegionalMask(nn.Module):
    """Y HỆT `AugmentedUNetRegional` (bản cột) — CHỈ thêm 2 tham số forward
    mới: `background_embeds`, `region_masks` (tensor THẬT, không phải suy
    từ num_regions/side như bản cột)."""

    def __init__(self, unet, controlnet, num_regions):
        super().__init__()
        self.unet = unet
        self.controlnet = controlnet
        self.set_state = hook_regional_mask_attn2(unet, num_regions)

    def forward(self, sample, timestep, uncond_embeds, background_embeds, region_embeds, region_masks, control_hint):
        cn_encoder_hidden = torch.cat([uncond_embeds, background_embeds], dim=0)
        down_res, mid_res = self.controlnet(
            sample, timestep, encoder_hidden_states=cn_encoder_hidden,
            controlnet_cond=control_hint, return_dict=False,
        )
        self.set_state(uncond_embeds, background_embeds, region_embeds, region_masks)
        placeholder_encoder_hidden = torch.cat([uncond_embeds, uncond_embeds], dim=0)
        noise_pred = self.unet(
            sample, timestep, encoder_hidden_states=placeholder_encoder_hidden,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            return_dict=False,
        )[0]
        return noise_pred


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="runwayml/stable-diffusion-v1-5")
    ap.add_argument("--controlnet_model", default="lllyasviel/control_v11p_sd15_openpose")
    ap.add_argument("--num_regions", type=int, default=2,
                     help="So nhan vat/vung MASK (>=2 — bang 1 thi dung ban augmented 1-nguoi binh thuong)")
    ap.add_argument("--output_dir", default="./exported_regional_mask")
    ap.add_argument("--image_size", type=int, default=512,
                     help="PHAI la anh VUONG (ke thua gioi han tu ban cot, xem GIOI HAN THAT)")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    if args.num_regions < 2:
        raise ValueError("num_regions phai >= 2 (bang 1 thi dung ban augmented 1-nguoi binh thuong)")

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_size = args.image_size // 8

    print("Đang tải ControlNet-OpenPose...")
    controlnet = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)

    print("Đang tải base SD1.5 + gắn ControlNet...")
    pipe = StableDiffusionControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet, torch_dtype=torch.float32, safety_checker=None
    ).to(device)

    print(f"Đang gắn hook Regional Prompting MASK ({args.num_regions} vùng + 1 nền)...")
    augmented = AugmentedUNetRegionalMask(pipe.unet, pipe.controlnet, args.num_regions).to(device).eval()

    with torch.no_grad():
        dummy_ids = pipe.tokenizer(["a photo"], padding="max_length",
                                    max_length=pipe.tokenizer.model_max_length,
                                    truncation=True, return_tensors="pt").input_ids.to(device)
        probe_embed = pipe.text_encoder(dummy_ids)[0]
    print(f"[probe] encoder_hidden_states 1 prompt shape THẬT: {tuple(probe_embed.shape)}")

    example_sample = torch.randn(2, 4, latent_size, latent_size, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_uncond = torch.randn_like(probe_embed)
    example_background = torch.randn_like(probe_embed)
    example_regions = torch.randn(args.num_regions, *probe_embed.shape[1:], device=device)
    # Mask THẬT dùng lúc trace: nửa trái=vùng 0, nửa phải=vùng 1 (nếu có),
    # còn lại rỗng — CHỈ để trace/dò shape, KHÔNG phải giá trị dùng lúc
    # infer thật (infer thật lấy mask từ renderCharacterMask() phía C++,
    # xem TECHNICAL_STATUS.md mục 172 phần "Việc còn lại").
    example_masks = torch.zeros(args.num_regions, args.image_size, args.image_size, device=device)
    for i in range(args.num_regions):
        lo = args.image_size * i // args.num_regions
        hi = args.image_size * (i + 1) // args.num_regions
        example_masks[i, :, lo:hi] = 1.0
    example_control_hint = torch.randn(2, 3, args.image_size, args.image_size, device=device)

    onnx_name = f"unet_regional_mask_controlnet_{args.num_regions}char.onnx"
    mnn_name = f"unet_regional_mask_controlnet_{args.num_regions}char.mnn"
    onnx_path = os.path.join(args.output_dir, onnx_name)
    print(f"Đang export ONNX -> {onnx_path} (có thể mất vài phút)...")
    with torch.no_grad():
        torch.onnx.export(
            augmented,
            (example_sample, example_timestep, example_uncond, example_background,
             example_regions, example_masks, example_control_hint),
            onnx_path,
            input_names=["sample", "timestep", "uncond_encoder_hidden_states",
                         "background_encoder_hidden_states", "region_encoder_hidden_states",
                         "region_masks", "control_hint"],
            output_names=["out_sample"],
            opset_version=17,
            do_constant_folding=True,
            # KHÔNG dùng dynamic_axes — giống mọi bản export khác. Mask
            # cũng shape CỐ ĐỊNH [num_regions, image_size, image_size] —
            # đổi image_size lúc infer mà không export lại sẽ suy side sai
            # (giới hạn KẾ THỪA từ bản cột, không phải mới).
            dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo — xem
            # giải thích đầy đủ trong export_ipa_controlnet_regional_unet.py /
            # TECHNICAL_STATUS.md mục 97, không lặp lại ở đây.
        )

    print("\n=== XONG PHẦN ONNX ===")
    print(f"Shape region_masks ({args.num_regions} vùng): {tuple(example_masks.shape)}")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, mnn_name)} --bizCode biz")
    print(f"\nQUAN TRỌNG: model CỐ ĐỊNH cho ĐÚNG {args.num_regions} vùng VÀ ảnh VUÔNG")
    print(f"{args.image_size}x{args.image_size} — mask truyền lúc infer PHẢI cùng kích thước")
    print("image_size này (tự resize trước nếu khác) — sai kích thước suy side SAI ở mọi")
    print("layer attn2, KHÔNG có kiểm tra runtime nào bắt lỗi này, ảnh hỏng ÂM THẦM.")


if __name__ == "__main__":
    main()
