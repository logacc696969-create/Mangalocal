#!/usr/bin/env python3
# mục 273 — kiểm TĨNH nối dây của nút "Thử gọi API thật" (FreeImageSelfTest + SettingsScreen). Không có kotlinc: kiểm cấu trúc mã + mô phỏng Python của phần định dạng
# thông báo (số học KB/giây) + phép thử phá mã. Hành vi gọi mạng thật CHƯA được kiểm (đó chính là việc nút này để người dùng làm trên máy).
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
def rd(rel): return open(os.path.join(K, rel), encoding='utf-8').read()
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)

def checks(st, ui):
    r = []
    r.append(('gọi đúng đường tạo ảnh nền/ảnh phác (FreeImageClient.generate), 1 ảnh nhỏ', 'FreeImageClient(provider, creds).generate(TEST_PROMPT, "", TEST_SIZE, TEST_SIZE, TEST_SEED, onWait)' in st and 'const val TEST_SIZE = 256' in st))
    r.append(('huỷ coroutine được ném lại TRƯỚC nhánh bắt mọi lỗi', re.search(r'catch \(ce: CancellationException\) \{\s*throw ce\s*\} catch \(ex: Exception\)', st) is not None))
    r.append(('lỗi thường thành thông báo (không ném)', 'FreeImageTestReport(false, describeFailure(provider, ex.message))' in st))
    r.append(('thành công báo đuôi ảnh, KB và thời gian', 'describeSuccess(provider, r.ext, r.bytes.size, System.currentTimeMillis() - t0)' in st))
    r.append(('UI: mỗi nhà cung cấp một nút, chỉ bật khi rảnh và đủ thông tin', 'for (p in FreeImageProvider.values())' in ui and 'enabled = freeImgTesting == null && prob.isEmpty()' in ui))
    r.append(('UI: thiếu thông tin thì hiện lý do (từ FreeImageApi.problems)', 'FreeImageApi.problems(p, settings.freeImage.toCreds())' in ui and 'if (prob.isNotEmpty()) Text(prob.joinToString("; ")' in ui))
    r.append(('UI: chạy trong scope.launch và luôn trả trạng thái rảnh', re.search(r'scope\.launch \{\s*val rep = FreeImageSelfTest\.run\(p, settings\.freeImage\.toCreds\(\)\)\s*freeImgResult = rep\.message; freeImgOk = rep\.ok; freeImgTesting = null', ui) is not None))
    r.append(('UI: kết quả đỏ/xanh theo thành công', 'color = if (freeImgOk) C.Green else C.Red' in ui))
    r.append(('có đủ import cho SettingsScreen', all(('import com.mangalocal.pipeline.' + n + '\n') in ui for n in ['FreeImageApi', 'FreeImageProvider', 'FreeImageSelfTest', 'toCreds'])))
    r.append(('khai báo đủ 3 trạng thái', all(v in ui for v in ['var freeImgTesting by remember', 'var freeImgResult by remember', 'var freeImgOk by remember'])))
    r.append(('không dùng Switch(/Slider( trần (test_param_help cấm)', not re.search(r'(?<![A-Za-z])(Switch|Slider)\(', ui.split('mục 273')[1][:3500])))
    return r

def fmt_success(label, ext, nbytes, ms):
    return f"✓ {label}: nhận ảnh .{ext} {(nbytes + 512) // 1024} KB sau {ms // 1000}.{(ms % 1000) // 100} giây — API và thông tin đăng nhập dùng được."

ST, UI = rd('pipeline/FreeImageSelfTest.kt'), rd('ui/SettingsScreen.kt')
for n, ok in checks(ST, UI): check(ok, n)
check(fmt_success('X', 'jpg', 24576, 1234) == '✓ X: nhận ảnh .jpg 24 KB sau 1.2 giây — API và thông tin đăng nhập dùng được.', 'mô phỏng định dạng: 24576 byte, 1234 ms -> 24 KB, 1.2 giây')
check('${(byteCount + 512) / 1024} KB' in ST and '${elapsedMs / 1000}.${(elapsedMs % 1000) / 100} giây' in ST, 'công thức Kotlin khớp mô phỏng Python')
muts = [
 ('bỏ ném lại huỷ coroutine', 'ST', 'catch (ce: CancellationException) {\n            throw ce\n        } ', ''),
 ('nút bật dù thiếu thông tin', 'UI', 'enabled = freeImgTesting == null && prob.isEmpty()', 'enabled = freeImgTesting == null'),
 ('nút bật khi đang thử', 'UI', 'enabled = freeImgTesting == null && prob.isEmpty()', 'enabled = prob.isEmpty()'),
 ('không trả trạng thái rảnh', 'UI', 'freeImgOk = rep.ok; freeImgTesting = null', 'freeImgOk = rep.ok'),
 ('ảnh thử lớn 1024', 'ST', 'const val TEST_SIZE = 256', 'const val TEST_SIZE = 1024'),
 ('thiếu import toCreds', 'UI', 'import com.mangalocal.pipeline.toCreds\n', ''),
 ('kết quả luôn xanh', 'UI', 'color = if (freeImgOk) C.Green else C.Red', 'color = C.Green'),
 ('KB làm tròn xuống thay vì gần nhất', 'ST', '(byteCount + 512) / 1024', 'byteCount / 1024'),
]
src = {'ST': ST, 'UI': UI}; caught = 0
for name, k, old, new in muts:
    assert old in src[k], name
    m2 = dict(src); m2[k] = src[k].replace(old, new, 1)
    bad = any(not ok for _, ok in checks(m2['ST'], m2['UI'])) or ('(byteCount + 512) / 1024' not in m2['ST'])
    caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name)
check(caught == len(muts), f'đột biến: {caught}/{len(muts)} bị bắt')

# mục 276 — FLUX schnell gửi seed (tuỳ chọn theo tài liệu Cloudflare) để thử lại sau 408/3007 ra đúng ảnh cũ. test_free_image_api.py cần kotlinc nên kiểm TĨNH thêm ở đây.
API = rd('pipeline/FreeImageApi.kt'); APIT = open(os.path.join(ROOT, 'tools/test_free_image_api.py'), encoding='utf-8').read()
def seed_checks(api, apit):
    return [('FLUX schnell: thân yêu cầu gửi seed (đã qua seedInt không âm)', 'model.contains("flux-1-schnell") -> "{\\"prompt\\":" + MiniJson.quote(p) + ",\\"steps\\":4,\\"seed\\":${seedInt(seed)}}"' in api),
            ('test_free_image_api.py kỳ vọng thân FLUX có seed', "want = {'prompt': p, 'steps': 4, 'seed': s31}" in apit),
            ('các họ model khác giữ nguyên (Lightning/SDXL vẫn có seed, model lạ chỉ prompt)', api.count('seedInt(seed)') >= 4)]
for n, ok in seed_checks(API, APIT): check(ok, n)
mm = [('FLUX không gửi seed', API.replace(',\\"steps\\":4,\\"seed\\":${seedInt(seed)}}"', ',\\"steps\\":4}"', 1), APIT),
      ('test không kỳ vọng seed', API, APIT.replace("'steps': 4, 'seed': s31}", "'steps': 4}", 1))]
cs = 0
for name, a, t in mm:
    bad = any(not ok for _, ok in seed_checks(a, t)); cs += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + 'seed FLUX — ' + name)
check(cs == len(mm), f'đột biến seed FLUX: {cs}/{len(mm)} bị bắt')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
