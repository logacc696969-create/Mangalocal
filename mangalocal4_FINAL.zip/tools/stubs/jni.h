#pragma once
#include <cstdint>
typedef int32_t jint; typedef int64_t jlong; typedef float jfloat; typedef jint jsize;
struct _jobject{}; typedef _jobject* jobject; typedef _jobject* jstring; typedef _jobject* jfloatArray;
struct JNIEnv_ {
  const char* GetStringUTFChars(jstring, void*) { return ""; }
  void ReleaseStringUTFChars(jstring, const char*) {}
  jfloatArray NewFloatArray(jsize) { return nullptr; }
  void SetFloatArrayRegion(jfloatArray, jsize, jsize, const jfloat*) {}
};
typedef JNIEnv_ JNIEnv;
#define JNIEXPORT
#define JNICALL
