#pragma once
#include <map>
#include <string>
#include <vector>
#include "Tensor.hpp"
#define MNN_FORWARD_CPU 0
#define MNN_FORWARD_OPENCL 3
namespace MNN {
struct BackendConfig { enum PrecisionMode { Precision_Normal, Precision_High, Precision_Low }; PrecisionMode precision = Precision_Normal; };
struct ScheduleConfig { int type = 0; int numThread = 4; BackendConfig* backendConfig = nullptr; };
class Session;
class Interpreter {
public:
  static Interpreter* createFromFile(const char*) { return nullptr; }
  Session* createSession(const ScheduleConfig&) { return nullptr; }
  std::map<std::string, Tensor*> getSessionInputAll(const Session*) const { return {}; }
  std::map<std::string, Tensor*> getSessionOutputAll(const Session*) const { return {}; }
  void resizeTensor(Tensor*, const std::vector<int>&) {}
  void resizeSession(Session*) {}
  int runSession(Session*) const { return 0; }
  bool releaseSession(Session*) { return true; }
};
}
