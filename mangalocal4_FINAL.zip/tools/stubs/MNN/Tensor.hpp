#pragma once
#include <vector>
namespace MNN {
class Tensor {
public:
  enum DimensionType { TENSORFLOW, CAFFE, CAFFE_C4 };
  Tensor(const Tensor*, DimensionType = CAFFE, bool = true) {}
  template <typename T> T* host() const { return nullptr; }
  bool copyFromHostTensor(const Tensor*) { return true; }
  bool copyToHostTensor(Tensor*) const { return true; }
  std::vector<int> shape() const { return {}; }
};
}
