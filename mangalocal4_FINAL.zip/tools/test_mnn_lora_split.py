#!/usr/bin/env python3
"""mục 264 — kiểm thử THỰC NGHIỆM trên MNN thật (tools/mnn_probe): LoRA tách rời qua Module::Config::base.
Biên dịch hai chương trình thử với bản build MNN (MNN_SRC = thư mục mã nguồn, MNN_LIB = libMNN.a tĩnh), chạy, rồi kiểm các sự thật đã đo:
  (1) nhánh LoRA tách rời cho đầu ra BẰNG bản gộp trọng số (sai lệch < 1e-5) ở mọi cấu hình;
  (2) config.base CHỈ chia sẻ trọng số nền khi rearrange=true (mặc định false thì KHÔNG) — đây là "kênh báo động": nếu đổi phiên bản MNN làm đổi hành vi, test này báo;
  (3) RAM: với base + rearrange=true mỗi module LoRA thêm rất ít (chỉ nhánh LoRA), không base thì mỗi module tốn cả bản sao trọng số.
KHÔNG chứng minh: chạy được trên UNet thật, backend OpenCL/NPU, trọng số lượng tử hoá w8, tốc độ. Không có bản build MNN -> BỎ QUA (exit 0).
"""
import os, re, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.environ.get('MNN_SRC', '/home/claude/work/tp/MNN'); LIB = os.environ.get('MNN_LIB', '/home/claude/work/mnnbuild/libMNN.a')
if not (os.path.isdir(os.path.join(SRC, 'include')) and os.path.isfile(LIB)):
    print('SKIP: không có bản build MNN (đặt MNN_SRC và MNN_LIB, xem tools/mnn_probe/README.md)'); sys.exit(0)
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + d) if (d and not c) else '')); ok &= bool(c)
tmp = tempfile.mkdtemp()
def build_run(name, timeout):
    exe = os.path.join(tmp, name)
    r = subprocess.run(['g++', '-std=c++17', '-O1', os.path.join(ROOT, 'tools/mnn_probe', name + '.cpp'), '-I', os.path.join(SRC, 'include'),
                        '-Wl,--whole-archive', LIB, '-Wl,--no-whole-archive', '-lpthread', '-ldl', '-o', exe], capture_output=True, text=True)
    if r.returncode != 0: return None, r.stderr[-500:]
    o = subprocess.run([exe], capture_output=True, text=True, cwd=tmp, timeout=timeout)
    return (o.stdout if o.returncode == 0 else None), o.stderr[-300:]
out, err = build_run('lora_split_equivalence', 120)
check('lora_split_equivalence biên dịch và chạy với MNN thật', out is not None, err)
if out:
    rows = []
    for line in out.split('\n'):
        m = re.match(r'(.+?)\s+(\d)\s+(\d)\s+([0-9.e+-]+)$', line.strip())
        if m: rows.append((m.group(1).strip(), int(m.group(2)), int(m.group(3)), float(m.group(4))))
    check('có đủ 16 dòng kết quả (4 kiểu x 2 shapeMutable x 2 rearrange)', len(rows) == 16, str(len(rows)))
    g = lambda kind, ra=None: [r[3] for r in rows if r[0].startswith(kind) and (ra is None or r[2] == ra)]
    check('(1) bản gộp trọng số khớp tham chiếu CPU thuần (< 1e-5) ở mọi cấu hình', all(v < 1e-5 for v in g('gộp')) and len(g('gộp')) == 4)
    check('(1) nhánh LoRA tách rời (conv_A -> conv_B -> ADD) + base, conv0 thật: BẰNG bản gộp (< 1e-5) ở mọi cấu hình', all(v < 1e-5 for v in g('tách rời + base, conv0 thật')) and len(g('tách rời + base, conv0 thật')) == 4)
    check('(2) rearrange=true: base CHIA SẺ trọng số nền (conv0 trong file = 0 mà kết quả vẫn đúng, < 1e-5)', all(v < 1e-5 for v in g('tách rời + base, conv0 trong file=0', 1)) and len(g('tách rời + base, conv0 trong file=0', 1)) == 2)
    check('(2) rearrange=false (mặc định của Module::Config): base KHÔNG chia sẻ — kết quả sai (> 1) vì dùng trọng số 0 của chính file LoRA', all(v > 1 for v in g('tách rời + base, conv0 trong file=0', 0)) and len(g('tách rời + base, conv0 trong file=0', 0)) == 2)
    check('(2) không có base: luôn dùng trọng số của file (kết quả sai > 1) — đối chứng', all(v > 1 for v in g('tách rời KHÔNG base')) and len(g('tách rời KHÔNG base')) == 4)
out, err = build_run('lora_split_memory', 250)
check('lora_split_memory biên dịch và chạy với MNN thật', out is not None, err)
if out:
    lines = {('ra' if l.startswith('[base+rearrange]') else 'rf' if l.startswith('[base, rearrange=false]') else 'nb'): l for l in out.split('\n') if l.startswith('[')}
    num = lambda l: [float(x) for x in re.findall(r'LoRA \d: \+(-?[0-9.]+) MB', l)]
    check('đủ 3 chế độ đo, mỗi chế độ 3 module LoRA', set(lines) == {'ra', 'rf', 'nb'} and all(len(num(v)) == 3 for v in lines.values()), str(lines.keys()))
    if set(lines) == {'ra', 'rf', 'nb'}:
        ra, rf, nb = num(lines['ra']), num(lines['rf']), num(lines['nb'])
        check(f'(3) base + rearrange=true: module LoRA thứ 2 và thứ 3 thêm rất ít RAM (< 10 MB; đo {ra[1]:.0f}, {ra[2]:.0f} MB)', ra[1] < 10 and ra[2] < 10)
        check(f'(3) KHÔNG base: MỖI module LoRA tốn cả bản sao trọng số (> 30 MB; đo {nb})', all(v > 30 for v in nb))
        check(f'(3) rearrange=false: tốn nhiều hơn rearrange=true cho mỗi module LoRA (đo {rf} so với {nb})', all(a > b for a, b in zip(rf, nb)))
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
