#!/usr/bin/env python3
# mục 277/278 — kiểm TĨNH giao diện: màn Tư thế (thẻ tỷ lệ theo tuổi nằm DƯỚI khung vẽ, bảng từng đoạn, Hoàn tác), màn Nhân vật (trạng thái trống có lối ra, nút "＋ Thêm nhân vật mới" có chữ,
# chip "Theo tuổi"), PoseExtractor uỷ quyền cho AgeBodyScaler. Phần HÌNH HỌC và SỐ LIỆU được kiểm bằng mã Kotlin thật ở test_age_body_table.py (mục 278 thay bản mô phỏng Python của mục 277).
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
def rd(p): return open(os.path.join(K, p), encoding='utf-8').read()
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)

PE, UI, CH, HP, MD = rd('pipeline/PoseExtractor.kt'), rd('ui/PoseEditorScreen.kt'), rd('ui/CharactersScreen.kt'), rd('ui/HelpScreen.kt'), rd('model/Models.kt')

def static(pe, ui, ch, hp, md):
    r = []
    r.append(('PoseExtractor: rescaleBodyForAge uỷ quyền AgeBodyScaler với hệ số theo tuổi neo', 'return AgeBodyScaler.rescale(person, AgeBodyTable.factors(from.years, to.years))' in pe))
    r.append(('PoseExtractor: Từ = Sang trả danh sách cũ', 'if (from == to) return person' in pe))
    r.append(('AgeCategory có tuổi neo từ AgeBodyTable', 'CHILD("Trẻ em", 0.42f, AgeBodyTable.CHILD_AGE)' in pe and 'ADULT("Người lớn", 0.50f, AgeBodyTable.ADULT_AGE)' in pe))
    r.append(('AgeProportions (gộp tay/chân làm một) đã bỏ khỏi mã', 'AgeProportions' not in pe and 'AgeProportions' not in ui.replace('Ngữ nghĩa/căn cứ', '')))
    r.append(('hàm cũ rescaleLegsForAge còn nguyên (không phá mã cũ)', 'fun rescaleLegsForAge(' in pe))
    r.append(('UI: khối tỷ lệ nằm SAU khung vẽ (Reset zoom) và TRƯỚC điều khiển khớp', 0 < ui.index('Reset zoom') < ui.index('mục 277: Tỷ lệ cơ thể theo tuổi') < ui.index('Điều khiển khớp đang chọn')))
    r.append(('UI: gọi rescaleBodyForAge (không còn rescaleLegsForAge)', 'poseExtractor.rescaleBodyForAge(before, fromAge, toAge)' in ui and 'poseExtractor.rescaleLegsForAge' not in ui))
    r.append(('UI: bảng từng đoạn đủ 7 dòng lấy từ AgeBodyTable', all(k in ui for k in ('AgeBodyTable.heightFractions(fromAge.years)', 'AgeBodyTable.factors(fromAge.years, toAge.years)', 'segRows.forEach')) and
              all(('Triple("' + n) in ui for n in ('Đầu', 'Thân (cổ → hông)', 'Vai / hông', 'Cánh tay trên', 'Cẳng tay', 'Đùi', 'Cẳng chân'))))
    r.append(('UI: ghi rõ số nào là ước lượng', 'Đầu và vai là ƯỚC LƯỢNG' in ui))
    agecard = ui[ui.index('MlLabel("tỷ lệ cơ thể theo tuổi")'):ui.index('Điều khiển khớp đang chọn')] if ('MlLabel("tỷ lệ cơ thể theo tuổi")' in ui and 'Điều khiển khớp đang chọn' in ui) else ''
    r.append(('UI: thẻ tuổi báo kết quả bằng chữ + có Hoàn tác (riêng thẻ này, không lẫn với thẻ vị trí mục 279)', '✓ Đã áp dụng' in agecard and 'MlOutlineBtn("↶ Hoàn tác (Người' in agecard and 'undoPerson!!' in agecard))
    r.append(('UI: báo lý do khi không áp dụng được', 'Không áp dụng được: thiếu khớp cổ hoặc hông' in ui))
    r.append(('UI: import AgeBodyTable', 'import com.mangalocal.model.AgeBodyTable' in ui))
    r.append(('Trợ giúp: nói rõ từng đoạn + nguồn số đo + nhân vật chọn tuổi', 'Mỗi ĐOẠN có hệ số riêng' in hp and 'Schmid 2019' in hp and 'chọn TUỔI 6–18' in hp))
    r.append(('Nhân vật: chưa chọn truyện thì có Scaffold + thanh dưới + danh sách truyện (không còn "...")', 'Text("...", color = C.T3)' not in ch and 'Chưa chọn truyện' in ch and 'bottomBar = { AppNavBar(nav, "characters") }' in ch and 'items(allStories)' in ch and 'vm.selectStory(st)' in ch))
    r.append(('Nhân vật: nút "＋ Thêm nhân vật mới" có chữ, ở ĐẦU danh sách', 'Thêm nhân vật mới' in ch and ch.index('Thêm nhân vật mới') < ch.index('item { ToolShortcuts(nav) }')))
    r.append(('Nhân vật: form thêm mở NGAY dưới nút và chỉ còn MỘT chỗ', ch.count('if (showAdd) item {') == 1 and 0 < ch.index('Thêm nhân vật mới') < ch.index('if (showAdd) item {') < ch.index('item { ToolShortcuts(nav) }')))
    r.append(('Nhân vật: chip "Theo tuổi" 6…18 gọi BoneProportions.forAge', 'Text("Theo tuổi:"' in ch and 'items(listOf(6, 8, 10, 12, 14, 16, 18))' in ch and 'BoneProportions.forAge(age, sex)' in ch))
    r.append(('Models: preset Trẻ em/Thiếu niên lấy từ forAge, không còn số tự đặt', 'fun presetChild(sex: BodySex = BodySex.UNSPECIFIED) = forAge(AgeBodyTable.CHILD_AGE, sex)' in md and 'fun presetTeen(sex: BodySex = BodySex.UNSPECIFIED) = forAge(AgeBodyTable.TEEN_AGE, sex)' in md and 'headSizeRatio = 1.3f' not in md))
    return r
for n, ok in static(PE, UI, CH, HP, MD): check(ok, n)

muts = [
 ('UI bỏ bảng từng đoạn', 'UI', 'segRows.forEach', 'segRows.map'),
 ('UI bỏ Hoàn tác của thẻ tuổi', 'UI', 'MlOutlineBtn("↶ Hoàn tác (Người', 'MlOutlineBtn("Xong (Người'),
 ('UI quay lại hàm chỉ-chân', 'UI', 'poseExtractor.rescaleBodyForAge(before, fromAge, toAge)', 'poseExtractor.rescaleLegsForAge(before, fromAge, toAge)'),
 ('PoseExtractor không còn uỷ quyền', 'PE', 'return AgeBodyScaler.rescale(person, AgeBodyTable.factors(from.years, to.years))', 'return person'),
 ('Nhân vật quay lại màn trống "..."', 'CH', 'Text("Chưa chọn truyện"', 'Text("..."'),
 ('Nhân vật bỏ nút Thêm có chữ', 'CH', 'Thêm nhân vật mới', 'Mới'),
 ('Nhân vật bỏ chip Theo tuổi', 'CH', 'Text("Theo tuổi:"', 'Text("Tuổi"'),
 ('Models quay lại preset tự đặt', 'MD', 'fun presetChild(sex: BodySex = BodySex.UNSPECIFIED) = forAge(AgeBodyTable.CHILD_AGE, sex)', 'fun presetChild(sex: BodySex = BodySex.UNSPECIFIED) = BoneProportions(headSizeRatio = 1.3f)'),
]
src = {'PE': PE, 'UI': UI, 'CH': CH, 'HP': HP, 'MD': MD}; caught = 0
for name, k, old, new in muts:
    assert old in src[k], name
    m2 = dict(src); m2[k] = src[k].replace(old, new, 1)
    try: bad = any(not ok for _, ok in static(m2['PE'], m2['UI'], m2['CH'], m2['HP'], m2['MD']))
    except ValueError: bad = True
    caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name)
check(caught == len(muts), f'đột biến: {caught}/{len(muts)} bị bắt')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
