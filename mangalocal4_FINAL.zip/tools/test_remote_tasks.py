#!/usr/bin/env python3
"""mục 250 — kiểm thử các tác vụ hậu kỳ trên server: faceswap (insightface), handfix (HandRefiner), kontext (FLUX Kontext).

Chạy THẬT các hàm của server (rút ra bằng ast) với module GIẢ cho insightface/controlnet_aux/diffusers/torch/huggingface_hub;
Pillow + numpy là thật. Chứng minh LOGIC: ghép mặt một-một, dán lại đúng vùng, kẹp tham số, hình học ghép ảnh tham chiếu, giải
phóng bộ nhớ, thông báo lỗi. KHÔNG chứng minh các mô hình thật chạy/ra ảnh đẹp (không GPU, không trọng số).
"""
import ast, base64, gc, io, os, sys, types
import numpy as np
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
APP = open(os.path.join(ROOT, 'tools', 'remote_server', 'app.py'), encoding='utf8').read()
tree = ast.parse(APP)

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

WANT_FN = ['_decode_rgb', '_png_bytes', '_box_iou', '_assign_faces', '_get_face_tools', '_largest_face', '_run_faceswap_sync',
           '_ear', '_mar', '_expression_metrics', '_expression_deviation', '_convex_hull', '_region_mask', '_restore_regions', '_lm68', '_best_face',
           '_fit8', '_import_mesh_graphormer', '_run_handfix_sync', '_fit16', '_stitch_geometry', '_kontext_dtype', '_load_kontext', '_run_kontext_sync',
           '_run_interact_sync']
WANT_GLOBS = ('_face_app', '_face_swapper', '_hand_detector', '_hand_cn', '_kontext_pipe', '_interact_pipe', 'EXPR_TOL', 'PROPORTION_TOL', 'CENTER_SHIFT_TOL', 'HEAD_SHOULDER_BAND', 'YAW_MAX_DEG')
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in WANT_FN]
globs = [n for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in WANT_GLOBS for t in n.targets)]
check('server có đủ %d hàm tác vụ + %d biến/hằng' % (len(WANT_FN), len(WANT_GLOBS)), {n.name for n in nodes} == set(WANT_FN) and len(globs) == len(WANT_GLOBS))

# ---------------- hạ tầng giả ----------------
log = {}
ORIG = [None]
AFTER_SEQ = []
def reset_log():
    ORIG[0] = None; AFTER_SEQ.clear()
    log.clear(); log.update(dict(swap=[], interact_calls=[], face_get=[], pipe_calls=[], from_pipe=0, cn_loaded=[], hf=0, kontext_loads=0, kontext_kw=None, empty_cache=0, lora=[], detector_kw=None, kontext_calls=[]))

class Face:
    def __init__(self, box, lm=None, yaw=None):
        self.bbox = np.array(box, dtype=np.float32); self.embedding = np.zeros(512)
        if lm is not None: self.landmark_3d_68 = np.concatenate([np.asarray(lm, dtype=np.float32), np.zeros((68, 1), dtype=np.float32)], axis=1)
        if yaw is not None: self.pose = np.array([0.0, yaw, 0.0])
FACES = {'scene': [], 'ref_a': [], 'ref_b': [], 'ref_none': []}
class FakeFaceAnalysis:
    def __init__(self, name=None, providers=None): log['fa_name'] = name; log['fa_providers'] = providers
    def prepare(self, ctx_id=0, det_size=(640, 640)): pass
    def get(self, bgr):
        h, w = bgr.shape[:2]
        log['face_get'].append((w, h))
        if ORIG[0] is not None and bgr.shape == ORIG[0].shape and not np.array_equal(bgr, ORIG[0]):
            log['after_calls'] = log.get('after_calls', 0) + 1
            if AFTER_SEQ: return AFTER_SEQ.pop(0)
        key = 'scene' if (w, h) == (400, 300) else ('ref_a' if w == 64 else ('ref_b' if w == 80 else ('ref_none' if w in (50, 100) else 'scene')))
        return FACES[key]
class FakeSwapper:
    def get(self, img, target_face, source_face, paste_back=True):
        log['swap'].append((target_face, source_face, paste_back)); out = img.copy(); x1, y1, x2, y2 = [int(v) for v in target_face.bbox]; out[y1:y2, x1:x2] = (0, 0, 255); return out   # BGR: đỏ... (B=0,G=0,R=255)
import tempfile
SW = os.path.join(tempfile.mkdtemp(), 'inswapper_128.onnx'); open(SW, 'wb').write(b'onnx')
def install(base_type='sd15', cn_path='', swapper_path=None, kontext_keep=False, hand_sig='full', mg='custom', cc=(7, 5), cuda=True, interact_rev='', interact_keep=False, aux_src='', pipe_rejects_hw=False):
    swapper_path = SW if swapper_path is None else swapper_path
    insight = types.ModuleType('insightface'); insight.model_zoo = types.SimpleNamespace(get_model=lambda p, **kw: log.__setitem__('swapper_path', p) or FakeSwapper())
    ins_app = types.ModuleType('insightface.app'); ins_app.FaceAnalysis = FakeFaceAnalysis
    # controlnet_aux
    class Detector:
        def __call__(self, input_image, detect_resolution=512, mask_bbox_padding=30, output_type='pil'):
            log['detector_kw'] = dict(detect_resolution=detect_resolution, mask_bbox_padding=mask_bbox_padding, output_type=output_type)
            return DETECT['res']
    class DetectorMin:
        def __call__(self, input_image): log['detector_kw'] = 'min'; return DETECT['res']
    mgd = types.SimpleNamespace(from_pretrained=lambda name, **kw: (Detector() if hand_sig == 'full' else DetectorMin()))
    for m in ('custom_controlnet_aux', 'custom_controlnet_aux.mesh_graphormer', 'controlnet_aux', 'controlnet_aux.mesh_graphormer'): sys.modules.pop(m, None)
    ca = types.ModuleType('controlnet_aux')
    if mg == 'custom':
        cm = types.ModuleType('custom_controlnet_aux.mesh_graphormer'); cm.MeshGraphormerDetector = mgd
        sys.modules['custom_controlnet_aux'] = types.ModuleType('custom_controlnet_aux'); sys.modules['custom_controlnet_aux.mesh_graphormer'] = cm
    elif mg == 'legacy':
        ca.MeshGraphormerDetector = mgd
    # diffusers
    class FakeCN:
        def to(self, d): log['cn_device'] = d; return self
    class FakePipe:
        def __call__(self, **kw):
            log['pipe_calls'].append(kw); w, h = kw['image'].size
            return types.SimpleNamespace(images=[Image.new('RGB', (w, h), (0, 255, 0))])
    dif = types.ModuleType('diffusers')
    dif.StableDiffusionControlNetInpaintPipeline = types.SimpleNamespace(from_pipe=lambda base, controlnet=None: (log.__setitem__('from_pipe', log['from_pipe'] + 1), FakePipe())[1])
    dif.ControlNetModel = types.SimpleNamespace(from_single_file=lambda p, torch_dtype=None: (log['cn_loaded'].append(p), FakeCN())[1])
    class KPipe:
        def enable_model_cpu_offload(self): log['offload'] = log.get('offload', 0) + 1
        def __call__(self, image=None, prompt=None, guidance_scale=None, num_inference_steps=None, generator=None):
            log['kontext_calls'].append((image.size, prompt, guidance_scale, num_inference_steps, generator))
            im = Image.new('RGB', (KOUT[0], KOUT[1]), (10, 20, 30))
            if KOUT[2] is not None:       # phần cảnh (trái) màu (10,20,30); phần ảnh tham chiếu (phải) màu (200,0,0)
                im = Image.new('RGB', (KOUT[0], KOUT[1]), (200, 0, 0)); im.paste((10, 20, 30), (0, 0, int(KOUT[0] * KOUT[2]), KOUT[1]))
            return types.SimpleNamespace(images=[im])
    def k_from(mid, **kw): log['kontext_loads'] += 1; log['kontext_kw'] = (mid, kw); return KPipe()
    dif.FluxKontextPipeline = types.SimpleNamespace(from_pretrained=k_from)
    class IPipe:
        def to(self, d): log['interact_device'] = d; return self
        def __call__(self, **kw):
            if pipe_rejects_hw and ('height' in kw or 'width' in kw): raise TypeError('unexpected keyword argument height')
            log['interact_calls'].append(kw)
            return types.SimpleNamespace(images=[Image.new('RGB', (512, 512), (50, 60, 70))])
    def i_from(mid, **kw): log['interact_loads'] = log.get('interact_loads', 0) + 1; log['interact_kw'] = (mid, kw); return IPipe()
    dif.DiffusionPipeline = types.SimpleNamespace(from_pretrained=i_from)
    quant = types.ModuleType('diffusers.quantizers')
    class PQC:
        def __init__(self, **kw): self.kw = kw
    quant.PipelineQuantizationConfig = PQC
    hf = types.ModuleType('huggingface_hub'); hf.hf_hub_download = lambda repo, fn: (log.__setitem__('hf', log['hf'] + 1), '/hf/' + fn)[1]
    torch = types.ModuleType('torch'); torch.bfloat16 = 'bf16'; torch.float16 = 'fp16'
    torch.cuda = types.SimpleNamespace(is_available=lambda: cuda, get_device_capability=lambda i=0: cc, empty_cache=lambda: log.__setitem__('empty_cache', log['empty_cache'] + 1))
    class Gen:
        def __init__(self, device='cpu'): self.device = device
        def manual_seed(self, s): self.seed = s; return self
    torch.Generator = Gen
    sys.modules.update({'insightface': insight, 'insightface.app': ins_app, 'controlnet_aux': ca, 'diffusers': dif, 'diffusers.quantizers': quant, 'huggingface_hub': hf, 'torch': torch})
    ns = {'Image': Image, 'io': io, 'base64': base64, 'os': os, 'gc': gc,
          'args': types.SimpleNamespace(inswapper_path=swapper_path, handrefiner_cn_path=cn_path, kontext_model_id='fake/kontext', keep_kontext=kontext_keep,
                                        controlnet_aux_src=aux_src, interact_model_id='fake/interact', interact_revision=interact_rev, keep_interact=interact_keep),
          'ensure_base_model': lambda mid, mt: log.setdefault('ensure', (mid, mt)), 'apply_lora': lambda p, l: log['lora'].append(l),
          '_torch_dtype': lambda: 'fp16', '_base_pipe': types.SimpleNamespace(device='cpu'), '_current_model_type': base_type}
    exec(compile(ast.Module(body=globs + nodes, type_ignores=[]), 'app.py', 'exec'), ns)
    return ns

def b64(img): b = io.BytesIO(); img.save(b, 'PNG'); return base64.b64encode(b.getvalue()).decode()
def decode(png): return Image.open(io.BytesIO(png)).convert('RGB')
DETECT = {'res': None}
KOUT = [100, 80, None]
def solid(w, h, c=(120, 120, 120)): return Image.new('RGB', (w, h), c)

# ---------------- _box_iou / _assign_faces ----------------
reset_log(); ns = install()
iou, assign = ns['_box_iou'], ns['_assign_faces']
check('IoU: trùng hoàn toàn = 1; không giao = 0; nửa chồng ≈ 1/3', iou((0, 0, 10, 10), (0, 0, 10, 10)) == 1.0 and iou((0, 0, 1, 1), (5, 5, 6, 6)) == 0.0 and abs(iou((0, 0, 10, 10), (5, 0, 15, 10)) - 1 / 3) < 1e-9)
check('IoU: hộp suy biến (diện tích 0) không chia 0', iou((0, 0, 0, 0), (0, 0, 0, 0)) == 0.0)
F = [(10, 10, 50, 60), (200, 20, 240, 70)]
check('ghép đúng một-một khi thứ tự đích khác thứ tự mặt', sorted(assign(F, [(195, 10, 250, 80), (5, 5, 55, 65)])) == [(0, 1), (1, 0)])
check('hai đích tranh một mặt -> mặt thuộc về đích có điểm cao hơn, đích kia bỏ trống (không dùng một mặt hai lần)', assign([(10, 10, 50, 60)], [(0, 0, 100, 100), (8, 8, 52, 62)]) == [(1, 0)])
check('IoU nhỏ nhưng TÂM mặt nằm trong hộp đích -> vẫn nhận (điểm thấp)', assign([(40, 40, 50, 50)], [(0, 0, 100, 100)]) == [(0, 0)])
check('thưởng "tâm mặt nằm trong hộp đích" quyết định khi IoU đánh lừa: mặt X (IoU 0.16, tâm NGOÀI hộp) thua mặt Y (IoU 0.11, tâm TRONG hộp)',
      assign([(40, -10, 100, 50), (20, 20, 40, 40)], [(0, 0, 60, 60)]) == [(0, 1)])
check('mặt hoàn toàn ngoài hộp đích -> không ghép', assign([(500, 500, 540, 540)], [(0, 0, 100, 100)]) == [])
check('thừa mặt / thừa đích đều không lỗi; không có mặt -> rỗng', assign(F + [(300, 300, 340, 340)], [(5, 5, 55, 65)]) == [(0, 0)] and assign([], [(0, 0, 1, 1)]) == [])
check('tham lam xác định: cùng đầu vào cho cùng kết quả', assign(F, [(5, 5, 55, 65), (195, 10, 250, 80)]) == assign(F, [(5, 5, 55, 65), (195, 10, 250, 80)]))

# ---------------- faceswap ----------------
scene = solid(400, 300)
FACES['scene'] = [Face((40, 30, 90, 90)), Face((250, 40, 310, 110))]
FACES['ref_a'] = [Face((5, 5, 30, 40)), Face((0, 0, 60, 60))]   # mặt lớn nhất = (0,0,60,60)
FACES['ref_b'] = [Face((10, 10, 70, 70))]
ref_a, ref_b = solid(64, 64, (255, 0, 0)), solid(80, 80, (0, 0, 255))
reset_log(); ns = install()
targets = [{'id': 'b', 'box': [250 / 400 - 0.02, 40 / 300 - 0.02, 310 / 400 + 0.02, 110 / 300 + 0.02], 'ref_b64': b64(ref_b)},
           {'id': 'a', 'box': [40 / 400 - 0.02, 30 / 300 - 0.02, 90 / 400 + 0.02, 90 / 300 + 0.02], 'ref_b64': b64(ref_a)}]
out = ns['_run_faceswap_sync']({'image_b64': b64(scene), 'targets': targets})
res = decode(out)
check('trả PNG hợp lệ cùng kích thước 400x300', res.size == (400, 300))
check('hoán đổi đủ 2 mặt, đúng cặp (mặt trái <- tham chiếu A, mặt phải <- tham chiếu B) dù đích khai báo ngược thứ tự',
      len(log['swap']) == 2 and {(tuple(s[0].bbox.tolist()), s[1] is FACES['ref_b'][0] or s[1] is FACES['ref_a'][1]) for s in log['swap']} == {((40.0, 30.0, 90.0, 90.0), True), ((250.0, 40.0, 310.0, 110.0), True)}
      and all(s[2] is True for s in log['swap']))
src_for_left = [s[1] for s in log['swap'] if tuple(s[0].bbox.tolist())[0] == 40.0][0]
check('mặt nguồn chọn là mặt LỚN NHẤT trong ảnh tham chiếu', src_for_left is FACES['ref_a'][1])
check('ảnh kết quả chỉ đổi trong vùng mặt: pixel ngoài vùng giữ nguyên, pixel trong vùng đổi', res.getpixel((5, 5)) == (120, 120, 120) and res.getpixel((60, 60)) == (255, 0, 0) and res.getpixel((280, 80)) == (255, 0, 0))
check('dùng đúng cấu hình insightface: buffalo_l + CUDA rồi CPU; nạp inswapper từ đường dẫn --inswapper-path', log['fa_name'] == 'buffalo_l' and log['fa_providers'] == ['CUDAExecutionProvider', 'CPUExecutionProvider'] and log['swapper_path'] == SW)
reset_log(); ns = install()
FACES['scene'] = [Face((40, 30, 90, 90))]
o2 = ns['_run_faceswap_sync']({'image_b64': b64(scene), 'targets': [targets[1], {'id': 'ghost', 'box': [0.8, 0.8, 0.95, 0.95], 'ref_b64': b64(ref_b)}]})
check('đích không khớp mặt nào (ghost) bị bỏ qua, đích khớp vẫn hoán đổi', len(log['swap']) == 1)
reset_log(); ns = install()
FACES['scene'] = [Face((40, 30, 90, 90))]
ns['_run_faceswap_sync']({'image_b64': b64(scene), 'targets': [{'id': 'n', 'box': targets[1]['box']}]})
check('đích thiếu ảnh tham chiếu -> bỏ qua, không lỗi', log['swap'] == [])
FACES['ref_none'] = []
reset_log(); ns = install()
ns['_run_faceswap_sync']({'image_b64': b64(scene), 'targets': [{'id': 'n', 'box': targets[1]['box'], 'ref_b64': b64(solid(50, 50))}]})
check('ảnh tham chiếu không có mặt: thử lại phóng 2x đúng 1 lần rồi bỏ qua (không vòng lặp)', log['swap'] == [] and (100, 100) in log['face_get'] and log['face_get'].count((100, 100)) == 1)
FACES['scene'] = [Face((40, 30, 90, 90))]
def raises(f, exc):
    try: f(); return False
    except exc: return True
reset_log(); ns = install()
check('thiếu image_b64 / thiếu targets / box sai độ dài -> ValueError', raises(lambda: ns['_run_faceswap_sync']({'targets': targets}), ValueError) and raises(lambda: ns['_run_faceswap_sync']({'image_b64': b64(scene)}), ValueError)
      and raises(lambda: ns['_run_faceswap_sync']({'image_b64': b64(scene), 'targets': [{'box': [0, 0, 1]}]}), ValueError))
reset_log(); ns = install(swapper_path='')
check('thiếu --inswapper-path -> FileNotFoundError nêu rõ cách khắc phục và giấy phép', raises(lambda: ns['_run_faceswap_sync']({'image_b64': b64(scene), 'targets': targets}), FileNotFoundError))
try:
    reset_log(); ns = install(swapper_path=''); ns['_run_faceswap_sync']({'image_b64': b64(scene), 'targets': targets})
except FileNotFoundError as e:
    check('thông báo lỗi nhắc tải riêng, phi thương mại và tên tham số', 'phi thương mại' in str(e) and '--inswapper-path' in str(e))

# ---------------- handfix ----------------
scene = solid(300, 200, (100, 100, 100))
mask_img = Image.new('L', (300, 200), 0); mask_img.paste(255, (100, 50, 160, 110))
depth_img = Image.new('RGB', (300, 200), (50, 50, 50))
DETECT['res'] = (depth_img, mask_img, {})
reset_log(); ns = install(cn_path='/local/cn.safetensors')
out = decode(ns['_run_handfix_sync']({'image_b64': b64(scene), 'seed': 5, 'strength': 5.0, 'steps': 1}))
kw = log['pipe_calls'][0]
check('trả ảnh cùng kích thước 300x200', out.size == (300, 200))
check('chỉ vùng mask được thay (xanh lá từ pipeline giả); ngoài mask giữ NGUYÊN pixel gốc', out.getpixel((130, 80)) == (0, 255, 0) and out.getpixel((10, 10)) == (100, 100, 100) and out.getpixel((290, 190)) == (100, 100, 100))
edge = out.getpixel((99, 80))
check('biên mask được làm mờ: pixel sát biên là HỖN HỢP giữa gốc (100,100,100) và vùng vẽ lại (0,255,0)', edge not in ((100, 100, 100), (0, 255, 0)) and 0 < edge[0] < 100 and 100 < edge[1] < 255)
check('kích thước đưa vào pipeline chia hết cho 8 (300x200 -> 296x200); ControlNet image là depth RGB', kw['image'].size == (296, 200) and kw['control_image'].size == (296, 200) and kw['control_image'].mode == 'RGB' and kw['mask_image'].size == (296, 200))
check('kẹp tham số: strength 5.0 -> 1.0, steps 1 -> 10; controlnet_conditioning_scale 1.0', kw['strength'] == 1.0 and kw['num_inference_steps'] == 10 and kw['controlnet_conditioning_scale'] == 1.0 and kw['generator'].seed == 5)
check('dùng ControlNet từ --handrefiner-cn-path (không tải HF) và bỏ LoRA nhân vật đang gắn trên pipeline nền', log['cn_loaded'] == ['/local/cn.safetensors'] and log['hf'] == 0 and log['lora'] == [None])
check('ép model nền SD1.5 khi gọi ensure_base_model', log['ensure'][1] == 'sd15')
reset_log(); ns = install()
ns['_run_handfix_sync']({'image_b64': b64(scene)})
check('không có --handrefiner-cn-path -> tự tải control_sd15_inpaint_depth_hand_fp16.safetensors từ Hugging Face đúng 1 lần', log['hf'] == 1 and log['cn_loaded'] == ['/hf/control_sd15_inpaint_depth_hand_fp16.safetensors'])
ns['_run_handfix_sync']({'image_b64': b64(scene)})
check('lần gọi thứ 2 dùng lại bộ phát hiện và ControlNet (không nạp lại)', len(log['cn_loaded']) == 1 and log['hf'] == 1)
DETECT['res'] = (depth_img, Image.new('L', (300, 200), 0), {})
reset_log(); ns = install()
res0 = ns['_run_handfix_sync']({'image_b64': b64(scene)})
check('không thấy tay (mask toàn 0) -> trả nguyên ảnh, KHÔNG gọi pipeline, không nạp ControlNet', decode(res0).tobytes() == scene.tobytes() and log['pipe_calls'] == [] and log['cn_loaded'] == [])
DETECT['res'] = (depth_img, mask_img, {})
reset_log(); ns = install(base_type='sdxl')
check('model nền SDXL -> ValueError rõ ràng (ControlNet chỉ cho SD1.5)', raises(lambda: ns['_run_handfix_sync']({'image_b64': b64(scene)}), ValueError))
reset_log(); ns = install(hand_sig='min')
ns['_run_handfix_sync']({'image_b64': b64(scene)})
check('bộ phát hiện chỉ nhận 1 tham số -> tham số tuỳ chọn được lọc theo chữ ký, không TypeError', log['detector_kw'] == 'min' and len(log['pipe_calls']) == 1)
DETECT['res'] = (np.zeros((200, 300, 3), dtype=np.uint8), np.full((200, 300), 255, dtype=np.uint8), {})
reset_log(); ns = install()
check('bộ phát hiện trả mảng numpy thay vì PIL -> vẫn xử lý được', decode(ns['_run_handfix_sync']({'image_b64': b64(scene)})).size == (300, 200))
check('thiếu image_b64 -> ValueError', raises(lambda: ns['_run_handfix_sync']({}), ValueError))

# ---------------- kontext ----------------
f16, stitch = ns['_fit16'], ns['_stitch_geometry']
check('_fit16: cạnh dài ≤ 1024 và bội của 16; ảnh nhỏ không phóng to', f16(2048, 1024) == (1024, 512) and f16(100, 50) == (96, 48) and f16(1000, 700)[0] % 16 == 0 and f16(1000, 700)[1] % 16 == 0 and max(f16(5000, 100)) <= 1024)
rnw, tot, left = stitch(512, 512, 200, 400)
check('hình học ghép tham chiếu: cùng chiều cao, bề rộng bội 16, phần cảnh = rw/(rw+rnw)', rnw == 256 and tot == 768 and abs(left - 512 / 768) < 1e-9)
reset_log(); ns = install(); KOUT[:] = [64, 48, None]
img = solid(120, 90, (9, 9, 9))
out = decode(ns['_run_kontext_sync']({'image_b64': b64(img), 'prompt': '  giữ nguyên danh tính  ', 'seed': 3}))
call = log['kontext_calls'][0]
check('kết quả được đổi về ĐÚNG kích thước ảnh gốc (120x90) dù mô hình trả cỡ khác', out.size == (120, 90))
check('prompt được cắt khoảng trắng; guidance 2.5 và 28 bước mặc định; ảnh vào là bội 16 giữ tỉ lệ', call[1] == 'giữ nguyên danh tính' and call[2] == 2.5 and call[3] == 28 and call[0] == (112, 80) and call[4].seed == 3)
kw = log['kontext_kw']
check('nạp model từ --kontext-model-id; GPU Turing (T4, cc 7.5) -> fp16 (không có bf16 phần cứng) + nén NF4 4-bit cho transformer + offload CPU',
      kw[0] == 'fake/kontext' and kw[1]['torch_dtype'] == 'fp16' and kw[1]['quantization_config'].kw['quant_backend'] == 'bitsandbytes_4bit'
      and kw[1]['quantization_config'].kw['quant_kwargs']['bnb_4bit_quant_type'] == 'nf4' and kw[1]['quantization_config'].kw['quant_kwargs']['bnb_4bit_compute_dtype'] == 'fp16' and kw[1]['quantization_config'].kw['components_to_quantize'] == ['transformer'] and log['offload'] == 1)
check('không --keep-kontext: giải phóng bộ nhớ sau mỗi request (nạp lại ở request sau)', log['empty_cache'] >= 1 and (ns['_run_kontext_sync']({'image_b64': b64(img), 'prompt': 'x'}) is not None) and log['kontext_loads'] == 2)
reset_log(); ns = install(kontext_keep=True)
ns['_run_kontext_sync']({'image_b64': b64(img), 'prompt': 'x'}); ns['_run_kontext_sync']({'image_b64': b64(img), 'prompt': 'y'})
check('--keep-kontext: nạp 1 lần, dùng lại cho request sau', log['kontext_loads'] == 1)
reset_log(); ns = install(); KOUT[:] = [224, 80, 80 / 112]
ref = solid(40, 80, (0, 200, 0))
out = decode(ns['_run_kontext_sync']({'image_b64': b64(solid(80, 80)), 'prompt': 'p', 'ref_b64': b64(ref)}))
cw, ch = log['kontext_calls'][0][0]
check('có ảnh tham chiếu: ảnh gửi vào là cảnh + tham chiếu ghép NGANG (112x80: cảnh 80 + tham chiếu 32), kết quả đưa về 80x80', (cw, ch) == (112, 80) and out.size == (80, 80))
check('kết quả CẮT lấy phần cảnh: mọi pixel là màu của phần cảnh (10,20,30), KHÔNG lẫn màu vùng tham chiếu (200,0,0)', out.getpixel((5, 5)) == (10, 20, 30) and out.getpixel((75, 40)) == (10, 20, 30) and out.getpixel((79, 79)) == (10, 20, 30))
reset_log(); ns = install(); KOUT[:] = [100, 80, None]
check('kẹp: guidance 99 -> 10; steps 1 -> 10', (ns['_run_kontext_sync']({'image_b64': b64(img), 'prompt': 'x', 'guidance_scale': 99, 'steps': 1}) is not None) and log['kontext_calls'][0][2] == 10.0 and log['kontext_calls'][0][3] == 10)
check('thiếu image_b64 / prompt rỗng -> ValueError', raises(lambda: ns['_run_kontext_sync']({'prompt': 'x'}), ValueError) and raises(lambda: ns['_run_kontext_sync']({'image_b64': b64(img), 'prompt': '   '}), ValueError))

# ================= mục 251: kiểm biểu cảm / tỉ lệ cho faceswap =================
def lm68(mouth_open=0.0, eye_open=0.30, brow=0.55, mouth_w=1.0, cx=100.0, cy=100.0, scale=1.0):
    """68 điểm iBUG tổng hợp quanh (cx,cy); khoảng cách hai mắt = 60·scale; tham số chính là CHÍNH các chỉ số đo."""
    s_ = scale; p = np.zeros((68, 2))
    for k in range(17): p[k] = (cx + (k - 8) * 6 * s_, cy + 20 * s_ + abs(k - 8) * 3 * s_ + 40 * s_)    # hàm
    for k, i in enumerate(range(27, 36)): p[i] = (cx + (k - 4) * 4 * s_, cy + 5 * s_ + 4 * s_ * (k % 3))   # mũi
    def eye(xc, yc, idx):
        h = eye_open * 12 * s_
        pts = [(xc - 12 * s_, yc), (xc - 4 * s_, yc - h), (xc + 4 * s_, yc - h), (xc + 12 * s_, yc), (xc + 4 * s_, yc + h), (xc - 4 * s_, yc + h)]
        for i, q in zip(idx, pts): p[i] = q
    eye(cx - 30 * s_, cy - 20 * s_, range(36, 42)); eye(cx + 30 * s_, cy - 20 * s_, range(42, 48))
    for idx, xc in ((range(17, 22), cx - 30 * s_), (range(22, 27), cx + 30 * s_)):
        for k, i in enumerate(idx): p[i] = (xc + (k - 2) * 7 * s_, cy - 20 * s_ - brow * 60 * s_)
    my = cy + 45 * s_; mw = mouth_w; u = mouth_open * 15 * s_ * mw
    p[48] = (cx - 20 * s_ * mw, my); p[54] = (cx + 20 * s_ * mw, my)
    for k, i in enumerate(range(49, 54)): p[i] = (cx + (-12 + 6 * k) * s_ * mw, my - 8 * s_ - u)
    for k, i in enumerate(range(55, 60)): p[i] = (cx + (12 - 6 * k) * s_ * mw, my + 8 * s_ + u)
    p[60] = (cx - 15 * s_ * mw, my); p[61] = (cx - 5 * s_ * mw, my - u); p[62] = (cx, my - u); p[63] = (cx + 5 * s_ * mw, my - u)
    p[64] = (cx + 15 * s_ * mw, my); p[65] = (cx + 5 * s_ * mw, my + u); p[66] = (cx, my + u); p[67] = (cx - 5 * s_ * mw, my + u)
    return p

reset_log(); ns = install()
met, dev_fn = ns['_expression_metrics'], ns['_expression_deviation']
m0 = met(lm68())
check('EAR đo đúng: mắt mở 0.30 -> 0.30; mắt khép 0.10 -> 0.10 (công thức Soukupová & Čech, mắt 36-41/42-47)', abs(m0['ear_r'] - 0.30) < 1e-6 and abs(m0['ear_l'] - 0.30) < 1e-6 and abs(met(lm68(eye_open=0.10))['ear_r'] - 0.10) < 1e-6)
check('MAR đo đúng theo môi TRONG 60-67: miệng khép 0 -> 0; mở 0.40 -> 0.40', abs(m0['mar']) < 1e-6 and abs(met(lm68(mouth_open=0.4))['mar'] - 0.4) < 1e-6)
check('độ rộng miệng (khoé 48-54) / khoảng cách hai mắt và độ cao lông mày so với mắt được chuẩn hoá', abs(m0['mouth_w'] - 40 / 60) < 1e-6 and abs(m0['brow_r'] - 0.55) < 1e-6 and abs(met(lm68(brow=0.30))['brow_l'] - 0.30) < 1e-6)
m2 = met(lm68(scale=2.5, cx=300, cy=250))
check('các chỉ số BẤT BIẾN theo kích thước/vị trí mặt (chuẩn hoá theo khoảng cách hai mắt)', all(abs(m2[k] - m0[k]) < 1e-9 for k in m0))
dv, bad = dev_fn(m0, met(lm68()))
check('cùng biểu cảm -> độ lệch 0, không vi phạm', all(v < 1e-9 for v in dv.values()) and bad == [])
check('miệng khép -> mở 0.30 vượt ngưỡng MAR; mắt 0.30 -> 0.20 vượt ngưỡng EAR; mắt 0.30 -> 0.26 trong ngưỡng', dev_fn(m0, met(lm68(mouth_open=0.3)))[1] == ['mar'] and dev_fn(m0, met(lm68(eye_open=0.20)))[1] == ['ear'] and dev_fn(m0, met(lm68(eye_open=0.26)))[1] == [])
check('lông mày nhướng 0.55 -> 0.40 vượt ngưỡng brow; miệng cười rộng 1.0 -> 1.4 vượt ngưỡng mouth_w', dev_fn(m0, met(lm68(brow=0.40)))[1] == ['brow'] and dev_fn(m0, met(lm68(mouth_w=1.4)))[1] == ['mouth_w'])
check('ngưỡng nằm trong server (đối chiếu hằng): EAR 0.07, MAR 0.10, mouth_w 0.12, brow 0.10; tỉ lệ 0.12; dịch tâm 0.08; yaw 55°; dải đầu/vai 0.25–0.60',
      ns['EXPR_TOL'] == {'ear': 0.07, 'mar': 0.10, 'mouth_w': 0.12, 'brow': 0.10} and ns['PROPORTION_TOL'] == 0.12 and ns['CENTER_SHIFT_TOL'] == 0.08 and ns['YAW_MAX_DEG'] == 55.0 and ns['HEAD_SHOULDER_BAND'] == (0.25, 0.60))
hull = ns['_convex_hull']
check('bao lồi: hình vuông + điểm bên trong -> đúng 4 đỉnh; điểm thẳng hàng/ít điểm không lỗi', set(hull([(0, 0), (10, 0), (10, 10), (0, 10), (5, 5), (3, 4)])) == {(0.0, 0.0), (10.0, 0.0), (10.0, 10.0), (0.0, 10.0)} and len(hull([(0, 0), (1, 1), (2, 2)])) <= 3 and hull([(1, 1)]) == [(1.0, 1.0)])
LM = lm68(cx=100, cy=100)
mk = np.asarray(ns['_region_mask']((200, 200), LM, 120.0))
check('mặt nạ vùng: phủ tâm MIỆNG (100,145) và hai MẮT (70,80),(130,80); KHÔNG phủ trán (100,10), cằm xa (100,195), má xa (10,100)', mk[145, 100] >= 250 and mk[80, 70] >= 250 and mk[80, 130] >= 250 and mk[10, 100] < 10 and mk[195, 100] < 10 and mk[100, 10] < 10)
check('mặt nạ có biên MỀM (có giá trị trung gian) để dán không lộ viền', 0 < int(((mk > 20) & (mk < 235)).sum()))
orig, swp = np.full((200, 200, 3), 10, np.uint8), np.full((200, 200, 3), 200, np.uint8)
rr = ns['_restore_regions'](orig, swp, LM, 120.0)
check('khôi phục vùng: tâm miệng/mắt = ẢNH GỐC (≈10), ngoài vùng = ẢNH ĐÃ HOÁN ĐỔI (200), kiểu uint8', rr[145, 100][0] <= 12 and rr[80, 70][0] <= 12 and rr[10, 100][0] == 200 and rr.dtype == np.uint8)
lmf = ns['_lm68']
check('_lm68: mặt không có landmark -> None; (68,3) -> (68,2); (50,3) -> None', lmf(types.SimpleNamespace()) is None and lmf(Face((0, 0, 1, 1), lm=LM)).shape == (68, 2) and lmf(types.SimpleNamespace(landmark_3d_68=np.zeros((50, 3)))) is None)
bf = ns['_best_face']
check('_best_face: chọn mặt có IoU lớn nhất; dưới 0.3 -> None', bf([Face((0, 0, 10, 10)), Face((50, 50, 90, 90))], (52, 52, 90, 90)).bbox[0] == 50 and bf([Face((0, 0, 10, 10))], (100, 100, 120, 120)) is None)

# ---- luồng faceswap có bảo vệ ----
scene = solid(400, 300, (120, 120, 120)); SCENE_BGR = np.asarray(scene)[:, :, ::-1].copy()
BOX = (40, 30, 90, 90); LM0 = lm68(cx=65, cy=60, scale=0.6)
LM_OPEN = lm68(cx=65, cy=60, scale=0.6, mouth_open=0.35)
tgt = lambda **kw: dict({'id': 'a', 'box': [38 / 400, 28 / 300, 92 / 400, 92 / 300], 'ref_b64': b64(ref_a)}, **kw)
FACES['ref_a'] = [Face((0, 0, 60, 60))]
def run_fs(after=None, face=None, preserve=None, tg=None, **inst):
    reset_log(); ORIG[0] = SCENE_BGR; AFTER_SEQ[:] = after or []
    FACES['scene'] = [face or Face(BOX, lm=LM0)]
    n = install(**inst)
    pl = {'image_b64': b64(scene), 'targets': [tg or tgt()]}
    if preserve: pl['preserve'] = preserve
    png = n['_run_faceswap_sync'](pl)
    im = Image.open(io.BytesIO(png)); rep_ = json.loads(im.text['mangalocal_report']); return im.convert('RGB'), rep_['faces'][0], rep_
import json
im, e, full = run_fs(after=[[Face((41, 31, 91, 91), lm=LM0)]])
check('biểu cảm giữ nguyên -> hoán đổi nguyên vẹn (status swapped), độ lệch ≈ 0, kích thước mặt không đổi', e['status'] == 'swapped' and max(e['dev'].values()) < 0.01 and abs(e['size_ratio'] - 1.0) < 0.01 and im.getpixel((65, 87)) == (255, 0, 0))
check('PNG mang báo cáo JSON trong khối tEXt: task=faceswap và danh sách mặt', full['task'] == 'faceswap' and len(full['faces']) == 1 and e['id'] == 'a')
im, e, _ = run_fs(after=[[Face(BOX, lm=LM_OPEN)], [Face(BOX, lm=LM0)]])
check('biểu cảm LỆCH (miệng mở) -> khôi phục miệng/mắt gốc rồi đo lại đạt -> status restored, lý do nêu "mar"', e['status'] == 'restored' and 'mar' in e['reason'])
check('sau khôi phục: tâm miệng (65,87) là ảnh GỐC (xám), phần mặt ngoài vùng miệng/mắt vẫn là mặt đã hoán đổi (đỏ)', im.getpixel((65, 87)) == (120, 120, 120) and im.getpixel((45, 70)) == (255, 0, 0))   # (45,70): má, ngoài vùng miệng/mắt/lông mày
im, e, _ = run_fs(after=[[Face(BOX, lm=LM_OPEN)], [Face(BOX, lm=LM_OPEN)]])
check('khôi phục xong mà VẪN lệch -> HOÀN NGUYÊN: status reverted và ảnh = ảnh gốc từng pixel', e['status'] == 'reverted' and 'vẫn lệch' in e['reason'] and np.array_equal(np.asarray(im)[:, :, ::-1], SCENE_BGR))
im, e, _ = run_fs(after=[[Face((30, 20, 100, 100), lm=LM0)]])
check('mặt sau hoán đổi to hơn 40% (đầu bị phình) -> reverted, lý do nêu kích thước/vị trí; ảnh giữ nguyên', e['status'] == 'reverted' and 'kích thước' in e['reason'] and np.array_equal(np.asarray(im)[:, :, ::-1], SCENE_BGR))
im, e, _ = run_fs(after=[[Face((60, 50, 110, 110), lm=LM0)]])
check('mặt dịch tâm 20px (40% bề rộng mặt) -> reverted (dịch tâm vượt ngưỡng)', e['status'] == 'reverted')
im, e, _ = run_fs(after=[[]])
check('không dò lại được mặt sau khi hoán đổi -> hoàn nguyên (không tin kết quả chưa kiểm)', e['status'] == 'reverted' and 'không dò lại' in e['reason'])
im, e, _ = run_fs(face=Face(BOX, lm=LM0, yaw=70))
check('mặt quay 70° (> 55°) -> bỏ qua, KHÔNG gọi bộ hoán đổi', e['status'] == 'skipped' and '70' in e['reason'] and log['swap'] == [])
im, e, _ = run_fs(face=Face(BOX, lm=LM0, yaw=40), after=[[Face(BOX, lm=LM0)]])
check('mặt quay 40° (≤ 55°) -> vẫn hoán đổi', e['status'] == 'swapped')
im, e, _ = run_fs(preserve='mouth_eyes', after=[[Face(BOX, lm=LM0)], [Face(BOX, lm=LM0)]])
check('preserve="mouth_eyes": LUÔN giữ miệng/mắt gốc kể cả khi biểu cảm không lệch', e['status'] == 'restored' and 'mouth_eyes' in e['reason'] and im.getpixel((65, 87)) == (120, 120, 120))
im, e, _ = run_fs(preserve='none')
check('preserve="none": không đo lại (không gọi dò mặt trên ảnh đã hoán đổi), vẫn hoán đổi', e['status'] == 'swapped' and log.get('after_calls', 0) == 0)
im, e, _ = run_fs(preserve='bậy', after=[[Face(BOX, lm=LM0)]])
check('preserve không hợp lệ -> dùng "auto"', e['status'] == 'swapped' and log.get('after_calls', 0) >= 1)
im, e, _ = run_fs(face=Face(BOX), preserve='auto')
check('không có landmark -> vẫn hoán đổi nhưng ghi chú "bỏ qua kiểm biểu cảm" (không giả vờ đã kiểm)', e['status'] == 'swapped' and 'landmark' in e['note'])
im, e, _ = run_fs(tg=tgt(shoulder_norm=0.05), after=[[Face(BOX, lm=LM0)]])
check('tỉ lệ mặt/vai ngoài dải nhân trắc (50px/20px = 2.5) -> có CẢNH BÁO nhưng không chặn hoán đổi', 'flag' in e and 'nhân trắc' in e['flag'] and e['status'] == 'swapped' and abs(e['head_shoulder'] - 2.5) < 1e-6)
im, e, _ = run_fs(tg=tgt(shoulder_norm=0.30), after=[[Face(BOX, lm=LM0)]])
check('tỉ lệ mặt/vai trong dải (50px/120px = 0.417) -> không cảnh báo', 'flag' not in e and abs(e['head_shoulder'] - 50 / 120) < 1e-3)
im, e, full = run_fs(tg=tgt(box=[0.8, 0.8, 0.95, 0.95]))
check('đích không khớp mặt nào -> báo cáo "skipped", ảnh giữ nguyên', e['status'] == 'skipped' and np.array_equal(np.asarray(im)[:, :, ::-1], SCENE_BGR))

reset_log(); ns = install()
png_np = ns['_png_bytes'](Image.new('RGB', (4, 4)), {'a': np.float32(1.5), 'b': [np.float32(2.0)], 'c': np.float64(0.25)})
check('_png_bytes: báo cáo chứa số numpy (float32/float64 — như bbox insightface) vẫn serialize được, đọc lại đúng giá trị', json.loads(Image.open(io.BytesIO(png_np)).text['mangalocal_report']) == {'a': 1.5, 'b': [2.0], 'c': 0.25})
# ---- import MeshGraphormer đúng nguồn ----
DETECT['res'] = (depth_img, mask_img, {})
scene_h = solid(300, 200, (100, 100, 100))
reset_log(); ORIG[0] = None; ns = install(mg='pypi_none')
msg = ''
try: ns['_run_handfix_sync']({'image_b64': b64(scene_h)})
except ImportError as e: msg = str(e)
check('chỉ có gói PyPI controlnet_aux (không có lớp MeshGraphormerDetector) -> ImportError hướng dẫn: nêu rõ PyPI không có, --controlnet-aux-src, mediapipe/trimesh/yacs', 'PyPI' in msg and '--controlnet-aux-src' in msg and 'mediapipe' in msg and 'trimesh' in msg and 'yacs' in msg)
reset_log(); ns = install(mg='legacy')
check('bản cũ import từ `controlnet_aux` (repo cũ của ComfyUI) vẫn dùng được', len(ns['_run_handfix_sync']({'image_b64': b64(scene_h)})) > 100 and len(log['pipe_calls']) == 1)
reset_log(); ns = install(mg='custom')
check('ưu tiên package `custom_controlnet_aux.mesh_graphormer` (bản fork hiện hành)', len(ns['_run_handfix_sync']({'image_b64': b64(scene_h)})) > 100)
reset_log(); ns = install(mg='pypi_none', aux_src='/tmp/fake_aux_src')
try: ns['_run_handfix_sync']({'image_b64': b64(scene_h)})
except ImportError: pass
check('--controlnet-aux-src được thêm vào sys.path trước khi import', '/tmp/fake_aux_src' in sys.path)
sys.path[:] = [x for x in sys.path if x != '/tmp/fake_aux_src']

# ---- Kontext: dtype theo GPU ----
reset_log(); ns = install(cc=(8, 0)); KOUT[:] = [64, 48, None]
ns['_run_kontext_sync']({'image_b64': b64(img), 'prompt': 'x'})
check('GPU Ampere (cc 8.0) -> bf16 (và compute dtype 4-bit bf16)', log['kontext_kw'][1]['torch_dtype'] == 'bf16' and log['kontext_kw'][1]['quantization_config'].kw['quant_kwargs']['bnb_4bit_compute_dtype'] == 'bf16')
reset_log(); ns = install(cc=(7, 5)); ns['_run_kontext_sync']({'image_b64': b64(img), 'prompt': 'x'})
check('GPU Turing/T4 (cc 7.5) -> fp16 (T4 không có bf16 phần cứng)', log['kontext_kw'][1]['torch_dtype'] == 'fp16')
reset_log(); ns = install(cuda=False); ns['_run_kontext_sync']({'image_b64': b64(img), 'prompt': 'x'})
check('không có CUDA -> bf16', log['kontext_kw'][1]['torch_dtype'] == 'bf16')

# ---- InteractDiffusion ----
IT = {'subject_phrase': 'person', 'object_phrase': 'person', 'action_phrase': 'hugging', 'subject_box': [0.05, 0.1, 0.5, 0.95], 'object_box': [0.45, 0.1, 0.95, 0.95]}
reset_log(); ns = install()
out = decode(ns['_run_interact_sync']({'interaction': IT, 'width': 512, 'height': 640, 'seed': 9}))
kw = log['interact_calls'][0]
check('tên tham số ĐÚNG model card: interactdiffusion_{subject,object,action}_phrases, _{subject,object}_boxes, _scheduled_sampling_beta=1, output_type=pil',
      kw['interactdiffusion_subject_phrases'] == ['person'] and kw['interactdiffusion_object_phrases'] == ['person'] and kw['interactdiffusion_action_phrases'] == ['hugging']
      and kw['interactdiffusion_subject_boxes'] == [[0.05, 0.1, 0.5, 0.95]] and kw['interactdiffusion_object_boxes'] == [[0.45, 0.1, 0.95, 0.95]]
      and kw['interactdiffusion_scheduled_sampling_beta'] == 1 and kw['output_type'] == 'pil')
check('mặc định: prompt "a photo of two people", 40 bước; ảnh trả về ĐÚNG cỡ yêu cầu (512x640) dù pipeline trả 512x512', kw['prompt'] == 'a photo of two people' and kw['num_inference_steps'] == 40 and out.size == (512, 640) and kw['height'] == 640 and kw['width'] == 512)
check('nạp bằng trust_remote_code=True, fp16, từ --interact-model-id; chuyển sang GPU; seed đặt vào generator', log['interact_kw'][0] == 'fake/interact' and log['interact_kw'][1]['trust_remote_code'] is True and log['interact_kw'][1]['variant'] == 'fp16' and log['interact_kw'][1]['torch_dtype'] == 'fp16'
      and 'revision' not in log['interact_kw'][1] and log['interact_device'] == 'cuda' and kw['generator'].seed == 9)
reset_log(); ns = install(interact_rev='abc123'); ns['_run_interact_sync']({'interaction': IT})
check('--interact-revision được truyền để GHIM commit (an toàn hơn khi chạy mã tải về)', log['interact_kw'][1]['revision'] == 'abc123')
reset_log(); ns = install(); ns['_run_interact_sync']({'interaction': IT, 'width': 4000, 'height': 100, 'steps': 1})
check('kẹp kích thước vào [256,768] (bội 8) và số bước ≥ 10', (log['interact_calls'][0]['width'], log['interact_calls'][0]['height']) == (768, 256) and log['interact_calls'][0]['num_inference_steps'] == 10)
def bad_it(**ch): d = dict(IT); d.update(ch); return d
check('thiếu cụm chủ thể/hành động -> ValueError', raises(lambda: ns['_run_interact_sync']({'interaction': bad_it(action_phrase='  ')}), ValueError) and raises(lambda: ns['_run_interact_sync']({}), ValueError))
check('hộp sai (3 số / ngoài [0,1] / x2 ≤ x1) -> ValueError', raises(lambda: ns['_run_interact_sync']({'interaction': bad_it(subject_box=[0, 0, 1])}), ValueError) and raises(lambda: ns['_run_interact_sync']({'interaction': bad_it(object_box=[0, 0, 1.5, 1])}), ValueError) and raises(lambda: ns['_run_interact_sync']({'interaction': bad_it(subject_box=[0.5, 0.1, 0.4, 0.9])}), ValueError))
reset_log(); ns = install(pipe_rejects_hw=True)
r = ns['_run_interact_sync']({'interaction': IT, 'width': 640, 'height': 512})
check('pipeline tuỳ biến không nhận height/width -> thử lại KHÔNG có hai tham số đó, kết quả vẫn đưa về cỡ yêu cầu', 'height' not in log['interact_calls'][0] and decode(r).size == (640, 512))
reset_log(); ns = install()
ns['_run_interact_sync']({'interaction': IT}); ns['_run_interact_sync']({'interaction': IT})
check('không --keep-interact: nạp lại mỗi request và giải phóng bộ nhớ', log['interact_loads'] == 2 and log['empty_cache'] >= 2)
reset_log(); ns = install(interact_keep=True)
ns['_run_interact_sync']({'interaction': IT}); ns['_run_interact_sync']({'interaction': IT})
check('--keep-interact: nạp 1 lần', log['interact_loads'] == 1)

for m in ('insightface', 'insightface.app', 'controlnet_aux', 'controlnet_aux.mesh_graphormer', 'custom_controlnet_aux', 'custom_controlnet_aux.mesh_graphormer', 'diffusers', 'diffusers.quantizers', 'huggingface_hub', 'torch'): sys.modules.pop(m, None)

# ---------------- điều phối + echo ----------------
gen = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_run_generation_sync')
gsrc = ast.get_source_segment(APP, gen)
reg = next(n for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == '_TASK_HANDLERS' for t in n.targets))
check('_TASK_HANDLERS có đủ 5 tác vụ: video, faceswap, handfix, kontext, interact', {k.value for k in reg.value.keys} == {'video', 'faceswap', 'handfix', 'kontext', 'interact'})
check('điều phối: tác vụ lạ -> 400; lỗi trong tác vụ -> 500 có chi tiết; chạy TRƯỚC khi đọc prompt (đường ảnh cũ không đổi)',
      'status_code=400, detail=f"Tác vụ không hỗ trợ' in gsrc and 'status_code=500, detail=f"Tác vụ {task} lỗi' in gsrc and gsrc.index('_TASK_HANDLERS') < gsrc.index('payload.get("prompt"'))
gfn = next(n for n in tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'generate')
gen_src = ast.get_source_segment(APP, gfn)
check('phản hồi mã hoá có trường `task` (echo) CHỈ khi request có task; lấy task TRƯỚC khi payload bị xoá', 'task_echo = payload.get("task")' in gen_src and 'resp["task"] = task_echo' in gen_src and gen_src.index('task_echo = ') < gen_src.index('del payload'))
check('tham số dòng lệnh mới có mặt, nhắc giấy phép phi thương mại', all(a in APP for a in ['"--inswapper-path"', '"--handrefiner-cn-path"', '"--kontext-model-id"', '"--keep-kontext"']) and APP.count('PHI THƯƠNG MẠI') >= 2)

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
