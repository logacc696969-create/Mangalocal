#!/usr/bin/env python3
# mục 270 — KIỂM CHÉO TĨNH Kotlin khi KHÔNG có kotlinc (không thay thế biên dịch thật; chỉ bắt lỗi "viết mù" phổ biến trong các tệp Compose chưa từng
# qua CI). Ba kiểm tra: (1) tham số CÓ TÊN ở nơi gọi hàm/constructor của dự án phải tồn tại ở ÍT NHẤT MỘT bản định nghĩa cùng tên; (2) mọi `vm.xxx` /
# `viewModel.xxx` trong UI phải là fun/val/var của MainViewModel; (3) mọi `import com.mangalocal.…` phải trỏ tới khai báo có thật; (4) cân bằng ngoặc ()[]{} (mục 273); (5) màu C.Tên có thật (mục 275).
# Giới hạn đã biết: không hiểu kiểu, không hiểu overload theo kiểu, không thấy thành viên kế thừa từ thư viện (AndroidViewModel.getApplication...).
import glob, os, re, sys
SHADOWS = {'Box'}  # tên dự án khai báo TRÙNG tên composable thư viện (data class Box ...) -> bỏ qua kiểm tham số có tên để khỏi báo nhầm
VM_INHERITED = {'getApplication'}
def strip(s):
    # remove comments and string literal contents (keep quotes) to simplify scanning
    out=[];i=0;n=len(s)
    while i<n:
        c=s[i]
        if s.startswith('//',i):
            j=s.find('\n',i); j=n if j<0 else j; i=j; continue
        if s.startswith('/*',i):
            j=s.find('*/',i+2); j=n if j<0 else j+2; out.append(' '); i=j; continue
        if s.startswith('"""',i):
            j=s.find('"""',i+3); j=n if j<0 else j+3; out.append('""'); i=j; continue
        if c=='"':
            j=i+1
            while j<n and s[j]!='"':
                if s[j]=='\\': j+=1
                elif s[j]=='$' and j+1<n and s[j+1]=='{':
                    d=1;j+=2
                    while j<n and d>0:
                        if s[j]=='{':d+=1
                        elif s[j]=='}':d-=1
                        j+=1
                    continue
                j+=1
            out.append('""'); i=j+1; continue
        if c=="'" and i+2<n and (s[i+2]=="'" or (s[i+1]=='\\' and i+3<n and s[i+3]=="'")):
            j=s.find("'",i+2 if s[i+1]!='\\' else i+3); out.append("'c'"); i=j+1; continue
        out.append(c); i+=1
    return ''.join(out)

def match_paren(s,i):
    d=0
    for j in range(i,len(s)):
        if s[j]=='(':d+=1
        elif s[j]==')':
            d-=1
            if d==0:return j
    return -1
def split_top(s):
    parts=[];d=0;cur=[]
    for ch in s:
        if ch in '([{<' and ch!='<': d+=1
        if ch in ')]}': d-=1
        if ch=='{' : pass
        if ch==',' and d==0: parts.append(''.join(cur));cur=[]
        else: cur.append(ch)
    if ''.join(cur).strip(): parts.append(''.join(cur))
    return parts



def analyze(root):
    files = glob.glob(root + '/**/*.kt', recursive=True)
    src = {f: open(f, encoding='utf-8').read() for f in files}
    clean = {f: strip(s) for f, s in src.items()}
    defs = {}
    for f, s in clean.items():
        for m in re.finditer(r'\bfun\s+(?:<[^>]*>\s*)?(?:[A-Za-z_][\w.<>?, ]*\.)?([A-Za-z_]\w*)\s*\(', s):
            name = m.group(1); i = m.end() - 1; j = match_paren(s, i)
            if j < 0: continue
            names = set()
            for p in split_top(s[i + 1:j]):
                p = re.sub(r'^(vararg|noinline|crossinline)\s+', '', p.strip())
                mm = re.match(r'([A-Za-z_]\w*)\s*:', p)
                if mm: names.add(mm.group(1))
            defs.setdefault(name, []).append(names)
        for m in re.finditer(r'\bclass\s+([A-Za-z_]\w*)\s*(?:<[^>]*>)?\s*\(', s):
            name = m.group(1); i = m.end() - 1; j = match_paren(s, i)
            if j < 0: continue
            names = set()
            for p in split_top(s[i + 1:j]):
                p = re.sub(r'^\s*(?:@\w+(?:\([^)]*\))?\s*)*', '', p)
                p = re.sub(r'^(?:private|public|internal|protected|override|open)?\s*(?:val|var)\s+', '', p.strip())
                mm = re.match(r'([A-Za-z_]\w*)\s*:', p.strip())
                if mm: names.add(mm.group(1))
            defs.setdefault(name, []).append(names)
    problems = []
    for f in files:
        s = clean[f]
        for m in re.finditer(r'(?<![\w.])([A-Za-z_]\w*)\s*\(', s):
            name = m.group(1)
            if name not in defs or name in SHADOWS: continue
            pre = s[max(0, m.start() - 12):m.start()]
            if re.search(r'\bfun\s+(?:<[^>]*>\s*)?$', pre) or re.search(r'\bclass\s+$', pre): continue
            i = m.end() - 1; j = match_paren(s, i)
            if j < 0: continue
            for a in split_top(s[i + 1:j]):
                mm = re.match(r'\s*([A-Za-z_]\w*)\s*=(?!=)', a)
                if mm and not any(mm.group(1) in n for n in defs[name]):
                    problems.append(('namedarg', os.path.relpath(f, root), s.count('\n', 0, m.start()) + 1, name + '(' + mm.group(1) + '=)'))
    vmf = os.path.join(root, 'ui/MainViewModel.kt')
    if vmf in clean:
        members = set(re.findall(r'\b(?:fun|val|var)\s+(?:<[^>]*>\s*)?([A-Za-z_]\w*)', clean[vmf])) | VM_INHERITED
        for f in files:
            if f == vmf: continue
            for m in re.finditer(r'(?<![\w.])(?:vm|viewModel)\.([A-Za-z_]\w*)', clean[f]):
                if m.group(1) not in members:
                    problems.append(('vm-member', os.path.relpath(f, root), clean[f].count('\n', 0, m.start()) + 1, 'vm.' + m.group(1)))
    decl = set()
    for f, s in clean.items():
        pk = re.search(r'^package\s+([\w.]+)', s, re.M)
        pk = pk.group(1) if pk else ''
        for m in re.finditer(r'^(?:[ \t]*(?:private|internal|public|data|enum|sealed|abstract|open|inline|const|value|annotation)\s+)*(?:class|object|interface|fun|val|var|typealias)\s+(?:<[^>]*>\s*)?(?:[A-Za-z_][\w<>?, ]*\.)?([A-Za-z_]\w*)', s, re.M):
            decl.add(pk + '.' + m.group(1))
    for f, s in src.items():
        for m in re.finditer(r'^import\s+(com\.mangalocal\.[\w.]+)(?:\s+as\s+\w+)?\s*$', s, re.M):
            imp = m.group(1)
            if imp.endswith('.*'): continue
            if imp not in decl and '.'.join(imp.split('.')[:-1]) not in decl:
                problems.append(('import', os.path.relpath(f, root), s.count('\n', 0, m.start()) + 1, imp))
    # (5) màu `C.Tên` phải là thành viên của object C (Components.kt) — lỗi hay gặp khi viết mù UI mới (mục 275)
    comp = os.path.join(root, 'ui/Components.kt')
    if comp in clean and 'object C' in clean[comp]:
        ci = clean[comp].index('object C'); cj = clean[comp].find('\n}', ci)
        cm = set(re.findall(r'val\s+(\w+)', clean[comp][ci:cj if cj > 0 else None]))
        for f in files:
            for m in re.finditer(r'(?<![\w.])C\.([A-Z]\w*)', clean[f]):
                if m.group(1) not in cm:
                    problems.append(('color', os.path.relpath(f, root), clean[f].count('\n', 0, m.start()) + 1, 'C.' + m.group(1)))
    # (4) cân bằng ngoặc ()[]{} sau khi bỏ chuỗi/ghi chú — bắt lỗi "thiếu/thừa ngoặc" của các lần sửa mù (không phải bộ phân tích cú pháp đầy đủ)
    pairs = {')': '(', ']': '[', '}': '{'}
    for f in files:
        stack = []; line = 1; bad = None
        for ch in clean[f]:
            if ch == '\n': line += 1
            elif ch in '([{': stack.append((ch, line))
            elif ch in pairs:
                if not stack or stack[-1][0] != pairs[ch]:
                    bad = (line, f"ngoặc '{ch}' không khớp"); break
                stack.pop()
        if bad is None and stack:
            bad = (stack[-1][1], f"ngoặc '{stack[-1][0]}' mở ở dòng {stack[-1][1]} chưa đóng")
        if bad: problems.append(('balance', os.path.relpath(f, root), bad[0], bad[1]))
    return files, sorted(set(problems))

if __name__ == '__main__':
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'app/src/main/java/com/mangalocal')
    files, probs = analyze(root)
    for p in probs: print(*p)
    print('đã kiểm', len(files), 'tệp Kotlin;', len(probs), 'nghi vấn')
    sys.exit(1 if probs else 0)
