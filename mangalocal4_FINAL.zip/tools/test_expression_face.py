#!/usr/bin/env python3
"""Mô phỏng Python (mục 238 TECHNICAL_STATUS.md) cho ExpressionFace.faceBoxes().
Chép lại NGUYÊN công thức từ ExpressionFace.kt (không có kotlinc ở sandbox) nên kiểm HÌNH HỌC, không kiểm biên dịch.
Bố cục khung xương THẬT: 18 khớp x (x, y, z, visible)."""
import math

FPP = 72
EYE_TO_HEAD, HEAD_FROM_SHOULDER, FEAT_W, FEAT_H, CENTER_BELOW, MIN_HEAD_PX = 0.42, 0.38, 0.85, 1.0, 0.35, 28.0

def face_boxes(sk, n_persons, W, H):
    out = []
    n = min(n_persons, len(sk) // FPP)
    min_side = min(W, H)
    vis = lambda b, j: sk[b + j * 4 + 3] > 0.5
    px = lambda b, j: sk[b + j * 4]
    py = lambda b, j: sk[b + j * 4 + 1]
    for i in range(n):
        b = i * FPP
        if not vis(b, 0): continue
        r, l = vis(b, 14), vis(b, 15)
        if not r and not l: continue
        both = r and l
        if both: ex, ey = (px(b, 14) + px(b, 15)) / 2, (py(b, 14) + py(b, 15)) / 2
        else:
            e = 14 if r else 15; ex, ey = px(b, e), py(b, e)
        sw = math.hypot((px(b, 2) - px(b, 5)) * W, (py(b, 2) - py(b, 5)) * H) if vis(b, 2) and vis(b, 5) else 0.0
        ed = math.hypot((px(b, 14) - px(b, 15)) * W, (py(b, 14) - py(b, 15)) * H) if both else 0.0
        hw = ed / EYE_TO_HEAD if both and ed > 0 else (sw * HEAD_FROM_SHOULDER if sw > 0 else 0.0)
        if sw > 0: hw = min(max(hw, 0.28 * sw), 0.55 * sw)
        if hw <= 0 or hw < MIN_HEAD_PX * (min_side / 512): continue
        cx = (ex + px(b, 0)) / 2 * W if both else px(b, 0) * W
        cy = ey * H + CENTER_BELOW * hw
        hwid, hhei = FEAT_W * hw / 2, FEAT_H * hw / 2
        c = lambda v, hi: max(0, min(int(v), hi))
        rect = (c(cx - hwid, W), c(cy - hhei, H), c(cx + hwid, W), c(cy + hhei, H))
        if rect[2] - rect[0] < 8 or rect[3] - rect[1] < 8: continue
        out.append(dict(idx=i, rect=rect, tq=not both, hw=hw))
    return out

def person(cx, eye_y, head_w_n=0.07, shoulder_w_n=0.19, eyes=(True, True), nose=True):
    """Người chuẩn hoá: đầu rộng head_w_n, mắt cách nhau 0.42*head_w_n, mũi dưới mắt 0.6*khoảng cách mắt."""
    d = EYE_TO_HEAD * head_w_n
    pts = {0: (cx, eye_y + 0.6 * d), 1: (cx, eye_y + 1.7 * head_w_n * 0.6),
           14: (cx - d / 2, eye_y), 15: (cx + d / 2, eye_y),
           16: (cx - head_w_n / 2, eye_y + 0.02), 17: (cx + head_w_n / 2, eye_y + 0.02),
           2: (cx - shoulder_w_n / 2, eye_y + 0.14), 5: (cx + shoulder_w_n / 2, eye_y + 0.14)}
    out = []
    for j in range(18):
        x, y = pts.get(j, (cx, eye_y + 0.3))
        v = 1.0
        if j == 0 and not nose: v = 0.0
        if j == 14 and not eyes[0]: v = 0.0
        if j == 15 and not eyes[1]: v = 0.0
        out += [x, y, 0.0, v]
    return out

def check(n, c):
    print(('PASS ' if c else 'FAIL ') + n); return c

def main():
    ok = True; W = H = 512
    sk = person(0.5, 0.20)
    r = face_boxes(sk, 1, W, H)
    ok &= check('người chính diện -> 1 vùng mặt', len(r) == 1 and not r[0]['tq'])
    x1, y1, x2, y2 = r[0]['rect']
    nose = (0.5 * W, (0.20 + 0.6 * EYE_TO_HEAD * 0.07) * H)
    ok &= check('vùng chứa mũi', x1 <= nose[0] <= x2 and y1 <= nose[1] <= y2)
    eye_y = 0.20 * H
    head_w = 0.07 * W
    mouth_y = eye_y + 0.65 * head_w   # miệng ~ dưới mắt 0.65 bề rộng đầu (heuristic giải phẫu)
    chin_y = eye_y + 0.95 * head_w
    brow_y = eye_y - 0.12 * head_w
    ok &= check('vùng chứa miệng ước lượng', y1 <= mouth_y <= y2)
    ok &= check('vùng chứa lông mày', y1 <= brow_y + 2)
    ok &= check('vùng không quá phình (rộng <= 1.0 bề rộng đầu)', (x2 - x1) <= 1.0 * head_w + 1)
    ok &= check('vùng KHÔNG tràn tới tai (rộng hơn đầu chắc chắn sai)', (x2 - x1) < head_w)
    ok &= check('quay lưng (không thấy mũi) -> bỏ', face_boxes(person(0.5, 0.2, nose=False), 1, W, H) == [])
    ok &= check('không thấy mắt nào -> bỏ', face_boxes(person(0.5, 0.2, eyes=(False, False)), 1, W, H) == [])
    t = face_boxes(person(0.5, 0.2, eyes=(True, False)), 1, W, H)
    ok &= check('một mắt (3/4) -> có vùng, đánh dấu threeQuarter', len(t) == 1 and t[0]['tq'])
    ok &= check('đầu quá nhỏ (xa) -> bỏ', face_boxes(person(0.5, 0.2, head_w_n=0.03, shoulder_w_n=0.08), 1, W, H) == [])
    two = face_boxes(person(0.3, 0.2) + person(0.7, 0.25), 2, W, H)
    ok &= check('hai người -> hai vùng, đúng chỉ số', [b['idx'] for b in two] == [0, 1])
    ok &= check('hai vùng không chồng nhau', two[0]['rect'][2] <= two[1]['rect'][0])
    edge = face_boxes(person(0.97, 0.05), 1, W, H)
    ok &= check('mặt sát mép ảnh -> vùng vẫn nằm trong ảnh', all(0 <= v <= 512 for b in edge for v in b['rect']))
    ok &= check('SDXL 1024: cùng người -> vùng tỉ lệ x2', abs((face_boxes(sk, 1, 1024, 1024)[0]['rect'][2] - face_boxes(sk, 1, 1024, 1024)[0]['rect'][0]) - 2 * (x2 - x1)) <= 3)
    ok &= check('khung xương rỗng -> rỗng', face_boxes([], 2, W, H) == [])
    ok &= check('số người > dữ liệu -> không lỗi', len(face_boxes(person(0.5, 0.2), 5, W, H)) == 1)
    print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'); raise SystemExit(0 if ok else 1)

if __name__ == '__main__':
    main()
