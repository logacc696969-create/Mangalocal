#!/usr/bin/env python3
"""Test THẬT (biên dịch + chạy C++) cho pose_templates::renderDepthHint() — mục 232 TECHNICAL_STATUS.md.

Khác các test *_sim.py/mô phỏng công thức: script này TRÍCH NGUYÊN VĂN hàm từ
app/src/main/jni/ip_adapter.cpp, biên dịch bằng g++ và chạy, nên phản ánh code
thật (không bị lệch nếu sửa ip_adapter.cpp). Yêu cầu: g++ trong PATH.

Kiểm tra: (1) z-buffer theo pixel — tay người XA nhưng GẦN camera nhất phải sáng
hơn thân người khác; (2) mức sàn — khớp xa nhất không được trùng màu nền;
(3) nền = 0; (4) cùng z vẫn ra hình; (5) không người -> canvas đen.
Dùng: python3 tools/test_depth_hint.py   (chạy từ thư mục gốc dự án)
"""
import os, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "app/src/main/jni/ip_adapter.cpp")

HEADER = r"""#include <vector>
#include <array>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cmath>
namespace pose_templates {
struct Keypoint { float x, y, z; bool visible; };
using Skeleton = std::array<Keypoint, 18>;
const std::vector<std::pair<int,int>> kBonePairs = {
    {1,2},{1,5},{2,3},{3,4},{5,6},{6,7},{1,8},{8,9},{9,10},
    {1,11},{11,12},{12,13},{1,0},{0,14},{14,16},{0,15},{15,17}
};
"""

TEST = r"""static pose_templates::Skeleton mk(float cx, float top, float z){
  pose_templates::Skeleton s{};
  auto set=[&](int i,float x,float y,float zz){ s[i]={x,y,zz,true}; };
  for(int i=0;i<18;i++) set(i,cx,top,z);
  set(0,cx,top,z); set(1,cx,top+0.08f,z);
  set(2,cx-0.07f,top+0.10f,z); set(5,cx+0.07f,top+0.10f,z);
  set(3,cx-0.10f,top+0.22f,z); set(6,cx+0.10f,top+0.22f,z);
  set(4,cx-0.11f,top+0.33f,z); set(7,cx+0.11f,top+0.33f,z);
  set(8,cx-0.04f,top+0.32f,z); set(11,cx+0.04f,top+0.32f,z);
  set(9,cx-0.04f,top+0.48f,z); set(12,cx+0.04f,top+0.48f,z);
  set(10,cx-0.04f,top+0.64f,z); set(13,cx+0.04f,top+0.64f,z);
  set(14,cx-0.01f,top-0.01f,z); set(15,cx+0.01f,top-0.01f,z);
  set(16,cx-0.02f,top,z); set(17,cx+0.02f,top,z);
  return s;
}
static int at(const std::vector<uint8_t>& c,int w,float x,float y,int h){ return c[((size_t)(int)(y*h)*w+(int)(x*w))*3]; }
int main(){
  int ok=1; auto chk=[&](const char* n,bool c){ printf("%s %s\n", c?"PASS":"FAIL", n); if(!c) ok=0; };
  const int W=512,H=512;
  // 1. Người XA (z lớn) có TAY PHẢI gần camera (z nhỏ) vắt qua thân người GẦN (z nhỏ hơn trung bình).
  pose_templates::Skeleton nearP = mk(0.55f,0.10f,0.0f);   // gần camera (z nhỏ)
  pose_templates::Skeleton farP  = mk(0.35f,0.10f,1.0f);   // xa
  farP[4] = {0.55f,0.25f,-0.2f,true};      // cổ tay phải của người XA đưa ra TRƯỚC thân người gần (z còn nhỏ hơn cả người gần)
  farP[3] = {0.45f,0.22f,0.4f,true};
  auto c = pose_templates::renderDepthHint({nearP,farP}, W, H);
  int v_torso = at(c,W,0.53f,0.34f,H);        // TRÊN nét xương cổ->hông của người gần, xa cổ tay người xa
  int v_hand  = at(c,W,0.55f,0.25f,H);        // đúng vị trí cổ tay người xa (z=-0.2, gần nhất)
  printf("   torso=%d hand=%d\n", v_torso, v_hand);
  chk("thân người gần có giá trị > 0 (đo đúng nét xương)", v_torso > 0);
  chk("tay người xa nhưng gần camera nhất SÁNG hơn thân người gần (z-buffer)", v_hand > v_torso);
  // 2. Người xa nhất không được trùng màu nền.
  int v_far_head = at(c,W,0.35f,0.10f,H);
  int v_bg = at(c,W,0.95f,0.95f,H);
  printf("   far_head=%d bg=%d\n", v_far_head, v_bg);
  chk("khớp xa nhất vẫn sáng hơn nền (mức sàn)", v_far_head > v_bg && v_far_head >= 48);
  // 3. Nền vẫn 0.
  chk("nền vẫn 0", v_bg==0);
  // 4. Hai người CÙNG z (đa số template): vẫn ra hình, không crash, không tối đen.
  auto c2 = pose_templates::renderDepthHint({mk(0.3f,0.1f,0.0f), mk(0.7f,0.1f,0.0f)}, W, H);
  chk("cùng z -> có pixel sáng ở cổ người 1", at(c2,W,0.3f,0.18f,H) > 0);
  // 5. Danh sách rỗng.
  { std::vector<pose_templates::Skeleton> none; auto e = pose_templates::renderDepthHint(none,W,H); chk("không người -> canvas đen", std::all_of(e.begin(), e.end(), [](uint8_t v){return v==0;})); }
  printf("%s\n", ok?"TAT CA DAT":"CO LOI");
  return ok?0:1;
}
"""

def main():
    src = open(SRC, encoding="utf-8").read()
    i = src.index("inline std::vector<uint8_t> renderDepthHint(")
    j = src.index("// Multi-IP-Adapter CÓ MASK VÙNG")
    code = HEADER + src[i:j] + "\n}\n" + TEST
    with tempfile.TemporaryDirectory() as d:
        cpp = os.path.join(d, "t.cpp"); exe = os.path.join(d, "t")
        open(cpp, "w", encoding="utf-8").write(code)
        r = subprocess.run(["g++", "-std=c++17", "-O1", "-o", exe, cpp], capture_output=True, text=True)
        if r.returncode != 0:
            print(r.stderr); sys.exit(2)
        r = subprocess.run([exe], capture_output=True, text=True)
        print(r.stdout)
        sys.exit(r.returncode)

if __name__ == "__main__":
    main()
