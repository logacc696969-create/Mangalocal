#!/usr/bin/env python3
"""mục 248 — kiểm thử tuỳ chọn PAG (Perturbed-Attention Guidance) trên server từ xa.

Chạy THẬT hàm `build_pag_pipe` của server (rút ra bằng ast, thay `diffusers` bằng bản giả) để kiểm: gọi đúng API
`AutoPipelineForText2Image.from_pipe(pipe, enable_pag=True, pag_applied_layers=["mid"])` và lỗi thì trả None.
Giới hạn thật: KHÔNG có GPU/diffusers ở đây nên KHÔNG chứng minh PAG chạy được với IP-Adapter/LoRA/ControlNet trên Colab;
phần chạy lại không-PAG là lưới an toàn cho đúng rủi ro đó.
"""
import ast, os, re, sys, types

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
APP = open(os.path.join(ROOT, 'tools', 'remote_server', 'app.py'), encoding='utf8').read()
KB = os.path.join(ROOT, 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(KB, *p), encoding='utf8').read()

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

tree = ast.parse(APP)
check('app.py hợp lệ cú pháp', tree is not None)
fn = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'build_pag_pipe'), None)
check('có hàm build_pag_pipe', fn is not None)

def load_with_fake(from_pipe_impl):
    calls = []
    fake = types.ModuleType('diffusers')
    class Auto:
        @staticmethod
        def from_pipe(pipe, **kw):
            calls.append((pipe, kw)); return from_pipe_impl(pipe, **kw)
    fake.AutoPipelineForText2Image = Auto
    sys.modules['diffusers'] = fake
    mod = ast.Module(body=[fn], type_ignores=[])
    ns = {}
    exec(compile(mod, 'app.py', 'exec'), ns)
    return ns['build_pag_pipe'], calls

if fn is not None:
    f, calls = load_with_fake(lambda pipe, **kw: ('PAG', pipe))
    out = f('PIPE')
    check('gọi from_pipe với enable_pag=True và pag_applied_layers=["mid"]', calls and calls[0][1] == {'enable_pag': True, 'pag_applied_layers': ['mid']})
    check('trả pipeline PAG khi dựng được', out == ('PAG', 'PIPE'))
    def boom(pipe, **kw): raise RuntimeError('không hỗ trợ')
    f2, _ = load_with_fake(boom)
    check('from_pipe lỗi -> trả None (không ném lỗi, caller chạy không PAG)', f2('PIPE') is None)
    sys.modules.pop('diffusers', None)

run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_run_generation_sync')
src = ast.get_source_segment(APP, run)
check('đọc pag_scale từ payload, mặc định 0, kẹp [0, 10], giá trị rác -> 0',
      'payload.get("pag_scale", 0.0)' in src and 'max(0.0, min(10.0,' in src and 'except (TypeError, ValueError):' in src and 'pag_scale = 0.0' in src)
check('chỉ dựng PAG khi pag_scale > 0 và chỉ truyền pag_scale khi dựng được', 'if pag_scale > 0:' in src and 'gen_kwargs["pag_scale"] = pag_scale' in src and 'if pag_pipe is not None:' in src)
check('PAG lỗi lúc chạy -> chạy lại KHÔNG PAG: bỏ pag_scale, đặt lại generator cùng seed, dùng pipe gốc',
      'gen_kwargs.pop("pag_scale", None)' in src and 'torch.Generator(device=pipe.device).manual_seed(int(seed))' in src and 'result = pipe(**gen_kwargs)' in src)
check('lỗi KHÔNG-PAG vẫn được ném lên như cũ (run_pipe is pipe -> raise)', 'if run_pipe is pipe:' in src and 'raise' in src)
check('không cache pipeline PAG (tránh thiếu image_encoder khi nạp IP-Adapter sau)', '_pag_pipe' not in APP.replace('build_pag_pipe', '') and 'KHÔNG cache' in APP)
check('log tham số có pag nhưng KHÔNG log nội dung prompt', 'pag={pag_scale or' in APP and 'print(f"[generate] model=' in APP)

# --- phía app ---
MD, RC, ST = rd('model', 'Models.kt'), rd('pipeline', 'RemoteGenerationClient.kt'), rd('ui', 'SettingsScreen.kt')
check('Kotlin: RemoteEndpointConfig.pagScale mặc định 0 (tắt)', 'val pagScale: Float = 0f' in MD)
check('Kotlin: client chỉ gửi pag_scale khi > 0 (server cũ không bị ảnh hưởng)', 'if (config.pagScale > 0f) put("pag_scale", config.pagScale.toDouble())' in RC)
check('Kotlin: thanh trượt trong khối Remote GPU, bước 0.5, 0..5', 'settings.remoteEndpoint.pagScale' in ST and 'copy(pagScale = (Math.round(it * 2f) / 2f))' in ST and 'valueRange = 0f..5f, steps = 9' in ST)

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
