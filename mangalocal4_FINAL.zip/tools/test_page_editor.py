#!/usr/bin/env python3
"""mục 260 — kiểm thử SỬA BỐ CỤC TRANG PDF (PageLayoutEditor.kt + nối dây + màn hình).

Không có kotlinc ở sandbox nên logic Kotlin được kiểm bằng BẢN CHÉP PYTHON viết bám từng dòng (bảng sức chứa/mẫu được ĐỌC từ chính
mã Kotlin để chống lệch), cộng kiểm tĩnh nối dây. Bản chép có thể lệch Kotlin ở chỗ tôi chép sai — các chuỗi điều kiện quan trọng nhất
được kiểm lại bằng regex trên nguồn Kotlin (phần 6) để giảm rủi ro đó. KHÔNG chứng minh: biên dịch được, giao diện đẹp, chạm được trên máy.
"""
import os, re, sys, random
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/')
def rd(p): return open(J + p, encoding='utf-8').read()
ED, PUB, MODELS, PIPE = rd('pipeline/PageLayoutEditor.kt'), rd('pipeline/PublishExporter.kt'), rd('model/Models.kt'), rd('pipeline/MangaPipeline.kt')
VM, MAIN, PP, SCR, HELP = rd('ui/MainViewModel.kt'), rd('MainActivity.kt'), rd('ui/PostProcessingScreen.kt'), rd('ui/PageLayoutScreen.kt'), rd('ui/ParamHelp.kt')

ok = True
def check(name, cond, detail=''):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + detail) if (detail and not cond) else ''))
    ok &= bool(cond)

# ---------- 1. đọc bảng từ mã Kotlin ----------
ENUM = re.findall(r'^\s*(\w+)\("[^"]*",\s*(\d+)\)', PUB[PUB.index('enum class PageTemplate'):PUB.index('/** pageWidthPt')], re.M)
PANELS_PER_PAGE = {n: int(c) for n, c in ENUM}
ALL = [n for n, _ in ENUM]
capbody = ED[ED.index('fun capacity('):ED.index('fun templateOf(')]
CAP = {m.group(1): int(m.group(2)) for m in re.finditer(r'PageTemplate\.(\w+) -> (\d+)', capbody)}
check('đọc được 6 mẫu từ enum PageTemplate', len(ALL) == 6 and 'AUTO' in ALL, str(ALL))
check('capacity() có ĐỦ nhánh cho mọi giá trị enum (when thiếu nhánh = lỗi biên dịch)', set(CAP) == set(ALL), f'{set(ALL) ^ set(CAP)}')
check('capacity() khớp panelsPerPage của enum (trừ AUTO là chế độ tài liệu)', all(CAP[k] == PANELS_PER_PAGE[k] for k in ALL if k != 'AUTO'), f'{CAP} vs {PANELS_PER_PAGE}')
PAGE_T = re.findall(r'PageTemplate\.(\w+)', ED[ED.index('val PAGE_TEMPLATES'):ED.index('fun capacity(')])
check('PAGE_TEMPLATES gồm đúng 5 mẫu cụ thể, không có AUTO', len(PAGE_T) == 5 and 'AUTO' not in PAGE_T and set(PAGE_T) == set(ALL) - {'AUTO'}, str(PAGE_T))
MAXP = int(re.search(r'const val MAX_PER_PAGE = (\d+)', ED).group(1))
check('MAX_PER_PAGE bằng sức chứa lớn nhất', MAXP == max(CAP.values()), f'{MAXP}')

# ---------- 2. bản chép Python (bám từng dòng PageLayoutEditor.kt) ----------
MUT = set()
def template_of(name):
    t = name if name in ALL else 'STACK_2'
    return 'STACK_2' if t == 'AUTO' else t
def best(n): return 'SPLASH' if n <= 1 else 'STACK_2' if n == 2 else 'ONE_PLUS_TWO' if n == 3 else 'GRID_2X2'
def fit(t, n):
    tt = 'STACK_2' if t == 'AUTO' else t
    if n <= 1: return 'SPLASH'
    if 'fit_nocap' in MUT: return tt
    return tt if CAP[tt] >= n else best(n)
def normalize(pages, valid_idx):
    order = list(dict.fromkeys(valid_idx))
    if not order: return []
    valid = set(order); seen = set(); groups = []
    for t0, ids in pages:
        kept = []
        for i in ids:
            if i in valid and (('no_dedupe' in MUT) or i not in seen):
                seen.add(i); kept.append(i)
        if not kept: continue
        t = template_of(t0)
        first = min(len(kept), CAP[t])
        groups.append((fit(t, first), first))
        rest = len(kept) - first
        while rest > 0:
            take = min(rest, MAXP); groups.append((best(take), take)); rest -= take
    if 'no_missing' not in MUT:
        missing = [i for i in order if i not in seen]
        for k in range(0, len(missing), 2):
            c = missing[k:k + 2]; groups.append((best(len(c)), len(c)))
    out = []; pos = 0
    for t, n in groups:
        out.append((t, order[pos:pos + n])); pos += n
    return out
def finish(pages): return normalize(pages, [i for _, ids in pages for i in ids])
def set_template(pages, page, t):
    if not (0 <= page < len(pages)) or t == 'AUTO': return pages
    ids = pages[page][1]; head = ids[:CAP[t]]
    out = list(pages[:page]); out.append((fit(t, len(head)), head))
    if 'drop_overflow' not in MUT:
        rest = ids[len(head):]
        for k in range(0, len(rest), MAXP):
            c = rest[k:k + MAXP]; out.append((best(len(c)), c))
    out += pages[page + 1:]
    return finish(out)
def split_page(pages, page, at):
    if not (0 <= page < len(pages)): return pages
    ids = pages[page][1]
    lim = (at < 1 or at > len(ids)) if 'split_off_by_one' in MUT else (at < 1 or at >= len(ids))
    if lim: return pages
    left, right = ids[:at], ids[at:]
    out = list(pages[:page]); out.append(((best(len(left)) if 'split_left_best' in MUT else fit(template_of(pages[page][0]), len(left))), left))
    if right: out.append((best(len(right)), right))
    out += pages[page + 1:]
    return finish(out)
def merge_next(pages, page):
    if page < 0 or page + 1 >= len(pages): return pages
    a, b = pages[page], pages[page + 1]; n = len(a[1]) + len(b[1])
    if n > MAXP and 'merge_nolimit' not in MUT: return pages
    ta = template_of(a[0])
    t = ta if (len(a[1]) > 1 and CAP[ta] >= n) else best(n)
    out = list(pages[:page]); out.append((t, a[1] + b[1])); out += pages[page + 2:]
    return finish(out)
def move_last_next(pages, page):
    if page < 0 or page + 1 >= len(pages): return pages
    a, b = pages[page], pages[page + 1]
    min_a = 1 if 'move_empty' in MUT else 2
    if len(a[1]) < min_a or len(b[1]) >= MAXP: return pages
    na, nb = a[1][:-1], [a[1][-1]] + b[1]
    out = list(pages); out[page] = (fit(template_of(a[0]), len(na)), na); out[page + 1] = (fit(template_of(b[0]), len(nb)), nb)
    return finish(out)
def move_first_prev(pages, page):
    if page < 1 or page >= len(pages): return pages
    a, b = pages[page - 1], pages[page]
    if len(b[1]) < 2 or len(a[1]) >= MAXP: return pages
    na, nb = a[1] + [b[1][0]], b[1][1:]
    out = list(pages); out[page - 1] = (fit(template_of(a[0]), len(na)), na); out[page] = (fit(template_of(b[0]), len(nb)), nb)
    return finish(out)
def eff(t, n):  # PageLayout.effectiveTemplate
    if n <= 1: return 'SPLASH'
    if t == 'GRID_2X2': return {2: 'STACK_2', 3: 'ONE_PLUS_TWO'}.get(n, 'GRID_2X2')
    if t == 'ONE_PLUS_TWO': return 'STACK_2' if n == 2 else 'ONE_PLUS_TWO'
    if t == 'AUTO': return 'STACK_2'
    return t
def cell_rows(t, n, rtl=False):
    e = eff(t, n)
    rows = {'SPLASH': [[0]], 'STACK_2': [[0], [1]], 'AUTO': [[0], [1]], 'GRID_2X2': [[0, 1], [2, 3]], 'ONE_PLUS_TWO': [[0], [1, 2]]}.get(e)
    if e == 'FOUR_KOMA': rows = [[i] for i in range(min(max(n, 2), 4))]
    if rtl and 'no_rtl' not in MUT: rows = [list(reversed(r)) for r in rows]
    return rows
def from_template(t, idxs):
    if t == 'AUTO': return None
    cap = CAP[t]
    raw = [(fit(t, len(idxs[k:k + cap])), idxs[k:k + cap]) for k in range(0, len(idxs), cap)]
    return normalize(raw, idxs)

# ---------- 3. hình học ô (bản chép PageLayout.cellsLeftToRight) để kiểm cellRows ----------
def geom_cells(t, n, w=400.0, h=600.0, g=8.0, rtl=False):
    c = (0.0, 0.0, w, h)
    def rows(k):
        rh = (h - g * (k - 1)) / k
        return [(0.0, i * (rh + g), w, i * (rh + g) + rh) for i in range(k)]
    e = eff(t, n)
    if e == 'SPLASH': r = [c]
    elif e in ('STACK_2', 'AUTO'): r = rows(2)
    elif e == 'FOUR_KOMA': r = rows(min(max(n, 2), 4))
    elif e == 'GRID_2X2':
        cw, ch = (w - g) / 2, (h - g) / 2
        r = [(0, 0, cw, ch), (cw + g, 0, w, ch), (0, ch + g, cw, h), (cw + g, ch + g, w, h)]
    else:
        cw, ch = (w - g) / 2, (h - g) / 2
        r = [(0, 0, w, ch), (0, ch + g, cw, h), (cw + g, ch + g, w, h)]
    if rtl: r = [(w - b[2], b[1], w - b[0], b[3]) for b in r]
    return r
def rows_from_geom(cells):
    by = {}
    for pos, b in enumerate(cells): by.setdefault(round(b[1], 3), []).append((b[0], pos))
    return [[p for _, p in sorted(v)] for _, v in sorted(by.items())]

# ---------- 4. kiểm cellRows == hình học thật ----------
bad = []
for t in ALL:
    for n in range(1, 5):
        for rtl in (False, True):
            if n > CAP[t] and t != 'AUTO': continue
            g = rows_from_geom(geom_cells(t, n, rtl=rtl)); cr = cell_rows(t, n, rtl)
            if g != cr: bad.append((t, n, rtl, g, cr))
check('cellRows khớp thứ tự ô hình học của PageLayout.cells cho mọi mẫu × n × rtl', not bad, str(bad[:2]))
check('mọi vị trí 0..n-1 xuất hiện đúng 1 lần trong sơ đồ (không ô thiếu/thừa)',
      all(sorted(p for r in cell_rows(t, n) for p in r if p < n) == list(range(n)) for t in ALL for n in range(1, CAP[t] + 1) if t != 'AUTO'))
check('hiện trạng đã biết: mẫu STACK_2 chỉ có 2 ô nên panel thứ 3 sẽ BỊ BỎ nếu không chặn (lý do tồn tại bất biến sức chứa)',
      len(geom_cells('STACK_2', 3)) == 2)

# ---------- 5. bất biến + fuzz ----------
def invariants(pages, order, label=''):
    flat = [i for _, ids in pages for i in ids]
    if flat != order: return f'{label}thứ tự/độ phủ sai: {flat} != {order}'
    for t, ids in pages:
        if t not in PAGE_T: return f'{label}mẫu ngoài danh sách: {t}'
        if not (1 <= len(ids) <= CAP[t]): return f'{label}trang {t} có {len(ids)} panel (sức chứa {CAP[t]})'
        if len(ids) == 1 and t != 'SPLASH': return f'{label}trang 1 panel không phải SPLASH: {t}'
        if len(geom_cells(t, len(ids))) < len(ids): return f'{label}số ô {len(geom_cells(t, len(ids)))} < số panel {len(ids)} ({t}) => mất panel trong PDF'
    return None
def garbage(rng, order):
    pages = []
    for _ in range(rng.randint(0, 7)):
        ids = [rng.choice(order + [99, -1, 1000]) for _ in range(rng.randint(0, 6))] if order else [rng.randint(0, 5)]
        pages.append((rng.choice(ALL + ['XYZ', '', 'splash']), ids))
    return pages
def op_props(op, k, p, q):
    """Tính chất RIÊNG của từng thao tác. Cần vì mỗi thao tác kết thúc bằng normalize() nên bất biến chung có thể che lỗi của thao tác."""
    if q == p: 
        if op in ('down', 'up') and 0 <= k < len(p):
            return None
        return None
    if op in ('down', 'up'):
        if len(q) != len(p): return f'{op}(k={k}): số trang đổi {len(p)}->{len(q)} (đẩy panel không được thêm/bớt trang)'
        a = k if op == 'down' else k - 1
        if op == 'down' and not (len(p[k][1]) >= 2 and q[k][1] == p[k][1][:-1] and q[k + 1][1][0] == p[k][1][-1]): return 'down: không đúng panel cuối sang đầu trang kế'
        if op == 'up' and not (len(p[k][1]) >= 2 and q[k - 1][1][-1] == p[k][1][0] and q[k][1] == p[k][1][1:]): return 'up: không đúng panel đầu sang cuối trang trước'
        if any(q[i] != p[i] for i in range(len(p)) if i not in (a, a + 1)): return f'{op}: đổi trang không liên quan'
    elif op == 'merge':
        if len(q) != len(p) - 1: return f'merge: số trang {len(p)}->{len(q)}'
        if len(p[k][1]) + len(p[k + 1][1]) > MAXP: return 'merge: vượt MAX_PER_PAGE mà vẫn gộp'
        if q[:k] != p[:k] or q[k + 1:] != p[k + 2:]: return 'merge: đổi trang không liên quan'
    elif op == 'split':
        if len(q) != len(p) + 1: return f'split: số trang {len(p)}->{len(q)}'
        if q[:k] != p[:k] or q[k + 2:] != p[k + 1:]: return 'split: đổi trang không liên quan'
        if q[k][1] + q[k + 1][1] != p[k][1]: return 'split: hai nửa không ghép lại thành trang gốc'
        if q[k][0] != fit(template_of(p[k][0]), len(q[k][1])): return 'split: nửa trái không giữ mẫu của trang gốc (khi còn vừa)'
    elif op == 'tpl':
        tail = len(p) - k - 1
        if q[:k] != p[:k] or (tail and q[len(q) - tail:] != p[k + 1:]): return 'tpl: đổi trang không liên quan'
        if len(q) < len(p): return 'tpl: số trang giảm'
    return None
def fuzz(seed=1, runs=1200):
    rng = random.Random(seed)
    for r in range(runs):
        n = rng.randint(0, 14); order = sorted(rng.sample(range(0, 40), n))
        p = normalize(garbage(rng, order), order)
        e = invariants(p, order, 'normalize: ')
        if e: return e
        if normalize(p, order) != p: return 'normalize không idempotent'
        if not order: continue
        for _ in range(25):
            op = rng.choice(['tpl', 'split', 'merge', 'down', 'up', 'tpl'])
            k = rng.randint(-1, len(p))
            if op == 'tpl': q = set_template(p, k, rng.choice(ALL))
            elif op == 'split': q = split_page(p, k, rng.randint(0, 5))
            elif op == 'merge': q = merge_next(p, k)
            elif op == 'down': q = move_last_next(p, k)
            else: q = move_first_prev(p, k)
            e = invariants(q, order, f'{op}(k={k}): ')
            if e: return e
            if op in ('down', 'up') and 0 <= k < len(p) and len(p[k][1]) < 2 and q != p: return f'{op}: trang 1 panel phải là no-op'
            if op == 'merge' and 0 <= k < len(p) - 1 and len(p[k][1]) + len(p[k + 1][1]) > MAXP and q != p: return 'merge quá MAX phải là no-op'
            e = op_props(op, k, p, q)
            if e: return e
            if normalize(q, order) != q: return f'{op}: kết quả chưa ở dạng chuẩn hoá'
            p = q
    return None
res = fuzz()
check('FUZZ 1200 bố cục rác × 25 thao tác: bảo toàn thứ tự + độ phủ + sức chứa + số ô >= số panel', res is None, str(res))
# chuẩn hoá sau khi chương đổi: xoá/thêm panel
p0 = from_template('GRID_2X2', list(range(8)))
p1 = normalize(p0, [0, 1, 2, 4, 5, 6, 7, 8, 9])   # xoá 3, thêm 8, 9
check('chương đổi (xoá panel 3, thêm 8 và 9): mọi panel đúng 1 lần theo thứ tự, không panel ma',
      invariants(p1, [0, 1, 2, 4, 5, 6, 7, 8, 9]) is None and [i for _, ids in p1 for i in ids] == [0, 1, 2, 4, 5, 6, 7, 8, 9])
check('chuẩn hoá rỗng: không panel nào dùng được => không trang nào', normalize([('STACK_2', [1, 2])], []) == [])
check('chỉ số trùng lặp trong dữ liệu hỏng chỉ giữ lần đầu', normalize([('STACK_2', [3, 3]), ('SPLASH', [3, 4])], [3, 4]) == [('STACK_2', [3, 4])] or
      sorted(i for _, ids in normalize([('STACK_2', [3, 3]), ('SPLASH', [3, 4])], [3, 4]) for i in ids) == [3, 4])
check('mẫu AUTO / lạ trong dữ liệu cũ -> STACK_2 (không bao giờ AUTO ở mức trang)',
      [t for t, _ in normalize([('AUTO', [0, 1]), ('XYZ', [2, 3])], [0, 1, 2, 3])] == ['STACK_2', 'STACK_2'])

# ---------- thao tác: ca cụ thể ----------
base = [('GRID_2X2', [0, 1, 2, 3]), ('STACK_2', [4, 5]), ('SPLASH', [6])]
check('setTemplate SPLASH trên trang 2 panel: panel thừa sang trang MỚI, không mất', set_template(base, 1, 'SPLASH')[1:3] == [('SPLASH', [4]), ('SPLASH', [5])])
check('setTemplate AUTO / chỉ số sai -> trả nguyên bản', set_template(base, 0, 'AUTO') == base and set_template(base, 9, 'STACK_2') == base)
check('setTemplate STACK_2 trên trang 4 panel: 2 panel đầu giữ, 2 panel sau thành trang mới', set_template(base, 0, 'STACK_2')[:2] == [('STACK_2', [0, 1]), ('STACK_2', [2, 3])])
check('splitPage đúng chỗ và từ chối ngoài biên', split_page(base, 0, 1)[:2] == [('SPLASH', [0]), ('ONE_PLUS_TWO', [1, 2, 3])] and
      split_page(base, 0, 0) == base and split_page(base, 0, 4) == base)
check('mergeWithNext: 4+2 > 4 bị từ chối; 2+1 gộp thành 1 rộng + 2 dưới', merge_next(base, 0) == base and merge_next(base, 1)[1] == ('ONE_PLUS_TWO', [4, 5, 6]))
check('moveLastToNext: từ chối khi trang chỉ còn 1 panel hoặc trang kế đã đủ 4', move_last_next(base, 2) == base and move_last_next([('STACK_2', [0, 1]), ('GRID_2X2', [2, 3, 4, 5])], 0) == [('STACK_2', [0, 1]), ('GRID_2X2', [2, 3, 4, 5])])
mv = move_last_next(base, 1)
check('moveLastToNext: panel 5 sang đầu trang 3 và mẫu trang 3 được nâng (SPLASH -> STACK_2)', mv[1] == ('SPLASH', [4]) and mv[2] == ('STACK_2', [5, 6]))
mu = move_first_prev(base, 1)
check('moveFirstToPrev: từ chối khi trang trước đã đủ 4; ca hợp lệ giữ thứ tự', mu == base and move_first_prev([('STACK_2', [0, 1]), ('STACK_2', [2, 3])], 1) == [('ONE_PLUS_TWO', [0, 1, 2]), ('SPLASH', [3])])
check('fromTemplate chia đúng sức chứa; trang cuối 2 panel GIỮ lựa chọn 2x2 nhưng vẽ như 2 dọc (hành vi cũ chunked(panelsPerPage) không đổi)',
      from_template('GRID_2X2', list(range(10))) == [('GRID_2X2', [0, 1, 2, 3]), ('GRID_2X2', [4, 5, 6, 7]), ('GRID_2X2', [8, 9])]
      and eff('GRID_2X2', 2) == 'STACK_2')

# ---------- 6. kiểm tĩnh nguồn Kotlin: chuỗi điều kiện quan trọng + nối dây ----------
for name, pat in [
    ('normalize: lọc chỉ số không tồn tại VÀ trùng bằng seen.add', r'pg\.panelIndexes\.filter \{ it in valid && seen\.add\(it\) \}'),
    ('normalize: phần thừa vượt sức chứa thành trang mới (không mất panel)', r'while \(rest > 0\)'),
    ('normalize: panel chưa có trong bố cục được nối vào cuối', r'order\.filter \{ it !in seen \}'),
    ('normalize: gán lại theo thứ tự đọc gốc', r'order\.subList\(pos, pos \+ n\)'),
    ('fit(): thiếu chỗ thì chọn mẫu tốt nhất', r'capacity\(tt\) >= n -> tt'),
    ('setTemplate: panel thừa thành trang mới', r'ids\.drop\(head\.size\)\.chunked\(MAX_PER_PAGE\)'),
    ('mergeWithNext: chặn quá MAX_PER_PAGE', r'if \(n > MAX_PER_PAGE\) return pages'),
    ('moveLastToNext: chặn khi trang chỉ còn 1 panel', r'a\.panelIndexes\.size < 2 \|\| b\.panelIndexes\.size >= MAX_PER_PAGE'),
    ('moveFirstToPrev: chặn khi trang chỉ còn 1 panel', r'b\.panelIndexes\.size < 2 \|\| a\.panelIndexes\.size >= MAX_PER_PAGE'),
    ('splitPage: chặn biên', r'at < 1 \|\| at >= ids\.size'),
    ('resolve: Panel.index trùng -> rơi về AUTO', r'idx\.size != idx\.toSet\(\)\.size\) return PageLayoutPlanner\.planPanels\(ok\)'),
    ('cellRows: rtl lật từng hàng', r'if \(rtl\) rows\.map \{ it\.reversed\(\) \} else rows'),
]:
    check('Kotlin: ' + name, re.search(pat, ED) is not None)
check('Kotlin: cellRows dùng effectiveTemplate (khớp cách PageLayout.cells chọn ô)', 'when (PageLayout.effectiveTemplate(t, n))' in ED)
whens = re.findall(r'PageTemplate\.(\w+) ->', ED[ED.index('fun cellRows('):])
check('Kotlin: cellRows có ĐỦ 6 nhánh enum', set(whens) == set(ALL), str(whens))
check('Model: Chapter.pageLayout là List<PageSpec>? = null (NULLABLE vì Gson không áp mặc định Kotlin khi đọc chapter.json cũ)', 'val pageLayout: List<PageSpec>? = null' in MODELS)
check('Model: PageSpec(template: String, panelIndexes: List<Int>)', 'data class PageSpec(val template: String, val panelIndexes: List<Int>)' in MODELS)
check('Xuất PDF: exportPdf nhận pageLayout và dùng PageLayoutEditor.resolve TRƯỚC nhánh AUTO',
      'pageLayout: List<PageSpec>? = null' in PUB and PUB.index('PageLayoutEditor.resolve(pageLayout, ok)') < PUB.index('PageLayoutPlanner.planPanels(ok)'))
check('Xuất PDF: private fun usable dùng chung PageLayoutEditor.usable (chỉ số panel khớp màn sửa)', 'private fun usable(panels: List<Panel>) = PageLayoutEditor.usable(panels)' in PUB)
check('Pipeline: bố cục tuỳ chỉnh luôn đi đường PublishExporter và truyền chapter.pageLayout',
      'extras.usesCustomPdf || chapter.pageLayout != null' in PIPE and 'extras.rightToLeft,\n                    chapter.pageLayout)' in PIPE)
check('ViewModel: updatePageLayout lưu chapter.json', re.search(r'fun updatePageLayout\(pages: List<com\.mangalocal\.model\.PageSpec>\?\) \{.*?storyManager\.saveChapter\(updated\)', VM, re.S) is not None)
check('Điều hướng: route page_layout + nút mở từ màn Hội thoại & Xuất file', 'composable("page_layout")' in MAIN and 'nav.navigate("page_layout")' in PP)
check('Màn hình: dùng đủ 5 thao tác của PageLayoutEditor', all(f'PageLayoutEditor.{f}(' in SCR for f in ['setTemplate', 'splitPage', 'mergeWithNext', 'moveLastToNext', 'moveFirstToPrev', 'fromAuto', 'fromTemplate', 'currentOrBase', 'cellRows']))
check('Màn hình: HelpDot("pageLayoutEditor") có mục trợ giúp tương ứng', 'HelpDot("pageLayoutEditor")' in SCR and '"pageLayoutEditor" to e(' in HELP)
check('Màn hình: không dùng Switch( trần và không đặt tên hàm cục bộ là apply (che hàm chuẩn)', not re.search(r'(?<![A-Za-z])Switch\(', SCR) and 'fun apply(' not in SCR)
for nm, src in [('PageLayoutEditor.kt', ED), ('PageLayoutScreen.kt', SCR), ('PublishExporter.kt', PUB)]:
    check(f'{nm}: ngoặc {{}} () [] cân bằng', all(src.count(a) == src.count(b) for a, b in ['{}', '()', '[]']))
# mọi symbol Kotlin mà màn hình gọi có thật
for sym, where in [('fun templateOf', ED), ('fun usable', ED), ('val PAGE_TEMPLATES', ED), ('fun MlOutlineBtn', rd('ui/Components.kt')), ('fun MlCard', rd('ui/Components.kt')), ('fun MlLabel', rd('ui/Components.kt')), ('fun HelpDot', HELP)]:
    check(f'tồn tại: {sym}', sym in where)
check('icon dùng ở màn hình đều đã được dùng ở nơi khác (không đoán icon)',
      all(any(('Icons.Default.' + ic) in rd('ui/' + f) for f in sorted(os.listdir(J + 'ui')) if f.endswith('.kt') and f != 'PageLayoutScreen.kt')
          for ic in set(re.findall(r'Icons\.Default\.(\w+)', SCR))))

# ---------- 7. THỬ PHÁ MÃ (đột biến trên bản chép: kiểm bộ test có đủ sắc để bắt lỗi) ----------
caught = 0; muts = ['no_dedupe', 'no_missing', 'drop_overflow', 'fit_nocap', 'split_left_best', 'merge_nolimit', 'move_empty', 'no_rtl']
def mutant_detected(m):
    MUT.clear(); MUT.add(m)
    try:
        if fuzz(seed=7, runs=300) is not None: return True
        if m == 'no_rtl': return cell_rows('GRID_2X2', 4, True) != rows_from_geom(geom_cells('GRID_2X2', 4, rtl=True))
        if m == 'merge_nolimit': return merge_next(base, 0) != base
        if m == 'move_empty': return move_last_next(base, 2) != base
        return False
    finally: MUT.clear()
for m in muts:
    d = mutant_detected(m); caught += d
    check(f'đột biến "{m}" bị bắt', d)
check(f'bắt đủ {len(muts)}/{len(muts)} đột biến', caught == len(muts), f'{caught}')
MUT.clear(); MUT.add('split_off_by_one')
eqv = all(split_page(base, k, len(base[k][1])) == base for k in range(len(base))) and fuzz(seed=7, runs=300) is None
MUT.clear()
check('đột biến "split_off_by_one" là TƯƠNG ĐƯƠNG (nửa phải rỗng bị normalize bỏ nên kết quả y hệt) — ghi nhận, không tính là lỗ hổng', eqv)

print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
