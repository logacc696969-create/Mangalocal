#!/usr/bin/env python3
"""mục 257 — kiểm thử HỆ THỐNG TRỢ GIÚP THÔNG SỐ (dấu "?" + popup) ở Cài đặt.

Không có kotlinc ở sandbox nên đây là kiểm tra TĨNH trên mã Kotlin thật (không phải biên dịch). Chứng minh:
  1. Mọi công tắc/thanh trượt trong SettingsScreen.kt đều có dấu "?" (không còn Switch(/Slider( trần).
  2. Mọi khoá được gọi ở UI đều có mục trong ParamHelp.kt và ngược lại (không mục mồ côi).
  3. Mỗi mục đủ 4 phần + mặc định, không chứa ký tự làm hỏng chuỗi Kotlin (dấu nháy kép, đô-la, gạch chéo ngược).
  4. "Mặc định" trong popup KHỚP giá trị trong Models.kt (chống lệch tài liệu <-> mã).
  5. Giá trị mặc định của các thông số MỚI nằm trong khoảng thanh trượt; hai thanh min/max tỉ lệ không thể đảo thứ tự.
  6. Cấu trúc Compose: LabelWithHelp chỉ dùng trong Row (là hàm của RowScope), HelpSwitch nhận đúng các tham số mà chỗ gọi truyền.
KHÔNG chứng minh: giao diện hiển thị đẹp, popup mở được trên máy — chỉ build + thử tay mới cho biết.
"""
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UI = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/ui/')
HELP = open(UI + 'ParamHelp.kt', encoding='utf-8').read()
SET = open(UI + 'SettingsScreen.kt', encoding='utf-8').read()
ALLUI = ''.join(open(UI + f, encoding='utf-8').read() + '\n' for f in sorted(os.listdir(UI)) if f.endswith('.kt') and f != 'ParamHelp.kt')
MODELS = open(os.path.join(ROOT, 'app/src/main/java/com/mangalocal/model/Models.kt'), encoding='utf-8').read().split('\n')

ok = True
def check(name, cond, detail=''):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + detail) if (detail and not cond) else ''))
    ok &= bool(cond)

# ---------- phân tích ParamHelp.kt ----------
ENTRIES = {}
for m in re.finditer(r'"([\w.]+)" to e\(\s*((?:"[^"]*"\s*,?\s*)+)\)', HELP):
    parts = re.findall(r'"([^"]*)"', m.group(2))
    ENTRIES[m.group(1)] = parts
n_decl = len(re.findall(r'" to e\(', HELP))
check('phân tích được mọi mục (số mục regex == số khai báo `to e(`)', len(ENTRIES) == n_decl and n_decl >= 70, f'{len(ENTRIES)} vs {n_decl}')
check('khoá trùng lặp: không có', len(re.findall(r'"([\w.]+)" to e\(', HELP)) == len(set(re.findall(r'"([\w.]+)" to e\(', HELP))))
bad4 = [k for k, p in ENTRIES.items() if len(p) < 5 or any(not x.strip() for x in p[:5])]
check('mỗi mục đủ title/what/effect/howTo/default không rỗng', not bad4, str(bad4[:5]))
# ký tự cấm nằm trong nội dung: regex trên đã dùng [^"]* nên nháy kép bên trong sẽ làm vỡ phân tích; kiểm đô-la và gạch chéo ngược
body = HELP[HELP.index('val entries'):HELP.index('/** Nút tròn')]
check('nội dung không chứa $ hay gạch chéo ngược (tránh chuỗi mẫu Kotlin)', '$' not in body and '\\' not in body)
check('mỗi mục có tối đa 6 chuỗi (note tuỳ chọn)', all(5 <= len(p) <= 6 for p in ENTRIES.values()))

# ---------- khoá dùng ở UI ----------
used = set()
used |= set(re.findall(r'HelpSwitch\(helpKey = "([\w.]+)"', ALLUI))
used |= set(re.findall(r'helpKey = "([\w.]+)"\)? ?\{', ALLUI))               # SlRow(... helpKey = "x") {
used |= set(re.findall(r'LabelWithHelp\((?:"(?:[^"\\]|\\.)*"|[^,]+), "([\w.]+)"\)', ALLUI))
used |= set(re.findall(r'HelpSlider\((?:"(?:[^"\\]|\\.)*"), "([\w.]+)"', ALLUI))
used |= set(re.findall(r'HelpDot\("([\w.]+)"\)', ALLUI))
check('có ít nhất 85 khoá trợ giúp được dùng ở UI (Cài đặt + các màn hình khác)', len(used) >= 85, str(len(used)))
missing = sorted(used - set(ENTRIES))
check('mọi khoá dùng ở UI đều có mục trợ giúp (không có dấu ? câm)', not missing, str(missing))
orphan = sorted(set(ENTRIES) - used)
check('mọi mục trợ giúp đều được dùng ở UI (không mục mồ côi)', not orphan, str(orphan))

# ---------- phủ kín: không còn Switch/Slider trần ----------
bare_sw = [(f, i + 1) for f in sorted(os.listdir(UI)) if f.endswith('.kt') and f != 'ParamHelp.kt' for i, l in enumerate(open(UI + f, encoding='utf-8').read().split('\n')) if re.search(r'(?<![A-Za-z])Switch\(', l)]
check('không còn `Switch(` trần ở MỌI màn hình (Cài đặt 42 + bubble, khớp xương, từ điển đều là HelpSwitch)', not bare_sw and len(re.findall(r'\bHelpSwitch\(', ALLUI)) >= 45, str(bare_sw))
n_sl = len(re.findall(r'\bSlider\(', SET))
n_lab = len(re.findall(r'LabelWithHelp\(', SET))
n_dot_slider = 1  # addonLora.weight dùng HelpDot cạnh dòng weight
n_slrow_inner = 1  # Slider bên trong hàm SlRow
check('mọi Slider( trong Cài đặt đều có dấu ? (LabelWithHelp/HelpDot; SlRow có helpKey)',
      n_sl == (n_lab - 1) + n_dot_slider + n_slrow_inner, f'Slider={n_sl} LabelWithHelp={n_lab}')  # -1: LabelWithHelp trong SlRow dùng chung cho 3 chỗ gọi
check('3 chỗ gọi SlRow đều truyền helpKey (steps, cfgScale, nThreads)', all(('helpKey = "%s"' % k) in SET for k in ['steps', 'cfgScale', 'nThreads']))

# ---------- cấu trúc Compose ----------
LINES_BY_FILE = {f: open(UI + f, encoding='utf-8').read().split('\n') for f in sorted(os.listdir(UI)) if f.endswith('.kt') and f != 'ParamHelp.kt'}
def enclosing_block_head(lines, idx):
    ind = len(lines[idx]) - len(lines[idx].lstrip())
    for j in range(idx - 1, -1, -1):
        t = lines[j]
        if not t.strip() or t.strip().startswith('//'): continue
        jind = len(t) - len(t.lstrip())
        if jind < ind: return t.strip()
    return ''
bad_ctx = []
for fname, lines in LINES_BY_FILE.items():
    for i, l in enumerate(lines):
        if 'LabelWithHelp(' in l and 'fun ' not in l:
            head = enclosing_block_head(lines, i)
            if not (head.startswith('Row(') or head.startswith('if (helpKey')):
                bad_ctx.append((fname, i + 1, head[:60]))
check('LabelWithHelp chỉ xuất hiện trực tiếp trong một Row (vì là hàm của RowScope)', not bad_ctx, str(bad_ctx[:4]))
check('LabelWithHelp khai báo là RowScope.LabelWithHelp và nhóm nhãn dùng weight(1f, fill = false)',
      'fun RowScope.LabelWithHelp(' in HELP and 'Modifier.weight(1f, fill = false)' in HELP)
params = set()
for m in re.finditer(r'HelpSwitch\(', ALLUI):
    i = m.end(); d = 1; j = i
    while d and j < len(ALLUI):
        d += (ALLUI[j] == '(') - (ALLUI[j] == ')'); j += 1
    body = ALLUI[i:j - 1]; dd = 0; cur = ''; ps = []
    for ch in body:
        if ch in '([{': dd += 1
        elif ch in ')]}': dd -= 1
        if ch == ',' and dd == 0: ps.append(cur); cur = ''
        else: cur += ch
    ps.append(cur)
    for p in ps:
        mm = re.match(r'\s*(\w+)\s*=', p)
        params.add(mm.group(1) if mm else '(vị trí)')
sig = re.search(r'fun HelpSwitch\((.*?)\)\s*\{', HELP, re.S).group(1)
declared = set(re.findall(r'(\w+)\s*:', sig))
check('các tham số mà chỗ gọi HelpSwitch truyền đều được khai báo', params <= declared, f'{params - declared}')
check('khung Compose: ngoặc {} () cân bằng trong ParamHelp.kt', HELP.count('{') == HELP.count('}') and HELP.count('(') == HELP.count(')'),
      f'{{{HELP.count("{")}/{HELP.count("}")} (({HELP.count("(")}/{HELP.count(")")}')
check('AlertDialog có nút đóng + cuộn được (nội dung dài không tràn màn hình nhỏ)', 'confirmButton' in HELP and 'verticalScroll(rememberScrollState())' in HELP)
check('HelpDot không crash khi thiếu mục (trả về không vẽ gì)', 'val entry = ParamHelp.entries[key]' in HELP and 'if (entry != null)' in HELP)

# ---------- các màn hình ngoài Cài đặt ----------
def rd(f): return open(UI + f, encoding='utf-8').read()
OUT = {'CharactersScreen.kt': ['boneTorso', 'boneUpperArm', 'boneForearm', 'boneUpperLeg', 'boneLowerLeg', 'boneHeadSize'],
       'ExpressionStudioScreen.kt': ['expressionIntensity'], 'GalleryReviewScreen.kt': ['panelSize', 'steps', 'cfgScale'],
       'PoseEditorScreen.kt': ['keypointVisible'], 'StoryScreens.kt': ['conceptDictionaryEnabled'], 'PostProcessingScreen.kt': ['bubbleTail', 'bubbleFont', 'bubbleFontScale']}
for f, keys in OUT.items():
    src = rd(f)
    miss = [k for k in keys if ('"' + k + '"') not in src]
    check(f'{f}: có dấu ? cho ' + ', '.join(keys), not miss, str(miss))
check('BoneRatioSlider nhận helpKey và dùng LabelWithHelp khi có', 'helpKey: String? = null, onValueChange' in rd('CharactersScreen.kt') and 'if (helpKey != null) LabelWithHelp(label, helpKey)' in rd('CharactersScreen.kt'))
check('mọi Slider( ở màn hình ngoài Cài đặt đều nằm cạnh một dấu ? (Gallery 4, Characters 1, Expression 1)',
      rd('GalleryReviewScreen.kt').count('HelpDot(') >= 3 and rd('ExpressionStudioScreen.kt').count('HelpDot(') >= 1)

# ---------- mặc định trong popup == Models.kt ----------
start = next(i for i, l in enumerate(MODELS) if 'data class GenerationSettings' in l)
FIELDS = {}
for i in range(start + 1, len(MODELS)):
    l = MODELS[i]
    if l.startswith(')'): break
    m = re.match(r'\s*val (\w+)\s*:\s*([\w<>?, ]+?)\s*=\s*([^,/]+?)\s*,?\s*(//.*)?$', l)
    if m: FIELDS[m.group(1)] = m.group(3).strip()
def num(s):
    m = re.search(r'-?\d+(?:\.\d+)?', s)
    return float(m.group(0)) if m else None
mism = []; checked = 0
for key, p in ENTRIES.items():
    if key not in FIELDS: continue
    d = p[4]; v = FIELDS[key]; checked += 1
    if v in ('true', 'false'):
        if d != ('Bật' if v == 'true' else 'Tắt'): mism.append((key, d, v))
        continue
    if v.startswith('ImageModelTier.'):  # enum: công tắc SDXL tắt <=> mặc định SD15
        if not (v == 'ImageModelTier.SD15' and d.startswith('Tắt')): mism.append((key, d, v))
        continue
    if v.startswith('"'):  # trường chuỗi: mặc định rỗng <=> popup ghi "Trống"
        if not (v == '""' and d.startswith('Trống')): mism.append((key, d, v))
        continue
    mv = float(v.rstrip('fL').replace('_', ''))
    nd = num(d)
    if nd is None: mism.append((key, d, v)); continue
    if '%' in d: nd /= 100.0
    if 'giây' in d: nd *= 1000.0
    if abs(nd - mv) > 1e-6: mism.append((key, d, v))
check(f'"Mặc định" trong popup khớp Models.kt ({checked} thông số là field Settings)', not mism and checked >= 55, str(mism[:5]))

# ---------- thông số mới: nằm trong khoảng thanh trượt ----------
RANGES = {}
for m in re.finditer(r'HelpSlider\("[^"]*", "(\w+)", [^\n]*\n\s*settings\.\w+(?:\.toFloat\(\))?, ([\d.]+)f\.\.([\d.]+)f', SET):
    RANGES[m.group(1)] = (float(m.group(2)), float(m.group(3)))
NEW = ['verifyMaxPoseError', 'verifyMaxScaleSpread', 'verifySingleScaleMin', 'verifySingleScaleMax', 'verifyExtraPersonsAllowed', 'contactSensitivity', 'scaleConsistencyThreshold']
check('đủ 7 thanh trượt mới với khoảng giá trị đọc được', all(k in RANGES for k in NEW), str([k for k in NEW if k not in RANGES]))
for k in NEW:
    if k not in RANGES: continue
    lo, hi = RANGES[k]; dv = float(FIELDS[k].rstrip('fL'))
    check(f'{k}: mặc định {dv} nằm trong thanh trượt [{lo}, {hi}]', lo <= dv <= hi)
check('không thể đảo thứ tự: tối thiểu tỉ lệ ≤ 1.0 ≤ tối đa tỉ lệ ở cả mặc định lẫn đầu mút thanh trượt',
      RANGES['verifySingleScaleMin'][1] <= RANGES['verifySingleScaleMax'][0] and float(FIELDS['verifySingleScaleMin'].rstrip('f')) < float(FIELDS['verifySingleScaleMax'].rstrip('f')))
check('độ nhạy điểm chạm: thanh trượt khớp khoảng kẹp [0.5, 1.5] của ContactDetector', RANGES['contactSensitivity'] == (0.5, 1.5))
check('verifyExtraPersonsAllowed được kẹp [0,3] khi ghi', 'copy(verifyExtraPersonsAllowed = it.toInt().coerceIn(0, 3))' in SET)
PIPE = open(os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline/MangaPipeline.kt'), encoding='utf-8').read()
check('nối dây: ngưỡng tỉ lệ vật thể truyền từ Cài đặt vào ScaleConsistencyChecker.check',
      'settings.scaleConsistencyThreshold' in PIPE and 'ScaleConsistencyChecker.check(entries, threshold)' in PIPE)

print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
