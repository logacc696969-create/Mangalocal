package androidx.core.content
object ContextCompat { fun startForegroundService(c: android.content.Context, i: android.content.Intent) {} }
