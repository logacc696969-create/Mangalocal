package androidx.lifecycle
open class ViewModel { protected open fun onCleared() {} }
open class AndroidViewModel(private val app: android.app.Application) : ViewModel() {
    @Suppress("UNCHECKED_CAST") fun <T : android.app.Application> getApplication(): T = app as T
}
val ViewModel.viewModelScope: kotlinx.coroutines.CoroutineScope get() = kotlinx.coroutines.MainScope()
