package androidx.core.app
class NotificationCompat {
    companion object { const val PRIORITY_LOW = -1; const val PRIORITY_DEFAULT = 0; const val CATEGORY_PROGRESS = "progress"; const val CATEGORY_SERVICE = "service"; const val FOREGROUND_SERVICE_IMMEDIATE = 1 }
    class Builder(c: android.content.Context, channel: String) {
        fun setContentTitle(s: CharSequence?): Builder = this
        fun setContentText(s: CharSequence?): Builder = this
        fun setSmallIcon(i: Int): Builder = this
        fun setOngoing(b: Boolean): Builder = this
        fun setOnlyAlertOnce(b: Boolean): Builder = this
        fun setProgress(max: Int, p: Int, ind: Boolean): Builder = this
        fun setContentIntent(p: android.app.PendingIntent?): Builder = this
        fun setPriority(p: Int): Builder = this
        fun setCategory(s: String?): Builder = this
        fun setSilent(b: Boolean): Builder = this
        fun addAction(i: Int, t: CharSequence?, p: android.app.PendingIntent?): Builder = this
        fun setForegroundServiceBehavior(i: Int): Builder = this
        fun build(): android.app.Notification = android.app.Notification()
    }
}
