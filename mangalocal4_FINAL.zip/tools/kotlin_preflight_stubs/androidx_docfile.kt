package androidx.documentfile.provider
class DocumentFile private constructor() {
    companion object {
        fun fromTreeUri(c: android.content.Context, u: android.net.Uri): DocumentFile? = null
        fun fromSingleUri(c: android.content.Context, u: android.net.Uri): DocumentFile? = null
        fun fromFile(f: java.io.File): DocumentFile = DocumentFile()
    }
    val uri: android.net.Uri get() = android.net.Uri.EMPTY
    val name: String? get() = null
    val isDirectory: Boolean get() = false
    val isFile: Boolean get() = false
    fun exists(): Boolean = false
    fun listFiles(): Array<DocumentFile> = emptyArray()
    fun findFile(n: String): DocumentFile? = null
    fun createFile(mime: String, name: String): DocumentFile? = null
    fun createDirectory(name: String): DocumentFile? = null
    fun delete(): Boolean = false
    fun canWrite(): Boolean = false
    fun canRead(): Boolean = false
    fun renameTo(n: String): Boolean = false
    fun length(): Long = 0
}
