package com.mangalocal
class MainActivity : android.app.Activity()
