package kotlinx.coroutines.flow
// coroutines 1.5.0 (đi kèm kotlinc) thiếu các hàm này; bản 1.7.3 của dự án có.
inline fun <T> MutableStateFlow<T>.update(function: (T) -> T) { while (true) { val prev = value; val next = function(prev); if (compareAndSet(prev, next)) return } }
inline fun <T> MutableStateFlow<T>.updateAndGet(function: (T) -> T): T { while (true) { val prev = value; val next = function(prev); if (compareAndSet(prev, next)) return next } }
inline fun <T> MutableStateFlow<T>.getAndUpdate(function: (T) -> T): T { while (true) { val prev = value; val next = function(prev); if (compareAndSet(prev, next)) return prev } }
