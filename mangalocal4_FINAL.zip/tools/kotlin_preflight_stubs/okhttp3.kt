package okhttp3
import java.util.concurrent.TimeUnit
class MediaType private constructor() {
    companion object { fun String.toMediaType(): MediaType = MediaType(); fun String.toMediaTypeOrNull(): MediaType? = MediaType() }
}
abstract class RequestBody {
    companion object {
        fun String.toRequestBody(contentType: MediaType? = null): RequestBody = object : RequestBody() {}
        fun ByteArray.toRequestBody(contentType: MediaType? = null, offset: Int = 0, byteCount: Int = size): RequestBody = object : RequestBody() {}
    }
}
class Headers { operator fun get(name: String): String? = null; fun names(): Set<String> = emptySet() }
abstract class ResponseBody : java.io.Closeable {
    abstract fun string(): String
    abstract fun bytes(): ByteArray
    abstract fun byteStream(): java.io.InputStream
    abstract fun contentLength(): Long
    fun contentType(): MediaType? = null
}
class Response : java.io.Closeable {
    val code: Int = 0
    val message: String = ""
    val isSuccessful: Boolean = false
    val headers: Headers = Headers()
    val body: ResponseBody? = null
    fun header(name: String, defaultValue: String? = null): String? = null
    override fun close() {}
}
class Request private constructor() {
    class Builder {
        fun url(u: String): Builder = this
        fun header(n: String, v: String): Builder = this
        fun addHeader(n: String, v: String): Builder = this
        fun post(b: RequestBody): Builder = this
        fun get(): Builder = this
        fun build(): Request = Request()
    }
    fun newBuilder(): Builder = Builder()
}
interface Call { fun execute(): Response; fun cancel(); fun isCanceled(): Boolean }
fun interface Interceptor { fun intercept(chain: Chain): Response; interface Chain { fun request(): Request; fun proceed(request: Request): Response } }
class CertificatePinner { class Builder { fun add(host: String, vararg pins: String): Builder = this; fun build(): CertificatePinner = CertificatePinner() } }
class OkHttpClient {
    fun newCall(r: Request): Call = object : Call { override fun execute() = Response(); override fun cancel() {}; override fun isCanceled() = false }
    fun newBuilder(): Builder = Builder()
    class Builder {
        fun connectTimeout(t: Long, u: TimeUnit): Builder = this
        fun readTimeout(t: Long, u: TimeUnit): Builder = this
        fun writeTimeout(t: Long, u: TimeUnit): Builder = this
        fun callTimeout(t: Long, u: TimeUnit): Builder = this
        fun retryOnConnectionFailure(b: Boolean): Builder = this
        fun certificatePinner(p: CertificatePinner): Builder = this
        fun followRedirects(b: Boolean): Builder = this
        fun addInterceptor(i: Interceptor): Builder = this
        fun addNetworkInterceptor(i: Interceptor): Builder = this
        fun build(): OkHttpClient = OkHttpClient()
    }
}
