#!/usr/bin/env python3
"""mục 265 — kiểm thử THỰC NGHIỆM công cụ gắn nhánh LoRA vào đồ thị MNN (tools/mnn_probe/lora_attach_branch.cpp) trên MNN thật.
Đây là bước (a) của mục 264.3. Mô hình đồ chơi có đủ các tình huống khó của UNet (xem lora_attach_check.cpp): conv dùng hai nơi (residual), conv 3x3 có relu gộp,
conv là đầu ra mạng. Tham chiếu là TÍNH BẰNG CPU THUẦN (độc lập với MNN), không phải MNN-so-với-MNN.
Kiểm:
  (1) nhánh gắn bằng công cụ cho đầu ra BẰNG bản gộp trọng số (CPU thuần) — conv 1x1 VÀ conv 3x3, đủ cả ba cấu hình shapeMutable x (không base);
  (2) Module::Config::base + rearrange=true chia sẻ trọng số nền QUA các op đã chèn (khớp theo TÊN op nên chèn giữa đồ thị vẫn đúng): file LoRA có trọng số nền = 0 mà kết quả vẫn đúng;
  (3) KHÔNG có base thì file LoRA dùng trọng số 0 của chính nó -> sai (đối chứng); rearrange=false -> không chia sẻ -> sai (đối chứng — bẫy đã ghi ở mục 264);
  (4) tên đầu ra mạng giữ nguyên, mọi chỗ dùng đầu ra conv gốc được đổi (c0 có hai chỗ dùng);
  (5) từ chối đúng cho đầu vào không hợp lệ (conv relu gộp mà không --unfuse-activation, tên không tồn tại, kích thước A/B sai, trùng dòng, gắn hai lần);
  (6) --strip-base-weights: file nhỏ hơn hẳn và vẫn chạy đúng khi có base + rearrange=true;
  (7) PHÁT HIỆN (đo ở mục 265): với Module::Config::base execution nền được nhân bản kèm hoạt hoá gộp (relu) của conv NỀN. File LoRA đã tách relu ra khỏi conv nhưng
      module nền gốc vẫn có relu gộp -> sai; nạp module nền từ đồ thị nền đã tách relu (--emit-base) thì đúng. Test canh cả hai chiều.
KHÔNG chứng minh: UNet thật (tên op thật, Linear có thành Convolution 1x1 hay MatMul), trọng số w8, backend OpenCL/NPU, tốc độ rearrange với conv 3x3.
Không có bản build MNN -> BỎ QUA (exit 0), giống test_mnn_lora_split.py.
"""
import os, re, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.environ.get('MNN_SRC', '/home/claude/work/tp/MNN'); LIB = os.environ.get('MNN_LIB', '/home/claude/work/mnnbuild/libMNN.a')
if not (os.path.isdir(os.path.join(SRC, 'include')) and os.path.isfile(LIB)):
    print('SKIP: không có bản build MNN (đặt MNN_SRC và MNN_LIB, xem tools/mnn_probe/README.md)'); sys.exit(0)
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + d) if (d and not c) else '')); ok &= bool(c)
tmp = tempfile.mkdtemp()
INC = ['-I', os.path.join(SRC, 'include'), '-I', os.path.join(SRC, 'schema/current'), '-I', os.path.join(SRC, '3rd_party/flatbuffers/include')]
LINK = ['-Wl,--whole-archive', LIB, '-Wl,--no-whole-archive', '-lpthread', '-ldl']
def build(src, exe):
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-w', os.path.join(ROOT, 'tools/mnn_probe', src)] + INC + LINK + ['-o', os.path.join(tmp, exe)], capture_output=True, text=True)
    return r.returncode == 0, r.stderr[-800:]
b1, e1 = build('lora_attach_check.cpp', 'check'); check('lora_attach_check.cpp biên dịch với MNN thật', b1, e1)
b2, e2 = build('lora_attach_branch.cpp', 'attach'); check('lora_attach_branch.cpp biên dịch với MNN thật (schema + flatbuffers)', b2, e2)
if not (b1 and b2):
    print('CÓ LỖI'); sys.exit(1)
CHECK, ATTACH = os.path.join(tmp, 'check'), os.path.join(tmp, 'attach')
def sh(args, timeout=120):
    r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, cwd=tmp)
    return r.returncode, r.stdout, r.stderr
rc, out, err = sh([CHECK, 'gen', tmp]); check('sinh mô hình đồ chơi + tham chiếu CPU', rc == 0 and 'gen ok' in out, err)
def attach(spec, outp, *flags):   # flags có thể chứa đường dẫn (sau --emit-base)
    return sh([ATTACH, os.path.join(tmp, 'base.mnn'), os.path.join(tmp, spec), os.path.join(tmp, outp)] + list(flags))
def attach_on(basef, spec, outp, *flags):
    return sh([ATTACH, os.path.join(tmp, basef), os.path.join(tmp, spec), os.path.join(tmp, outp)] + list(flags))
def diff(lora, ref, sm, ra, base='-'):
    rc, out, err = sh([CHECK, 'run', os.path.join(tmp, lora), os.path.join(tmp, 'x.bin'), os.path.join(tmp, ref), str(sm), str(ra),
                       base if base == '-' else os.path.join(tmp, base)])
    m = re.search(r'maxdiff=([0-9.e+-]+) nan=(\d)', out)
    return (float(m.group(1)), m.group(2) == '1') if m else (None, out.strip() or err[-200:])

# ---- đối chứng: ref khác nhau thật (nếu ref_base == ref_full thì mọi so sánh bên dưới vô nghĩa)
d_base_vs_full, _ = diff('base.mnn', 'ref_full.bin', 0, 0)
d_base_vs_base, _ = diff('base.mnn', 'ref_base.bin', 0, 0)
check('mô hình nền khớp tham chiếu CPU của nó (< 1e-4) — tham chiếu đáng tin', d_base_vs_base is not None and d_base_vs_base < 1e-4, str(d_base_vs_base))
check('LoRA có tác động THẬT: đầu ra nền cách xa đầu ra có LoRA (> 0.1) — nếu không thì mọi phép so sánh dưới đây vô nghĩa', d_base_vs_full is not None and d_base_vs_full > 0.1, str(d_base_vs_full))
d_merged, _ = diff('merged_full.mnn', 'ref_full.bin', 0, 0)
check('bản gộp trọng số (Express) khớp tham chiếu CPU (< 1e-4) — tham chiếu LoRA đúng', d_merged is not None and d_merged < 1e-4, str(d_merged))

# ---- (1) gắn đủ ba nhánh: 1x1 (c0, có hai chỗ dùng), 3x3 + relu gộp (c1), đầu ra mạng (out); --emit-base xuất đồ thị nền đã tách relu tương ứng
rc, o, e = attach('spec_full.txt', 'lora_full.mnn', '--unfuse-activation', '--emit-base', os.path.join(tmp, 'base_unfused.mnn'))
check('gắn ba nhánh (1x1, 3x3 có relu gộp, đầu ra mạng) thành công', rc == 0 and 'OK: gắn 3 nhánh' in o, o + e)
check('báo đổi 2 chỗ dùng cho c0 (c1 và res) — chỗ dùng không bị bỏ sót', re.search(r'c0\s+in=16 out=32 k=1x1 rank=4 scale=0\.7\s+\(đổi 2 chỗ dùng\)', o) is not None, o)
check('c1 (3x3, relu gộp) được tách hoạt hoá', re.search(r'c1\s+in=32 out=32 k=3x3 rank=3 scale=0\.5 \[tách hoạt hoá\]', o) is not None, o)
check('--emit-base ghi đồ thị nền tương ứng (chỉ tách relu của c1)', 'OK: ghi đồ thị nền tương ứng' in o and 'c1' in o and os.path.exists(os.path.join(tmp, 'base_unfused.mnn')), o)
d, nan = diff('base_unfused.mnn', 'ref_base.bin', 0, 0)
check(f'đồ thị nền đã tách relu chạy KHÔNG LoRA vẫn bằng nền gốc (< 1e-4; đo {d}) — phép tách hoạt hoá không đổi nghĩa', d is not None and d < 1e-4 and not nan, str((d, nan)))
for sm in (0, 1):
    d, nan = diff('lora_full.mnn', 'ref_full.bin', sm, 0)
    # file LoRA mang trọng số nền THẬT (chưa strip) nên chạy độc lập được
    check(f'(1) nhánh LoRA gắn bằng công cụ == bản gộp (CPU thuần) < 1e-4, shapeMutable={sm}, không base (đo {d})', d is not None and d < 1e-4 and not nan, str((d, nan)))
rc, o, e = attach('spec_c0c2.txt', 'lora_c0c2.mnn')
check('gắn nhánh chỉ cho c0 và out (c1 không gắn, relu gộp giữ nguyên) thành công', rc == 0 and 'OK: gắn 2 nhánh' in o, o + e)
d, nan = diff('lora_c0c2.mnn', 'ref_c0c2.bin', 0, 0)
check(f'(1) gắn một phần: khớp tham chiếu CPU (c1 không đổi) < 1e-4 (đo {d})', d is not None and d < 1e-4 and not nan, str((d, nan)))
d, nan = diff('lora_c0c2.mnn', 'ref_c0c2.bin', 0, 1, 'base.mnn')
check(f'(1) gắn một phần + base thường (c1 relu gộp KHÔNG bị tách) + rearrange=true: đúng < 1e-4 (đo {d})', d is not None and d < 1e-4 and not nan, str((d, nan)))

# ---- (2)(3) chia sẻ trọng số nền QUA các op chèn. LoRA dựng trên đồ thị nền có trọng số 0 (cùng tên op) -> chỉ đúng nếu trọng số lấy từ base thật
rc, o, e = attach_on('base_zero.mnn', 'spec_c0c2.txt', 'lora_zero_c0c2.mnn')
check('gắn nhánh (c0, out) lên đồ thị nền trọng số 0 (cùng tên op với base)', rc == 0, o + e)
for sm in (0, 1):
    d, nan = diff('lora_zero_c0c2.mnn', 'ref_c0c2.bin', sm, 1, 'base.mnn')
    check(f'(2) base + rearrange=true, shapeMutable={sm}: trọng số nền được chia sẻ QUA các op chèn (khớp theo tên op) -> đúng < 1e-4 (đo {d})', d is not None and d < 1e-4 and not nan, str((d, nan)))
d_nb, nan = diff('lora_zero_c0c2.mnn', 'ref_c0c2.bin', 0, 1)
check(f'(3) KHÔNG base: file dùng trọng số nền 0 của chính nó -> sai (> 0.1; đo {d_nb}) — đối chứng', d_nb is not None and d_nb > 0.1, str((d_nb, nan)))
d_nr, nan = diff('lora_zero_c0c2.mnn', 'ref_c0c2.bin', 0, 0, 'base.mnn')
check(f'(3) base nhưng rearrange=false: KHÔNG chia sẻ -> sai (> 0.1; đo {d_nr}) — bẫy ở mục 264, báo nếu đổi phiên bản MNN', d_nr is not None and d_nr > 0.1, str((d_nr, nan)))

# ---- (7) conv có hoạt hoá gộp + base: PHÁT HIỆN MỚI của mục 265 (đo, không phải suy luận)
rc, o, e = attach_on('base_zero.mnn', 'spec_full.txt', 'lora_zero_full.mnn', '--unfuse-activation')
check('gắn đủ ba nhánh lên đồ thị nền trọng số 0', rc == 0, o + e)
for sm in (0, 1):
    d, nan = diff('lora_zero_full.mnn', 'ref_full.bin', sm, 1, 'base_unfused.mnn')
    check(f'(7) base = đồ thị nền ĐÃ TÁCH relu (--emit-base) + rearrange=true, shapeMutable={sm}: đúng < 1e-4 cả với conv 3x3 và conv dùng hai nơi (đo {d})', d is not None and d < 1e-4 and not nan, str((d, nan)))
d_pit, nan = diff('lora_zero_full.mnn', 'ref_full.bin', 0, 1, 'base.mnn')
check(f'(7) BẪY: base là đồ thị nền GỐC (relu còn gộp trong conv) + file LoRA đã tách relu -> execution nhân bản mang theo relu của nền -> SAI (> 0.1; đo {d_pit}). Báo nếu MNN đổi hành vi', d_pit is not None and d_pit > 0.1, str((d_pit, nan)))

# ---- (6) --strip-base-weights
rc, o, e = attach('spec_full.txt', 'lora_strip.mnn', '--unfuse-activation', '--strip-base-weights')
check('--strip-base-weights: gắn thành công', rc == 0, o + e)
size = lambda n: os.path.getsize(os.path.join(tmp, n))
check(f'(6) file LoRA bỏ trọng số nền nhỏ hơn hẳn file nền ({size("lora_strip.mnn")} so với {size("base.mnn")} byte; < 1/3)', size('lora_strip.mnn') * 3 < size('base.mnn'))
check('(6) file LoRA KHÔNG bỏ trọng số nền lớn hơn file nền (nền + nhánh)', size('lora_full.mnn') > size('base.mnn'))
d, nan = diff('lora_strip.mnn', 'ref_full.bin', 0, 1, 'base_unfused.mnn')
check(f'(6) file LoRA bỏ trọng số nền + base (đã tách relu) + rearrange=true: đúng < 1e-4 (đo {d})', d is not None and not isinstance(nan, str) and d < 1e-4 and not nan, str((d, nan)))

# ---- (5) từ chối đầu vào xấu: không ghi file, mã thoát 2, thông báo nêu đúng lý do
def refuse(label, spec_text, want, *flags):
    sp = os.path.join(tmp, 'bad_spec.txt'); open(sp, 'w').write(spec_text)
    outp = os.path.join(tmp, 'bad_out.mnn')
    if os.path.exists(outp): os.remove(outp)
    rc, o, e = sh([ATTACH, os.path.join(tmp, 'base.mnn'), sp, outp] + list(flags))
    check(f'(5) từ chối: {label}', rc == 2 and want in e and not os.path.exists(outp), f'rc={rc} err={e.strip()[:200]}')
A0, B0, A1, B1 = [os.path.join(tmp, n) for n in ('A0.bin', 'B0.bin', 'A1.bin', 'B1.bin')]
refuse('conv relu gộp mà thiếu --unfuse-activation', f'c1 3 0.5 {A1} {B1}\n', 'relu')
refuse('tên không tồn tại', f'nope 4 0.7 {A0} {B0}\n', "không có op/tensor tên 'nope'")
refuse('A sai kích thước (rank khai 5 nhưng file là rank 4)', f'c0 5 0.7 {A0} {B0}\n', 'cần')
refuse('B sai kích thước', f'c0 4 0.7 {A0} {A0}\n', 'B:')
refuse('cùng đích hai dòng', f'c0 4 0.7 {A0} {B0}\nc0 4 0.7 {A0} {B0}\n', 'xuất hiện hai lần')
refuse('thiếu trường', f'c0 4 0.7 {A0}\n', 'cần <target>')
refuse('rank <= 0', f'c0 0 0.7 {A0} {B0}\n', 'rank phải > 0')
refuse('op không phải Convolution (res là phép cộng)', f'res 4 0.7 {A0} {B0}\n', 'chỉ gắn được vào OpType_Convolution')
rc, o, e = sh([ATTACH, os.path.join(tmp, 'base_group.mnn'), os.path.join(tmp, 'spec_group.txt'), os.path.join(tmp, 'g_out.mnn')])
check('(5) từ chối conv NHÓM (group=2): không ghi file, nêu đúng lý do', rc == 2 and 'group=2' in e and not os.path.exists(os.path.join(tmp, 'g_out.mnn')), f'rc={rc} err={e.strip()[:200]}')
rc, o, e = sh([ATTACH, '--list', os.path.join(tmp, 'lora_full.mnn')])
check('(4) sau khi gắn: đầu ra conv gốc được ĐỔI TÊN (<tên>/lora_base) — tên gốc dành cho đầu ra cuối, không có hai tensor trùng tên', rc == 0 and 'out=c0/lora_base' in o and 'out=c1/lora_base' in o and 'out=out/lora_base' in o, o[-500:])
rc, o, e = attach_on('lora_c0c2.mnn', 'spec_c0c2.txt', 'twice.mnn')
check('(5) từ chối gắn lần hai lên đồ thị đã có nhánh (tên op lora::... đã có)', rc == 2 and 'đã gắn nhánh' in e, e.strip()[:200])
rc, o, e = sh([ATTACH, '--list', os.path.join(tmp, 'base.mnn')])
check('--list liệt kê đủ 3 conv với kênh/kernel/cờ relu', rc == 0 and 'name=c0' in o and 'name=c1' in o and 'name=out' in o and 'k=3x3' in o and 'relu' in o, o[-400:])
check('--list trên file không phải MNN: lỗi rõ ràng', sh([ATTACH, '--list', os.path.join(tmp, 'A0.bin')])[0] == 2)

# ---- THỬ PHÁ MÃ: cố ý làm hỏng từng chỗ trong công cụ, bộ kiểm phải bắt được (MUT_RANGE=a:b để chạy một đoạn, mặc định tất cả)
CPP = os.path.join(ROOT, 'tools/mnn_probe/lora_attach_branch.cpp')
def quick(exe):
    """Các hành vi quyết định của công cụ, chạy gọn. True = TẤT CẢ đúng."""
    try:
        def A(base, spec, outp, *fl): return sh([exe, os.path.join(tmp, base), os.path.join(tmp, spec), os.path.join(tmp, outp)] + list(fl))
        rc, o, e = A('base.mnn', 'spec_full.txt', 'q_full.mnn', '--unfuse-activation', '--emit-base', os.path.join(tmp, 'q_base_unf.mnn'))
        if rc != 0: return False
        d, nan = diff('q_full.mnn', 'ref_full.bin', 0, 0)
        if d is None or d >= 1e-4 or nan: return False
        rc, o, e = A('base_zero.mnn', 'spec_full.txt', 'q_zero.mnn', '--unfuse-activation')
        if rc != 0: return False
        d, nan = diff('q_zero.mnn', 'ref_full.bin', 0, 1, 'q_base_unf.mnn')
        if d is None or d >= 1e-4 or nan: return False
        rc, o, e = A('base.mnn', 'spec_c1_only.txt', 'q_fused.mnn')
        if not (rc == 2 and 'relu' in e): return False
        rc, o, e = A('base_group.mnn', 'spec_group.txt', 'q_grp.mnn')
        if not (rc == 2 and 'group=2' in e): return False
        rc, o, e = sh([exe, '--list', os.path.join(tmp, 'q_full.mnn')])
        if not (rc == 0 and 'out=c0/lora_base' in o and 'out=out/lora_base' in o): return False
        rc, o, e = A('q_full.mnn', 'spec_c0c2.txt', 'q_twice.mnn')
        if not (rc == 2 and 'đã gắn nhánh' in e): return False
        rc, o, e = A('base.mnn', 'spec_full.txt', 'q_strip.mnn', '--unfuse-activation', '--strip-base-weights')
        if rc != 0 or os.path.getsize(os.path.join(tmp, 'q_strip.mnn')) * 3 >= os.path.getsize(os.path.join(tmp, 'base.mnn')): return False
        d, nan = diff('q_strip.mnn', 'ref_full.bin', 0, 1, 'q_base_unf.mnn')
        if d is None or d >= 1e-4 or nan: return False
        d, nan = diff('q_full.mnn', 'ref_full.bin', 0, 0)   # file không strip phải chạy độc lập
        return d is not None and d < 1e-4 and not nan
    except Exception:
        return False
src = open(CPP, encoding='utf-8').read()
check('đối chứng: công cụ gốc qua bộ kiểm gọn (nếu không thì phép thử phá mã vô nghĩa)', quick(ATTACH))
MUTANTS = [
    ('không đổi chỗ dùng đầu ra conv gốc sang đầu ra ADD', 'if (idx == convOut) { idx = tFinal; ++rewired; }', 'if (false) { idx = tFinal; ++rewired; }'),
    ('quên nhân scale vào B', 'v *= s.scale; }', '}'),
    ('ADD thành SUB', 'bo->opType = BinaryOpOperation_ADD;', 'bo->opType = BinaryOpOperation_SUB;'),
    ('không gỡ relu gộp khỏi conv khi tách hoạt hoá', 'c.relu = false; c.relu6 = false;\n        std::unique_ptr<OpT> act', 'std::unique_ptr<OpT> act'),
    ('nhánh B dùng hình học (kernel) của conv gốc', 'makeConv(nB, s.rank, out, tA, tB, c, false,', 'makeConv(nB, s.rank, out, tA, tB, c, true,'),
    ('không đổi tên tensor đầu ra conv gốc', 'net.tensorName[convOut] = origName + "/lora_base";', ''),
    ('findOp luôn xét cả tên tensor (nhập nhằng tên op/tensor sau lần gắn đầu)', 'if (hits == 0) {\n        for (int i = 0; i < (int)net.oplists.size(); ++i)\n            for (int o', 'if (true) {\n        for (int i = 0; i < (int)net.oplists.size(); ++i)\n            for (int o'),
    ('--strip-base-weights luôn bật', 'if (branch && opt.stripBase) {', 'if (branch) {'),
    ('--emit-base không tách relu', 'if (!branch && !fused) return true;', 'if (!branch) return true;'),
    ('bỏ chặn conv relu gộp khi thiếu --unfuse-activation', 'if (fused && !opt.unfuse && branch) {', 'if (false) {'),
    ('bỏ kiểm group != 1', 'if (c.group != 1) {', 'if (false) {'),
]
lo, hi = 0, len(MUTANTS)
if os.environ.get('MUT_RANGE'):
    a, b = os.environ['MUT_RANGE'].split(':'); lo, hi = int(a), int(b)
killed = 0; ran = 0
for i in range(lo, min(hi, len(MUTANTS))):
    name, old, new = MUTANTS[i]
    if src.count(old) != 1:
        check(f'đột biến {i} có điểm cắm duy nhất trong mã ({name})', False, f'tìm thấy {src.count(old)} chỗ'); continue
    mp = os.path.join(tmp, f'mut{i}.cpp'); open(mp, 'w', encoding='utf-8').write(src.replace(old, new))
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-w', mp] + INC + LINK + ['-o', os.path.join(tmp, f'mut{i}')], capture_output=True, text=True)
    if r.returncode != 0:
        check(f'đột biến {i} biên dịch được ({name})', False, r.stderr[-300:]); continue
    ran += 1
    survived = quick(os.path.join(tmp, f'mut{i}'))
    check(f'đột biến "{name}" bị bộ kiểm bắt', not survived)
    killed += (not survived)
if ran: check(f'thử phá mã: {killed}/{ran} đột biến bị bắt', killed == ran)
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
