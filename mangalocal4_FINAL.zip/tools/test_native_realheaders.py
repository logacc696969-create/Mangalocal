#!/usr/bin/env python3
"""mục 285 — biên dịch (g++ -fsyntax-only, C++17) MỌI tệp .cpp của app/src/main/jni với HEADER THẬT: MNN 3.6.1 (nhánh CI dùng) + xtensor 0.25.0 / xtl 0.7.7 / xsimd 10.0.0 / xtensor-blas 0.21.0 /
nlohmann json 3.11.3 / tokenizers-cpp / stb — đúng phiên bản build.yml tải. Trước đây (282.4) kiểm cú pháp native chỉ bằng header GIẢ (tools/mnn_mock, tools/stubs); lần này bắt được trôi API so với MNN thật.
KHÔNG phải Android NDK/clang và KHÔNG liên kết/chạy: chỉ chứng minh mã khớp chữ ký API và kiểu của thư viện thật (host x86-64, g++). jni.h lấy từ JDK; android/log.h, bitmap.h là bản giả tối thiểu.
Cần: MNN_SRC (cây MNN 3.6.1, mặc định /home/claude/ocl/MNN-3.6.1), TP (thư mục chứa xtl xsimd xtensor xtensor-blas json tokenizers-cpp stb, mặc định /home/claude/tp), JDK (jni.h).
Thiếu bất kỳ cái nào → BỎ QUA (exit 0) và nói rõ. Dùng: python3 tools/test_native_realheaders.py [tên_tệp.cpp ...]
"""
import glob, os, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); JNI = os.path.join(ROOT, 'app/src/main/jni')
MNN = os.environ.get('MNN_SRC', '/home/claude/ocl/MNN-3.6.1'); TP = os.environ.get('TP', '/home/claude/tp')
def skip(w): print('BỎ QUA:', w); sys.exit(0)
if not shutil.which('g++'): skip('không có g++')
jh = glob.glob('/usr/lib/jvm/*/include/jni.h')
if not jh: skip('không thấy jni.h (cài JDK: openjdk-21-jdk-headless)')
for d in ('include/MNN/Interpreter.hpp', 'transformers/llm/engine/include/llm/llm.hpp'):
    if not os.path.isfile(os.path.join(MNN, d)): skip(f'thiếu {d} trong MNN_SRC={MNN}')
need = {'xtl': 'include/xtl/xbase64.hpp', 'xsimd': 'include/xsimd/xsimd.hpp', 'xtensor': 'include/xtensor/xarray.hpp', 'xtensor-blas': 'include/xtensor-blas/xlinalg.hpp', 'json': 'include/nlohmann/json.hpp',
        'tokenizers-cpp': 'include/tokenizers_cpp.h', 'stb': 'stb_image.h'}
for k, f in need.items():
    if not os.path.isfile(os.path.join(TP, k, f)) and not (k == 'tokenizers-cpp' and os.path.isfile(os.path.join(TP, k, 'tokenizers_cpp.h'))): skip(f'thiếu {k}/{f} trong TP={TP} (build.yml clone đúng phiên bản)')
jdk = os.path.dirname(jh[0]); stubs = tempfile.mkdtemp(); os.makedirs(os.path.join(stubs, 'android'))
for h in os.listdir(os.path.join(ROOT, 'tools/stubs/android')): shutil.copy(os.path.join(ROOT, 'tools/stubs/android', h), os.path.join(stubs, 'android', h))
open(os.path.join(stubs, 'android', 'bitmap.h'), 'w').write('#pragma once\n#include <jni.h>\n#include <stdint.h>\ntypedef struct { uint32_t width, height, stride; int32_t format; uint32_t flags; } AndroidBitmapInfo;\nenum { ANDROID_BITMAP_FORMAT_RGBA_8888 = 1, ANDROID_BITMAP_RESULT_SUCCESS = 0 };\nint AndroidBitmap_getInfo(JNIEnv*, jobject, AndroidBitmapInfo*);\nint AndroidBitmap_lockPixels(JNIEnv*, jobject, void**);\nint AndroidBitmap_unlockPixels(JNIEnv*, jobject);\n')
# bắt chước bước "Copy stb headers" của build.yml: stb_image_resize2.h ở gốc repo hoặc (từ 2026-10-19) trong deprecated/ — cả hai đều được thử, như CI
ov = os.path.join(stubs, 'ov'); os.makedirs(os.path.join(ov, 'sd_engine'))
rs = [p for p in (os.path.join(TP, 'stb', 'stb_image_resize2.h'), os.path.join(TP, 'stb', 'deprecated', 'stb_image_resize2.h')) if os.path.isfile(p)]
if not rs: print('FAIL không tìm thấy stb_image_resize2.h ở gốc stb lẫn deprecated/ — build.yml cũng sẽ lỗi ở bước "Copy stb headers"'); sys.exit(1)
print('stb_image_resize2.h lấy từ:', os.path.relpath(rs[0], TP))
for dst in (ov, os.path.join(ov, 'sd_engine')):
    shutil.copy(rs[0], dst)
    for h in ('stb_image.h', 'stb_image_write.h'): shutil.copy(os.path.join(TP, 'stb', h), dst)
# khác biệt GLIBC (host) / bionic (Android) DUY NHẤT cần bù: SIGSTKSZ là hằng trên bionic nhưng là sysconf() trên glibc >= 2.34 (native_crash_handler.cpp dùng làm kích thước mảng tĩnh)
os.makedirs(os.path.join(ov, 'android'))
open(os.path.join(ov, 'android', 'log.h'), 'w').write('#pragma once\n#include <stdarg.h>\nenum android_LogPriority { ANDROID_LOG_UNKNOWN = 0, ANDROID_LOG_DEFAULT, ANDROID_LOG_VERBOSE, ANDROID_LOG_DEBUG, ANDROID_LOG_INFO, ANDROID_LOG_WARN, ANDROID_LOG_ERROR, ANDROID_LOG_FATAL, ANDROID_LOG_SILENT };\n'
    'extern "C" { int __android_log_print(int, const char*, const char*, ...); int __android_log_write(int, const char*, const char*); int __android_log_vprint(int, const char*, const char*, va_list); void __android_log_assert(const char*, const char*, const char*, ...); }\n')
open(os.path.join(ov, 'host_sigstksz.h'), 'w').write('#include <signal.h>\n#undef SIGSTKSZ\n#define SIGSTKSZ 16384\n')
inc = [f'-I{ov}', f'-I{ov}/sd_engine', '-include', os.path.join(ov, 'host_sigstksz.h'), f'-I{MNN}/include', f'-I{MNN}/transformers/diffusion/engine/include', f'-I{MNN}/transformers/diffusion/include', f'-I{MNN}/transformers/llm/engine/include', f'-I{TP}/stb', f'-I{TP}/xtensor/include', f'-I{TP}/xtl/include',
       f'-I{TP}/xsimd/include', f'-I{TP}/tokenizers-cpp/include', f'-I{TP}/tokenizers-cpp', f'-I{TP}/json/include', f'-I{TP}/xtensor-blas/include', f'-I{JNI}', f'-I{JNI}/sd_engine', f'-I{jdk}', f'-I{jdk}/linux', f'-I{stubs}']
files = [os.path.basename(a) for a in sys.argv[1:]] or sorted(os.path.basename(f) for f in glob.glob(os.path.join(JNI, '*.cpp')))
fails = []; ok = 0
for f in files:
    for extra in ([[]] if f != 'mnn_diffusion_pipeline.cpp' else [[], ['-DMANGALOCAL_ENABLE_LORA_MODULE=1']]):
        r = subprocess.run(['g++', '-std=c++17', '-fsyntax-only', '-w', '-DANDROID', '-fpermissive'] + extra + inc + [os.path.join(JNI, f)], capture_output=True, text=True)
        tag = f + (' ' + ' '.join(extra) if extra else '')
        if r.returncode == 0: ok += 1; print('PASS', tag)
        else:
            fails.append(tag); errs = [l for l in r.stderr.splitlines() if 'error' in l][:4]; print('FAIL', tag); [print('    ', e[:230]) for e in errs]
shutil.rmtree(stubs, ignore_errors=True)
print(f'\n{ok} đạt, {len(fails)} lỗi'); print('ĐẠT' if not fails else 'CÓ LỖI: ' + ', '.join(fails)); sys.exit(1 if fails else 0)
