#!/usr/bin/env python3
"""mục 255 — kiểm thử `tools/remote_server/smoke_test.py` (client thử nhanh server từ xa).

Dựng một server GIẢ bằng thư viện chuẩn (http.server) dùng ĐÚNG phép mã hoá của app.py `generate()` (đọc từng dòng: RSA-OAEP SHA-256 bọc
khoá AES-256, AES-256-GCM, IV 12 byte, không AAD, IV mới cho chiều trả về, kiểm `Authorization: Bearer`, echo `task`). Chứng minh: client
mã hoá/giải mã ĐÚNG giao thức, xử lý lỗi (401/500/server cũ/fingerprint lạ), bỏ qua đúng tác vụ thiếu đầu vào, lưu đúng định dạng.
Ngoài ra ĐỐI CHIẾU TĨNH: mọi khoá payload client gửi đều là khoá app.py THẬT SỰ đọc (bắt lỗi gõ sai tên trường).
KHÔNG chứng minh server thật (fastapi/torch không có ở sandbox) hay chất lượng ảnh.
"""
import base64, contextlib, io, json, os, re, sys, tempfile, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import requests
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding as rsa_padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from PIL import Image
from PIL.PngImagePlugin import PngInfo

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, 'remote_server'))
import smoke_test as st  # noqa: E402

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

TOKEN = 'tok-test'
PRIV = rsa.generate_private_key(public_exponent=65537, key_size=2048)
PUB_DER = PRIV.public_key().public_bytes(encoding=serialization.Encoding.DER, format=serialization.PublicFormat.SubjectPublicKeyInfo)

STATE = {'calls': [], 'fail_task': None, 'echo': True, 'token': TOKEN}

def make_png(report=None):
    buf = io.BytesIO(); img = Image.new('RGB', (64, 48), (10, 120, 200))
    if report is not None:
        info = PngInfo(); info.add_text('mangalocal_report', json.dumps(report, ensure_ascii=True)); img.save(buf, format='PNG', pnginfo=info)
    else:
        img.save(buf, format='PNG')
    return buf.getvalue()

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, obj):
        raw = json.dumps(obj).encode(); self.send_response(code); self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        if self.path == '/pubkey': self._send(200, {'public_key_der_b64': base64.b64encode(PUB_DER).decode()})
        else: self._send(404, {'detail': 'not found'})
    def do_POST(self):
        if self.path != '/generate': return self._send(404, {'detail': 'not found'})
        if self.headers.get('Authorization') != f"Bearer {STATE['token']}":
            return self._send(401, {'detail': 'Auth token sai hoặc thiếu'})
        req = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        aes_key = PRIV.decrypt(base64.b64decode(req['wrapped_key_b64']), rsa_padding.OAEP(mgf=rsa_padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
        payload = json.loads(AESGCM(aes_key).decrypt(base64.b64decode(req['iv_b64']), base64.b64decode(req['ciphertext_b64']), None).decode('utf-8'))
        task = payload.get('task'); STATE['calls'].append(payload)
        if task and task == STATE['fail_task']:
            return self._send(500, {'detail': f'Tác vụ {task} lỗi: CUDA out of memory. Tried to allocate 2.00 GiB'})
        if task == 'video': out = b'\x00\x00\x00\x18ftypmp42' + b'\x00' * 32
        elif task == 'faceswap': out = make_png({'task': 'faceswap', 'faces': [{'id': 0, 'status': 'swapped', 'expr_dev': {'ear': 0.02}}]})
        else: out = make_png()
        resp_iv = os.urandom(12); resp = {'iv_b64': base64.b64encode(resp_iv).decode(), 'ciphertext_b64': base64.b64encode(AESGCM(aes_key).encrypt(resp_iv, out, None)).decode()}
        if STATE['echo'] and isinstance(task, str): resp['task'] = task
        self._send(200, resp)

srv = ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
URL = f'http://127.0.0.1:{srv.server_address[1]}'

tmp = tempfile.mkdtemp()
IMG = os.path.join(tmp, 'panel.png'); Image.new('RGB', (80, 60), (200, 50, 50)).save(IMG)
REF = os.path.join(tmp, 'ref.png'); Image.new('RGB', (32, 32), (50, 200, 50)).save(REF)

def run(*args, tasks=None, token=TOKEN):
    """Chạy smoke_test.main; trả (mã thoát, stdout)."""
    STATE['calls'].clear()
    argv = ['--url', URL, '--token', token, '--out', os.path.join(tmp, 'out')] + list(args)
    if tasks is not None: argv += ['--tasks', tasks]
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            code = st.main(argv)
    except SystemExit as e:
        code = e.code
    return code, buf.getvalue()

# ---- 1. luồng đầy đủ ----
code, out = run('--image', IMG, '--ref', REF, '--face-box', '0.2,0.1,0.6,0.5')
check('luồng đầy đủ: mã thoát 0', code == 0)
check('đã gửi đúng 5 tác vụ mặc định (không có video)', [c.get('task') for c in STATE['calls']] == [None, 'faceswap', 'handfix', 'interact', 'kontext'])
fp_expected = ':'.join(re.findall('..', __import__('hashlib').sha256(PUB_DER).hexdigest().upper()))
check('in fingerprint đúng định dạng của server (SHA-256 DER hoa, cách bằng ":")', fp_expected in out)
check('lưu đủ 5 file kết quả .png', all(os.path.getsize(os.path.join(tmp, 'out', t + '.png')) > 0 for t in ['generate', 'faceswap', 'handfix', 'interact', 'kontext']))
check('in báo cáo faceswap nhúng trong PNG (tEXt)', 'báo cáo:' in out and '"status": "swapped"' in out)
fs = next(c for c in STATE['calls'] if c.get('task') == 'faceswap')
check('faceswap: targets[0] có id/box/ref_b64 và preserve=auto', fs['targets'][0]['id'] == 0 and fs['targets'][0]['box'] == [0.2, 0.1, 0.6, 0.5] and base64.b64decode(fs['targets'][0]['ref_b64']) == open(REF, 'rb').read() and fs['preserve'] == 'auto')
check('ảnh gửi đi giải mã ra đúng byte của --image', base64.b64decode(fs['image_b64']) == open(IMG, 'rb').read())
it = next(c for c in STATE['calls'] if c.get('task') == 'interact')['interaction']
b = it['subject_box'] + it['object_box']
check('interact: hộp hợp lệ [0,1], x2>x1,y2>y1 (cùng luật server)', all(0 <= v <= 1 for v in b) and it['subject_box'][2] > it['subject_box'][0] and it['object_box'][3] > it['object_box'][1] and it['action_phrase'] == 'hug')
kc = next(c for c in STATE['calls'] if c.get('task') == 'kontext')
check('kontext có ref_b64 khi cho --ref', 'ref_b64' in kc)

# ---- 2. bỏ qua đúng tác vụ thiếu đầu vào ----
code, out = run('--image', IMG, tasks='faceswap,kontext')
check('thiếu --ref/--face-box: faceswap BỎ QUA (không gọi server), mã thoát 0', code == 0 and 'BỎ QUA' in out and [c.get('task') for c in STATE['calls']] == ['kontext'])
check('kontext không --ref thì KHÔNG gửi ref_b64', 'ref_b64' not in STATE['calls'][0])
code, out = run(tasks='handfix')
check('thiếu --image: handfix bỏ qua, nêu lý do', code == 0 and 'thiếu --image' in out and not STATE['calls'])
code, out = run(tasks='generate')
check('generate không cần --image', code == 0 and len(STATE['calls']) == 1)

# ---- 3. lỗi ----
code, out = run('--image', IMG, tasks='handfix', token='sai-token')
check('sai token: báo HTTP 401 nguyên văn, mã thoát 1', code == 1 and 'HTTP 401' in out and 'Auth token sai' in out)
STATE['fail_task'] = 'kontext'
code, out = run('--image', IMG, tasks='handfix,kontext,interact')
check('kontext lỗi VRAM: in nguyên văn "CUDA out of memory", mã thoát 1, các tác vụ khác VẪN chạy', code == 1 and 'CUDA out of memory' in out and [c.get('task') for c in STATE['calls']] == ['handfix', 'kontext', 'interact'])
STATE['fail_task'] = None
STATE['echo'] = False
code, out = run('--image', IMG, tasks='handfix')
check('server CŨ không echo task: cảnh báo rõ', 'server CŨ' in out)
STATE['echo'] = True

# ---- 4. fingerprint / đối số ----
code, out = run('--fingerprint', 'AA:BB:CC', tasks='generate')
check('--fingerprint sai: dừng mã 2, KHÔNG gửi gì lên server', code == 2 and not STATE['calls'])
code, out = run('--fingerprint', fp_expected.lower(), tasks='generate')
check('--fingerprint đúng (không phân biệt hoa/thường): chạy bình thường', code == 0 and len(STATE['calls']) == 1)
code, out = run(tasks='generate,khongbiet')
check('tác vụ không biết: mã thoát 2 và không gửi gì', code == 2 and not STATE['calls'])
code, _ = run('--face-box', '0.9,0.1,0.2,0.5', tasks='generate')
check('--face-box ngược (x2<x1): argparse từ chối', code == 2)
code, _ = run('--face-box', '0.1,0.1,1.5,0.5', tasks='generate')
check('--face-box ngoài [0,1]: argparse từ chối', code == 2)

# ---- 5. video ----
code, out = run('--image', IMG, tasks='video')
check('video (nêu rõ): lưu .mp4 theo chữ ký ftyp', code == 0 and os.path.exists(os.path.join(tmp, 'out', 'video.mp4')))

# ---- 6. đối chiếu TĨNH khoá payload với app.py thật ----
APP = open(os.path.join(HERE, 'remote_server', 'app.py'), encoding='utf8').read().split('\n')
def server_keys(a, b):
    keys = set()
    for l in APP[a - 1:b]:
        keys |= set(re.findall(r'payload(?:\.get\(|\[)\s*"([a-zA-Z0-9_]+)"', l))
    return keys
def find_fn(name):
    start = next(i for i, l in enumerate(APP) if l.startswith('def ' + name + '('))
    end = next((i for i in range(start + 1, len(APP)) if APP[i].startswith(('def ', 'class ', '@app', '_TASK_HANDLERS'))), len(APP))
    return start + 1, end
class A:  # đối số giả như argparse
    prompt = 'p'; action = 'hug'; kontext_prompt = 'k'; preserve = 'auto'; steps = 20; seed = 1; face_box = [0.1, 0.1, 0.5, 0.5]
for task, fn in [('faceswap', '_run_faceswap_sync'), ('handfix', '_run_handfix_sync'), ('interact', '_run_interact_sync'), ('kontext', '_run_kontext_sync'), ('video', '_run_video_sync')]:
    p, skip = st.build_payload(task, A, 'AAAA', 'BBBB')
    sk = server_keys(*find_fn(fn))
    check(f'khoá payload client cho `{task}` đều được app.py ({fn}) đọc', skip is None and (set(p) - {'task'}) <= sk)
pg, _ = st.build_payload('generate', A, None, None)
gen_start, gen_end = find_fn('_run_generation_sync')
gen_keys = server_keys(gen_start, gen_end)
check('khoá payload client cho `generate` đều được app.py đọc', set(pg) <= gen_keys)
isrc = '\n'.join(APP[find_fn('_run_interact_sync')[0] - 1:find_fn('_run_interact_sync')[1]])
check('interaction.* client gửi (3 cụm từ + 2 hộp) đều là khoá server đọc', all(('"' + k + '"') in isrc for k in ['subject_phrase', 'object_phrase', 'action_phrase', 'subject_box', 'object_box']))
fsrc = '\n'.join(APP[find_fn('_run_faceswap_sync')[0] - 1:find_fn('_run_faceswap_sync')[1]])
check('targets[].id/box/ref_b64 client gửi đều được faceswap đọc', all(('"' + k + '"') in fsrc for k in ['id', 'box', 'ref_b64']))
check('app.py có đủ 5 tác vụ client biết (faceswap/handfix/interact/kontext/video)', all(('"' + t + '":') in '\n'.join(APP) for t in ['faceswap', 'handfix', 'interact', 'kontext', 'video']))

srv.shutdown()
print('\nTỔNG KẾT:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
