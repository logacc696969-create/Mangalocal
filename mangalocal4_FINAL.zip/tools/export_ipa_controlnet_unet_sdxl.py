"""
export_ipa_controlnet_unet_sdxl.py — mục 177 TECHNICAL_STATUS.md (SDXL
Phase 2a). Xuất 1 bản UNet SDXL đã gộp sẵn IP-Adapter (giữ nhân vật, 1
người) + ControlNet-OpenPose-SDXL (giữ tư thế) thành ONNX rồi .mnn — bản
SDXL tương đương `export_ipa_controlnet_unet.py` (SD1.5).

=== PHẠM VI CÓ CHỦ ĐÍCH — CHỈ BẢN CƠ BẢN NHẤT, KHÔNG NHỒI MỌI TÍNH NĂNG ===
Bản SD1.5 hiện tại (export_ipa_controlnet_unet.py) đã tích luỹ qua RẤT
NHIỀU đợt (mục 51 depth, mục 52 mask N-nhân-vật, mục 81 cân bằng
ControlNet, mục 97 Smooth Timestep Decay, mục 146/147 per-instance decay)
— cố nhồi TẤT CẢ các tính năng đó vào bản SDXL đầu tiên này cùng lúc là
rủi ro chồng rủi ro (đúng nguyên tắc mục 59 đã nêu khi xây nền SDXL base:
"không cố nhồi mọi tính năng SD1.5 đã có... vào cùng 1 lượt"). Bản NÀY
CHỈ làm đúng những gì `export_ipa_controlnet_unet.py` làm ở PHIÊN BẢN
ĐẦU TIÊN của nó (1 nhân vật, IP-Adapter + ControlNet-Pose, KHÔNG decay,
KHÔNG depth, KHÔNG mask N-nhân-vật). Các tính năng còn thiếu liệt kê rõ
ở "CHƯA LÀM" cuối file — Phase 2c/2d cho các đợt sau nếu Phase 2 cơ bản
này build-test được.

=== KIẾN TRÚC — ĐÃ TRA CỨU THẬT, KHÔNG SUY DIỄN TỪ SD1.5 (mục 176) ===
1. Image encoder IP-Adapter cho SDXL dùng OpenCLIP-ViT-bigG-14 (KHÁC
   ViT-H-14 của SD1.5) — nhưng API `diffusers` HOÀN TOÀN GIỐNG NHAU
   (`pipe.image_encoder` + `pipe.unet.encoder_hid_proj.image_projection_
   layers[0]`, đã xác nhận qua tra cứu: cùng cơ chế `IPAdapterAttnProcessor
   2_0`/`load_ip_adapter()` dùng chung cho cả 2 kiến trúc trong diffusers)
   — TÁI SỬ DỤNG NGUYÊN `ImageEncoderForExport`/`export_image_encoder()`
   từ export_ipa_controlnet_unet.py (copy nguyên văn, KHÔNG viết lại) vì
   API generic, không có gì SDXL-specific trong 2 hàm đó.
2. `pipe.load_ip_adapter("h94/IP-Adapter", subfolder="sdxl_models",
   weight_name="ip-adapter_sdxl.bin")` — xác nhận qua tài liệu chính thức
   HuggingFace (mục 176, tra cứu web ngày viết file này).
3. ControlNet-OpenPose-SDXL: `thibaud/controlnet-openpose-sdxl-1.0` —
   model được cộng đồng dùng CHUẨN nhất cho việc này (324+ likes trên
   HuggingFace tại thời điểm tra cứu, được ít nhất 4 bản fork/mirror khác
   nhau — dimitribarbot/kristian1515/r3gm — đều dẫn nguồn về đúng model
   này, không phải model tự chọn bừa).
4. PHÁT HIỆN QUAN TRỌNG (tránh được 1 bug thật nhờ tra cứu TRƯỚC khi
   viết, không phải sau khi lỗi): KHÁC với ControlNet SD1.5 (chỉ cần
   `sample/timestep/encoder_hidden_states/controlnet_cond`), ControlNet
   SDXL có `addition_embed_type: "text_time"` trong config (xác nhận qua
   chính file config.json thật của `diffusers/controlnet-canny-sdxl-1.0-
   small` và 1 GitHub issue mô tả đúng lỗi này) — nghĩa là BẢN THÂN
   ControlNet SDXL cũng bắt buộc nhận `added_cond_kwargs={"text_embeds":
   ..., "time_ids": ...}` GIỐNG HỆT UNet, KHÔNG PHẢI chỉ UNet mới cần —
   thiếu tham số này ControlNet SDXL sẽ ném thẳng `ValueError` lúc trace.
   forward() bên dưới truyền đúng cả 2 chỗ.
5. `encoder_hidden_states` = nối [CLIP-L 768, CLIP-bigG 1280] = 2048-dim
   (giống hệt export_sdxl_base.py, PipelineSdxlCpu.hpp đã port).
   `text_embeds` = pooled CLIP-bigG (1280-dim). `time_ids` = 6 giá trị
   (h,w,0,0,h,w) — Kotlin/C++ tự tính giống bản base, script này chỉ cần
   export đúng UNet+ControlNet NHẬN 2 input đó, không tự sinh giá trị.

=== GIỚI HẠN THẬT (đọc kỹ trước khi tin đây là "đã xong") ===
- CHƯA build-test — như MỌI script export khác trong dự án (không có
  GPU/mạng trong sandbox lúc viết) — chỉ xác nhận cú pháp hợp lệ
  (py_compile) + khớp đúng API diffusers thật đã tra cứu (không đoán).
- CHƯA có xác nhận THẬT nào (kể cả từ bên thứ 3) rằng IP-Adapter SDXL +
  ControlNet-OpenPose-SDXL hoạt động tốt CÙNG LÚC trên 1 UNet — 2 tính
  năng đã xác nhận từng cái hoạt động RIÊNG (tài liệu chính thức + repo
  cộng đồng), nhưng KẾT HỢP CẢ HAI trong 1 lần forward() giống cách file
  này làm CHƯA có tiền lệ xác nhận được lúc viết (khác SD1.5 — bản SD1.5
  gộp cả hai đã build-test được, xem TECHNICAL_STATUS.md lịch sử mục 4/28).
- CHƯA rõ hiệu năng CPU/OpenCL trên điện thoại — UNet SDXL ~2.6B tham số
  (so với SD1.5 ~860M) — chính wiki local-dream (dự án gốc mà MangaLocal
  port kiến trúc pipeline) ghi rõ "SDXL models are supported on Snapdragon
  8 Gen 3 and newer devices" (hàm ý cần NPU, không nói CPU) — đây là bằng
  chứng THẬT (không phải suy đoán) rằng CPU/OpenCL có thể QUÁ CHẬM để
  dùng được thực tế, dù code đúng 100%. Xem TECHNICAL_STATUS.md mục 177.
- KHÔNG bao gồm: depth ControlNet, mask N-nhân-vật, Regional Prompting,
  Smooth Timestep Decay, cân bằng ControlNet (pose_scale/depth_scale) —
  xem "CHƯA LÀM" cuối file.

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_unet_sdxl.py \\
        --base_model stabilityai/stable-diffusion-xl-base-1.0 \\
        --output_dir ./exported_sdxl_augmented
"""
import argparse
import os

import torch
import torch.nn as nn
from diffusers import ControlNetModel, StableDiffusionXLControlNetPipeline


class AugmentedUnetXL(nn.Module):
    """Bọc UNet SDXL + ControlNet-SDXL thành 1 module duy nhất để export
    ONNX 1 lần — mirror ĐÚNG cấu trúc `AugmentedUNet` (SD1.5, xem
    export_ipa_controlnet_unet.py) nhưng thêm `text_embeds`/`time_ids` bắt
    buộc phải truyền cho CẢ controlnet LẪN unet (xem điểm #4 docstring đầu
    file — KHÁC SD1.5, không phải lặp thừa tham số)."""

    def __init__(self, unet, controlnet):
        super().__init__()
        self.unet = unet
        self.controlnet = controlnet

    def forward(self, sample, timestep, encoder_hidden_states, text_embeds, time_ids,
                control_hint, ip_image_embeds):
        added_cond = {"text_embeds": text_embeds, "time_ids": time_ids}
        down_res, mid_res = self.controlnet(
            sample,
            timestep,
            encoder_hidden_states=encoder_hidden_states,
            controlnet_cond=control_hint,
            added_cond_kwargs=added_cond,
            return_dict=False,
        )
        noise_pred = self.unet(
            sample,
            timestep,
            encoder_hidden_states=encoder_hidden_states,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            # image_embeds bọc trong list — diffusers hỗ trợ nhiều IP-Adapter
            # cùng lúc (list of tensors), dùng 1 phần tử ở đây, giống hệt quy
            # ước bản SD1.5.
            added_cond_kwargs={**added_cond, "image_embeds": [ip_image_embeds]},
            return_dict=False,
        )[0]
        return noise_pred


def probe_ip_adapter_embed_shape(pipe, device):
    """Tự dò shape thật của image_embeds SDXL bằng 1 lần chạy thử — GIỐNG
    HỆT nguyên tắc probe_ip_adapter_embed_shape() bản SD1.5 (không đoán số,
    vì tài liệu không nêu shape cụ thể)."""
    from PIL import Image

    dummy_image = Image.new("RGB", (224, 224), color=(128, 128, 128))
    with torch.no_grad():
        embeds = pipe.prepare_ip_adapter_image_embeds(
            ip_adapter_image=[dummy_image],
            ip_adapter_image_embeds=None,
            device=device,
            num_images_per_prompt=1,
            do_classifier_free_guidance=False,
        )
    embed_tensor = embeds[0]
    print(f"[probe] image_embeds shape THẬT (SDXL, dò được, không đoán): {tuple(embed_tensor.shape)}")
    return embed_tensor


class ImageEncoderForExport(nn.Module):
    """COPY NGUYÊN VĂN từ export_ipa_controlnet_unet.py (SD1.5) — API
    diffusers generic, không có gì SDXL-specific (xem điểm #1 docstring đầu
    file). Giữ 1 bản riêng ở đây (không import chéo giữa 2 script) để file
    này tự chạy độc lập, đúng quy ước mỗi tools/export_*.py trong dự án
    không phụ thuộc lẫn nhau."""

    def __init__(self, image_encoder, image_projection_layer):
        super().__init__()
        self.image_encoder = image_encoder
        self.image_projection_layer = image_projection_layer

    def forward(self, pixel_values):
        outputs = self.image_encoder(pixel_values, output_hidden_states=True)
        image_embeds = outputs.image_embeds
        projected = self.image_projection_layer(image_embeds)
        return projected


def export_image_encoder(pipe, output_dir, device):
    print("Đang export CLIP-bigG image encoder + projection riêng (ip_image_encoder.onnx)...")
    image_proj_layer = pipe.unet.encoder_hid_proj.image_projection_layers[0]
    encoder_module = ImageEncoderForExport(pipe.image_encoder, image_proj_layer).to(device).eval()

    example_pixels = torch.randn(1, 3, 224, 224, device=device)  # kích thước chuẩn CLIP ViT, giống hệt SD1.5
    onnx_path = os.path.join(output_dir, "ip_image_encoder.onnx")
    with torch.no_grad():
        output = encoder_module(example_pixels)
        torch.onnx.export(
            encoder_module, example_pixels, onnx_path,
            input_names=["pixel_values"], output_names=["image_embeds"],
            opset_version=17, do_constant_folding=True,
            dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
            # hành vi trace khác) — xem export_sd15_base.py/mục 97 TECHNICAL_STATUS.md
            # cho toàn bộ bằng chứng thực nghiệm đã kiểm chứng lý do ghim tham số này.
        )
    print(f"  -> {onnx_path}, output shape: {tuple(output.shape)}")
    return output


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="stabilityai/stable-diffusion-xl-base-1.0")
    ap.add_argument("--controlnet_model", default="thibaud/controlnet-openpose-sdxl-1.0",
                     help="ControlNet-OpenPose cho SDXL — mục 176 TECHNICAL_STATUS.md, "
                          "model chuẩn cộng đồng dùng nhiều nhất, đã tra cứu chéo qua "
                          "nhiều bản fork/mirror đều dẫn nguồn về đây.")
    ap.add_argument("--ip_adapter_repo", default="h94/IP-Adapter")
    ap.add_argument("--ip_adapter_weight", default="ip-adapter_sdxl.bin")
    ap.add_argument("--output_dir", default="./exported_sdxl_augmented")
    ap.add_argument("--image_size", type=int, default=1024,
                     help="SDXL sinh tốt nhất ở 1024 (khác SD1.5 512) — giống export_sdxl_base.py. "
                          "CHƯA hỗ trợ non-square cho bản augmented này (phạm vi Phase 2 cơ bản, "
                          "xem CHƯA LÀM cuối file — khác export_sdxl_base.py base cũng CHƯA hỗ trợ).")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    if args.image_size % 64 != 0:
        # mục 161 đợt 7 TECHNICAL_STATUS.md — cùng lý do chia hết 64 (không
        # phải 8) đã áp dụng cho mọi script SD1.5, SDXL cũng có ràng buộc
        # tương tự ở tầng UNet downsample nội bộ.
        raise ValueError(f"image_size phải chia hết cho 64 — nhận {args.image_size}")

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_size = args.image_size // 8

    print("Đang tải ControlNet-OpenPose-SDXL...")
    controlnet = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)

    print(f"Đang tải base SDXL ({args.base_model}, ~7GB) + gắn ControlNet...")
    pipe = StableDiffusionXLControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet, torch_dtype=torch.float32
    )

    print(f"Đang nạp IP-Adapter SDXL ({args.ip_adapter_repo}/sdxl_models/{args.ip_adapter_weight})...")
    pipe.load_ip_adapter(args.ip_adapter_repo, subfolder="sdxl_models", weight_name=args.ip_adapter_weight)
    pipe.set_ip_adapter_scale(1.0)  # scale TĨNH mặc định — KHÔNG có Smooth Timestep Decay ở
    # bản Phase 2 cơ bản này (xem docstring đầu file, "CHƯA LÀM"), scale cố định lúc export.
    pipe.to(device)

    # Dò shape thật của image_embeds — KHÔNG đoán, giống hệt bản SD1.5.
    example_embeds = probe_ip_adapter_embed_shape(pipe, device)

    # Export riêng CLIP-bigG image encoder để dùng lúc runtime.
    export_image_encoder(pipe, args.output_dir, device)

    print("Đang lắp AugmentedUnetXL (UNet + ControlNet SDXL gộp)...")
    augmented = AugmentedUnetXL(pipe.unet, pipe.controlnet).to(device).eval()

    # Input mẫu để trace ONNX.
    example_sample = torch.randn(1, 4, latent_size, latent_size, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_encoder_hidden = torch.randn(1, 77, 2048, device=device)  # CLIP-L+CLIP-bigG nối, giống PipelineSdxlCpu.hpp
    example_text_embeds = torch.randn(1, 1280, device=device)  # pooled CLIP-bigG
    example_time_ids = torch.tensor(
        [[args.image_size, args.image_size, 0, 0, args.image_size, args.image_size]],
        device=device, dtype=torch.float32)
    example_control_hint = torch.randn(1, 3, args.image_size, args.image_size, device=device)

    onnx_path = os.path.join(args.output_dir, "unet_ipa_controlnet_sdxl.onnx")
    print(f"Đang export ONNX -> {onnx_path} (model SDXL lớn, có thể mất nhiều phút)...")
    with torch.no_grad():
        torch.onnx.export(
            augmented,
            (example_sample, example_timestep, example_encoder_hidden, example_text_embeds,
             example_time_ids, example_control_hint, example_embeds),
            onnx_path,
            input_names=["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids",
                         "control_hint", "ip_image_embeds"],
            output_names=["out_sample"],
            opset_version=17,
            do_constant_folding=True,
            dynamo=False,  # xem docstring đầu file — cùng lý do/bằng chứng thực nghiệm đã
            # dùng cho MỌI lệnh torch.onnx.export() khác trong dự án (mục 97 TECHNICAL_STATUS.md).
        )

    print("\n=== XONG PHẦN ONNX ===")
    print(f"Shape ip_image_embeds thật đã dò được: {tuple(example_embeds.shape)}")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, 'unet_ipa_controlnet_sdxl.mnn')} \\")
    print(f"      --bizCode biz")
    print(f"  MNNConvert -f ONNX --modelFile {os.path.join(args.output_dir, 'ip_image_encoder.onnx')} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, 'ip_image_encoder_sdxl.mnn')} \\")
    print(f"      --bizCode biz")
    print("\nSau khi convert xong, dùng model_manifest.json với pipeline 'sdxl_cpu_augmented'")
    print("(xem app/src/main/jni/ip_adapter_sdxl.cpp phía MangaLocal, mục 177 TECHNICAL_STATUS.md).")
    print(f"\nQUAN TRỌNG: ghi lại số {example_embeds.shape[1]} (số token) và "
          f"{example_embeds.shape[2]} (chiều embedding) nếu khác kỳ vọng — ip_adapter_sdxl.cpp "
          f"tự đọc shape thật từ tensor lúc chạy (không hardcode), nên KHÔNG bắt buộc khớp "
          f"con số cụ thể, nhưng nên đối chiếu nếu ảnh ra sai để loại trừ nguyên nhân này.")
    print("\n=== CHƯA LÀM (Phase 2c/2d — SAU KHI Phase 2 cơ bản này build-test được) ===")
    print("- Depth ControlNet (giải quyết thứ tự trước/sau khi 2+ người chồng lấn, mục 51 ở SD1.5)")
    print("- Mask N-nhân-vật (mỗi người 1 vùng + 1 ảnh tham chiếu riêng, mục 52 ở SD1.5)")
    print("- Regional Prompting / Regional-Mask (mục 56/69/172 ở SD1.5)")
    print("- Smooth Timestep Decay + cân bằng ControlNet (mục 81/97/146/147 ở SD1.5)")
    print("- Non-square (chỉ 1024x1024 vuông ở bản này)")


if __name__ == "__main__":
    main()
