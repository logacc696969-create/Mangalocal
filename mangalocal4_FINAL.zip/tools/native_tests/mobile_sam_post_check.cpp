// mục 288 — harness cho mobile_sam_post.hpp (KHÔNG cần MNN). Dùng bởi tools/test_mobile_sam_core.py.
//   post <W> <H> <low.f32 (256*256)> <out.u8 (W*H)>   : letterbox(W,H) -> postprocessLowRes
//   lb   <W> <H> <rgb.u8>            <out.f32>         : letterboxHWC (xuất 1024*1024*3 float), in "newW newH scale"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include "mobile_sam_post.hpp"
static std::vector<char> slurp(const char *p) { std::ifstream f(p, std::ios::binary); return std::vector<char>((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>()); }
int main(int argc, char **argv) {
  if (argc < 6) return 2;
  const int W = std::atoi(argv[2]), H = std::atoi(argv[3]);
  auto in = slurp(argv[4]);
  if (!std::strcmp(argv[1], "post")) {
    std::vector<unsigned char> rgb((std::size_t)W * H * 3, 0); std::vector<float> hwc; mobilesam::Letterbox lb;
    if (!mobilesam::letterboxHWC(rgb.data(), W, H, &hwc, &lb)) return 3;
    if (in.size() != (std::size_t)mobilesam::kLow * mobilesam::kLow * 4) return 4;
    std::vector<unsigned char> m;
    if (!mobilesam::postprocessLowRes((const float *)in.data(), lb, W, H, &m)) return 5;
    std::ofstream(argv[5], std::ios::binary).write((const char *)m.data(), m.size());
    return 0;
  }
  if (!std::strcmp(argv[1], "lb")) {
    if (in.size() != (std::size_t)W * H * 3) return 4;
    std::vector<float> hwc; mobilesam::Letterbox lb;
    if (!mobilesam::letterboxHWC((const unsigned char *)in.data(), W, H, &hwc, &lb)) return 3;
    std::ofstream(argv[5], std::ios::binary).write((const char *)hwc.data(), hwc.size() * 4);
    std::printf("%d %d %.9f\n", lb.newW, lb.newH, lb.scale);
    return 0;
  }
  return 2;
}
