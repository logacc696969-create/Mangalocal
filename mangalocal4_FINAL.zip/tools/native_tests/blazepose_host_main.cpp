// mục 280 — chạy THẬT blazepose_wrapper.cpp trên máy chủ (không phải Android): include thẳng wrapper rồi gọi BlazePoseWrapper::run.
// Dùng bởi tools/test_blazepose_native.py (liên kết với _mnncengine*.so của gói pip MNN, có xuất ký hiệu C++ của MNN).
// Cách dùng: blazepose_host_main <thư mục có blazepose_*.mnn> <crop.f32 (256*256*3 float RGB 0..1, HWC)> <out.f32>
#include "../../app/src/main/jni/blazepose_wrapper.cpp"
#include <cstdio>
int main(int argc, char** argv) {
    if (argc < 4) { std::fprintf(stderr, "usage: %s modelDir crop.f32 out.f32\n", argv[0]); return 2; }
    BlazePoseWrapper w(argv[1]);
    if (!w.ok) { std::fprintf(stderr, "wrapper khong khoi tao duoc\n"); return 3; }
    std::vector<float> in(256 * 256 * 3);
    FILE* f = std::fopen(argv[2], "rb");
    if (!f || std::fread(in.data(), sizeof(float), in.size(), f) != in.size()) { std::fprintf(stderr, "khong doc du crop\n"); return 4; }
    std::fclose(f);
    auto out = w.run(in.data(), (int)in.size());
    if (out.empty()) { std::fprintf(stderr, "run tra mang rong\n"); return 5; }
    FILE* g = std::fopen(argv[3], "wb"); std::fwrite(out.data(), sizeof(float), out.size(), g); std::fclose(g);
    std::printf("ok %zu float, co_nguoi=%.3f\n", out.size(), out[0]);
    return 0;
}
