#!/usr/bin/env python3
"""Mô phỏng Python (mục 233 + 235 TECHNICAL_STATUS.md) cho PageLayout, cắt dải Webtoon và
ScaleConsistencyChecker. Chép lại NGUYÊN công thức từ PublishExporter.kt (mục 247: thêm RTL — phần đối chiếu NGUỒN Kotlin ở cuối main() đọc trực tiếp file) / ScaleConsistencyChecker.kt
(không có kotlinc trong sandbox) -> kiểm chứng HÌNH HỌC/SỐ HỌC, không phải biên dịch Kotlin.
Sửa Kotlin thì sửa lại file này."""
import statistics

def eff(t, n):
    if n <= 1: return 'SPLASH'
    if t == 'GRID_2X2': return {2: 'STACK_2', 3: 'ONE_PLUS_TWO'}.get(n, 'GRID_2X2')
    if t == 'ONE_PLUS_TWO': return 'STACK_2' if n == 2 else 'ONE_PLUS_TWO'
    return t

def rows(c, g, k):
    l, t, r, b = c; rh = ((b - t) - g * (k - 1)) / k
    return [(l, t + i * (rh + g), r, t + i * (rh + g) + rh) for i in range(k)]

def cells_ltr(t, n, c, g):
    l, tp, r, b = c; w, h = r - l, b - tp
    e = eff(t, n)
    if e == 'SPLASH': return [c]
    if e == 'STACK_2': return rows(c, g, 2)
    if e == 'FOUR_KOMA': return rows(c, g, max(2, min(4, n)))
    cw, ch = (w - g) / 2, (h - g) / 2
    if e == 'GRID_2X2':
        return [(l, tp, l + cw, tp + ch), (l + cw + g, tp, r, tp + ch), (l, tp + ch + g, l + cw, b), (l + cw + g, tp + ch + g, r, b)]
    return [(l, tp, r, tp + ch), (l, tp + ch + g, l + cw, b), (l + cw + g, tp + ch + g, r, b)]

def cells(t, n, c, g, rtl=False):
    base = cells_ltr(t, n, c, g)
    if not rtl: return base
    return [(c[0] + c[2] - x[2], x[1], c[0] + c[2] - x[0], x[3]) for x in base]

def gutter(p): return 27 if p <= 150 else 36 if p <= 300 else 45 if p <= 500 else 54 if p <= 700 else 63

PROFILES = {'A4': (595, 842, False, False), 'KDP_6X9': (432, 648, False, True), 'KDP_6X9_BLEED': (441, 666, True, True)}

def content(profile, pg, total, rtl=False):
    w, h, bleed, kdp = PROFILES[profile]
    if not kdp: return (12, 12, w - 12, h - 12)
    outside = 27 if bleed else 18; inside = gutter(total); right_hand = (pg % 2 == 0) if rtl else (pg % 2 == 1)
    return (inside if right_hand else outside, outside, w - (outside if right_hand else inside), h - outside)

def overlap(a, b):
    return max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))

def check(name, cond):
    print(('PASS ' if cond else 'FAIL ') + name); return cond

def webtoon(heights_scaled, seg_h=1280, gap=24):
    """Trả (danh sách chiều cao từng dải, tổng pixel panel đã vẽ)."""
    segs, seg_y, drawn = [], 0, 0
    def flush(used):
        nonlocal seg_y
        if used > 0: segs.append(used)
        seg_y = 0
    for sh in heights_scaled:
        src = 0
        while src < sh:
            take = min(seg_h - seg_y, sh - src); seg_y += take; src += take; drawn += take
            if seg_y >= seg_h: flush(seg_y)
        seg_y = min(seg_y + gap, seg_h)
        if seg_y >= seg_h: flush(seg_y)
    flush(seg_y)
    return segs, drawn

def scale_check(entries, thr=0.20, min_torso=0.05):
    by = {}
    for panel, group, torso, boxes in entries:
        if torso < min_torso: continue
        for label, h in boxes:
            if h <= 0: continue
            by.setdefault((group, label.strip().lower()), []).append((panel, h / torso))
    out = []
    for (group, label), obs in by.items():
        if len(obs) < 2: continue
        ratios = sorted(r for _, r in obs)
        ref = obs[0][1] if len(obs) == 2 else statistics.median(ratios)
        if ref <= 0: continue
        for i, (panel, r) in enumerate(obs):
            if len(obs) == 2 and i == 0: continue
            dev = abs(r - ref) / ref
            if dev > thr: out.append((label, group, panel, dev))
    return sorted(out, key=lambda x: x[2])

def main():
    ok = True
    # --- KDP: kích thước trang (đã tra cứu KDP: 6x9 có bleed = 6.125 x 9.25 in) ---
    ok &= check('KDP 6x9 có bleed = 6.125x9.25 in = 441x666 pt', PROFILES['KDP_6X9_BLEED'][:2] == (round(6.125 * 72), round(9.25 * 72)))
    ok &= check('KDP 6x9 không bleed = 432x648 pt', PROFILES['KDP_6X9'][:2] == (432, 648))
    c1, c2 = content('KDP_6X9_BLEED', 1, 100), content('KDP_6X9_BLEED', 2, 100)
    ok &= check('trang lẻ: lề trong (trái) 27pt=0.375in, lề ngoài (phải) 27pt', c1[0] == 27 and 441 - c1[2] == 27)
    ok &= check('trang chẵn: lề ngoài trái, lề trong phải', c2[0] == 27 and 441 - c2[2] == 27)
    cn = content('KDP_6X9', 1, 100)
    ok &= check('không bleed: lề ngoài/trên/dưới >= 0.25in=18pt, trong 27pt', cn[1] == 18 and 648 - cn[3] == 18 and cn[0] == 27 and 432 - cn[2] == 18)
    ok &= check('gutter tăng theo số trang (27->63pt)', gutter(24) == 27 and gutter(150) == 27 and gutter(200) > 27 and gutter(800) == 63)

    # --- Bố cục: mọi ô trong vùng nội dung, không chồng nhau, đúng số ô ---
    for prof in PROFILES:
        for t, per in [('STACK_2', 2), ('GRID_2X2', 4), ('ONE_PLUS_TWO', 3), ('FOUR_KOMA', 4), ('SPLASH', 1)]:
            good = True
            for n in range(1, per + 1):
                c = content(prof, 1, 20)
                cs = cells(t, n, c, 8)
                inside = all(x[0] >= c[0] - 1e-6 and x[1] >= c[1] - 1e-6 and x[2] <= c[2] + 1e-6 and x[3] <= c[3] + 1e-6 for x in cs)
                nov = all(overlap(cs[i], cs[j]) < 1e-6 for i in range(len(cs)) for j in range(i + 1, len(cs)))
                enough = len(cs) >= n
                pos = all((x[2] - x[0]) > 0 and (x[3] - x[1]) > 0 for x in cs)
                good &= inside and nov and enough and pos
            ok &= check(f'{prof}/{t}: ô trong lề, không chồng, đủ ô cho 1..{per} panel', good)


    # --- Mục 247: manga phải -> trái (quy tắc KDP G201857950: RTL => số chẵn ở trang PHẢI, số lẻ ở trang TRÁI) ---
    r1, r2 = content('KDP_6X9', 1, 100, True), content('KDP_6X9', 2, 100, True)
    ok &= check('RTL trang 1 (trang trái): lề trong 27pt nằm bên PHẢI, lề ngoài 18pt bên trái', r1[0] == 18 and 432 - r1[2] == 27)
    ok &= check('RTL trang 2 (trang phải): lề trong 27pt nằm bên TRÁI', r2[0] == 27 and 432 - r2[2] == 18)
    ok &= check('RTL: trang n có gutter ngược phía với LTR cùng trang n',
                all(abs((content('KDP_6X9', n, 200, True)[0]) - (content('KDP_6X9', n, 200, False)[0])) > 1 for n in range(1, 9)))
    ok &= check('RTL không đổi lề trên/dưới và tổng bề rộng nội dung',
                all(content('KDP_6X9_BLEED', n, 320, True)[1::2] == content('KDP_6X9_BLEED', n, 320, False)[1::2]
                    and abs((content('KDP_6X9_BLEED', n, 320, True)[2] - content('KDP_6X9_BLEED', n, 320, True)[0])
                            - (content('KDP_6X9_BLEED', n, 320, False)[2] - content('KDP_6X9_BLEED', n, 320, False)[0])) < 1e-6
                    for n in range(1, 7)))
    ok &= check('A4 (không KDP): lề đối xứng nên RTL không đổi vùng nội dung', content('A4', 1, 10, True) == content('A4', 1, 10, False))
    cg = content('KDP_6X9', 2, 20, True)
    ltr_g, rtl_g = cells('GRID_2X2', 4, cg, 8), cells('GRID_2X2', 4, cg, 8, True)
    ok &= check('RTL lưới 2x2: ô đọc đầu tiên (ô 0) nằm bên PHẢI, ô 1 bên trái cùng hàng',
                rtl_g[0][0] > rtl_g[1][0] and abs(rtl_g[0][1] - rtl_g[1][1]) < 1e-6 and ltr_g[0][0] < ltr_g[1][0])
    mir = lambda cs, c: [(c[0] + c[2] - x[2], x[1], c[0] + c[2] - x[0], x[3]) for x in cs]
    base3 = cells('ONE_PLUS_TWO', 3, cg, 8)
    ok &= check('RTL: lật 2 lần = bản gốc (phép đối xứng) và lật 1 lần KHÁC bản gốc ở ô dưới',
                all(abs(a - b) < 1e-6 for x, y in zip(mir(mir(base3, cg), cg), base3) for a, b in zip(x, y))
                and abs(mir(base3, cg)[1][0] - base3[1][0]) > 1)
    ok &= check('RTL: ONE_PLUS_TWO — ô 1 (đọc trước) ở dưới-PHẢI, ô 2 ở dưới-trái; ô 0 (rộng) giữ nguyên',
                cells('ONE_PLUS_TWO', 3, cg, 8, True)[1][0] > cells('ONE_PLUS_TWO', 3, cg, 8, True)[2][0]
                and all(abs(a - b) < 1e-6 for a, b in zip(cells('ONE_PLUS_TWO', 3, cg, 8, True)[0], base3[0])))
    for prof in PROFILES:
        for t, per in [('STACK_2', 2), ('GRID_2X2', 4), ('ONE_PLUS_TWO', 3), ('FOUR_KOMA', 4), ('SPLASH', 1)]:
            good = True
            for pg in (1, 2, 3):
                for n in range(1, per + 1):
                    c = content(prof, pg, 20, True)
                    cs = cells(t, n, c, 8, True)
                    good &= all(x[0] >= c[0] - 1e-6 and x[2] <= c[2] + 1e-6 and x[1] >= c[1] - 1e-6 and x[3] <= c[3] + 1e-6 for x in cs)
                    good &= all(overlap(cs[i], cs[j]) < 1e-6 for i in range(len(cs)) for j in range(i + 1, len(cs)))
                    good &= {tuple(round(v, 4) for v in (x[1], x[3], x[2] - x[0])) for x in cs} == {tuple(round(v, 4) for v in (x[1], x[3], x[2] - x[0])) for x in cells(t, n, c, 8, False)}
            ok &= check(f'RTL {prof}/{t}: ô trong lề, không chồng, cùng tập kích thước/hàng với LTR', good)

    # --- Mục 247: đối chiếu NGUỒN Kotlin thật (đọc file, không chép công thức) ---
    import re, os
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app', 'src', 'main', 'java', 'com', 'mangalocal')
    rd = lambda *p: open(os.path.join(base, *p), encoding='utf8').read()
    pe, mp, md, vm, st = rd('pipeline', 'PublishExporter.kt'), rd('pipeline', 'MangaPipeline.kt'), rd('model', 'Models.kt'), rd('ui', 'MainViewModel.kt'), rd('ui', 'SettingsScreen.kt')
    ok &= check('Kotlin: contentRect có tham số rtl và lật điều kiện trang phải', 'totalPages: Int, rtl: Boolean = false' in pe and 'if (rtl) pageNumber1 % 2 == 0 else pageNumber1 % 2 == 1' in pe)
    ok &= check('Kotlin: cells(rtl) lật ngang quanh vùng nội dung', 'c.left + c.right - r.right' in pe and 'c.left + c.right - r.left' in pe)
    ok &= check('Kotlin: exportPdf truyền rtl cho cả contentRect và cells', 'contentRect(profile, idx + 1, plan.size, rtl)' in pe and 'content, gutter, rtl)' in pe)
    ok &= check('Kotlin: ExportExtras.rightToLeft kéo theo usesCustomPdf', 'val rightToLeft: Boolean = false' in pe and '|| rightToLeft' in pe)
    ok &= check('Kotlin: MangaPipeline truyền extras.rightToLeft vào exportPdf', 'extras.pageProfile, extras.rightToLeft)' in mp)
    ok &= check('Kotlin: Settings -> ViewModel -> Extras nối đủ', 'exportRightToLeft: Boolean = false' in md and 'rightToLeft = st.exportRightToLeft' in vm
                and 'settings.exportRightToLeft' in st and 'copy(exportRightToLeft = it)' in st)
    ok &= check('Kotlin: metadata ghi readingDirection', '"readingDirection"' in pe)
    ok &= check('Kotlin: bảng gutter KDP khớp bảng chính thức 24-150/151-300/301-500/501-700/701-828 (27/36/45/54/63pt)',
                all(x in pe for x in ['pages <= 150 -> 27f', 'pages <= 300 -> 36f', 'pages <= 500 -> 45f', 'pages <= 700 -> 54f', 'else -> 63f']))
    off = dict(zip((150, 300, 500, 700, 828), (0.375, 0.5, 0.625, 0.75, 0.875)))
    ok &= check('gutter(pages) khớp bảng KDP chính thức (inch*72) tại mọi biên băng', all(gutter(p) == round(v * 72) for p, v in off.items()) and gutter(151) == 36 and gutter(301) == 45 and gutter(501) == 54 and gutter(701) == 63)

    # --- Webtoon: bảo toàn chiều cao, mỗi dải <= 1280 ---
    segs, drawn = webtoon([800, 800, 800, 1000, 400])
    ok &= check('webtoon: mỗi dải <= 1280px', all(s <= 1280 for s in segs))
    ok &= check('webtoon: không mất pixel panel (tổng vẽ = tổng scaled)', drawn == 800 * 3 + 1000 + 400)
    ok &= check('webtoon: số dải hợp lý', 4 <= len(segs) <= 7)
    segs2, _ = webtoon([100])
    ok &= check('webtoon: 1 panel nhỏ -> 1 dải cắt đúng chiều cao dùng', len(segs2) == 1 and segs2[0] == 100 + 24)

    # --- Scale checker ---
    e_ok = [(0, 'phòng', 0.30, [('bàn', 0.15)]), (1, 'phòng', 0.30, [('bàn', 0.16)]), (2, 'phòng', 0.29, [('bàn', 0.15)])]
    ok &= check('vật thể nhất quán (<20%) -> không cảnh báo', scale_check(e_ok) == [])
    e_bad = [(0, 'phòng', 0.30, [('bàn', 0.15)]), (1, 'phòng', 0.30, [('bàn', 0.15)]), (2, 'phòng', 0.30, [('bàn', 0.26)])]
    w = scale_check(e_bad)
    ok &= check('bàn cao gấp ~1.7 ở panel 3 -> cảnh báo đúng panel', len(w) == 1 and w[0][2] == 2)
    ok &= check('đổi zoom (cả người lẫn bàn cùng to) -> KHÔNG cảnh báo', scale_check([(0, 'a', 0.2, [('bàn', 0.10)]), (1, 'a', 0.4, [('bàn', 0.20)])]) == [])
    ok &= check('khác nhóm cảnh -> không so với nhau', scale_check([(0, 'phòng', 0.3, [('bàn', 0.15)]), (1, 'quán', 0.3, [('bàn', 0.30)])]) == [])
    ok &= check('2 panel: panel sau lệch -> cờ panel sau', [x[2] for x in scale_check([(0, 'a', 0.3, [('ghế', 0.10)]), (1, 'a', 0.3, [('ghế', 0.20)])])] == [1])
    ok &= check('thân quá nhỏ bị bỏ qua (tránh chia cho ~0)', scale_check([(0, 'a', 0.01, [('bàn', 0.1)]), (1, 'a', 0.3, [('bàn', 0.1)])]) == [])
    ok &= check('nhãn khác hoa/thường vẫn gom cùng', len(scale_check([(0, 'a', 0.3, [('Bàn', 0.15)]), (1, 'a', 0.3, [('bàn', 0.15)]), (2, 'a', 0.3, [('BÀN', 0.30)])])) == 1)

    print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI')
    raise SystemExit(0 if ok else 1)

if __name__ == '__main__':
    main()
