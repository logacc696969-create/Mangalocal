#!/usr/bin/env python3
"""mục 268 — kiểm thử `tools/lora_to_mnn_spec.py` (bước (e) của mục 264.3: LoRA safetensors + danh sách op của UNet -> spec.txt + .bin cho lora_attach_branch).

Chạy THẬT công cụ (không mô phỏng lại logic của nó) trên: tệp safetensors do test tự ghi (F32/F16/BF16, định dạng kohya và PEFT), danh sách op mô phỏng đúng định dạng `printf` của
`lora_attach_branch --list` và đúng quy ước tên torch.onnx.export (`/down_blocks.0/attentions.0/.../attn1/to_q/MatMul`). Kiểm: tên khoá -> op, kích thước từng tensor, scale = alpha/rank*strength
(kể cả rslora/--alpha/adapter_config), nội dung .bin KHỚP TỪNG BIT với numpy (thứ tự [r][in][kh][kw] và [out][r]), mọi trường hợp "không gắn được" phải LỖI (mã 3) và KHÔNG ghi spec,
tệp hỏng không ném traceback, `spec.txt` đúng văn phạm của parseSpec trong C++ (kiểm bằng bộ phân tích viết lại độc lập) và kích thước .bin đúng r*in*kh*kw*4 / out*r*4.
Cuối cùng THỬ PHÁ MÃ: mỗi đột biến của công cụ PHẢI làm ít nhất một phép kiểm đỏ.
KHÔNG chứng minh: bản đồ tên op đúng trên UNet thật (chưa có file thật; danh sách op ở đây MÔ PHỎNG theo quy ước), lora_attach_branch chấp nhận spec trên UNet thật, kết quả ảnh.
Cần numpy. Thuần Python (không kotlinc/MNN).
"""
import contextlib
import importlib.util
import io
import json
import math
import os
import re
import shutil
import struct
import sys
import tempfile

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REAL_TOOL = os.path.join(ROOT, 'tools', 'lora_to_mnn_spec.py')
_mod_cache = {}


def load_tool(path):
    if path not in _mod_cache:
        spec = importlib.util.spec_from_file_location('lora_tool_%d' % len(_mod_cache), path)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        _mod_cache[path] = m
    return _mod_cache[path]


# ───────────────────────── tiện ích dựng dữ liệu ─────────────────────────
def write_st(path, tensors):
    """tensors: {tên: (np.ndarray float32, 'F32'|'F16'|'BF16')} -> safetensors."""
    hdr, blobs, off = {}, [], 0
    for k, (a, dt) in tensors.items():
        a = np.ascontiguousarray(a, dtype=np.float32)
        if dt == 'F32':
            b = a.astype('<f4').tobytes()
        elif dt == 'F16':
            b = a.astype('<f2').tobytes()
        elif dt == 'BF16':
            b = (a.view(np.uint32) >> 16).astype('<u2').tobytes()
        else:
            raise ValueError(dt)
        hdr[k] = {'dtype': dt, 'shape': list(a.shape), 'data_offsets': [off, off + len(b)]}
        off += len(b)
        blobs.append(b)
    h = json.dumps(hdr).encode()
    h += b' ' * ((8 - len(h) % 8) % 8)
    with open(path, 'wb') as f:
        f.write(struct.pack('<Q', len(h)) + h + b''.join(blobs))


def op_line(idx, typ, name, extra):
    return '%4d  %-18s name=%s  out=%s  %s\n' % (idx, typ, name, name + '_output_0', extra)


def conv(name, i, o, ky=1, kx=1, g=1, flags=''):
    return ('Convolution', name, f'in={i} out={o} k={ky}x{kx} group={g}' + flags)


def ops_text(ops):
    s = ''.join(op_line(10 + n, t, nm, ex) for n, (t, nm, ex) in enumerate(ops))
    return s + '-- %d op (Convolution/Depthwise/ConvInt8/MatMul/InnerProduct) trong 912 op\n' % len(ops)


TB = '/down_blocks.0/attentions.0/transformer_blocks.0'
OPS = [
    conv('/conv_in/Conv', 4, 6, 3, 3),
    conv(TB + '/attn1/to_q/MatMul', 8, 8),
    conv(TB + '/attn2/to_k/MatMul', 12, 8),
    conv(TB + '/attn1/to_out.0/MatMul', 8, 8),
    conv(TB + '/ff/net.0/proj/MatMul', 8, 20),
    conv('/down_blocks.0/attentions.0/proj_in/Conv', 8, 8, 1, 1),
    conv('/down_blocks.0/resnets.0/conv1/Conv', 8, 10, 3, 3),
    conv('/mid_block/attentions.0/transformer_blocks.0/attn1/to_v/MatMul', 8, 8),
    ('MatMul', '/up_blocks.1/resnets.0/time_emb_proj/MatMul', '(KHÔNG hỗ trợ gắn nhánh)'),
    ('ConvolutionDepthwise', '/up_blocks.1/resnets.0/dw/Conv', '(KHÔNG hỗ trợ gắn nhánh)'),
    conv('/up_blocks.2/resnets.0/gconv/Conv', 8, 8, 3, 3, g=2),
    conv('/up_blocks.2/resnets.0/sq/Conv', 8, 8, 1, 1, flags=' symmetricQuan'),
]
FLAT = {  # khoá phẳng kohya <-> op mô phỏng
    'conv_in': (4, 6, 3, 3), 'down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_q': (8, 8, 1, 1),
    'down_blocks_0_attentions_0_transformer_blocks_0_attn2_to_k': (12, 8, 1, 1), 'down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_out_0': (8, 8, 1, 1),
    'down_blocks_0_attentions_0_transformer_blocks_0_ff_net_0_proj': (8, 20, 1, 1), 'down_blocks_0_attentions_0_proj_in': (8, 8, 1, 1),
    'down_blocks_0_resnets_0_conv1': (8, 10, 3, 3), 'mid_block_attentions_0_transformer_blocks_0_attn1_to_v': (8, 8, 1, 1),
}
OPNAME = {'conv_in': '/conv_in/Conv', 'down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_q': TB + '/attn1/to_q/MatMul',
          'down_blocks_0_attentions_0_transformer_blocks_0_attn2_to_k': TB + '/attn2/to_k/MatMul', 'down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_out_0': TB + '/attn1/to_out.0/MatMul',
          'down_blocks_0_attentions_0_transformer_blocks_0_ff_net_0_proj': TB + '/ff/net.0/proj/MatMul', 'down_blocks_0_attentions_0_proj_in': '/down_blocks.0/attentions.0/proj_in/Conv',
          'down_blocks_0_resnets_0_conv1': '/down_blocks.0/resnets.0/conv1/Conv', 'mid_block_attentions_0_transformer_blocks_0_attn1_to_v': '/mid_block/attentions.0/transformer_blocks.0/attn1/to_v/MatMul'}


def lora_pair(rng, flat, r, four_d_a=None, dt='F32'):
    """-> (down, up) float32 đúng kích thước op `flat`. four_d_a: ép down 4D (kohya conv 1x1); mặc định: 4D nếu kernel > 1."""
    i, o, ky, kx = FLAT[flat]
    four = (ky, kx) != (1, 1) if four_d_a is None else four_d_a
    down = rng.integers(-8, 9, size=(r, i, ky, kx) if four else (r, i)).astype(np.float32) / 8.0
    up = rng.integers(-8, 9, size=(o, r, 1, 1) if (four and (ky, kx) != (1, 1) or four_d_a) else (o, r)).astype(np.float32) / 8.0
    return down, up


class Suite:
    def __init__(self, tool_path, verbose):
        self.tool = load_tool(tool_path)
        self.tool_path = tool_path
        self.verbose = verbose
        self.failed = []
        self.n = 0
        self.tmp = tempfile.mkdtemp()
        self.seq = 0

    def check(self, name, cond, detail=''):
        self.n += 1
        if not cond:
            self.failed.append(name)
        if self.verbose:
            print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + str(detail)[:300]) if (detail and not cond) else ''))

    def d(self, tag='d'):
        self.seq += 1
        p = os.path.join(self.tmp, f'{tag}{self.seq}')
        os.makedirs(p, exist_ok=True)
        return p

    def run(self, argv):
        out, err = io.StringIO(), io.StringIO()
        try:
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                rc = self.tool.main(argv)
        except SystemExit as e:
            rc = e.code if isinstance(e.code, int) else 2
        except BaseException as e:   # ngoại lệ lọt ra = traceback với người dùng = lỗi của công cụ
            rc, err = 1, io.StringIO('Traceback: %s: %s' % (type(e).__name__, e))
        return rc, out.getvalue(), err.getvalue()

    def go(self, tensors, ops=None, extra=(), tag='c', ops_raw=None):
        """ghi LoRA + danh sách op, chạy công cụ -> (rc, stdout, stderr, thư mục ra, đường dẫn spec). ops_raw: nội dung --list nguyên văn (vd đầu ra THẬT)."""
        w = self.d(tag)
        lp, op_, out = os.path.join(w, 'l.safetensors'), os.path.join(w, 'ops.txt'), os.path.join(w, 'out')
        write_st(lp, tensors)
        open(op_, 'w', encoding='utf-8').write(ops_raw if ops_raw is not None else ops_text(OPS if ops is None else ops))
        rc, so, se = self.run(['--lora', lp, '--ops', op_, '--out', out, *extra])
        return rc, so, se, out, os.path.join(out, 'spec.txt')

    def cleanup(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


def ref_parse_spec(path):
    """viết lại độc lập parseSpec của C++ (lora_attach_branch.cpp): bỏ sau '#', 5 trường, rank>0, scale hữu hạn. -> list[(op, rank, scale, A, B)] hoặc ném ValueError."""
    res = []
    for ln, line in enumerate(open(path, encoding='utf-8'), 1):
        line = line.split('#', 1)[0]
        f = line.split()
        if not f:
            continue
        if len(f) != 5:
            raise ValueError(f'dòng {ln}: {len(f)} trường (cần 5)')
        rank = int(f[1])
        scale = float(f[2])
        if rank <= 0 or not math.isfinite(scale):
            raise ValueError(f'dòng {ln}: rank/scale không hợp lệ')
        res.append((f[0], rank, scale, f[3], f[4]))
    return res


def kohya(flat, down, up, alpha=None, dt='F32'):
    p = 'lora_unet_' + flat
    t = {p + '.lora_down.weight': (down, dt), p + '.lora_up.weight': (up, dt)}
    if alpha is not None:
        t[p + '.alpha'] = (np.array(alpha, dtype=np.float32), 'F32')
    return t


def run_all(tool_path, verbose):
    S = Suite(tool_path, verbose)
    chk = S.check
    rng = np.random.default_rng(268)
    T = S.tool
    try:
        # ── T1 kohya đầy đủ: 8 module, đủ kiểu (Linear→conv 1x1 2D, conv 1x1 4D, conv 3x3, conv_in 3x3)
        r = 4
        tens, ref = {}, {}
        for n_, flat in enumerate(sorted(FLAT)):
            down, up = lora_pair(rng, flat, r, four_d_a=(True if flat.endswith('proj_in') else None))
            alpha = [None, 2.0, 4.0, 8.0, 1.0, 3.0, 16.0, 4.0][n_]
            tens.update(kohya(flat, down, up, alpha))
            ref[flat] = (down, up, r if alpha is None else alpha)
        rc, so, se, out, spec = S.go(tens)
        chk('T1 kohya 8 module (linear 2D, conv1x1 4D, conv3x3): mã thoát 0', rc == 0, (so + se)[-400:])
        if rc == 0:
            try:
                rows = ref_parse_spec(spec)
            except ValueError as e:
                rows = []
                chk('T1b spec.txt đúng văn phạm parseSpec', False, str(e))
            chk('T1b spec.txt đúng văn phạm parseSpec của C++ (5 trường, rank>0, scale hữu hạn) và đủ 8 dòng', len(rows) == 8, len(rows))
            byop = {x[0]: x for x in rows}
            allok = len(byop) == 8
            why = ''
            for flat, (down, up, alpha) in ref.items():
                row = byop.get(OPNAME[flat])
                if row is None:
                    allok = False; why = 'thiếu op ' + OPNAME[flat]; continue
                _, rk, sc, ap, bp = row
                i, o, ky, kx = FLAT[flat]
                if rk != r or abs(sc - alpha / r) > 1e-9:
                    allok = False; why = f'{flat}: rank={rk} scale={sc} (mong đợi {r}, {alpha / r})'
                a_bytes, b_bytes = open(ap, 'rb').read(), open(bp, 'rb').read()
                if len(a_bytes) != r * i * ky * kx * 4 or len(b_bytes) != o * r * 4:
                    allok = False; why = f'{flat}: kích thước bin {len(a_bytes)}/{len(b_bytes)}'
                if a_bytes != down.reshape(r, -1).astype('<f4').tobytes() or b_bytes != up.reshape(o, r).astype('<f4').tobytes():
                    allok = False; why = f'{flat}: nội dung bin lệch'
            chk('T1c tên op, rank, scale=alpha/rank, kích thước và NỘI DUNG .bin khớp từng bit với numpy ([r][in][kh][kw] và [out][r])', allok, why)
            chk('T1d báo cáo nêu 8 module khớp và có lệnh tiếp theo', 'khớp & ghi 8' in so and 'lora_attach_branch' in so, so[-300:])
            # xác định (cùng đầu vào -> cùng spec/bin)
            rc2, _, _, out2, spec2 = S.go(tens)
            same = rc2 == 0 and open(spec2).read().replace(out2, 'D') == open(spec).read().replace(out, 'D') and all(
                open(os.path.join(out, f), 'rb').read() == open(os.path.join(out2, f), 'rb').read() for f in sorted(os.listdir(out)) if f.endswith('.bin')) and len([f for f in os.listdir(out) if f.endswith('.bin')]) == 16
            chk('T1e xác định: chạy hai lần cho spec và .bin y hệt', same)

        # ── T2 strength
        flat = 'down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_q'
        down, up = lora_pair(rng, flat, 4)
        base = kohya(flat, down, up, 8.0)
        for st_, want in ((0.5, 1.0), (-1.0, -2.0), (0.0, 0.0)):
            rc, so, se, out, spec = S.go(base, extra=['--strength', repr(st_)])
            sc = ref_parse_spec(spec)[0][2] if rc == 0 else None
            chk(f'T2 --strength {st_} => scale {want}', rc == 0 and sc is not None and abs(sc - want) < 1e-9, (rc, sc, se[-200:]))
        rc, so, se, out, spec = S.go(base, extra=['--strength', 'nan'])
        chk('T2b --strength nan => mã 2 (lỗi dùng) và không ghi spec', rc == 2 and not os.path.exists(spec), (rc, se[-150:]))
        rc, so, se, out, spec = S.go(base, extra=['--strength', 'abc'])
        chk('T2c --strength abc => mã 2', rc == 2, rc)
        for bad_alpha_arg in ('0', '-1', 'inf', 'nan'):
            chk(f'T2d --alpha {bad_alpha_arg} => mã 2 (alpha phải hữu hạn và > 0)', S.go(base, extra=['--alpha', bad_alpha_arg])[0] == 2)

        # ── T3 PEFT/diffusers
        path = TB + '/attn1/to_q'.replace('/', '.')
        pe = 'down_blocks.0.attentions.0.transformer_blocks.0.attn1.to_q'
        for pref, mid in (('unet.', ''), ('base_model.model.', ''), ('', ''), ('unet.', '.default')):
            t = {f'{pref}{pe}.lora_A{mid}.weight': (down, 'F32'), f'{pref}{pe}.lora_B{mid}.weight': (up, 'F32')}
            rc, so, se, out, spec = S.go(t)
            ok_ = rc == 0 and len(ref_parse_spec(spec)) == 1 and abs(ref_parse_spec(spec)[0][2] - 1.0) < 1e-9
            chk(f'T3 PEFT khoá "{pref}…lora_A{mid}.weight": khớp, alpha mặc định = rank => scale 1', ok_, (rc, so + se)[-300:] if not ok_ else '')
        t = {f'unet.{pe}.lora_A.weight': (down, 'F32'), f'unet.{pe}.lora_B.weight': (up, 'F32')}
        chk('T3b PEFT không alpha: báo cáo cảnh báo "alpha=rank (scale 1)"', 'alpha=rank' in S.go(t)[1])
        rc, so, se, out, spec = S.go(t, extra=['--alpha', '8'])
        chk('T3c --alpha 8, rank 4 => scale 2', rc == 0 and abs(ref_parse_spec(spec)[0][2] - 2.0) < 1e-9)
        w = S.d('cfg'); cfgp = os.path.join(w, 'adapter_config.json')
        json.dump({'lora_alpha': 16, 'r': 4}, open(cfgp, 'w'))
        rc, so, se, out, spec = S.go(t, extra=['--adapter-config', cfgp])
        chk('T3d adapter_config lora_alpha=16, rank 4 => scale 4', rc == 0 and abs(ref_parse_spec(spec)[0][2] - 4.0) < 1e-9, (rc, se[-150:]))
        json.dump({'lora_alpha': 16, 'use_rslora': True}, open(cfgp, 'w'))
        rc, so, se, out, spec = S.go(t, extra=['--adapter-config', cfgp])
        chk('T3e use_rslora: scale = alpha/sqrt(rank) = 16/2 = 8', rc == 0 and abs(ref_parse_spec(spec)[0][2] - 8.0) < 1e-9)
        json.dump({'lora_alpha': 16, 'rank_pattern': {'x': 2}}, open(cfgp, 'w'))
        chk('T3f rank_pattern => mã 2 (chưa hỗ trợ, không đoán)', S.go(t, extra=['--adapter-config', cfgp])[0] == 2)
        json.dump({'lora_alpha': 16, 'use_dora': True}, open(cfgp, 'w'))
        chk('T3g use_dora => mã 2', S.go(t, extra=['--adapter-config', cfgp])[0] == 2)
        json.dump({'lora_alpha': 16}, open(cfgp, 'w'))
        rc, so, se, out, spec = S.go(base, extra=['--adapter-config', cfgp])
        chk('T3h alpha trong tệp LoRA (kohya .alpha=8) THẮNG adapter_config (16): scale 2', rc == 0 and abs(ref_parse_spec(spec)[0][2] - 2.0) < 1e-9)

        # ── T4 dtype
        for dt in ('F16', 'BF16'):
            d_, u_ = lora_pair(rng, flat, 4)
            rc, so, se, out, spec = S.go({k: (v[0], dt) for k, v in kohya(flat, d_, u_, 4.0).items()})
            good = False
            if rc == 0:
                row = ref_parse_spec(spec)[0]
                good = open(row[3], 'rb').read() == d_.reshape(4, -1).astype('<f4').tobytes() and open(row[4], 'rb').read() == u_.reshape(8, 4).astype('<f4').tobytes()
            chk(f'T4 {dt}: giá trị float32 sau chuyển đổi khớp từng bit', good, (rc, se[-200:]))

        # ── T5 text-encoder bị bỏ qua nhưng được đếm
        t5 = dict(base)
        t5['lora_te_text_model_encoder_layers_0_self_attn_q_proj.lora_down.weight'] = (np.zeros((4, 8), np.float32), 'F32')
        t5['lora_te2_text_model_encoder_layers_0_self_attn_q_proj.lora_up.weight'] = (np.zeros((8, 4), np.float32), 'F32')
        t5['text_encoder.text_model.encoder.layers.0.self_attn.q_proj.lora_A.weight'] = (np.zeros((4, 8), np.float32), 'F32')
        rc, so, se, out, spec = S.go(t5)
        chk('T5 khoá text-encoder (kohya te/te2 và PEFT) bị bỏ qua, được đếm (3), không phải lỗi', rc == 0 and 'text-encoder bỏ qua 3' in so, (rc, so + se)[-300:])

        # ── T6 khoá lạ / LyCORIS => LỖI, không ghi spec; --allow-unmatched chấp nhận có chủ đích
        t6 = dict(base)
        t6['lora_unet_down_blocks_0_resnets_0_conv2.hada_w1_a'] = (np.zeros((4, 4), np.float32), 'F32')
        rc, so, se, out, spec = S.go(t6)
        chk('T6 khoá LyCORIS (hada) => mã 3 và KHÔNG ghi spec', rc == 3 and not os.path.exists(spec), (rc, os.path.exists(spec)))
        rc, so, se, out, spec = S.go(t6, extra=['--allow-unmatched'])
        chk('T6b --allow-unmatched: mã 0, spec có phần còn lại, báo "THIẾU"', rc == 0 and os.path.exists(spec) and 'THIẾU' in so, (rc, so[-200:]))
        t6b = dict(base)
        t6b['transformer.blocks.0.attn.to_q.lora_A.weight'] = (np.zeros((4, 8), np.float32), 'F32')
        chk('T6c khoá DiT "transformer." => mã 3 (không phải LoRA cho UNet)', S.go(t6b)[0] == 3)

        # ── T7 module không có op
        d2, u2 = lora_pair(rng, flat, 4)
        t7 = dict(base)
        t7.update(kohya('up_blocks_9_attentions_9_to_q', d2, u2, 4.0))
        rc, so, se, out, spec = S.go(t7)
        chk('T7 module LoRA không có op tương ứng => mã 3, nêu đúng tên, KHÔNG ghi spec', rc == 3 and 'up_blocks_9_attentions_9_to_q' in so and not os.path.exists(spec), (rc, so[-250:]))
        rc, so, se, out, spec = S.go(t7, extra=['--allow-unmatched'])
        chk('T7b --allow-unmatched: mã 0, ghi 1 module, cảnh báo thiếu', rc == 0 and len(ref_parse_spec(spec)) == 1 and 'THIẾU' in so)
        t7b = kohya('khong_co_op_nao', d2, u2, 4.0)
        rc, so, se, out, spec = S.go(t7b, extra=['--allow-unmatched'])
        chk('T7c không module nào khớp: mã 3 kể cả khi --allow-unmatched, không ghi spec', rc == 3 and not os.path.exists(spec), (rc, os.path.exists(spec)))

        # ── T8 sai kích thước/rank
        sub = 'down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_q'
        cases = {
            'lora_down sai in': (np.zeros((4, 9), np.float32), up),
            'lora_up sai out': (down, np.zeros((7, 4), np.float32)),
            'rank down/up lệch': (down, np.zeros((8, 3), np.float32)),
            'lora_down 3 chiều': (np.zeros((4, 8, 1), np.float32), up),
            'lora_up 3 chiều (out, r, 1) — kích thước phẳng vẫn khớp nên dễ lọt': (down, np.zeros((8, 4, 1), np.float32)),
            'lora_down 1 chiều': (np.zeros((32,), np.float32), up),
        }
        for nm, (dn, upx) in cases.items():
            rc, so, se, out, spec = S.go(kohya(sub, dn, upx, 4.0))
            chk(f'T8 {nm} => mã 3, nêu module, không ghi spec', rc == 3 and sub in so and not os.path.exists(spec), (rc, so[-250:]))
        c3 = 'down_blocks_0_resnets_0_conv1'
        rc, so, se, out, spec = S.go(kohya(c3, np.zeros((4, 8), np.float32), np.zeros((10, 4), np.float32), 4.0))
        chk('T8b lora_down 2D nhưng op là conv 3x3 => mã 3', rc == 3 and c3 in so, (rc, so[-200:]))
        rc, so, se, out, spec = S.go(kohya(c3, np.zeros((4, 8, 3, 3), np.float32), np.zeros((10, 4, 3, 3), np.float32), 4.0))
        chk('T8c lora_up 4D nhưng kernel 3x3 (phải 1x1) => mã 3', rc == 3 and c3 in so, (rc, so[-200:]))
        rc, so, se, out, spec = S.go({'lora_unet_' + sub + '.lora_down.weight': (down, 'F32')})
        chk('T8d thiếu lora_up => mã 3 nêu "thiếu"', rc == 3 and 'thiếu' in so, (rc, so[-200:]))

        # ── T9 op không gắn được
        for nm, flat9 in (('MatMul', 'up_blocks_1_resnets_0_time_emb_proj'), ('depthwise', 'up_blocks_1_resnets_0_dw'), ('group=2', 'up_blocks_2_resnets_0_gconv'), ('symmetricQuan', 'up_blocks_2_resnets_0_sq')):
            rc, so, se, out, spec = S.go(kohya(flat9, np.zeros((4, 8), np.float32), np.zeros((8, 4), np.float32), 4.0))
            chk(f'T9 module trỏ vào op {nm} => mã 3 "OP KHÔNG GẮN ĐƯỢC"', rc == 3 and 'OP KHÔNG GẮN ĐƯỢC' in so, (rc, so[-250:]))

        fake = OPS + [('InnerProduct', '/up_blocks_3/fake/ip/MatMul', 'in=8 out=8 k=1x1 group=1'), ('ConvInt8', '/up_blocks_3/fake/ci8/Conv', 'in=8 out=8 k=1x1 group=1')]
        for nm, flat9 in (('InnerProduct có sẵn in/out/k', 'up_blocks_3_fake_ip'), ('ConvInt8 có sẵn in/out/k', 'up_blocks_3_fake_ci8')):
            rc, so, se, out, spec = S.go(kohya(flat9, np.zeros((4, 8), np.float32), np.zeros((8, 4), np.float32), 4.0), ops=fake)
            chk(f'T9b {nm}: vẫn là op KHÔNG gắn được (quyết theo LOẠI op, không theo việc dòng có thông tin kênh)', rc == 3 and 'OP KHÔNG GẮN ĐƯỢC' in so, (rc, so[-250:]))

        # ── T10 mơ hồ và ưu tiên op gắn được
        amb = OPS + [conv(TB + '/attn1/to_q/Add', 8, 8)]
        rc, so, se, out, spec = S.go(base, ops=amb)
        chk('T10 hai op gắn được cùng đường dẫn => mã 3 "MƠ HỒ", không đoán', rc == 3 and 'MƠ HỒ' in so, (rc, so[-250:]))
        mix = OPS + [('MatMul', TB + '/attn1/to_q/Add', '(KHÔNG hỗ trợ gắn nhánh)')]
        rc, so, se, out, spec = S.go(base, ops=mix)
        chk('T10b một op gắn được + một op không gắn được cùng đường dẫn => chọn op gắn được', rc == 0 and ref_parse_spec(spec)[0][0] == TB + '/attn1/to_q/MatMul', (rc, so[-200:]))

        # ── T11 cảnh báo relu gộp
        relu_ops = [conv(TB + '/attn1/to_q/MatMul', 8, 8, flags=' relu')]
        rc, so, se, out, spec = S.go(base, ops=relu_ops)
        chk('T11 op đích có relu gộp => có DÒNG CẢNH BÁO riêng (không chỉ dòng lệnh) và lệnh có --unfuse-activation/--emit-base', rc == 0 and 'CẢNH BÁO: 1 op đích có hoạt hoá relu' in so and '--unfuse-activation --emit-base' in so, so[-300:])
        rc, so, se, out, spec = S.go(base)
        chk('T11b không có relu => không có dòng cảnh báo relu và lệnh không có --unfuse-activation', rc == 0 and 'hoạt hoá relu' not in so and '--unfuse-activation' not in so)

        # ── T12 tệp safetensors hỏng
        w = S.d('bad'); opp = os.path.join(w, 'ops.txt'); open(opp, 'w', encoding='utf-8').write(ops_text(OPS))
        good = os.path.join(w, 'good.safetensors'); write_st(good, base)
        data = open(good, 'rb').read()
        bads = {'rỗng': b'', 'ngắn hơn 8 byte': b'abc', 'header khổng lồ': struct.pack('<Q', 10 ** 12) + b'x',
                'header không phải JSON': struct.pack('<Q', 8) + b'notjson!', 'header là mảng JSON': struct.pack('<Q', 8) + b'[1,2,3] ', 'cắt dở dữ liệu': data[:-5],
                'cắt dở header': data[:20]}
        for nm, b in bads.items():
            p = os.path.join(w, 'x.safetensors'); open(p, 'wb').write(b)
            rc, so, se = S.run(['--lora', p, '--ops', opp, '--out', os.path.join(w, 'o')])
            chk(f'T12 tệp hỏng ({nm}) => mã 2, không traceback', rc == 2 and 'Traceback' not in se, (rc, se[-160:]))
        hdr = {'x.lora_down.weight': {'dtype': 'F32', 'shape': [4, 8], 'data_offsets': [0, 64]}}
        h = json.dumps(hdr).encode(); h += b' ' * ((8 - len(h) % 8) % 8)
        p = os.path.join(w, 'shape.safetensors'); open(p, 'wb').write(struct.pack('<Q', len(h)) + h + b'\0' * 64)
        rc, so, se = S.run(['--lora', p, '--ops', opp, '--out', os.path.join(w, 'o')])
        chk('T12a shape [4,8] nhưng chỉ có 64 byte dữ liệu (cần 128) => mã 2, không traceback', rc == 2 and 'Traceback' not in se, (rc, se[-160:]))
        hdr = {'a.lora_down.weight': {'dtype': 'I64', 'shape': [1], 'data_offsets': [0, 8]}}
        h = json.dumps(hdr).encode(); h += b' ' * ((8 - len(h) % 8) % 8)
        p = os.path.join(w, 'i64.safetensors'); open(p, 'wb').write(struct.pack('<Q', len(h)) + h + b'\0' * 8)
        rc, so, se = S.run(['--lora', p, '--ops', opp, '--out', os.path.join(w, 'o')])
        chk('T12b dtype I64 => mã 2 nêu dtype', rc == 2 and 'I64' in se, (rc, se[-160:]))
        rc, so, se = S.run(['--lora', os.path.join(w, 'khong_co.safetensors'), '--ops', opp, '--out', os.path.join(w, 'o')])
        chk('T12c tệp LoRA không tồn tại => mã 2', rc == 2 and 'Traceback' not in se)

        # ── T13 danh sách op hỏng
        for nm, txt in (('rỗng', ''), ('rác', 'xin chào\nkhông phải danh sách op\n'), ('chỉ có dòng tổng kết', '-- 0 op (...) trong 5 op\n')):
            q = os.path.join(w, 'ops_bad.txt'); open(q, 'w', encoding='utf-8').write(txt)
            rc, so, se = S.run(['--lora', good, '--ops', q, '--out', os.path.join(w, 'o2')])
            chk(f'T13 danh sách op {nm} => mã 2', rc == 2 and 'Traceback' not in se, (rc, se[-160:]))

        # ── T14 thư mục đầu ra có khoảng trắng / '#'
        for bad_dir in ('co khoang trang', 'co#thang'):
            rc, so, se, out, spec = S.go(base, extra=[])  # dựng sẵn tệp
            lp = os.path.join(os.path.dirname(out), 'l.safetensors'); op_ = os.path.join(os.path.dirname(out), 'ops.txt')
            rc, so, se = S.run(['--lora', lp, '--ops', op_, '--out', os.path.join(S.d('sp'), bad_dir)])
            chk(f'T14 thư mục đầu ra "{bad_dir}" => mã 2 (spec tách trường bằng khoảng trắng, "#" là chú thích)', rc == 2, (rc, se[-160:]))

        # ── T15 --dry-run
        rc, so, se, out, spec = S.go(base, extra=['--dry-run'])
        chk('T15 --dry-run: mã 0, in báo cáo, KHÔNG ghi tệp nào', rc == 0 and 'khớp & ghi 1' in so and not os.path.exists(out), (rc, os.path.exists(out)))

        # ── T16 trộn kohya + PEFT cho cùng module; alpha không phải số
        mixed = dict(base)
        mixed[f'unet.{pe}.lora_A.weight'] = (down, 'F32'); mixed[f'unet.{pe}.lora_B.weight'] = (up, 'F32')
        chk('T16 cùng một module có cả khoá kohya lẫn PEFT => mã 3', S.go(mixed)[0] == 3)
        bad_alpha = dict(base); bad_alpha['lora_unet_' + sub + '.alpha'] = (np.array([1.0, 2.0], np.float32), 'F32')
        chk('T16b .alpha có 2 phần tử => mã 3', S.go(bad_alpha)[0] == 3)
        one = dict(base); one['lora_unet_' + sub + '.alpha'] = (np.array([8.0], np.float32), 'F32')
        rc, so, se, out, spec = S.go(one)
        chk('T16c .alpha shape (1,) được nhận như số', rc == 0 and abs(ref_parse_spec(spec)[0][2] - 2.0) < 1e-9)

        # ── T17 suy ra tên và khoá (kiểm hàm thuần)
        names = {'/down_blocks.0/attentions.0/transformer_blocks.0/attn1/to_out.0/MatMul': 'down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_out_0',
                 '/mid_block/resnets.1/conv2/Conv': 'mid_block_resnets_1_conv2', '/conv_in/Conv': 'conv_in', '/up_blocks.3/attentions.2/proj_out/Conv': 'up_blocks_3_attentions_2_proj_out',
                 '/down_blocks.1/attentions.0/transformer_blocks.0/ff/net.0/proj/MatMul': 'down_blocks_1_attentions_0_transformer_blocks_0_ff_net_0_proj',
                 'conv_in': 'conv_in', '/x/': 'x', '/a.b/c.d/MatMul': 'a_b_c_d'}
        bad_n = {k: T.op_flat_id(k) for k, v in names.items() if T.op_flat_id(k) != v}
        chk('T17 op_flat_id: bỏ đoạn loại op, "." -> "_", chịu tên không có "/"', not bad_n, bad_n)
        ops_p = T.parse_ops(ops_text(OPS))
        chk('T17b parse_ops: đọc đủ 12 dòng, đúng 8 op gắn được, 4 op không gắn được kèm lý do', len(ops_p) == 12 and sum(o['supported'] for o in ops_p) == 8 and all(o['why'] for o in ops_p if not o['supported']), [(o['name'], o['supported']) for o in ops_p])
        c = [o for o in ops_p if o['name'].endswith('conv1/Conv')][0]
        chk('T17c parse_ops: in/out/kernel của conv 3x3 đọc đúng', (c['in'], c['out'], c['ky'], c['kx'], c['group']) == (8, 10, 3, 3, 1), c)

        # ── T19 DỮ LIỆU THẬT (mục 269): `--list` thật của UNet diffusers thu nhỏ qua torch.onnx.export -> mnnconvert 3.6.1, và 83 module torch thật
        fx = os.path.join(ROOT, 'tools', 'fixtures')
        real_ops = open(os.path.join(fx, 'unet_tiny_ops.txt'), encoding='utf-8').read()
        mods = [l.split() for l in open(os.path.join(fx, 'unet_tiny_modules.txt'), encoding='utf-8') if l.strip() and not l.startswith('#')]
        rr = np.random.default_rng(269)
        real_t = {}
        for path_, kind, i_, o_, ky_, kx_ in mods:
            i_, o_, ky_, kx_ = int(i_), int(o_), int(ky_), int(kx_)
            dn = rr.integers(-4, 5, size=(4, i_) if kind == 'L' else (4, i_, ky_, kx_)).astype(np.float32) / 4.0
            upv = rr.integers(-4, 5, size=(o_, 4) if kind == 'L' else (o_, 4, 1, 1)).astype(np.float32) / 4.0
            real_t.update(kohya(path_.replace('.', '_'), dn, upv, 4.0))
        chk('T19 dữ liệu thật: đọc đủ 83 module torch', len(mods) == 83, len(mods))
        rp = T.parse_ops(real_ops)
        chk('T19b parse_ops trên đầu ra --list THẬT: 83 Convolution gắn được + 16 MatMul không gắn được', sum(o['supported'] for o in rp) == 83 and sum(o['type'] == 'MatMul' for o in rp) == 16, (len(rp), sum(o['supported'] for o in rp)))
        rc, so, se, out, spec = S.go(real_t, ops_raw=real_ops)
        chk('T19c không --map: 82/83 khớp, conv_out (op bị MNN đổi tên thành tên đầu ra) => mã 3, KHÔNG ghi spec', rc == 3 and 'khớp & ghi 82' in so and 'conv_out' in so and not os.path.exists(spec), (rc, so[-300:]))
        chk('T19d báo cáo GỢI Ý đúng ứng viên: out_sample và dòng --map conv_out=out_sample', '--map conv_out=out_sample' in so, so[-400:])
        rc, so, se, out, spec = S.go(real_t, ops_raw=real_ops, extra=['--map', 'conv_out=out_sample'])
        rows = ref_parse_spec(spec) if rc == 0 else []
        chk('T19e có --map conv_out=out_sample: mã 0, đủ 83 dòng spec', rc == 0 and len(rows) == 83, (rc, len(rows), so[-200:]))
        names_ = [x[0] for x in rows]
        sup = {o['name']: o for o in rp if o['supported']}
        chk('T19f mọi op trong spec có thật trong --list, gắn được, KHÔNG dùng một op hai lần', all(n in sup for n in names_) and len(set(names_)) == len(names_), [n for n in names_ if n not in sup][:3])
        sizes_ok = all(os.path.getsize(a) == rk * sup[n]['in'] * sup[n]['ky'] * sup[n]['kx'] * 4 and os.path.getsize(b) == sup[n]['out'] * rk * 4 for n, rk, sc, a, b in rows if n in sup)
        chk('T19g kích thước A.bin/B.bin của cả 83 dòng khớp in/out/kernel trong --list thật', sizes_ok)
        chk('T19h các lớp Gemm (time_emb_proj, time_embedding) CÓ trong spec — chúng thành Convolution 1x1 sau mnnconvert (mô phỏng cũ giả định sai)', any('time_emb_proj/Gemm_output_0__matmul_converted' in n for n in names_) and any('time_embedding/linear_1' in n for n in names_))
        chk('T19i lớp Add gộp (to_out.0: MatMul+Add -> conv mang tên Add) và conv cuối out_sample có trong spec', any('attn1/to_out.0/Add_output_0__matmul_converted' in n for n in names_) and 'out_sample' in names_)
        rc, so, se, out, spec = S.go(real_t, ops_raw=real_ops, extra=['--allow-unmatched'])
        chk('T19j --allow-unmatched (không --map): mã 0, 82 dòng, cảnh báo THIẾU', rc == 0 and len(ref_parse_spec(spec)) == 82 and 'THIẾU' in so)
        mm_op = [o['name'] for o in rp if o['type'] == 'MatMul'][0]
        rc, so, se, out, spec = S.go(real_t, ops_raw=real_ops, extra=['--map', 'conv_out=' + mm_op])
        chk('T19k --map trỏ vào op MatMul (không gắn được) => mã 3 "OP KHÔNG GẮN ĐƯỢC"', rc == 3 and 'OP KHÔNG GẮN ĐƯỢC' in so, (rc, so[-250:]))

        # ── T20 --map: kiểm đầu vào và gợi ý
        fin = [conv('out_sample', 6, 4, 3, 3), conv(TB + '/attn1/to_q/MatMul', 8, 8)]
        cdown = np.zeros((4, 6, 3, 3), np.float32); cup = np.zeros((4, 4, 1, 1), np.float32)
        qd, qu = lora_pair(rng, 'down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_q', 4)
        t20 = dict(kohya('conv_out', cdown, cup, 4.0)); t20.update(kohya('down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_q', qd, qu, 4.0))
        rc, so, se, out, spec = S.go(t20, ops=fin)
        chk('T20 module không có op nhưng có op CHƯA dùng khớp kích thước => mã 3 và gợi ý --map', rc == 3 and '--map conv_out=out_sample' in so, (rc, so[-300:]))
        rc, so, se, out, spec = S.go(t20, ops=fin, extra=['--map', 'conv_out=out_sample'])
        chk('T20b --map đúng => mã 0, hai dòng spec, op out_sample có mặt', rc == 0 and sorted(x[0] for x in ref_parse_spec(spec)) == sorted(['out_sample', TB + '/attn1/to_q/MatMul']), (rc, so[-200:]))
        chk('T20c --map với khoá dạng PEFT có dấu chấm (down_blocks.0.….to_q) được chuẩn hoá', S.go(t20, ops=[conv('zzz', 8, 8), conv('out_sample', 6, 4, 3, 3)], extra=['--map', 'down_blocks.0.attentions.0.transformer_blocks.0.attn1.to_q=zzz', '--map', 'conv_out=out_sample'])[0] == 0)
        for nm, args_ in (('thiếu dấu =', ['--map', 'conv_out']), ('khoá rỗng', ['--map', '=out_sample']), ('op rỗng', ['--map', 'conv_out=']),
                          ('module không có trong LoRA', ['--map', 'khong_co=out_sample']), ('op không có trong danh sách', ['--map', 'conv_out=khong_co_op']),
                          ('chỉ định hai lần', ['--map', 'conv_out=out_sample', '--map', 'conv_out=out_sample'])):
            rc, so, se, out, spec = S.go(t20, ops=fin, extra=args_)
            chk(f'T20d --map {nm} => mã 2, không ghi spec', rc == 2 and not os.path.exists(spec), (rc, se[-150:]))
        # gợi ý không được nêu op ĐÃ dùng, và không gợi ý khi kích thước lệch
        only_used = [conv(TB + '/attn1/to_q/MatMul', 8, 8)]
        t20b = dict(kohya('down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_q', qd, qu, 4.0)); t20b.update(kohya('b_zzz', np.zeros((4, 8), np.float32), np.zeros((8, 4), np.float32), 4.0))
        rc, so, se, out, spec = S.go(t20b, ops=only_used)
        chk('T20e op đã dùng cho module khác KHÔNG được gợi ý cho module còn thiếu', rc == 3 and 'Ứng viên' not in so and 'b_zzz' in so, (rc, so[-300:]))
        rc, so, se, out, spec = S.go(t20, ops=[conv('out_sample', 7, 4, 3, 3), conv(TB + '/attn1/to_q/MatMul', 8, 8)])
        chk('T20f op chưa dùng nhưng KHÁC kích thước (in=7 thay vì 6) => không gợi ý', rc == 3 and 'Ứng viên' not in so, (rc, so[-300:]))

        # op đã được --map dùng cho module A thì KHÔNG được gợi ý lại cho module B cùng kích thước (đường dẫn của op đó không thuộc module LoRA nào nên chỉ điều kiện "chưa dùng" mới chặn được)
        t20g = dict(kohya('conv_out', cdown, cup, 4.0)); t20g.update(kohya('zz_other', cdown, cup, 4.0))
        rc, so, se, out, spec = S.go(t20g, ops=[conv('out_sample', 6, 4, 3, 3)], extra=['--map', 'conv_out=out_sample'])
        chk('T20g op đã --map cho module A không được gợi ý lại cho module B cùng kích thước', rc == 3 and 'zz_other' in so and 'Ứng viên' not in so, (rc, so[-300:]))

        # ── T21 tên op kiểu THẬT của mnnconvert (đuôi _output_0__matmul_converted, op cuối mang tên đầu ra)
        real_names = {'/down_blocks.0/attentions.0/transformer_blocks.0/attn1/to_q/MatMul_output_0__matmul_converted': 'down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_q',
                      '/up_blocks.1/attentions.0/transformer_blocks.0/attn1/to_out.0/Add_output_0__matmul_converted': 'up_blocks_1_attentions_0_transformer_blocks_0_attn1_to_out_0',
                      '/down_blocks.0/resnets.0/conv1/Conv_output_0': 'down_blocks_0_resnets_0_conv1', '/time_embedding/linear_1/Gemm_output_0__matmul_converted': 'time_embedding_linear_1',
                      'out_sample': 'out_sample'}
        bad_r = {k: T.op_flat_id(k) for k, v in real_names.items() if T.op_flat_id(k) != v}
        chk('T21 op_flat_id trên tên op THẬT của mnnconvert (đuôi _output_0__matmul_converted; op không có "/")', not bad_r, bad_r)

        # ── T18 chạy như CLI thật (dòng lệnh)
        if tool_path == REAL_TOOL:
            import subprocess
            w2 = S.d('cli'); lp = os.path.join(w2, 'l.safetensors'); write_st(lp, base); op_ = os.path.join(w2, 'ops.txt'); open(op_, 'w', encoding='utf-8').write(ops_text(OPS))
            p = subprocess.run([sys.executable, tool_path, '--lora', lp, '--ops', op_, '--out', os.path.join(w2, 'o')], capture_output=True, text=True)
            chk('T18 chạy như tập lệnh dòng lệnh: mã 0 và có spec.txt', p.returncode == 0 and os.path.exists(os.path.join(w2, 'o', 'spec.txt')), p.stderr[-200:])
            p = subprocess.run([sys.executable, tool_path, '--lora', lp], capture_output=True, text=True)
            chk('T18b thiếu tham số bắt buộc => mã 2', p.returncode == 2, p.returncode)
    finally:
        S.cleanup()
    return S


MUTS = [
    ('scale = alpha*rank', "alpha / r) * strength", "alpha * r) * strength"),
    ('bỏ strength', ") * strength\n        if not math.isfinite(scale):", ")\n        if not math.isfinite(scale):"),
    ('bỏ rslora', "alpha / math.sqrt(r) if use_rslora else alpha / r", "alpha / r"),
    ('đổi chỗ A và B trong spec', '{ap} {bp}\')', '{bp} {ap}\')'),
    ('A ghi sai thứ tự (chuyển vị)', "e['A'].reshape(r, -1)", "e['A'].reshape(r, -1).T.copy().reshape(r, -1)"),
    ('B ghi sai thứ tự (chuyển vị)', "e['B'].reshape(e['B'].shape[0], r)", "e['B'].reshape(e['B'].shape[0], r).T.copy().reshape(e['B'].shape[0], r)"),
    ('BF16 dịch sai', "(a.astype(np.uint32) << 16)", "(a.astype(np.uint32) << 8)"),
    ('F16 đọc như F32', "'F16': ('<f2', 2)", "'F16': ('<f4', 4)"),
    ('bỏ kiểm in của lora_down', "if tuple(down.shape) != want_a:", "if False:"),
    ('bỏ kiểm out của lora_up', "if up.shape[0] != op['out']:", "if False:"),
    ('bỏ kiểm rank down/up', "if r <= 0 or up.shape[1] != r:", "if r <= 0:"),
    ('bỏ kiểm up 4D kernel 1x1', "if up.ndim == 4 and up.shape[2:] != (1, 1):", "if False:"),
    ('bỏ kiểm down 2D trên conv 3x3', "if down.ndim == 2 and (op['ky'], op['kx']) != (1, 1):", "if False:"),
    ('bỏ kiểm số chiều lạ', "if down.ndim not in (2, 4) or up.ndim not in (2, 4):", "if False:"),
    ('nhận mọi loại op', "elif d['type'] != 'Convolution':", "elif False:"),
    ('nhận group != 1', "if d['group'] != 1:", "if False:"),
    ('nhận symmetricQuan', "elif 'symmetricQuan' in d['rest']:", "elif False:"),
    ('bỏ kiểm mơ hồ', "if len(sup) > 1:", "if False:"),
    ('luôn ghi spec dù có mục lỗi', "if problems and not args.allow_unmatched:", "if False:"),
    ('ghi spec rỗng khi không khớp gì', "if not plan['entries']:", "if False:"),
    ('không bỏ qua text-encoder', "if _KOHYA_TE.match(key) or key.startswith(_TE_PREFIXES):", "if False:"),
    ('bỏ qua khoá lạ im lặng', "unsupported.append(key)", "pass"),
    ('không bỏ đoạn cuối tên op', "parts = parts[:-1]", "parts = parts"),
    ('không đổi "." thành "_" ở tên op', "return '_'.join(parts).replace('.', '_')", "return '_'.join(parts)"),
    ('không đổi "." thành "_" ở khoá PEFT', "flat = m.group('m').replace('.', '_')", "flat = m.group('m')"),
    ('bỏ qua alpha trong tệp', "alpha = mod['alpha'] if mod['alpha'] is not None else (alpha_default if alpha_default is not None else float(r))", "alpha = (alpha_default if alpha_default is not None else float(r))"),
    ('bỏ qua lora_alpha của adapter_config', "if alpha_default is None and cfg.get('lora_alpha') is not None:", "if False:"),
    ('bỏ chặn rank_pattern', "if cfg.get('rank_pattern') or cfg.get('alpha_pattern'):", "if False:"),
    ('bỏ chặn DoRA', "if cfg.get('use_dora'):", "if False:"),
    ('--dry-run vẫn ghi', "if not args.dry_run:", "if True:"),
    ('bỏ kiểm đường dẫn có khoảng trắng', "if re.search(r'[\\s#]', absdir):", "if False:"),
    ('bỏ cảnh báo relu', "    if relu:\n        L.append(f'  CẢNH BÁO", "    if False:\n        L.append(f'  CẢNH BÁO"),
    ('cho phép lẫn kohya và PEFT', "if m['fmt'] != fmt:", "if False:"),
    ('nhận alpha nhiều phần tử', "if arr.size != 1:", "if False:"),
    ('không phát hiện tệp bị cắt', "if len(buf) != e - s:", "if False:"),
    ('không kiểm kích thước dữ liệu so với shape', "if s < 0 or e < s or e - s != cnt * isz:", "if False:"),
    ('không phát hiện thiếu lora_up/down', "if mod['down'] is None or mod['up'] is None:", "if False:"),
    ('không kiểm strength hữu hạn', "if not math.isfinite(args.strength):", "if False:"),
    ('không kiểm --alpha dương', "if args.alpha is not None and not (math.isfinite(args.alpha) and args.alpha > 0):", "if False:"),
    ('chấp nhận danh sách op rỗng', "if not ops:", "if False:"),
    ('nhận dtype lạ', "if dtype not in _DT:", "if False:"),
    ('bỏ gợi ý ứng viên', "sug = [o for o in free if", "sug = [o for o in [] if"),
    ('gợi ý cả op đã dùng', "o['name'] not in used and op_flat_id", "True and op_flat_id"),
    ('gợi ý mọi op chưa dùng, bỏ lọc kích thước', "if (o['in'], o['out'], o['ky'], o['kx']) == shape][:3]", "if True][:3]"),
    ('bỏ --map (không dùng override)', "cands = by_name.get(overrides[flat]) if flat in overrides else by_flat.get(flat)", "cands = by_flat.get(flat)"),
    ('--map không kiểm module có trong LoRA', "if k not in modules:", "if False:"),
    ('--map không kiểm op có trong danh sách', "if not any(o['name'] == v.strip() for o in ops):", "if False:"),
    ('--map cho phép chỉ định hai lần', "if k in overrides:", "if False:"),
    ('--map không chuẩn hoá dấu chấm', "k = k.strip().replace('.', '_')", "k = k.strip()"),
    ('--map không kiểm dạng KHOÁ=OP', "if '=' not in item or item.startswith('=') or item.endswith('='):", "if False:"),
]


def main():
    real = run_all(REAL_TOOL, True)
    ok = not real.failed
    print(f'\nĐã chạy {real.n} phép kiểm trên công cụ thật; lỗi: {len(real.failed)}')
    if real.n < 90:   # chống quét rỗng (bộ test hiện có ~100 phép)
        print('FAIL số phép kiểm quá ít:', real.n); ok = False
    src = open(REAL_TOOL, encoding='utf-8').read()
    tmp = tempfile.mkdtemp()
    caught, survived, missing, broke = 0, [], [], []
    for i, (name, a, b) in enumerate(MUTS):
        if src.count(a) < 1:
            missing.append(name); continue
        mp = os.path.join(tmp, f'mut{i}.py')
        open(mp, 'w', encoding='utf-8').write(src.replace(a, b, 1))
        try:
            m = run_all(mp, False)
        except Exception as e:   # đột biến làm hỏng cả bộ test (vd lỗi cú pháp lúc nạp) — vẫn là "bị bắt", nhưng ghi lại
            broke.append(f'{name}: {type(e).__name__}')
            caught += 1
            print(f'  [{i + 1}/{len(MUTS)}] bắt (sập bộ test)  {name}')
            continue
        if m.failed:
            caught += 1
            print(f'  [{i + 1}/{len(MUTS)}] bắt  {name}  <- {m.failed[0][:80]}')
        else:
            survived.append(name)
            print(f'  [{i + 1}/{len(MUTS)}] SỐNG SÓT  {name}')
    shutil.rmtree(tmp, ignore_errors=True)
    print('FAIL mẫu đột biến không còn khớp mã nguồn: ' + str(missing) if missing else 'PASS mọi mẫu đột biến còn khớp mã nguồn')
    print(('FAIL' if survived else 'PASS') + f' thử phá mã: {caught}/{len(MUTS)} đột biến bị bắt' + (f'; SỐNG SÓT: {survived}' if survived else ''))
    if broke:
        print('LƯU Ý đột biến làm sập cả bộ test:', broke)
    ok = ok and not survived and not missing
    print('\nKẾT QUẢ:', 'ĐẠT' if ok else 'CÓ LỖI')
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
