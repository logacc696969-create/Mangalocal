#!/usr/bin/env python3
"""mục 262 — kiểm thử `pipeline/PersonCountArbiter.kt` (phân xử số người detector-first) bằng kotlinc THẬT.

Duyệt TOÀN BỘ lưới: kịch bản 1..5 x detector {null,0..8} x VLM {null,0..8} x số người thừa cho phép -1..3 (âm = đầu vào hỏng, phải được kẹp về 0) = 2.500 ca; đối chiếu bản tham chiếu Python viết độc lập
từ bảng quy tắc (kind + có cảnh báo VLM hay không + ghi chú có/không). Thêm: tính chất an toàn (detector đếm KHÔNG khớp thì không bao giờ bỏ cảnh báo VLM lệch cùng hướng;
VLM đếm đúng thì không bao giờ có cảnh báo VLM), nối dây tĩnh, `OutputVerifier.kt` KHÔNG bị đụng so với zip gốc, thử phá mã (đột biến PHẢI biên dịch được).
KHÔNG chứng minh: detector đếm đúng trên ảnh thật (cảnh quần nhau detector đếm thiếu); chỉ chứng minh quy tắc phân xử được cài đúng.
Cần kotlinc (KOTLINC=...); không có -> BỎ QUA.
"""
import os, re, shutil, subprocess, sys, tempfile, hashlib, zipfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + d) if (d and not c) else '')); ok &= bool(c)
def find():
    for c in [os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/work/kotlinc/bin/kotlinc']:
        if c and os.path.exists(c): return c
KOTLINC = find()
DRV = r'''
import com.mangalocal.pipeline.PersonCountArbiter
fun main() {
    val sb = StringBuilder()
    for (e in 1..5) for (d in listOf<Int?>(null) + (0..8).toList()) for (v in listOf<Int?>(null) + (0..8).toList()) for (a in -1..3) {
        val r = PersonCountArbiter.decide(e, d, v, a)
        sb.append(e).append(' ').append(d ?: "n").append(' ').append(v ?: "n").append(' ').append(a).append(' ').append(r.kind.name).append(' ').append(r.warnVlmCount).append(' ').append(r.note.isNotEmpty()).append('\n')
    }
    print(sb)
}
'''
def sign(x): return (x > 0) - (x < 0)
def ref(e, d, v, a):
    if v is None: return ('NO_VLM', False, False)
    if d is None: return ('VLM_ONLY', v != e, False)
    dok = d >= e and d <= e + max(a, 0)
    if v == e: return ('CONSISTENT', False, False) if dok else ('UNCERTAIN', False, True)
    if dok: return ('DETECTOR_OVERRIDES_VLM', False, True)
    if sign(d - e) == sign(v - e): return ('BOTH_SAY_FEW' if v < e else 'BOTH_SAY_MANY', True, True)
    return ('UNCERTAIN', True, True)
def run_suite(src, tmp, tag):
    d = os.path.join(tmp, tag); os.makedirs(d, exist_ok=True); open(os.path.join(d, 'Drv.kt'), 'w').write(DRV)
    jar = os.path.join(tmp, tag + '.jar')
    r = subprocess.run([KOTLINC, src, os.path.join(d, 'Drv.kt'), '-d', jar], capture_output=True, text=True)
    if r.returncode != 0: return None, 'compile: ' + r.stderr[-500:]
    klib = os.path.join(os.path.dirname(os.path.dirname(KOTLINC)), 'lib', 'kotlin-stdlib.jar')
    o = subprocess.run(['java', '-cp', f'{jar}:{klib}', 'DrvKt'], capture_output=True, text=True)
    if o.returncode != 0: return None, 'run: ' + o.stderr[-300:]
    return o.stdout.strip().split('\n'), ''
def mismatches(lines):
    if lines is None: return 10**9, []
    bad = []; i = 0
    for e in range(1, 6):
        for d in [None] + list(range(9)):
            for v in [None] + list(range(9)):
                for a in range(-1, 4):
                    p = lines[i].split(); i += 1
                    got = (p[4], p[5] == 'true', p[6] == 'true'); want = ref(e, d, v, a)
                    if got != want: bad.append(((e, d, v, a), got, want))
    return len(bad), bad
def props(lines):
    """tính chất an toàn, KHÔNG dựa vào bảng tham chiếu"""
    ok1 = ok2 = ok3 = True; i = 0
    for e in range(1, 6):
        for d in [None] + list(range(9)):
            for v in [None] + list(range(9)):
                for a in range(-1, 4):
                    p = lines[i].split(); i += 1; warn = p[5] == 'true'
                    if v is not None and v == e and warn: ok1 = False                       # VLM đếm đúng -> không bao giờ có cảnh báo VLM
                    if v is not None and d is not None and v != e and not (e <= d <= e + a) and sign(d - e) == sign(v - e) and not warn: ok2 = False  # hai nguồn cùng lệch -> phải giữ cảnh báo
                    if v is None and warn: ok3 = False                                    # không có VLM -> không cảnh báo VLM
    return ok1, ok2, ok3
SRC = os.path.join(KT, 'pipeline/PersonCountArbiter.kt')
if not KOTLINC:
    print('SKIP phần kotlinc: không có kotlinc')
else:
    tmp = tempfile.mkdtemp()
    lines, err = run_suite(SRC, tmp, 'real')
    check('PersonCountArbiter.kt biên dịch + chạy bằng kotlinc thật', lines is not None and len(lines) == 5 * 10 * 10 * 5, err)
    if lines is not None and len(lines) == 2500:
        nb, bad = mismatches(lines)
        check('2.500 ca của lưới khớp tham chiếu Python (kind + cảnh báo VLM + ghi chú)', nb == 0, str(bad[:2]))
        p1, p2, p3 = props(lines)
        check('an toàn: VLM đếm ĐÚNG kịch bản thì KHÔNG BAO GIỜ có cảnh báo VLM', p1)
        check('an toàn: detector lệch và VLM lệch CÙNG hướng thì LUÔN giữ cảnh báo (hai nguồn đồng ý)', p2)
        check('an toàn: không có VLM thì không có cảnh báo VLM', p3)
        kinds = {l.split()[4] for l in lines}
        check('lưới phủ đủ 7 loại quyết định', len(kinds) == 7, str(kinds))
        src = open(SRC, encoding='utf-8').read()
        muts = [
            ('detectorOk: cận dưới lệch', 'detected >= expected &&', 'detected > expected &&'),
            ('detectorOk: bỏ qua số người thừa', 'detected <= expected + maxOf(extraAllowed, 0)', 'detected <= expected'),
            ('detectorOk: không kẹp số người thừa âm', 'maxOf(extraAllowed, 0)', 'extraAllowed'),
            ('detector thắng nhưng vẫn cảnh báo', 'return Decision(Kind.DETECTOR_OVERRIDES_VLM, false,', 'return Decision(Kind.DETECTOR_OVERRIDES_VLM, true,'),
            ('so hướng đảo', 'return if (dSign == vSign) {', 'return if (dSign != vSign) {'),
            ('VLM đúng mà detector lệch vẫn cảnh báo', 'else Decision(Kind.UNCERTAIN, false, "Đếm người: detector $detected, VLM $vlm, kịch bản $expected', 'else Decision(Kind.UNCERTAIN, true, "Đếm người: detector $detected, VLM $vlm, kịch bản $expected'),
            ('VLM_ONLY không cảnh báo', 'return Decision(Kind.VLM_ONLY, vlm != expected, "")', 'return Decision(Kind.VLM_ONLY, vlm == null, "")'),
            ('NO_VLM cảnh báo', 'return Decision(Kind.NO_VLM, false, "")', 'return Decision(Kind.NO_VLM, true, "")'),
            ('đảo nhãn FEW/MANY', 'if (vSign < 0) Kind.BOTH_SAY_FEW else Kind.BOTH_SAY_MANY', 'if (vSign < 0) Kind.BOTH_SAY_MANY else Kind.BOTH_SAY_FEW'),
        ]
        lo, hi = (int(x) for x in os.environ.get('MUT_RANGE', '0:999').split(':'))
        caught = 0; sel = [(k, m) for k, m in enumerate(muts) if lo <= k < hi]
        for k, (name, old, new) in sel:
            if old not in src: check(f'đột biến "{name}": mẫu có trong mã', False, 'mẫu không còn khớp'); continue
            mp = os.path.join(tmp, f'm{k}.kt'); open(mp, 'w', encoding='utf-8').write(src.replace(old, new, 1))
            ml, me = run_suite(mp, tmp, f'm{k}')
            if ml is None and me.startswith('compile'): check(f'đột biến "{name}" phải BIÊN DỊCH được (nếu không thì "bị bắt" là vô nghĩa)', False, me); continue
            hit = True if ml is None else mismatches(ml)[0] > 0
            check(f'đột biến "{name}" bị bắt', hit); caught += hit
        check(f'thử phá mã: {caught}/{len(sel)} đột biến bị bắt', caught == len(sel))
    shutil.rmtree(tmp, ignore_errors=True)
# ---- nối dây tĩnh ----
rd = lambda *p: open(os.path.join(*p), encoding='utf-8').read()
VJ = rd(KT, 'pipeline/VisionJudge.kt'); MP = rd(KT, 'pipeline/MangaPipeline.kt'); ML = rd(KT, 'model/Models.kt'); ST = rd(KT, 'ui/SettingsScreen.kt')
check('VisionJudge.reasons: suppressCount mặc định false (hành vi cũ GIỮ NGUYÊN khi không truyền) và chỉ chặn lý do ĐẾM, lý do tiếp xúc vẫn giữ',
      'suppressCount: Boolean = false' in VJ and 'if (!suppressCount && c != null && c != expectedPeople)' in VJ and 'expectContact && v.contact == false' in VJ)
check('MangaPipeline: truyền số người detector (result0.detected) vào visionJudgeReasons', 'visionJudgeReasons(imagePath, panel, result0.expected, settings, result0.detected)' in MP)
check('MangaPipeline: phân xử chỉ khi bật cờ; cờ tắt -> dec = null -> không chặn (hành vi cũ)', 'if (settings.visionCountDetectorFirst) PersonCountArbiter.decide(' in MP and 'suppressCount = dec != null && !dec.warnVlmCount' in MP)
check('Models: visionCountDetectorFirst mặc định BẬT (bên trong tính năng VLM vốn tắt) và có UI chỉ hiện khi đã đặt thư mục VLM', 'val visionCountDetectorFirst: Boolean = true' in ML and 'helpKey = "visionCountDetectorFirst"' in ST and 'if (settings.visionJudgeModelDir.isNotBlank()) Row(' in ST)
orig = '/mnt/user-data/uploads/mangalocal4_FINAL.zip'
if os.path.exists(orig):
    z = zipfile.ZipFile(orig)
    a = hashlib.sha256(z.read('app/src/main/java/com/mangalocal/pipeline/OutputVerifier.kt')).hexdigest()
    b = hashlib.sha256(open(os.path.join(KT, 'pipeline/OutputVerifier.kt'), 'rb').read()).hexdigest()
    check('OutputVerifier.kt (lý do của DETECTOR) KHÔNG bị đụng so với zip gốc — phân xử chỉ tác động lý do của VLM', a == b)
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
