#!/usr/bin/env python3
"""mục 259 — kiểm thử GIÁM KHẢO NHÌN-HIỂU ẢNH (VLM): `pipeline/VisionJudge.kt` + nối dây vào MangaPipeline/CMake/Gradle/workflow.

Không có kotlinc/model thật ở sandbox nên: (1) hành vi của hàm thuần được kiểm bằng BẢN CHÉP Python đối chiếu từng mẫu regex/bảng từ chính mã
Kotlin (đọc ra rồi so, không gõ lại), (2) nối dây được kiểm tĩnh trên mã nguồn thật. KHÔNG chứng minh: model VL nạp được, đếm đúng, hay build
MNN với cờ omni/vision thành công — các việc đó chỉ CI + máy thật mới trả lời được.
"""
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/')
def rd(*a): return open(os.path.join(*a), encoding='utf-8').read()
VJ = rd(P, 'pipeline/VisionJudge.kt'); MP = rd(P, 'pipeline/MangaPipeline.kt'); MD = rd(P, 'model/Models.kt'); ST = rd(P, 'ui/SettingsScreen.kt')
CM = rd(ROOT, 'app/src/main/jni/CMakeLists.txt'); GR = rd(ROOT, 'app/build.gradle'); WF = rd(ROOT, '.github/workflows/build.yml')

ok = True
def check(name, cond, detail=''):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + detail) if (detail and not cond) else ''))
    ok &= bool(cond)

# ---------- bản chép Python: các hằng số/mẫu được ĐỌC từ mã Kotlin ----------
MAXP = int(re.search(r'const val MAX_PEOPLE = (\d+)', VJ).group(1))
WORDS = dict((k, int(v)) for k, v in re.findall(r'"(\w+)" to (\d+)', re.search(r'WORD_NUMBERS = mapOf\((.*?)\)\n', VJ, re.S).group(1)))
CONTACT = re.search(r'CONTACT_REGEX = Regex\(\s*(.*?)\n    \)', VJ, re.S).group(1)
CONTACT = re.compile(''.join(re.findall(r'"([^"]*)"', CONTACT)))
def parse_count(a):
    m = re.search(r'\d+', a)
    if m:
        n = int(m.group(0)); return n if 0 <= n <= MAXP else None
    for tok in re.split(r'[^a-z]+', a.lower()):
        if tok in WORDS: return WORDS[tok]
    return None
def parse_yes_no(a):
    toks = [t for t in re.split(r'[^a-z]+', a.lower()) if t]
    if not toks: return None
    return {'yes': True, 'no': False}.get(toks[0])
def is_contact(action): return CONTACT.search(action.lower()) is not None
def reasons(counted, contact, expected, expect_contact):
    out = []
    if counted is not None and counted != expected: out.append('count')
    if expect_contact and contact is False: out.append('contact')
    return out

check('bảng từ chỉ số đọc được từ Kotlin (zero..ten, none, nobody) và MAX_PEOPLE = 30', WORDS['two'] == 2 and WORDS['ten'] == 10 and WORDS['none'] == 0 and MAXP == 30)
for ans, exp in [('2', 2), ('There are 3 people.', 3), ('Two', 2), ('I see two people', 2), ('0', 0), ('none', 0), ('12 men and 3 women', 12),
                 ('  \n 4', 4), ('Five', 5), ('Zero people', 0)]:
    check(f'parseCount({ans!r}) = {exp}', parse_count(ans) == exp)
for ans in ['', 'many people', 'no people', '100', '31', 'unclear', '😀']:
    check(f'parseCount({ans!r}) = null (không hiểu/vô lý -> không đoán)', parse_count(ans) is None)
check('parseCount: ưu tiên chữ số đầu tiên dù có từ chỉ số sau đó ("3 and two")', parse_count('3 and two') == 3)
for ans, exp in [('YES', True), ('Yes, they are hugging', True), ('no.', False), ('No', False), ('  \n yes', True), ('NO!', False)]:
    check(f'parseYesNo({ans!r}) = {exp}', parse_yes_no(ans) is exp)
for ans in ['', 'maybe', 'Yesterday', 'Not sure', 'nope', '123']:
    check(f'parseYesNo({ans!r}) = null (khớp NGUYÊN từ đầu tiên, không đoán)', parse_yes_no(ans) is None)
for act, exp in [('hugging tightly', True), ('fighting', True), ('đang ôm nhau', True), ('hôn', True), ('wrestling on the ground', True), ('carrying her', True),
                 ('standing', False), ('walking in park', False), ('chạy', False), ('', False), ('Grappling', True)]:
    check(f'isContactAction({act!r}) = {exp}', is_contact(act) is exp)

check('reasons: đếm khác kịch bản -> cảnh báo; đếm đúng -> không', reasons(3, None, 2, False) == ['count'] and reasons(2, None, 2, False) == [])
check('reasons: cảnh yêu cầu tiếp xúc mà VLM nói NO -> cảnh báo; YES hoặc không hiểu (null) -> KHÔNG phạt', reasons(None, False, 2, True) == ['contact'] and reasons(None, True, 2, True) == [] and reasons(None, None, 2, True) == [])
check('reasons: cảnh KHÔNG yêu cầu tiếp xúc thì NO không bị phạt; câu trả lời không hiểu thì không phạt đếm', reasons(2, False, 2, False) == [] and reasons(None, None, 2, False) == [])

# ---------- luồng gọi với model GIẢ (bản chép của judge) ----------
def judge(img, ask_contact, ask):
    rc = ask('count|' + img)
    rk = ask('contact|' + img) if ask_contact else ''
    return parse_count(rc), (parse_yes_no(rk) if ask_contact else None)
calls = []
def fake(p): calls.append(p); return '2' if p.startswith('count') else 'Yes'
r = judge('/x/a.png', True, fake)
check('judge: hỏi đếm rồi hỏi tiếp xúc (2 lần gọi) khi cảnh có tiếp xúc', r == (2, True) and len(calls) == 2)
calls.clear(); r = judge('/x/a.png', False, fake)
check('judge: cảnh không tiếp xúc -> CHỈ 1 lần gọi (tiết kiệm vài giây mỗi panel)', r == (2, None) and len(calls) == 1)
check('Kotlin: judge chỉ hỏi tiếp xúc khi askContact, và nhận ask là hàm tiêm vào (test được không cần model)',
      'if (askContact) ask(contactPrompt(imagePath)) else ""' in VJ and 'ask: (String) -> String' in VJ)

# ---------- prompt đúng định dạng MNN-LLM đa phương thức ----------
check('prompt đếm và tiếp xúc đều có dạng <img>đường_dẫn</img>câu hỏi (cú pháp MNN-LLM) và yêu cầu trả lời ngắn',
      '"<img>$imagePath</img>How many people' in VJ and '"<img>$imagePath</img>Are at least two of the people' in VJ and 'single number only' in VJ and 'YES or NO only' in VJ)
check('hằng số trả lời ngắn: 12 token (đủ một số hoặc YES/NO, không để model kể lể tốn thời gian)', 'const val MAX_ANSWER_TOKENS = 12' in VJ)

# ---------- nối dây vào pipeline ----------
check('verifyOutputPose: thêm lý do VLM vào kết quả (passed=false + reasons nối thêm), KHÔNG ghi đè lý do cũ',
      'val vlmReasons = visionJudgeReasons(imagePath, panel, result0.expected, settings' in MP and   # mục 262: có thể kèm result0.detected
      'result0.copy(passed = false, reasons = result0.reasons + vlmReasons)' in MP)
vj = MP[MP.index('private fun visionJudgeReasons('):MP.index('private fun verifyOutputPose(')]
check('visionJudgeReasons: rỗng khi chưa đặt thư mục, người kỳ vọng <= 0, hoặc thư mục đã thử hỏng', 'if (dir.isEmpty() || expectedPeople <= 0 || vlmFailedDir == dir) return emptyList()' in vj)
check('visionJudgeReasons: thiếu config.json -> log + đánh dấu hỏng + bỏ qua (không ném lỗi)', 'File(dir, "config.json")' in vj and 'vlmFailedDir = dir' in vj and 'không thấy' in vj)
check('visionJudgeReasons: llamaInit trả 0 (không nạp được, vd APK chưa bật enable_vlm) -> log rõ + bỏ qua, không thử lại các panel sau',
      'if (vlmHandle == 0L) {' in vj and 'NativeBridge.llamaInit(cfg.absolutePath' in vj and 'enable_vlm' in vj)
check('visionJudgeReasons: mọi ngoại lệ bị bắt (Throwable) -> bỏ qua, KHÔNG làm hỏng sinh ảnh', 'catch (e: Throwable)' in vj and 'emptyList()' in vj)
check('visionJudgeReasons: gọi model qua llamaGenerate(handle, prompt, MAX_ANSWER_TOKENS, 0f) (nhiệt độ 0 = tất định)', 'NativeBridge.llamaGenerate(h, prompt, VisionJudge.MAX_ANSWER_TOKENS, 0f)' in vj)
check('vòng đời: finally giải phóng handle khi KHÔNG giữ (regenerate 1 panel nạp-rồi-giải-phóng)', 'if (!vlmKeepAlive) releaseVisionJudge()' in vj)
rg = MP[MP.index('suspend fun runGeneration('):]
check('vòng đời: runGeneration bật keepAlive ở đầu và giải phóng model ở finally (không rò RAM 2 GB)',
      'vlmKeepAlive = true; vlmFailedDir = null' in rg and 'vlmKeepAlive = false; releaseVisionJudge()' in rg and
      rg.index('vlmKeepAlive = true') < rg.index('vlmKeepAlive = false; releaseVisionJudge()'))
check('releaseVisionJudge: xoá handle trước khi free (không free hai lần) và bắt lỗi', 'val h = vlmHandle\n        vlmHandle = 0L\n        if (h != 0L) try { NativeBridge.llamaFree(h) }' in MP)
check('chỉ hỏi tiếp xúc khi >=2 người và hành động của cảnh ngụ ý tiếp xúc', 'expectedPeople >= 2 && VisionJudge.isContactAction(panel.scene.action)' in vj)
check('VLM chỉ chạy khi bật verifyOutputPose (thoát sớm ở đầu hàm, mặc định tắt) — không có đường chạy ngầm', 'if (!settings.verifyOutputPose) return null' in MP[MP.index('private fun verifyOutputPose('):MP.index('private fun verifyOutputPose(') + 400])
check('Settings: visionJudgeModelDir mặc định rỗng (tắt) + ô nhập trong Cài đặt có dấu ?', 'val visionJudgeModelDir: String = ""' in MD and 'HelpDot("visionJudgeModelDir")' in ST and 'copy(visionJudgeModelDir = it)' in ST)

# ---------- build opt-in ----------
check('CMake: cờ MANGALOCAL_ENABLE_VLM mặc định OFF; bật thì đặt đủ 3 cờ MNN (vision, opencv, imgcodecs) — mục 274 bỏ omni',
      'option(MANGALOCAL_ENABLE_VLM' in CM and ' OFF)' in CM[CM.index('option(MANGALOCAL_ENABLE_VLM'):CM.index('option(MANGALOCAL_ENABLE_VLM') + 200] and
      all(('set(%s ON CACHE BOOL "" FORCE)' % k) in re.sub(r'\s+', ' ', CM) or re.search(r'set\(%s\s+ON CACHE BOOL "" FORCE\)' % k, CM) for k in ['LLM_SUPPORT_VISION', 'MNN_BUILD_OPENCV', 'MNN_IMGCODECS']))
_vlm_body = CM[CM.index('if(MANGALOCAL_ENABLE_VLM)'):CM.index('endif()', CM.index('if(MANGALOCAL_ENABLE_VLM)'))]
check('CMake: khối VLM KHÔNG bật MNN_BUILD_LLM_OMNI (ép AUDIO -> MNNAudio OBJECT + POST_BUILD lỗi, log CI #137) và ép MNN_BUILD_AUDIO OFF',
      not re.search(r'set\(MNN_BUILD_LLM_OMNI\s+ON', _vlm_body) and re.search(r'set\(MNN_BUILD_AUDIO\s+OFF CACHE BOOL "" FORCE\)', _vlm_body) is not None)
vlm_blk = CM.index('if(MANGALOCAL_ENABLE_VLM)')
check('CMake: khối VLM nằm SAU `MNN_BUILD_OPENCV OFF` (FORCE ghi đè) và TRƯỚC add_subdirectory(MNN)',
      CM.index('set(MNN_BUILD_OPENCV     OFF') < vlm_blk < CM.index('add_subdirectory(${TP}/MNN '))
check('Gradle: chỉ truyền -DMANGALOCAL_ENABLE_VLM=ON khi -Pmangalocal.enableVlm=true (mặc định không đổi build)',
      'project.property("mangalocal.enableVlm") == "true"' in GR and '-DMANGALOCAL_ENABLE_VLM=ON' in GR)
check('Workflow: input enable_vlm mặc định false, truyền -Pmangalocal.enableVlm=true bằng BIẾN RIÊNG (không bị biến QNN ghi đè) vào gradlew',
      re.search(r'enable_vlm:\s*\n\s*description:.*\n\s*default: false', WF) is not None and 'VLM_GRADLE_ARGS="-Pmangalocal.enableVlm=true"' in WF and '$VLM_GRADLE_ARGS' in WF)
check('Workflow: build mặc định (push) không đụng gì tới VLM (biến rỗng khi input không phải true)', 'VLM_GRADLE_ARGS=""' in WF)

print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
