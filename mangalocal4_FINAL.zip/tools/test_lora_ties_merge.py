#!/usr/bin/env python3
"""mục 249 — kiểm thử tools/lora_ties_merge.py bằng DỮ LIỆU TỔNG HỢP (numpy).

Chứng minh: các tính chất toán học đúng (cắt top-k, bầu dấu, trung bình rời, DARE kỳ vọng, SVD cắt hạng, định dạng kohya, quy
trình đầu-cuối). KHÔNG chứng minh gộp TIES/DARE giảm rò danh tính giữa LoRA nhân vật thật — cần thử trên LoRA thật.
"""
import importlib.util, os, sys
import numpy as np

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
spec = importlib.util.spec_from_file_location('lora_ties_merge', os.path.join(ROOT, 'tools', 'lora_ties_merge.py'))
M = importlib.util.module_from_spec(spec); spec.loader.exec_module(M)

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

rng = np.random.default_rng(249)
def _r(f):
    try: f(); return False
    except ValueError: return True
def lora(modules, rank=4, shape=(16, 24), alpha=None, seed=0):
    r = np.random.default_rng(seed); t = {}
    for m in modules:
        t[m + M.DOWN] = r.standard_normal((rank, shape[1])).astype(np.float32)
        t[m + M.UP] = r.standard_normal((shape[0], rank)).astype(np.float32)
        if alpha is not None: t[m + M.ALPHA] = np.array(alpha, dtype=np.float32)
    return t

# ---------- đọc định dạng kohya ----------
t = lora(['lora_unet_a', 'lora_unet_b'], alpha=2.0); t['junk.weight'] = np.zeros(3)
L = M.read_lora(t)
check('read_lora: nhận đủ module có cả down+up, bỏ khoá lạ', set(L) == {'lora_unet_a', 'lora_unet_b'} and L['lora_unet_a'][2] == 2.0)
t2 = lora(['m'])   # không có khoá alpha
check('thiếu alpha -> alpha = hạng (quy ước kohya, hệ số 1.0)', M.read_lora(t2)['m'][2] == 4.0)
only_down = {'x' + M.DOWN: np.zeros((2, 3), dtype=np.float32)}
check('module chỉ có down (thiếu up) bị bỏ', M.read_lora(only_down) == {})
d, u, a = M.read_lora(lora(['m'], alpha=8.0))['m']
check('ΔW = (alpha/hạng)·up@down', np.allclose(M.delta_of(d, u, a), (8.0 / 4) * (u @ d), atol=1e-5))

# ---------- trim ----------
x = np.array([[1.0, -5.0, 0.2], [3.0, -0.1, 4.0]], dtype=np.float32)
tr = M.trim_topk(x, 0.5)
check('trim 0.5 giữ 3/6 phần tử có |giá trị| lớn nhất (-5, 4, 3), còn lại = 0', np.count_nonzero(tr) == 3 and set(tr[tr != 0].tolist()) == {-5.0, 4.0, 3.0})
check('trim 1.0 giữ nguyên; mảng toàn 0 không lỗi', np.array_equal(M.trim_topk(x, 1.0), x) and not M.trim_topk(np.zeros((3, 3), dtype=np.float32), 0.5).any())
big = rng.standard_normal((200, 200)).astype(np.float32)
check('trim 0.2 trên mảng ngẫu nhiên giữ ≈ 20% (±1%) và đúng là phần có |giá trị| lớn nhất', abs(np.count_nonzero(M.trim_topk(big, 0.2)) / big.size - 0.2) < 0.01
      and np.abs(M.trim_topk(big, 0.2)[M.trim_topk(big, 0.2) != 0]).min() >= np.abs(big[M.trim_topk(big, 0.2) == 0]).max())

# ---------- bầu dấu + trung bình rời ----------
A = np.array([3.0, 3.0, -2.0, 0.0, 5.0], dtype=np.float32)
B = np.array([1.0, -1.0, -4.0, 6.0, 0.0], dtype=np.float32)
em = M.elect_and_mean([A, B])
check('đồng dấu -> trung bình (3,1 -> 2)', abs(em[0] - 2.0) < 1e-6)
check('trái dấu -> thắng bởi tổng, phần tử THUA bị bỏ (3,-1: tổng +2 -> giữ 3; -2,-4: tổng -6 -> trung bình -3)', abs(em[1] - 3.0) < 1e-6 and abs(em[2] + 3.0) < 1e-6)
check('chỉ một LoRA khác 0 -> lấy nguyên giá trị đó (không bị chia đôi)', abs(em[3] - 6.0) < 1e-6 and abs(em[4] - 5.0) < 1e-6)
check('hai LoRA triệt tiêu nhau (tổng 0) -> 0, không lỗi chia 0', M.elect_and_mean([np.array([2.0]), np.array([-2.0])])[0] == 0.0)
check('hỗ trợ ≥ 3 LoRA: (+2, +4, -1) -> dấu + , trung bình (2,4) = 3', abs(M.elect_and_mean([np.array([2.0]), np.array([4.0]), np.array([-1.0])])[0] - 3.0) < 1e-6)

# ---------- merge_deltas ----------
Dd1 = np.zeros((4, 4), dtype=np.float32); Dd1[0, :2] = [1, 2]
Dd2 = np.zeros((4, 4), dtype=np.float32); Dd2[3, 2:] = [3, 4]
check('hai ΔW có giá đỡ RỜI nhau: ties (density 1) == linear == tổng', np.allclose(M.merge_deltas([Dd1, Dd2], [1, 1], 'ties', 1.0), Dd1 + Dd2) and np.allclose(M.merge_deltas([Dd1, Dd2], [1, 1], 'linear'), Dd1 + Dd2))
check('trọng số được áp trước khi gộp (linear: 2·A + 0.5·B)', np.allclose(M.merge_deltas([Dd1, Dd2], [2, 0.5], 'linear'), 2 * Dd1 + 0.5 * Dd2))
check('một ΔW duy nhất, ties density 1 -> chính nó', np.allclose(M.merge_deltas([Dd1], [1.0], 'ties', 1.0), Dd1))
conflict1 = np.array([[5.0, 1.0]], dtype=np.float32); conflict2 = np.array([[-1.0, 1.0]], dtype=np.float32)
mt = M.merge_deltas([conflict1, conflict2], [1, 1], 'ties', 1.0)
check('khác linear ở chỗ xung đột: ô (5,-1): linear=4, ties=5 (loại phần trái dấu); ô (1,1): ties=1 (trung bình), linear=2',
      np.allclose(M.merge_deltas([conflict1, conflict2], [1, 1], 'linear'), [[4.0, 2.0]]) and np.allclose(mt, [[5.0, 1.0]]))
check('method lạ -> ValueError', _r(lambda: M.merge_deltas([Dd1], [1], 'abc')))
check('danh sách ΔW rỗng -> ValueError', _r(lambda: M.merge_deltas([], [], 'ties')))

# ---------- DARE ----------
base = np.ones((300, 300), dtype=np.float32)
dd = M.dare_drop(base, 0.25, np.random.default_rng(1))
check('DARE: giữ ≈ density phần tử, mỗi phần tử giữ được nhân 1/density', abs(np.count_nonzero(dd) / base.size - 0.25) < 0.01 and set(np.unique(dd).tolist()) <= {0.0, 4.0})
check('DARE: kỳ vọng được bảo toàn (trung bình ≈ trung bình gốc, sai < 2%)', abs(dd.mean() - 1.0) < 0.02)
check('DARE: cùng seed -> cùng kết quả; khác seed -> khác', np.array_equal(M.dare_drop(base, 0.5, np.random.default_rng(3)), M.dare_drop(base, 0.5, np.random.default_rng(3))) and not np.array_equal(M.dare_drop(base, 0.5, np.random.default_rng(3)), M.dare_drop(base, 0.5, np.random.default_rng(4))))
check('density 1.0 -> DARE không đổi gì', np.array_equal(M.dare_drop(base, 1.0, np.random.default_rng(0)), base))
check('merge_deltas dare_ties/dare_linear xác định theo seed', np.array_equal(M.merge_deltas([base, base * 2], [1, 1], 'dare_ties', 0.5, seed=7), M.merge_deltas([base, base * 2], [1, 1], 'dare_ties', 0.5, seed=7))
      and np.array_equal(M.merge_deltas([base, base], [1, 1], 'dare_linear', 0.5, seed=7), M.merge_deltas([base, base], [1, 1], 'dare_linear', 0.5, seed=7)))

# ---------- SVD về LoRA ----------
low = (rng.standard_normal((20, 3)) @ rng.standard_normal((3, 30))).astype(np.float32)
down, up, r = M.to_lora(low, 8, (8, 30), (20, 8))
check('ΔW hạng 3 cắt về hạng 8 -> dựng lại gần như chính xác', np.allclose(up.reshape(20, r) @ down.reshape(r, 30), low, atol=1e-3) and r == 8)
down, up, r = M.to_lora(low, 2, (8, 30), (20, 8))
err_rank2 = np.linalg.norm(up.reshape(20, r) @ down.reshape(r, 30) - low)
check('cắt xuống hạng 2 (< hạng thật 3) -> mất thông tin nhưng là xấp xỉ tốt nhất (sai số = giá trị suy biến thứ 3)', r == 2 and abs(err_rank2 - np.linalg.svd(low, compute_uv=False)[2]) < 1e-3)
check('hạng yêu cầu lớn hơn số giá trị suy biến -> kẹp, không lỗi', M.to_lora(np.ones((3, 5), dtype=np.float32), 99, (4, 5), (3, 4))[2] == 3)
cd, cu = rng.standard_normal((4, 6, 3, 3)).astype(np.float32), rng.standard_normal((10, 4, 1, 1)).astype(np.float32)
dl = M.delta_of(cd, cu, 4.0)
nd, nu, nr = M.to_lora(dl, 4, cd.shape, cu.shape)
check('conv: giữ hình dạng (r,in,k,k)/(out,r,1,1) và dựng lại ΔW', nd.shape == (4, 6, 3, 3) and nu.shape == (10, 4, 1, 1) and np.allclose(M.delta_of(nd, nu, float(nr)), dl, atol=1e-3))

# ---------- merge_loras / merge_files ----------
mods = ['lora_unet_x', 'lora_unet_y']
la, lb = M.read_lora(lora(mods, seed=1, alpha=4.0)), M.read_lora(lora(mods, seed=2, alpha=4.0))
out = M.merge_loras([la, lb], [1, 1], 'linear', rank=8)
dlin = M.delta_of(*M.read_lora(out)['lora_unet_x'])
ref = M.delta_of(*la['lora_unet_x']) + M.delta_of(*lb['lora_unet_x'])
check('linear qua merge_loras (hạng đủ lớn) khớp tổng ΔW gốc', np.allclose(dlin, ref, atol=1e-3))
check('đầu ra đúng định dạng kohya: down/up/alpha cho từng module, alpha = hạng', set(out) == {m + s for m in mods for s in (M.DOWN, M.UP, M.ALPHA)} and float(out['lora_unet_x' + M.ALPHA]) == out['lora_unet_x' + M.DOWN].shape[0])
check('đầu ra đọc lại được bằng read_lora (vòng tròn)', set(M.read_lora(out)) == set(mods))
lc = M.read_lora(lora(['lora_unet_x', 'lora_unet_z'], seed=3, alpha=4.0))
oc = M.merge_loras([la, lc], [1, 1], 'ties', 1.0)
check('module chỉ có ở một LoRA vẫn được gộp (không mất); hợp mọi module', set(M.read_lora(oc)) == {'lora_unet_x', 'lora_unet_y', 'lora_unet_z'})
solo = M.delta_of(*M.read_lora(oc)['lora_unet_y'])
check('module chỉ ở một LoRA, density 1 -> ΔW giữ nguyên (xấp xỉ do SVD hạng đủ)', np.allclose(solo, M.delta_of(*la['lora_unet_y']), atol=1e-3))
warns = []
lbad = M.read_lora(lora(['lora_unet_x'], seed=5, shape=(10, 24), alpha=4.0))
ob = M.merge_loras([la, lbad], [1, 1], 'ties', 1.0, warn=warns.append)
check('module khác hình dạng giữa các LoRA -> bỏ qua kèm cảnh báo, module còn lại vẫn gộp', 'lora_unet_x' + M.DOWN not in ob and 'lora_unet_y' + M.DOWN in ob and any('lora_unet_x' in w for w in warns))
check('số trọng số sai -> ValueError; không LoRA -> ValueError', _r(lambda: M.merge_loras([la, lb], [1])) and _r(lambda: M.merge_loras([])))
check('không module nào gộp được -> ValueError rõ ràng', _r(lambda: M.merge_loras([M.read_lora(lora(['a'], seed=1)), M.read_lora(lora(['a'], seed=2, shape=(9, 24)))], [1, 1], warn=lambda s: None)))
check('--scale nhân vào ΔW đã gộp', np.allclose(M.delta_of(*M.read_lora(M.merge_loras([la], [1], 'linear', scale=0.5, rank=8))['lora_unet_x']), 0.5 * M.delta_of(*la['lora_unet_x']), atol=1e-3))

# đầu-cuối với bộ đọc/ghi giả (np.savez) — kiểm cả đường merge_files
import tempfile
tmp = tempfile.mkdtemp()
pa, pb, po = os.path.join(tmp, 'a.npz'), os.path.join(tmp, 'b.npz'), os.path.join(tmp, 'o.npz')
np.savez(pa, **lora(mods, seed=1, alpha=4.0)); np.savez(pb, **lora(mods, seed=2, alpha=4.0))
loader = lambda p: dict(np.load(p)); saver = lambda t, p: np.savez(p, **t)
res = M.merge_files([pa, pb], po, [1, 1], 'ties', 0.5, 8, 0, 1.0, loader, saver)
check('merge_files đầu-cuối: ghi file, đọc lại được, đủ module', os.path.isfile(po) and set(M.read_lora(dict(np.load(po)))) == set(mods) and len(res) == 6)
np.savez(os.path.join(tmp, 'rong.npz'), x=np.zeros(3))
check('file không phải LoRA kohya -> ValueError nêu tên file', _r(lambda: M.merge_files([os.path.join(tmp, 'rong.npz')], po, loader=loader, saver=saver)))
src = open(os.path.join(ROOT, 'tools', 'lora_ties_merge.py'), encoding='utf8').read()
check('safetensors chỉ được import BÊN TRONG merge_files', src.count('from safetensors') == 1 and src.index('from safetensors') > src.index('def merge_files'))
check('CLI kiểm density ∈ (0,1] và liệt kê đủ 4 phương pháp', 'ap.error("--density phải trong (0, 1]")' in src and M.METHODS == ('linear', 'ties', 'dare_ties', 'dare_linear'))

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
