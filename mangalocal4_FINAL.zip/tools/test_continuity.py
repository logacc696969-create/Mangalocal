#!/usr/bin/env python3
"""mục 260 — kiểm thử ContinuityChecker.kt (mở rộng CANVAS: liên tục bối cảnh / nhân vật / vật thể).
Bản chép Python bám từng dòng Kotlin (chưa có kotlinc ở sandbox) + kiểm tĩnh nối dây + thử phá mã. Không chứng minh: mức nhiễu trên truyện thật."""
import os, re, sys, random
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/')
def rd(p): return open(J + p, encoding='utf-8').read()
KT, PIPE, MODELS, SET, HELP = rd('pipeline/ContinuityChecker.kt'), rd('pipeline/MangaPipeline.kt'), rd('model/Models.kt'), rd('ui/SettingsScreen.kt'), rd('ui/ParamHelp.kt')
ok = True
def check(name, cond, detail=''):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + detail) if (detail and not cond) else ''))
    ok &= bool(cond)

MUT = set()
def norm(s): return s.strip().lower()
def E(i, loc='', chars=(), objs=()): return (i, loc, frozenset(chars), frozenset(objs))
def check_run(run, out):
    n = len(run)
    for i in range(n):
        if run[i][1] != '': continue
        p = i - 1
        while p >= 0 and run[p][1] == '': p -= 1
        q = i + 1
        while q < n and run[q][1] == '': q += 1
        if p >= 0 and q < n and (run[p][1] == run[q][1] or 'drift_any' in MUT): out.add(('LOCATION_DRIFT', run[i][0], run[p][1]))
    for i in range(1, n - 1):
        loc = run[i][1]
        if loc == '' or ((run[i - 1][1] != loc or run[i + 1][1] != loc) and 'gap_anyloc' not in MUT): continue
        if not run[i][2] and 'gap_empty_ok' not in MUT: continue
        for c in run[i - 1][2] & run[i + 1][2]:
            if c not in run[i][2]: out.add(('CHARACTER_GAP', run[i][0], c))
    for a in range(n):
        loc = run[a][1]
        if loc == '': continue
        for label in run[a][3]:
            b = a + 1
            while b < n and (run[b][1] == loc or 'prop_anyloc' in MUT):
                if label in run[b][3]:
                    for k in range(a + 1, b):
                        if label not in run[k][3] and (run[k][3] or 'prop_empty_ok' in MUT): out.add(('PROP_GAP', run[k][0], label))
                    break
                b += 1
def run_check(entries):
    s = sorted(((i, norm(l), frozenset(x for x in (norm(c) for c in ch) if x), frozenset(x for x in (norm(o) for o in ob) if x)) for i, l, ch, ob in entries), key=lambda e: e[0])
    out = set(); start = 0
    while start < len(s):
        end = start + 1
        while end < len(s) and (s[end][0] == s[end - 1][0] + 1 or 'no_runs' in MUT): end += 1
        check_run(s[start:end], out); start = end
    return sorted(out, key=lambda w: (w[1], ['LOCATION_DRIFT', 'CHARACTER_GAP', 'PROP_GAP'].index(w[0]), w[2]))

# ---------- ca cụ thể ----------
A = 'Phòng ngủ'
r = run_check([E(0, A), E(1, ''), E(2, A)])
check('LOCATION_DRIFT: panel không khai bối cảnh nằm giữa hai panel cùng bối cảnh', r == [('LOCATION_DRIFT', 1, 'phòng ngủ')], str(r))
check('LOCATION_DRIFT: hai bối cảnh KHÁC nhau hai bên -> không cảnh báo (có thể chuyển cảnh)', run_check([E(0, A), E(1, ''), E(2, 'Phố')]) == [])
check('LOCATION_DRIFT: cả đoạn không khai bối cảnh -> không cảnh báo', run_check([E(0), E(1), E(2)]) == [])
check('LOCATION_DRIFT: nhiều panel trống liên tiếp giữa cùng bối cảnh đều bị báo', [w[1] for w in run_check([E(0, A), E(1), E(2), E(3, A)])] == [1, 2])
check('LOCATION_DRIFT: panel trống ở ĐẦU hoặc CUỐI đoạn (thiếu một bên) không bị báo', run_check([E(0), E(1, A), E(2, A), E(3)]) == [])
r = run_check([E(0, A, ['An', 'Bình']), E(1, A, ['An']), E(2, A, ['An', 'Bình'])])
check('CHARACTER_GAP: Bình có ở panel 0 và 2, vắng panel 1 (có An) -> báo đúng nhân vật, đúng panel', r == [('CHARACTER_GAP', 1, 'bình')], str(r))
check('CHARACTER_GAP: panel giữa KHÔNG có ai (cảnh nền) -> không báo', run_check([E(0, A, ['An']), E(1, A, []), E(2, A, ['An'])]) == [])
check('CHARACTER_GAP: khác bối cảnh -> không báo (cắt cảnh hợp lệ)', run_check([E(0, A, ['An']), E(1, 'Phố', ['Bình']), E(2, A, ['An'])]) == [])
check('CHARACTER_GAP: thiếu bối cảnh (rỗng) -> không báo (không đủ căn cứ cùng cảnh)', run_check([E(0, '', ['An']), E(1, '', ['Bình']), E(2, '', ['An'])]) == [])
check('CHARACTER_GAP: vắng ở 2 panel liên tiếp -> không báo (chỉ bắt khoảng hở đúng 1 panel)', run_check([E(0, A, ['An', 'B']), E(1, A, ['An']), E(2, A, ['An']), E(3, A, ['An', 'B'])]) == [])
r = run_check([E(0, A, objs=['bàn']), E(1, A, objs=['ghế']), E(2, A, objs=['bàn'])])
check('PROP_GAP: bàn có ở panel 0 và 2, panel 1 khai vật khác (ghế) thiếu bàn -> báo', r == [('PROP_GAP', 1, 'bàn')], str(r))
check('PROP_GAP: panel giữa không khai vật nào -> không báo (chưa khai ≠ biến mất)', run_check([E(0, A, objs=['bàn']), E(1, A), E(2, A, objs=['bàn'])]) == [])
check('PROP_GAP: panel giữa khác bối cảnh -> không báo', run_check([E(0, A, objs=['bàn']), E(1, 'Phố', objs=['xe']), E(2, A, objs=['bàn'])]) == [])
check('PROP_GAP: liền nhau (b-a=1) không có panel giữa -> không báo', run_check([E(0, A, objs=['bàn']), E(1, A, objs=['bàn'])]) == [])
check('chuẩn hoá: hoa/thường và khoảng trắng không tạo khác biệt', run_check([E(0, '  PHÒNG ngủ ', ['An ']), E(1, 'phòng NGỦ', ['an', 'Bình']), E(2, 'phòng ngủ', ['AN ', 'bình '])]) == [('CHARACTER_GAP', 1, 'bình')] or
      run_check([E(0, '  PHÒNG ngủ ', ['Bình ']), E(1, 'phòng NGỦ', ['an']), E(2, 'phòng ngủ', [' bình'])]) == [('CHARACTER_GAP', 1, 'bình')])
check('chuỗi rỗng/khoảng trắng trong tên nhân vật bị bỏ (không sinh cảnh báo ma)', run_check([E(0, A, [' ', 'An']), E(1, A, ['An']), E(2, A, ['', 'An'])]) == [])
check('chỉ số panel KHÔNG liên tiếp (sinh lại lẻ) -> tách đoạn, không báo khoảng hở giả', run_check([E(0, A, ['An', 'Bình']), E(5, A, ['An']), E(9, A, ['An', 'Bình'])]) == [])
check('đầu vào không theo thứ tự vẫn ra kết quả đúng (tự sắp theo chỉ số)',
      run_check([E(2, A, ['An', 'Bình']), E(0, A, ['An', 'Bình']), E(1, A, ['An'])]) == [('CHARACTER_GAP', 1, 'bình')])
check('rỗng / 1-2 panel không crash và không báo', run_check([]) == [] and run_check([E(0, A, ['An'])]) == [] and run_check([E(0, A, ['An']), E(1, A, [])]) == [])

# ---------- fuzz: bất biến ----------
def fuzz(seed=3, runs=2500):
    rng = random.Random(seed)
    locs = ['', 'A', 'B']; chars = ['x', 'y', 'z']; objs = ['o1', 'o2']
    for _ in range(runs):
        n = rng.randint(0, 9); idx = sorted(rng.sample(range(0, 14), n))
        ents = [E(i, rng.choice(locs), rng.sample(chars, rng.randint(0, 3)), rng.sample(objs, rng.randint(0, 2))) for i in idx]
        res = run_check(ents)
        byi = {e[0]: e for e in ents}
        if res != run_check(list(reversed(ents))): return 'kết quả phụ thuộc thứ tự đầu vào'
        for kind, pi, subj in res:
            e = byi.get(pi)
            if e is None: return f'cảnh báo cho panel không tồn tại {pi}'
            prev, nxt = byi.get(pi - 1), byi.get(pi + 1)
            if kind == 'LOCATION_DRIFT' and e[1] != '': return 'drift ở panel ĐÃ có bối cảnh'
            if kind == 'CHARACTER_GAP':
                if prev is None or nxt is None: return 'gap ở panel không có hàng xóm 2 phía'
                if not (subj in prev[2] and subj in nxt[2] and subj not in e[2]): return 'gap sai điều kiện nhân vật'
                if not (e[1] == prev[1] == nxt[1] != '' and e[2]): return 'gap sai điều kiện bối cảnh/trống'
            if kind == 'PROP_GAP':
                if subj in e[3] or not e[3] or e[1] == '': return 'prop gap sai điều kiện'
        if len(res) != len(set(res)): return 'có cảnh báo trùng'
    return None
res = fuzz()
check('FUZZ 2500 truyện ngẫu nhiên: cảnh báo chỉ ở panel thật, đúng điều kiện từng loại, không trùng, không phụ thuộc thứ tự nhập', res is None, str(res))

# ---------- nối dây ----------
check('Kotlin: ContinuityChecker có 3 loại cảnh báo và tách theo đoạn chỉ số liên tiếp',
      all(k in KT for k in ['LOCATION_DRIFT', 'CHARACTER_GAP', 'PROP_GAP']) and 'sorted[end].panelIndex == sorted[end - 1].panelIndex + 1' in KT)
check('Kotlin: drift chỉ khi bối cảnh trước và sau GIỐNG nhau', 'run[p].location == run[q].location' in KT)
check('Kotlin: gap nhân vật cần 3 panel cùng bối cảnh không rỗng và panel giữa có người', 'run[i - 1].location != loc || run[i + 1].location != loc' in KT and 'if (run[i].characters.isEmpty()) continue' in KT)
check('Kotlin: gap vật thể chỉ khi panel giữa khai vật khác (isNotEmpty)', 'label !in run[k].objects && run[k].objects.isNotEmpty()' in KT)
check('Pipeline: gọi sau kiểm tỉ lệ, chỉ khi bật cờ, bọc try/catch (lỗi không làm hỏng tiến trình)',
      'if (settings.checkContinuity) {\n                try { logContinuityWarnings(completedPanels) }' in PIPE and 'Kiểm tra liên tục lỗi' in PIPE)
_st = PIPE.index('private fun logContinuityWarnings(panels: List<Panel>) {')
_body = PIPE[_st:PIPE.index('\n    }\n', _st)]
check('Pipeline: logContinuityWarnings chỉ ghi log (không gọi sinh ảnh, không lưu, không copy dữ liệu)',
      'log(' in _body and not any(t in _body for t in ['imagePipeline', 'storyManager', '.copy(', 'saveChapter', 'generatePanel']), _body[:200])
check('Cài đặt: checkContinuity mặc định BẬT (chỉ log, không đổi đầu ra) + công tắc + trợ giúp', 'val checkContinuity: Boolean = true' in MODELS and 'HelpSwitch(helpKey = "checkContinuity"' in SET and '"checkContinuity" to e(' in HELP)
check('ngoặc {} () [] cân bằng ở ContinuityChecker.kt', all(KT.count(a) == KT.count(b) for a, b in ['{}', '()', '[]']))

# ---------- thử phá mã ----------
muts = ['drift_any', 'gap_anyloc', 'gap_empty_ok', 'prop_anyloc', 'prop_empty_ok', 'no_runs']
def probe(m):
    MUT.clear(); MUT.add(m)
    try:
        t = [
            run_check([E(0, A), E(1, ''), E(2, 'Phố')]) != [],
            run_check([E(0, A, ['An']), E(1, 'Phố', ['Bình']), E(2, A, ['An'])]) != [],
            run_check([E(0, A, ['An']), E(1, A, []), E(2, A, ['An'])]) != [],
            run_check([E(0, A, objs=['bàn']), E(1, 'Phố', objs=['xe']), E(2, A, objs=['bàn'])]) != [],
            run_check([E(0, A, objs=['bàn']), E(1, A), E(2, A, objs=['bàn'])]) != [],
            run_check([E(0, A, ['An', 'Bình']), E(5, A, ['An']), E(9, A, ['An', 'Bình'])]) != [],
        ]
        return any(t) or fuzz(seed=5, runs=400) is not None
    finally: MUT.clear()
c = 0
for m in muts:
    d = probe(m); c += d; check(f'đột biến "{m}" bị bắt', d)
check(f'bắt đủ {len(muts)}/{len(muts)} đột biến', c == len(muts))
print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
