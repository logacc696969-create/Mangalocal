#!/usr/bin/env python3
"""mục 266 — kiểm thử `pipeline/HttpRetryPolicy.kt` (chính sách thử lại cho API ngoài bậc miễn phí) bằng kotlinc THẬT.

Đối chiếu với bản tham chiếu Python viết ĐỘC LẬP từ quy tắc (không dịch từ Kotlin): chỉ thử lại lỗi tạm thời (408/425/429/5xx/lỗi mạng); 429 hết hạn mức THEO NGÀY thì bỏ ngay;
Retry-After (giây nguyên/thập phân làm tròn lên, hoặc ngày RFC 1123) được tôn trọng, > 120 giây thì bỏ; không có Retry-After thì lùi cấp số nhân kẹp 30 giây (+ tối đa 25% jitter);
đủ số lần thì bỏ. Fuzz 6000 tình huống ngẫu nhiên + các ca biên tường minh. Kèm thử phá mã.
KHÔNG chứng minh: hành vi thật của từng nhà cung cấp (định dạng Retry-After/thân lỗi có thể khác — chỉ kiểm các dạng đã biết), và việc ExternalLlmClient/FreeImageClient gọi đúng chính sách
(phần mạng là mã Android, chỉ biên dịch trên CI). Cần kotlinc (không có -> SKIP).
"""
import email.utils, datetime, math, os, random, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + str(d)[:400]) if (d and not c) else '')); ok &= bool(c)
def find():
    for c in [os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/work/kotlinc/bin/kotlinc', '/home/claude/tools_dl/kotlinc/bin/kotlinc']:
        if c and os.path.exists(c): return c
KOTLINC = find()
if not KOTLINC:
    print('SKIP: không có kotlinc'); sys.exit(0)
KLIB = os.path.join(os.path.dirname(os.path.dirname(KOTLINC)), 'lib', 'kotlin-stdlib.jar')

DRIVER = r'''
import com.mangalocal.pipeline.*
import java.io.File
fun hex(s: String): String = s.toByteArray(Charsets.UTF_8).joinToString("") { "%02x".format(it) }
fun unhex(h: String): String { if (h == "-") return ""; val b = ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }; return String(b, Charsets.UTF_8) }
fun main(args: Array<String>) {
    val out = StringBuilder()
    for (line in File(args[0]).readLines()) {
        if (line.isEmpty()) continue
        val p = line.split("\t")
        when (p[0]) {
            "D" -> {
                val ra: String? = if (p[2] == "NULL") null else unhex(p[2])
                val d = HttpRetryPolicy.decide(p[1].toInt(), ra, unhex(p[3]), p[4].toInt(), p[5].toInt(), p[6].toLong(), p[7].toDouble())
                out.append(when (d) { is HttpRetryPolicy.Decision.Retry -> "R ${d.delayMs}"; is HttpRetryPolicy.Decision.GiveUp -> "G " + hex(d.reason) }).append("\n")
            }
            "B" -> out.append(HttpRetryPolicy.backoffMs(p[1].toInt(), p[2].toDouble())).append("\n")
            "RA" -> out.append(HttpRetryPolicy.parseRetryAfterMs(if (p[1] == "NULL") null else unhex(p[1]), p[2].toLong())?.toString() ?: "null").append("\n")
            "Q" -> out.append(HttpRetryPolicy.isDailyQuotaExhausted(unhex(p[1]))).append("\n")
            "T" -> out.append(HttpRetryPolicy.isRetryable(p[1].toInt())).append("\n")
            "F" -> out.append(hex(HttpRetryPolicy.failureMessage(p[1].toInt(), unhex(p[2])))).append("\n")
        }
    }
    File(args[1]).writeText(out.toString())
}
'''
def hx(s): return s.encode('utf-8').hex() if s else '-'
def unhx(h): return bytes.fromhex(h).decode('utf-8') if h != '-' else ''

# ---------- bản tham chiếu Python (viết từ quy tắc) ----------
RETRYABLE = {-1, 408, 425, 429, 500, 502, 503, 504}
DAILY = ['perday', 'per day', 'per-day', 'per_day', 'daily free allocation', 'daily limit', 'daily quota', 'free-models-per-day']
def ref_daily(body):
    low = body.lower()
    return any(m in low for m in DAILY) or re.search(r'"code"\s*:\s*3036\b', body) is not None
def ref_ra(h, now):
    if h is None: return None
    h = h.strip()
    if not h: return None
    if re.fullmatch(r'\d+(\.\d+)?', h): return int(math.ceil(float(h) * 1000.0))
    try:
        dt = email.utils.parsedate_to_datetime(h)
    except Exception:
        return None
    if dt is None or dt.tzinfo is None: return None
    return max(0, int(dt.timestamp() * 1000) - now)
def ref_backoff(attempt, jit):
    a = min(max(attempt, 1), 30)
    d = min(2000 * (2 ** (a - 1)), 30000)
    return d + int(d * 0.25 * min(max(jit, 0.0), 1.0))
def ref_decide(code, ra, body, attempt, mx, now, jit):
    if code not in RETRYABLE: return 'G'
    if code == 429 and ref_daily(body): return 'G'
    if attempt >= mx: return 'G'
    r = ref_ra(ra, now)
    if r is not None and r > 120000: return 'G'
    return f'R {r if r is not None else ref_backoff(attempt, jit)}'

rng = random.Random(266)
NOW = 1_800_000_000_000
def http_date(delta_s):
    dt = datetime.datetime.fromtimestamp(NOW / 1000 + delta_s, datetime.timezone.utc)
    return email.utils.format_datetime(dt, usegmt=True)
RAS = [None, '', '  ', '0', '1', '5', '1.5', '0.2', '30', '120', '120.001', '121', '3600', '86400', '-5', 'abc', '5s', '1e3', 'tomorrow', '12 Oct',
       '0.0001', '1.0001', '2.0004', '7.3333', '119.9999', '120.0001']   # 6 giá trị cuối: phần thập phân thật sự làm LÊN khác XUỐNG (các giá trị cũ cho kết quả nguyên nên không phân biệt được)
RAS += [http_date(d) for d in (-100, 0, 10, 90, 119, 121, 4000)]
BODIES = ['', 'oops', 'Rate limit exceeded: free-models-per-day', '{"error":{"code":429,"status":"RESOURCE_EXHAUSTED","details":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel-FreeTier"}]}}',
          '{"error":{"code":429,"details":[{"quotaId":"GenerateRequestsPerMinutePerProjectPerModel-FreeTier"}]}}',
          '{"success":false,"errors":[{"code":3036,"message":"You have used up your daily free allocation of 10,000 neurons"}]}', '{"errors":[{"code": 3036 }]}', '{"errors":[{"code":30360}]}',
          '{"code":13036}', 'Daily Limit Reached', 'too many requests']
CODES = [-1, 200, 400, 401, 403, 404, 408, 413, 425, 429, 429, 429, 500, 502, 503, 504, 599, 418]

cases = []
for _ in range(6000):
    cases.append((rng.choice(CODES), rng.choice(RAS), rng.choice(BODIES), rng.randint(1, 6), rng.randint(1, 6), NOW, rng.choice([0.0, 0.5, 1.0, rng.random(), -1.0, 2.0])))
def kt_ra(h): return 'NULL' if h is None else hx(h)

def lines_for():
    L = []
    for c in cases: L.append('\t'.join(['D', str(c[0]), kt_ra(c[1]), hx(c[2]), str(c[3]), str(c[4]), str(c[5]), repr(c[6])]))
    for a in list(range(-3, 41)): L.append(f'B\t{a}\t{rng_j(a)}')
    for h in RAS: L.append(f'RA\t{kt_ra(h)}\t{NOW}')
    for b in BODIES: L.append('Q\t' + hx(b))
    for c in CODES + [0, -2, 100, 600]: L.append(f'T\t{c}')
    L.append('F\t401\t' + hx('{"error": "bad   key"}'))
    L.append('F\t429\t' + hx('x' * 500))
    L.append('F\t-1\t-')
    L.append('F\t503\t' + hx('  nhiều\n\n  khoảng   trắng  '))
    return L
def rng_j(a): return repr(((a * 37) % 11) / 10.0)

def verify(res):
    errs = []; i = 0
    for c in cases:
        want = ref_decide(*c); got = res[i]; i += 1
        if want == 'G':
            if not got.startswith('G'): errs.append(('decide', c, want, got))
        elif got != want: errs.append(('decide', c, want, got))
    for a in range(-3, 41):
        want = str(ref_backoff(a, ((a * 37) % 11) / 10.0)); got = res[i]; i += 1
        if got != want: errs.append(('backoff', a, want, got))
    for h in RAS:
        want = ref_ra(h, NOW); got = res[i]; i += 1
        if got != ('null' if want is None else str(want)): errs.append(('retry-after', h, want, got))
    for b in BODIES:
        want = 'true' if ref_daily(b) else 'false'; got = res[i]; i += 1
        if got != want: errs.append(('daily', b[:40], want, got))
    for c in CODES + [0, -2, 100, 600]:
        want = 'true' if c in RETRYABLE else 'false'; got = res[i]; i += 1
        if got != want: errs.append(('retryable', c, want, got))
    m401, m429, mnet, m503 = (unhx(res[i + k]) for k in range(4))
    if not (m401.startswith('Khoá/token API sai') and '401' in m401 and 'bad key' in m401): errs.append(('msg401', m401))
    if not (m429.startswith('Bị giới hạn') and len(m429) <= len('Bị giới hạn tần suất/hạn mức (429): ') + 200): errs.append(('msg429-len', len(m429)))
    if not (mnet.startswith('Lỗi mạng') and ':' not in mnet): errs.append(('msgnet', mnet))
    if not (m503.endswith('nhiều khoảng trắng') and '\n' not in m503): errs.append(('msg503', m503))
    # lý do khi bỏ vì hết hạn mức ngày phải nói rõ (người dùng cần biết đổi nguồn/đợi hôm sau)
    daily_cases = [(k, c) for k, c in enumerate(cases) if c[0] == 429 and ref_daily(c[2]) and c[4] > c[3]]
    if daily_cases and 'hết hạn mức' not in unhx(res[daily_cases[0][0]][2:]).lower(): errs.append(('daily-reason', unhx(res[daily_cases[0][0]][2:])))
    return errs

tmp = tempfile.mkdtemp()
def compile_(src, tag):
    d = os.path.join(tmp, tag); os.makedirs(d, exist_ok=True)
    open(os.path.join(d, 'Drv.kt'), 'w').write(DRIVER)
    jar = os.path.join(tmp, tag + '.jar')
    r = subprocess.run([KOTLINC, src, os.path.join(d, 'Drv.kt'), '-d', jar], capture_output=True, text=True)
    return jar, r
def run(jar, lines):
    fi = os.path.join(tmp, 'in.txt'); fo = os.path.join(tmp, 'out.txt')
    open(fi, 'w').write('\n'.join(lines) + '\n')
    r = subprocess.run(['java', '-cp', f'{jar}:{KLIB}', 'DrvKt', fi, fo], capture_output=True, text=True)
    if r.returncode != 0: return None, r.stderr[-500:]
    return open(fo, encoding='utf-8').read().split('\n')[:len(lines)], ''

SRC = os.path.join(KT, 'HttpRetryPolicy.kt')
jar, r = compile_(SRC, 'orig')
check('HttpRetryPolicy.kt biên dịch bằng kotlinc thật', r.returncode == 0, r.stderr[-600:])
if r.returncode != 0:
    print('CÓ LỖI'); sys.exit(1)
L = lines_for()
res, err = run(jar, L)
check('chạy driver', res is not None, err)
errs = verify(res) if res else [('run', err)]
check(f'khớp bản tham chiếu độc lập: {len(cases)} tình huống decide, backoff 1..30, {len(RAS)} giá trị Retry-After, {len(BODIES)} thân lỗi, mã retryable, thông báo lỗi', not errs, errs[:3])
# phân bố: ca nào cũng xảy ra thật (nếu không thì fuzz vô nghĩa)
dist = {'R': 0, 'G': 0}
for c in cases:
    dist[ref_decide(*c)[0]] += 1
check(f'fuzz có cả ca thử lại ({dist["R"]}) lẫn ca bỏ ({dist["G"]})', dist['R'] > 500 and dist['G'] > 500, dist)
daily429 = sum(1 for c in cases if c[0] == 429 and ref_daily(c[2]) and c[4] > c[3])
check(f'fuzz có ca 429 hết hạn mức ngày còn lượt thử ({daily429}) — chốt này quyết định có đốt hạn mức hay không', daily429 > 30, daily429)
# ca tường minh dễ đọc
def one(code, ra, body, attempt=1, mx=4, jit=0.0):
    rs, e = run(jar, ['\t'.join(['D', str(code), kt_ra(ra), hx(body), str(attempt), str(mx), str(NOW), repr(jit)])])
    return rs[0] if rs else e
check('429 không Retry-After, lần 1/4 -> thử lại sau 2000 ms', one(429, None, '') == 'R 2000', one(429, None, ''))
check('429 Retry-After 7 -> chờ đúng 7000 ms (không tự đặt lùi cấp số)', one(429, '7', '') == 'R 7000')
check('429 Retry-After 121 giây -> bỏ (không treo lượt sinh)', one(429, '121', '').startswith('G'))
check('401 -> bỏ ngay, không thử lại (thử lại chỉ đốt hạn mức)', one(401, None, '').startswith('G'))
check('lần thử cuối (4/4) -> bỏ', one(503, None, '', 4, 4).startswith('G'))

# ---------- thử phá mã ----------
base = open(SRC, encoding='utf-8').read()
MUT = [
    ('429 không còn được coi là đáng thử lại', 'code == 408 || code == 425 || code == 429 ||', 'code == 408 || code == 425 ||'),
    ('lỗi mạng không còn đáng thử lại', 'code == NETWORK_ERROR || code == 408', 'code == 408'),
    ('401 bị coi là đáng thử lại (đốt hạn mức)', 'code == 408 || code == 425', 'code == 401 || code == 408 || code == 425'),
    ('bỏ chốt hết hạn mức theo ngày', 'if (code == 429 && isDailyQuotaExhausted(body)) {', 'if (false) {'),
    ('bỏ dấu hiệu "perday" của Gemini', '"perday", ', ''),
    ('bỏ nhận diện mã 3036 của Cloudflare', 'return Regex("\\"code\\"\\\\s*:\\\\s*3036\\\\b").containsMatchIn(body)', 'return false'),
    ('đủ số lần vẫn thử tiếp (>= thành >)', 'if (attempt >= maxAttempts) return Decision.GiveUp', 'if (attempt > maxAttempts) return Decision.GiveUp'),
    ('bỏ chốt Retry-After quá lâu (ngưỡng không bao giờ đạt; vẫn biên dịch được nhờ giữ smart-cast của ra)', 'if (ra != null && ra > MAX_ACCEPTED_WAIT_MS) {', 'if (ra != null && ra > Long.MAX_VALUE) {'),
    ('lùi không nhân đôi', 'for (i in 1 until a) { d *= 2;', 'for (i in 1 until a) { d *= 1;'),
    ('Retry-After làm tròn xuống thay vì lên', 'return Math.ceil(sec * 1000.0).toLong()', 'return Math.floor(sec * 1000.0).toLong()'),
    ('ngày HTTP trong quá khứ cho độ trễ âm', '(t - nowMs).coerceAtLeast(0L)', '(t - nowMs)'),
    ('bỏ qua Retry-After (luôn lùi cấp số)', 'val delay = ra ?: backoffMs(attempt, jitter01)', 'val delay = backoffMs(attempt, jitter01)'),
    ('thông báo lỗi không cắt thân phản hồi', '.trim().take(200)', '.trim()'),
]
lo, hi = 0, len(MUT)
if os.environ.get('MUT_RANGE'):
    a, b = os.environ['MUT_RANGE'].split(':'); lo, hi = int(a), int(b)
killed = ran = 0
for i in range(lo, min(hi, len(MUT))):
    name, old, new = MUT[i]
    if base.count(old) != 1:
        check(f'đột biến {i} có điểm cắm duy nhất ({name})', False, f'{base.count(old)} chỗ'); continue
    mp = os.path.join(tmp, f'HttpRetryPolicy_m{i}.kt'); open(mp, 'w', encoding='utf-8').write(base.replace(old, new))
    j, rr = compile_(mp, f'mut{i}')
    if rr.returncode != 0:
        check(f'đột biến {i} biên dịch được ({name})', False, rr.stderr[-300:]); continue
    ran += 1
    res2, e2 = run(j, L)
    survived = res2 is not None and not verify(res2)
    check(f'đột biến "{name}" bị bộ kiểm bắt', not survived)
    killed += (not survived)
if ran: check(f'thử phá mã: {killed}/{ran} đột biến bị bắt', killed == ran)
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
