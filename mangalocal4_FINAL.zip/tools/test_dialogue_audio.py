#!/usr/bin/env python3
"""mục 248 — kiểm thử DialogueAudio (lồng tiếng TTS cho gói video).

Chạy được: kế hoạch file/tên/thứ tự, cao độ theo tên (mô phỏng tràn Int 32-bit của Kotlin), đọc độ dài WAV với file WAV
THẬT sinh bằng module `wave`. KHÔNG chạy được: TextToSpeech của Android (không có thiết bị) — phần gọi API chỉ được đối
chiếu chuỗi nguồn; nó CHƯA được thử trên máy.
"""
import io, os, re, struct, sys, wave
import xml.dom.minidom as minidom

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
KB = os.path.join(ROOT, 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(KB, *p), encoding='utf8').read()
KT = rd('pipeline', 'DialogueAudio.kt')
const = lambda n: float(re.search(r'const val %s = ([0-9._]+)' % n, KT).group(1).replace('_', ''))
MAX_CHARS, PITCH_MIN, PITCH_MAX = int(const('MAX_CHARS')), const('PITCH_MIN'), const('PITCH_MAX')

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

# ---- bản chép ----
def plan(panels):
    out = []
    for idx, lines in sorted(panels, key=lambda p: p[0]):
        for li, (who, text) in enumerate(lines):
            t = text.strip()[:MAX_CHARS]
            if t: out.append((idx, li, who, t, 'p%03d_l%02d.wav' % (idx + 1, li + 1)))
    return out

def i32(x): return ((x + 2 ** 31) % 2 ** 32) - 2 ** 31
def pitch_for(name):
    h = 7
    for c in name.strip().lower(): h = i32(h * 31 + ord(c))
    u = ((h & 0x7fffffff) % 1000) / 999.0
    return PITCH_MIN + u * (PITCH_MAX - PITCH_MIN)

def wav_seconds(b):
    if len(b) < 44 or b[0:4] != b'RIFF' or b[8:12] != b'WAVE': return None
    o = 12; rate = ch = bits = 0
    while o + 8 <= len(b):
        cid = b[o:o + 4]; size = struct.unpack_from('<I', b, o + 4)[0]; body = o + 8
        if cid == b'fmt ' and body + 16 <= len(b):
            ch = struct.unpack_from('<H', b, body + 2)[0]; rate = struct.unpack_from('<I', b, body + 4)[0]; bits = struct.unpack_from('<H', b, body + 14)[0]
        elif cid == b'data':
            rem = len(b) - body
            data = rem if size == 0 or size > rem else size
            bps = rate * ch * (bits // 8)
            return None if bps <= 0 else data / bps
        nxt = body + size + (size & 1)
        if nxt > len(b): return None
        o = nxt
    return None

def make_wav(seconds, rate=22050, ch=1, width=2):
    buf = io.BytesIO()
    with wave.open(buf, 'wb') as w:
        w.setnchannels(ch); w.setsampwidth(width); w.setframerate(rate)
        w.writeframes(b'\x00' * int(seconds * rate) * ch * width)
    return buf.getvalue()

# ---- kế hoạch ----
P = [(2, [('An', 'Chào  '), ('Bình', '   '), ('An', 'Tạm biệt')]), (0, [('Bình', 'Xin chào')]), (1, [])]
pl = plan(P)
check('sắp theo chỉ số panel rồi thứ tự thoại, bỏ câu rỗng/khoảng trắng', [(a, b) for a, b, *_ in pl] == [(0, 0), (2, 0), (2, 2)])
check('tên file 1-based, ổn định: p001_l01.wav ...', [x[4] for x in pl] == ['p001_l01.wav', 'p003_l01.wav', 'p003_l03.wav'])
check('chỉ số dòng giữ vị trí gốc kể cả khi bỏ dòng rỗng (không đánh lại số)', pl[2][1] == 2)
check('cắt tối đa %d ký tự mỗi câu và bỏ khoảng trắng đầu/cuối' % MAX_CHARS, len(plan([(0, [('A', 'x' * 1000)])])[0][3]) == MAX_CHARS and plan(P)[1][3] == 'Chào')
check('không có thoại -> kế hoạch rỗng', plan([(0, []), (1, [])]) == [])
check('tên file không trùng giữa mọi câu', len({x[4] for x in plan([(i, [('A', 'a'), ('B', 'b')]) for i in range(30)])}) == 60)

# ---- pitch ----
names = ['An', 'Bình', 'Linh', 'Minh', 'Hoa', 'Nam', 'Trang', 'Quân', 'Lan', 'Khôi', 'a', 'A ']
ps = [pitch_for(n) for n in names]
check('pitch luôn trong [%.2f, %.2f]' % (PITCH_MIN, PITCH_MAX), all(PITCH_MIN - 1e-6 <= p <= PITCH_MAX + 1e-6 for p in ps))
check('pitch ổn định (cùng tên cùng giá trị), không phân biệt hoa/thường và khoảng trắng đầu cuối', pitch_for('Linh') == pitch_for('  linh ') and pitch_for('a') == pitch_for('A '))
check('các nhân vật khác nhau thường có pitch khác nhau (≥ 8/10 giá trị riêng biệt)', len({round(pitch_for(n), 4) for n in names[:10]}) >= 8)
check('mô phỏng tràn 32-bit: tên rất dài không lỗi và vẫn trong khoảng', PITCH_MIN <= pitch_for('x' * 5000) <= PITCH_MAX)

# ---- độ dài WAV (file thật) ----
check('WAV mono 22.05kHz 16-bit dài 2.0s -> ≈2.0', abs(wav_seconds(make_wav(2.0)) - 2.0) < 1e-3)
check('WAV stereo 44.1kHz 16-bit dài 1.5s -> ≈1.5', abs(wav_seconds(make_wav(1.5, 44100, 2)) - 1.5) < 1e-3)
w = bytearray(make_wav(1.0)); di = w.index(b'data'); struct.pack_into('<I', w, di + 4, 0xFFFFFFFF)
check('tiêu đề data = 0xFFFFFFFF (kiểu ghi luồng) -> dùng số byte còn lại', abs(wav_seconds(bytes(w)) - 1.0) < 1e-3)
w = bytearray(make_wav(1.0)); struct.pack_into('<I', w, di + 4, 0)
check('tiêu đề data = 0 -> dùng số byte còn lại', abs(wav_seconds(bytes(w)) - 1.0) < 1e-3)
check('không phải RIFF / quá ngắn / rỗng -> None', wav_seconds(b'OggS' + b'\x00' * 100) is None and wav_seconds(b'RIFF') is None and wav_seconds(b'') is None)
# WAV có chunk phụ (LIST) lẻ byte phía trước data -> phải nhảy qua đúng (đệm chẵn)
base = make_wav(1.0); fmt_end = base.index(b'data')
lst = b'LIST' + struct.pack('<I', 3) + b'abc' + b'\x00'
w2 = base[:fmt_end] + lst + base[fmt_end:]
w2 = bytearray(w2); struct.pack_into('<I', w2, 4, len(w2) - 8)
check('chunk phụ có kích thước LẺ được đệm chẵn rồi nhảy qua đúng -> vẫn ≈1.0s', abs(wav_seconds(bytes(w2)) - 1.0) < 1e-3)
check('fmt hỏng (tốc độ lấy mẫu 0) -> None, không chia cho 0', wav_seconds(bytes(bytearray(make_wav(1.0)[:24]) + b'\x00\x00\x00\x00' + make_wav(1.0)[28:])) is None)

# ---- đối chiếu nguồn Kotlin + nối dây ----
MP, MD, PE, VM, ST = rd('pipeline', 'MangaPipeline.kt'), rd('model', 'Models.kt'), rd('pipeline', 'PublishExporter.kt'), rd('ui', 'MainViewModel.kt'), rd('ui', 'SettingsScreen.kt')
check('Kotlin: dùng đúng API synthesizeToFile(text, Bundle, File, id) + onDone + isLanguageAvailable',
      'tts.synthesizeToFile(item.text, Bundle(), file, id)' in KT and 'override fun onDone' in KT and 'tts.isLanguageAvailable(locale) < TextToSpeech.LANG_AVAILABLE' in KT)
check('Kotlin: luôn shutdown TTS (finally) và có thời hạn cho init + từng câu', 'tts.shutdown()' in KT and 'finally {' in KT and 'withTimeoutOrNull(INIT_TIMEOUT_MS)' in KT and 'withTimeoutOrNull(ITEM_TIMEOUT_MS)' in KT)
check('Kotlin: thiếu giọng/TTS KHÔNG ném lỗi (trả rỗng, ghi log)', KT.count('return@withContext emptyList()') >= 2)
check('Kotlin: setLanguage gọi dạng hàm (không dùng thuộc tính tổng hợp vì setter trả Int)', 'tts.setLanguage(locale)' in KT and 'tts.language =' not in KT)
check('Kotlin: tên file và công thức pitch/độ dài khớp bản chép', '"p%03d_l%02d.wav".format(p.index + 1, li + 1)' in KT and 'h = h * 31 + c.code' in KT and '(h and 0x7fffffff) % 1000' in KT and 'size == 0L || size > remaining' in KT and 'size and 1L' in KT)
check('nối dây: Settings -> ViewModel -> ExportExtras -> exportVideoPack(speech=)', 'exportVideoSpeech: Boolean = false' in MD and 'videoSpeech = st.exportVideoSpeech' in VM
      and 'val videoSpeech: Boolean = false' in PE and 'speech = extras.videoSpeech' in MP and 'settings.exportVideoSpeech' in ST and 'copy(exportVideoSpeech = it)' in ST)
check('nối dây: lỗi lồng tiếng không làm hỏng gói video; thư mục tạm luôn được dọn', 'Lồng tiếng lỗi' in MP and 'ttsDir.deleteRecursively()' in MP)
check('nối dây: clip được nhét vào zip theo panel và ghi vào info.json', 'put(dir + clip.item.fileName, clip.file.readBytes())' in MP and 'meta["dialogueAudio"]' in MP)
mf = open(os.path.join(ROOT, 'app', 'src', 'main', 'AndroidManifest.xml'), encoding='utf8').read()
dom = minidom.parseString(mf)
acts = [a.getAttribute('android:name') for q in dom.getElementsByTagName('queries') for a in q.getElementsByTagName('action')]
check('manifest: hợp lệ XML và có <queries> TTS_SERVICE cho Android 11+', 'android.intent.action.TTS_SERVICE' in acts)
check('manifest: <queries> nằm NGOÀI <application> (đúng cú pháp)', not any(n.parentNode.nodeName == 'application' for n in dom.getElementsByTagName('queries')))

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
