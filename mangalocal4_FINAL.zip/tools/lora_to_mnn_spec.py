#!/usr/bin/env python3
"""mục 268 TECHNICAL_STATUS.md — bước (e) của mục 264.3: LoRA `.safetensors` + danh sách op của UNet -> `spec.txt` + các `.bin` cho `tools/mnn_probe/lora_attach_branch`.

CÁCH DÙNG (chạy trên PC, KHÔNG chạy trên điện thoại):
    1) ./lora_attach_branch --list unet.mnn > ops.txt           # liệt kê op Convolution của UNet THẬT (bước bắt buộc: tên op chỉ biết được từ file thật)
    2) python3 lora_to_mnn_spec.py --lora my.safetensors --ops ops.txt --out ./lora_out [--strength 1.0] [--alpha N] [--adapter-config adapter_config.json]
    3) ./lora_attach_branch unet.mnn lora_out/spec.txt unet_lora.mnn [--unfuse-activation --emit-base unet_base2.mnn]   # lệnh được in ở cuối báo cáo

VÌ SAO KHÔNG ĐOÁN TÊN OP (kết quả tra cứu ở mục 268):
  - MNNConvert mặc định `convertMatmulToConv = 1` ("matmul với đầu vào hằng -> convolution", tools/converter/source/common/cli.cpp, MNN 3.6.1), nên các Linear của transformer
    trong UNet thành Convolution 1x1 — đúng loại mà lora_attach_branch gắn được.
  - Tên op đến từ tên nút ONNX do torch.onnx.export đặt theo phạm vi module: `/down_blocks.0/attentions.0/transformer_blocks.0/attn1/to_q/MatMul` (cùng quy ước mà
    transformers/llm/export/utils/lora.py của MNN dựa vào khi tách `names = op['name'].split('/')`). Bỏ đoạn cuối (loại op) rồi đổi '.' thành '_' ra đúng khoá kohya
    `lora_unet_down_blocks_0_attentions_0_transformer_blocks_0_attn1_to_q`.
  - Nhưng UNet thật của dự án có thể do bên thứ ba chuyển đổi với cờ khác => công cụ KHÔNG tách khoá theo dấu gạch dưới (mơ hồ: `down_blocks`, `to_q`... đều có gạch dưới) mà dựng bảng
    {khoá-phẳng -> op} TỪ DANH SÁCH OP THẬT rồi tra từng khoá LoRA. Module LoRA nào không có op tương ứng, sai kích thước, hoặc rơi vào op không gắn được => LỖI (mã thoát 3),
    vì gắn THIẾU LoRA mà vẫn báo thành công là lỗi tệ nhất (ảnh ra khác mong đợi mà không ai biết vì sao). `--allow-unmatched` để chấp nhận có chủ đích.

ĐỊNH DẠNG LoRA ĐƯỢC HỖ TRỢ: kohya (`lora_unet_<đường_dẫn_phẳng>.lora_down.weight|.lora_up.weight|.alpha`) và diffusers/PEFT (`[unet.|base_model.model.]<đường.dẫn>.lora_A[.default].weight|lora_B...`,
alpha lấy từ --alpha hoặc --adapter-config). Khoá text-encoder được ĐẾM và bỏ qua (công cụ này chỉ cho UNet). LyCORIS (hada/lokr), DoRA, khoá lạ => LỖI, không bỏ qua im lặng.
ĐÃ KIỂM TRÊN FILE THẬT (mục 269): UNet diffusers thu nhỏ -> torch.onnx.export (TorchScript, opset 17) -> mnnconvert 3.6.1 thật -> `--list` thật: 82/83 module Linear/Conv2d khớp op;
  tên op thật là `<đường/dẫn/module>/<Loại>_output_0[__matmul_converted]` (Gemm/MatMul+Add gộp thành Convolution mang tên của Add); op CUỐI (conv_out) bị MNN đổi tên thành tên đầu ra
  của đồ thị (`out_sample`) nên mất đường dẫn -> dùng `--map conv_out=out_sample` (báo cáo có gợi ý ứng viên khớp kích thước).
KHÔNG chứng minh: bản đồ tên op đúng trên UNet SD1.5 THẬT của dự án (chỉ đúng trên UNet thu nhỏ do chính script xuất của MNN tạo) (chưa có file thật — chỉ kiểm bằng danh sách op mô phỏng theo quy ước tên ở trên), và kết quả ảnh. Trọng số ra float32 little-endian.
"""
import argparse
import json
import math
import os
import re
import struct
import sys

import numpy as np

EXIT_USAGE = 2
EXIT_UNMATCHED = 3


class ToolError(Exception):
    def __init__(self, msg, code=EXIT_USAGE):
        super().__init__(msg)
        self.code = code


# ───────────────────────── safetensors (không cần thư viện safetensors/torch) ─────────────────────────
_DT = {'F32': ('<f4', 4), 'F16': ('<f2', 2), 'BF16': ('<u2', 2)}


def read_safetensors(path):
    """-> {tên: np.ndarray float32}. Ném ToolError (không traceback) với tệp hỏng/bị cắt/dtype lạ."""
    try:
        f = open(path, 'rb')
    except OSError as e:
        raise ToolError(f'không mở được {path}: {e}')
    with f:
        head = f.read(8)
        if len(head) != 8:
            raise ToolError(f'{path}: tệp quá ngắn, không phải safetensors')
        n = struct.unpack('<Q', head)[0]
        if n == 0 or n > 200_000_000:
            raise ToolError(f'{path}: độ dài header bất thường ({n}), không phải safetensors')
        raw = f.read(n)
        if len(raw) != n:
            raise ToolError(f'{path}: header bị cắt')
        try:
            header = json.loads(raw.decode('utf-8'))
        except (UnicodeDecodeError, ValueError):
            raise ToolError(f'{path}: header không phải JSON hợp lệ')
        if not isinstance(header, dict):
            raise ToolError(f'{path}: header không phải đối tượng JSON')
        base = 8 + n
        out = {}
        for name, meta in header.items():
            if name == '__metadata__':
                continue
            try:
                dtype = meta['dtype']
                shape = tuple(int(x) for x in meta['shape'])
                s, e = (int(x) for x in meta['data_offsets'])
            except (KeyError, TypeError, ValueError):
                raise ToolError(f'{path}: mô tả tensor "{name}" hỏng')
            if dtype not in _DT:
                raise ToolError(f'tensor "{name}": dtype {dtype} chưa hỗ trợ (chỉ F32/F16/BF16)')
            npdt, isz = _DT[dtype]
            cnt = 1
            for d in shape:
                if d < 0:
                    raise ToolError(f'tensor "{name}": shape âm')
                cnt *= d
            if s < 0 or e < s or e - s != cnt * isz:
                raise ToolError(f'tensor "{name}": kích thước dữ liệu không khớp shape {shape}')
            f.seek(base + s)
            buf = f.read(e - s)
            if len(buf) != e - s:
                raise ToolError(f'tensor "{name}": tệp bị cắt')
            a = np.frombuffer(buf, dtype=npdt)
            if dtype == 'BF16':
                a = (a.astype(np.uint32) << 16).view(np.float32)
            else:
                a = a.astype(np.float32)
            out[name] = a.reshape(shape)
        return out


# ───────────────────────── khoá LoRA ─────────────────────────
_KOHYA_UNET = re.compile(r'^lora_unet_(?P<m>.+)\.(?P<k>lora_down\.weight|lora_up\.weight|alpha)$')
_KOHYA_TE = re.compile(r'^lora_te\d*_')
_PEFT = re.compile(r'^(?:base_model\.model\.)?(?:unet\.)?(?P<m>.+?)\.lora_(?P<ab>[AB])(?:\.[A-Za-z0-9_-]+)?\.weight$')
_TE_PREFIXES = ('text_encoder.', 'text_encoder_2.', 'base_model.model.text_encoder')


def parse_lora_keys(tensors):
    """-> (modules, te_count, unsupported). modules: {khoá-phẳng: {'down','up','alpha','fmt','keys'}}."""
    modules = {}
    te = 0
    unsupported = []

    def slot(flat, fmt):
        m = modules.setdefault(flat, {'down': None, 'up': None, 'alpha': None, 'fmt': fmt, 'keys': []})
        if m['fmt'] != fmt:
            raise ToolError(f'module "{flat}" có cả khoá kohya lẫn PEFT — tệp LoRA lẫn định dạng', EXIT_UNMATCHED)
        return m

    for key in sorted(tensors):
        arr = tensors[key]
        if _KOHYA_TE.match(key) or key.startswith(_TE_PREFIXES):
            te += 1
            continue
        m = _KOHYA_UNET.match(key)
        if m:
            s = slot(m.group('m'), 'kohya')
            s['keys'].append(key)
            k = m.group('k')
            if k == 'alpha':
                if arr.size != 1:
                    raise ToolError(f'khoá "{key}": alpha phải là một số, thấy shape {arr.shape}', EXIT_UNMATCHED)
                s['alpha'] = float(arr.reshape(-1)[0])
            elif k == 'lora_down.weight':
                s['down'] = arr
            else:
                s['up'] = arr
            continue
        m = _PEFT.match(key)
        if m and not key.startswith('transformer.'):
            flat = m.group('m').replace('.', '_')
            s = slot(flat, 'peft')
            s['keys'].append(key)
            if m.group('ab') == 'A':
                s['down'] = arr
            else:
                s['up'] = arr
            continue
        unsupported.append(key)
    return modules, te, unsupported


# ───────────────────────── danh sách op (đầu ra của `lora_attach_branch --list`) ─────────────────────────
_OP_LINE = re.compile(r'^\s*(?P<idx>\d+)\s+(?P<type>\w+)\s+name=(?P<name>\S+)\s+out=(?P<out>\S+)\s+(?P<rest>.*)$')
_CONV_INFO = re.compile(r'in=(?P<in>\d+)\s+out=(?P<out>\d+)\s+k=(?P<ky>\d+)x(?P<kx>\d+)\s+group=(?P<g>\d+)')


def op_flat_id(name):
    """`/down_blocks.0/attentions.0/.../attn1/to_q/MatMul` -> `down_blocks_0_attentions_0_..._attn1_to_q` (bỏ đoạn cuối = loại op; '.' -> '_')."""
    parts = [p for p in name.strip().split('/') if p != '']
    if len(parts) >= 2:
        parts = parts[:-1]
    return '_'.join(parts).replace('.', '_')


def parse_ops(text):
    """-> list[dict]: type, name, supported(bool), why(str), in, out, ky, kx, group, relu(bool)."""
    ops = []
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith('--'):
            continue
        m = _OP_LINE.match(line)
        if not m:
            continue
        d = {'type': m.group('type'), 'name': m.group('name'), 'rest': m.group('rest'), 'supported': False, 'why': '',
             'in': 0, 'out': 0, 'ky': 0, 'kx': 0, 'group': 0, 'relu': False}
        if '#' in d['name']:
            d['why'] = 'tên op chứa "#" (spec dùng "#" làm dấu chú thích)'
        elif d['type'] != 'Convolution':
            d['why'] = f'loại {d["type"]} — lora_attach_branch chỉ gắn được vào Convolution'
        else:
            c = _CONV_INFO.search(d['rest'])
            if not c:
                d['why'] = 'không đọc được in/out/k/group từ dòng liệt kê'
            else:
                d.update({'in': int(c.group('in')), 'out': int(c.group('out')), 'ky': int(c.group('ky')), 'kx': int(c.group('kx')), 'group': int(c.group('g'))})
                d['relu'] = bool(re.search(r'\brelu6?\b', d['rest']))
                if d['group'] != 1:
                    d['why'] = f'group={d["group"]} (chỉ gắn được group=1)'
                elif 'symmetricQuan' in d['rest']:
                    d['why'] = 'symmetricQuan (chỉ gắn được conv float/weight-quant)'
                else:
                    d['supported'] = True
        ops.append(d)
    return ops


# ───────────────────────── ánh xạ ─────────────────────────
def _fmt_scale(x):
    return '%.9g' % x


def build_plan(modules, ops, alpha_default, use_rslora, strength, overrides=None):
    """-> dict: entries[], unmatched[], bad[], unsupported[], ambiguous[]. Không ghi tệp.
    overrides: {khoá-phẳng: tên op} do --map chỉ định tay (dùng cho op mà MNN ĐÃ ĐỔI TÊN thành tên đầu ra của đồ thị, vd conv cuối `out_sample`, nên tên không còn đường dẫn module)."""
    overrides = overrides or {}
    by_flat = {}
    for o in ops:
        by_flat.setdefault(op_flat_id(o['name']), []).append(o)
    by_name = {}
    for o in ops:
        by_name.setdefault(o['name'], []).append(o)
    entries, unmatched, bad, unsupported, ambiguous = [], [], [], [], []
    for flat in sorted(modules):
        mod = modules[flat]
        if mod['down'] is None or mod['up'] is None:
            bad.append((flat, 'thiếu ' + ('lora_down/lora_A' if mod['down'] is None else 'lora_up/lora_B')))
            continue
        down, up = mod['down'], mod['up']
        if down.ndim not in (2, 4) or up.ndim not in (2, 4):
            bad.append((flat, f'số chiều lạ: down {down.shape}, up {up.shape}'))
            continue
        r = down.shape[0]
        if r <= 0 or up.shape[1] != r:
            bad.append((flat, f'rank không khớp: down {down.shape}, up {up.shape}'))
            continue
        if up.ndim == 4 and up.shape[2:] != (1, 1):
            bad.append((flat, f'lora_up 4D phải có kernel 1x1, thấy {up.shape}'))
            continue
        cands = by_name.get(overrides[flat]) if flat in overrides else by_flat.get(flat)
        if not cands:
            unmatched.append((flat, '__NOOP__'))
            continue
        sup = [o for o in cands if o['supported']]
        if not sup:
            unsupported.append((flat, '; '.join(sorted({f'{o["name"]}: {o["why"]}' for o in cands}))))
            continue
        if len(sup) > 1:
            ambiguous.append((flat, ' | '.join(o['name'] for o in sup)))
            continue
        op = sup[0]
        want_a = (r, op['in']) if down.ndim == 2 else (r, op['in'], op['ky'], op['kx'])
        if down.ndim == 2 and (op['ky'], op['kx']) != (1, 1):
            bad.append((flat, f'lora_down 2D nhưng op "{op["name"]}" có kernel {op["ky"]}x{op["kx"]}'))
            continue
        if tuple(down.shape) != want_a:
            bad.append((flat, f'lora_down {tuple(down.shape)} không khớp op "{op["name"]}" (cần {want_a})'))
            continue
        if up.shape[0] != op['out']:
            bad.append((flat, f'lora_up out={up.shape[0]} không khớp op "{op["name"]}" out={op["out"]}'))
            continue
        alpha = mod['alpha'] if mod['alpha'] is not None else (alpha_default if alpha_default is not None else float(r))
        if not math.isfinite(alpha):
            bad.append((flat, f'alpha không hữu hạn ({alpha})'))
            continue
        scale = (alpha / math.sqrt(r) if use_rslora else alpha / r) * strength
        if not math.isfinite(scale):
            bad.append((flat, 'scale không hữu hạn'))
            continue
        entries.append({'flat': flat, 'op': op['name'], 'rank': r, 'scale': scale, 'alpha': alpha, 'alpha_src': 'file' if mod['alpha'] is not None else ('--alpha' if alpha_default is not None else 'mặc định=rank'),
                        'A': down, 'B': up, 'relu': op['relu']})
    # Gợi ý cho module không có op: op gắn được CHƯA dùng, đường dẫn không thuộc module LoRA nào, cùng in/out/kernel. Chỉ GỢI Ý — không tự gắn (đoán sai = gắn nhầm chỗ âm thầm).
    used = {e['op'] for e in entries}
    free = [o for o in ops if o['supported'] and o['name'] not in used and op_flat_id(o['name']) not in modules]
    fixed = []
    for flat, why in unmatched:
        if why != '__NOOP__':
            fixed.append((flat, why)); continue
        d, u = modules[flat]['down'], modules[flat]['up']
        shape = (d.shape[1], u.shape[0]) + ((d.shape[2], d.shape[3]) if d.ndim == 4 else (1, 1))
        sug = [o for o in free if (o['in'], o['out'], o['ky'], o['kx']) == shape][:3]
        msg = 'không có op Convolution/MatMul nào trong danh sách có đường dẫn module này'
        if flat in overrides:
            msg = f'--map {flat}={overrides[flat]}: không có op tên đó trong danh sách'
        elif sug:
            msg += '. Ứng viên op CHƯA dùng, khớp kích thước (in=%d out=%d k=%dx%d): %s — nếu đúng, thêm %s' % (
                shape[0], shape[1], shape[2], shape[3], ', '.join(o['name'] for o in sug), ' '.join(f'--map {flat}={o["name"]}' for o in sug[:1]))
        fixed.append((flat, msg))
    unmatched = fixed
    return {'entries': entries, 'unmatched': unmatched, 'bad': bad, 'unsupported': unsupported, 'ambiguous': ambiguous}


def write_outputs(plan, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    absdir = os.path.abspath(out_dir)
    if re.search(r'[\s#]', absdir):
        raise ToolError(f'đường dẫn đầu ra "{absdir}" có khoảng trắng hoặc "#" — spec.txt tách trường bằng khoảng trắng và coi "#" là chú thích; chọn thư mục khác')
    lines = ['# tạo bởi tools/lora_to_mnn_spec.py (mục 268) — <tên op> <rank> <scale> <A.bin> <B.bin>']
    for i, e in enumerate(plan['entries']):
        ap = os.path.join(absdir, f'{i:04d}_A.bin')
        bp = os.path.join(absdir, f'{i:04d}_B.bin')
        r = e['rank']
        np.ascontiguousarray(e['A'].reshape(r, -1), dtype='<f4').tofile(ap)       # [r][in][kh][kw]
        np.ascontiguousarray(e['B'].reshape(e['B'].shape[0], r), dtype='<f4').tofile(bp)   # [out][r]
        lines.append(f'{e["op"]} {r} {_fmt_scale(e["scale"])} {ap} {bp}')
    sp = os.path.join(absdir, 'spec.txt')
    with open(sp, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    return sp


def report(plan, te, unsupported_keys, spec_path, ops, strength, lora_modules):
    L = []
    n = len(plan['entries'])
    L.append(f'LoRA: {lora_modules} module UNet; khớp & ghi {n}; text-encoder bỏ qua {te}; strength={strength:g}')
    for title, key in (('KHÔNG CÓ OP TƯƠNG ỨNG', 'unmatched'), ('SAI KÍCH THƯỚC/RANK', 'bad'), ('OP KHÔNG GẮN ĐƯỢC', 'unsupported'), ('MƠ HỒ (nhiều op cùng đường dẫn)', 'ambiguous')):
        items = plan[key]
        if items:
            L.append(f'  {title}: {len(items)}')
            for flat, why in items[:15]:
                L.append(f'    - {flat}: {why}')
            if len(items) > 15:
                L.append(f'    … và {len(items) - 15} mục nữa')
    if unsupported_keys:
        L.append(f'  KHOÁ KHÔNG HỖ TRỢ (LyCORIS/DoRA/DiT/lạ): {len(unsupported_keys)}')
        for k in unsupported_keys[:10]:
            L.append(f'    - {k}')
    srcs = {}
    for e in plan['entries']:
        srcs[e['alpha_src']] = srcs.get(e['alpha_src'], 0) + 1
    if srcs:
        L.append('  nguồn alpha: ' + ', '.join(f'{k}={v}' for k, v in sorted(srcs.items())))
        if '--alpha' not in srcs and 'file' not in srcs:
            L.append('  LƯU Ý: tệp không có alpha và không truyền --alpha/--adapter-config => alpha=rank (scale 1). Nếu LoRA huấn luyện với lora_alpha khác rank, kết quả SAI cường độ.')
    relu = [e['op'] for e in plan['entries'] if e['relu']]
    if relu:
        L.append(f'  CẢNH BÁO: {len(relu)} op đích có hoạt hoá relu/relu6 gộp trong conv (ví dụ {relu[0]}) => khi gắn phải dùng --unfuse-activation và nạp module nền từ file --emit-base (mục 265, "bẫy đã đo").')
    if spec_path:
        L.append('')
        L.append('Lệnh tiếp theo:')
        L.append(f'  ./lora_attach_branch <unet.mnn> {spec_path} <unet_lora.mnn>' + (' --unfuse-activation --emit-base <unet_base2.mnn>' if relu else ''))
    return '\n'.join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description='LoRA safetensors + danh sách op -> spec.txt cho lora_attach_branch (mục 268)')
    ap.add_argument('--lora', required=True)
    ap.add_argument('--ops', required=True, help='đầu ra của `lora_attach_branch --list unet.mnn`')
    ap.add_argument('--out', required=True)
    ap.add_argument('--strength', type=float, default=1.0)
    ap.add_argument('--alpha', type=float, default=None, help='alpha chung cho module không có .alpha (PEFT)')
    ap.add_argument('--adapter-config', default=None, help='adapter_config.json của PEFT: đọc lora_alpha và use_rslora')
    ap.add_argument('--map', action='append', default=[], metavar='KHOÁ=OP', help='chỉ định tay module LoRA -> tên op (lặp được). KHOÁ là khoá phẳng kohya (down_blocks_0_..., conv_out) hoặc đường dẫn có dấu chấm')
    ap.add_argument('--allow-unmatched', action='store_true')
    ap.add_argument('--dry-run', action='store_true', help='chỉ in báo cáo, không ghi tệp')
    try:
        args = ap.parse_args(argv)
    except SystemExit as e:
        return EXIT_USAGE if e.code not in (0, None) else 0
    try:
        if not math.isfinite(args.strength):
            raise ToolError('--strength phải là số hữu hạn')
        if args.alpha is not None and not (math.isfinite(args.alpha) and args.alpha > 0):
            raise ToolError('--alpha phải là số hữu hạn > 0')
        alpha_default, use_rslora = args.alpha, False
        if args.adapter_config:
            try:
                cfg = json.load(open(args.adapter_config, encoding='utf-8'))
            except (OSError, ValueError) as e:
                raise ToolError(f'không đọc được {args.adapter_config}: {e}')
            if cfg.get('rank_pattern') or cfg.get('alpha_pattern'):
                raise ToolError('adapter_config có rank_pattern/alpha_pattern — chưa hỗ trợ (rank/alpha khác nhau theo từng lớp)')
            if cfg.get('use_dora'):
                raise ToolError('adapter_config bật use_dora — DoRA chưa hỗ trợ')
            if alpha_default is None and cfg.get('lora_alpha') is not None:
                alpha_default = float(cfg['lora_alpha'])
            use_rslora = bool(cfg.get('use_rslora'))
        try:
            ops_text = open(args.ops, encoding='utf-8', errors='replace').read()
        except OSError as e:
            raise ToolError(f'không đọc được {args.ops}: {e}')
        ops = parse_ops(ops_text)
        if not ops:
            raise ToolError(f'{args.ops}: không đọc được dòng op nào — đây có phải đầu ra của `lora_attach_branch --list` không?')
        tensors = read_safetensors(args.lora)
        modules, te, unsupported_keys = parse_lora_keys(tensors)
        if not modules:
            raise ToolError('không có module UNet nào trong LoRA (khoá lạ hoặc chỉ có text-encoder)', EXIT_UNMATCHED)
        overrides = {}
        for item in args.map:
            if '=' not in item or item.startswith('=') or item.endswith('='):
                raise ToolError(f'--map "{item}": cần dạng KHOÁ=TÊN_OP')
            k, v = item.split('=', 1)
            k = k.strip().replace('.', '_')
            if k in overrides:
                raise ToolError(f'--map: khoá "{k}" được chỉ định hai lần')
            if k not in modules:
                raise ToolError(f'--map: module "{k}" không có trong LoRA')
            if not any(o['name'] == v.strip() for o in ops):
                raise ToolError(f'--map: op "{v}" không có trong danh sách op')
            overrides[k] = v.strip()
        plan = build_plan(modules, ops, alpha_default, use_rslora, args.strength, overrides)
        spec_path = None
        problems = len(plan['unmatched']) + len(plan['bad']) + len(plan['unsupported']) + len(plan['ambiguous']) + len(unsupported_keys)
        if not plan['entries']:
            print(report(plan, te, unsupported_keys, None, ops, args.strength, len(modules)))
            raise ToolError('không module nào khớp được => không ghi gì (kiểm tra --ops có phải của đúng UNet, và LoRA có phải cho UNet SD1.5)', EXIT_UNMATCHED)
        if problems and not args.allow_unmatched:
            print(report(plan, te, unsupported_keys, None, ops, args.strength, len(modules)))
            raise ToolError(f'{problems} mục không gắn được => KHÔNG ghi spec (gắn thiếu LoRA âm thầm là lỗi tệ nhất). Dùng --allow-unmatched nếu chấp nhận có chủ đích.', EXIT_UNMATCHED)
        if not args.dry_run:
            spec_path = write_outputs(plan, args.out)
        print(report(plan, te, unsupported_keys, spec_path, ops, args.strength, len(modules)))
        if problems:
            print(f'CẢNH BÁO: --allow-unmatched: {problems} mục bị bỏ — LoRA được gắn THIẾU.')
        return 0
    except ToolError as e:
        print(f'LỖI: {e}', file=sys.stderr)
        return e.code


if __name__ == '__main__':
    sys.exit(main())
