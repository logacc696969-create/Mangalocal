"""
export_ipa_controlnet_mask_unet.py — BẢN MỞ RỘNG của
export_ipa_controlnet_unet.py: xuất UNet SD1.5 đã gộp sẵn 1 IP-Adapter DÙNG
CHO 2 ẢNH NHÂN VẬT CÓ MASK VÙNG (giải quyết identity bleeding khi 2 nhân vật
đứng cùng khung hình — mục "Multi-IP-Adapter / Regional Prompting local"
cuối TECHNICAL_STATUS.md, trước đây "CHỦ ĐỘNG CHƯA làm" vì chưa đọc được
source thật) + ControlNet-OpenPose (giữ tư thế, giống bản gốc).

CHẠY TRÊN MÁY TÍNH (không phải điện thoại), cần Python + GPU khuyến khích.

=== TỔNG QUÁT HOÁ RA N NHÂN VẬT (không chỉ 2) ===
Bản đầu chỉ hỗ trợ đúng 2 nhân vật. User hỏi "nếu ảnh có >2 nhân vật thì
sao" — cơ chế IP-Adapter masking của diffusers KHÔNG giới hạn ở 2 ảnh/mask
(list N ảnh -> list N mask là hợp lệ theo đúng API đã tra ở trên, không
phải suy diễn riêng). Script này giờ nhận `--num_characters N` (mặc định
2, xem GIỚI HẠN THẬT phía dưới cho khuyến nghị N nên dùng bao nhiêu) — MỖI
N cần export RIÊNG 1 file .mnn (dự án này không dùng dynamic_axes ở bất kỳ
export script nào, shape luôn cố định), không có "1 file dùng được mọi N".


Sau khi đọc kỹ, đây KHÔNG PHẢI "Regional Prompting" (can thiệp attention nội
bộ UNet ở nhiều lớp, thứ mà lượt trước tôi từ chối viết vì chưa đọc được
source thật nào) — mà là tính năng "IP-Adapter masking", MỘT tính năng CHÍNH
THỨC, có tài liệu hẳn hoi của diffusers, giải quyết ĐÚNG vấn đề bleeding
bằng cách chia ảnh thành vùng nhị phân cho từng nhân vật thay vì để 2 đặc
trưng cạnh tranh toàn ảnh. Đã xác nhận qua:
  - docs/source/en/using-diffusers/ip_adapter.md (mục "IP-Adapter masking")
    của chính repo diffusers — dùng `IPAdapterMaskProcessor.preprocess()`
    rồi truyền vào `cross_attention_kwargs={"ip_adapter_masks": [...]}`.
  - PR #10346 (đã merge) — xác nhận cơ chế này chạy thật trong production,
    kèm ví dụ `pipe.set_ip_adapter_scale([scale1, scale2])` +
    `cross_attention_kwargs={"ip_adapter_masks": [masks]}`.
  - Issue #8626 — xác nhận rõ cách dùng "1 IP-Adapter, NHIỀU ảnH" (đúng
    trường hợp của mình — 2 nhân vật, không phải 2 loại IP-Adapter khác
    nhau): `ip_adapter_image=[[img1, img2]]` (list lồng — 1 phần tử ngoài
    cho 1 adapter, bên trong là list nhiều ảnh), `set_ip_adapter_scale(
    [[s1, s2]])` (1 scale cho mỗi cặp ảnh-mask), mask tensor cuối cùng shape
    `[1, num_images_for_ip_adapter, height, width]` (đã xác nhận qua thông
    báo lỗi thật trong PR #10346, không đoán).

GIỚI HẠN THẬT (nói rõ, không phóng đại):
  - Đây LÀ mask theo vùng ảnh cứng (binary mask thô do app tự vẽ từ bounding
    box khung xương từng người — xem renderCharacterMasks() phía
    ip_adapter.cpp), KHÔNG PHẢI segmentation chính xác pixel-level. Ranh
    giới vùng có thể lệch nhẹ so với contour thật của nhân vật — chấp nhận
    được cho bài toán "2 người khác vùng ảnh", không nhằm cắt viền tuyệt đối.
  - `ip_adapter_scale` bị "đóng băng" thành hằng số ngay trong đồ thị ONNX
    lúc export (giống hệt giới hạn đã có ở bản gốc export_ipa_controlnet_
    unet.py với 1 IP-Adapter) — muốn đổi độ ảnh hưởng của từng nhân vật
    phải export lại, không chỉnh được lúc chạy trên điện thoại.
  - CHƯA XÁC NHẬN CHẠY THẬT (như mọi phần native khác trong dự án): chưa
    chạy script này thật (cần GPU + PyTorch + thời gian), chưa MNNConvert,
    chưa build APK với phần C++ mới trong ip_adapter.cpp. Rủi ro cụ thể
    nhất: `F.interpolate` mà IPAdapterAttnProcessor dùng để resize mask
    xuống từng lớp UNet có thể sinh ra op ONNX (Resize) mà MNNConvert xử lý
    khác bản PyTorch gốc — cần thử thật với ảnh mask cụ thể mới biết chắc
    kết quả có giữ đúng ranh giới vùng hay không.

Cài đặt:
    pip install diffusers transformers accelerate torch onnx pillow numpy

Chạy:
    python export_ipa_controlnet_mask_unet.py \\
        --base_model runwayml/stable-diffusion-v1-5 \\
        --output_dir ./exported_mask \\
        --image_size 512
"""
import argparse
import os

import torch
import torch.nn as nn
from diffusers import ControlNetModel, StableDiffusionControlNetPipeline
from diffusers.image_processor import IPAdapterMaskProcessor

# Tái dùng lại hàm export CLIP image encoder từ bản gốc — KHÔNG copy trùng
# lặp. Bản mask KHÔNG cần probe_ip_adapter_embed_shape (1 ảnh) của bản gốc
# vì cần shape cho 2 ảnh cùng lúc — viết hàm probe riêng bên dưới, nhưng
# vẫn gọi đúng API prepare_ip_adapter_image_embeds() thật như bản gốc.
from export_ipa_controlnet_unet import export_image_encoder
from ip_adapter_decay import IpDecayState, wrap_unet_ip_adapter_processors


class AugmentedUNetMask(nn.Module):
    """Giống AugmentedUNet (bản gốc, 1 nhân vật) nhưng dùng 1 IP-Adapter
    cho N ẢNH nhân vật CÓ MASK VÙNG — đúng API "IP-Adapter masking" chính
    thức của diffusers (xem docstring đầu file), KHÔNG tự chế cơ chế mask
    mới. N ở đây là số nhân vật lúc TRACE (cố định vào đồ thị ONNX qua
    chính shape của example_embeds/example_masks truyền vào torch.onnx.
    export() — forward() bên dưới KHÔNG hardcode số 2 ở đâu cả, tự động
    theo đúng N truyền vào lúc export). Không tự viết lại toán học
    resize-mask-theo-lớp — để nguyên IPAdapterAttnProcessor2_0 (đã gắn sẵn
    qua pipe.load_ip_adapter()) tự làm việc đó khi self.unet(...) được gọi
    với đúng cross_attention_kwargs.
    """

    def __init__(self, unet, controlnet, decay_state: IpDecayState):
        super().__init__()
        self.unet = unet
        self.controlnet = controlnet
        # Xem tools/ip_adapter_decay.py + mục 97/100 TECHNICAL_STATUS.md —
        # đọc bởi attn processor đã bọc bên trong self.unet, không đăng ký
        # làm submodule (cố tình).
        self._decay_state = decay_state

    def forward(self, sample, timestep, encoder_hidden_states, control_hint,
                ip_image_embeds, ip_masks, ip_decay_floor, ip_decay_start_timestep, ip_static_scale):
        down_res, mid_res = self.controlnet(
            sample, timestep, encoder_hidden_states=encoder_hidden_states,
            controlnet_cond=control_hint, return_dict=False,
        )
        # Smooth Timestep Decay + consistencyStrength cho IP-Adapter MASK
        # N-nhân-vật — MỞ RỘNG mục 97/99 (trước đây CHỈ áp dụng đường sinh
        # 1-nhân-vật) sang đường mask. mục 147 TECHNICAL_STATUS.md: giờ MỖI
        # nhân vật có decay RIÊNG (Per-Instance Decay) — không còn "1 hệ số
        # chung cho cả N nhân vật" như trước — xem
        # DecayedIPAdapterAttnProcessor2_0.__call__ (tools/ip_adapter_decay.py)
        # cho chỗ đọc theo đúng index [i].
        # mục 147 TECHNICAL_STATUS.md — ĐÃ SỬA "Per-Instance Decay" (trước
        # đây 3 input này là SCALAR, áp dụng ĐỀU cho mọi nhân vật — đóng
        # gap xác nhận thật ở mục 146: cảnh vật lộn nhiều người, hạ decay
        # ở step cuối để biểu cảm phát huy sẽ làm YẾU identity-lock của CẢ
        # N người cùng lúc dù chỉ 1 người đang biểu cảm mạnh). Giờ 3 input
        # là VECTOR shape [N] (N = num_characters lúc export, không
        # hardcode) — MỖI nhân vật có floor/start/static_scale RIÊNG.
        # DecayedIPAdapterAttnProcessor2_0 (tools/ip_adapter_decay.py, nhánh
        # CÓ mask) đọc đúng phần tử [i] tương ứng — xem sửa ở đó.
        #
        # Công thức GIỮ NGUYÊN, chỉ khác: mọi phép toán giờ trên VECTOR
        # thay vì SCALAR (PyTorch broadcast tự động timestep — 0-d — với
        # vector [N], không cần sửa gì thêm) — kết quả effective_ip_scale
        # cũng là vector [N], gán thẳng vào decay_state.value.
        safe_start = torch.clamp(ip_decay_start_timestep, min=1e-3)
        ramp = torch.clamp(timestep.float(), min=torch.zeros_like(safe_start), max=safe_start) / safe_start
        effective_ip_scale = ip_static_scale * (ip_decay_floor + (1.0 - ip_decay_floor) * ramp)
        self._decay_state.value = effective_ip_scale

        noise_pred = self.unet(
            sample, timestep, encoder_hidden_states=encoder_hidden_states,
            down_block_additional_residuals=down_res,
            mid_block_additional_residual=mid_res,
            # image_embeds: list 1 phần tử (1 IP-Adapter) chứa tensor
            # [batch, 2, tokens, dim] (2 nhân vật) — ĐÚNG shape thật dò được
            # ở probe_two_char_embeds() bên dưới, không đoán.
            added_cond_kwargs={"image_embeds": [ip_image_embeds]},
            # ip_adapter_masks: list 1 phần tử (khớp số lượng IP-Adapter,
            # ở đây chỉ có 1) chứa tensor mask [batch, 2, H, W] — đúng quy
            # ước đã xác nhận qua thông báo lỗi thật của PR #10346.
            cross_attention_kwargs={"ip_adapter_masks": [ip_masks]},
            return_dict=False,
        )[0]
        return noise_pred


def probe_multi_char_embeds(pipe, device, num_characters):
    """Dò shape THẬT của image_embeds khi 1 IP-Adapter nhận N ảnh (N nhân
    vật) — gọi đúng API thật `prepare_ip_adapter_image_embeds()` với
    `ip_adapter_image` là LIST LỒNG `[[img1, img2, ..., imgN]]` (1 phần tử
    ngoài = 1 IP-Adapter, bên trong N ảnh — đã xác nhận qua issue #8626,
    không đoán thứ tự chiều stack, tổng quát hoá tự nhiên từ trường hợp 2
    ảnh đã xác nhận sang N ảnh cùng cơ chế)."""
    from PIL import Image

    colors = [(160, 120, 120), (120, 120, 160), (120, 160, 120), (160, 160, 120),
              (160, 120, 160), (120, 160, 160)]  # đủ màu phân biệt cho tới 6 nhân vật, chỉ để dò shape nên không cần nhiều hơn
    dummies = [Image.new("RGB", (224, 224), color=colors[i % len(colors)]) for i in range(num_characters)]
    with torch.no_grad():
        embeds = pipe.prepare_ip_adapter_image_embeds(
            ip_adapter_image=[dummies],
            ip_adapter_image_embeds=None,
            device=device,
            num_images_per_prompt=1,
            do_classifier_free_guidance=False,
        )
    embed_tensor = embeds[0]  # 1 phần tử vì chỉ có 1 IP-Adapter
    print(f"[probe] image_embeds ({num_characters} nhân vật) shape THẬT: {tuple(embed_tensor.shape)}")
    return embed_tensor


def probe_multi_char_masks(width, height, device, num_characters):
    """Dựng N mask mẫu (chia đều theo cột dọc, giống ví dụ chính thức của
    diffusers mở rộng ra N) chỉ để TRACE đúng shape/dtype — mask THẬT lúc
    chạy trên điện thoại do app tự vẽ từ bounding box khung xương từng
    người (renderCharacterMask() trong ip_adapter.cpp), không liên quan gì
    đến N mask mẫu ở đây. mục 161 (đợt 5) — width/height TÁCH RIÊNG (trước
    kia 1 tham số image_size dùng chung cả 2 chiều, chỉ đúng cho ảnh
    vuông) — width chia cột (lo/hi theo TRỤC NGANG), height dùng cho vòng
    lặp Y (TRỤC DỌC). Giá trị pixel không quan trọng (chỉ cần đúng
    shape/dtype để trace ONNX, mask THẬT không lấy từ đây).
    """
    from PIL import Image

    masks = []
    for i in range(num_characters):
        m = Image.new("L", (width, height), color=0)
        lo = int(width * i / num_characters)
        hi = int(width * (i + 1) / num_characters)
        for x in range(lo, hi):
            for y in range(0, height, 8):  # thưa cho nhanh, chỉ cần đúng shape/API, không cần chính xác pixel
                m.putpixel((x, y), 255)
        masks.append(m)

    processor = IPAdapterMaskProcessor()
    mask_tensor = processor.preprocess(masks, height=height, width=width).to(device)
    print(f"[probe] ip_adapter_masks shape THẬT (sau IPAdapterMaskProcessor, {num_characters} nhân vật): {tuple(mask_tensor.shape)}")
    return mask_tensor


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_model", default="runwayml/stable-diffusion-v1-5")
    ap.add_argument("--controlnet_model", default="lllyasviel/control_v11p_sd15_openpose")
    ap.add_argument("--ip_adapter_repo", default="h94/IP-Adapter")
    ap.add_argument("--ip_adapter_weight", default="ip-adapter_sd15.bin")
    # Scale riêng cho từng nhân vật — bị đóng băng vào đồ thị ONNX lúc export
    # (xem GIỚI HẠN THẬT ở đầu file), mặc định bằng nhau.
    ap.add_argument("--num_characters", type=int, default=2,
                     help="So nhan vat can tach vung (mac dinh 2 - truong hop co xac nhan nguon that ro rang nhat, xem GIOI HAN THAT o dau file cho khuyen nghi N lon hon)")
    ap.add_argument("--char_scales", default="",
                     help="Danh sach scale cach nhau boi dau phay, vd '0.8,0.8,0.7' - phai co dung --num_characters gia tri. De trong = dung 0.8 cho tat ca.")
    ap.add_argument("--output_dir", default="./exported_mask")
    ap.add_argument("--image_size", type=int, default=None,
                     help="LƯU Ý: đặt CẢ width VÀ height bằng giá trị này (chỉ dùng cho ảnh vuông, tương thích ngược). Ưu tiên dùng --width/--height nếu cần ảnh không vuông.")
    ap.add_argument("--width", type=int, default=512, help="Phải chia hết cho 64 (VAE 8x + UNet giảm thêm 8x = 64x thật; mục 161 đợt 7 TECHNICAL_STATUS.md)")
    ap.add_argument("--height", type=int, default=512, help="Phải chia hết cho 64 (VAE 8x + UNet giảm thêm 8x = 64x thật; mục 161 đợt 7 TECHNICAL_STATUS.md)")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    num_chars = args.num_characters
    if num_chars < 2:
        raise ValueError("num_characters phai >= 2 (mask vung chi co y nghia khi >=2 nhan vat can tach biet)")
    if args.char_scales.strip():
        scales = [float(s) for s in args.char_scales.split(",")]
        if len(scales) != num_chars:
            raise ValueError(f"--char_scales co {len(scales)} gia tri nhung --num_characters={num_chars}")
    else:
        scales = [0.8] * num_chars
    # mục 161 (đợt 5) — cùng logic tương thích ngược đã áp dụng ở 2 script
    # export_ipa_controlnet_unet.py/depth_unet.py.
    if args.image_size is not None:
        args.width = args.height = args.image_size
    if args.width % 64 != 0 or args.height % 64 != 0:
        # mục 161 (đợt 7) — tra cứu web xác nhận cần chia hết 64, không
        # phải 8 (xem comment đầy đủ trong export_sd15_base.py — bug thật
        # đã báo cáo: huggingface/diffusers issue #255).
        raise ValueError(f"width/height phải chia hết cho 64 (không phải 8 — UNet có thêm 3 tầng downsample nội bộ ngoài VAE) — nhận {args.width}x{args.height}")

    os.makedirs(args.output_dir, exist_ok=True)
    device = args.device
    latent_h, latent_w = args.height // 8, args.width // 8

    print("Đang tải ControlNet-OpenPose...")
    controlnet = ControlNetModel.from_pretrained(args.controlnet_model, torch_dtype=torch.float32)

    print("Đang tải base SD1.5 + gắn ControlNet...")
    pipe = StableDiffusionControlNetPipeline.from_pretrained(
        args.base_model, controlnet=controlnet, torch_dtype=torch.float32, safety_checker=None
    )

    print(f"Đang nạp IP-Adapter ({args.ip_adapter_repo}/{args.ip_adapter_weight})...")
    pipe.load_ip_adapter(args.ip_adapter_repo, subfolder="models", weight_name=args.ip_adapter_weight)
    # set_ip_adapter_scale nhận LIST LỒNG [[s1, s2, ..., sN]] khi 1 adapter
    # dùng cho nhiều ảnh/mask — đã xác nhận qua issue #8626 ("one scale for
    # each image-mask pair"), khác set_ip_adapter_scale(1.0) (1 số) của bản
    # gốc 1-ảnh.
    pipe.set_ip_adapter_scale([scales])
    pipe.to(device)

    # Bọc attention processor thật để Smooth Timestep Decay + consistencyStrength
    # tác động ĐÚNG vào output attention — mở rộng mục 97/99 sang đường mask
    # N-nhân-vật. Xem tools/ip_adapter_decay.py + GIỚI HẠN THẬT.
    decay_state = IpDecayState()
    n_wrapped = wrap_unet_ip_adapter_processors(pipe.unet, decay_state)
    if n_wrapped == 0:
        raise RuntimeError(
            "wrap_unet_ip_adapter_processors() không bọc được processor nào — "
            "xem cùng lỗi này trong export_ipa_controlnet_unet.py cho cách xử lý."
        )
    print(f"Đã bọc {n_wrapped} attention processor với Smooth Timestep Decay (IP-Adapter mask {num_chars} nhân vật).")

    # Dò shape thật — KHÔNG đoán, cho cả embeds lẫn masks.
    example_embeds = probe_multi_char_embeds(pipe, device, num_chars)
    example_masks = probe_multi_char_masks(args.width, args.height, device, num_chars)

    # Export riêng CLIP image encoder (dùng lại nguyên bản gốc — mỗi nhân
    # vật vẫn encode RIÊNG trên điện thoại qua đúng 1 file ip_image_encoder.mnn
    # này, app tự ghép N kết quả lại thành tensor [1,N,tokens,dim] trước khi
    # đưa vào UNet — xem ghép ở ip_adapter.cpp, KHÔNG cần export thêm model
    # encoder riêng theo N).
    export_image_encoder(pipe, args.output_dir, device)

    print(f"Đang lắp AugmentedUNetMask (UNet + ControlNet + IP-Adapter-mask {num_chars} nhân vật)...")
    augmented = AugmentedUNetMask(pipe.unet, pipe.controlnet, decay_state).to(device).eval()

    example_sample = torch.randn(1, 4, latent_h, latent_w, device=device)
    example_timestep = torch.tensor([999], device=device, dtype=torch.long)
    example_encoder_hidden = torch.randn(1, 77, 768, device=device)
    example_control_hint = torch.randn(1, 3, args.height, args.width, device=device)
    # mục 147 TECHNICAL_STATUS.md — 3 input Per-Instance Decay, giờ là
    # VECTOR shape [num_chars] (trước là scalar dùng chung mọi người —
    # xem giải thích đầy đủ ở forward()). Mẫu = "không suy giảm/không đổi
    # cường độ gốc" cho MỌI nhân vật — giá trị THẬT do app truyền mỗi lần
    # gọi, MỖI nhân vật 1 giá trị riêng theo Scene.expression (mục 98) của
    # người đó tại panel đang sinh.
    example_ip_decay_floor = torch.ones(num_chars, device=device, dtype=torch.float32)
    example_ip_decay_start_timestep = torch.full((num_chars,), 999.0, device=device, dtype=torch.float32)
    example_ip_static_scale = torch.ones(num_chars, device=device, dtype=torch.float32)

    # Tên file GHI RÕ N trong tên (khác bản đầu chỉ có 1 file cố định cho
    # N=2) — nhiều N có thể export song song ra cùng --output_dir mà không
    # ghi đè lẫn nhau (vd vừa muốn N=2 vừa muốn N=3 cho các panel khác
    # nhau). App/Kotlin tự chọn đúng file theo số nhân vật trong panel.
    onnx_name = f"unet_ipa_mask_controlnet_{num_chars}char.onnx"
    mnn_name = f"unet_ipa_mask_controlnet_{num_chars}char.mnn"
    onnx_path = os.path.join(args.output_dir, onnx_name)
    print(f"Đang export ONNX -> {onnx_path} (có thể mất vài phút)...")
    with torch.no_grad():
        torch.onnx.export(
            augmented,
            (example_sample, example_timestep, example_encoder_hidden,
             example_control_hint, example_embeds, example_masks,
             example_ip_decay_floor, example_ip_decay_start_timestep, example_ip_static_scale),
            onnx_path,
            input_names=["sample", "timestep", "encoder_hidden_states",
                         "control_hint", "ip_image_embeds", "ip_adapter_masks",
                         "ip_decay_floor", "ip_decay_start_timestep", "ip_static_scale"],
            output_names=["out_sample"],
            opset_version=17,
            do_constant_folding=True,
            # KHÔNG dùng dynamic_axes — giống mọi bản export khác trong dự
            # án này, ưu tiên tốc độ trên điện thoại với shape cố định. HỆ
            # QUẢ: N cố định vĩnh viễn trong file .mnn này, đổi N phải export
            # lại (xem tên file có N ở trên).
        
            dynamo=False,  # torch >=2.9 đổi exporter mặc định sang dynamo (cần onnxscript,
            # hành vi trace khác) — đã tự cài torch 2.13 + kiểm chứng THẬT bằng
            # torch.onnx.export()+onnxruntime (xem tools/ip_adapter_decay.py và
            # lịch sử làm việc): thiếu dynamo=False sẽ lỗi ModuleNotFoundError nếu
            # thiếu onnxscript, hoặc dùng nhánh dynamo CHƯA kiểm chứng với cơ chế
            # runtime-scalar (pose_scale/depth_scale/ip_decay_floor...) toàn dự án
            # đang dựa vào. Ghim False để giữ ĐÚNG hành vi TorchScript-trace đã
            # xác nhận hoạt động đúng bằng thực nghiệm.
        )

    print("\n=== XONG PHẦN ONNX ===")
    print(f"Shape ip_image_embeds ({num_chars} nhân vật) thật: {tuple(example_embeds.shape)}")
    print(f"Shape ip_adapter_masks thật: {tuple(example_masks.shape)}")
    print("BƯỚC TIẾP THEO (thủ công, cần máy đã build MNNConverter):")
    print(f"  MNNConvert -f ONNX --modelFile {onnx_path} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, mnn_name)} \\")
    print(f"      --bizCode biz")
    print(f"  MNNConvert -f ONNX --modelFile {os.path.join(args.output_dir, 'ip_image_encoder.onnx')} \\")
    print(f"      --MNNModel {os.path.join(args.output_dir, 'ip_image_encoder.mnn')} \\")
    print(f"      --bizCode biz")
    print(f"\nQUAN TRỌNG: model này CỐ ĐỊNH cho ĐÚNG {num_chars} nhân vật (tên file có")
    print(f"'{num_chars}char') — dùng cho panel có ĐÚNG {num_chars} nhân vật cần giữ identity")
    print("tách biệt. App chọn model theo số nhân vật trong panel (xem")
    print("sdTxt2ImgWithCharactersAndPose trong ip_adapter.cpp) — KHÔNG dùng lẫn giữa")
    print("các N khác nhau, và KHÔNG ghi đè lên bản 1-nhân-vật.")
    print(f"\nGhi lại {example_embeds.shape[-2]} (số token) và {example_embeds.shape[-1]} "
          f"(chiều embedding) — cần khớp đúng trong ip_adapter.cpp (hằng số "
          f"IP_EMBED_TOKENS/IP_EMBED_DIM), y hệt bản gốc.")


if __name__ == "__main__":
    main()
