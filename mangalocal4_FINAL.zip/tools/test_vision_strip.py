#!/usr/bin/env python3
"""mục 266 — kiểm thử `VisionJudge.stripImageTag` + đường gọi giám khảo QUA API bằng kotlinc THẬT.

Vấn đề: prompt của giám khảo trên máy có dạng `<img>/đường/dẫn/nội/bộ.png</img>câu hỏi` (thẻ chỉ có nghĩa với MNN-LLM). Khi gửi qua API ngoài, đường dẫn nội bộ (có thể chứa tên truyện,
tên người dùng) KHÔNG được lọt ra ngoài; chỉ câu hỏi thuần đi kèm ảnh. Kiểm: (1) stripImageTag == bản tham chiếu Python (chỉ gỡ thẻ ở ĐẦU, cho cả đường dẫn có khoảng trắng/Unicode/xuống dòng,
không đụng thẻ nằm giữa câu, chỉ gỡ thẻ đầu tiên); (2) chạy VisionJudge.judge với `ask` kiểu API: mọi prompt tới "API" đều không chứa đường dẫn hay `<img>`, vẫn đủ câu hỏi đếm (+ tiếp xúc khi cần)
và kết luận đúng; (3) MAX_ANSWER_TOKENS_API đủ rộng cho model "suy nghĩ" (>= 64 và > mức trên máy). Thử phá mã.
KHÔNG chứng minh: model đám mây trả lời đúng. Cần kotlinc (không có -> SKIP).
"""
import os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline/VisionJudge.kt')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + str(d)[:400]) if (d and not c) else '')); ok &= bool(c)
def find():
    for c in [os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/work/kotlinc/bin/kotlinc', '/home/claude/tools_dl/kotlinc/bin/kotlinc']:
        if c and os.path.exists(c): return c
KOTLINC = find()
if not KOTLINC:
    print('SKIP: không có kotlinc'); sys.exit(0)
KLIB = os.path.join(os.path.dirname(os.path.dirname(KOTLINC)), 'lib', 'kotlin-stdlib.jar')

DRIVER = r'''
import com.mangalocal.pipeline.*
import java.io.File
fun hex(s: String): String = s.toByteArray(Charsets.UTF_8).joinToString("") { "%02x".format(it) }
fun unhex(h: String): String = if (h == "-") "" else String(ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }, Charsets.UTF_8)
fun main(args: Array<String>) {
    val out = StringBuilder()
    for (line in File(args[0]).readLines()) {
        if (line.isEmpty()) continue
        val p = line.split("\t")
        when (p[0]) {
            "S" -> out.append(hex(VisionJudge.stripImageTag(unhex(p[1])))).append("\n")
            "J" -> {
                val path = unhex(p[1]); val contact = p[2] == "1"; val answers = p[3].split("|").map { unhex(it) }
                val sent = ArrayList<String>(); var i = 0
                val v = VisionJudge.judge(path, contact) { prompt -> sent.add(VisionJudge.stripImageTag(prompt)); answers[minOf(i++, answers.size - 1)] }
                out.append(sent.size).append("\t").append(sent.joinToString("\u0001") { hex(it) }).append("\t").append(v.counted ?: "null").append("\t").append(v.contact ?: "null").append("\n")
            }
            "K" -> out.append(VisionJudge.MAX_ANSWER_TOKENS_API).append(" ").append(VisionJudge.MAX_ANSWER_TOKENS).append("\n")
        }
    }
    File(args[1]).writeText(out.toString())
}
'''
def hx(s): return s.encode('utf-8').hex() if s else '-'
def unhx(h): return bytes.fromhex(h).decode('utf-8') if h != '-' else ''
def ref_strip(p): return re.sub(r'^\s*<img>.*?</img>', '', p, flags=re.S).strip()

STRIP = []
for path in ['/data/user/0/com.mangalocal/files/stories/abc/p1.png', '/sdcard/Ảnh truyện/chương 1/p 2.png', 'C:\\x\\y.png', 'a\nb.png', '', ' ', 'x</img>y']:
    q = 'How many people are visible in this image? Answer with a single number only.'
    STRIP.append(f'<img>{path}</img>{q}')
STRIP += ['  \n <img>/p.png</img> hỏi gì đó  ', 'Look <img>/mid.png</img> not at start', '<img>/a.png</img>one <img>/b.png</img> two', 'không có thẻ nào', '', '<img></img>', '<img>/only.png</img>', '<IMG>/upper.png</IMG>q',
          '<img>/a.png</img>\n\n  q với dòng mới  \n']
JUDGE = [
    ('/data/secret user/stories/s1/panel_3.png', 0, ['two']),
    ('/sdcard/Ảnh/bí mật.png', 1, ['3', 'YES']),
    ('/x/y.png', 1, ['maybe', 'no']),
]

def lines_for():
    L = ['S\t' + hx(s) for s in STRIP]
    for path, contact, ans in JUDGE: L.append('\t'.join(['J', hx(path), str(contact), '|'.join(hx(a) for a in ans)]))
    L.append('K')
    return L

def verify(res):
    errs = []; i = 0
    for s in STRIP:
        got = unhx(res[i]); i += 1
        if got != ref_strip(s): errs.append(('strip', s[:50], got[:50], ref_strip(s)[:50]))
    for path, contact, ans in JUDGE:
        n, sent, counted, cont = res[i].split('\t'); i += 1
        prompts = [unhx(x) for x in sent.split('\x01')] if sent else []
        want_n = 2 if contact else 1
        if int(n) != want_n: errs.append(('n-prompts', path, n))
        for pr in prompts:
            if path in pr or '<img>' in pr or '</img>' in pr: errs.append(('LEAK', path, pr[:80]))
        if prompts and 'How many people' not in prompts[0]: errs.append(('count-question', prompts[0][:60]))
        if contact and (len(prompts) < 2 or 'physical contact' not in prompts[1]): errs.append(('contact-question', prompts[-1][:60] if prompts else ''))
        exp_count = {'two': '2', '3': '3', 'maybe': 'null'}[ans[0]]
        if counted != exp_count: errs.append(('counted', path, counted, exp_count))
        exp_contact = 'null' if not contact else {'YES': 'true', 'no': 'false'}[ans[1]]
        if cont != exp_contact: errs.append(('contact', path, cont, exp_contact))
    api, local = (int(x) for x in res[i].split()); i += 1
    if not (api >= 64 and api > local): errs.append(('tokens', api, local))
    return errs

tmp = tempfile.mkdtemp()
def compile_(src, tag):
    d = os.path.join(tmp, tag); os.makedirs(d, exist_ok=True)
    open(os.path.join(d, 'Drv.kt'), 'w').write(DRIVER)
    jar = os.path.join(tmp, tag + '.jar')
    return jar, subprocess.run([KOTLINC, src, os.path.join(d, 'Drv.kt'), '-d', jar], capture_output=True, text=True)
def run(jar, lines):
    fi = os.path.join(tmp, 'in.txt'); fo = os.path.join(tmp, 'out.txt')
    open(fi, 'w').write('\n'.join(lines) + '\n')
    r = subprocess.run(['java', '-cp', f'{jar}:{KLIB}', 'DrvKt', fi, fo], capture_output=True, text=True)
    if r.returncode != 0: return None, r.stderr[-400:]
    return open(fo, encoding='utf-8').read().split('\n')[:len(lines)], ''

jar, r = compile_(KT, 'orig')
check('VisionJudge.kt biên dịch bằng kotlinc thật', r.returncode == 0, r.stderr[-500:])
if r.returncode != 0:
    print('CÓ LỖI'); sys.exit(1)
L = lines_for()
res, err = run(jar, L)
check('chạy driver', res is not None, err)
errs = verify(res) if res else [('run', err)]
check(f'stripImageTag khớp tham chiếu ({len(STRIP)} ca) + {len(JUDGE)} lượt giám khảo kiểu API không lọt đường dẫn nội bộ', not errs, errs[:3])

base = open(KT, encoding='utf-8').read()
MUT = [
    ('stripImageTag không neo ở đầu (gỡ cả thẻ giữa câu)', 'Regex("^\\\\s*<img>.*?</img>", RegexOption.DOT_MATCHES_ALL)', 'Regex("\\\\s*<img>.*?</img>", RegexOption.DOT_MATCHES_ALL)'),
    ('stripImageTag không xử lý đường dẫn có xuống dòng', 'RegexOption.DOT_MATCHES_ALL), "").trim()', 'RegexOption.IGNORE_CASE), "").trim()'),
    ('stripImageTag tham lam (gỡ tới thẻ đóng CUỐI)', '<img>.*?</img>', '<img>.*</img>'),
    ('stripImageTag không cắt khoảng trắng', '"").trim()', '"")'),
    ('MAX_ANSWER_TOKENS_API quá nhỏ cho model suy nghĩ', 'const val MAX_ANSWER_TOKENS_API = 256', 'const val MAX_ANSWER_TOKENS_API = 12'),
]
lo, hi = 0, len(MUT)
if os.environ.get('MUT_RANGE'):
    a, b = os.environ['MUT_RANGE'].split(':'); lo, hi = int(a), int(b)
killed = ran = 0
for i in range(lo, min(hi, len(MUT))):
    name, old, new = MUT[i]
    if base.count(old) != 1:
        check(f'đột biến {i} có điểm cắm duy nhất ({name})', False, f'{base.count(old)} chỗ'); continue
    mp = os.path.join(tmp, f'VisionJudge_m{i}.kt'); open(mp, 'w', encoding='utf-8').write(base.replace(old, new))
    j, rr = compile_(mp, f'mut{i}')
    if rr.returncode != 0:
        check(f'đột biến {i} biên dịch được ({name})', False, rr.stderr[-300:]); continue
    ran += 1
    res2, e2 = run(j, L)
    survived = res2 is not None and not verify(res2)
    check(f'đột biến "{name}" bị bộ kiểm bắt', not survived)
    killed += (not survived)
if ran: check(f'thử phá mã: {killed}/{ran} đột biến bị bắt', killed == ran)
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
