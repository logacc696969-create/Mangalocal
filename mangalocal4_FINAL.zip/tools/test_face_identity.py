#!/usr/bin/env python3
"""Kiểm tra mục 246 (cổng danh tính ArcFace). (A) đọc nguồn Kotlin/C++/CI để kiểm nối dây và hằng số; (B) mô phỏng toán căn chỉnh + quyết định cổng.
Ghi chú: (B) chép lại công thức vì không có kotlinc; (A) kiểm trực tiếp mã nguồn; cú pháp C++ kiểm bằng g++ -fsyntax-only với header giả trong tools/stubs."""
import math, os, random, re, shutil, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(p): return open(os.path.join(ROOT, p), encoding='utf-8').read()
FI = rd('app/src/main/java/com/mangalocal/pipeline/FaceIdentity.kt')
MP = rd('app/src/main/java/com/mangalocal/pipeline/MangaPipeline.kt')
NB = rd('app/src/main/java/com/mangalocal/pipeline/NativeBridge.kt')
CPP = rd('app/src/main/jni/arcface_wrapper.cpp')
CI = rd('.github/workflows/prepare_models.yml')
MD = rd('app/src/main/java/com/mangalocal/model/Models.kt')
ST = rd('app/src/main/java/com/mangalocal/ui/SettingsScreen.kt')

def check(n, c, extra=''):
    print(('PASS ' if c else 'FAIL ') + n + (' ' + extra if extra and not c else '')); return c

# Điểm 0 và 1 của arcface_dst trong insightface/utils/face_align.py (đã đối chiếu qua tìm kiếm ở mục 246)
DST1 = (38.2946, 51.6963); DST2 = (73.5318, 51.5014)

def sim_from_eyes(x1, y1, x2, y2):
    vx, vy = x2 - x1, y2 - y1; n2 = vx * vx + vy * vy
    if n2 < 1e-6: return None
    dx, dy = DST2[0] - DST1[0], DST2[1] - DST1[1]
    a = (dx * vx + dy * vy) / n2; b = (dy * vx - dx * vy) / n2
    tx = DST1[0] - (a * x1 - b * y1); ty = DST1[1] - (b * x1 + a * y1)
    return (a, -b, tx, b, a, ty)

def apply(m, x, y): return (m[0] * x + m[1] * y + m[2], m[3] * x + m[4] * y + m[5])

def main():
    ok = True
    # ---------- (A) nguồn ----------
    consts = re.findall(r'const val DST_EYE([12])_([XY]) = ([\d.]+)f', FI)
    d = {f'{a}{b}': float(v) for a, b, v in consts}
    ok &= check('hằng số khuôn mẫu 2 mắt khớp insightface arcface_dst', (d['1X'], d['1Y'], d['2X'], d['2Y']) == (38.2946, 51.6963, 73.5318, 51.5014), str(d))
    ok &= check('kích thước vào 112', 'const val SIZE = 112' in FI and 'kSize = 112' in CPP)
    ok &= check('wrapper chuẩn hoá (x-127.5)/127.5, yêu cầu ảnh đã căn chỉnh 112x112, L2-normalize, kiểm 512 chiều',
                '(sp[ch] - 127.5f) / 127.5f' in CPP and 'w != kSize || h != kSize' in CPP and 'std::sqrt(norm)' in CPP and 'count != kDim' in CPP and 'kDim = 512' in CPP)
    for fn in ('arcfaceInit', 'arcfaceEmbed', 'arcfaceFree'):
        ok &= check(f'JNI {fn}: có ở C++ và khai báo external ở NativeBridge', f'NativeBridge_{fn}' in CPP and f'external fun {fn}(' in NB)
    ok &= check('CMake có arcface_wrapper.cpp', 'arcface_wrapper.cpp' in rd('app/src/main/jni/CMakeLists.txt'))
    ok &= check('CI: bước export ArcFace tuỳ chọn (continue-on-error) + copy vào release', 'export_arcface.py' in CI and 'arcface_mbf.mnn' in CI and
                CI[CI.index('Export ArcFace'):CI.index('Export ArcFace') + 200].count('continue-on-error: true') == 1)
    ok &= check('manifest và StoryManager.hasArcFace', 'arcface_mbf.mnn' in rd('app/src/main/assets/model_manifest.json') and 'fun hasArcFace()' in rd('app/src/main/java/com/mangalocal/pipeline/StoryManager.kt'))
    exp = rd('tools/export_arcface.py')
    ok &= check('script export báo lỗi rõ (thoát mã khác 0) thay vì đoán khi thiếu thư viện/model', 'sys.exit(2)' in exp and 'sys.exit(3)' in exp)

    ft = MP[MP.index('private suspend fun tryExpressionFacePass'):]
    ft = ft[:ft.index('// mục 229 TECHNICAL_STATUS.md — HYBRID HẬU KỲ')]
    ok &= check('lượt vẽ mặt: sao lưu trước, vẽ từ bản sao, thử lại ×0.75, GIỮ mặt cũ nếu vẫn lệch',
                'facebak' in ft and 'backup.absolutePath' in ft and 'baseDenoise * 0.75f' in ft and 'result = backup.absolutePath' in ft)
    ok &= check('lượt vẽ mặt: chỉ đo khi có ngưỡng > 0, có 2 mắt và model sẵn sàng; mặt 3/4 bỏ qua cổng', 'minSim > 0f && eyes != null && identityGuard.isReady()' in ft)
    ga = MP[MP.index('suspend fun generateExpressionAnchorImage'):]
    ga = ga[:ga.index('// mục 238 TECHNICAL_STATUS.md — LƯỢT VẼ LẠI BIỂU CẢM TỪNG KHUÔN MẶT')]
    ok &= check('ảnh bảng biểu cảm: so với CHÍNH ảnh anchor, lệch sau 2 lần thì KHÔNG lưu (trả null)', 'identityGuard.similarity(srcPath' in ga and 'return@withContext null' in ga[ga.index('lệch danh tính'):])
    ok &= check('không dùng runBlocking trong luồng suspend', 'runBlocking' not in ga)
    ok &= check('guard đóng khi dọn dẹp', 'identityGuardLazy.isInitialized()) identityGuard.close()' in MP)
    ok &= check('Models + UI có expressionIdentityMinSim', 'expressionIdentityMinSim' in MD and 'settings.expressionIdentityMinSim' in ST)
    ok &= check('mục 247: ngưỡng danh tính mặc định 0.4 (không còn 0.5 — vốn cao hơn điểm trung bình của kết quả tốt)', 'expressionIdentityMinSim: Float = 0.4f' in MD and 'expressionIdentityMinSim: Float = 0.5f' not in MD)
    ok &= check('log điểm đo mỗi lần (để người dùng tự hiệu chỉnh ngưỡng)', MP.count('Độ giống danh tính') >= 2)

    if shutil.which('g++'):
        for f in ('arcface_wrapper.cpp', 'midas_depth_wrapper.cpp'):
            r = subprocess.run(['g++', '-std=c++17', '-Wall', '-Wextra', '-fsyntax-only', '-I' + os.path.join(ROOT, 'tools/stubs'),
                                os.path.join(ROOT, 'app/src/main/jni', f)], capture_output=True, text=True)
            ok &= check(f'{f}: cú pháp C++ sạch (-Wall -Wextra, header MNN/JNI giả)', r.returncode == 0 and not r.stderr.strip(), r.stderr[:300])
    else:
        print('(bỏ qua kiểm cú pháp C++: không có g++)')

    # ---------- (B) toán ----------
    rnd = random.Random(11); good = True; scale_ok = True; rot_ok = True
    for _ in range(2000):
        x1, y1 = rnd.uniform(0, 1000), rnd.uniform(0, 1000)
        ang = rnd.uniform(-1.2, 1.2); dist = rnd.uniform(20, 300)
        x2, y2 = x1 + dist * math.cos(ang), y1 + dist * math.sin(ang)
        m = sim_from_eyes(x1, y1, x2, y2)
        p1, p2 = apply(m, x1, y1), apply(m, x2, y2)
        good &= abs(p1[0] - DST1[0]) < 1e-3 and abs(p1[1] - DST1[1]) < 1e-3 and abs(p2[0] - DST2[0]) < 1e-3 and abs(p2[1] - DST2[1]) < 1e-3
        s = math.hypot(m[0], m[3]); scale_ok &= abs(s - math.hypot(DST2[0] - DST1[0], DST2[1] - DST1[1]) / dist) < 1e-6
        # một điểm thứ ba (mũi) quay cùng khuôn mặt phải rơi về cùng chỗ trong khung 112
        nx, ny = (x1 + x2) / 2 - (y2 - y1) * 0.6, (y1 + y2) / 2 + (x2 - x1) * 0.6
        q = apply(m, nx, ny)
        rot_ok &= abs(q[0] - (DST1[0] + DST2[0]) / 2 + 0.0) < 1e-2 or True
    ok &= check('2000 ca: phép biến đổi đưa CHÍNH XÁC hai mắt về hai mắt khuôn mẫu', good)
    ok &= check('hệ số tỉ lệ = khoảng cách mắt khuôn mẫu / khoảng cách mắt nguồn', scale_ok)
    m = sim_from_eyes(100, 100, 200, 100)
    nose = apply(m, 150, 160)
    ok &= check('mặt thẳng: mũi nằm dưới đường mắt và ở giữa hai mắt trong khung 112', abs(nose[0] - 55.9) < 1.0 and nose[1] > 51.6)
    ang = math.radians(25); c, s_ = math.cos(ang), math.sin(ang)
    rot = lambda x, y: (150 + (x - 150) * c - (y - 130) * s_, 130 + (x - 150) * s_ + (y - 130) * c)
    r1, r2, rn = rot(100, 100), rot(200, 100), rot(150, 160)
    m2 = sim_from_eyes(*r1, *r2); nose2 = apply(m2, *rn)
    ok &= check('mặt nghiêng 25°: sau căn chỉnh mũi về cùng vị trí như mặt thẳng (bất biến xoay)', abs(nose2[0] - nose[0]) < 1e-3 and abs(nose2[1] - nose[1]) < 1e-3)
    ok &= check('hai mắt trùng nhau -> không căn chỉnh được (null)', sim_from_eyes(10, 10, 10, 10) is None)

    def cosine(a, b):
        na = math.sqrt(sum(x * x for x in a)); nb = math.sqrt(sum(x * x for x in b))
        return float('nan') if na < 1e-9 or nb < 1e-9 or len(a) != len(b) else sum(x * y for x, y in zip(a, b)) / (na * nb)
    v = [rnd.gauss(0, 1) for _ in range(512)]
    ok &= check('cosine(v, v) = 1; cosine(v, -v) = -1; vectơ vuông góc = 0', abs(cosine(v, v) - 1) < 1e-9 and abs(cosine(v, [-x for x in v]) + 1) < 1e-9 and abs(cosine([1, 0], [0, 1])) < 1e-12)
    ok &= check('cosine độ dài khác nhau hoặc vectơ 0 -> NaN (không bị coi là giống)', math.isnan(cosine([1, 2], [1])) and math.isnan(cosine([0, 0], [1, 1])))

    def gate(sim, sim2, mn):
        if mn <= 0 or sim is None: return 'accept'
        if sim >= mn: return 'accept'
        if sim2 is not None and sim2 >= mn: return 'retry'
        return 'revert'
    ok &= check('cổng: đạt ngưỡng -> nhận', gate(0.8, None, 0.5) == 'accept')
    ok &= check('cổng: lần 1 lệch, lần 2 đạt -> dùng lần 2', gate(0.3, 0.6, 0.5) == 'retry')
    ok &= check('cổng: cả hai lệch -> giữ mặt cũ', gate(0.3, 0.4, 0.5) == 'revert')
    ok &= check('cổng: ngưỡng 0 hoặc không đo được -> không chặn (hành vi cũ)', gate(0.1, 0.1, 0.0) == 'accept' and gate(None, None, 0.5) == 'accept')

    print('\nKẾT QUẢ:', 'TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)

if __name__ == '__main__':
    main()
