#!/usr/bin/env python3
"""mục 284 — sinh khối mảng BREADTH của AgeBodyTable.kt TỪ các tệp chép nguyên văn nguồn (tools/data/nhanes3_breadth_t53_t56.txt, zivicnjak2008_tables1_4.txt).
Dùng:  python3 tools/gen_age_breadth_table.py          → in khối Kotlin ra stdout
       python3 tools/gen_age_breadth_table.py --check  → thoát 0 nếu khối trong AgeBodyTable.kt đúng bằng khối sinh ra
Cột mỗi hàng (hàng i = tuổi 6+i, đơn vị cm): NHANES vai nam, vai nữ, hông nam, hông nữ | Zivicnjak vai nam, vai nữ, hông nam, hông nữ (mm → cm)."""
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rows(fn, tag):
    out = {}
    for l in open(os.path.join(ROOT, 'tools/data', fn), encoding='utf-8'):
        if l.startswith('#') or not l.strip(): continue
        p = l.split()
        if p[0] == tag: out[(p[1], int(p[2]))] = p[4]
    return out
def block():
    n53, n56 = rows('nhanes3_breadth_t53_t56.txt', 'T53'), rows('nhanes3_breadth_t53_t56.txt', 'T56')
    z1, z4 = rows('zivicnjak2008_tables1_4.txt', 'T1'), rows('zivicnjak2008_tables1_4.txt', 'T4')
    cm = lambda mm: f'{float(mm) / 10:.2f}'.rstrip('0').rstrip('.') if False else repr(round(float(mm) / 10, 2))
    lines = []
    for age in range(6, 19):
        v = [n53[('M', age)], n53[('F', age)], n56[('M', age)], n56[('F', age)], cm(z1[('M', age)]), cm(z1[('F', age)]), cm(z4[('M', age)]), cm(z4[('F', age)])]
        lines.append('        floatArrayOf(' + ', '.join(x + 'f' for x in v) + '),   // ' + str(age))
    return '    private val BREADTH = arrayOf(\n' + '\n'.join(lines) + '\n    )'
if __name__ == '__main__':
    b = block()
    if '--check' in sys.argv:
        src = open(os.path.join(ROOT, 'app/src/main/java/com/mangalocal/model/AgeBodyTable.kt'), encoding='utf-8').read()
        sys.exit(0 if b in src else 1)
    print(b)
