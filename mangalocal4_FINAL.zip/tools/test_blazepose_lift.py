#!/usr/bin/env python3
# mục 280 — kiểm BlazePose (độ sâu 3D thật) ở HAI tầng:
#  (1) TEST ĐƠN VỊ: biên dịch và chạy BlazePoseLiftTest.kt (kotlinc) — dữ liệu tổng hợp có đáp án biết trước.
#  (2) TEST TÍCH HỢP VỚI MÔ HÌNH THẬT trên ảnh thật (bus.jpg, hai người): Kotlin cắt ROI → Python chạy blazepose_lite.mnn (đã chuyển từ tflite thật của MediaPipe v0.8.10) → Kotlin phân tích →
#      so với đường tham chiếu độc lập (PIL cắt ảnh + tflite chuẩn). Gồm ca ảnh XOAY 90° để kiểm quy ước xoay ROI và xoay `world` bằng DỮ LIỆU THẬT.
# Phần (2) cần: python numpy, Pillow, MNN (pip install MNN), ai-edge-litert; công cụ `mnnconvert` (đi kèm pip MNN); mạng (lần đầu tải model ~3 MB + ảnh ~130 KB từ GitHub, kiểm sha256).
# Thiếu một thứ nào: phần (2) BỎ QUA và nói rõ (không coi là đạt ngầm). Thư mục đệm: $BLAZEPOSE_DIR hoặc tools/.cache_blazepose.
# Cờ --native: chạy thêm blazepose_wrapper.cpp THẬT trên máy chủ (tools/test_blazepose_native.py).
import hashlib, math, os, shutil, subprocess, sys, tempfile, urllib.request
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K = os.path.join(ROOT, 'app/src/main/java/com/mangalocal'); TDIR = os.path.join(ROOT, 'tools/kotlin_tests')
CACHE = os.environ.get('BLAZEPOSE_DIR', os.path.join(ROOT, 'tools', '.cache_blazepose'))
SRC = {
    'pose_landmark_lite.tflite': ('https://raw.githubusercontent.com/google/mediapipe/v0.8.10/mediapipe/modules/pose_landmark/pose_landmark_lite.tflite', 'f17bfbecadb61c3be1baa8b8d851cc6619c870a87167b32848ad20db306b9d61'),
    'pose_landmark_full.tflite': ('https://raw.githubusercontent.com/google/mediapipe/v0.8.10/mediapipe/modules/pose_landmark/pose_landmark_full.tflite', 'e9a5c5cb17f736fafd4c2ec1da3b3d331d6edbe8a0d32395855aeb2cdfd64b9f'),
    'bus.jpg': ('https://raw.githubusercontent.com/ultralytics/ultralytics/main/ultralytics/assets/bus.jpg', 'c02019c4979c191eb739ddd944445ef408dad5679acab6fd520ef9d434bfbc63'),
}
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)

def find_kotlinc():
    for c in (os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/tools/kotlinc/bin/kotlinc', '/home/claude/work/kotlinc/bin/kotlinc'):
        if c and os.path.exists(c): return c

# ───────────────────────── (1) test đơn vị ─────────────────────────
kc = find_kotlinc()
LIFT = os.path.join(K, 'pipeline/BlazePoseLift.kt'); STUB = os.path.join(TDIR, 'StubStoryManager.kt')
if not kc:
    print('BỎ QUA toàn bộ phần chạy Kotlin: không có kotlinc (đặt KOTLINC=/đường/dẫn/kotlinc, bản 1.9.x).')
    print('ĐẠT (chỉ kiểm tĩnh)' if not fails else 'THẤT BẠI'); sys.exit(1 if fails else 0)
tmp = tempfile.mkdtemp(prefix='bpl_')
def kotlin_jar(name, *files):
    jar = os.path.join(tmp, name + '.jar')
    r = subprocess.run([kc, '-nowarn', STUB, LIFT, *files, '-include-runtime', '-d', jar], capture_output=True, text=True)
    return jar if r.returncode == 0 else (None, r.stderr[-1500:])
j = kotlin_jar('unit', os.path.join(TDIR, 'BlazePoseLiftTest.kt'))
check(isinstance(j, str), 'biên dịch BlazePoseLift.kt + test đơn vị' + ('' if isinstance(j, str) else '\n' + j[1]))
if isinstance(j, str):
    o = subprocess.run(['java', '-Dstdout.encoding=UTF-8', '-jar', j], capture_output=True, text=True).stdout
    n_pass = sum(1 for l in o.splitlines() if l.startswith('PASS')); bad = [l for l in o.splitlines() if l.startswith('FAIL')]
    for l in bad: print(l)
    check(not bad and n_pass >= 36, f'test đơn vị (dữ liệu tổng hợp có đáp án): {n_pass} phép kiểm đạt, {len(bad)} lỗi')

# ───────────────────────── (2) tích hợp với mô hình thật ─────────────────────────
def ensure_artifacts():
    try:
        import numpy, PIL, MNN, ai_edge_litert  # noqa
    except Exception as e:
        return None, f'thiếu thư viện Python ({e})'
    os.makedirs(CACHE, exist_ok=True)
    for name, (url, sha) in SRC.items():
        p = os.path.join(CACHE, name)
        if not os.path.exists(p):
            try: urllib.request.urlretrieve(url, p)
            except Exception as e: return None, f'không tải được {name}: {e}'
        if hashlib.sha256(open(p, 'rb').read()).hexdigest() != sha: return None, f'sha256 của {name} KHÁC bản đã ghim — nguồn đã đổi, cần xem lại'
    mnn = os.path.join(CACHE, 'blazepose_lite.mnn')
    if not os.path.exists(mnn):
        mc = shutil.which('mnnconvert')
        if not mc: return None, 'không có công cụ mnnconvert (pip install MNN)'
        r = subprocess.run([mc, '-f', 'TFLITE', '--modelFile', os.path.join(CACHE, 'pose_landmark_lite.tflite'), '--MNNModel', mnn, '--bizCode', 'mangalocal'], capture_output=True, text=True)
        if r.returncode != 0 or not os.path.exists(mnn): return None, 'mnnconvert lỗi: ' + (r.stdout + r.stderr)[-300:]
    return CACHE, None

art, why = ensure_artifacts()
if art is None:
    print(f'BỎ QUA test tích hợp với mô hình thật: {why}')
else:
    import numpy as np
    from PIL import Image
    import MNN
    from ai_edge_litert.interpreter import Interpreter
    FROM_BLAZE = [0, -1, 12, 14, 16, 11, 13, 15, 24, 26, 28, 23, 25, 27, 5, 2, 8, 7]
    def sig(v): return 1 / (1 + np.exp(-v))
    tfl = Interpreter(model_path=os.path.join(art, 'pose_landmark_lite.tflite')); tfl.allocate_tensors()
    tin = tfl.get_input_details()[0]; touts = {d['name']: d for d in tfl.get_output_details()}
    def run_tflite(crop):
        tfl.set_tensor(tin['index'], crop[None].astype(np.float32)); tfl.invoke()
        g = lambda n: tfl.get_tensor(touts[n]['index']).reshape(-1)
        return np.concatenate([g('Identity_1'), g('Identity'), g('Identity_4')]).astype(np.float32)
    net = MNN.Interpreter(os.path.join(art, 'blazepose_lite.mnn')); sess = net.createSession(); inp = net.getSessionInput(sess)
    def run_mnn(crop):
        t = MNN.Tensor((1, 256, 256, 3), MNN.Halide_Type_Float, crop[None].astype(np.float32).copy(), MNN.Tensor_DimensionType_Tensorflow)
        inp.copyFrom(t); net.runSession(sess); res = []
        for n in ('Identity_1', 'Identity', 'Identity_4'):
            o = net.getSessionOutput(sess, n); sh = o.getShape()
            h = MNN.Tensor(sh, MNN.Halide_Type_Float, np.zeros(sh, np.float32), MNN.Tensor_DimensionType_Tensorflow); o.copyToHostTensor(h)
            res.append(np.array(h.getData(), dtype=np.float32).reshape(-1))
        return np.concatenate(res)
    def pil_crop(img, box_px, scale=1.25, size=256):
        x1, y1, x2, y2 = box_px; cx = (x1 + x2) / 2; cy = (y1 + y2) / 2; side = max(x2 - x1, y2 - y1) * scale; a = side / size
        c = img.transform((size, size), Image.AFFINE, (a, 0, cx - side / 2, 0, a, cy - side / 2), resample=Image.BILINEAR, fillcolor=(0, 0, 0))
        return np.asarray(c, dtype=np.float32) / 255.0, (cx, cy, side)
    def decode(raw, roi):   # đường tham chiếu độc lập: ROI không xoay
        cx, cy, side = roi; L = raw[1:196].reshape(39, 5); Wd = raw[196:].reshape(39, 3)
        img = np.stack([cx + (L[:, 0] / 256 - .5) * side, cy + (L[:, 1] / 256 - .5) * side], 1)
        return img[:33], sig(L[:33, 3]), Wd[:33]   # 39 điểm của model = 33 điểm thân + 6 điểm phụ (bàn tay/chân dùng cho ROI); chỉ dùng 33 điểm thân
    bus = Image.open(os.path.join(art, 'bus.jpg')).convert('RGB'); Wi, Hi = bus.size
    boxes = {'trai': (50, 398, 245, 904), 'giua': (222, 405, 345, 860)}
    ref = {}
    for nm, b in boxes.items():
        crop, roi = pil_crop(bus, b); raw = run_tflite(crop); ref[nm] = decode(raw, roi) + (raw[0],)
    # ảnh xoay 90° theo chiều kim đồng hồ: (x, y) → (H − y, x); world (x, y) → (−y, x)
    rot = bus.rotate(-90, expand=True); rot_path = os.path.join(tmp, 'bus_rot90.png'); rot.save(rot_path)
    def to_rot(xy): return np.stack([Hi - xy[:, 1], xy[:, 0]], 1)
    def kps18(img_xy, vis, W, H):
        out = []
        for i in range(18):
            b = FROM_BLAZE[i]
            if b >= 0: x, y, v = img_xy[b, 0], img_xy[b, 1], vis[b]
            else: x, y, v = (img_xy[11, 0] + img_xy[12, 0]) / 2, (img_xy[11, 1] + img_xy[12, 1]) / 2, min(vis[11], vis[12])
            out.append(f'{x / W} {y / H} {1 if v > 0.5 else 0}')
        return ' '.join(out)
    lines = []
    for nm, b in boxes.items():
        lines.append(f'{nm}_box|{os.path.join(art, "bus.jpg")}|box|{b[0] / Wi} {b[1] / Hi} {b[2] / Wi} {b[3] / Hi}')
        lines.append(f'{nm}_kps|{os.path.join(art, "bus.jpg")}|kps|{kps18(ref[nm][0], ref[nm][1], Wi, Hi)}')
        lines.append(f'{nm}_rot|{rot_path}|kps|{kps18(to_rot(ref[nm][0]), ref[nm][1], Hi, Wi)}')
    cases = os.path.join(tmp, 'cases.txt'); open(cases, 'w').write('\n'.join(lines) + '\n')
    outdir = os.path.join(tmp, 'io'); os.makedirs(outdir, exist_ok=True)
    j2 = kotlin_jar('it', os.path.join(TDIR, 'BlazePoseLiftIT.kt'))
    check(isinstance(j2, str), 'biên dịch cầu nối tích hợp BlazePoseLiftIT.kt' + ('' if isinstance(j2, str) else '\n' + j2[1]))
    if isinstance(j2, str):
        r = subprocess.run(['java', '-jar', j2, 'crop', cases, outdir], capture_output=True, text=True)
        check(r.returncode == 0, 'Kotlin cắt ROI cho 6 ca (hộp, khung xương, khung xương ảnh xoay 90°)' + ('' if r.returncode == 0 else '\n' + r.stderr[-800:]))
        if r.returncode == 0:
            for l in lines:
                nm = l.split('|')[0]; crop = np.fromfile(os.path.join(outdir, nm + '.crop.f32'), dtype='<f4').reshape(256, 256, 3)
                run_mnn(crop).astype('<f4').tofile(os.path.join(outdir, nm + '.out.f32'))
            r = subprocess.run(['java', '-jar', j2, 'parse', cases, outdir], capture_output=True, text=True)
            check(r.returncode == 0, 'Kotlin phân tích đầu ra model thật (parseOutput, depthFor)' + ('' if r.returncode == 0 else '\n' + r.stderr[-800:]))
            if r.returncode == 0:
                def lifted(nm): return np.loadtxt(os.path.join(outdir, nm + '.lifted.txt'))
                def roi_of(nm): return np.loadtxt(os.path.join(outdir, nm + '.roi.txt'))
                # (a) đường Kotlin (cắt + MNN + ánh xạ ngược) so với đường tham chiếu (PIL + tflite)
                for nm in boxes:
                    L = lifted(nm + '_box'); img, vis, Wd, _ = ref[nm]; sel = vis > 0.5
                    dpx = np.abs(L[:, 0:2] - img)[sel].max(); dw = np.abs(L[:, 3:6] - Wd)[sel].max()
                    body = max(img[sel, 1].max() - img[sel, 1].min(), 1)
                    check(dpx <= 0.01 * body, f'[{nm}] Kotlin(cắt+MNN) vs PIL(cắt)+tflite: lệch điểm ảnh tối đa {dpx:.2f}px ≤ 1% chiều cao người ({0.01 * body:.1f}px)')
                    check(dw <= 0.03, f'[{nm}] lệch toạ độ world tối đa {dw:.4f} m ≤ 0,03 m')
                # (b) ảnh XOAY 90°. PHÉP SO SÁNH SẮC: ca xoay (ROI xoay 90° bù lại) với CÙNG ROI không xoay trên ảnh gốc (ca _kps) — hai ảnh cắt gần như giống hệt từng pixel, nên mọi lỗi
                #     quy ước xoay (hướng góc, xoay world) sẽ hiện thành lệch lớn. (So với tham chiếu theo HỘP không dùng được cho việc này: khác tâm và cỡ ROI ⇒ biến thiên tự nhiên của model.)
                for nm in boxes:
                    rr = roi_of(nm + '_rot'); img, vis, Wd, _ = ref[nm]; sel = vis > 0.5; body = max(img[sel, 1].max() - img[sel, 1].min(), 1)
                    check(abs(rr[3] - math.pi / 2) < 0.15, f'[{nm}] ảnh xoay 90°: ROI tự xoay {math.degrees(rr[3]):.1f}° (kỳ vọng ≈ 90°)')
                    Lk = lifted(nm + '_kps'); Lr = lifted(nm + '_rot')
                    dpx = np.abs(Lr[:, 0:2] - to_rot(Lk[:, 0:2]))[sel].max()
                    exp_w = np.stack([-Lk[:, 4], Lk[:, 3], Lk[:, 5]], 1); dw = np.abs(Lr[:, 3:6] - exp_w)[sel].max()
                    check(dpx <= 0.005 * body, f'[{nm}] ảnh xoay 90° vs cùng ROI không xoay: điểm ảnh khớp phép xoay hình học, lệch tối đa {dpx:.2f}px ≤ 0,5% chiều cao ({0.005 * body:.1f}px)')
                    check(dw <= 0.01, f'[{nm}] ảnh xoay 90°: world sau khi xoay lại theo ROI khớp (−y, x, z) của ca không xoay, lệch tối đa {dw:.4f} m ≤ 0,01 m (z KHÔNG đổi khi xoay ảnh)')
                    # thông tin (kiểm chặn lỗi lớn, KHÔNG phải độ chính xác): ROI theo khung xương so với ROI theo hộp = biến thiên tự nhiên của model khi đổi khung cắt
                    dv = np.abs(Lk[:, 0:2] - img)[sel].max(); dwv = np.abs(Lk[:, 3:6] - Wd)[sel].max()
                    print(f'  (thông tin) [{nm}] ROI theo khung xương vs ROI theo hộp: lệch điểm ảnh tối đa {dv:.1f}px = {100 * dv / body:.1f}% chiều cao; world {dwv:.3f} m')
                    check(dv <= 0.08 * body and dwv <= 0.25, f'[{nm}] đổi khung cắt (tâm hông + cỡ 2,5·r thay vì tâm hộp) chỉ làm model đổi trong giới hạn (≤ 8% chiều cao, ≤ 0,25 m) — không có lỗi lớn')
                # (c) depthFor trên dữ liệu thật, so với cài đặt độc lập bằng numpy
                for nm in boxes:
                    zk = np.loadtxt(os.path.join(outdir, nm + '_kps.z.txt')); L = lifted(nm + '_kps'); img, vis, Wd, _ = ref[nm]
                    tok = [l for l in lines if l.startswith(nm + '_kps|')][0].split('|')[3].split(); kp = np.array(tok, dtype=float).reshape(18, 3)
                    wx = np.zeros((18, 3)); vv = np.zeros(18)
                    for i in range(18):
                        b = FROM_BLAZE[i]
                        if b >= 0: wx[i] = L[b, 3:6]; vv[i] = L[b, 2]
                        else: wx[i] = (L[11, 3:6] + L[12, 3:6]) / 2; vv[i] = min(L[11, 2], L[12, 2])
                    hw = (wx[8] + wx[11]) / 2; hs = (kp[8, :2] + kp[11, :2]) / 2; num = den = 0.0
                    asp = Wi / Hi   # mục 282: ảnh nguồn KHÔNG vuông (bus.jpg 810×1080) — khớp trong đơn vị đẳng hướng (x·aspect, y), z quy về đơn vị bề ngang
                    for i in range(18):
                        if kp[i, 2] < .5 or vv[i] < .5 or i in (8, 11): continue
                        dw_ = wx[i, :2] - hw[:2]; dk = (kp[i, :2] - hs) * np.array([asp, 1.0]); num += (dk * dw_).sum(); den += (dw_ ** 2).sum()
                    s = num / den; zp = np.where(kp[:, 2] > .5, (s / asp) * (wx[:, 2] - hw[2]), 0.0)
                    check(np.isfinite(zk).all() and np.abs(zk - zp).max() < 1e-3, f'[{nm}] depthFor (Kotlin) = cài đặt numpy độc lập: lệch tối đa {np.abs(zk - zp).max():.2e}; tỷ lệ s = {s:.3f} khung/mét')
                    check(zk.max() - zk.min() >= 0.02, f'[{nm}] dải z {zk.max() - zk.min():.3f} ≥ 0,02 (Z_MEANINGFUL) ⇒ Pose3D.hasDepth = true, orbit dùng z thật không đoán')
                zg = np.loadtxt(os.path.join(outdir, 'giua_kps.z.txt'))
                check(zg[7] < -0.05 and zg[7] < zg[1] and zg[0] < zg[1], f'[giua] tay trái gập ngang ngực ra TRƯỚC (z cổ tay trái {zg[7]:.3f} < −0,05 và < z cổ), mũi ra trước cổ — khớp ảnh thật')
    # (d) hai model ĐÓNG TRONG APK (app/src/main/assets/blazepose/, mục 281) chạy ĐÚNG như tflite chuẩn (chặn đóng nhầm/hỏng/cũ vào APK)
    def tflite_runner(path):
        it = Interpreter(model_path=path); it.allocate_tensors(); i0 = it.get_input_details()[0]; o = {d['name']: d for d in it.get_output_details()}
        def run(crop):
            it.set_tensor(i0['index'], crop[None].astype(np.float32)); it.invoke(); g = lambda n: it.get_tensor(o[n]['index']).reshape(-1)
            return np.concatenate([g('Identity_1'), g('Identity'), g('Identity_4')]).astype(np.float32)
        return run
    def mnn_runner(path):
        nt = MNN.Interpreter(path); ss = nt.createSession(); ip = nt.getSessionInput(ss)
        def run(crop):
            t = MNN.Tensor((1, 256, 256, 3), MNN.Halide_Type_Float, crop[None].astype(np.float32).copy(), MNN.Tensor_DimensionType_Tensorflow)
            ip.copyFrom(t); nt.runSession(ss); res = []
            for n in ('Identity_1', 'Identity', 'Identity_4'):
                o = nt.getSessionOutput(ss, n); sh = o.getShape()
                h = MNN.Tensor(sh, MNN.Halide_Type_Float, np.zeros(sh, np.float32), MNN.Tensor_DimensionType_Tensorflow); o.copyToHostTensor(h)
                res.append(np.array(h.getData(), dtype=np.float32).reshape(-1))
            return np.concatenate(res)
        return run
    acrop, _ = pil_crop(bus, boxes['giua'])
    for variant in ('lite', 'full'):
        ap = os.path.join(ROOT, 'app/src/main/assets/blazepose', f'blazepose_{variant}.mnn')
        if not os.path.exists(ap): check(False, f'thiếu {ap}'); continue
        a = tflite_runner(os.path.join(art, f'pose_landmark_{variant}.tflite'))(acrop); b = mnn_runner(ap)(acrop)
        d_flag = abs(a[0] - b[0]); d_lm = np.abs(a[1:196] - b[1:196]).max(); d_w = np.abs(a[196:] - b[196:]).max()
        check(d_flag < 1e-3 and d_lm < 0.01 and d_w < 1e-3 and b[0] > 0.5, f'model đóng trong APK blazepose_{variant}.mnn = tflite chuẩn: |Δ cờ| {d_flag:.5f}, |Δ điểm ảnh| {d_lm:.4f} px, |Δ world| {d_w:.5f} m, cờ có người {b[0]:.3f}')
shutil.rmtree(tmp, ignore_errors=True)
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
