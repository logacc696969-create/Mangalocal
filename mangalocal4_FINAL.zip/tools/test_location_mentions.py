#!/usr/bin/env python3
"""mục 249 — kiểm thử LocationMentions (@-mention bối cảnh trong văn bản truyện).

Thuật toán chép lại bằng Python (sandbox không có kotlinc); hằng số/điều kiện quyết định được đối chiếu chuỗi nguồn Kotlin,
và test chạy thật: kịch bản tiếng Việt có dấu, email không bị hiểu nhầm, khớp dài nhất, dính theo vị trí, fuzz bất biến.
Không chứng minh LLM thật tuân theo hướng dẫn; ánh xạ cảnh↔vị trí chỉ là xấp xỉ (xem LocationMentions.kt).
"""
import os, random, re, sys, unicodedata

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
KB = os.path.join(ROOT, 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(KB, *p), encoding='utf8').read()
KT = rd('pipeline', 'LocationMentions.kt')
MAXB = int(re.search(r'const val MAX_BRACKET_NAME = (\d+)', KT).group(1))

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

# ---------------- bản chép ----------------
def fold(s):
    d = unicodedata.normalize('NFD', s.replace('đ', 'd').replace('Đ', 'D'))
    d = ''.join(c for c in d if unicodedata.category(c) != 'Mn')
    return re.sub(r'\s+', ' ', d.lower()).strip()

def is_word(c): return c.isalnum() or c == '_'

def find(text, known):
    by_len = sorted({k for k in known if k.strip()}, key=lambda k: -len(k))
    out = []; i = 0
    while i < len(text):
        if text[i] != '@' or (i > 0 and is_word(text[i - 1])): i += 1; continue
        after = i + 1
        if after < len(text) and text[after] == '[':
            close = text.find(']', after + 1)
            if close != -1 and after + 2 <= close <= after + 1 + MAXB and '\n' not in text[after + 1:close]:
                raw = text[after + 1:close].strip()
                if raw:
                    canon = next((k for k in by_len if fold(k) == fold(raw)), raw)
                    out.append((canon, i, close + 1, canon in by_len)); i = close + 1; continue
            i += 1; continue
        matched = False
        for name in by_len:
            e = after + len(name)
            if e <= len(text) and fold(text[after:e]) == fold(name) and (e == len(text) or not is_word(text[e])):
                out.append((name, i, e, True)); i = e; matched = True; break
        if not matched: i += 1
    return out

def strip(text, ms):
    if not ms: return text
    sb = []; pos = 0
    for name, s, e, _ in sorted(ms, key=lambda m: m[1]):
        if s < pos: continue
        sb.append(text[pos:s]); sb.append(name); pos = e
    sb.append(text[pos:]); return ''.join(sb)

def assign(n, length, ms):
    if n <= 0: return []
    srt = sorted(ms, key=lambda m: m[1]); out = []
    for i in range(n):
        chosen = None
        for name, s, e, k in srt:
            if s * n < (i + 1) * max(length, 1): chosen = name
            else: break
        out.append(chosen)
    return out

def snap(raw, names):
    f = fold(raw)
    return next((n for n in names if fold(n) == f), raw)

def apply(scenes, length, ms, known):
    mentioned = list(dict.fromkeys(m[0] for m in ms)); pool = list(dict.fromkeys(mentioned + list(known)))
    sticky = assign(len(scenes), length, ms); out = []
    for i, loc in enumerate(scenes):
        snapped = snap(loc, pool) if loc and loc.strip() else None
        if not ms: chosen = snapped
        elif snapped is not None and snapped in mentioned: chosen = snapped
        else: chosen = sticky[i] if sticky[i] is not None else snapped
        out.append(chosen)
    return out

# ---------------- find / strip ----------------
K = ['Quán Cà Phê', 'Cầu Cũ', 'Cầu']
t = 'Lan đến @Quán Cà Phê lúc tối. Sau đó cô ra @[Bờ Sông Mới] ngồi.'
ms = find(t, K)
check('nhận @Tên đã biết (có dấu, nhiều từ) và @[Tên mới]', [(m[0], m[3]) for m in ms] == [('Quán Cà Phê', True), ('Bờ Sông Mới', False)])
check('strip: bỏ ký hiệu @ và [] — còn tên thường', strip(t, ms) == 'Lan đến Quán Cà Phê lúc tối. Sau đó cô ra Bờ Sông Mới ngồi.')
check('khớp không phân biệt hoa/thường/dấu, trả về TÊN CHUẨN đã biết', [m[0] for m in find('@quan ca phe và @CẦU CŨ', K)] == ['Quán Cà Phê', 'Cầu Cũ'])
check('khớp DÀI NHẤT: "@Cầu Cũ" không bị cắt thành "Cầu"', [m[0] for m in find('Đứng ở @Cầu Cũ', K)] == ['Cầu Cũ'])
check('ranh giới từ: "@Cầu" trong "@Cầuđỏ" KHÔNG khớp; "@Cầu." khớp', find('@Cầuđỏ', ['Cầu']) == [] and [m[0] for m in find('Ở @Cầu.', ['Cầu'])] == ['Cầu'])
check('email / nhắc người KHÔNG bị hiểu nhầm: "a@Cầu.com" (sau chữ) và "@someone" (không khớp tên đã biết)', find('gửi tới an@Cầu.com', ['Cầu']) == [] and find('nhắn @someone nhé', ['Cầu']) == [])
check('@[...] rỗng / quá dài / xuống dòng / thiếu ] -> bỏ qua, không lỗi', find('@[]', K) == [] and find('@[' + 'x' * (MAXB + 5) + ']', K) == [] and find('@[a\nb]', K) == [] and find('@[chưa đóng', K) == [])
check('@[Tên] trùng tên đã biết (khác hoa/thường) -> dùng tên chuẩn, known=True', find('@[quán cà phê]', K)[0][0] == 'Quán Cà Phê' and find('@[quán cà phê]', K)[0][3] is True)
check('văn bản không có @ -> không mention, strip giữ nguyên', find('Không có gì', K) == [] and strip('Không có gì', []) == 'Không có gì')
check('hai mention sát nhau và mention ở cuối văn bản đều nhận', len(find('@[A]@[B]', [])) == 2 and [m[0] for m in find('Ra @Cầu', ['Cầu'])] == ['Cầu'])

# ---------------- gán dính theo vị trí ----------------
text = 'a' * 100
ms2 = [('Quán', 10, 14, True), ('Cầu', 60, 64, True)]
check('cảnh đầu (đoạn 0–25%) nhận Quán (mention ở 10%); cảnh 2 (25–50%) vẫn Quán; cảnh 3 (50–75%) nhận Cầu (60%); cảnh 4 giữ Cầu', assign(4, 100, ms2) == ['Quán', 'Quán', 'Cầu', 'Cầu'])
check('cảnh nằm TRƯỚC mention đầu tiên -> chưa có bối cảnh', assign(4, 100, [('Quán', 80, 84, True)]) == [None, None, None, 'Quán'])
check('không mention -> toàn None; số cảnh 0 -> rỗng', assign(3, 100, []) == [None] * 3 and assign(0, 100, ms2) == [])

# ---------------- áp dụng lên cảnh ----------------
known = ['Quán Cà Phê', 'Cầu Cũ']
m3 = find('@Quán Cà Phê ' + 'x' * 40 + ' @Cầu Cũ ' + 'y' * 40, known)
L = len('@Quán Cà Phê ' + 'x' * 40 + ' @Cầu Cũ ' + 'y' * 40)
check('LLM để trống -> lấy theo vị trí', apply([None, '', None, None], L, m3, known) == ['Quán Cà Phê', 'Quán Cà Phê', 'Cầu Cũ', 'Cầu Cũ'])
check('LLM chọn ĐÚNG một bối cảnh đã nhắc (kể cả khác vị trí xấp xỉ) -> giữ lựa chọn của LLM, đã chuẩn hoá tên', apply(['cau cu', None, None, None], L, m3, known)[0] == 'Cầu Cũ')
check('LLM bịa nơi KHÁC khi người dùng đã gắn thẻ ở vị trí đó -> bị thay bằng thẻ', apply(['phòng ngủ', None, None, None], L, m3, known)[0] == 'Quán Cà Phê')
check('cảnh trước mention đầu, LLM có tên tự đặt -> GIỮ tên LLM (không có thẻ nào áp dụng)', apply(['phòng ngủ', None, None, None], 100, [('Quán', 90, 94, True)], ['Quán'])[0] == 'phòng ngủ')
check('không có mention: chỉ chuẩn hoá tên về tên đã biết, còn lại nguyên văn (hành vi cũ giữ nguyên)', apply(['quán cà phê', 'Nơi lạ', None], 50, [], known) == ['Quán Cà Phê', 'Nơi lạ', None])

# ---------------- fuzz bất biến ----------------
rng = random.Random(249)
alphabet = list('abc dđêôư@[]\n') + ['@Quán', '@[X]', ' @Cầu ', 'Cầu', 'Quán Cà Phê']
bad = []
for trial in range(3000):
    s = ''.join(rng.choice(alphabet) for _ in range(rng.randint(0, 40)))
    mm = find(s, K)
    spans = [(m[1], m[2]) for m in mm]
    if any(a >= b for a, b in spans) or any(spans[i][1] > spans[i + 1][0] for i in range(len(spans) - 1)): bad.append(('span', trial)); continue
    if any(not (0 <= a and b <= len(s)) for a, b in spans): bad.append(('biên', trial)); continue
    st = strip(s, mm)
    if '@[' in st and any(m[3] is False for m in mm) and False: pass
    # phần ngoài các span giữ nguyên, phần trong thay bằng tên
    exp = []; pos = 0
    for (name, a, b, _) in sorted(mm, key=lambda m: m[1]): exp.append(s[pos:a]); exp.append(name); pos = b
    exp.append(s[pos:])
    if st != ''.join(exp): bad.append(('strip', trial)); continue
    n = rng.randint(0, 8); asg = assign(n, len(s), mm)
    if len(asg) != n: bad.append(('assign độ dài', trial)); continue
    seen = False
    for x in asg:   # đơn điệu: đã có bối cảnh thì không quay lại None
        if x is not None: seen = True
        elif seen: bad.append(('assign đơn điệu', trial)); break
    scenes = [rng.choice([None, '', 'Cầu cũ', 'Chỗ lạ', 'quán cà phê']) for _ in range(n)]
    out = apply(scenes, len(s), mm, K)
    if len(out) != n: bad.append(('apply độ dài', trial)); continue
    if not mm and out != [snap(x, K) if x and x.strip() else None for x in scenes]: bad.append(('apply không mention', trial))
check('fuzz 3000 chuỗi: span hợp lệ không chồng, strip đúng nguyên văn ngoài span, assign đúng độ dài và đơn điệu, apply giữ độ dài và hành vi cũ khi không mention', not bad)
if bad: print('   ví dụ lỗi:', bad[:5])

# ---------------- đối chiếu nguồn Kotlin + nối dây ----------------
LP, SS = rd('pipeline', 'LLMParser.kt'), rd('ui', 'StoryScreens.kt')
check('Kotlin: hằng số và điều kiện của find khớp bản chép', 'const val MAX_BRACKET_NAME = 60' in KT and 'isWordChar(text[i - 1])' in KT and "text[after] == '['" in KT
      and 'close in (after + 2)..(after + 1 + MAX_BRACKET_NAME)' in KT and 'sortedByDescending { it.length }' in KT and '(endIdx == text.length || !isWordChar(text[endIdx]))' in KT)
check('Kotlin: so khớp không phân biệt hoa/thường/dấu (đ→d, NFD, bỏ \\p{Mn}, gộp khoảng trắng)', "replace('đ', 'd').replace('Đ', 'D')" in KT and 'Normalizer.Form.NFD' in KT and '\\\\p{Mn}+' in KT and 'Regex("\\\\s+")' in KT)
check('Kotlin: assign/apply khớp bản chép', 'm.start.toLong() * sceneCount < (i + 1L) * maxOf(textLength, 1)' in KT and 'snapped != null && mentionedNames.any { it == snapped } -> snapped' in KT
      and 'else -> sticky[i] ?: snapped' in KT and 'mentions.isEmpty() -> snapped' in KT)
check('nối dây: parseStory bỏ ký hiệu khỏi văn bản gửi LLM, thêm hướng dẫn, hậu xử lý ở CẢ 2 nhánh (≤ batch và nhiều batch)',
      'val locMentions = LocationMentions.find(text, knownLocationNames)' in LP and 'val cleanText = LocationMentions.strip(text, locMentions)' in LP
      and 'storyGuidance + LocationMentions.guidanceFor(locMentions)' in LP and LP.count('scenePrompt(cleanText,') == 2 and LP.count('LocationMentions.apply(parseScenes(') == 1 and LP.count('LocationMentions.apply(allScenes,') == 1)
check('nối dây: không còn gọi scenePrompt với văn bản gốc còn ký hiệu @', 'scenePrompt(text,' not in LP)
check('nối dây: ô nhập truyện có gợi ý cú pháp', '@[Bối cảnh mới]' in SS and '@Tên bối cảnh đã có' in SS)

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
