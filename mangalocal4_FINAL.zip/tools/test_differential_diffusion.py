#!/usr/bin/env python3
"""mục 248 — kiểm thử Differential Diffusion (DD).

Phần LOGIC (sd_engine/DifferentialDiffusion.hpp) được BIÊN DỊCH và CHẠY THẬT bằng g++ (không có MNN/xtensor ở đây nên
không biên dịch được Pipeline.hpp — đoạn sửa trong Pipeline.hpp chỉ được đối chiếu chuỗi nguồn). Không chứng minh ảnh đẹp hơn:
hiệu quả thật phải so ảnh bật/tắt cùng seed trên máy.
"""
import os, re, subprocess, sys, tempfile

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
JNI = os.path.join(ROOT, 'app', 'src', 'main', 'jni')
KB = os.path.join(ROOT, 'app', 'src', 'main', 'java', 'com', 'mangalocal')
rd = lambda *p: open(os.path.join(*p), encoding='utf8', errors='replace').read()

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok &= bool(cond)

CPP = r'''
#include "DifferentialDiffusion.hpp"
#include <cstdio>
#include <cstdlib>
#include <vector>
int main() {
  // 1) cờ mặc định tắt, ghi/đọc được
  std::printf("default %d\n", (int)g_differential_diffusion.load());
  g_differential_diffusion.store(true); std::printf("set %d\n", (int)g_differential_diffusion.load()); g_differential_diffusion.store(false);
  // 2) phần nhiễu còn lại
  std::printf("rem %.6f %.6f %.6f %.6f %.6f\n", ddRemaining(0, 20), ddRemaining(20, 20), ddRemaining(25, 20), ddRemaining(5, 0), ddRemaining(10, 20));
  // 3) số bước được thả tự do với c = (j+0.37)/T  (không có hòa) ; c=0 và c=1
  int Ts[] = {1, 2, 7, 20, 50};
  for (int T : Ts) {
    for (int j = 0; j < T; ++j) {
      float c = ((float)j + 0.37f) / (float)T;
      int released = 0, last = 0, mono = 1;
      for (int d = 1; d <= T; ++d) { int g = (int)ddGate(c, ddRemaining(d, T)); released += g; if (g < last) mono = 0; last = g; }
      std::printf("rel %d %d %d %d\n", T, j, released, mono);
    }
    int r0 = 0, r1 = 0;
    for (int d = 1; d <= T; ++d) { r0 += (int)ddGate(0.0f, ddRemaining(d, T)); r1 += (int)ddGate(1.0f, ddRemaining(d, T)); }
    std::printf("edge %d %d %d\n", T, r0, r1);
  }
  // 4) mask nhị phân: ddGateBuffer == chính mask ở MỌI bước (tính chất an toàn)
  srand(248); int diff = 0, total = 0;
  for (int trial = 0; trial < 200; ++trial) {
    int T = 1 + rand() % 60; size_t n = 1 + rand() % 400; std::vector<float> m(n), g(n);
    for (auto &x : m) x = (rand() % 2) ? 1.0f : 0.0f;
    for (int d = 1; d <= T; ++d) { ddGateBuffer(m.data(), g.data(), n, ddRemaining(d, T)); for (size_t k = 0; k < n; ++k) { total++; if (g[k] != m[k]) diff++; } }
  }
  std::printf("binary %d %d\n", total, diff);
  // 5) ddGateBuffer == ddGate từng phần tử với mask mềm
  int bad = 0; std::vector<float> m(101), g(101);
  for (int k = 0; k <= 100; ++k) m[k] = k / 100.0f;
  for (int d = 1; d <= 13; ++d) { float r = ddRemaining(d, 13); ddGateBuffer(m.data(), g.data(), m.size(), r); for (int k = 0; k <= 100; ++k) if (g[k] != ddGate(m[k], r)) bad++; }
  std::printf("buffer %d\n", bad);
  return 0;
}
'''

tmp = tempfile.mkdtemp()
src = os.path.join(tmp, 't.cpp'); exe = os.path.join(tmp, 't')
open(src, 'w').write(CPP)
comp = subprocess.run(['g++', '-std=c++17', '-O1', '-Wall', '-Wextra', '-Werror', '-I', os.path.join(JNI, 'sd_engine'), src, '-o', exe], capture_output=True, text=True)
check('header biên dịch sạch với g++ -std=c++17 -Wall -Wextra -Werror', comp.returncode == 0)
if comp.returncode != 0: print(comp.stderr[:800])
run = subprocess.run([exe], capture_output=True, text=True) if comp.returncode == 0 else None
out = run.stdout.split('\n') if run else []
L = lambda k: [l.split() for l in out if l.startswith(k + ' ')]

check('cờ toàn cục mặc định TẮT, ghi/đọc được', L('default') == [['default', '0']] and L('set') == [['set', '1']])
rem = L('rem')[0][1:] if L('rem') else []
check('ddRemaining: 1 ở đầu, 0 ở cuối, kẹp ≥ 0, tổng bước ≤ 0 -> 0, giữa = 0.5', rem == ['1.000000', '0.000000', '0.000000', '0.000000', '0.500000'])
rel = L('rel')
exact = all(int(x[3]) == int(x[2]) + 1 for x in rel)
check('pixel độ thay đổi c=(j+0.37)/T được thả đúng (j+1) bước CUỐI, với T ∈ {1,2,7,20,50} (%d trường hợp)' % len(rel), len(rel) == 1 + 2 + 7 + 20 + 50 and exact)
check('đơn điệu: đã thả tự do thì các bước sau vẫn tự do', all(x[4] == '1' for x in rel))
edge = L('edge')
check('c=0 không bao giờ tự do; c=1 tự do ở MỌI bước', len(edge) == 5 and all(x[2] == '0' and int(x[3]) == int(x[1]) for x in edge))
b = L('binary')[0] if L('binary') else ['binary', '0', '1']
check('mask NHỊ PHÂN: kết quả đúng bằng mask ở mọi bước (%s phần tử, 0 khác biệt) -> bật DD không đổi gì với mask cứng' % b[1], int(b[1]) > 10000 and b[2] == '0')
check('ddGateBuffer khớp ddGate từng phần tử (mask mềm)', L('buffer') == [['buffer', '0']])

# ---- đối chiếu nguồn ----
PH = rd(JNI, 'sd_engine', 'Pipeline.hpp'); MD = rd(JNI, 'mnn_diffusion_pipeline.cpp')
NB = rd(KB, 'pipeline', 'NativeBridge.kt'); MP = rd(KB, 'pipeline', 'MangaPipeline.kt'); ML = rd(KB, 'model', 'Models.kt'); ST = rd(KB, 'ui', 'SettingsScreen.kt')
check('Pipeline.hpp: include header và nhánh DD chỉ chạy khi cờ bật, giữ NGUYÊN nhánh trộn cũ',
      '#include "DifferentialDiffusion.hpp"' in PH and 'if (g_differential_diffusion.load())' in PH and
      'latents = xt::eval(orig_noised * (1.0f - mask) + latents * mask);' in PH)
check('Pipeline.hpp: số bước tính đúng (đã chạy i - start_step + 1 / tổng timesteps.size() - start_step)',
      'ddRemaining(i - start_step + 1, (int)timesteps.size() - start_step)' in PH and 'ddGateBuffer(mask.data(), dd_gate.data(), mask.size(), dd_remaining)' in PH)
check('Pipeline.hpp: chỉ trong khối `if (req.has_mask)` (txt2img không bị ảnh hưởng)',
      re.search(r'if \(req\.has_mask\) \{.*?maskBlendTimestepIndex\(i, \(int\)timesteps\.size\(\), g_mask_blend_matched\.load\(\)\).*?g_differential_diffusion\.load\(\)', PH, re.S) is not None)  # mục 262: t_xt giờ qua maskBlendTimestepIndex (cờ tắt = i, như cũ)
check('JNI: hàm riêng setDifferentialDiffusion(jboolean) ghi cờ toàn cục', 'Java_com_mangalocal_pipeline_NativeBridge_setDifferentialDiffusion(JNIEnv*, jobject, jboolean enabled)' in MD and 'g_differential_diffusion.store(enabled == JNI_TRUE)' in MD)
check('Kotlin: external fun setDifferentialDiffusion(enabled: Boolean) khớp JNI', 'external fun setDifferentialDiffusion(enabled: Boolean)' in NB)
check('nối dây: cờ được đặt ở CẢ 3 điểm vào (runGeneration, regeneratePanel, upscaleApprovedPanels)', MP.count('NativeBridge.setDifferentialDiffusion(settings.differentialInpaint)') == 3)
check('nối dây: Models mặc định TẮT + công tắc Cài đặt', 'val differentialInpaint: Boolean = false' in ML and 'settings.differentialInpaint' in ST and 'copy(differentialInpaint = it)' in ST)

print('\nKẾT QUẢ: ' + ('TẤT CẢ ĐẠT' if ok else 'CÓ LỖI'))
sys.exit(0 if ok else 1)
