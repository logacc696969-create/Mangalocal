#!/usr/bin/env python3
"""mục 285 — CHẠY THẬT sd_engine/UnetModule.hpp (UnetModuleSet) trên backend OpenCL của MNN 3.6.1 THẬT (lần ĐẦU TIÊN; trước đó chỉ CPU — 283, 284.6).
Chạy cùng bộ kiểm của tools/mnn_probe/unet_module_real_check.cpp (32 phép: từng biến thể, step(), kích thước động, lỗi đầu vào, base_is_variant, "tước == đầy đủ" ...) hai lần: CPU (đối chứng) và OpenCL,
cho cả hai lane fp32 và w8 (định dạng UNet thật của app), rồi phá mã UnetModule.hpp khi chạy trên OpenCL: bộ kiểm phải đỏ.

GIỚI HẠN — ĐỌC KỸ: sandbox không có GPU; OpenCL ở đây là pocl (OpenCL trên CPU). Nghĩa là CHỈ kiểm TÍNH ĐÚNG CHỨC NĂNG của đường chia sẻ trọng số (Module::Config::base + rearrange + onClone của các execution OpenCL)
trên backend OpenCL của MNN; KHÔNG nói gì về Adreno 660 (Zenfone 8): tốc độ, RAM, độ chính xác fp16, các kernel dành riêng cho Adreno (đường tối ưu "subgroup/Adreno" của MNN không được chạy).
Cần MỘT BẢN MNN TỰ BUILD VÁ HAI CHỖ (chỉ trong sandbox, KHÔNG thuộc dự án), vì pocl bị MNN từ chối:
  1) source/backend/opencl/core/runtime/OpenCLRuntime.cpp dòng ~71: getDevices(CL_DEVICE_TYPE_GPU) -> CL_DEVICE_TYPE_ALL  (MNN chỉ nhận thiết bị loại GPU; pocl là CPU ⇒ "Can't Find type=3 backend");
  2) cùng tệp dòng ~180: tắt nhánh `cl_intel_subgroups` (pocl khai báo nhưng không biên dịch nổi `winogradTransform_subgroup_buf`; Adreno không có tiện ích này nên nhánh đó không liên quan thiết bị thật).
Build: cmake -G Ninja -DMNN_OPENCL=ON -DMNN_LOW_MEMORY=ON -DMNN_CPU_WEIGHT_DEQUANT_GEMM=ON -DMNN_SUPPORT_TRANSFORMER_FUSE=ON -DMNN_BUILD_SHARED_LIBS=ON -DMNN_SEP_BUILD=OFF -DMNN_BUILD_CONVERTER=OFF -DMNN_BUILD_TOOLS=OFF ... ; ninja MNN
Cần thêm: apt pocl-opencl-icd ocl-icd-libopencl1 ocl-icd-opencl-dev; pip MNN==3.6.1 (lấy `mnnconvert` cho lane w8).
Biến môi trường: MNN_OCL_BUILD (thư mục chứa libMNN.so, mặc định /home/claude/ocl/build), MNN_SRC (mặc định /home/claude/ocl/MNN-3.6.1). Thiếu/không có OpenCL → BỎ QUA (exit 0) và nói rõ lý do.
Dùng: python3 tools/test_unet_module_opencl.py [--mut] [--only-mut]   (MUT_RANGE=lo:hi để chạy từng khúc đột biến)
"""
import glob, os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.environ.get('MNN_OCL_BUILD', '/home/claude/ocl/build'); SRC = os.environ.get('MNN_SRC', '/home/claude/ocl/MNN-3.6.1')
JNI = os.path.join(ROOT, 'app/src/main/jni'); T = os.path.join(ROOT, 'tools/mnn_probe')
HARN, ATT = os.path.join(T, 'unet_module_real_check.cpp'), os.path.join(T, 'lora_attach_branch.cpp')
def skip(why): print('BỎ QUA test OpenCL thật:', why); sys.exit(0)
if not shutil.which('g++'): skip('không có g++')
if not os.path.isfile(os.path.join(BUILD, 'libMNN.so')): skip(f'không thấy {BUILD}/libMNN.so (bản MNN có OpenCL tự build, xem đầu tệp)')
for sub in ('include/MNN/expr/Module.hpp', 'schema/current/MNN_generated.h', '3rd_party/flatbuffers/include/flatbuffers/flatbuffers.h'):
    if not os.path.isfile(os.path.join(SRC, sub)): skip(f'thiếu {sub} trong MNN_SRC={SRC}')
mnnconvert = shutil.which('mnnconvert') or '/usr/local/bin/mnnconvert'
lp = (glob.glob('/usr/lib/x86_64-linux-gnu/libpython3*.so') or [''])[0]
tmp = tempfile.mkdtemp(); fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)
env = dict(os.environ, LD_PRELOAD=lp, LD_LIBRARY_PATH=BUILD + ':' + os.environ.get('LD_LIBRARY_PATH', ''))
def sh(args, timeout=280, e=None):
    r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, env=e or env); return r.returncode, r.stdout, r.stderr

# 0) OpenCL có thật sự khởi tạo được không? (chương trình dò)
probe = os.path.join(tmp, 'probe.cpp'); open(probe, 'w').write('''#include <MNN/Interpreter.hpp>
#include <cstdio>
int main(){ MNN::BackendConfig bc; MNN::ScheduleConfig sc; sc.type = MNN_FORWARD_OPENCL; sc.backendConfig = &bc; auto r = MNN::Interpreter::createRuntime({sc}); std::printf("%s\\n", r.first.empty() ? "NONE" : "OK"); return 0; }''')
r = subprocess.run(['g++', '-std=c++17', '-O1', '-w', probe, f'-I{SRC}/include', '-o', os.path.join(tmp, 'probe'), '-L' + BUILD, '-lMNN', '-Wl,-rpath,' + BUILD, '-lpthread', '-ldl'], capture_output=True, text=True)
if r.returncode != 0: skip('không biên dịch được chương trình dò: ' + r.stderr[-300:])
rc, out, err = sh([os.path.join(tmp, 'probe')])
if "Can't Find type=3" in out + err or 'OK' not in out: skip('backend OpenCL KHÔNG khởi tạo được trong libMNN này ("Can\'t Find type=3 backend"): cần bản MNN đã vá hai chỗ cho pocl (xem đầu tệp) hoặc thiết bị GPU thật')

def build(exe, jni=JNI, opencl=False, harn=HARN):
    d = ['-DMANGALOCAL_UNET_FORWARD_TYPE=MNN_FORWARD_OPENCL'] if opencl else []
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-w'] + d + [f'-I{SRC}/include', f'-I{jni}', harn, '-o', exe, '-L' + BUILD, '-lMNN', '-Wl,-rpath,' + BUILD, '-lpthread', '-ldl'], capture_output=True, text=True)
    return r.returncode == 0, r.stderr[-800:]
okc, ec = build(os.path.join(tmp, 'h_cpu')); okl, el = build(os.path.join(tmp, 'h_cl'), opencl=True)
check(okc and okl, 'harness (UnetModule.hpp THẬT) biên dịch + liên kết với libMNN có OpenCL — bản CPU (đối chứng) và bản OpenCL (-DMANGALOCAL_UNET_FORWARD_TYPE=MNN_FORWARD_OPENCL)')
r = subprocess.run(['g++', '-std=c++17', '-O1', '-w', ATT, f'-I{SRC}/include', f'-I{SRC}/schema/current', f'-I{SRC}/3rd_party/flatbuffers/include', '-o', os.path.join(tmp, 'attach')], capture_output=True, text=True)
check(r.returncode == 0, 'lora_attach_branch biên dịch'); ATTACH = os.path.join(tmp, 'attach')
if not (okc and okl and r.returncode == 0): print(ec, el, r.stderr[-500:]); print('CÓ LỖI'); sys.exit(1)

def lane(harness, d, w8=False):
    os.makedirs(d, exist_ok=True); rc, out, err = sh([harness, 'gen', d])
    if rc != 0 or 'gen ok' not in out: return -1, 'gen lỗi: ' + out + err
    base = os.path.join(d, 'unet_base.mnn')
    if w8:
        shutil.copy(base, os.path.join(d, 'unet_base_f32.mnn'))
        rc, out, err = sh([mnnconvert, '-f', 'MNN', '--modelFile', os.path.join(d, 'unet_base_f32.mnn'), '--MNNModel', base, '--weightQuantBits', '8'])
        if rc != 0 or not os.path.exists(base): return -1, 'mnnconvert w8 lỗi: ' + out + err
    for i in (1, 2):
        if sh([ATTACH, base, os.path.join(d, f'spec{i}.txt'), os.path.join(d, f'lora{i}.lora.mnn'), '--strip-all-conv-weights'])[0] != 0: return -1, f'attach {i} lỗi'
        if sh([ATTACH, base, os.path.join(d, f'spec{i}.txt'), os.path.join(d, f'lora{i}_full.mnn')])[0] != 0: return -1, f'attach đầy đủ {i} lỗi'
    e = dict(env)
    if w8: e['UNET_TOL_ABS'] = '6.0'
    try: r = subprocess.run([harness, 'run', d], capture_output=True, text=True, timeout=280, env=e); return r.returncode, r.stdout
    except subprocess.TimeoutExpired: return -2, 'HẾT GIỜ (treo)'
def count(out): return len(re.findall(r'^PASS ', out, re.M)), len(re.findall(r'^FAIL ', out, re.M))
have_conv = os.path.exists(mnnconvert)
results = {}
LANES = () if '--only-mut' in sys.argv else (('CPU fp32', 'h_cpu', False), ('OpenCL fp32', 'h_cl', False), ('CPU w8', 'h_cpu', True), ('OpenCL w8', 'h_cl', True))
for name, harness, w8 in LANES:
    if w8 and not have_conv: print(f'  (bỏ qua lane {name}: không có mnnconvert — pip install MNN==3.6.1)'); continue
    cache = os.path.expanduser('~/.cache/pocl'); shutil.rmtree(cache, ignore_errors=True)
    rc, out = lane(os.path.join(tmp, harness), os.path.join(tmp, 'd_' + name.replace(' ', '_')), w8); p, f = count(out); results[name] = (rc, p, f, out)
    kern = len(glob.glob(os.path.join(cache, '**', '*.so'), recursive=True))
    results[name] += (kern,)
    check(rc == 0 and f == 0 and p >= 32, f'{name}: UnetModuleSet THẬT: {p} phép kiểm đạt, {f} lỗi (rc={rc})')
    if rc != 0: print(out[-600:])
    m = re.search(r'runOne\(0\): maxdiff=([0-9.e+-]+)', out); eq = re.search(r'tước \+ base so với tệp LoRA đầy đủ cùng lượng tử hoá: (\S+) \| (\S+)', out)
    print(f'  [số đo] {name}: sai lệch so với đáp án CPU thuần (double) {m.group(1) if m else "?"}; "đã tước + base" so với "đầy đủ": {eq.group(1) + " | " + eq.group(2) if eq else "?"}; kernel OpenCL pocl đã biên dịch: {kern}')
    if 'OpenCL' in name: check(kern > 50, f'{name}: BẰNG CHỨNG chạy OpenCL thật — pocl đã biên dịch {kern} kernel (> 50)')
    else: check(kern == 0, f'{name}: đối chứng — không có kernel OpenCL nào được biên dịch ({kern})')
    if eq: check(all(float(x) <= 1e-4 for x in eq.groups()), f'{name}: module ĐÃ TƯỚC trọng số + base == tệp LoRA ĐẦY ĐỦ cùng backend, cùng lượng tử hoá (≤ 1e-4)')
if 'OpenCL fp32' in results and 'CPU fp32' in results:
    a = float(re.search(r'runOne\(0\): maxdiff=([0-9.e+-]+)', results['OpenCL fp32'][3]).group(1)); b = float(re.search(r'runOne\(0\): maxdiff=([0-9.e+-]+)', results['CPU fp32'][3]).group(1))
    check(a < 1e-4 and b < 1e-4, f'fp32: OpenCL ({a:.1e}) và CPU ({b:.1e}) đều khớp đáp án CPU thuần < 1e-4')

# phép phá mã trên UnetModule.hpp, CHẠY TRÊN OpenCL (lane fp32)
if '--mut' in sys.argv:
    hp = os.path.join(JNI, 'sd_engine/UnetModule.hpp'); src = open(hp, encoding='utf-8').read()
    muts = [('rearrange=false (không chia sẻ trọng số nền)', 'mc.rearrange = true;', 'mc.rearrange = false;'),
            ('không gắn base cho module LoRA', 'mb.base = base_.get();', ''),
            ('đảo thứ tự tên cổng vào', '{"sample", "timestep", "encoder_hidden_states"}', '{"timestep", "sample", "encoder_hidden_states"}'),
            ('sai ánh xạ chỉ số biến thể khi nền là biến thể', 'loras_[base_is_variant_ ? idx - 1 : idx]', 'loras_[idx]'),
            ('công tắc backend bị bỏ qua (luôn CPU) — phải bị bắt bởi bằng chứng kernel OpenCL', 'sc.type = MANGALOCAL_UNET_FORWARD_TYPE;', 'sc.type = MNN_FORWARD_CPU;')]
    lo, hi = (int(x) for x in os.environ.get('MUT_RANGE', '0:999').split(':')); caught = 0; sel = [(i, m) for i, m in enumerate(muts)][lo:hi]
    for i, (name, old, new) in sel:
        assert old in src, f'mẫu đột biến không có: {name}'
        mj = os.path.join(tmp, f'jni_m{i}'); shutil.copytree(os.path.join(JNI, 'sd_engine'), os.path.join(mj, 'sd_engine'))
        open(os.path.join(mj, 'sd_engine/UnetModule.hpp'), 'w', encoding='utf-8').write(src.replace(old, new, 1))
        exe = os.path.join(tmp, f'hm{i}'); ok, e = build(exe, mj, opencl=True)
        if not ok: caught += 1; print('  BỊ BẮT (không biên dịch): ' + name); continue
        shutil.rmtree(os.path.expanduser('~/.cache/pocl'), ignore_errors=True)
        rc, out = lane(exe, os.path.join(tmp, f'dm{i}')); kern = len(glob.glob(os.path.expanduser('~/.cache/pocl/**/*.so'), recursive=True))
        bad = rc != 0 or 'FAIL' in out or kern == 0
        caught += bad; print(('  BỊ BẮT' if bad else '  SỐNG SÓT') + f': {name}', flush=True)
    check(caught == len(sel), f'phá mã (trên OpenCL): {caught}/{len(sel)} đột biến trên UnetModule.hpp bị bắt')
else: print('(bỏ qua đột biến — chạy với --mut)')
shutil.rmtree(tmp, ignore_errors=True)
print('\nCÓ LỖI' if fails else '\nĐẠT'); sys.exit(1 if fails else 0)
