#!/usr/bin/env python3
# mục 270 — chạy tools/test_unet_module.cpp (logic UnetModule.hpp trên BẢN GIẢ LẬP MNN) + phép thử phá mã.
# Chỉ cần g++ (không cần MNN/kotlinc). MUT_RANGE=a:b chạy một đoạn đột biến (mặc định tất cả; "0:0" = bỏ qua đột biến).
import os, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JNI = os.path.join(ROOT, 'app/src/main/jni')
MOCK = os.path.join(ROOT, 'tools/mnn_mock')
SRC = os.path.join(ROOT, 'tools/test_unet_module.cpp')
if not shutil.which('g++'):
    print('SKIP: không có g++'); sys.exit(0)

MUTS = [
 ('rearrange=false (base không chia sẻ trọng số — bẫy 264.2)', 'UnetModule.hpp', 'mc.rearrange = true;', 'mc.rearrange = false;'),
 ('không đặt base cho module LoRA', 'UnetModule.hpp', 'mb.base = base_.get();', 'mb.base = nullptr;'),
 ('đảo thứ tự input (timestep trước sample)', 'UnetModule.hpp', 'onForward({in_s, in_t, in_e})', 'onForward({in_t, in_s, in_e})'),
 ('bỏ kiểm kích thước đầu ra', 'UnetModule.hpp', '(std::size_t)info->size != n_sample', 'false'),
 ('huỷ nền TRƯỚC module LoRA', 'UnetModule.hpp', 'while (!loras_.empty()) loras_.pop_back();\n    base_.reset();', 'base_.reset();\n    while (!loras_.empty()) loras_.pop_back();'),
 ('timestep kiểu float', 'UnetModule.hpp', 'auto in_t = _Input({1}, NCHW, halide_type_of<int>());', 'auto in_t = _Input({1}, NCHW, halide_type_of<float>());'),
 ('trộn nhiều biến thể dùng điều kiện văn bản của biến thể 0', 'UnetModule.hpp', 'sample_b2, enc_per_variant[(std::size_t)act[j]], bufs[j].data()', 'sample_b2, enc_per_variant[0], bufs[j].data()'),
 ('Switch chạy luôn biến thể 0', 'UnetModule.hpp', 'return runOne((std::size_t)act[0], p.h8', 'return runOne(0, p.h8'),
 ('lỗi nạp LoRA không dọn', 'UnetModule.hpp', 'if (!m) { release(); return fail(err, "Module::load module LoRA', 'if (!m) { return fail(err, "Module::load module LoRA'),
 ('shapeMutable=false', 'UnetModule.hpp', 'mc.shapeMutable = true;', 'mc.shapeMutable = false;'),
 ('hoán đổi h8/w8 trong dạng sample', 'UnetModule.hpp', '_Input({2, 4, h8, w8}, NCHW', '_Input({2, 4, w8, h8}, NCHW'),
 ('không kẹp numThread >= 1', 'UnetModule.hpp', 'sc.numThread = num_threads < 1 ? 1 : num_threads;', 'sc.numThread = num_threads;'),
 ('Memory_Normal thay Memory_Low', 'UnetModule.hpp', 'backend_config_->memory = MNN::BackendConfig::Memory_Low;', 'backend_config_->memory = MNN::BackendConfig::Memory_Normal;'),
 ('không ghi nhận nền đã chạy', 'UnetModule.hpp', 'if (is_base) base_ran_ = true;', ''),
 ('bỏ khởi động nền khi đã bật cờ', 'UnetModule.hpp', 'if (warm_start_base_ && !is_base && !base_ran_) {', 'if (false) {'),
 ('khởi động nền MỌI lần', 'UnetModule.hpp', 'if (warm_start_base_ && !is_base && !base_ran_) {', 'if (warm_start_base_ && !is_base) {'),
 ('khởi động nền dù cờ tắt', 'UnetModule.hpp', 'if (warm_start_base_ && !is_base && !base_ran_) {', 'if (!is_base && !base_ran_) {'),
 ('load không ghi nhận cờ khởi động', 'UnetModule.hpp', '    warm_start_base_ = warm_start_base;\n', ''),
 ('release không đặt lại cờ khởi động', 'UnetModule.hpp', '    base_is_variant_ = false;\n    warm_start_base_ = false;\n  }', '    base_is_variant_ = false;\n  }'),
 ('khởi động nền không đánh dấu đã chạy', 'UnetModule.hpp', 'scratch.data(), err)) return false;\n      base_ran_ = true;', 'scratch.data(), err)) return false;'),
 ('đếm biến thể luôn cộng nền', 'UnetModule.hpp', 'base_is_variant_ ? 1 + loras_.size() : loras_.size()) : 0', '1 + loras_.size()) : 0'),
 ('ánh xạ chỉ số module sai', 'UnetModule.hpp', 'loras_[base_is_variant_ ? idx - 1 : idx]', 'loras_[idx > 0 ? idx - 1 : 0]'),
 ('nền luôn là biến thể', 'UnetModule.hpp', 'const bool is_base = base_is_variant_ && idx == 0;', 'const bool is_base = idx == 0;'),
 ('bỏ nhánh Regional', 'UnetModule.hpp', 'if (p.regional_fields) {', 'if (false) {'),
 ('không kiểm file LoRA tồn tại', 'UnetModule.hpp', 'if (!fileExists(p)) return fail(err, "thiếu file module LoRA " + p);', ''),
 ('độ dài chuỗi 77 -> 78', 'UnetModule.hpp', 'constexpr int kSeqLen = 77;', 'constexpr int kSeqLen = 78;'),
 ('bỏ trọng số w_i', 'UnetModule.hpp', 'p.weights ? *p.weights : kNoWeights', 'kNoWeights'),
 ('chép thiếu một nửa đầu ra', 'UnetModule.hpp', 'std::memcpy(out_b2, p, n_sample * sizeof(float));', 'std::memcpy(out_b2, p, (n_sample / 2) * sizeof(float));'),
 ('đuôi module .lora.mnn -> .mnn', 'LoraCompose.hpp', 'static const char kSuffix[] = ".lora.mnn";', 'static const char kSuffix[] = ".mnn";'),
 ('moduleMode coi Mixed là All', 'LoraCompose.hpp', 'return m == paths.size() ? ModuleMode::All : ModuleMode::Mixed;', 'return ModuleMode::All;'),
 ('đuôi đứng một mình cũng là module', 'LoraCompose.hpp', 'return p.size() > n && p.compare', 'return p.size() >= n && p.compare'),
 ('nạp nền bằng đường dẫn LoRA đầu', 'UnetModule.hpp', 'Module::load(in_names, out_names, base_path.c_str(), rt_, &mc)', 'Module::load(in_names, out_names, lora_paths[0].c_str(), rt_, &mc)'),
 ('không đóng RuntimeManager khi release', 'UnetModule.hpp', '    rt_.reset();\n    backend_config_.reset();', '    backend_config_.reset();'),
]

def build(inc_jni, out):
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-I', inc_jni, '-I', MOCK, '-o', out, SRC], capture_output=True, text=True)
    return r

def run(exe, d):
    return subprocess.run([exe, d], capture_output=True, text=True, timeout=60)

tmp = tempfile.mkdtemp(prefix='unet_module_')
try:
    exe = os.path.join(tmp, 'base_test')
    r = build(JNI, exe)
    if r.returncode != 0:
        print(r.stderr[-3000:]); print('FAIL: không biên dịch được'); sys.exit(1)
    r = run(exe, os.path.join(tmp, 'data'))
    out = r.stdout
    passed = out.count('PASS '); failed = out.count('FAIL ')
    print(f'phần kiểm chính: {passed} PASS, {failed} FAIL (rc={r.returncode})')
    if r.returncode != 0 or failed:
        print(out[-3000:]); sys.exit(1)
    lo, hi = 0, len(MUTS)
    if os.environ.get('MUT_RANGE'):
        a, b = os.environ['MUT_RANGE'].split(':'); lo, hi = int(a), int(b)
    caught = 0; survived = []
    for i in range(lo, min(hi, len(MUTS))):
        name, fn, old, new = MUTS[i]
        d = os.path.join(tmp, f'mut{i}'); shutil.copytree(os.path.join(JNI, 'sd_engine'), os.path.join(d, 'sd_engine'))
        p = os.path.join(d, 'sd_engine', fn); s = open(p, encoding='utf-8').read()
        if old not in s:
            print(f'FAIL: đột biến {i} ("{name}") không khớp mã nguồn — cập nhật test'); sys.exit(1)
        open(p, 'w', encoding='utf-8').write(s.replace(old, new, 1))
        mexe = os.path.join(d, 'mut_test'); b = build(d, mexe)
        if b.returncode != 0:
            print(f'  [{i}] KHÔNG BIÊN DỊCH ĐƯỢC: {name}'); survived.append((i, name + ' (không biên dịch)')); shutil.rmtree(d); continue
        try:
            m = run(mexe, os.path.join(d, 'data'))
            bad = (m.returncode != 0)
        except subprocess.TimeoutExpired:
            bad = True
        if bad: caught += 1
        else: survived.append((i, name))
        print(f'  [{i}] {"BỊ BẮT" if bad else "SỐNG SÓT"}: {name}')
        shutil.rmtree(d)
    n = min(hi, len(MUTS)) - lo
    print(f'đột biến: {caught}/{n} bị bắt')
    if survived:
        for i, nm in survived: print('SỐNG SÓT:', i, nm)
        sys.exit(1)
    print('ĐẠT')
finally:
    shutil.rmtree(tmp, ignore_errors=True)
