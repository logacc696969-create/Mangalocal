#!/usr/bin/env python3
# mục 279 — kiểm TĨNH: 4 màn cần truyện/chương đang mở (Gia đình, Bối cảnh, Bố cục trang, Hậu kỳ) không còn vẽ Text("...") trống trơn khi chưa có truyện/chương, mà dùng NoContextScreen
# (có nút Quay lại + Về danh sách truyện). Màn Nhân vật (mục 277) có bản riêng. Cảm giác thật trên máy CHƯA kiểm (cần máy; Compose chưa biên dịch ở môi trường này).
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
U = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/ui')
def rd(n): return open(os.path.join(U, n), encoding='utf-8').read()
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)
SCREENS = [('FamilyScreen.kt', 'story', 'truyện'), ('LocationsScreen.kt', 'story', 'truyện'), ('PageLayoutScreen.kt', 'chapter', 'chương'), ('PostProcessingScreen.kt', 'chapter', 'chương')]
def checks(src, comp):
    r = [('Components: NoContextScreen có nút Quay lại và Về danh sách truyện, mô tả lý do',
          'fun NoContextScreen(what: String, onBack: () -> Unit, onHome: () -> Unit)' in comp and 'MlOutlineBtn("← Quay lại", onClick = onBack)' in comp and 'MlOutlineBtn("Về danh sách truyện", onClick = onHome' in comp and 'Chưa mở $what nào' in comp)]
    for f, var, what in SCREENS:
        t = src[f]
        r.append((f'{f}: không còn Text("...") trống; dùng NoContextScreen("{what}") với lối ra', 'Text("...", color = C.T3)' not in t
                  and f'if ({var} == null) {{ NoContextScreen("{what}", onBack = {{ nav.popBackStack() }}, onHome = {{ nav.navigate("stories") {{ launchSingleTop = true }} }}); return }}' in t))
    return r
src = {f: rd(f) for f, _, _ in SCREENS}; comp = rd('Components.kt')
for n, ok in checks(src, comp): check(ok, n)
caught = 0; muts = []
for f, var, what in SCREENS:
    muts.append((f'{f} quay lại "..."', f, f'if ({var} == null) {{ NoContextScreen("{what}"', f'if ({var} == null) {{ Box(Modifier.fillMaxSize()) {{ Text("...", color = C.T3) }}; return }}; if (false) {{ NoContextScreen("{what}"'))
muts.append(('Components bỏ nút Về danh sách truyện', 'Components.kt', 'MlOutlineBtn("Về danh sách truyện", onClick = onHome', 'MlOutlineBtn("Về", onClick = onHome'))
muts.append(('NoContextScreen không còn Quay lại', 'Components.kt', 'MlOutlineBtn("← Quay lại", onClick = onBack)', ''))
for name, f, old, new in muts:
    s2 = dict(src); c2 = comp
    if f == 'Components.kt': assert old in comp, name; c2 = comp.replace(old, new, 1)
    else: assert old in src[f], name; s2[f] = src[f].replace(old, new, 1)
    bad = any(not ok for _, ok in checks(s2, c2)); caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name)
check(caught == len(muts), f'đột biến: {caught}/{len(muts)} bị bắt')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
