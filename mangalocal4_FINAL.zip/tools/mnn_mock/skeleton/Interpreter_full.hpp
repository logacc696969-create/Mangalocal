// mục 270 — KHUNG GIẢ (không phải mã thật): chỉ chữ ký mà PipelineSd15Cpu.hpp dùng, để biên dịch thử cú pháp/kiểu phần mã module LoRA khi không có MNN/xtensor.
#pragma once
#include <map>
#include <string>
#include <vector>
#define MNN_FORWARD_CPU 0
#define MNN_FORWARD_OPENCL 3
namespace MNN {
struct BackendConfig {
  enum MemoryMode { Memory_Normal = 0, Memory_High, Memory_Low };
  enum PowerMode { Power_Normal = 0, Power_High, Power_Low };
  enum PrecisionMode { Precision_Normal = 0, Precision_High, Precision_Low };
  MemoryMode memory = Memory_Normal; PowerMode power = Power_Normal; PrecisionMode precision = Precision_Normal;
};
struct ScheduleConfig { int type = 0; int numThread = 4; BackendConfig *backendConfig = nullptr; };
class Tensor {
 public:
  enum DimensionType { TENSORFLOW, CAFFE, CAFFE_C4 };
  Tensor(const Tensor *, DimensionType = CAFFE, bool = true) {}
  template <typename T> T *host() const { return nullptr; }
  bool copyFromHostTensor(const Tensor *) { return true; }
  bool copyToHostTensor(Tensor *) const { return true; }
};
class Session;
class Interpreter {
 public:
  static Interpreter *createFromFile(const char *) { return nullptr; }
  Session *createSession(const ScheduleConfig &) { return nullptr; }
  Tensor *getSessionInput(const Session *, const char *) { return nullptr; }
  Tensor *getSessionOutput(const Session *, const char *) { return nullptr; }
  void resizeTensor(Tensor *, const std::vector<int> &) {}
  void resizeSession(Session *) {}
  void updateCacheFile(Session *) {}
  void releaseModel() {}
  int runSession(Session *) const { return 0; }
  bool releaseSession(Session *) { return true; }
};
}  // namespace MNN
