// mục 270 — KHUNG GIẢ (không phải mã thật): chỉ chữ ký mà PipelineSd15Cpu.hpp dùng, để biên dịch thử cú pháp/kiểu phần mã module LoRA khi không có MNN/xtensor.
#pragma once
#include <MNN/Interpreter.hpp>
#include <string>
struct MnnSessionOptions { bool use_opencl=false, allow_npu=false, require_npu=false; std::string cache_file; int num_threads=4; };
inline std::string ensureCacheDir(const std::string &) { return ""; }
inline MNN::Interpreter *createMnnInterpreterMmap(const char *) { return nullptr; }
inline MNN::Session *createMnnSession(MNN::Interpreter *, const MnnSessionOptions &) { return nullptr; }
