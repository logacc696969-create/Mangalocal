#include "sd_engine/PipelineSd15Cpu.hpp"
int main() { TextEncoder te; PipelineSd15Cpu p(te, "", "", "", "", "", false); p.enableUnetModules(true); return 0; }
