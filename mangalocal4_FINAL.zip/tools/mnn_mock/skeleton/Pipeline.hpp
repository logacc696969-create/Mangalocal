// mục 270 — KHUNG GIẢ (không phải mã thật): chỉ chữ ký mà PipelineSd15Cpu.hpp dùng, để biên dịch thử cú pháp/kiểu phần mã module LoRA khi không có MNN/xtensor.
#pragma once
#include <cstring>
#include <string>
#include <vector>
#include <memory>
#include "Config.hpp"
struct ProcessedPromptPair { std::vector<float> negative_embeddings, positive_embeddings; };
struct TextEncoder { ProcessedPromptPair processPromptPair(const std::string&, const std::string&, int) { return {}; } };
struct GenerationRequest { std::string prompt, negative_prompt; int width = 512, height = 512; bool use_opencl=false, use_npu=false, require_npu=false; };
struct Conditioning {
  std::vector<float> hidden, pooled, time_ids; int hidden_dim = 0, pooled_dim = 0, seq_len = 77;
  float *negHidden() { return hidden.data(); }
  float *posHidden() { return hidden.data() + (size_t)seq_len * hidden_dim; }
};
class Pipeline {
 public:
  Pipeline(TextEncoder &te, const std::string &dir, bool sdxl, bool v) : text_encoder_(te), model_dir_(dir) {}
  virtual ~Pipeline() = default;
  virtual bool initialize() = 0;
  virtual bool supportsImg2Img() const = 0;
  virtual void encodeText(const ProcessedPromptPair &, bool, bool, Conditioning &) = 0;
  virtual void vaeEncode(const GenerationRequest &, const float *, float *, float *) = 0;
  virtual void vaeDecode(const GenerationRequest &, const float *, float *) = 0;
  virtual void beginDenoise(const GenerationRequest &) {}
  virtual void onConditioningReady(const GenerationRequest &) {}
  virtual void endDenoise() {}
  virtual void runUnetStep(const GenerationRequest &, const float *, float, bool, Conditioning &, float *) = 0;
  virtual bool canSkipUncond() const = 0;
  virtual bool previewSupported() const = 0;
  virtual void releaseTransientModels() {}
  virtual int textSeqLen() const { return 77; }
  virtual int textHiddenDim() const { return 768; }
  virtual int textPooledDim() const { return 0; }
 protected:
  TextEncoder &text_encoder_;
  std::string model_dir_;
};
