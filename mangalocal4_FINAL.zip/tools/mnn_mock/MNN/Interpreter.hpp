#pragma once
// mục 270 — BẢN GIẢ LẬP tối thiểu của MNN (KHÔNG phải MNN thật) để kiểm logic của UnetModule.hpp bằng g++ khi sandbox không có MNN.
// Chỉ khớp CHỮ KÝ những lời gọi mà UnetModule.hpp dùng; hành vi do tools/mnn_mock/MNN/expr/Expr.hpp tự định nghĩa.
#define MNN_FORWARD_CPU 0
namespace MNN {
struct BackendConfig {
  enum MemoryMode { Memory_Normal = 0, Memory_High, Memory_Low };
  enum PowerMode { Power_Normal = 0, Power_High, Power_Low };
  MemoryMode memory = Memory_Normal;
  PowerMode power = Power_Normal;
};
struct ScheduleConfig {
  int type = MNN_FORWARD_CPU;
  int numThread = 4;
  BackendConfig *backendConfig = nullptr;
};
}  // namespace MNN
