#pragma once
// mục 270 — BẢN GIẢ LẬP MNN Express (xem Interpreter.hpp cùng thư mục). Mô hình đồ chơi: file model là TEXT.
//   "unet <scale> <bias>"  : out = sample*scale + bias + 0.001*timestep + 0.0001*mean(enc)
//   "lora <delta>"         : module LoRA đã gắn nhánh, TRỌNG SỐ NỀN BỊ BỎ (stripped): chỉ đúng nếu config.base != null VÀ rearrange == true
//                            (khi đó = đầu ra nền + delta*sample); ngược lại ra GIÁ TRỊ RÁC 777 (mô phỏng cái bẫy ở 264.2).
// Mọi lời gọi được ghi vào mock::g.events để test kiểm thứ tự/cờ; mock::g.violation bật khi nền bị huỷ trước module LoRA phụ thuộc nó.
#include <MNN/Interpreter.hpp>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <memory>
#include <set>
#include <sstream>
#include <string>
#include <vector>

struct halide_type_t { int code; int bits; };
template <typename T> halide_type_t halide_type_of();
template <> inline halide_type_t halide_type_of<float>() { return {2, 32}; }
template <> inline halide_type_t halide_type_of<int>() { return {0, 32}; }

namespace mock {
struct State {
  std::vector<std::string> events;
  int load_calls = 0;
  int fail_load_nth = 0;       // 1-based: Module::load lần thứ n trả nullptr
  bool fail_rt = false;
  bool wrong_out_size = false; // đầu ra nhỏ hơn cần
  bool null_out = false;       // onForward trả vector rỗng
  bool violation = false;      // nền bị huỷ khi còn module LoRA phụ thuộc, hoặc LoRA huỷ khi nền đã mất
  int live_modules = 0;
  int live_rt = 0;
  int last_threads = -1;
  int last_memory = -1, last_power = -1;
  std::set<const void *> live;
  void reset() { *this = State(); }
};
inline State g;
}  // namespace mock

namespace MNN {
namespace Express {
enum Dimensionformat { NHWC, NC4HW4, NCHW };

class Variable {
 public:
  struct Info { std::vector<int> dim; int size = 0; int code = 0; };
  template <typename T> T *writeMap() { return reinterpret_cast<T *>(data.data()); }
  template <typename T> const T *readMap() { return reinterpret_cast<const T *>(data.data()); }
  const Info *getInfo() const { return &info; }
  std::vector<unsigned char> data;
  Info info;
};

class VARP {
 public:
  VARP() {}
  VARP(std::shared_ptr<Variable> v) : c_(std::move(v)) {}
  Variable *get() const { return c_.get(); }
  Variable *operator->() const { return c_.get(); }
 private:
  std::shared_ptr<Variable> c_;
};

inline VARP _Input(std::vector<int> shape, Dimensionformat, halide_type_t t) {
  auto v = std::make_shared<Variable>();
  int n = 1; for (int d : shape) n *= d;
  v->info.dim = shape; v->info.size = n; v->info.code = t.code;
  v->data.assign((size_t)n * 4, 0);
  return VARP(v);
}
inline VARP _Convert(VARP x, Dimensionformat) { return x; }

class Executor {
 public:
  class RuntimeManager {
   public:
    static RuntimeManager *createRuntimeManager(const MNN::ScheduleConfig &sc) {
      if (mock::g.fail_rt) return nullptr;
      auto *r = new RuntimeManager();
      mock::g.live_rt++;
      mock::g.last_threads = sc.numThread;
      if (sc.backendConfig) { mock::g.last_memory = (int)sc.backendConfig->memory; mock::g.last_power = (int)sc.backendConfig->power; }
      else { mock::g.last_memory = -99; mock::g.last_power = -99; }
      mock::g.events.push_back("rt type=" + std::to_string(sc.type));
      return r;
    }
    ~RuntimeManager() { mock::g.live_rt--; }
  };
};

class Module {
 public:
  struct Config {
    bool dynamic = false;
    bool shapeMutable = true;
    bool rearrange = false;
    const Module *base = nullptr;
  };
  static Module *load(const std::vector<std::string> &in, const std::vector<std::string> &out, const char *file,
                      std::shared_ptr<Executor::RuntimeManager> rt, const Config *cfg) {
    mock::g.load_calls++;
    std::string names;
    for (auto &s : in) names += s + ",";
    names += "->";
    for (auto &s : out) names += s + ",";
    mock::g.events.push_back(std::string("load ") + file + " names=" + names + " base=" + (cfg && cfg->base ? "1" : "0") +
                             " rearrange=" + (cfg && cfg->rearrange ? "1" : "0") + " shapeMutable=" + (cfg && cfg->shapeMutable ? "1" : "0") +
                             " rt=" + (rt ? "1" : "0"));
    if (mock::g.fail_load_nth == mock::g.load_calls) return nullptr;
    std::ifstream f(file);
    std::string kind; f >> kind;
    auto *m = new Module();
    mock::g.live_modules++;
    mock::g.live.insert(m);
    if (kind == "unet") { m->is_lora = false; f >> m->scale >> m->bias; }
    else if (kind == "lora") { m->is_lora = true; f >> m->delta; }
    else { delete m; return nullptr; }
    m->file = file;
    if (cfg) { m->base = cfg->base; m->rearrange = cfg->rearrange; }
    if (m->is_lora && m->base) const_cast<Module *>(m->base)->dependents++;
    return m;
  }
  ~Module() {
    mock::g.events.push_back("destroy " + file);
    if (dependents > 0) mock::g.violation = true;
    if (is_lora && base) {
      if (!mock::g.live.count(base)) mock::g.violation = true;
      else const_cast<Module *>(base)->dependents--;
    }
    mock::g.live.erase(this);
    mock::g.live_modules--;
  }
  std::vector<VARP> onForward(const std::vector<VARP> &in) {
    mock::g.events.push_back("forward " + file);
    if (in.size() == 3) {
      std::string d = "dims=";
      for (size_t i = 0; i < in[0]->info.dim.size(); ++i) d += (i ? "," : "") + std::to_string(in[0]->info.dim[i]);
      mock::g.events.push_back(d);
    }
    if (mock::g.null_out) return {};
    if (in.size() != 3) { mock::g.events.push_back("BAD_INPUT_COUNT"); return {}; }
    if (in[1]->info.code != 0) mock::g.events.push_back("BAD_TS_TYPE");     // timestep phải là int
    if (in[0]->info.code != 2 || in[2]->info.code != 2) mock::g.events.push_back("BAD_FLOAT_TYPE");
    if (in[0]->info.dim.size() != 4 || in[0]->info.dim[0] != 2 || in[0]->info.dim[1] != 4) mock::g.events.push_back("BAD_SAMPLE_DIMS");
    if (in[2]->info.dim.size() != 3 || in[2]->info.dim[0] != 2 || in[2]->info.dim[1] != 77) mock::g.events.push_back("BAD_ENC_DIMS");
    const float *s = reinterpret_cast<const float *>(in[0]->data.data());
    const int ts = *reinterpret_cast<const int *>(in[1]->data.data());
    const float *e = reinterpret_cast<const float *>(in[2]->data.data());
    int ns = in[0]->info.size, ne = in[2]->info.size;
    double me = 0; for (int i = 0; i < ne; ++i) me += e[i]; me /= (ne ? ne : 1);
    int no = mock::g.wrong_out_size ? ns / 2 : ns;
    auto v = std::make_shared<Variable>();
    v->info.dim = {2, 4, 1, no / 8 ? no / 8 : 1}; v->info.size = no; v->info.code = 2;
    v->data.assign((size_t)no * 4, 0);
    float *o = reinterpret_cast<float *>(v->data.data());
    for (int i = 0; i < no; ++i) {
      if (!is_lora) o[i] = s[i] * scale + bias + 0.001f * ts + 0.0001f * (float)me;
      else if (!base || !rearrange) o[i] = 777.0f;  // trọng số nền bị bỏ mà không chia sẻ -> rác (264.2)
      else o[i] = s[i] * base->scale + base->bias + 0.001f * ts + 0.0001f * (float)me + delta * s[i];
    }
    return {VARP(v)};
  }
  std::string file;
  bool is_lora = false, rearrange = false;
  float scale = 0, bias = 0, delta = 0;
  const Module *base = nullptr;
  int dependents = 0;
};
}  // namespace Express
}  // namespace MNN
