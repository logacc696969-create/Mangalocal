#!/usr/bin/env python3
"""mục 286 — kiểm app/src/main/jni/jni_progress.hpp (callback tiến trình JNI) trên JVM THẬT (OpenJDK), có phá mã.
Mẫu CŨ (14 chỗ): AttachCurrentThread → GetObjectClass → CallVoidMethod → DetachCurrentThread MỖI step, trong lambda được Pipeline::generate gọi ĐỒNG BỘ trên luồng gọi JNI (luồng Java).
  - ART: DetachCurrentThread trên luồng đang có khung Java ⇒ LOG(FATAL) "attempting to detach while still running code" (Runtime::DetachCurrentThread, runtime/runtime.cc) — app abort.
  - HotSpot (JVM dùng ở đây) KHÔNG abort mà trả JNI_ERR; nên "không sập trên JDK" KHÔNG chứng minh gì cho Android. Cái đo được ở đây: số lần Detach bị JVM TỪ CHỐI, rò tham chiếu cục bộ, exception treo.
Cách đo: chèn PROXY vào JavaVM (tools/jni_probe/jni_progress_probe.cpp) đếm Attach/Detach/GetEnv thật + kết quả thật của JVM; chạy java -Xcheck:jni và đếm cảnh báo.
Cần: g++, JDK (javac, java, jni.h — apt openjdk-21-jdk-headless). Thiếu → BỎ QUA (exit 0). Dùng: python3 tools/test_jni_progress.py [--mut]
"""
import glob, os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); JNI = os.path.join(ROOT, 'app/src/main/jni'); PROBE = os.path.join(ROOT, 'tools/jni_probe')
HELPER = os.path.join(JNI, 'jni_progress.hpp')
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)

# ───── (A) kiểm tĩnh nguồn: mẫu cũ không còn, mọi chỗ gọi đều qua helper ─────
def code_lines(s): return [l for l in s.split('\n') if not l.strip().startswith('//')]
src = {f: open(f, encoding='utf-8').read() for f in glob.glob(os.path.join(JNI, '*.cpp')) + glob.glob(os.path.join(JNI, 'sd_engine', '*.hpp'))}
raw = [os.path.basename(f) for f, s in src.items() if re.search(r'AttachCurrentThread|DetachCurrentThread', '\n'.join(code_lines(s)))]
check(not raw, f'không còn Attach/DetachCurrentThread ở ngoài jni_progress.hpp (mọi callback đi qua helper): {raw}')
users = [os.path.basename(f) for f, s in src.items() if 'jniCallProgress(' in s]
n_calls = sum(s.count('mangalocal::jniCallProgress(jvm, cbGlobal, step, total);') for s in src.values())
check(n_calls == 14, f'14 lời gọi helper (đã thay đủ 14 khối cũ): {n_calls}')
check(all('#include "jni_progress.hpp"' in src[os.path.join(JNI, u)] for u in users if os.path.join(JNI, u) in src), f'mọi tệp dùng helper đều #include "jni_progress.hpp" ({len(users)} tệp)')
check(not [u for u in users if u.endswith('.hpp') and u != 'jni_progress.hpp'], 'helper chỉ dùng trong .cpp')

jdk = [os.path.dirname(os.path.dirname(os.path.realpath(p))) for p in [shutil.which('javac') or ''] if p]
if not (shutil.which('g++') and jdk and os.path.isfile(os.path.join(jdk[0], 'include', 'jni.h')) and shutil.which('java')):
    print('BỎ QUA phần chạy JVM: cần g++, javac, java, jni.h (apt openjdk-21-jdk-headless)'); print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
JH = jdk[0]; tmp = tempfile.mkdtemp()
LOADER = 'public class Loader { static { System.loadLibrary("probe"); } public static void main(String[] a) throws Exception { Probe.main(a); } }\n'
open(os.path.join(tmp, 'Loader.java'), 'w').write(LOADER)
r = subprocess.run(['javac', '-d', tmp, os.path.join(PROBE, 'Probe.java'), os.path.join(tmp, 'Loader.java')], capture_output=True, text=True)
check(r.returncode == 0, 'javac Probe + Loader' + ('' if r.returncode == 0 else r.stderr[-300:]))

def build(helper_path, tag):
    d = os.path.join(tmp, tag); os.makedirs(d, exist_ok=True)
    shutil.copy(helper_path, os.path.join(d, 'jni_progress.hpp'))     # thư mục riêng: #include "jni_progress.hpp" lấy bản này (bản đột biến) chứ không phải bản thật
    so = os.path.join(d, 'libprobe.so')
    r = subprocess.run(['g++', '-std=c++17', '-O1', '-shared', '-fPIC', '-I' + os.path.join(JH, 'include'), '-I' + os.path.join(JH, 'include', 'linux'), '-I' + d, os.path.join(PROBE, 'jni_progress_probe.cpp'), '-o', so, '-lpthread'], capture_output=True, text=True)
    return (d if r.returncode == 0 else None), r.stderr[-500:]
def run(d, mode, steps, thr=False):
    try:
        p = subprocess.run(['java', '-Xcheck:jni', f'-Djava.library.path={d}', '-cp', tmp, 'Loader', mode, str(steps)] + (['throw'] if thr else []), capture_output=True, text=True, timeout=25)
    except subprocess.TimeoutExpired:
        return None   # treo (ví dụ luồng native còn gắn vào JVM nên JVM không thoát được) = kịch bản KHÔNG chạy được = lỗi
    out = p.stdout + p.stderr; m = re.search(r'RESULT mode=(\w+) rc=(-?\d+) delivered=(\d+) thrown=(\d+) attach=(\d+) detach=(\d+) detachFailed=(\d+) getenv=(\d+) drift=(\d+) escaped=(\w*)', out)
    if not m: return None
    k = ['mode', 'rc', 'delivered', 'thrown', 'attach', 'detach', 'detachFailed', 'getenv', 'drift', 'escaped']; d2 = dict(zip(k, m.groups()))
    for x in k[1:-1]: d2[x] = int(d2[x])
    d2['warn_cap'] = len(re.findall(r'exceeds capacity', out)); d2['warn_exc'] = len(re.findall(r'exception pending|without checking exceptions', out)); d2['warn_any'] = len(re.findall(r'WARNING', out)); d2['rc_proc'] = p.returncode
    return d2
STEPS = 40
def scenarios(d):
    return dict(old=run(d, 'old', STEPS), new=run(d, 'new', STEPS), native=run(d, 'native', STEPS), old_thr=run(d, 'old', 10, True), new_thr=run(d, 'new', 10, True))

def evaluate(S, tag=''):
    ok = []
    o, n, t, ot, nt = S['old'], S['new'], S['native'], S['old_thr'], S['new_thr']
    if None in (o, n, t, ot, nt): return [('chạy được cả 5 kịch bản', False)]
    ok.append((f'{tag}luồng Java: giao đủ {STEPS} callback, KHÔNG Attach, KHÔNG Detach (JVM không phải từ chối lần nào)', n['delivered'] == STEPS and n['attach'] == 0 and n['detach'] == 0 and n['detachFailed'] == 0))
    ok.append((f'{tag}luồng Java: KHÔNG rò tham chiếu cục bộ sau {STEPS} step (tham chiếu tạo sau vòng lặp nằm sát tham chiếu tạo trước: lệch {n["drift"]} byte ≤ 64)', n['drift'] <= 64))
    ok.append((f'{tag}luồng Java: không cảnh báo -Xcheck:jni nào (không rò tham chiếu cục bộ, không exception treo)', n['warn_any'] == 0))
    ok.append((f'{tag}luồng native thuần: giao đủ {STEPS} callback, Attach = Detach = {STEPS}, Detach thành công', t['delivered'] == STEPS and t['attach'] == STEPS and t['detach'] == STEPS and t['detachFailed'] == 0 and t['warn_any'] == 0))
    ok.append((f'{tag}callback ném RuntimeException ở step 3: helper nuốt, vẫn giao đủ 10 step, không để exception thoát ra, không cảnh báo', nt['delivered'] == 10 and nt['thrown'] == 1 and nt['escaped'] == '' and nt['rc'] == 0 and nt['warn_any'] == 0))
    return ok

# ───── (B) mã THẬT ─────
d, e = build(HELPER, 'real'); check(d is not None, 'biên dịch jni_progress.hpp THẬT + probe với jni.h của JDK (kiểm tra cả overload attachThread cho void**)' + ('' if d else '\n' + e))
if d:
    S = scenarios(d)
    for name, ok in evaluate(S): check(ok, name)
    # đối chứng: mẫu CŨ phải BỊ phát hiện bởi cùng phép đo (nếu không, phép đo vô nghĩa)
    o, ot = S['old'], S['old_thr']
    print(f'  [số đo] mẫu CŨ trên luồng Java ({STEPS} step): Attach {o["attach"]}, Detach {o["detach"]}, Detach bị JVM TỪ CHỐI {o["detachFailed"]}; cảnh báo -Xcheck:jni: {o["warn_any"]}; độ lệch tham chiếu cục bộ {o["drift"]} byte')
    print(f'  [số đo] mẫu MỚI trên luồng Java: Attach {S["new"]["attach"]}, Detach {S["new"]["detach"]}, GetEnv {S["new"]["getenv"]}; trên luồng native: Attach {S["native"]["attach"]}, Detach {S["native"]["detach"]}')
    check(o['detachFailed'] == STEPS and o['delivered'] == STEPS, f'ĐỐI CHỨNG: mẫu cũ trên luồng Java gọi Detach {STEPS}/{STEPS} lần và JVM từ chối cả {o["detachFailed"]} (JNI_ERR) — trên ART đó là LOG(FATAL) abort')
    check(o['drift'] > 64, f'ĐỐI CHỨNG: phép đo rò thấy mẫu cũ rò {STEPS} tham chiếu cục bộ (lệch {o["drift"]} byte > 64; mẫu mới lệch {S["new"]["drift"]})')
    check(o['warn_any'] > 0 and ot['escaped'] == 'RuntimeException', f'ĐỐI CHỨNG: phép đo -Xcheck:jni bắt được mẫu cũ ({o["warn_any"]} cảnh báo; exception của callback thoát ra ngoài: {ot["escaped"] or "không"})')

# ───── (C) phá mã helper ─────
MUTS = [
 ('luôn Detach (kể cả luồng Java)', 'if (attachedHere) jvm->DetachCurrentThread();', 'jvm->DetachCurrentThread();'),
 ('không bao giờ Detach luồng đã Attach', 'if (attachedHere) jvm->DetachCurrentThread();', ''),
 ('luôn Attach, bỏ GetEnv', 'const jint st = jvm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);', 'const jint st = JNI_EDETACHED;'),
 ('bỏ local frame (rò tham chiếu cục bộ)', 'if (env->PushLocalFrame(8) == 0) {', '{'),
 ('không xoá exception của callback (cả hai chỗ)', 'env->ExceptionClear();', ''),
 ('coi JNI_EDETACHED là lỗi (luồng native không bao giờ giao được)', 'if (st == JNI_EDETACHED) {', 'if (false) {'),
]
if '--mut' in sys.argv:
    text = open(HELPER, encoding='utf-8').read(); caught = 0
    for i, (name, old, new) in enumerate(MUTS):
        assert text.count(old) >= 1 and (text.count(old) == 1 or 'cả hai chỗ' in name), f'mẫu đột biến không hợp lệ: {name} ({text.count(old)})'
        mp = os.path.join(tmp, f'helper_m{i}.hpp'); open(mp, 'w', encoding='utf-8').write(text.replace(old, new) if 'cả hai chỗ' in name else text.replace(old, new, 1))
        # lưu ý: PopLocalFrame còn lại khi bỏ PushLocalFrame là không cân bằng — đúng ý đồ của đột biến "bỏ local frame" nên cũng bỏ nốt PopLocalFrame
        if 'PushLocalFrame' in old: open(mp, 'w', encoding='utf-8').write(text.replace(old, new, 1).replace('env->PopLocalFrame(nullptr);', ''))
        dd, ee = build(mp, f'm{i}')
        if dd is None: caught += 1; print('  BỊ BẮT (không biên dịch): ' + name); continue
        bad = [n for n, ok in evaluate(scenarios(dd)) if not ok]
        caught += bool(bad); print(('  BỊ BẮT' if bad else '  SỐNG SÓT') + ': ' + name, flush=True)
    check(caught == len(MUTS), f'phá mã helper: {caught}/{len(MUTS)} đột biến bị bắt')
else: print(f'(bỏ qua đột biến — chạy với --mut; có {len(MUTS)})')
shutil.rmtree(tmp, ignore_errors=True)
print('\nĐẠT' if not fails else '\nTHẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
