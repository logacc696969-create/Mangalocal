#!/usr/bin/env python3
"""mục 261 — kiểm thử `pipeline/LoraComposePlan.kt` (chọn Switch/Composite cho panel) bằng kotlinc THẬT + nối dây LoRA compose / OccCFG / mask tiếp xúc.

Phần 1 (chạy Kotlin thật trên JVM): bảng ca đúng/sai của `LoraComposePlan.choose` đối chiếu với bản tham chiếu Python viết độc lập từ quy tắc:
  bật cờ; đúng >=2 nhân vật; mọi nhân vật có LoRA + unet.mnn tồn tại + đường dẫn không rỗng; không trùng id; <= 4 UNet; tau làm tròn kẹp [1,10] (NaN -> 5);
  UNet chính = nhân vật ĐẦU (bài Multi-LoRA Composition: LoRA nhân vật đầu bật trước); activeCount = 1 (Switch) hoặc k (Composite).
Phần 2 (tĩnh, trên mã Kotlin thật): armOccCfg ở đủ 10 hàm sinh gốc; clearOccCfg trong finally của generatePanels + regeneratePanel; compose chỉ ở nhánh thường;
  cờ MẶC ĐỊNH TẮT; mask liên tục chỉ khi bật cả DD; JNI/Kotlin external khớp.
KHÔNG chứng minh: chạy được trên máy thật, ảnh đẹp hơn. Cần kotlinc (KOTLINC=...) — không có thì phần 1 được BỎ QUA (in SKIP).
"""
import os, re, shutil, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
ok = True
def check(name, cond, detail=''):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name + ((' :: ' + detail) if (detail and not cond) else ''))
    ok &= bool(cond)

def find_kotlinc():
    for c in [os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/work/kotlinc/bin/kotlinc']:
        if c and os.path.exists(c): return c
    return None

# ---------------- phần 1: Kotlin thật ----------------
CASES = [  # (enabled, composite, tau, [(id, hasLora, path, exists)], expected)
    (True, False, 5.0, [('a', True, '/m/a/unet.mnn', True), ('b', True, '/m/b/unet.mnn', True)], 2),
    (True, True, 5.0, [('a', True, '/m/a/unet.mnn', True), ('b', True, '/m/b/unet.mnn', True), ('c', True, '/m/c/unet.mnn', True)], 3),
    (False, False, 5.0, [('a', True, '/a', True), ('b', True, '/b', True)], 2),
    (True, False, 5.0, [('a', True, '/a', True)], 1),
    (True, False, 5.0, [('a', True, '/a', True), ('b', True, '/b', True)], 3),
    (True, False, 5.0, [('a', True, '/a', True), ('b', False, '/b', True)], 2),
    (True, False, 5.0, [('a', True, '/a', True), ('b', True, '/b', False)], 2),
    (True, False, 5.0, [('a', True, '/a', True), ('b', True, '', True)], 2),
    (True, False, 5.0, [('a', True, '/a', True), ('a', True, '/a2', True)], 2),
    (True, False, 5.0, [(x, True, '/' + x, True) for x in 'abcde'], 5),
    (True, False, 5.0, [(x, True, '/' + x, True) for x in 'abcd'], 4),
    (True, False, 0.2, [('a', True, '/a', True), ('b', True, '/b', True)], 2),
    (True, False, 99.0, [('a', True, '/a', True), ('b', True, '/b', True)], 2),
    (True, False, float('nan'), [('a', True, '/a', True), ('b', True, '/b', True)], 2),
    (True, False, 3.6, [('a', True, '/a', True), ('b', True, '/b', True)], 2),
    (True, True, 7.0, [('z', True, '/z', True), ('y', True, '/y', True)], 2),
]
_C2 = [('a', True, '/m/a/unet.mnn', True), ('b', True, '/m/b/unet.mnn', True)]
_C3 = _C2 + [('c', True, '/m/c/unet.mnn', True)]
CASES = [c + (False,) for c in CASES] + [
    (True, False, 5.0, _C2, 2, True),   # regional, cờ Composite tắt
    (True, True, 5.0, _C3, 3, True),    # regional + Composite
    (False, False, 5.0, _C2, 2, True),  # cờ tổng tắt -> null dù regional
    (True, False, 5.0, _C2[:1], 1, True),  # 1 nhân vật -> null dù regional
]
_K = lambda i, clip, ex=True: (i, True, f'/m/{i}/unet.mnn', True, clip, ex)
CASES = [c if len(c) == 7 else c + (False,) for c in CASES] + [
    (True, False, 5.0, [_K('a', '/m/a/clip.mnn'), _K('b', '/m/b/clip.mnn')], 2, False, True),                  # CLIP riêng cho biến thể phụ b
    (True, False, 5.0, [_K('a', '/m/a/clip.mnn'), _K('b', '/m/b/clip.mnn'), _K('c', None, False)], 3, False, True),  # c thiếu clip -> ""
    (True, False, 5.0, [_K('a', None, False), _K('b', None, False)], 2, False, True),                          # không ai có clip -> rỗng
    (True, False, 5.0, [_K('a', '/m/a/clip.mnn'), _K('b', '/m/b/clip.mnn')], 2, False, False),                 # tắt cờ -> rỗng
    (True, False, 5.0, [_K('a', '/m/a/clip.mnn'), _K('b', '/m/b/clip.mnn', False)], 2, False, True),           # clip không tồn tại -> rỗng
    (True, False, 5.0, [_K('a', '/m/a/clip.mnn'), _K('b', '  ')], 2, False, True),                            # đường dẫn trắng -> rỗng
    (True, True, 5.0, [_K('a', '/m/a/clip.mnn'), _K('b', '/m/b/clip.mnn')], 2, True, True),                    # regional + CLIP riêng: giữ qua withMasks
]
_S = lambda i, cs: (i, True, f'/m/{i}/unet.mnn', True, None, False, cs)   # mục 263: clip_skip2 lúc convert (None = không biết)
CASES += [
    (True, False, 5.0, [_S('a', True), _S('b', True)], 2, False, False),                 # cùng clip_skip -> OK
    (True, False, 5.0, [_S('a', True), _S('b', False)], 2, False, False),                # lệch -> null
    (True, False, 5.0, [_S('a', None), _S('b', True)], 2, False, False),                 # một bên không biết -> vẫn OK
    (True, False, 5.0, [_S('a', True), _S('b', None), _S('c', False)], 3, False, False), # có người không biết nhưng hai người ĐÃ BIẾT lệch -> null
    (True, False, 5.0, [_S('a', False), _S('b', False), _S('c', False)], 3, False, False),
    (True, False, 5.0, [_S('a', None), _S('b', None)], 2, False, False),                 # không ai biết -> OK (không suy đoán)
]
def ref(enabled, composite, tau, chars, expected, regional=False, ownclip=False):
    if not enabled or expected < 2 or len(chars) != expected or len(chars) > 4: return None
    if len({c[0] for c in chars}) != len(chars): return None
    for c in chars:
        if not c[1] or not c[3] or not c[2].strip(): return None
    t = 5.0 if tau != tau else tau
    t = int(min(10, max(1, round(t + 1e-9)))) if t == t else 5
    # Kotlin roundToInt: làm tròn nửa lên (3.5 -> 4) = floor(x+0.5)
    import math
    t = int(min(10, max(1, math.floor((5.0 if tau != tau else tau) + 0.5))))
    known = {c[6] for c in chars if len(c) == 7 and c[6] is not None}
    if len(known) > 1: return None   # mục 263: clip_skip lệch giữa các nhân vật ĐÃ BIẾT
    k = len(chars); base = k if composite else 1
    act = k if (composite or regional) else 1
    clips = [(c[4] if (len(c) >= 6 and c[5] and c[4] and c[4].strip()) else '') for c in chars[1:]] if ownclip else []
    if not any(clips): clips = []
    return (chars[0][0], [c[2] for c in chars[1:]], act, t, regional, base, clips)

def kt_bool(b): return 'true' if b else 'false'
def kt_str(s): return '"' + s + '"'
def kt_float(f): return 'Float.NaN' if f != f else f'{f}f'
DRV_HEAD = 'import com.mangalocal.pipeline.LoraComposePlan\nfun main() {\n'
def driver():
    body = ''
    for enabled, composite, tau, chars, expected, regional, ownclip in CASES:
        def _cm(c):
            i, h, p, e = c[:4]
            base = f'{kt_str(i)}, {kt_bool(h)}, {kt_str(p) if p is not None else "null"}, {kt_bool(e)}'
            if len(c) >= 6: base += f', {kt_str(c[4]) if c[4] is not None else "null"}, {kt_bool(c[5])}'
            if len(c) == 7: base += f', {"null" if c[6] is None else kt_bool(c[6])}'
            return f'LoraComposePlan.CharModel({base})'
        cm = ', '.join(_cm(c) for c in chars)
        body += f'    run {{ val r = LoraComposePlan.choose({kt_bool(enabled)}, {kt_bool(composite)}, {kt_float(tau)}, listOf({cm}), {expected}, {kt_bool(regional)}, {kt_bool(ownclip)}); ' \
                f'println(if (r == null) "NULL" else {{ val n0 = r.withMasks(null); val m1 = r.withMasks(com.mangalocal.pipeline.ContactMap.RegionMasks(FloatArray(2), 2, 1, 1)); ' \
                f'"OK " + r.primaryModelId + " | " + r.extraUnetPaths.joinToString(",") + " | " + r.activeCount + " | " + r.tau + " | " + r.regional + " | " + n0.activeCount + "," + n0.regional + "," + (n0.masks == null) + " | " + m1.activeCount + "," + m1.regional + "," + (m1.masks != null) + " | " + r.extraClipPaths.size + ":" + r.extraClipPaths.joinToString(",") + " | " + (n0.extraClipPaths == r.extraClipPaths && m1.extraClipPaths == r.extraClipPaths) }}) }}\n'
    return DRV_HEAD + body + '}\n'

def run_suite(src_path, tmp, tag):
    os.makedirs(os.path.join(tmp, tag), exist_ok=True)
    drv = os.path.join(tmp, tag, 'Drv.kt'); open(drv, 'w').write(driver())
    jar = os.path.join(tmp, f'{tag}.jar')
    r = subprocess.run([KOTLINC, src_path, os.path.join(KT, 'pipeline/ContactMap.kt'), drv, '-d', jar], capture_output=True, text=True)
    if r.returncode != 0: return None, 'compile: ' + r.stderr[-600:]
    klib = os.path.join(os.path.dirname(os.path.dirname(KOTLINC)), 'lib', 'kotlin-stdlib.jar')
    o = subprocess.run(['java', '-cp', f'{jar}:{klib}', 'DrvKt'], capture_output=True, text=True)
    if o.returncode != 0: return None, 'run: ' + o.stderr[-400:]
    return o.stdout.strip().split('\n'), ''

def matches(lines):
    bad = 0
    if lines is None or len(lines) != len(CASES): return len(CASES)
    for line, case in zip(lines, CASES):
        exp = ref(*case)
        if exp is None:
            if line != 'NULL': bad += 1
        else:
            reg_after_masks = exp[4]
            want = (f'OK {exp[0]} | {",".join(exp[1])} | {exp[2]} | {exp[3]} | {str(exp[4]).lower()} | '
                    f'{exp[5]},false,true | {exp[2]},{str(reg_after_masks).lower()},{str(reg_after_masks).lower()} | {len(exp[6])}:{",".join(exp[6])} | true')
            if line != want: bad += 1
    return bad

KOTLINC = find_kotlinc()
SRC = os.path.join(KT, 'pipeline/LoraComposePlan.kt')
if not KOTLINC:
    print('SKIP phần 1: không có kotlinc (đặt KOTLINC=...)')
else:
    tmp = tempfile.mkdtemp()
    lines, err = run_suite(SRC, tmp, 'real')
    check('LoraComposePlan.kt biên dịch + chạy bằng kotlinc thật', lines is not None, err)
    if lines is not None:
        check(f'{len(CASES)} ca khớp tham chiếu Python (null/không-null, UNet chính, danh sách phụ, activeCount, tau)', matches(lines) == 0, str(list(zip(lines, CASES))[:3]))
        src = open(SRC, encoding='utf-8').read()
        mutants = [
            ('bỏ kiểm LoRA', 'if (!c.hasLora || !c.unetExists || c.unetPath.isNullOrBlank()) return null', 'if (!c.unetExists || c.unetPath.isNullOrBlank()) return null'),
            ('bỏ kiểm unet tồn tại', 'if (!c.hasLora || !c.unetExists ||', 'if (!c.hasLora ||'),
            ('bỏ kiểm trùng id', 'if (chars.map { it.characterId }.toSet().size != chars.size) return null', ''),
            ('bỏ giới hạn 4 UNet', 'if (chars.size > MAX_VARIANTS) return null', ''),
            ('UNet chính là nhân vật cuối', 'primaryModelId = chars[0].characterId', 'primaryModelId = chars.last().characterId'),
            ('Composite sai activeCount', 'activeCount = if (composite || regional) k else 1,', 'activeCount = if (composite || regional) 1 else k,'),
            ('tau không kẹp', '.roundToInt().coerceIn(MIN_TAU, MAX_TAU)', '.roundToInt()'),
            ('tau NaN không về 5', '(if (tauRaw.isFinite()) tauRaw else 5f)', 'tauRaw'),
            ('bỏ kiểm số nhân vật khớp', 'if (expectedCount < 2 || chars.size != expectedCount) return null', 'if (expectedCount < 2) return null'),
            ('cờ tắt vẫn chạy', 'if (!enabled) return null', ''),
            ('regional không kéo activeCount lên k', 'activeCount = if (composite || regional) k else 1,', 'activeCount = if (composite) k else 1,'),
            ('thiếu mask vẫn giữ regional', 'if (regional && m != null) Choice(primaryModelId, extraUnetPaths, activeCount, tau, true, m, fallbackActiveCount, extraClipPaths)', 'if (regional) Choice(primaryModelId, extraUnetPaths, activeCount, tau, true, m, fallbackActiveCount, extraClipPaths)'),
            ('thiếu mask không quay về activeCount theo cờ', 'else Choice(primaryModelId, extraUnetPaths, fallbackActiveCount, tau, false, null, fallbackActiveCount, extraClipPaths)', 'else Choice(primaryModelId, extraUnetPaths, activeCount, tau, false, null, fallbackActiveCount, extraClipPaths)'),
            ('fallbackActiveCount bỏ cờ Composite', 'fallbackActiveCount = if (composite) k else 1', 'fallbackActiveCount = 1'),
            ('CLIP riêng bỏ qua cờ ownClip', 'if (!ownClip) return emptyList()', ''),
            ('CLIP riêng gồm cả nhân vật chính', 'val out = chars.drop(1).map { c ->', 'val out = chars.map { c ->'),
            ('CLIP riêng không lọc trắng/không tồn tại', 'if (c.clipExists && !c.clipPath.isNullOrBlank()) c.clipPath else ""', 'c.clipPath ?: ""'),
            ('CLIP riêng trả danh sách toàn rỗng', 'return if (out.any { it.isNotEmpty() }) out else emptyList()', 'return out'),
            ('clip_skip lệch vẫn cho qua', 'if (clipSkipStatus(chars) == ClipSkipStatus.MISMATCH) return null  // mục 263', ''),
            ('clipSkipStatus coi "không biết" là một giá trị', 'val known = chars.mapNotNull { it.clipSkip2 }.toSet()', 'val known = chars.map { it.clipSkip2 }.toSet()'),
            ('clipSkipStatus báo lệch khi chỉ có 1 giá trị', 'known.size > 1 ->', 'known.size > 0 ->'),
            ('withMasks làm rơi CLIP riêng', 'if (regional && m != null) Choice(primaryModelId, extraUnetPaths, activeCount, tau, true, m, fallbackActiveCount, extraClipPaths)', 'if (regional && m != null) Choice(primaryModelId, extraUnetPaths, activeCount, tau, true, m, fallbackActiveCount)'),
        ]
        caught = 0
        lo, hi = (int(x) for x in os.environ.get('MUT_RANGE', '0:999').split(':'))
        selected = [(k_, m_) for k_, m_ in enumerate(mutants) if lo <= k_ < hi]
        for n, (name, old, new) in selected:
            if old not in src:
                check(f'đột biến "{name}": mẫu có trong mã', False, 'mẫu không còn khớp'); continue
            mp = os.path.join(tmp, f'm{n}.kt'); open(mp, 'w', encoding='utf-8').write(src.replace(old, new, 1))
            ml, me = run_suite(mp, tmp, f'm{n}')
            if ml is None and me.startswith('compile'):
                check(f'đột biến "{name}" phải BIÊN DỊCH được (nếu không thì "bị bắt" là vô nghĩa)', False, me); continue
            hit = True if ml is None else matches(ml) > 0   # ném ngoại lệ lúc chạy trên ca thử = khác biệt hành vi quan sát được = bắt thật
            check(f'đột biến "{name}" bị bắt', hit); caught += hit
        check(f'thử phá mã: {caught}/{len(selected)} đột biến bị bắt', caught == len(selected))
    shutil.rmtree(tmp, ignore_errors=True)

# ---------------- phần 2: nối dây tĩnh ----------------
def rd(*p): return open(os.path.join(KT, *p), encoding='utf-8').read()
IP = rd('pipeline/ImagePipeline.kt'); MP = rd('pipeline/MangaPipeline.kt'); ML = rd('model/Models.kt'); ST = rd('ui/SettingsScreen.kt')
check('ImagePipeline: armOccCfg() ở đủ 10 hàm sinh ảnh gốc (SD1.5 x6 + SDXL x4)', IP.count('armOccCfg()  // mục 261') == 10, str(IP.count('armOccCfg()  // mục 261')))
check('ImagePipeline: armOccCfg nuốt lỗi .so cũ (Throwable) — không làm hỏng lượt sinh', re.search(r'private fun armOccCfg\(\)[\s\S]*?catch \(_: Throwable\)', IP) is not None)
check('ImagePipeline.clearOccCfg xoá cả plan Kotlin lẫn cờ native', 'fun clearOccCfg()' in IP and 'occCfgPlan = null' in IP and 'NativeBridge.clearOccCfg()' in IP)
check('MangaPipeline: clearOccCfg() trong finally của generatePanels và regeneratePanel', MP.count('imagePipeline.clearOccCfg()') == 2)
check('MangaPipeline: occCfgPlan được dựng ở generatePanels và regeneratePanel', MP.count('imagePipeline.occCfgPlan = buildOccCfgPlan(') == 2)
check('OccCFG chỉ dựng khi bật cờ và >= 2 người', 'if (!settings.occCfgEnabled || numPersons < 2) return null' in MP)
check('generatePanel: loraCompose != null thì BỎ nhánh augmented (đường thường)', 'if (loraCompose == null && useStoryDiffusion && referenceImagePath != null)' in IP)
check('generatePanel: setLoraCompose đặt trước sdTxt2Img và clearLoraCompose trong finally', re.search(r'NativeBridge\.setLoraCompose\([\s\S]*?try \{\s*NativeBridge\.sdTxt2Img\([\s\S]*?\} finally \{\s*if \(composing\)[^\n]*clearLoraCompose', IP) is not None)
check('MangaPipeline: loraCompose truyền ở cả 3 lời gọi generatePanel thường (2 ở generatePanels + 1 ở regeneratePanel)', len(re.findall(r'loraCompose = loraChoice\b', MP)) == 2 and MP.count('loraCompose = loraChoiceRg') == 1)
check('regeneratePanel: không nạp augmented khi đã chọn compose', 'if (loraChoiceRg == null && settings.useStoryDiffusion && referenceImage != null)' in MP)
check('prepareLoraCompose: thiếu điều kiện -> null + log, KHÔNG ném lỗi', 'dùng đường cũ")' in MP and 'LoraComposePlan.choose(true,' in MP)
for f in ('occCfgEnabled', 'contactGradedMask', 'loraCompose', 'loraComposeComposite'):
    check(f'Models: {f} mặc định TẮT', f'val {f}: Boolean = false' in ML)
check('Models: mặc định occCfgBoost 1.4, contactMaskFloor 0.45, loraSwitchTau 5', 'val occCfgBoost: Float = 1.4f' in ML and 'val contactMaskFloor: Float = 0.45f' in ML and 'val loraSwitchTau: Float = 5f' in ML)
check('mask liên tục chỉ khi bật CẢ differentialInpaint và contactGradedMask', 'it.differentialInpaint && it.contactGradedMask' in MP)
check('mask liên tục nhân SAU silhouette và bỏ qua khi không có tiếp xúc (cm == null giữ nguyên)', MP.index('SilhouetteFilter.strokeAxis(canvas, skeletonData, idx, fullW, fullH)') < MP.index('ContactMap.gradedWeight(cm.intensityAt(') and 'if (cm != null) {' in MP)
check('Cài đặt: 4 công tắc + 3 thanh trượt có UI', all(k in ST for k in ('helpKey = "occCfgEnabled"', 'helpKey = "contactGradedMask"', 'helpKey = "loraCompose"', 'helpKey = "loraComposeComposite"', '"occCfgBoost"', '"contactMaskFloor"', '"loraSwitchTau"')))
check('MangaPipeline: dựng mask vùng bằng ContactMap.regionMasks với characterOrder = thứ tự nhân vật của biến thể (người i = LoRA i)', 'ContactMap.regionMasks(skeleton(), characterNames.size' in MP and MP.count('characterOrder = panel.scene.characters, chapterNumber') == 3)
check('MangaPipeline: thiếu mask -> choice.withMasks(null) quay về Switch/Composite + log', 'choice = choice.withMasks(masks)' in MP and 'không dựng được mask vùng' in MP)
check('ImagePipeline: setLoraComposeMasks chỉ gọi SAU setLoraCompose và chỉ khi regional + có mask', re.search(r'NativeBridge\.setLoraCompose\([\s\S]*?if \(loraCompose\.regional && rm != null\) NativeBridge\.setLoraComposeMasks', IP) is not None)
check('Models: loraComposeRegional mặc định TẮT', 'val loraComposeRegional: Boolean = false' in ML)
check('Cài đặt: công tắc loraComposeRegional có UI và ẩn Composite/tau khi bật', 'helpKey = "loraComposeRegional"' in ST and 'if (!settings.loraComposeRegional) Row(' in ST and '!settings.loraComposeComposite && !settings.loraComposeRegional' in ST)
check('MangaPipeline: CharModel mang clip.mnn của model nhân vật; choose nhận ownClip từ Cài đặt', 'File(File(storyManager.modelsDir, it.dir), "clip.mnn")' in MP and 'ownClip = settings.loraComposeOwnClip' in MP)
check('ImagePipeline: setLoraComposeClips gọi SAU setLoraCompose, chỉ khi có CLIP riêng', re.search(r'NativeBridge\.setLoraCompose\([\s\S]*?if \(loraCompose\.extraClipPaths\.isNotEmpty\(\)\) NativeBridge\.setLoraComposeClips', IP) is not None)
SM = open(os.path.join(KT, 'pipeline/StoryManager.kt'), encoding='utf-8').read()
check('mục 263: manifest có clip_skip2 nullable (null = không biết), ghi lúc convert, MangaPipeline truyền vào CharModel và ghi log riêng khi lệch', 'val clip_skip2: Boolean? = null' in SM and 'clipSkip2 = clipSkip2)' in SM and 'entry?.clip_skip2' in MP and 'clip_skip KHÁC NHAU' in MP)
check('Models: loraComposeOwnClip mặc định BẬT (bên trong tính năng vốn tắt) và có UI', 'val loraComposeOwnClip: Boolean = true' in ML and 'helpKey = "loraComposeOwnClip"' in ST)
print('ALL OK' if ok else 'CÓ LỖI')
sys.exit(0 if ok else 1)
