#!/usr/bin/env python3
"""mục 266 — kiểm thử `pipeline/MiniJson.kt` + `pipeline/OpenAiChatJson.kt` bằng kotlinc THẬT, đối chiếu với module `json` của Python (độc lập, không phải bản dịch).

Kiểm: (1) MiniJson.quote == json.dumps(ensure_ascii=False) trên chuỗi ngẫu nhiên (ký tự điều khiển, Unicode, nháy, gạch chéo ngược); (2) MiniJson.parse đọc đúng 1500 tài liệu JSON
ngẫu nhiên lồng nhau (kiểm bằng cách in lại rồi json.loads so với bản gốc) và TỪ CHỐI đúng các tài liệu hỏng mà json.loads cũng từ chối; (3) body chữ/ảnh OpenAI hợp lệ và đúng nội dung
(ký tự đặc biệt, nháy, xuống dòng, data URL); (4) extractContent: content chuỗi, content mảng phần tử, lỗi {error}, choices rỗng, content null/rỗng, JSON hỏng.
Thử phá mã: bộ kiểm phải bắt được đột biến có ý nghĩa. KHÔNG chứng minh: tương thích với dịch vụ thật (chưa gọi thử), độ lớn ảnh tối đa từng nhà cung cấp.
Cần kotlinc (không có -> SKIP).
"""
import json, os, random, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = os.path.join(ROOT, 'app/src/main/java/com/mangalocal/pipeline')
ok = True
def check(n, c, d=''):
    global ok
    print(('PASS ' if c else 'FAIL ') + n + ((' :: ' + str(d)[:400]) if (d and not c) else '')); ok &= bool(c)
def find():
    for c in [os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/work/kotlinc/bin/kotlinc', '/home/claude/tools_dl/kotlinc/bin/kotlinc']:
        if c and os.path.exists(c): return c
KOTLINC = find()
if not KOTLINC:
    print('SKIP: không có kotlinc'); sys.exit(0)
KLIB = os.path.join(os.path.dirname(os.path.dirname(KOTLINC)), 'lib', 'kotlin-stdlib.jar')

DRIVER = r'''
import com.mangalocal.pipeline.*
import java.io.File
fun hex(s: String): String = s.toByteArray(Charsets.UTF_8).joinToString("") { "%02x".format(it) }
fun unhex(h: String): String { val b = ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }; return String(b, Charsets.UTF_8) }
fun w(x: Any?): String = when (x) {
    null -> "null"
    is Map<*, *> -> x.entries.joinToString(",", "{", "}") { MiniJson.quote(it.key as String) + ":" + w(it.value) }
    is List<*> -> x.joinToString(",", "[", "]") { w(it) }
    is String -> MiniJson.quote(x)
    is Boolean -> x.toString()
    is Long -> x.toString()
    is Double -> x.toString()
    else -> "?" + x.javaClass.name
}
fun main(args: Array<String>) {
    val out = StringBuilder()
    for (line in File(args[0]).readLines()) {
        if (line.isEmpty()) continue
        val p = line.split("\t")
        when (p[0]) {
            "Q" -> out.append(MiniJson.quote(unhex(p[1]))).append("\n")
            "P" -> out.append(try { "OK " + w(MiniJson.parse(unhex(p[1]))) } catch (e: IllegalArgumentException) { "ERR" }).append("\n")
            "TB" -> out.append(OpenAiChatJson.textBody(unhex(p[1]), unhex(p[2]), p[3].toInt(), p[4].toFloat())).append("\n")
            "VB" -> out.append(OpenAiChatJson.visionBody(unhex(p[1]), unhex(p[2]), unhex(p[3]), unhex(p[4]), p[5].toInt(), p[6].toFloat())).append("\n")
            "EX" -> out.append(try { "OK " + hex(OpenAiChatJson.extractContent(unhex(p[1]))) } catch (e: IllegalArgumentException) { "ERR " + hex(e.message ?: "") }).append("\n")
        }
    }
    File(args[1]).writeText(out.toString())
}
'''
def hx(s): return s.encode('utf-8').hex()
def unhx(h):
    try: return bytes.fromhex(h).decode('utf-8')
    except Exception: return None      # đầu ra hỏng (đột biến) -> coi như không đọc được, KHÔNG ném ngoại lệ
def jl(s):
    """json.loads không ném: đầu ra Kotlin hỏng cú pháp (do đột biến) thành giá trị đánh dấu để so sánh ra khác biệt."""
    try: return json.loads(s)
    except Exception: return ('JSON-HỎNG', s[:60])
def compile_(srcdir_files, tmp, tag):
    d = os.path.join(tmp, tag); os.makedirs(d, exist_ok=True)
    open(os.path.join(d, 'Drv.kt'), 'w').write(DRIVER)
    jar = os.path.join(tmp, tag + '.jar')
    r = subprocess.run([KOTLINC] + srcdir_files + [os.path.join(d, 'Drv.kt'), '-d', jar], capture_output=True, text=True)
    return jar, r
def run(jar, tmp, lines):
    fi = os.path.join(tmp, 'in.txt'); fo = os.path.join(tmp, 'out.txt')
    open(fi, 'w').write('\n'.join(lines) + '\n')
    r = subprocess.run(['java', '-cp', f'{jar}:{KLIB}', 'DrvKt', fi, fo], capture_output=True, text=True)
    if r.returncode != 0: return None, r.stderr[-500:]
    return open(fo, encoding='utf-8').read().split('\n')[:len(lines)], ''

rng = random.Random(266)
def rand_str():
    pool = ['a', 'Z', '0', ' ', '"', '\\', '/', '\n', '\r', '\t', '\b', '\x0c', '\x01', '\x1f', 'é', 'ệ', '日', '🙂', '\u2028', '{', '[', ',', ':']
    return ''.join(rng.choice(pool) for _ in range(rng.randint(0, 14)))
def rand_val(d=0):
    k = rng.random()
    if d > 4 or k < 0.35:
        return rng.choice([None, True, False, rng.randint(-10**12, 10**12), round(rng.uniform(-1e6, 1e6), 4), rand_str(), 0, -1, 1.5e-7])
    if k < 0.65: return [rand_val(d + 1) for _ in range(rng.randint(0, 4))]
    return {rand_str() or 'k': rand_val(d + 1) for _ in range(rng.randint(0, 4))}

QS = [rand_str() for _ in range(400)] + ['', '"', '\\', '\x00', '\x7f', 'a"b\\c']
DOCS = []
for _ in range(1500):
    v = rand_val()
    DOCS.append(json.dumps(v, ensure_ascii=rng.random() < 0.5, indent=rng.choice([None, 1])))
BAD = ['', ' ', '{', '[', '{"a"}', '{"a":}', '{"a":1,}', '[1,]', '[1 2]', '{a:1}', "{'a':1}", '"abc', '"a\\x"', '"\\u12"', '"\\u12zz"', 'tru', 'nul', '01', '1.', '-', '+1', '1e', '.5',
       '[1]x', '{} {}', '"a\nb"', '[' * 70 + ']' * 70, '"x\\ny\nz"', '{"a":1 "b":2}', 'NaN', 'Infinity', '[1,,2]', '\u00a0 1']

TEXT = ['Xin chào "thế giới"\nDòng 2\t🙂', 'a\\b', '', 'x' * 5000]
RESP = {
    'str':   json.dumps({'choices': [{'message': {'role': 'assistant', 'content': 'Trả lời ổn ✓'}, 'finish_reason': 'stop'}]}),
    'parts': json.dumps({'choices': [{'message': {'content': [{'type': 'text', 'text': 'A'}, {'type': 'image', 'x': 1}, {'type': 'text', 'text': 'B'}]}}]}),
    'err':   json.dumps({'error': {'message': 'Quota exceeded', 'code': 429}}),
    'nochoice': json.dumps({'choices': []}),
    'nullc': json.dumps({'choices': [{'message': {'content': None}, 'finish_reason': 'length'}]}),
    'blank': json.dumps({'choices': [{'message': {'content': '   '}}]}),
    'broken': '{"choices": [',
    'notjson': '<html>502</html>',
}

def lines_for():
    L = []
    for s in QS: L.append('Q\t' + hx(s))
    for d in DOCS: L.append('P\t' + hx(d))
    for b in BAD: L.append('P\t' + hx(b))
    L.append('P\t' + hx('[' * 60 + ']' * 60)); L.append('P\t' + hx('[' * 70 + ']' * 70)); L.append('P\t' + hx('{"a":' * 65 + '1' + '}' * 65))   # giới hạn độ sâu 64: 60 tầng đọc được, 70 và 65 tầng bị từ chối
    for t in TEXT:
        L.append('TB\t' + '\t'.join([hx('gemini-2.5-flash'), hx(t), '300', '0.7']))
        L.append('VB\t' + '\t'.join([hx('m"x'), hx(t), hx('QUJD'), hx('image/jpeg'), '12', '0']))
    for k, v in RESP.items(): L.append('EX\t' + hx(v))
    return L

def verify(res, label_prefix=''):
    """Trả về danh sách lỗi (rỗng = mọi thứ đúng)."""
    errs = []
    i = 0
    for s in QS:
        if res[i] != json.dumps(s, ensure_ascii=False): errs.append(('quote', s, res[i]))
        i += 1
    for d in DOCS:
        want = json.loads(d)
        r = res[i]; i += 1
        if not r.startswith('OK '): errs.append(('parse-ok', d[:80], r)); continue
        got = jl(r[3:])
        # so cả KIỂU: Python coi 5.0 == 5 và True == 1 nên so sánh == che mất việc Kotlin trả sai kiểu số/boolean -> so thêm bản in lại
        if got != want or json.dumps(got) != json.dumps(want): errs.append(('parse-val', d[:80], r[:80]))
    for b in BAD:
        r = res[i]; i += 1
        try: json.loads(b); py_rejects = False
        except Exception: py_rejects = True
        if py_rejects and r != 'ERR': errs.append(('bad-accepted', b[:40], r[:40]))
    d60, d70, dobj = res[i], res[i + 1], res[i + 2]; i += 3
    if not d60.startswith('OK '): errs.append(('depth60-rejected', d60[:30]))
    if d70 != 'ERR': errs.append(('depth70-accepted', d70[:30]))
    if dobj != 'ERR': errs.append(('depth-obj65-accepted', dobj[:30]))
    for t in TEXT:
        tb = jl(res[i]); i += 1
        if tb != {'model': 'gemini-2.5-flash', 'temperature': 0.7, 'max_tokens': 300, 'messages': [{'role': 'user', 'content': t}]}: errs.append(('textbody', t[:20], str(tb)[:120]))
        vb = jl(res[i]); i += 1
        want = {'model': 'm"x', 'temperature': 0.0, 'max_tokens': 12, 'messages': [{'role': 'user', 'content': [
            {'type': 'text', 'text': t}, {'type': 'image_url', 'image_url': {'url': 'data:image/jpeg;base64,QUJD'}}]}]}
        if vb != want: errs.append(('visionbody', t[:20], str(vb)[:160]))
    ex = dict(zip(RESP.keys(), res[i:i + len(RESP)]))
    def okv(k): return unhx(ex[k][3:]) if ex[k].startswith('OK ') else None
    def erv(k): return unhx(ex[k][4:]) if ex[k].startswith('ERR ') else None
    if okv('str') != 'Trả lời ổn ✓': errs.append(('ex-str', ex['str'][:60]))
    if okv('parts') != 'AB': errs.append(('ex-parts', ex['parts'][:60]))
    if not ((erv('err') or '') and 'Quota exceeded' in (erv('err') or '')): errs.append(('ex-err', ex['err'][:80]))
    if not ('choices' in (erv('nochoice') or '')): errs.append(('ex-nochoice', ex['nochoice'][:80]))
    if not ('finish_reason=length' in (erv('nullc') or '')): errs.append(('ex-nullc', ex['nullc'][:80]))
    if erv('blank') is None: errs.append(('ex-blank', ex['blank'][:60]))
    if erv('broken') is None: errs.append(('ex-broken', ex['broken'][:60]))
    if erv('notjson') is None: errs.append(('ex-notjson', ex['notjson'][:60]))
    return errs

tmp = tempfile.mkdtemp()
SRC = [os.path.join(KT, 'MiniJson.kt'), os.path.join(KT, 'OpenAiChatJson.kt')]
jar, r = compile_(SRC, tmp, 'orig')
check('MiniJson.kt + OpenAiChatJson.kt biên dịch bằng kotlinc thật', r.returncode == 0, r.stderr[-600:])
if r.returncode != 0:
    print('CÓ LỖI'); sys.exit(1)
L = lines_for()
res, err = run(jar, tmp, L)
check('chạy driver', res is not None, err)
errs = verify(res) if res else [('run', err)]
check(f'MiniJson/OpenAiChatJson khớp json của Python: {len(QS)} chuỗi, {len(DOCS)} tài liệu ngẫu nhiên, {len(BAD)} tài liệu hỏng, body chữ/ảnh, 8 kiểu phản hồi', not errs, errs[:3])
# kiểm riêng vài điểm bắt buộc để thấy rõ khi vỡ
bad_ok = {b: res[len(QS) + len(DOCS) + i] for i, b in enumerate(BAD)} if res else {}
check('từ chối đúng 30+ tài liệu hỏng (không nuốt lỗi cú pháp)', sum(1 for b, r_ in bad_ok.items() if r_ == 'ERR') >= 28, [(b[:20], r_[:20]) for b, r_ in bad_ok.items() if r_ != 'ERR'])
# chuỗi base64 ảnh dài ~3 MB (phản hồi ảnh thật) phải đọc NGUYÊN VẸN qua đường nhanh; và khi có '\\' sau đoạn dài thì đường chậm vẫn đúng
import base64
big = base64.b64encode(os.urandom(2_200_000)).decode()
long_doc = json.dumps({'result': {'image': big}, 'success': True})
tail_doc = json.dumps({'s': big[:100000] + '\n' + big[100000:200000]})   # JSON chứa chuỗi thoát \n ở GIỮA chuỗi dài -> buộc đường chậm
res_big, eb = run(jar, tmp, ['P\t' + hx(long_doc), 'P\t' + hx(tail_doc)])
okb = res_big is not None and res_big[0].startswith('OK ') and (jl(res_big[0][3:]) or {}).get('result', {}).get('image') == big
check(f'chuỗi base64 ~{len(big) // 1_000_000} MB đọc nguyên vẹn (đường nhanh)', okb, eb)
okt = res_big is not None and res_big[1].startswith('OK ') and (jl(res_big[1][3:]) or {}).get('s') == big[:100000] + '\n' + big[100000:200000]
check('chuỗi dài có ký tự thoát giữa chừng vẫn đúng (đường chậm)', okt, eb)

# ---- thử phá mã
def src_text(name): return open(os.path.join(KT, name), encoding='utf-8').read()
MUT = [
    ('MiniJson.kt', 'quote: không thoát dấu nháy kép', "'\"' -> sb.append(\"\\\\\\\"\")", "'\"' -> sb.append('\"')"),
    ('MiniJson.kt', 'quote: không thoát ký tự điều khiển < 0x20', "else -> if (ch < ' ') {", "else -> if (false) {"),
    ('MiniJson.kt', 'parse: bỏ kiểm ký tự thừa sau giá trị', 'if (p.pos != text.length) p.fail("còn ký tự thừa sau giá trị JSON")', ''),
    ('MiniJson.kt', 'parse: chấp nhận dấu phẩy thừa cuối mảng', "                l.add(value(depth + 1))\n                skipWs()\n                if (pos >= s.length) fail(\"hết dữ liệu trong mảng\")",
        "                if (pos < s.length && s[pos] == ']') { pos++; return l }\n                l.add(value(depth + 1))\n                skipWs()\n                if (pos >= s.length) fail(\"hết dữ liệu trong mảng\")"),
    ('MiniJson.kt', 'parse: \\n trong chuỗi bị đọc thành \'n\'', "'n' -> sb.append('\\n')", "'n' -> sb.append('n')"),
    ('MiniJson.kt', 'parse: bỏ giới hạn độ sâu', 'if (depth > MAX_DEPTH) fail("lồng quá sâu (> $MAX_DEPTH)")', ''),
    ('MiniJson.kt', 'parse: cho phép ký tự điều khiển thô trong chuỗi (đường chậm)', "c < ' ' -> fail(\"ký tự điều khiển trong chuỗi\")\n                    else -> sb.append(c)", "else -> sb.append(c)"),
    ('MiniJson.kt', 'parse: số nguyên lớn thành Long sai (luôn Double)', 'return if (isDouble) t.toDouble() else (t.toLongOrNull() ?: t.toDouble())', 'return t.toDouble()'),
    ('OpenAiChatJson.kt', 'visionBody: thiếu tiền tố data: URL', '"data:$mime;base64,$imageBase64"', '"$imageBase64"'),
    ('OpenAiChatJson.kt', 'visionBody: image_url thành text', '{\\"type\\":\\"image_url\\"', '{\\"type\\":\\"text\\"'),
    ('OpenAiChatJson.kt', 'extractContent: nuốt lỗi {error}', 'if (err != null) {', 'if (false) {'),
    ('OpenAiChatJson.kt', 'extractContent: content rỗng không bị coi là lỗi', 'if (text.isBlank()) {', 'if (false) {'),
    ('OpenAiChatJson.kt', 'extractContent: content mảng chỉ lấy phần tử đầu', 'content.joinToString("")', 'content.take(1).joinToString("")'),
]
lo, hi = 0, len(MUT)
if os.environ.get('MUT_RANGE'):
    a, b = os.environ['MUT_RANGE'].split(':'); lo, hi = int(a), int(b)
killed = ran = 0
for i in range(lo, min(hi, len(MUT))):
    fname, name, old, new = MUT[i]
    t0 = src_text(fname)
    if t0.count(old) != 1:
        check(f'đột biến {i} có điểm cắm duy nhất ({name})', False, f'{t0.count(old)} chỗ'); continue
    md = os.path.join(tmp, f'm{i}'); os.makedirs(md, exist_ok=True)
    files = []
    for f in ('MiniJson.kt', 'OpenAiChatJson.kt'):
        body = t0.replace(old, new) if f == fname else src_text(f)
        open(os.path.join(md, f), 'w', encoding='utf-8').write(body); files.append(os.path.join(md, f))
    j, rr = compile_(files, tmp, f'mut{i}')
    if rr.returncode != 0:
        check(f'đột biến {i} biên dịch được ({name})', False, rr.stderr[-300:]); continue
    ran += 1
    res2, e2 = run(j, tmp, L)
    survived = res2 is not None and not verify(res2)
    check(f'đột biến "{name}" bị bộ kiểm bắt', not survived)
    killed += (not survived)
if ran: check(f'thử phá mã: {killed}/{ran} đột biến bị bắt', killed == ran)
print('ALL OK' if ok else 'CÓ LỖI'); sys.exit(0 if ok else 1)
