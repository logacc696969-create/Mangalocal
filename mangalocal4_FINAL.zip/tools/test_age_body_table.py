#!/usr/bin/env python3
# mục 278 — (1) bảng số trong AgeBodyTable.kt khớp TỪNG SỐ với bản chép bảng A1 của bài gốc (tools/data/schmid2019_tableA1.txt); (2) BIÊN DỊCH và CHẠY mã Kotlin thật
# (tools/kotlin_tests/AgeBodyTest.kt: AgeBodyTable + AgeBodyScaler + BoneProportions.forAge, 100+ phép kiểm) nếu có kotlinc; không có thì BỎ QUA phần (2) và nói rõ.
# Đột biến (3) CHỈ chạy khi có cờ --mut (mỗi đột biến = một lần biên dịch kotlinc ~20–40 giây): phá mã nguồn có chủ đích, chạy lại test Kotlin, phải có kiểm FAIL.
# Cách dùng: python3 tools/test_age_body_table.py [--mut]
import os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K = os.path.join(ROOT, 'app/src/main/java/com/mangalocal')
TBL = os.path.join(K, 'model/AgeBodyTable.kt'); SCL = os.path.join(K, 'pipeline/AgeBodyScaler.kt'); MOD = os.path.join(K, 'model/Models.kt')
TDIR = os.path.join(ROOT, 'tools/kotlin_tests')
fails = []
def check(c, n):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: fails.append(n)

# (1) bảng khớp nguồn
src = open(TBL, encoding='utf-8').read()
pub = {'M': [], 'F': []}
for l in open(os.path.join(ROOT, 'tools/data/schmid2019_tableA1.txt'), encoding='utf-8'):
    if l[0] in 'MF':
        p = l.split(); pub[p[0]].append((int(p[1]), [float(x) for x in p[2:8]]))
def kt_rows(name):
    body = re.search(r'private val ' + name + r' = arrayOf\((.*?)\n    \)', src, re.S).group(1)
    return [[float(x) for x in m.group(1).replace('f', '').split(',')] for m in re.finditer(r'floatArrayOf\(([^)]*)\)', body)]
for sex, name in (('M', 'MALE'), ('F', 'FEMALE')):
    rows = kt_rows(name)
    check(len(rows) == 13 == len(pub[sex]), f'{name}: 13 hàng (tuổi 6–18)')
    check(all(a == b for (age, b), a in zip(pub[sex], rows)), f'{name}: khớp TỪNG SỐ với bảng A1 của bài gốc (chiều cao, thân+đầu+cổ, đùi, cẳng chân, cánh tay trên, cẳng tay)')
    check([a for a, _ in pub[sex]] == list(range(6, 19)), f'{name}: tuổi liên tục 6…18')
check('Schmid' in src and '10.1016/j.jbiomech.2019.07.049' in src, 'ghi nguồn (tác giả + DOI) ngay trong mã')
check('ƯỚC LƯỢNG' in src and 'KHÔNG CÓ SỐ ĐO THẬT' in src, 'ghi rõ phần nào là ước lượng (đầu, thân) — vai/hông nay là số đo thật (mục 284)')
check('NHANES III' in src and 'Zivicnjak' in src and 'Coll. Antropol. 32' in src and 'tools/data/nhanes3_breadth_t53_t56.txt' in src and 'tools/data/zivicnjak2008_tables1_4.txt' in src, 'ghi nguồn bề ngang vai/hông (NHANES III + Zivicnjak 2008) và đường dẫn bản chép ngay trong mã')

# (1b) BỀ NGANG vai/hông (mục 284): bảng BREADTH trong Kotlin phải được SINH từ hai tệp chép nguyên văn, và đáp án tính ĐỘC LẬP từ chính hai tệp đó phải khớp Kotlin
def parse_fixture(fn):
    out = {}
    for l in open(os.path.join(ROOT, 'tools/data', fn), encoding='utf-8'):
        if l.startswith('#') or not l.strip(): continue
        tb, sx, age, n, mean, sd = l.split(); out[(tb, sx, int(age))] = (int(n), float(mean))
    return out
NH, ZV = parse_fixture('nhanes3_breadth_t53_t56.txt'), parse_fixture('zivicnjak2008_tables1_4.txt')
check(len(NH) == 70 and len(ZV) == 68, f'tệp chép nguyên văn đủ dòng (NHANES 70 = 17+17+18+18; Zivicnjak 68 = 4×17): {len(NH)}, {len(ZV)}')
check(all(n >= 100 for (n, _) in NH.values() if True) and all(n >= 30 for (n, _) in ZV.values()), 'mỗi ô có đủ người đo (NHANES ≥ 100, Zivicnjak ≥ 30)')
check(subprocess.run([sys.executable, os.path.join(ROOT, 'tools/gen_age_breadth_table.py'), '--check']).returncode == 0, 'khối BREADTH trong AgeBodyTable.kt đúng BẰNG khối sinh từ hai tệp nguyên văn (từng số)')
def ser(src_tbl, bt, scale):   # chuỗi trung bình nam–nữ, chuẩn hoá theo 18 tuổi
    v = {a: ((src_tbl[(bt, 'M', a)][1] + src_tbl[(bt, 'F', a)][1]) / 2) * scale for a in range(6, 19)}; return {a: v[a] / v[18] for a in v}
S4 = [ser(NH, 'T53', 1), ser(NH, 'T56', 1), ser(ZV, 'T1', 0.1), ser(ZV, 'T4', 0.1)]
# chiều cao TB nam–nữ theo bảng Schmid (cột 0 của MALE/FEMALE) để tính shoulderFraction độc lập
exp_path = os.path.join(tempfile.gettempdir(), 'age_width_expected.txt')
import re as _re
_src = open(TBL, encoding='utf-8').read()
def _tab(name):
    m = _re.search(name + r' = arrayOf\((.*?)\n    \)', _src, _re.S); rows = _re.findall(r'floatArrayOf\(([^)]*)\)', m.group(1))
    return [[float(x.replace('f', '')) for x in r.split(',')] for r in rows]
_M, _F = _tab('MALE'), _tab('FEMALE'); H = lambda a: (_M[a - 6][0] + _F[a - 6][0]) / 2
with open(exp_path, 'w') as f:
    for a in range(6, 19):
        vals = [s[a] for s in S4]; r = sum(vals) / 4
        f.write(f'{a} {r:.6f} {max(vals) - min(vals):.6f} {0.245 * r * H(18) / H(a):.6f}\n')
spreads = [max(s[a] for s in S4) - min(s[a] for s in S4) for a in range(6, 19)]
check(max(spreads) <= 0.06, f'(Python độc lập) bốn chuỗi vai/hông của hai quần thể đồng thuận ≤ 0,06 ở mọi tuổi 6–18 (lớn nhất {max(spreads):.3f})')
check(all(abs(S4[0][a] - S4[2][a]) <= 0.06 for a in range(6, 19)), '(Python độc lập) NHANES III và Zivicnjak khớp nhau về VAI (≤ 0,06) — hai quần thể, hai kỹ thuật đo')
os.environ['AGE_WIDTH_EXPECTED'] = exp_path

# (2) chạy Kotlin thật
def find_kotlinc():
    for c in (os.environ.get('KOTLINC'), shutil.which('kotlinc'), '/home/claude/tools/kotlinc/bin/kotlinc', '/home/claude/work/kotlinc/bin/kotlinc'):
        if c and os.path.exists(c): return c
def run_kotlin(out_dir, tbl=TBL, scl=SCL, mod=MOD):
    kc = find_kotlinc(); jar = os.path.join(out_dir, 't.jar')
    r = subprocess.run([kc, '-nowarn', os.path.join(TDIR, 'StubStoryManager.kt'), os.path.join(TDIR, 'AgeBodyTest.kt'), tbl, scl, mod, '-include-runtime', '-d', jar], capture_output=True, text=True)
    if r.returncode != 0: return None, r.stderr[-1500:]
    o = subprocess.run(['java', '-Dstdout.encoding=UTF-8', '-jar', jar], capture_output=True, text=True)
    return o.stdout, o.stderr
kc = find_kotlinc()
if not kc:
    print('BỎ QUA (2)+(3): không có kotlinc (đặt KOTLINC=/đường/dẫn/kotlinc, bản 1.9.x — tải ở github.com/JetBrains/kotlin/releases). Chỉ kiểm được (1).')
else:
    with tempfile.TemporaryDirectory() as td:
        out, err = run_kotlin(td)
        check(out is not None, 'biên dịch AgeBodyTable + AgeBodyScaler + Models.kt + test bằng kotlinc' + ('' if out is not None else '\n' + err))
        if out is not None:
            n_pass = sum(1 for l in out.splitlines() if l.startswith('PASS')); bad = [l for l in out.splitlines() if l.startswith('FAIL')]
            for l in bad: print(l)
            check(not bad and n_pass >= 118, f'mã Kotlin thật: {n_pass} phép kiểm đạt, {len(bad)} lỗi')
    # (3) đột biến
    muts = [] if '--mut' not in sys.argv else [
        ('cẳng tay dùng hệ số cánh tay trên', SCL, 'place(4, 3, fFa); place(7, 6, fFa)', 'place(4, 3, fUa); place(7, 6, fUa)'),
        ('cẳng chân dùng hệ số đùi', SCL, 'place(10, 9, fSh); place(13, 12, fSh)', 'place(10, 9, fTh); place(13, 12, fTh)'),
        ('bỏ chuẩn hoá chiều cao', SCL, 'val norm = if (after > 1e-6f) before / after else 1f', 'val norm = 1f'),
        ('không đổi đầu', SCL, 'place(0, 1, fh)', ''),
        ('đo chân bằng một bên hông', SCL, 'meanLen(listOf(8 to 9, 11 to 12))', 'meanLen(listOf(8 to 9))'),
        ('bảng: đùi = cẳng chân', TBL, 'thigh = v(i, 2, sex), shank = v(i, 3, sex)', 'thigh = v(i, 3, sex), shank = v(i, 3, sex)'),
        ('bảng: đầu lớn hơn người lớn', TBL, 'if (a >= HEAD_MATURE_AGE) return 1f', 'if (a >= HEAD_MATURE_AGE) return 1.1f'),
        ('bảng: hệ số đảo', TBL, 'return Segments(b.head / a.head, b.trunk / a.trunk', 'return Segments(a.head / b.head, b.trunk / a.trunk'),
        # mục 284: bề ngang vai/hông là số đo thật
        ('bề ngang: chỉ dùng cột nam', TBL, 'BodySex.UNSPECIFIED -> (a[2 * k] + a[2 * k + 1]) / 2f }', 'BodySex.UNSPECIFIED -> a[2 * k] }'),
        ('bề ngang: bỏ quần thể thứ hai khỏi trung bình', TBL, 'return (s[0] + s[1] + s[2] + s[3]) / 4f }', 'return (s[0] + s[1]) / 2f }'),
        ('bề ngang: quên chia cho chiều cao', TBL, 'ADULT_WIDTH_FRACTION * shoulderVsAdult(age, sex) * heightCm(ADULT_AGE) / heightCm(age, sex)', 'ADULT_WIDTH_FRACTION * shoulderVsAdult(age, sex)'),
        ('bề ngang: mốc người lớn đổi', TBL, 'private const val ADULT_WIDTH_FRACTION = 0.245f', 'private const val ADULT_WIDTH_FRACTION = 0.230f'),
        ('bề ngang: forAge quên widthRatio', MOD, 'headSizeRatio = r.head, widthRatio = r.shoulder', 'headSizeRatio = r.head'),
        ('bề ngang: độ lệch đồng thuận tính sai', TBL, 'return s.max() - s.min() }', 'return s.max() - s.max() }'),
        # mục 283: approxHeadsTall có tính kích thước đầu
        ('số đầu: bỏ chia cho kích thước đầu', MOD, 'return height / head', 'return height'),
        ('số đầu: chiều cao bỏ hệ số đầu', MOD, 'val height = a.head * headSizeRatio + a.trunk', 'val height = a.head + a.trunk'),
        ('số đầu: quay lại công thức cũ (bỏ qua đầu)', MOD, 'return height / head', 'return 7.5f * (torsoRatio * 0.4f + upperLegRatio * 0.3f + lowerLegRatio * 0.3f)'),
        ('số đầu: bỏ bàn chân', MOD, 'a.shank * lowerLegRatio + foot * legAvg', 'a.shank * lowerLegRatio'),
        ('ngưỡng nhóm child quay lại 5,5', MOD, 'const val CHILD_HEADS_MAX = 6.3f', 'const val CHILD_HEADS_MAX = 5.5f'),
        ('ngưỡng không-tag quay lại 7,0', MOD, 'const val ADULT_HEADS_MAX_FOR_NO_TAG = 7.1f', 'const val ADULT_HEADS_MAX_FOR_NO_TAG = 7.0f'),
        ('chia cho 0 khi đầu = 0', MOD, 'val head = (a.head * headSizeRatio).coerceAtLeast(0.01f)', 'val head = a.head * headSizeRatio'),
    ]
    flt = os.environ.get('MUT_FILTER')
    if flt: muts = [m for m in muts if flt in m[0]]   # chạy riêng một nhóm đột biến (vd. MUT_FILTER='bề ngang')
    caught = 0
    for name, path, old, new in muts:
        text = open(path, encoding='utf-8').read(); assert old in text, name
        with tempfile.TemporaryDirectory() as td:
            mp = os.path.join(td, os.path.basename(path)); open(mp, 'w', encoding='utf-8').write(text.replace(old, new, 1))
            tbl = mp if path == TBL else TBL; scl = mp if path == SCL else SCL; mod = mp if path == MOD else MOD
            out, err = run_kotlin(td, tbl, scl, mod)
            bad = out is None or any(l.startswith('FAIL') for l in out.splitlines())
        caught += bad; print(('  BỊ BẮT: ' if bad else '  SỐNG SÓT: ') + name)
    if muts: check(caught == len(muts), f'đột biến: {caught}/{len(muts)} bị bắt')
    else: print('(bỏ qua đột biến — chạy với --mut để kiểm)')
print('ĐẠT' if not fails else 'THẤT BẠI: ' + '; '.join(fails)); sys.exit(1 if fails else 0)
