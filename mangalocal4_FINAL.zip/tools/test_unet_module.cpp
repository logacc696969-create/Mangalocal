// mục 270 — kiểm LOGIC của UnetModule.hpp trên BẢN GIẢ LẬP MNN (tools/mnn_mock). KHÔNG chứng minh gì về MNN thật: chỉ chứng minh thứ tự/cờ/
// kích thước/trộn/dọn dẹp của mã dự án đúng so với hợp đồng đã đo ở mục 264-265 (rearrange=true + base, nền chạy trước, huỷ LoRA trước nền...).
#include <cmath>
#include <cstdio>
#include <fstream>
#include <functional>
#include <string>
#include <vector>
#include "sd_engine/UnetModule.hpp"

static int g_fail = 0, g_pass = 0;
#define CHECK(c, name) do { if (c) { ++g_pass; std::printf("PASS %s\n", name); } else { ++g_fail; std::printf("FAIL %s  (dòng %d)\n", name, __LINE__); } } while (0)

static std::string dir;
static void wr(const std::string &n, const std::string &t) { std::ofstream f(dir + "/" + n); f << t; }
static std::string P(const std::string &n) { return dir + "/" + n; }
static bool has(const std::string &sub) { for (auto &e : mock::g.events) if (e.find(sub) != std::string::npos) return true; return false; }
static int idxOf(const std::string &sub) { for (size_t i = 0; i < mock::g.events.size(); ++i) if (mock::g.events[i].find(sub) != std::string::npos) return (int)i; return -1; }
static int countOf(const std::string &sub) { int n = 0; for (auto &e : mock::g.events) if (e.find(sub) != std::string::npos) ++n; return n; }

static const int H8 = 2, W8 = 3, HID = 4;  // KHÔNG vuông: hoán đổi h/w phải lộ ra
static const size_t NS = (size_t)2 * 4 * H8 * W8, NE = (size_t)2 * 77 * HID;

// Các khối T1..T10 kiểm chế độ base_is_variant=true (nền là biến thể 0); T12 kiểm CHẾ ĐỘ MẶC ĐỊNH (nền chỉ để chia sẻ trọng số).
static float expected(float scale, float bias, float delta, float s, int ts, float mean_enc) {
  return s * scale + bias + delta * s + 0.001f * ts + 0.0001f * mean_enc;
}
static bool near(float a, float b) { return std::fabs(a - b) < 1e-4f; }

int main(int argc, char **argv) {
  dir = argc > 1 ? argv[1] : "/tmp/unet_module_test";
  std::string mk = "mkdir -p " + dir; if (std::system(mk.c_str()) != 0) return 2;
  wr("base.mnn", "unet 0.5 0.1"); wr("a.lora.mnn", "lora 0.2"); wr("b.lora.mnn", "lora -0.1");
  std::vector<float> sample(NS), encM(NE, 1.0f), encA(NE, 2.0f), encB(NE, 3.0f), out(NS);
  for (size_t i = 0; i < NS; ++i) sample[i] = 0.1f * (float)i - 1.0f;

  // ---- T1: nạp đúng thứ tự + cờ
  { mock::g.reset(); std::string err;
    unet_module::UnetModuleSet s;
    bool ok = s.load(P("base.mnn"), {P("a.lora.mnn"), P("b.lora.mnn")}, 4, &err, true);
    CHECK(ok, "T1 load ok");
    CHECK(s.count() == 3 && s.loaded(), "T1 count = 1 + 2 LoRA");
    int ib = idxOf("load " + P("base.mnn")), ia = idxOf("load " + P("a.lora.mnn")), ibb = idxOf("load " + P("b.lora.mnn"));
    CHECK(ib >= 0 && ia > ib && ibb > ia, "T1 nền nạp TRƯỚC, LoRA theo thứ tự");
    CHECK(mock::g.events[ib].find("base=0 rearrange=1") != std::string::npos, "T1 nền: base=0 rearrange=1");
    CHECK(mock::g.events[ia].find("base=1 rearrange=1") != std::string::npos && mock::g.events[ibb].find("base=1 rearrange=1") != std::string::npos, "T1 LoRA: base=1 rearrange=1 (chia sẻ trọng số)");
    CHECK(mock::g.events[ib].find("shapeMutable=1") != std::string::npos, "T1 shapeMutable=1 (cấu hình MNN-LLM)");
    CHECK(mock::g.events[ib].find("names=sample,timestep,encoder_hidden_states,->out_sample,") != std::string::npos, "T1 tên input/output đúng thứ tự");
    CHECK(mock::g.events[ib].find("rt=1") != std::string::npos, "T1 dùng chung RuntimeManager");
    CHECK(mock::g.last_threads == 4 && mock::g.last_memory == (int)MNN::BackendConfig::Memory_Low && mock::g.last_power == (int)MNN::BackendConfig::Power_High, "T1 CPU 4 luồng, Memory_Low, Power_High");
    CHECK(mock::g.events[0] == "rt type=0", "T1 RuntimeManager là CPU (type 0)");
    CHECK(mock::g.live_rt == 1 && mock::g.live_modules == 3, "T1 sống: 1 rt + 3 module");
    s.release();
    CHECK(mock::g.live_modules == 0 && mock::g.live_rt == 0, "T1 release dọn hết");
    CHECK(!mock::g.violation, "T1 release: LoRA huỷ TRƯỚC nền (không vi phạm)");
    CHECK(idxOf("destroy " + P("b.lora.mnn")) < idxOf("destroy " + P("a.lora.mnn")) && idxOf("destroy " + P("a.lora.mnn")) < idxOf("destroy " + P("base.mnn")), "T1 huỷ ngược thứ tự nạp");
    s.release(); CHECK(mock::g.live_modules == 0, "T1 release lần 2 an toàn");
  }
  // ---- T2: chạy từng biến thể, số học + đối số
  { mock::g.reset(); std::string err; unet_module::UnetModuleSet s;
    s.load(P("base.mnn"), {P("a.lora.mnn"), P("b.lora.mnn")}, 4, &err, true);
    CHECK(!s.baseRan(), "T2 chưa chạy nền");
    bool ok = s.runOne(0, H8, W8, HID, 37, sample.data(), encM.data(), out.data(), &err);
    bool good = ok; for (size_t i = 0; i < NS; ++i) good = good && near(out[i], expected(0.5f, 0.1f, 0, sample[i], 37, 1.0f));
    CHECK(good, "T2 nền: đầu ra đúng (sample/timestep/enc truyền đúng)");
    CHECK(s.baseRan(), "T2 baseRan sau lượt chạy nền");
    ok = s.runOne(1, H8, W8, HID, 37, sample.data(), encA.data(), out.data(), &err);
    good = ok; for (size_t i = 0; i < NS; ++i) good = good && near(out[i], expected(0.5f, 0.1f, 0.2f, sample[i], 37, 2.0f));
    CHECK(good, "T2 LoRA a: = nền + nhánh (không ra giá trị rác 777)");
    ok = s.runOne(2, H8, W8, HID, 5, sample.data(), encB.data(), out.data(), &err);
    good = ok; for (size_t i = 0; i < NS; ++i) good = good && near(out[i], expected(0.5f, 0.1f, -0.1f, sample[i], 5, 3.0f));
    CHECK(good, "T2 LoRA b: đúng, timestep khác");
    CHECK(!has("BAD_"), "T2 kiểu/kích thước input đúng (timestep int, sample 2x4xHxW, enc 2x77xD)");
    CHECK(has("dims=2,4,2,3") && !has("dims=2,4,3,2"), "T2 sample có dạng (2,4,h8,w8) — không hoán đổi h/w");
    CHECK(!s.runOne(3, H8, W8, HID, 0, sample.data(), encM.data(), out.data(), &err) && !err.empty(), "T2 chỉ số ngoài phạm vi bị từ chối");
    CHECK(!s.runOne(0, H8, W8, HID, 0, nullptr, encM.data(), out.data(), &err), "T2 sample null bị từ chối");
    CHECK(!s.runOne(0, H8, W8, HID, 0, sample.data(), nullptr, out.data(), &err), "T2 enc null bị từ chối");
    CHECK(!s.runOne(0, H8, W8, HID, 0, sample.data(), encM.data(), nullptr, &err), "T2 out null bị từ chối");
    CHECK(!s.runOne(0, 0, W8, HID, 0, sample.data(), encM.data(), out.data(), &err), "T2 h8=0 bị từ chối");
  }
  // ---- T3: kiểm kích thước/đầu ra rỗng
  { mock::g.reset(); std::string err; unet_module::UnetModuleSet s;
    s.load(P("base.mnn"), {P("a.lora.mnn")}, 2, &err, true);
    mock::g.wrong_out_size = true;
    std::vector<float> guard(NS + 8, -5.0f);
    CHECK(!s.runOne(0, H8, W8, HID, 1, sample.data(), encM.data(), guard.data(), &err), "T3 đầu ra sai kích thước bị từ chối");
    bool untouched = true; for (float v : guard) untouched = untouched && v == -5.0f;
    CHECK(untouched, "T3 không ghi vào bộ đệm đầu ra khi sai kích thước");
    mock::g.wrong_out_size = false; mock::g.null_out = true;
    CHECK(!s.runOne(0, H8, W8, HID, 1, sample.data(), encM.data(), out.data(), &err), "T3 onForward rỗng bị từ chối");
    CHECK(mock::g.last_threads == 2, "T3 numThread truyền đúng");
  }
  // ---- T4: Switch (m=1): chọn biến thể theo công thức 4, dùng enc của biến thể đó
  { mock::g.reset(); std::string err; unet_module::UnetModuleSet s;
    s.load(P("base.mnn"), {P("a.lora.mnn"), P("b.lora.mnn")}, 4, &err, true);
    std::vector<const float *> enc = {encM.data(), encA.data(), encB.data()};
    const float sc[3] = {0.0f, 0.2f, -0.1f}; const float mean[3] = {1.0f, 2.0f, 3.0f};
    bool all = true;
    for (int step = 0; step < 12; ++step) {
      unet_module::StepParams p; p.step = step; p.tau = 2; p.active_count = 1; p.h8 = H8; p.w8 = W8; p.hidden_dim = HID; p.timestep = 10 + step;
      bool ok = s.step(p, sample.data(), enc, out.data(), &err);
      int who = (step % (3 * 2)) / 2;
      for (size_t i = 0; i < NS; ++i) all = all && ok && near(out[i], expected(0.5f, 0.1f, sc[who], sample[i], 10 + step, mean[who]));
    }
    CHECK(all, "T4 Switch tau=2 k=3: 12 bước chọn đúng biến thể + enc riêng");
    CHECK(countOf("forward") == 12, "T4 Switch chạy ĐÚNG 1 UNet mỗi bước");
    CHECK(idxOf("forward " + P("base.mnn")) == idxOf("forward"), "T4 nền chạy ĐẦU TIÊN (bước 0)");
  }
  // ---- T5: Composite (m=k) trung bình có trọng số; T6: kết hợp m=2
  { mock::g.reset(); std::string err; unet_module::UnetModuleSet s;
    s.load(P("base.mnn"), {P("a.lora.mnn"), P("b.lora.mnn")}, 4, &err, true);
    std::vector<const float *> enc = {encM.data(), encA.data(), encB.data()};
    const float sc[3] = {0.0f, 0.2f, -0.1f}; const float mean[3] = {1.0f, 2.0f, 3.0f};
    unet_module::StepParams p; p.step = 0; p.tau = 5; p.active_count = 3; p.h8 = H8; p.w8 = W8; p.hidden_dim = HID; p.timestep = 20;
    bool ok = s.step(p, sample.data(), enc, out.data(), &err), good = ok;
    for (size_t i = 0; i < NS; ++i) { float e = 0; for (int j = 0; j < 3; ++j) e += expected(0.5f, 0.1f, sc[j], sample[i], 20, mean[j]) / 3.0f; good = good && near(out[i], e); }
    CHECK(good, "T5 Composite m=3: trung bình đều 3 UNet");
    CHECK(countOf("forward") == 3, "T5 Composite chạy ĐỦ 3 UNet");
    std::vector<float> w = {1.0f, 3.0f, 0.0f};  // w=0 coi như 1 (LoraCompose.hpp)
    p.weights = &w; mock::g.events.clear();
    ok = s.step(p, sample.data(), enc, out.data(), &err); good = ok;
    const float fw[3] = {1.0f / 5.0f, 3.0f / 5.0f, 1.0f / 5.0f};
    for (size_t i = 0; i < NS; ++i) { float e = 0; for (int j = 0; j < 3; ++j) e += fw[j] * expected(0.5f, 0.1f, sc[j], sample[i], 20, mean[j]); good = good && near(out[i], e); }
    CHECK(good, "T5 trọng số w_i chuẩn hoá (w<=0 -> 1)");
    // m=2, bước 1 (tau=1, k=3) -> first = 1 -> {1,2}
    unet_module::StepParams q; q.step = 1; q.tau = 1; q.active_count = 2; q.h8 = H8; q.w8 = W8; q.hidden_dim = HID; q.timestep = 3;
    mock::g.events.clear(); ok = s.step(q, sample.data(), enc, out.data(), &err); good = ok;
    for (size_t i = 0; i < NS; ++i) good = good && near(out[i], 0.5f * expected(0.5f, 0.1f, sc[1], sample[i], 3, mean[1]) + 0.5f * expected(0.5f, 0.1f, sc[2], sample[i], 3, mean[2]));
    CHECK(good && countOf("forward") == 2 && !has("forward " + P("base.mnn")), "T6 kết hợp m=2: chỉ {a,b}, trung bình đều");
  }
  // ---- T7: Regional
  { mock::g.reset(); std::string err; unet_module::UnetModuleSet s;
    s.load(P("base.mnn"), {P("a.lora.mnn")}, 4, &err, true);
    std::vector<const float *> enc = {encM.data(), encA.data()};
    const size_t hw = (size_t)H8 * W8;
    std::vector<float> fields(2 * hw);
    for (size_t p = 0; p < hw; ++p) { fields[p] = 0.25f * (float)p; fields[hw + p] = 1.0f - fields[p]; }
    unet_module::StepParams p; p.step = 0; p.tau = 5; p.active_count = 2; p.h8 = H8; p.w8 = W8; p.hidden_dim = HID; p.timestep = 9; p.regional_fields = fields.data();
    bool ok = s.step(p, sample.data(), enc, out.data(), &err), good = ok;
    for (size_t pl = 0; pl < 8; ++pl) for (size_t q = 0; q < hw; ++q) {
      size_t i = pl * hw + q;
      float e = fields[q] * expected(0.5f, 0.1f, 0.0f, sample[i], 9, 1.0f) + fields[hw + q] * expected(0.5f, 0.1f, 0.2f, sample[i], 9, 2.0f);
      good = good && near(out[i], e);
    }
    CHECK(good, "T7 Regional: trộn TỪNG PIXEL theo hàng của đúng biến thể");
  }
  // ---- T8: step từ chối đầu vào sai
  { mock::g.reset(); std::string err; unet_module::UnetModuleSet s;
    s.load(P("base.mnn"), {P("a.lora.mnn")}, 4, &err, true);
    unet_module::StepParams p; p.h8 = H8; p.w8 = W8; p.hidden_dim = HID;
    std::vector<const float *> one = {encM.data()}, withNull = {encM.data(), nullptr};
    CHECK(!s.step(p, sample.data(), one, out.data(), &err), "T8 sai số lượng enc bị từ chối");
    CHECK(!s.step(p, sample.data(), withNull, out.data(), &err), "T8 enc null bị từ chối");
    unet_module::UnetModuleSet empty;
    CHECK(!empty.step(p, sample.data(), one, out.data(), &err) && !empty.loaded() && empty.count() == 0, "T8 chưa nạp -> từ chối");
  }
  // ---- T9: lỗi nạp -> dọn sạch, không rò, không vi phạm thứ tự
  { std::string err;
    for (int nth = 1; nth <= 3; ++nth) {
      mock::g.reset(); mock::g.fail_load_nth = nth; unet_module::UnetModuleSet s;
      bool ok = s.load(P("base.mnn"), {P("a.lora.mnn"), P("b.lora.mnn")}, 4, &err, true);
      std::string nm = "T9 Module::load #" + std::to_string(nth) + " thất bại";
      CHECK(!ok && !s.loaded() && !err.empty(), (nm + " -> load=false").c_str());
      CHECK(mock::g.live_modules == 0 && mock::g.live_rt == 0 && !mock::g.violation, (nm + " -> dọn sạch, đúng thứ tự").c_str());
    }
    mock::g.reset(); mock::g.fail_rt = true; unet_module::UnetModuleSet s;
    CHECK(!s.load(P("base.mnn"), {P("a.lora.mnn")}, 4, &err, true) && mock::g.load_calls == 0, "T9 RuntimeManager null -> không gọi Module::load");
    mock::g.reset(); unet_module::UnetModuleSet s2;
    CHECK(!s2.load(P("base.mnn"), {P("missing.lora.mnn")}, 4, &err, true) && mock::g.load_calls == 0 && err.find("missing") != std::string::npos, "T9 thiếu file LoRA -> từ chối TRƯỚC khi nạp gì");
    mock::g.reset(); unet_module::UnetModuleSet s3;
    CHECK(!s3.load(P("missing.mnn"), {P("a.lora.mnn")}, 4, &err) && mock::g.load_calls == 0, "T9 thiếu UNet nền -> từ chối");
    mock::g.reset(); unet_module::UnetModuleSet s4;
    CHECK(!s4.load("", {P("a.lora.mnn")}, 4, &err) && !s4.load(P("base.mnn"), {}, 4, &err, true) && !s4.load(P("base.mnn"), {""}, 4, &err, true), "T9 đường dẫn rỗng/không LoRA bị từ chối");
    wr("junk.lora.mnn", "garbage");
    mock::g.reset(); unet_module::UnetModuleSet s5;
    CHECK(!s5.load(P("base.mnn"), {P("junk.lora.mnn")}, 4, &err, true) && mock::g.live_modules == 0 && !mock::g.violation, "T9 file hỏng -> dọn sạch");
  }
  // ---- T10: nạp lại (load lần 2) thay thế sạch; threads kẹp >= 1
  { mock::g.reset(); std::string err; unet_module::UnetModuleSet s;
    s.load(P("base.mnn"), {P("a.lora.mnn")}, 4, &err, true);
    s.load(P("base.mnn"), {P("a.lora.mnn"), P("b.lora.mnn")}, 0, &err, true);
    CHECK(s.count() == 3 && mock::g.live_modules == 3 && mock::g.live_rt == 1 && !mock::g.violation, "T10 nạp lần 2: thay thế sạch, không rò");
    CHECK(mock::g.last_threads == 1, "T10 numThread < 1 kẹp về 1");
    { unet_module::UnetModuleSet t; t.load(P("base.mnn"), {P("a.lora.mnn")}, 4, &err, true); }
    CHECK(mock::g.live_modules == 3 && !mock::g.violation, "T10 destructor tự dọn (RAII)");
  }
  // ---- T11: phân loại đường dẫn module (std-only)
  {
    using lora_compose::ModuleMode; using lora_compose::moduleMode; using lora_compose::isModulePath;
    CHECK(isModulePath("a/unet_x.lora.mnn") && !isModulePath("a/unet.mnn") && !isModulePath(".lora.mnn") && !isModulePath("x.lora.mnn.bak") && !isModulePath("x.LORA.MNN") && !isModulePath(""), "T11 isModulePath: đúng đuôi, không khớp bậy");
    CHECK(moduleMode({}) == ModuleMode::None && moduleMode({"a.mnn", "b.mnn"}) == ModuleMode::None, "T11 moduleMode None");
    CHECK(moduleMode({"a.lora.mnn", "b.lora.mnn"}) == ModuleMode::All, "T11 moduleMode All");
    CHECK(moduleMode({"a.lora.mnn", "b.mnn"}) == ModuleMode::Mixed && moduleMode({"a.mnn", "b.lora.mnn"}) == ModuleMode::Mixed, "T11 moduleMode Mixed");
  }
  // ---- T12: CHẾ ĐỘ MẶC ĐỊNH (base_is_variant=false): nền chỉ chia sẻ trọng số, mỗi module LoRA là MỘT biến thể
  { mock::g.reset(); std::string err; unet_module::UnetModuleSet s;
    CHECK(s.load(P("base.mnn"), {P("a.lora.mnn"), P("b.lora.mnn")}, 4, &err), "T12 load mặc định ok");
    CHECK(s.count() == 2 && !s.baseIsVariant(), "T12 count = số module LoRA (nền KHÔNG là biến thể)");
    std::vector<const float *> enc = {encA.data(), encB.data()};
    bool ok = s.runOne(0, H8, W8, HID, 11, sample.data(), encA.data(), out.data(), &err), good = ok;
    for (size_t i = 0; i < NS; ++i) good = good && near(out[i], expected(0.5f, 0.1f, 0.2f, sample[i], 11, 2.0f));
    CHECK(good, "T12 biến thể 0 = module a (nền + nhánh a, KHÔNG phải nền thuần)");
    CHECK(!has("forward " + P("base.mnn")) && !s.baseRan() && !s.warmStartBase(), "T12 mặc định KHÔNG khởi động nền (chia sẻ trọng số xảy ra lúc nạp — mục 272)");
    ok = s.runOne(1, H8, W8, HID, 11, sample.data(), encB.data(), out.data(), &err); good = ok;
    for (size_t i = 0; i < NS; ++i) good = good && near(out[i], expected(0.5f, 0.1f, -0.1f, sample[i], 11, 3.0f));
    CHECK(good && !has("forward " + P("base.mnn")), "T12 biến thể 1 = module b; nền không chạy");
    CHECK(!s.runOne(2, H8, W8, HID, 0, sample.data(), encA.data(), out.data(), &err), "T12 chỉ số 2 ngoài phạm vi (chỉ 2 biến thể)");
    mock::g.events.clear();
    bool all = true;
    for (int step = 0; step < 6; ++step) {
      unet_module::StepParams p; p.step = step; p.tau = 1; p.active_count = 1; p.h8 = H8; p.w8 = W8; p.hidden_dim = HID; p.timestep = step;
      bool ok2 = s.step(p, sample.data(), enc, out.data(), &err);
      const float d = (step % 2 == 0) ? 0.2f : -0.1f; const float m = (step % 2 == 0) ? 2.0f : 3.0f;
      for (size_t i = 0; i < NS; ++i) all = all && ok2 && near(out[i], expected(0.5f, 0.1f, d, sample[i], step, m));
    }
    CHECK(all && countOf("forward") == 6 && !has("forward " + P("base.mnn")), "T12 Switch tau=1 k=2: xen kẽ a,b; nền không chạy thêm");
    unet_module::StepParams p; p.step = 0; p.tau = 5; p.active_count = 2; p.h8 = H8; p.w8 = W8; p.hidden_dim = HID; p.timestep = 4;
    mock::g.events.clear(); ok = s.step(p, sample.data(), enc, out.data(), &err); good = ok;
    for (size_t i = 0; i < NS; ++i) good = good && near(out[i], 0.5f * expected(0.5f, 0.1f, 0.2f, sample[i], 4, 2.0f) + 0.5f * expected(0.5f, 0.1f, -0.1f, sample[i], 4, 3.0f));
    CHECK(good && countOf("forward") == 2, "T12 Composite m=2: trung bình a và b, KHÔNG có nền thuần trong phép trộn");
    const size_t hw = (size_t)H8 * W8; std::vector<float> fields(2 * hw);
    for (size_t q = 0; q < hw; ++q) { fields[q] = 0.2f * (float)q; fields[hw + q] = 1.0f - fields[q]; }
    p.regional_fields = fields.data(); ok = s.step(p, sample.data(), enc, out.data(), &err); good = ok;
    for (size_t pl = 0; pl < 8; ++pl) for (size_t q = 0; q < hw; ++q) { size_t i = pl * hw + q;
      good = good && near(out[i], fields[q] * expected(0.5f, 0.1f, 0.2f, sample[i], 4, 2.0f) + fields[hw + q] * expected(0.5f, 0.1f, -0.1f, sample[i], 4, 3.0f)); }
    CHECK(good, "T12 Regional trên 2 module: hàng i của mask = module i");
    CHECK(!s.step(p, sample.data(), std::vector<const float *>{encA.data(), encB.data(), encA.data()}, out.data(), &err), "T12 enc 3 phần tử cho 2 biến thể bị từ chối");
    s.release(); CHECK(!s.baseIsVariant() && s.count() == 0, "T12 release đặt lại chế độ");
  }
  // T12b: warm_start_base=true — nền khởi động ĐÚNG MỘT LẦN trước module LoRA đầu tiên (đầu ra bỏ đi); lỗi -> không đánh dấu, thử lại khởi động lại
  { mock::g.reset(); std::string err; unet_module::UnetModuleSet s;
    s.load(P("base.mnn"), {P("a.lora.mnn"), P("b.lora.mnn")}, 4, &err, false, true);
    CHECK(s.warmStartBase() && !s.baseIsVariant(), "T12b cờ warm_start_base được ghi nhận");
    bool ok = s.runOne(0, H8, W8, HID, 11, sample.data(), encA.data(), out.data(), &err), good = ok;
    for (size_t i = 0; i < NS; ++i) good = good && near(out[i], expected(0.5f, 0.1f, 0.2f, sample[i], 11, 2.0f));
    CHECK(good, "T12b đầu ra module a đúng (đầu ra khởi động nền không lẫn vào)");
    CHECK(countOf("forward " + P("base.mnn")) == 1 && idxOf("forward " + P("base.mnn")) < idxOf("forward " + P("a.lora.mnn")), "T12b nền khởi động ĐÚNG MỘT LẦN, TRƯỚC module đầu tiên");
    ok = s.runOne(1, H8, W8, HID, 11, sample.data(), encB.data(), out.data(), &err);
    CHECK(ok && countOf("forward " + P("base.mnn")) == 1 && s.baseRan(), "T12b module b: nền không chạy lại");
  }
  { mock::g.reset(); std::string err; unet_module::UnetModuleSet s;
    s.load(P("base.mnn"), {P("a.lora.mnn")}, 4, &err, false, true);
    mock::g.null_out = true;
    CHECK(!s.runOne(0, H8, W8, HID, 1, sample.data(), encA.data(), out.data(), &err) && !s.baseRan(), "T12c khởi động nền lỗi -> từ chối, baseRan vẫn false");
    mock::g.null_out = false; mock::g.events.clear();
    bool ok = s.runOne(0, H8, W8, HID, 1, sample.data(), encA.data(), out.data(), &err);
    CHECK(ok && s.baseRan() && countOf("forward " + P("base.mnn")) == 1, "T12c thử lại: khởi động nền rồi chạy module");
    s.release(); CHECK(!s.warmStartBase(), "T12c release đặt lại cờ khởi động");
  }
  // T12d: base_is_variant + warm_start: chạy nền như biến thể 0 đánh dấu đã chạy; LoRA sau đó không khởi động lại
  { mock::g.reset(); std::string err; unet_module::UnetModuleSet s;
    s.load(P("base.mnn"), {P("a.lora.mnn")}, 4, &err, true, true);
    bool ok = s.runOne(0, H8, W8, HID, 2, sample.data(), encM.data(), out.data(), &err);
    ok = ok && s.runOne(1, H8, W8, HID, 2, sample.data(), encA.data(), out.data(), &err);
    CHECK(ok && countOf("forward " + P("base.mnn")) == 1, "T12d nền là biến thể 0 + cờ khởi động: nền chạy đúng 1 lần");
  }
  std::printf("\nTONG: %d PASS, %d FAIL\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
