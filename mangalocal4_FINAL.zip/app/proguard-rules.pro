# mục 142 TECHNICAL_STATUS.md — 2 rule dưới đây ĐÃ ĐỦ AN TOÀN cho R8 (nếu
# app/build.gradle bật minifyEnabled=true sau này, xem comment ở đó): dòng
# 1 giữ NGUYÊN tên MỌI lớp trong package com.mangalocal.** (không đổi tên/
# obfuscate) — bao gồm cả com.mangalocal.pipeline.NativeBridge, nơi JNI
# native code (mnn_diffusion_pipeline.cpp, ip_adapter.cpp...) liên kết
# hàm theo ĐÚNG tên lớp đầy đủ dạng "Java_com_mangalocal_pipeline_
# NativeBridge_xxx" — R8 đổi tên lớp đó mà thiếu rule này sẽ vỡ liên kết
# JNI ngay lúc khởi động (UnsatisfiedLinkError). Dòng 2 giữ thêm mọi
# phương thức `native` ở BẤT KỲ lớp nào khác (phòng hờ, dòng 1 riêng đã đủ
# cho các lớp thật của dự án).
#
# CỐ TÌNH giữ rule RỘNG (`-keep class com.mangalocal.** { *; }` — cả field,
# method không phải native) thay vì rule HẸP chỉ liệt kê đúng NativeBridge
# + các lớp Gson/JSON cần giữ tên field — rule rộng giảm hầu hết lợi ích
# giảm dung lượng của R8 (gần như tắt shrink/obfuscate cho toàn bộ code
# của dự án), nhưng AN TOÀN HƠN NHIỀU so với đoán thiếu 1 lớp nào đó cần
# giữ (Gson đọc GenerationSettings/BatchProgressState... qua reflection
# theo tên field, model_manifest.json parse theo tên field JSON, JNI theo
# tên lớp NativeBridge — thiếu ĐÚNG 1 rule hẹp sai chỗ = crash runtime khó
# tìm ra ngay). Khi có build thật để test kỹ (bật minifyEnabled=true, chạy
# hết luồng sinh ảnh + LLM + export CBZ + import truyện, xác nhận không
# crash), CÓ THỂ thu hẹp lại rule cho đúng dung lượng tối ưu hơn — CHƯA làm
# ở đây vì không có cách kiểm chứng thật trong sandbox này.
-keep class com.mangalocal.** { *; }
-keepclassmembers class * { native <methods>; }
