package com.mangalocal.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mangalocal.model.FreeImageConfig
import com.mangalocal.pipeline.FreeImageApi
import com.mangalocal.pipeline.ImageSource
import com.mangalocal.pipeline.toCreds

/**
 * mục 266 TECHNICAL_STATUS.md — hộp thoại chọn NGUỒN tạo ảnh, hiện NGAY TẠI CHỖ TẠO (màn Bối cảnh: "Tạo ảnh nền"; màn Nhân vật: "tạo bằng AI" và "phiên bản
 * ngoại hình") để người dùng biết và chọn: theo cấu hình hiện tại (SD trên máy hoặc Remote GPU), hay API MIỄN PHÍ (Cloudflare Workers AI / Pollinations).
 *
 * Nguồn API chưa nhập đủ thông tin đăng nhập (Cài đặt > API ảnh miễn phí) thì bị làm mờ kèm lý do — không cho chọn rồi mới báo lỗi. Lý do dùng
 * FreeImageApi.problems() (đã kiểm thử). Chỉ dành cho ảnh KHÔNG CẦN điều khiển (ảnh nền, ảnh phác nhân vật), không dùng cho panel.
 */
@Composable
fun ImageSourceDialog(
    title: String,
    freeImage: FreeImageConfig,
    initial: ImageSource = ImageSource.CONFIGURED,
    onPick: (ImageSource) -> Unit,
    onDismiss: () -> Unit
) {
    val creds = freeImage.toCreds()
    // lý do nguồn chưa dùng được (null = dùng được)
    val unavailable: (ImageSource) -> String? = { s ->
        val p = s.freeProvider()
        if (p == null) null else {
            val pr = FreeImageApi.problems(p, creds)
            if (pr.isEmpty()) null else pr.joinToString("; ") + " — nhập ở Cài đặt > API ảnh miễn phí"
        }
    }
    var selected by remember { mutableStateOf(if (unavailable(initial) == null) initial else ImageSource.CONFIGURED) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.S1,
        title = { Text(title, color = C.T1) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    "Chọn nơi tạo ảnh lần này. API miễn phí có hạn mức mỗi ngày và gửi MÔ TẢ chữ của bạn tới bên thứ ba qua Internet " +
                        "(ứng dụng vẫn chạy offline nếu chọn \"cấu hình hiện tại\").",
                    color = C.T3, fontSize = 11.sp, lineHeight = 14.sp
                )
                Spacer(Modifier.height(6.dp))
                for (s in ImageSource.values()) {
                    val why = unavailable(s)
                    Row(
                        Modifier.fillMaxWidth().clickable(enabled = why == null) { selected = s }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        RadioButton(selected = selected == s, onClick = { selected = s }, enabled = why == null)
                        Column(Modifier.padding(start = 4.dp, top = 10.dp)) {
                            Text(s.label, color = if (why == null) C.T1 else C.T3, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            if (why != null) Text(why, color = C.Orange, fontSize = 11.sp, lineHeight = 14.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onPick(selected) }) { Text("Tạo ảnh") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Huỷ") } }
    )
}
