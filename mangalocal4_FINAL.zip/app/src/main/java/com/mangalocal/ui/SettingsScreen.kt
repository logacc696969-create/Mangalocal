package com.mangalocal.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*
import com.mangalocal.pipeline.RemoteGenerationClient
import kotlinx.coroutines.launch

// mục 134 TECHNICAL_STATUS.md — nhóm 21 card cài đặt (trước đó là danh
// sách PHẲNG dài ~1200 dòng, cuộn không phân cấp — tối ưu UX di động kém)
// thành 6 nhóm gấp/mở theo chủ đề. Nhóm hay dùng (Model, Kích thước, Hoàn
// thiện ảnh) MỞ SẴN; nhóm ít dùng hơn (Nâng cao/Thử nghiệm, Hệ thống,
// Remote GPU) ĐÓNG SẴN — giảm rợn ngợp lúc mới vào màn Settings, user tự
// mở khi cần đúng mục. Dùng lại ĐÚNG pattern Surface(onClick)+remember đã
// có sẵn ở 2 card đầu file (Hướng dẫn đặt model/Tối ưu phần cứng), không
// phát minh style mới. KHÔNG dùng animateContentSize() (tránh phụ thuộc
// thêm androidx.compose.animation chưa xác nhận có sẵn trong classpath —
// mở/đóng tức thời, không có animation, đánh đổi chấp nhận được).
@Composable
private fun SettingsSectionHeader(icon: String, title: String, expanded: Boolean, onToggle: () -> Unit) {
    Surface(onClick = onToggle, color = C.S1, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Border)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 16.sp)
            Spacer(Modifier.width(8.dp))
            Text(title, color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = C.T3)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(nav: NavController, vm: MainViewModel) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()
    val llmModels by vm.llmModels.collectAsState()
    // mục 93 TECHNICAL_STATUS.md — "So Sánh Thử" PromptStyle
    val isRunningTest by vm.isRunningPromptStyleTest.collectAsState()
    val testResult by vm.promptStyleTestResult.collectAsState()
    var showGuide by remember { mutableStateOf(false) }
    // Model đã convert sẵn (mục 12/14 TECHNICAL_STATUS.md — hệ model_manifest.json
    // mới, KHÁC hẳn settings.sdModelPath/loraPath cũ đã deprecated). LoRA giờ
    // gán RIÊNG từng nhân vật qua CharactersScreen (mục 14), không còn 1
    // "LoRA mặc định" chung cho cả truyện nữa — bỏ hẳn dropdown đó ở đây.
    val convertedModels = remember { vm.storyManager.listConvertedModels() }
    // mục 66 TECHNICAL_STATUS.md — cần danh sách nhân vật thật của truyện đang
    // mở để đổi rule routing từ free-text sang chip chọn (chống gõ sai tên).
    val currentStory by vm.currentStory.collectAsState()
    val scope = rememberCoroutineScope()
    var fingerprintResult by remember { mutableStateOf<String?>(null) }
    var fingerprintError by remember { mutableStateOf<String?>(null) }
    var checkingConnection by remember { mutableStateOf(false) }
    var llmApiChecking by remember { mutableStateOf(false) }
    var llmApiResult by remember { mutableStateOf<String?>(null) }
    var llmApiError by remember { mutableStateOf<String?>(null) }

    var expandModel by remember { mutableStateOf(true) }
    var expandSize by remember { mutableStateOf(true) }
    var expandPostProc by remember { mutableStateOf(true) }
    var expandAdvanced by remember { mutableStateOf(false) }
    var expandSystem by remember { mutableStateOf(false) }
    var expandRemote by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Cài đặt & Model") },
                actions = { IconButton(onClick = { vm.rescanModels(); vm.rescanConsistencySources() }) { Icon(Icons.Default.Refresh, null, tint = C.Blue) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        bottomBar = { AppNavBar(nav, "settings") },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                // mục 155 TECHNICAL_STATUS.md — lối vào Help thứ 2 (đã có ở
                // TopAppBar của StoryListScreen/StoryDetailScreen) — thêm ở
                // đây vì Cài đặt cũng là nơi user hay tìm hướng dẫn.
                Surface(onClick = { nav.navigate("help") }, color = C.S1, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Border)) {
                    Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Help, null, tint = C.T2, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Trợ giúp — hướng dẫn sử dụng", color = C.T1, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null, tint = C.T3)
                    }
                }
            }

            item {
                Surface(onClick = { showGuide = !showGuide }, color = C.PurpleDim, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Purple.copy(0.4f))) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.FolderOpen, null, tint = C.Purple, modifier = Modifier.size(18.dp))
                            Text("📁 Hướng dẫn đặt model", color = C.Purple, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Icon(if (showGuide) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = C.Purple)
                        }
                        if (showGuide) {
                            Spacer(Modifier.height(8.dp))
                            Text(vm.modelSetupGuide(), color = C.T2, fontSize = 11.sp, fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                        }
                    }
                }
            }

            item {
                var showHw by remember { mutableStateOf(false) }
                Surface(onClick = { showHw = !showHw }, color = C.GreenDim, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Green.copy(0.4f))) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Speed, null, tint = C.Green, modifier = Modifier.size(18.dp))
                            Text("⚙️ Tối ưu phần cứng (tự động)", color = C.Green, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Icon(if (showHw) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = C.Green)
                        }
                        Text("Không hardcode cho máy cụ thể — tự phát hiện chipset, GPU, RAM mỗi lần chạy.",
                            color = C.T2, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 4.dp))
                        if (showHw) {
                            Spacer(Modifier.height(8.dp))
                            Text(vm.hardwareSummary(), color = C.T2, fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                        }
                    }
                }
            }

            item {
                SettingsSectionHeader("📦", "Model & Checkpoint", expandModel) { expandModel = !expandModel }
            }

            if (expandModel) {
            item {
                MlCard {
                    MlLabel("trạng thái model")
                    vm.modelStatus().forEach { (name, ok) ->
                        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (ok) Icons.Default.CheckCircle else Icons.Default.Cancel, null,
                                tint = if (ok) C.Green else C.Red, modifier = Modifier.size(16.dp))
                            Text(name, color = C.T1, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Text(if (ok) "sẵn sàng" else "thiếu", color = if (ok) C.Green else C.Red, fontSize = 11.sp)
                        }
                    }
                }
            }
            item {
                // mục 161 TECHNICAL_STATUS.md (đợt 3) — "#4 Dynamic Model
                // Delivery". Đặt Ở DƯỚI khối "trạng thái model" (không thay
                // thế) — khối trên vẫn giữ nguyên nghĩa cũ (tổng quan
                // has*() theo TÍNH NĂNG), khối này liệt kê CHI TIẾT từng
                // FILE (model base + shared: ESRGAN/YOLO-pose/MobileSAM) và
                // cho tải trực tiếp NẾU model_manifest.json có khai URL.
                // Rỗng danh sách -> ẩn hẳn card này (không hiện card trống
                // gây rối mắt) — xảy ra khi chưa convert model nào VÀ chưa
                // khai sharedDownloads.
                val downloadProgress by vm.downloadProgress.collectAsState()
                val downloadErrors by vm.downloadErrors.collectAsState()
                val isDownloading by vm.isDownloading.collectAsState()
                val allTargets = remember(convertedModels) {
                    (convertedModels.flatMap { vm.listDownloadTargets(it.id) } + vm.listDownloadTargets(null))
                }
                if (allTargets.isNotEmpty()) {
                    MlCard {
                        MlLabel("tải model tự động (mục 161)")
                        Text(
                            "Chỉ hoạt động nếu model_manifest.json đã khai URL — mặc định KHÔNG có URL nào " +
                            "(Claude không tự host được model, xem HUONG_DAN_SU_DUNG.md). File chưa khai URL " +
                            "vẫn phải tự tải/copy tay như trước.",
                            color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        val missingWithUrl = allTargets.filter { !it.exists && it.url != null }
                        if (missingWithUrl.isNotEmpty()) {
                            MlOutlineBtn(
                                if (isDownloading) "Đang tải (${missingWithUrl.size} file)..." else "Tải tất cả (${missingWithUrl.size} file còn thiếu)",
                                icon = Icons.Default.Download, enabled = !isDownloading,
                                onClick = { vm.downloadModelFiles(missingWithUrl) }
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                        allTargets.forEach { t ->
                            val key = t.destFile.absolutePath
                            val prog = downloadProgress[key]
                            val err = downloadErrors[key]
                            Row(Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (t.exists) Icons.Default.CheckCircle
                                    else if (err != null) Icons.Default.Error
                                    else if (t.url != null) Icons.Default.CloudDownload
                                    else Icons.Default.Cancel,
                                    null,
                                    tint = if (t.exists) C.Green else if (err != null) C.Red else if (t.url != null) C.Blue else C.T3,
                                    modifier = Modifier.size(14.dp)
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(t.label, color = C.T1, fontSize = 11.sp)
                                    if (prog != null && !t.exists) {
                                        val (done, total) = prog
                                        Text(
                                            if (total > 0) "${done / 1_000_000}MB / ${total / 1_000_000}MB" else "${done / 1_000_000}MB...",
                                            color = C.T3, fontSize = 9.sp
                                        )
                                    } else if (err != null) {
                                        Text("Lỗi: $err", color = C.Red, fontSize = 9.sp)
                                    } else if (!t.exists && t.url == null) {
                                        Text("chưa khai URL — tự tải tay", color = C.T3, fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item {
                MlCard {
                    MlLabel("chọn model")
                    // SD Model: chọn theo id trong model_manifest.json (hệ MNN mới),
                    // KHÔNG còn 1 file .safetensors đơn lẻ như trước (mục 9/12
                    // TECHNICAL_STATUS.md — sdModelPath đã deprecated).
                    if (convertedModels.isEmpty()) {
                        Text("Chưa có model nào convert xong — xem hướng dẫn ở trên (prepare_models.yml).",
                            color = C.Orange, fontSize = 11.sp)
                    } else {
                        Text("SD Model (id trong model_manifest.json):", color = C.T3, fontSize = 11.sp)
                        Spacer(Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(convertedModels) { m ->
                                val sel = settings.sdModelId == m.id
                                FilterChip(selected = sel, onClick = {
                                    // mục 64 TECHNICAL_STATUS.md — chọn model npu_required=true
                                    // thì TỰ ĐỘNG bật luôn công tắc NPU (không bắt user phải tự
                                    // nhớ bật tay rồi mới sinh ảnh được — sdInit() sẽ từ chối
                                    // thẳng nếu NPU đang tắt cho model loại này).
                                    vm.updateSettings { copy(sdModelId = m.id, useNpu = if (m.npu_required) true else useNpu) }
                                }, label = { Text(m.display_name.take(20) + if (m.npu_required) " ⚡NPU" else "", fontSize = 11.sp) })
                            }
                        }
                        if (convertedModels.any { it.id == settings.sdModelId && it.npu_required }) {
                            Spacer(Modifier.height(4.dp))
                            Text("⚡ Model đang chọn BẮT BUỘC NPU thật — không chạy được bằng GPU/CPU (mục 64 TECHNICAL_STATUS.md).",
                                color = C.Orange, fontSize = 11.sp, lineHeight = 13.sp)
                        }

                        // mục 93 TECHNICAL_STATUS.md — khai báo PromptStyle
                        // cho checkpoint đang chọn. Đặt NGAY DƯỚI ô chọn
                        // model để rõ ràng đang khai báo cho model NÀO.
                        Spacer(Modifier.height(14.dp))
                        Divider(color = C.Border)
                        Spacer(Modifier.height(14.dp))
                        MlLabel("kiểu prompt checkpoint này mong đợi")
                        Text(
                            "KHÔNG có cách tự dò chắc chắn từ file checkpoint — bạn cần tự khai báo. " +
                            "Cách tra: mở trang model (Civitai/HuggingFace) tìm mục \"Recommended prompt\"/" +
                            "\"Trigger words\"/\"How to use\". Thấy ví dụ dạng \"1girl, blue hair, dress\" " +
                            "(cụm từ ngắn cách nhau bằng dấu phẩy) → chọn Tag-based. Thấy ví dụ dạng câu văn " +
                            "(\"a girl with blue hair wearing a dress\") → chọn Ngôn ngữ tự nhiên. Không thấy " +
                            "ghi gì cả → bấm \"So sánh thử\" bên dưới, tự nhìn ảnh nào mạch lạc hơn.",
                            color = C.T3, fontSize = 11.sp, lineHeight = 14.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        val curStyle = settings.promptStyleOverrides[settings.sdModelId] ?: PromptStyle.TAG_BASED
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = curStyle == PromptStyle.TAG_BASED,
                                onClick = { vm.updateSettings { copy(promptStyleOverrides = promptStyleOverrides + (sdModelId to PromptStyle.TAG_BASED)) } },
                                label = { Text("Tag-based", fontSize = 11.sp) })
                            FilterChip(selected = curStyle == PromptStyle.NATURAL_LANGUAGE,
                                onClick = { vm.updateSettings { copy(promptStyleOverrides = promptStyleOverrides + (sdModelId to PromptStyle.NATURAL_LANGUAGE)) } },
                                label = { Text("Ngôn ngữ tự nhiên", fontSize = 11.sp) })
                        }

                        Spacer(Modifier.height(10.dp))
                        var testDesc by remember { mutableStateOf("một cô gái tóc dài đứng trong công viên, trời nắng") }
                        OutlinedTextField(
                            value = testDesc, onValueChange = { testDesc = it },
                            label = { Text("Mô tả để chạy thử (bất kỳ, không cần liên quan truyện)", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(), textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp)
                        )
                        Spacer(Modifier.height(6.dp))
                        MlBtn(
                            text = if (isRunningTest) "Đang chạy thử (2 ảnh nhanh, độ phân giải thấp)..." else "🔬 So sánh thử",
                            icon = Icons.Default.Refresh,
                            enabled = !isRunningTest,
                            onClick = { vm.runPromptStyleComparisonTest(testDesc) }
                        )
                        Text("Sinh 2 ảnh 384×384, 15 bước, CÙNG 1 seed (chỉ khác kiểu prompt) — nhanh nhưng chất " +
                            "lượng thấp hơn ảnh thật, chỉ để so sánh MẠCH LẠC, không phản ánh đúng chất lượng cuối.",
                            color = C.T3, fontSize = 11.sp, lineHeight = 13.sp)

                        testResult?.let { r ->
                            Spacer(Modifier.height(10.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text("Tag-based", color = C.T2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    Box(Modifier.fillMaxWidth().aspectRatio(1f).background(C.S0, RoundedCornerShape(8.dp)).clip(RoundedCornerShape(8.dp))) {
                                        coil.compose.AsyncImage(model = java.io.File(r.tagBasedImagePath), contentDescription = null, modifier = Modifier.fillMaxSize())
                                    }
                                    MlBtn(text = "Chọn kiểu này", icon = Icons.Default.Refresh, onClick = {
                                        vm.updateSettings { copy(promptStyleOverrides = promptStyleOverrides + (sdModelId to PromptStyle.TAG_BASED)) }
                                        vm.dismissPromptStyleTestResult()
                                    })
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("Ngôn ngữ tự nhiên", color = C.T2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    Box(Modifier.fillMaxWidth().aspectRatio(1f).background(C.S0, RoundedCornerShape(8.dp)).clip(RoundedCornerShape(8.dp))) {
                                        coil.compose.AsyncImage(model = java.io.File(r.naturalLanguageImagePath), contentDescription = null, modifier = Modifier.fillMaxSize())
                                    }
                                    MlBtn(text = "Chọn kiểu này", icon = Icons.Default.Refresh, onClick = {
                                        vm.updateSettings { copy(promptStyleOverrides = promptStyleOverrides + (sdModelId to PromptStyle.NATURAL_LANGUAGE)) }
                                        vm.dismissPromptStyleTestResult()
                                    })
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    ModelDropdown("LLM Model", settings.llmModelPath, llmModels,
                        onSelect = { vm.updateSettings { copy(llmModelPath = it.path) } }, onRescan = { vm.rescanModels() })
                    Spacer(Modifier.height(8.dp))
                    Text("LoRA giờ gán RIÊNG từng nhân vật qua màn hình Nhân vật (mục 14 TECHNICAL_STATUS.md), " +
                        "không còn 1 LoRA mặc định chung ở đây.", color = C.T3, fontSize = 11.sp, lineHeight = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    Text("Hướng dẫn viết kịch bản cho LLM", color = C.T2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text("Áp dụng cho MỌI truyện — mô tả văn phong, nhịp độ/tốc độ, cách thiết lập bối cảnh, " +
                        "biến tấu/twist bạn muốn, v.v. Để trống = LLM tự quyết hoàn toàn, không ép gì thêm.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = settings.llmStoryGuidance,
                        onValueChange = { vm.updateSettings { copy(llmStoryGuidance = it) } },
                        placeholder = { Text(
                            "Ví dụ: văn phong u tối, nhịp độ chậm rãi xây dựng không khí; " +
                            "thiết lập thế giới giả tưởng thời trung cổ; thỉnh thoảng chèn twist bất ngờ ở cuối chương...",
                            fontSize = 11.sp, color = C.T3
                        ) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                        minLines = 3
                    )
                }
            }
            item {
                MlCard {
                    MlLabel("sdxl (thử nghiệm — mục 184 TECHNICAL_STATUS.md, đọc kỹ trước khi bật)")
                    Text("Pipeline SDXL HOÀN TOÀN TÁCH BIỆT với \"chọn model\" ở trên (SD1.5) — cần bộ " +
                        "model .mnn convert riêng, đặt trong 1 thư mục con RIÊNG của modelsDir (xem " +
                        "prepare_models.yml, HUONG_DAN_SU_DUNG.md mục 3.5). TOÀN BỘ đường SDXL — cả " +
                        "pipeline lẫn phần chọn/nối dây ở thẻ này — CHƯA build-test/CHƯA chạy thử thật " +
                        "lần nào (không có GPU/thiết bị thật lúc viết). Bật lên có thể sinh ảnh lỗi, " +
                        "rất chậm, hoặc crash. SD1.5 vẫn là lựa chọn mặc định/an toàn — chỉ bật nếu bạn " +
                        "chấp nhận rủi ro và muốn tự thử nghiệm.",
                        color = C.Orange, fontSize = 11.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Dùng SDXL thay vì SD1.5 (mặc định cho panel không override riêng)",
                            color = C.T2, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Switch(checked = settings.defaultModelTier == ImageModelTier.SDXL, onCheckedChange = { checked ->
                            vm.updateSettings { copy(defaultModelTier = if (checked) ImageModelTier.SDXL else ImageModelTier.SD15) }
                        })
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = settings.sdxlModelId ?: "",
                        onValueChange = { vm.updateSettings { copy(sdxlModelId = it.ifBlank { null }) } },
                        label = { Text("Tên thư mục model SDXL (trong modelsDir, vd \"sdxl_augmented_v1\")", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                        singleLine = true
                    )
                    // mục 189 TECHNICAL_STATUS.md — chọn độ phân giải SDXL.
                    // CHỈ 2 lựa chọn (768/1024), KHÔNG có 512 — SDXL không có
                    // bucket huấn luyện vuông nào dưới 1024², ép xuống 512
                    // từng ghi nhận sinh lỗi giải phẫu (nhân đôi người/chi
                    // thể) ở 1 số seed — phản tác dụng với đúng mục đích
                    // Quality Gate/SDXL-thay-thế (mục 185) đang cố tránh.
                    Spacer(Modifier.height(8.dp))
                    Text("Độ phân giải SDXL", color = C.T2, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = settings.sdxlResolution == 1024, onClick = { vm.updateSettings { copy(sdxlResolution = 1024) } },
                            label = { Text("1024×1024 (đúng chuẩn, chậm hơn)", fontSize = 11.sp) })
                        FilterChip(selected = settings.sdxlResolution == 768, onClick = { vm.updateSettings { copy(sdxlResolution = 768) } },
                            label = { Text("768×768 (nhẹ hơn ~44%, chưa chuẩn)", fontSize = 11.sp) })
                    }
                    Text("Không có lựa chọn 512 — SDXL không huấn luyện ở cỡ vuông đó, từng ghi nhận sinh lỗi " +
                        "giải phẫu (thừa người/chi) thay vì chỉ mờ hơn.",
                        color = C.T3, fontSize = 9.sp, lineHeight = 12.sp)
                    // mục 191 TECHNICAL_STATUS.md — cảnh báo QUAN TRỌNG, đóng
                    // gap thật (không phải chỉ nhắc lại): model SDXL .mnn
                    // export CỐ ĐỊNH ở 1 độ phân giải (KHÔNG dynamic_axes —
                    // mục 52b), lựa chọn ở đây KHÔNG tự đổi được shape lúc
                    // chạy — phải khớp ĐÚNG giá trị `sdxl_image_size` đã dùng
                    // khi chạy prepare_models.yml để tạo ra thư mục
                    // `sdxlModelId` đang khai bên dưới. Chọn sai = lệch shape,
                    // sinh ảnh lỗi/crash.
                    Spacer(Modifier.height(4.dp))
                    Text("⚠ QUAN TRỌNG: lựa chọn này phải khớp đúng giá trị \"sdxl_image_size\" đã dùng khi " +
                        "chạy prepare_models.yml để export model — model chỉ chạy đúng ở ĐÚNG độ phân giải đã " +
                        "export ra (không tự đổi được lúc chạy app). Muốn dùng cả 2 mức, chạy workflow 2 lần " +
                        "và copy vào 2 thư mục model riêng trên máy.",
                        color = C.Orange, fontSize = 9.sp, lineHeight = 12.sp)
                    val sdxlId = settings.sdxlModelId
                    if (sdxlId.isNullOrBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text("Chưa khai tên thư mục — dù bật switch trên, MangaPipeline sẽ tự rơi về " +
                            "SD1.5 cho mọi panel (không lỗi, chỉ không dùng được SDXL).",
                            color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                    } else {
                        Spacer(Modifier.height(8.dp))
                        // mục 184 — chỉ dò thử N=2 cho có ý nghĩa hiển thị nhanh;
                        // N thật (3/4/5...) được tự dò lại ĐÚNG lúc sinh ảnh thật
                        // trong dispatchSdxlPanel(), KHÔNG giới hạn ở N=2 này.
                        val hasAug = vm.storyManager.hasAugmentedSdxlUnet(sdxlId)
                        val hasMask2 = vm.storyManager.hasMultiCharMaskSdxlUnet(sdxlId, 2)
                        val hasReg2 = vm.storyManager.hasRegionalSdxlUnet(sdxlId, 2)
                        val hasRegMask2 = vm.storyManager.hasRegionalMaskSdxlUnet(sdxlId, 2)
                        Text("Phát hiện trong \"$sdxlId\": augmented 1-người ${if (hasAug) "✓" else "✗"} · " +
                            "mask 2-người ${if (hasMask2) "✓" else "✗"} · regional cột-2 ${if (hasReg2) "✓" else "✗"} · " +
                            "regional-mask 2 ${if (hasRegMask2) "✓" else "✗"} (chỉ dò thử N=2, N khác tự dò lúc sinh ảnh thật).",
                            color = if (hasAug) C.T3 else C.Orange, fontSize = 10.sp, lineHeight = 13.sp)
                        if (!hasAug) {
                            Spacer(Modifier.height(4.dp))
                            Text("⚠ Chưa thấy đủ unet_ipa_controlnet_sdxl.mnn + ip_image_encoder_sdxl.mnn trong " +
                                "thư mục này — panel không có model N-nhân-vật/regional phù hợp SẼ KHÔNG sinh " +
                                "được bằng SDXL (tự rơi về SD1.5). Xem prepare_models.yml.",
                                color = C.Orange, fontSize = 10.sp, lineHeight = 13.sp)
                        }
                        // mục 192 TECHNICAL_STATUS.md — hiển thị độ phân giải
                        // THẬT đọc từ marker file sdxl_resolution.txt (ghi bởi
                        // prepare_models.yml lúc export) — đóng vòng phản hồi:
                        // user KHÔNG cần tự nhớ đã export ở đâu nữa, app tự
                        // đọc và báo khớp/lệch với lựa chọn đang chọn ở trên.
                        Spacer(Modifier.height(4.dp))
                        val exportedRes = vm.storyManager.readSdxlExportedResolution(sdxlId)
                        if (exportedRes == null) {
                            Text(if (settings.sdxlResolution == 768)
                                    "⚠ Độ phân giải THẬT: không rõ (thiếu file sdxl_resolution.txt) — mọi model " +
                                    "cũ chưa có file này CHẮC CHẮN là 1024 (768 chỉ mới hỗ trợ export từ bản " +
                                    "này) nên app sẽ TỰ DÙNG 1024, bỏ qua lựa chọn 768 ở trên."
                                else
                                    "Độ phân giải THẬT: không rõ (thiếu file sdxl_resolution.txt) — model cũ " +
                                    "kiểu này luôn là 1024, khớp đúng lựa chọn ở trên ✓",
                                color = if (settings.sdxlResolution == 768) C.Orange else C.T3,
                                fontSize = 9.sp, lineHeight = 12.sp)
                        } else if (exportedRes == settings.sdxlResolution) {
                            Text("Độ phân giải THẬT: ${exportedRes}×${exportedRes} — khớp đúng lựa chọn ở trên ✓",
                                color = C.Green, fontSize = 9.sp, lineHeight = 12.sp)
                        } else {
                            Text("⚠ Độ phân giải THẬT: ${exportedRes}×${exportedRes} — LỆCH với lựa chọn " +
                                "${settings.sdxlResolution}×${settings.sdxlResolution} ở trên. App sẽ tự dùng " +
                                "đúng $exportedRes×$exportedRes (theo model thật) — đổi lựa chọn ở trên cho " +
                                "khớp để hết cảnh báo này.",
                                color = C.Orange, fontSize = 9.sp, lineHeight = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Chưa có UI chọn riêng theo TỪNG panel (batch-select ở màn hình duyệt ảnh) — " +
                        "công tắc này áp dụng CHUNG cho cả chương, trừ khi 1 panel cụ thể đã có " +
                        "modelTierOverride riêng (hiện chỉ đặt được qua sửa dữ liệu tay, chưa có nút bấm).",
                        color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                }
            }
            item {
                MlCard {
                    MlLabel("llm ngoài (api — tuỳ chọn, mặc định vẫn dùng model local)")
                    Text("Dùng LLM qua API ngoài (OpenAI/OpenRouter/Groq hay server tự host tương thích OpenAI) " +
                        "THAY VÌ model .gguf local — hữu ích khi máy yếu hoặc muốn model mạnh hơn. " +
                        "⚠ Khác Remote GPU (ảnh): đây là API thật của bên thứ 3, chỉ có TLS chuẩn bảo vệ, " +
                        "không có lớp mã hoá riêng nào của app. Đừng gửi nội dung thực sự riêng tư qua đây.",
                        color = C.Orange, fontSize = 11.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật LLM ngoài", color = C.T1, fontSize = 13.sp)
                            Text("Tắt = luôn dùng model local như trước, không đổi gì cả", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.externalLlm.enabled,
                            onCheckedChange = { vm.updateSettings { copy(externalLlm = externalLlm.copy(enabled = it)) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }

                    if (settings.externalLlm.enabled) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = settings.externalLlm.baseUrl,
                            onValueChange = { vm.updateSettings { copy(externalLlm = externalLlm.copy(baseUrl = it)) } },
                            label = { Text("Base URL (vd https://api.openai.com/v1)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = settings.externalLlm.apiKey,
                            onValueChange = { vm.updateSettings { copy(externalLlm = externalLlm.copy(apiKey = it)) } },
                            label = { Text("API key") },
                            singleLine = true, modifier = Modifier.fillMaxWidth(),
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = settings.externalLlm.modelName,
                            onValueChange = { vm.updateSettings { copy(externalLlm = externalLlm.copy(modelName = it)) } },
                            label = { Text("Tên model (vd gpt-4o-mini, anthropic/claude-3.5-sonnet...)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            enabled = !llmApiChecking && settings.externalLlm.baseUrl.isNotBlank() && settings.externalLlm.modelName.isNotBlank(),
                            onClick = {
                                llmApiChecking = true; llmApiResult = null; llmApiError = null
                                scope.launch {
                                    try {
                                        val reply = com.mangalocal.pipeline.ExternalLlmClient(settings.externalLlm).testConnection()
                                        llmApiResult = reply.trim()
                                    } catch (ex: Exception) {
                                        llmApiError = ex.message ?: "Lỗi không rõ"
                                    } finally { llmApiChecking = false }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (llmApiChecking) "Đang kiểm tra..." else "Kiểm tra kết nối") }
                        llmApiResult?.let { r ->
                            Spacer(Modifier.height(6.dp))
                            Text("✓ API phản hồi: \"$r\"", color = C.Green, fontSize = 11.sp)
                        }
                        llmApiError?.let { err ->
                            Spacer(Modifier.height(6.dp))
                            Text("✗ $err", color = C.Red, fontSize = 11.sp)
                        }
                    }
                }
            }
            item {
                MlCard {
                    MlLabel("nhập model (từ file trên máy)")
                    Text("Bộ nhớ app nằm ở Android/data/com.mangalocal/files — khó vào bằng trình quản lý " +
                        "file ngoài trên Android 11+. Dùng các nút dưới đây để chọn file/thư mục TỪ BẤT KỲ ĐÂU " +
                        "(Tải xuống, Google Drive, thẻ nhớ...) — app tự copy vào đúng chỗ cần, không cần tự " +
                        "mò vào thư mục app.", color = C.T3, fontSize = 11.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(10.dp))

                    val pickLlm = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
                        if (it.isNotEmpty()) vm.importLlmModels(it)
                    }
                    val pickLora = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
                        if (it.isNotEmpty()) vm.importLoras(it)
                    }
                    val pickEmbedding = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
                        if (it.isNotEmpty()) vm.importEmbeddingSources(it)
                    }
                    val pickYolo = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
                        if (it.isNotEmpty()) vm.importYoloModels(it)
                    }
                    val pickEsrgan = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
                        if (it.isNotEmpty()) vm.importEsrganModels(it)
                    }

                    MlOutlineBtn("Nhập LLM (.gguf)", onClick = { pickLlm.launch(arrayOf("*/*")) }, icon = Icons.Default.UploadFile)
                    Spacer(Modifier.height(8.dp))
                    MlOutlineBtn("Nhập LoRA (.safetensors)", onClick = { pickLora.launch(arrayOf("*/*")) }, icon = Icons.Default.UploadFile)
                    Spacer(Modifier.height(14.dp))
                    Divider(color = C.Border)
                    Spacer(Modifier.height(10.dp))
                    // mục 69 TECHNICAL_STATUS.md — LoRA Addon (chất lượng chung, TOÀN
                    // CỤC — khác LoRA nhân vật ở trên, xem Models.kt.AddonLora). Đối
                    // chiếu review mục 66: SAI khi nói "tầng dữ liệu đã có, chỉ thiếu
                    // UI" — thêm cả 2 từ đầu trong mục này.
                    Text("LoRA Addon (chất lượng chung — áp dụng CHO MỌI nhân vật/model)", color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("⚠️ Pipeline chỉ merge LoRA lúc CONVERT, không nạp được lúc sinh ảnh — thêm/bật/tắt/đổi trọng số ở đây CHỈ áp dụng cho model convert TỪ SAU thời điểm này. Model đã convert trước đó cần convert lại (Nhân vật → sửa → Convert lại) mới nhận addon mới.",
                        color = C.Orange, fontSize = 11.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    var addons by remember { mutableStateOf(vm.addonLoras()) }
                    addons.forEach { addon ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Switch(checked = addon.enabled, onCheckedChange = { vm.setAddonLoraEnabled(addon.id, it); addons = vm.addonLoras() },
                                colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                            Column(Modifier.weight(1f).padding(start = 6.dp)) {
                                Text(addon.displayName, color = C.T1, fontSize = 12.sp)
                                Text("weight ${"%.2f".format(addon.weight)}", color = C.T3, fontSize = 11.sp)
                            }
                            IconButton(onClick = { vm.removeAddonLora(addon.id); addons = vm.addonLoras() }) {
                                Icon(Icons.Default.Delete, null, tint = C.T3, modifier = Modifier.size(18.dp))
                            }
                        }
                        Slider(value = addon.weight, onValueChange = { vm.setAddonLoraWeight(addon.id, it); addons = vm.addonLoras() },
                            valueRange = 0f..1.5f, colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue))
                    }
                    var newAddonName by remember { mutableStateOf("") }
                    OutlinedTextField(value = newAddonName, onValueChange = { newAddonName = it },
                        placeholder = { Text("Tên hiển thị (vd \"Chất lượng anime chung\")", fontSize = 11.sp) },
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    val pickAddonLora = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                        if (uri != null) { vm.addAddonLora(uri, newAddonName); newAddonName = ""; addons = vm.addonLoras() }
                    }
                    MlOutlineBtn("Thêm Addon LoRA (.safetensors)", onClick = { pickAddonLora.launch(arrayOf("*/*")) }, icon = Icons.Default.UploadFile)
                    Spacer(Modifier.height(8.dp))
                    MlOutlineBtn("Nhập embedding gốc (.safetensors)", onClick = { pickEmbedding.launch(arrayOf("*/*")) }, icon = Icons.Default.UploadFile)
                    Spacer(Modifier.height(8.dp))
                    MlOutlineBtn("Nhập model YOLO/MobileSAM (.mnn)", onClick = { pickYolo.launch(arrayOf("*/*")) }, icon = Icons.Default.UploadFile)
                    Spacer(Modifier.height(8.dp))
                    MlOutlineBtn("Nhập model ESRGAN (.mnn)", onClick = { pickEsrgan.launch(arrayOf("*/*")) }, icon = Icons.Default.UploadFile)

                    Spacer(Modifier.height(14.dp))
                    Divider(color = C.Border)
                    Spacer(Modifier.height(10.dp))
                    Text("Model SD (nhiều file: clip/unet/vae.../tokenizer) — chọn CẢ THƯ MỤC chứa các file đó " +
                        "(vd thư mục \"release\" tải từ prepare_models.yml). Đặt tên ID khớp với model_manifest.json " +
                        "để app nhận diện đúng model.", color = C.T3, fontSize = 11.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    var sdModelId by remember { mutableStateOf("") }
                    OutlinedTextField(
                        value = sdModelId, onValueChange = { sdModelId = it },
                        label = { Text("ID model (tên thư mục con trong models/)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    val pickSdFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
                        if (uri != null) {
                            context.contentResolver.takePersistableUriPermission(
                                uri,
                                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            )
                            vm.importSdModelFolder(uri, sdModelId)
                        }
                    }
                    MlOutlineBtn("Chọn thư mục model SD...",
                        onClick = { pickSdFolder.launch(null) }, icon = Icons.Default.FolderOpen)
                }
            }
            }

            item {
                SettingsSectionHeader("🖼️", "Kích thước, chất lượng & tham số sinh ảnh", expandSize) { expandSize = !expandSize }
            }

            if (expandSize) {
            item {
                MlCard {
                    MlLabel("kích thước & phong cách")
                    // mục 96 TECHNICAL_STATUS.md — đọc default_width/height
                    // của CHECKPOINT ĐANG CHỌN (mục 59 đã thêm field vào
                    // model_manifest.json nhưng chưa có Kotlin nào đọc) —
                    // SDXL cần ~1024, chip cố định cũ (384-768) không đủ,
                    // chọn nhầm 512 cho SDXL sẽ ra ảnh kém (không phải lỗi,
                    // chỉ là dưới mức chất lượng model đó được thiết kế).
                    val activeModel = convertedModels.find { it.id == settings.sdModelId }
                    // mục 161 TECHNICAL_STATUS.md (đợt 5) — TRƯỚC ĐÂY chỉ
                    // xử lý trường hợp default_width == default_height
                    // (vuông) — recommendedSize (Int? đơn) không diễn tả
                    // được model có default KHÔNG VUÔNG (vd 768x512, mục
                    // "#3 Dynamic Axes" thu hẹp). Đổi sang cặp
                    // recommendedW/recommendedH riêng biệt — vuông vẫn hoạt
                    // động y hệt cũ (recommendedW==recommendedH), KHÔNG
                    // VUÔNG giờ hiện được đúng.
                    val recommendedW = activeModel?.default_width
                    val recommendedH = activeModel?.default_height
                    val isRecommendedSquare = recommendedW != null && recommendedW == recommendedH
                    val baseChips = listOf(384, 512, 640, 768)
                    val chips = if (isRecommendedSquare && recommendedW !in baseChips)
                        (baseChips + recommendedW!!).sorted() else baseChips

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Kích thước ảnh gốc", color = C.T2, fontSize = 12.sp)
                        Text("${settings.width}x${settings.height}", color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    // mục 161 (đợt 5) — checkpoint KHÔNG vuông (VD profile
                    // 768x512 "ngang", 512x768 "dọc") hiện 1 nút riêng NGOÀI
                    // dải chip vuông — bấm là áp ĐÚNG cặp width/height thật
                    // của checkpoint (KHÔNG ép user tự đoán/gõ tay 2 số).
                    if (recommendedW != null && recommendedH != null && !isRecommendedSquare) {
                        val selNonSquare = settings.width == recommendedW && settings.height == recommendedH
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (selNonSquare) C.Blue.copy(alpha = 0.2f) else C.S2,
                            border = BorderStroke(1.dp, if (selNonSquare) C.Blue else C.Border),
                            modifier = Modifier.clickable { vm.updateSettings { copy(width = recommendedW, height = recommendedH) } }
                        ) {
                            Text("★ ${recommendedW}x${recommendedH} (đúng tỷ lệ checkpoint này)",
                                color = if (selNonSquare) C.Blue else C.T2, fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Checkpoint đang chọn (${activeModel?.display_name}) là bản KHÔNG VUÔNG " +
                            "(${recommendedW}x${recommendedH}) — dùng chip vuông bên dưới VẪN chạy được nếu " +
                            "checkpoint có cả 2 bản (kiểm tra model_manifest.json), nhưng sẽ dùng SAI file " +
                            "UNet/VAE nếu bạn tự đổi model_manifest.json mà không hiểu cơ chế này — an toàn nhất " +
                            "là dùng đúng nút ★ ở trên.",
                            color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
                        )
                        Spacer(Modifier.height(6.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        chips.forEach { sz ->
                            val sel = settings.width == sz && settings.height == sz
                            val isRecommended = isRecommendedSquare && sz == recommendedW
                            FilterChip(selected = sel, onClick = { vm.updateSettings { copy(width = sz, height = sz) } },
                                label = { Text("${sz}x${sz}${if (isRecommended) " ★" else ""}", fontSize = 11.sp) })
                        }
                    }
                    if (isRecommendedSquare && recommendedW != settings.width) {
                        Text("⚠ Checkpoint đang chọn (${activeModel?.display_name}) được thiết kế cho ${recommendedW}x${recommendedW} " +
                            "(đánh dấu ★) — dùng kích thước khác vẫn chạy được nhưng có thể ra ảnh kém hơn mức model này thật sự làm được.",
                            color = C.Orange, fontSize = 11.sp, lineHeight = 13.sp)
                    } else {
                        Text("512x512 khớp đúng SD1.5 gốc, kích thước khác vẫn chạy được nhưng bố cục có thể lệch tỷ lệ hơn.",
                            color = C.T3, fontSize = 11.sp, lineHeight = 13.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Không còn giới hạn số panel — số lớn giờ được LLM viết theo TỪNG ĐỢT nhỏ (chunked) " +
                        "thay vì 1 lần duy nhất, nên không còn bị cắt JSON giữa chừng nữa. Đánh đổi: số càng lớn " +
                        "càng tốn nhiều lượt gọi LLM hơn (chậm hơn khi phân tích truyện, KHÔNG ảnh hưởng tốc độ vẽ ảnh).",
                        color = C.T3, fontSize = 11.sp, lineHeight = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Số panel/chương", color = C.T2, fontSize = 12.sp)
                        // SỬA (yêu cầu bỏ giới hạn 30): trước đây dùng Slider
                        // valueRange = 1f..30f — Slider cần 1 khoảng CỐ ĐỊNH
                        // nên không thể "không giới hạn" đúng nghĩa. Đổi sang
                        // ô nhập số tự do, chỉ ép tối thiểu 1 (0 panel/số âm
                        // không có nghĩa), không ép trần trên nữa.
                        OutlinedTextField(
                            value = settings.panelCount.toString(),
                            onValueChange = { txt ->
                                val n = txt.filter { it.isDigit() }.toIntOrNull()
                                if (n != null) vm.updateSettings { copy(panelCount = n.coerceAtLeast(1)) }
                                else if (txt.isBlank()) vm.updateSettings { copy(panelCount = 1) }
                            },
                            modifier = Modifier.width(90.dp),
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Style mặc định", color = C.T3, fontSize = 11.sp)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(ImageStyle.values()) { style ->
                            val sel = settings.imageStyle == style
                            FilterChip(selected = sel, onClick = { vm.updateSettings { copy(imageStyle = style) } },
                                label = { Text("${style.emoji} ${style.label}", fontSize = 11.sp) })
                        }
                    }
                }
            }
            item {
                MlCard {
                    MlLabel("upscale")
                    UpscaleOption.values().forEach { opt ->
                        val sel = settings.upscaleOption == opt
                        Row(Modifier.fillMaxWidth().clickable { vm.updateSettings { copy(upscaleOption = opt) } }
                            .padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = sel, onClick = { vm.updateSettings { copy(upscaleOption = opt) } },
                                colors = RadioButtonDefaults.colors(selectedColor = C.Blue, unselectedColor = C.T3))
                            Text(opt.label, color = if (sel) C.T1 else C.T2, fontSize = 13.sp)
                        }
                    }
                }
            }
            item {
                MlCard {
                    MlLabel("tham số sinh ảnh")
                    @Composable
                    fun SlRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, fmt: String = "%.0f", onChange: (Float) -> Unit) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label, color = C.T2, fontSize = 12.sp)
                            Text(fmt.format(value), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(value = value, onValueChange = onChange, valueRange = range,
                            colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                        Spacer(Modifier.height(4.dp))
                    }
                    SlRow("Steps", settings.steps.toFloat(), 10f..30f) { vm.updateSettings { copy(steps = it.toInt()) } }
                    SlRow("CFG Scale", settings.cfgScale, 3f..15f, "%.1f") { vm.updateSettings { copy(cfgScale = it) } }
                    // mục 138 TECHNICAL_STATUS.md — SỬA BUG THẬT: Slider
                    // "Threads" TRƯỚC ĐÂY là UI VỎ RỖNG — kéo được, số hiển
                    // thị đổi, nhưng KHÔNG nơi nào trong pipeline đọc giá
                    // trị này (mọi nơi dùng `optimalConfig.nThreads` tự
                    // tính từ phần cứng, bỏ qua hoàn toàn). Đã nối thật qua
                    // `effectiveNThreads()`, kèm cờ Auto/Manual — mặc định
                    // Auto (giữ NGUYÊN hành vi tự-tối-ưu-theo-máy vốn là
                    // tính năng có chủ đích của `RuntimeOptimizer`, không
                    // đổi gì cho ai chưa đụng vào) — tắt Auto để override
                    // tay bằng Slider.
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Threads (tự động theo máy)", color = C.T2, fontSize = 12.sp)
                        }
                        Switch(checked = settings.nThreadsAutoDetect,
                            onCheckedChange = { vm.updateSettings { copy(nThreadsAutoDetect = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                    if (!settings.nThreadsAutoDetect) {
                        Spacer(Modifier.height(4.dp))
                        SlRow("Threads (tuỳ chỉnh tay)", settings.nThreads.toFloat(), 1f..8f) { vm.updateSettings { copy(nThreads = it.toInt()) } }
                        Text("Ghi đè số thread LLM tự động dò theo phần cứng — chỉ đổi khi bạn biết rõ máy mình, giá trị tự động thường đã tối ưu.",
                            color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Divider(color = C.Border, modifier = Modifier.padding(vertical = 8.dp))
                    // ĐÃ THAY "Vulkan GPU" (mục 25 TECHNICAL_STATUS.md — toggle CŨ
                    // KHÔNG được bất kỳ pipeline nào đọc, dead code từ trước khi
                    // đổi engine sang MNN) bằng useOpenCL THẬT — field này mới là
                    // cái ImagePipeline.loadSD() thực sự dùng.
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("OpenCL GPU", color = C.T1, fontSize = 13.sp)
                            Text("Tăng tốc GPU Adreno/Mali qua MNN (tắt = ép CPU, dùng để chẩn đoán lỗi)", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.useOpenCL, onCheckedChange = { vm.updateSettings { copy(useOpenCL = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                    Spacer(Modifier.height(6.dp))
                    // NPU/QNN (mục 60 TECHNICAL_STATUS.md) — TÁCH RIÊNG khỏi
                    // OpenCL ở trên (không phải "bật GPU sẽ tự thử NPU") —
                    // nói THẲNG trong mô tả rằng cần build đặc biệt, tránh
                    // user bật rồi tưởng máy chậm là do lỗi.
                    // mục 64 TECHNICAL_STATUS.md — model npu_required=true thì KHOÁ
                    // công tắc này ở trạng thái BẬT, không cho tắt (tắt được thì
                    // sdInit() sẽ từ chối chạy ngay, gây khó hiểu cho người dùng).
                    val currentModelNpuRequired = convertedModels.any { it.id == settings.sdModelId && it.npu_required }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("NPU (Qualcomm QNN) — thử nghiệm", color = C.T1, fontSize = 13.sp)
                            Text(
                                if (currentModelNpuRequired)
                                    "Model đang chọn BẮT BUỘC NPU — công tắc này bị khoá BẬT, không tắt được. Đổi sang model SD1.5 khác nếu muốn tắt."
                                else
                                    "Chỉ có tác dụng nếu bản APK được BUILD RIÊNG với QNN SDK (mặc định KHÔNG có) + máy có chip Snapdragon hỗ trợ. Bật trên bản thường vẫn AN TOÀN (tự rớt về OpenCL/CPU), chỉ là không nhanh hơn.",
                                color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.useNpu || currentModelNpuRequired,
                            enabled = !currentModelNpuRequired,
                            onCheckedChange = { vm.updateSettings { copy(useNpu = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                }
            }
            }

            item {
                SettingsSectionHeader("🩹", "Hoàn thiện ảnh (hires-fix · auto-fix · quality gate)", expandPostProc) { expandPostProc = !expandPostProc }
            }

            if (expandPostProc) {
            item {
                MlCard {
                    MlLabel("🖼️ hires-fix (ultrafix) — mục 16/20")
                    Text("Vẽ lại NHẸ toàn ảnh SAU khi ESRGAN phóng to, trước auto-fix mặt/tay — biến ranh giới " +
                        "nhòe/dính do phóng to thành nét sắc hơn. CHƯA BUILD-TEST, tốn thêm thời gian sinh đáng kể.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật Ultrafix", color = C.T1, fontSize = 13.sp)
                        }
                        Switch(checked = settings.useUltrafixRedraw, onCheckedChange = { vm.updateSettings { copy(useUltrafixRedraw = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                    }
                    if (settings.useUltrafixRedraw) {
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Denoising Strength", color = C.T2, fontSize = 12.sp)
                            Text("%.2f".format(settings.ultrafixDenoiseStrength), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(value = settings.ultrafixDenoiseStrength, onValueChange = { vm.updateSettings { copy(ultrafixDenoiseStrength = it) } },
                            valueRange = 0.2f..0.6f, colors = SliderDefaults.colors(thumbColor = C.Orange, activeTrackColor = C.Orange, inactiveTrackColor = C.Border))
                        Text("Thông số vàng cộng đồng: 0.35-0.45 — thấp hơn giữ nguyên bố cục, cao hơn đổi nhiều chi tiết hơn.",
                            color = C.T3, fontSize = 11.sp)
                    }
                }
            }
            item {
                MlCard {
                    MlLabel("🏭 industrial batch mode — mục 133")
                    Text("Đổi cách xử lý bước upscale: thay vì xen kẽ ESRGAN→Ultrafix→dò mặt/tay→inpaint " +
                        "TỪNG panel một (mọi model phải ở lại RAM cùng lúc suốt cả vòng lặp), tách thành 4 " +
                        "GIAI ĐOẠN tuần tự — mỗi giai đoạn xử lý TẤT CẢ panel bằng ĐÚNG 1 model rồi mới giải " +
                        "phóng, chuyển giai đoạn kế: (1) ESRGAN toàn bộ panel, (2) Ultrafix (SD) toàn bộ panel, " +
                        "(3) dò vùng + build mask (MobileSAM) toàn bộ panel, (4) SD vẽ lại theo mask toàn bộ " +
                        "panel. Ảnh ra GIỐNG HỆT chế độ cũ (chỉ đổi trình tự model nào resident lúc nào) — chỉ " +
                        "có ích để giảm RAM đỉnh trên máy RAM thấp, chậm hơn không đáng kể trên máy RAM dư dả. " +
                        "CHƯA BUILD-TEST.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật xử lý 4 giai đoạn", color = C.T1, fontSize = 13.sp)
                        }
                        Switch(checked = settings.industrialBatchUpscaleMode,
                            onCheckedChange = { vm.updateSettings { copy(industrialBatchUpscaleMode = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                    }
                }
            }
            item {
                MlCard {
                    MlLabel("🩹 auto-fix mặt/tay (adetailer-style) — mục 17/20")
                    Text("Tự dò vùng mặt/tay (tái dùng khung xương YOLOv8-pose, KHÔNG cần model riêng — mục 20) " +
                        "rồi vẽ lại qua img2img SAU auto-fix Ultrafix, ở độ phân giải cuối cùng. Không bắt được lỗi " +
                        "\"dính người\" tổng quát — chỉ mặt/tay. CHƯA BUILD-TEST.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật auto-fix mặt/tay", color = C.T1, fontSize = 13.sp)
                        }
                        Switch(checked = settings.autoFixFacesHands, onCheckedChange = { vm.updateSettings { copy(autoFixFacesHands = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                    }
                    if (settings.autoFixFacesHands) {
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Denoising Strength", color = C.T2, fontSize = 12.sp)
                            Text("%.2f".format(settings.autoFixDenoiseStrength), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(value = settings.autoFixDenoiseStrength, onValueChange = { vm.updateSettings { copy(autoFixDenoiseStrength = it) } },
                            valueRange = 0.3f..0.7f, colors = SliderDefaults.colors(thumbColor = C.Orange, activeTrackColor = C.Orange, inactiveTrackColor = C.Border))
                    }
                }
            }
            item {
                MlCard {
                    MlLabel("🔍 quality gate tự động (đếm chi + tỷ lệ xương) — mục 74")
                    Text("Tái dùng khung xương YOLOv8-pose đã detect sẵn (KHÔNG chạy inference thêm) " +
                        "để tự đếm chi/đo tỷ lệ xương, phát hiện lỗi giải phẫu rõ ràng và TỰ SINH LẠI " +
                        "tối đa 3 lần trước khi dùng ảnh ít lỗi nhất. Làm chậm đáng kể (thêm 1-3 lần UNet " +
                        "forward/panel) — khuyến nghị chỉ bật khi sinh cảnh nhiều nhân vật. CHƯA BUILD-TEST.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Bật Quality Gate", color = C.T1, fontSize = 13.sp) }
                        Switch(checked = settings.enableQualityGate, onCheckedChange = { vm.updateSettings { copy(enableQualityGate = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                    }
                    if (settings.enableQualityGate) {
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Dùng kho seed hoàn hảo (mục 75)", color = C.T1, fontSize = 13.sp)
                                Text("Ưu tiên seed đã pass gate ngay lần đầu cho panel cùng cấu trúc", color = C.T3, fontSize = 11.sp)
                            }
                            Switch(checked = settings.useSeedRegistry, onCheckedChange = { vm.updateSettings { copy(useSeedRegistry = it) } },
                                colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                        }

                        Spacer(Modifier.height(10.dp))
                        Divider(color = C.Border)
                        Spacer(Modifier.height(10.dp))
                        Text("Auto-fix vùng giao thoa hông/tay (≥2 nhân vật)", color = C.T1, fontSize = 13.sp)
                        Text("Phóng to vùng hông/tay 2+ người chồng lấn, inpaint denoise cao hơn để khâu sạch lỗi da thịt dính.",
                            color = C.T3, fontSize = 11.sp, lineHeight = 14.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Bật", color = C.T1, fontSize = 13.sp) }
                            Switch(checked = settings.autoFixInteractions, onCheckedChange = { vm.updateSettings { copy(autoFixInteractions = it) } },
                                colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                        }
                        if (settings.autoFixInteractions) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Denoise giao thoa", color = C.T2, fontSize = 12.sp)
                                Text("%.2f".format(settings.autoFixInteractionStrength), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Slider(value = settings.autoFixInteractionStrength, onValueChange = { vm.updateSettings { copy(autoFixInteractionStrength = it) } },
                                valueRange = 0.4f..0.75f, colors = SliderDefaults.colors(thumbColor = C.Orange, activeTrackColor = C.Orange, inactiveTrackColor = C.Border))
                            Text("Khuyến nghị 0.55 — cao hơn mặt/tay (0.45), đủ lực rebuild vùng giao thoa.", color = C.T3, fontSize = 11.sp)

                            // mục 94 TECHNICAL_STATUS.md — tính năng CON, chỉ
                            // hiện khi auto-fix giao thoa (cha) đã bật, vì
                            // dùng CHUNG vùng phát hiện tay-đè-lên-thân đã có
                            // sẵn, không phải cơ chế phát hiện riêng.
                            Spacer(Modifier.height(8.dp))
                            Divider(color = C.Border)
                            Spacer(Modifier.height(8.dp))
                            Text("Tự mô tả trang phục xộc xệch/rách tại điểm chạm", color = C.T1, fontSize = 12.sp)
                            Text(
                                "Khi bật: mỗi điểm tay đè lên thân người khác (đúng vùng auto-fix ở trên) sẽ được " +
                                "ghép thêm mô tả \"vải nhăn/xộc xệch/hơi rách\" dùng ĐÚNG trang phục của nhân vật bị " +
                                "chạm (dịch qua LLM theo kiểu prompt đã khai báo ở checkpoint, xem mục \"kiểu prompt " +
                                "checkpoint\" phía trên) — KHÔNG đảm bảo đúng HƯỚNG rách theo lực kéo thật, chỉ đảm " +
                                "bảo đúng VỊ TRÍ (toạ độ điểm chạm) và đúng LOẠI trang phục (nhân vật nào mặc gì).",
                                color = C.T3, fontSize = 11.sp, lineHeight = 14.sp
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text("Bật", color = C.T1, fontSize = 13.sp) }
                                Switch(checked = settings.autoTearClothingAtContactPoints,
                                    onCheckedChange = { vm.updateSettings { copy(autoTearClothingAtContactPoints = it) } },
                                    colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                            }
                        }

                        // mục 115/117/126 TECHNICAL_STATUS.md — Multi-Pass
                        // Inpainting Cascade, ưu tiên số 1 cảnh đông người.
                        // Mặc định BẬT (mục 126 — đây là fix đúng-sai, TỰ
                        // ĐỘNG kích hoạt khi panel có 2+ nhân vật, KHÔNG bắt
                        // user tự soát từng ảnh rồi mới bật switch toàn cục).
                        Spacer(Modifier.height(10.dp))
                        Divider(color = C.Border)
                        Spacer(Modifier.height(10.dp))
                        Text("Cascade khoá danh tính từng người (cảnh đông người)", color = C.T1, fontSize = 13.sp)
                        Text(
                            "TỰ ĐỘNG chạy thêm 1 lượt riêng cho từng nhân vật khi panel có 2+ người, để sửa lại " +
                            "đúng khuôn mặt/thân hình/tỷ lệ từng người (tránh hoà lẫn đặc điểm nếu chỉ sinh 1 lượt " +
                            "chung). CHẬM HƠN (tốn thêm N lượt sinh ảnh, N = số nhân vật trong cảnh) — chỉ tắt nếu " +
                            "máy yếu, ưu tiên tốc độ hơn độ chính xác từng người.",
                            color = C.T3, fontSize = 11.sp, lineHeight = 14.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Bật (khuyến nghị giữ nguyên)", color = C.T1, fontSize = 13.sp) }
                            Switch(checked = settings.enableMultiPassCascade,
                                onCheckedChange = { vm.updateSettings { copy(enableMultiPassCascade = it) } },
                                colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                        }
                        if (settings.enableMultiPassCascade) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Denoise mỗi lượt cascade", color = C.T2, fontSize = 12.sp)
                                Text("%.2f".format(settings.cascadeDenoiseStrength), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Slider(value = settings.cascadeDenoiseStrength, onValueChange = { vm.updateSettings { copy(cascadeDenoiseStrength = it) } },
                                valueRange = 0.3f..0.6f, colors = SliderDefaults.colors(thumbColor = C.Orange, activeTrackColor = C.Orange, inactiveTrackColor = C.Border))
                            Text("Thấp = giữ sát bố cục lượt đầu (an toàn). Cao = sửa tự do hơn nhưng dễ lệch bố cục chung. Khuyến nghị 0.45.",
                                color = C.T3, fontSize = 11.sp, lineHeight = 14.sp)
                        }

                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { vm.clearSeedRegistry() }, colors = ButtonDefaults.buttonColors(containerColor = C.S1)) {
                            Text("🗑 Xoá kho seed (nên xoá sau khi đổi SD model)", color = C.T1, fontSize = 12.sp)
                        }
                    }
                }
            }
            }

            item {
                SettingsSectionHeader("🧪", "Nâng cao & thử nghiệm", expandAdvanced) { expandAdvanced = !expandAdvanced }
            }

            if (expandAdvanced) {
            item {
                MlCard {
                    MlLabel("⚖️ cân bằng pose/depth controlnet — mục 81")
                    Text("Điều chỉnh trọng số + cửa sổ timestep của 2 ControlNet (Pose+Depth, mục 51) khi cộng " +
                        "residual — giải quyết hiện tượng \"loãng\" ranh giới cơ thể khi 2 điều kiện giằng co ở " +
                        "vùng chồng lấn. CHỈ có tác dụng với model .mnn đã export lại theo mục 81 — model cũ " +
                        "âm thầm bỏ qua 3 giá trị này (không lỗi, không cải thiện gì). CHƯA BUILD-TEST.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Pose scale (điều kiện chính)", color = C.T2, fontSize = 12.sp)
                        Text("%.2f".format(settings.poseConditioningScale), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Slider(value = settings.poseConditioningScale, onValueChange = { vm.updateSettings { copy(poseConditioningScale = it) } },
                        valueRange = 0.5f..1.5f, colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Depth scale (hỗ trợ)", color = C.T2, fontSize = 12.sp)
                        Text("%.2f".format(settings.depthConditioningScale), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Slider(value = settings.depthConditioningScale, onValueChange = { vm.updateSettings { copy(depthConditioningScale = it) } },
                        valueRange = 0.2f..1.2f, colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Depth active min-timestep", color = C.T2, fontSize = 12.sp)
                        Text("${settings.depthActiveMinTimestep.toInt()}", color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Slider(value = settings.depthActiveMinTimestep, onValueChange = { vm.updateSettings { copy(depthActiveMinTimestep = it) } },
                        valueRange = 0f..900f, colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                    Text("Depth chỉ tác động khi timestep ≥ giá trị này (xấp xỉ control_guidance_end — xem mục 81).",
                        color = C.T3, fontSize = 11.sp)
                }
            }
            item {
                MlCard {
                    MlLabel("🌗 suy giảm ip-adapter theo timestep (smooth decay)")
                    Text("Cho identity IP-Adapter YẾU DẦN ở các step cuối, nhường chỗ cho biểu cảm/chi tiết mặt " +
                        "do prompt quyết định thay vì bị khoá cứng theo ảnh tham chiếu suốt quá trình. floor=1.0 " +
                        "= TẮT hẳn (mặc định, không đổi gì so với trước). Chỉ có tác dụng với model .mnn đã " +
                        "export lại + CHỈ áp dụng đường sinh 1 nhân vật. CHƯA BUILD-TEST — cơ chế scale ĐÚNG " +
                        "output attention (không phải xấp xỉ scale-input), nhưng mức độ ảnh hưởng cảm nhận " +
                        "được trên ảnh thật vẫn chưa được kiểm chứng A/B.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Floor (cường độ tối thiểu cuối step)", color = C.T2, fontSize = 12.sp)
                        Text("%.2f".format(settings.ipDecayFloor), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Slider(value = settings.ipDecayFloor, onValueChange = { vm.updateSettings { copy(ipDecayFloor = it) } },
                        valueRange = 0.2f..1.0f, colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Mốc timestep bắt đầu suy giảm", color = C.T2, fontSize = 12.sp)
                        Text("${settings.ipDecayStartTimestep.toInt()}", color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Slider(value = settings.ipDecayStartTimestep, onValueChange = { vm.updateSettings { copy(ipDecayStartTimestep = it) } },
                        valueRange = 100f..999f, colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                    Text("999 = suy giảm mượt ngay từ đầu; số nhỏ hơn = giữ nguyên cường độ lâu hơn rồi mới bắt đầu giảm dần về Floor.",
                        color = C.T3, fontSize = 11.sp)
                }
            }
            item {
                MlCard {
                    MlLabel("🎯 tự động chỉnh theo hành động (mục 107, thử nghiệm)")
                    Text("Khi BẬT: mỗi panel tự tra bộ số Pose/Depth/Decay theo action_category đã phân loại " +
                        "sẵn (embrace/combat/kiss/run/neutral, mục 86) thay vì luôn dùng 6 slider tĩnh ở trên. " +
                        "Cảnh đánh nhau và cảnh tâm sự sẽ dùng bộ số KHÁC NHAU tự động, không cần bạn tự đoán " +
                        "chỉnh tay từng cảnh.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("⚠ CÁC CON SỐ TRONG PRESET LÀ ƯỚC LƯỢNG HỢP LÝ, CHƯA KIỂM CHỨNG BẰNG SO SÁNH ẢNH " +
                        "THẬT. Dùng nút \"So sánh thử\" trong màn hình duyệt ảnh (từng panel) để tự xác nhận/" +
                        "tinh chỉnh trước khi tin tưởng cho cả truyện. Chỉ có tác dụng với model .mnn đã export " +
                        "lại theo mục 97/99 — model cũ tự bỏ qua an toàn (không đổi gì so với TẮT).",
                        color = C.Orange, fontSize = 11.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Bật tự động chỉnh theo hành động", color = C.T2, fontSize = 12.sp)
                        Switch(checked = settings.autoConditioningPresets,
                            onCheckedChange = { vm.updateSettings { copy(autoConditioningPresets = it) } })
                    }
                }
            }
            item {
                MlCard {
                    MlLabel("☀️ auto-histogram guard — mục 79/80")
                    Text("Đo độ sáng trung bình ảnh gốc trước Ultrafix (thuần pixel-level, không cần model " +
                        "mới), chèn tag bù trừ NHẸ nếu quá tối/quá sáng. Không phân biệt được \"tối cố ý\" " +
                        "(cảnh đêm) với \"tối do lỗi\" — chỉ nên bật nếu bạn thấy nhiều panel bị lệch sáng " +
                        "ngẫu nhiên. CHƯA BUILD-TEST.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Bật Histogram Guard", color = C.T1, fontSize = 13.sp) }
                        Switch(checked = settings.enableHistogramGuard, onCheckedChange = { vm.updateSettings { copy(enableHistogramGuard = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
                    }
                }
            }
            item {
                MlCard {
                    MlLabel("storydiffusion")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Consistent Self-Attention", color = C.T1, fontSize = 13.sp)
                            Text("Nhất quán mặt + trang phục + vóc dáng", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.useStoryDiffusion, onCheckedChange = { vm.updateSettings { copy(useStoryDiffusion = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                    if (settings.useStoryDiffusion) {
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Mức độ nhất quán", color = C.T2, fontSize = 12.sp)
                            // mục 9 TECHNICAL_STATUS.md — ĐÃ ĐÓNG GAP (mục 97): trước đây
                            // consistencyStrength KHÔNG có tác dụng vì pipe.set_ip_adapter_scale()
                            // đóng băng lúc export. Giờ nối qua "ip_static_scale" — runtime
                            // input mới của UNet, dùng ĐÚNG cơ chế attention processor đã bọc
                            // cho Smooth Timestep Decay (mục 97), tầng nhân RIÊNG độc lập với
                            // decay theo timestep. CHỈ có tác dụng với model .mnn đã export lại
                            // thêm input này — model cũ tự bỏ qua an toàn (giữ cường độ gốc).
                            Text("%.0f%%".format(settings.consistencyStrength * 100), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(value = settings.consistencyStrength, onValueChange = { vm.updateSettings { copy(consistencyStrength = it) } },
                            valueRange = 0.3f..1.0f,
                            colors = SliderDefaults.colors(thumbColor = C.Purple, activeTrackColor = C.Purple, inactiveTrackColor = C.Border))
                        Text("Đã nối vào logic sinh ảnh thật (mục 97) — chỉ có tác dụng với model .mnn đã export lại (thêm input ip_static_scale); model cũ vẫn dùng cường độ gốc, không đổi.",
                            color = C.T3, fontSize = 11.sp, lineHeight = 13.sp)

                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { nav.navigate("pose_editor") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(6.dp))
                            Text("Vẽ / sửa khung xương tư thế")
                        }
                    }
                }
            }
            item {
                MlCard {
                    // mục 71 TECHNICAL_STATUS.md — Seed Propagation. Đồng
                    // thời sửa bug thật (xem MangaPipeline.resolveEffective()):
                    // mặc định TRƯỚC ĐÂY seed = hash tên nhân vật (mọi panel
                    // của 1 người luôn ra cùng 1 seed, dễ lặp bố cục kỳ quái).
                    // Giờ mặc định ngẫu nhiên thật; bật switch này để CHỦ Ý
                    // giữ seed giống nhau giữa panel liên tiếp CÙNG bối cảnh.
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Kế thừa seed cùng bối cảnh", color = C.T1, fontSize = 13.sp)
                            Text("Panel liên tiếp có cùng scene.setting (bối cảnh) sẽ dùng chung 1 seed — giữ góc máy/ánh sáng nền đứng yên qua nhiều panel (vd 1 trận đánh dài). Mặc định TẮT (mỗi panel seed ngẫu nhiên độc lập).",
                                color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                        }
                        Switch(checked = settings.seedInheritanceEnabled, onCheckedChange = { vm.updateSettings { copy(seedInheritanceEnabled = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                    // mục 138 TECHNICAL_STATUS.md — trước đây field này
                    // (`slidingWindowSize`) tồn tại trong Models.kt nhưng
                    // KHÔNG có UI, KHÔNG ai đọc — kế thừa seed chỉ so được
                    // với ĐÚNG 1 panel liền trước. Đã nối thật (xem
                    // MangaPipeline.runGeneration()): giờ tìm ngược trong
                    // cửa sổ N panel gần nhất, không chỉ 1 panel liền kề.
                    if (settings.seedInheritanceEnabled) {
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Cửa sổ tìm kiếm", color = C.T2, fontSize = 12.sp)
                            Text("${settings.slidingWindowSize} panel gần nhất", color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(value = settings.slidingWindowSize.toFloat(),
                            onValueChange = { vm.updateSettings { copy(slidingWindowSize = it.toInt()) } },
                            valueRange = 1f..10f, steps = 8,
                            colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                        Text("1 = chỉ so panel liền trước (như cũ). Lớn hơn = tìm ngược xa hơn, ví dụ cảnh A-B-A vẫn nhận lại đúng seed của A dù panel B (bối cảnh khác) chen giữa.",
                            color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                }
            }
            }

            item {
                SettingsSectionHeader("⚙️", "Hệ thống & vận hành", expandSystem) { expandSystem = !expandSystem }
            }

            if (expandSystem) {
            item {
                MlCard {
                    MlLabel("🌡️ kiểm soát nhiệt độ")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Ngưỡng dừng", color = C.T2, fontSize = 12.sp)
                        Text("${settings.thermalThreshold}°C", color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = settings.thermalThreshold.toFloat(),
                        onValueChange = { vm.updateSettings { copy(thermalThreshold = it.toInt()) } },
                        valueRange = 35f..55f,
                        colors = SliderDefaults.colors(thumbColor = C.Red, activeTrackColor = C.Red, inactiveTrackColor = C.Border))
                    Text("Khi vượt ngưỡng, pipeline tự tạm dừng + rung báo động",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    // mục 137 TECHNICAL_STATUS.md — SỬA BUG THẬT: trước đây
                    // dòng "ngưỡng - 3°C" bên dưới là chữ CỨNG, không phải
                    // giá trị thật (settings.thermalResumeOffset tồn tại
                    // trong Models.kt nhưng CHƯA từng được đọc ở đâu cả —
                    // ThermalMonitor tự resume ngay khi chạm ĐÚNG ngưỡng,
                    // không có độ trễ nào, dù UI khẳng định có "-3°C").
                    // Đã nối `thermalResumeOffset` vào `ThermalMonitor.start()`
                    // thật (xem ThermalMonitor.kt) — giờ thêm Slider để user
                    // chỉnh được, và text hiển thị ĐÚNG giá trị đang cấu hình
                    // thay vì số cứng.
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Độ trễ trước khi tiếp tục", color = C.T2, fontSize = 12.sp)
                        Text("ngưỡng - ${settings.thermalResumeOffset}°C", color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = settings.thermalResumeOffset.toFloat(),
                        onValueChange = { vm.updateSettings { copy(thermalResumeOffset = it.toInt()) } },
                        valueRange = 1f..10f,
                        colors = SliderDefaults.colors(thumbColor = C.Red, activeTrackColor = C.Red, inactiveTrackColor = C.Border))
                    Text("Giá trị càng lớn, máy càng nguội sâu mới tiếp tục sinh ảnh — tránh nhấp nháy tạm dừng/tiếp tục liên tục khi nhiệt độ dao động ngay sát ngưỡng.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Tự động tiếp tục", color = C.T1, fontSize = 13.sp)
                            Text("Khi nguội xuống ngưỡng - ${settings.thermalResumeOffset}°C", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.autoResume, onCheckedChange = { vm.updateSettings { copy(autoResume = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                }
            }
            item {
                // Đóng gap "đã code nhưng thiếu UI" (TECHNICAL_STATUS.md mục
                // 82/84): trước đây jpegQuality của exportCbz() và
                // timeoutMs của cancelSafely() chỉ có thể đổi bằng cách sửa
                // code, không có UI nào chạm tới cả — xem GenerationSettings
                // (Models.kt) và call site ở MainViewModel.kt.
                MlCard {
                    MlLabel("📦 xuất file CBZ")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Chất lượng JPEG", color = C.T2, fontSize = 12.sp)
                        Text("${settings.cbzJpegQuality}", color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = settings.cbzJpegQuality.toFloat(),
                        onValueChange = { vm.updateSettings { copy(cbzJpegQuality = it.toInt()) } },
                        valueRange = 60f..100f,
                        colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                    Text("Cao hơn = ảnh nét hơn nhưng file CBZ nặng hơn. Dưới 80 dễ thấy artefact khối ở nét mảnh (viền bong bóng thoại).",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                }
            }
            item {
                MlCard {
                    MlLabel("⏱️ huỷ tiến trình")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Thời gian chờ trước khi báo treo", color = C.T2, fontSize = 12.sp)
                        Text("${settings.cancelTimeoutMs / 1000}s", color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = (settings.cancelTimeoutMs / 1000).toFloat(),
                        onValueChange = { vm.updateSettings { copy(cancelTimeoutMs = it.toLong() * 1000L) } },
                        valueRange = 10f..90f,
                        colors = SliderDefaults.colors(thumbColor = C.Orange, activeTrackColor = C.Orange, inactiveTrackColor = C.Border))
                    Text("Khi bấm Huỷ, app đợi tối đa khoảng thời gian này để tiến trình sinh ảnh dừng hẳn trước khi báo có thể bị treo. Máy yếu/model to nên để cao hơn.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                }
            }
            }

            item {
                SettingsSectionHeader("🌐", "Remote GPU (tuỳ chọn)", expandRemote) { expandRemote = !expandRemote }
            }

            if (expandRemote) {
            item {
                MlCard {
                    MlLabel("remote gpu (tuỳ chọn — mặc định vẫn 100% local)")
                    Text("Gửi ảnh sinh ra ngoài Colab/GPU thuê ngoài để nhanh hơn. " +
                        "⚠ Đã mã hoá hybrid RSA+AES giữa máy và server, nhưng CHỦ HẠ TẦNG GPU vẫn có khả năng " +
                        "truy cập dữ liệu lúc đang tính toán trừ khi dùng Confidential-Computing GPU (xem TECHNICAL_STATUS.md). " +
                        "Không dùng cho nội dung thực sự riêng tư/nhạy cảm.",
                        color = C.Orange, fontSize = 11.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật Remote GPU", color = C.T1, fontSize = 13.sp)
                            Text("Tắt = luôn sinh local như trước, không đổi gì cả", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.remoteEndpoint.enabled,
                            onCheckedChange = { vm.updateSettings { copy(remoteEndpoint = remoteEndpoint.copy(enabled = it)) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }

                    if (settings.remoteEndpoint.enabled) {
                        Spacer(Modifier.height(10.dp))
                        // SỬA (yêu cầu: đổi model TRƯỚC khi generate 1 chương,
                        // không hardcode toàn dự án chỉ SD1.5): trước đây model
                        // gốc trên remote CHỈ đổi được bằng cách sửa CLI arg
                        // --model rồi khởi động lại cả server Colab (mất
                        // fingerprint, phải nối lại từ đầu). Giờ đổi ngay ở
                        // đây, server tự nhận model khác lần trước và tự tải
                        // lại — KHÔNG cần restart Colab. Để trống = dùng đúng
                        // model server đã khởi động sẵn (--model, hành vi cũ).
                        Text("Model trên remote (để trống = dùng model server đặt lúc khởi động)",
                            color = C.T2, fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            value = settings.remoteEndpoint.remoteModelId,
                            onValueChange = { vm.updateSettings { copy(remoteEndpoint = remoteEndpoint.copy(remoteModelId = it)) } },
                            placeholder = { Text("vd stabilityai/stable-diffusion-xl-base-1.0", fontSize = 11.sp, color = C.T3) },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            RemoteModelType.values().forEach { type ->
                                FilterChip(
                                    selected = settings.remoteEndpoint.remoteModelType == type,
                                    onClick = { vm.updateSettings { copy(remoteEndpoint = remoteEndpoint.copy(remoteModelType = type)) } },
                                    label = { Text(type.name, fontSize = 11.sp) }
                                )
                            }
                        }
                        Text(settings.remoteEndpoint.remoteModelType.label, color = C.T3, fontSize = 11.sp, lineHeight = 13.sp)
                        Text("⚠ Đổi model tốn vài phút để server tải lại (chỉ xảy ra 1 LẦN khi thật sự đổi, " +
                            "không phải mỗi panel) — đặt xong trước khi bấm Generate cho cả chương, đừng đổi giữa chừng.",
                            color = C.Orange, fontSize = 11.sp, lineHeight = 13.sp)
                        Spacer(Modifier.height(12.dp))
                        Divider(color = C.Border)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = settings.remoteEndpoint.baseUrl,
                            onValueChange = { vm.updateSettings { copy(remoteEndpoint = remoteEndpoint.copy(baseUrl = it)) } },
                            label = { Text("Base URL (vd https://xxxx.ngrok-free.app)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = settings.remoteEndpoint.authToken,
                            onValueChange = { vm.updateSettings { copy(remoteEndpoint = remoteEndpoint.copy(authToken = it)) } },
                            label = { Text("Auth token (đặt lúc chạy remote_server/app.py)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth(),
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            enabled = !checkingConnection && settings.remoteEndpoint.baseUrl.isNotBlank(),
                            onClick = {
                                checkingConnection = true; fingerprintResult = null; fingerprintError = null
                                scope.launch {
                                    try {
                                        val fp = RemoteGenerationClient(settings.remoteEndpoint).fetchServerFingerprint()
                                        fingerprintResult = fp
                                    } catch (ex: Exception) {
                                        fingerprintError = ex.message ?: "Lỗi không rõ"
                                    } finally { checkingConnection = false }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (checkingConnection) "Đang kiểm tra..." else "Kiểm tra kết nối + lấy fingerprint") }
                        fingerprintResult?.let { fp ->
                            Spacer(Modifier.height(6.dp))
                            Text("✓ Kết nối OK. Fingerprint server:", color = C.Green, fontSize = 11.sp)
                            Text(fp, color = C.T1, fontSize = 11.sp, fontFamily = FontFamily.Monospace, lineHeight = 14.sp)
                            Text("Đối chiếu với fingerprint in ra ở log lúc chạy remote_server/app.py — " +
                                "khớp thì mới chắc chắn không bị bên thứ ba giả mạo server (xem RemoteGenerationClient.kt).",
                                color = C.T3, fontSize = 11.sp, lineHeight = 13.sp)
                        }
                        fingerprintError?.let { err ->
                            Spacer(Modifier.height(6.dp))
                            Text("✗ $err", color = C.Red, fontSize = 11.sp)
                        }

                        Spacer(Modifier.height(14.dp))
                        Text("Chế độ chọn local/remote", color = C.T2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(RoutingMode.MANUAL to "Thủ công", RoutingMode.AUTO to "Tự động (LLM quyết định)").forEach { (mode, label) ->
                                FilterChip(selected = settings.routingMode == mode,
                                    onClick = { vm.updateSettings { copy(routingMode = mode) } },
                                    label = { Text(label, fontSize = 12.sp) })
                            }
                        }

                        if (settings.routingMode == RoutingMode.MANUAL) {
                            Spacer(Modifier.height(10.dp))
                            Text("Mặc định cho panel không chọn riêng:", color = C.T3, fontSize = 11.sp)
                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(GenerationBackend.LOCAL to "Local", GenerationBackend.REMOTE to "Remote").forEach { (b, label) ->
                                    FilterChip(selected = settings.defaultBackend == b,
                                        onClick = { vm.updateSettings { copy(defaultBackend = b) } },
                                        label = { Text(label, fontSize = 12.sp) })
                                }
                            }
                            Text("Chọn riêng cho từng panel ở Gallery Review (mở panel > Backend) — " +
                                "luôn thắng mọi quy tắc bên dưới.", color = C.T3, fontSize = 11.sp)

                            Spacer(Modifier.height(14.dp))
                            Text("Quy tắc khai báo trước (áp dụng hàng loạt, không cần sinh xong mới chọn):",
                                color = C.T2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("Vd: nhân vật \"Lan\" → luôn Local. Từ khoá \"trong nhà tắm\" → luôn Local. " +
                                "Rule đứng TRÊN thắng khi 1 panel khớp nhiều rule mâu thuẫn.",
                                color = C.T3, fontSize = 11.sp, lineHeight = 13.sp)
                            Spacer(Modifier.height(6.dp))

                            settings.manualRoutingRules.forEachIndexed { idx, rule ->
                                Row(verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                    Text("${idx + 1}.", color = C.T3, fontSize = 11.sp, modifier = Modifier.width(18.dp))
                                    Text(
                                        (if (rule.matchType == RoutingMatchType.CHARACTER) "Nhân vật: " else "Từ khoá: ") + rule.value,
                                        color = C.T1, fontSize = 12.sp, modifier = Modifier.weight(1f)
                                    )
                                    Text(rule.backend.name, color = if (rule.backend == GenerationBackend.LOCAL) C.Green else C.Blue,
                                        fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 6.dp))
                                    IconButton(onClick = {
                                        vm.updateSettings { copy(manualRoutingRules = manualRoutingRules.filterIndexed { i, _ -> i != idx }) }
                                    }, modifier = Modifier.size(28.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = "Xoá rule", tint = C.T3, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }

                            var newRuleType by remember { mutableStateOf(RoutingMatchType.CHARACTER) }
                            var newRuleValue by remember { mutableStateOf("") }
                            var newRuleBackend by remember { mutableStateOf(GenerationBackend.LOCAL) }
                            // mục 66 TECHNICAL_STATUS.md — đối chiếu review: claim "ô tự gõ
                            // tay, dễ lệch chính tả so với kịch bản LLM parser trả về, rule
                            // bị vô hiệu âm thầm" ĐÚNG THẬT — trước đây value luôn là
                            // OutlinedTextField tự do kể cả khi matchType=CHARACTER. Giờ đổi
                            // sang chip chọn TỪ ĐÚNG danh sách currentStory.characters thật
                            // (không thể gõ sai tên nữa) khi matchType=CHARACTER — chỉ còn
                            // KEYWORD mới dùng ô tự do (đúng bản chất, "từ khoá" vốn không
                            // gắn với 1 nhân vật cụ thể).
                            val storyCharNames = currentStory?.characters?.map { it.name } ?: emptyList()

                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(RoutingMatchType.CHARACTER to "Nhân vật", RoutingMatchType.KEYWORD to "Từ khoá").forEach { (t, label) ->
                                    FilterChip(selected = newRuleType == t, onClick = { newRuleType = t; newRuleValue = "" },
                                        label = { Text(label, fontSize = 11.sp) })
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            if (newRuleType == RoutingMatchType.CHARACTER) {
                                if (storyCharNames.isEmpty()) {
                                    Text("Chưa có nhân vật nào trong truyện đang mở — vào màn Nhân vật để thêm trước.",
                                        color = C.T3, fontSize = 11.sp)
                                } else {
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        items(storyCharNames) { name ->
                                            FilterChip(selected = newRuleValue == name, onClick = { newRuleValue = name },
                                                label = { Text(name, fontSize = 11.sp) })
                                        }
                                    }
                                }
                            } else {
                                OutlinedTextField(
                                    value = newRuleValue, onValueChange = { newRuleValue = it },
                                    placeholder = { Text("Từ khoá xuất hiện trong mô tả cảnh", fontSize = 11.sp) },
                                    singleLine = true, modifier = Modifier.fillMaxWidth()
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                listOf(GenerationBackend.LOCAL to "Local", GenerationBackend.REMOTE to "Remote").forEach { (b, label) ->
                                    FilterChip(selected = newRuleBackend == b, onClick = { newRuleBackend = b },
                                        label = { Text(label, fontSize = 11.sp) })
                                }
                                Spacer(Modifier.weight(1f))
                                OutlinedButton(
                                    enabled = newRuleValue.isNotBlank(),
                                    onClick = {
                                        vm.updateSettings { copy(manualRoutingRules = manualRoutingRules + ManualRoutingRule(
                                            matchType = newRuleType, value = newRuleValue.trim(), backend = newRuleBackend)) }
                                        newRuleValue = ""
                                    }
                                ) { Text("Thêm", fontSize = 12.sp) }
                            }
                        } else {
                            Spacer(Modifier.height(10.dp))
                            Text("Hướng dẫn cho LLM (tiếng Việt tự nhiên) — nói rõ panel nào nên local, panel nào remote:",
                                color = C.T3, fontSize = 11.sp)
                            Spacer(Modifier.height(4.dp))
                            OutlinedTextField(
                                value = settings.autoRoutingPolicyPrompt,
                                onValueChange = { vm.updateSettings { copy(autoRoutingPolicyPrompt = it) } },
                                placeholder = { Text("Để trống = dùng quy tắc an toàn mặc định (nhạy cảm→local, còn lại→remote)", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth().height(90.dp)
                            )
                            Text("Panel vẫn có thể override tay ở Gallery Review — override tay LUÔN thắng LLM.",
                                color = C.T3, fontSize = 11.sp)
                        }
                    }
                }
            }
            }

            item {
                MlCard {
                    MlLabel("stack kỹ thuật · local mặc định + remote gpu tuỳ chọn")
                    listOf(
                        "🧠 LLM" to "llama.cpp · chia scene + character detection + dịch prompt theo giai đoạn",
                        "🎨 SD 1.5" to "MNN (sd15_cpu) · bất kỳ checkpoint đã convert",
                        "🔄 StoryDiffusion" to "IP-Adapter + ControlNet-Pose (UNet augmented)",
                        "🦴 Pose" to "YOLOv8-pose qua MNN (đã thay MediaPipe — mục 19)",
                        "🩹 Auto-fix mặt/tay" to "tái dùng khung xương YOLOv8-pose, không model riêng (mục 20)",
                        "✂️ Mask thủ công" to "MobileSAM click-to-mask (mục 21)",
                        "🔍 Upscale" to "ESRGAN (4x-UltraSharp) + Ultrafix redraw",
                        "💬 Auto Bubble" to "YOLOv8n qua MNN · object detection",
                        "🌡️ Thermal" to "Kernel thermal_zone · auto pause",
                        "📄 Export" to "PDF + CBZ"
                    ).forEachIndexed { i, (t, d) ->
                        Column(Modifier.padding(vertical = 7.dp)) {
                            Text(t, color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(d, color = C.T3, fontSize = 11.sp)
                        }
                        if (i < 9) Divider(color = C.Border)
                    }
                }
            }
        }
    }
}
