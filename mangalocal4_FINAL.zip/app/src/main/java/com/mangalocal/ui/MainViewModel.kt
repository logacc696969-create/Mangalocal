package com.mangalocal.ui

import android.app.Application
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.RemoteException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.mangalocal.model.*
import com.mangalocal.pipeline.*
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {
    // mục 71 TECHNICAL_STATUS.md — khoá đơn luồng tường minh (item #3 còn
    // treo ở mục 70). Điện thoại chỉ có 1 SoC — 2 tác vụ AI cùng lúc (vd
    // người dùng bấm "Sinh panel" thủ công đúng lúc runIndustrialBatch()
    // đang chạy) sẽ tranh chấp RAM/VRAM, rủi ro OOM/crash thật (không phải
    // lý thuyết — pipeline C++ không tự khoá gì ở tầng của nó). MỌI đường
    // gọi prepareChapter()/runGeneration()/regeneratePanel() PHẢI bọc qua
    // generationMutex.withLock — đảm bảo tại 1 thời điểm chỉ 1 panel được
    // forward qua UNet, bất kể gọi từ đâu trong UI.
    private val generationMutex = Mutex()

    val storyManager = StoryManager(app)
    // mục 142 TECHNICAL_STATUS.md — checkpoint cuốn chiếu cho batch công
    // nghiệp, xem BatchStateRegistry.kt.
    private val batchStateRegistry = BatchStateRegistry(app)
    val thermalMonitor = ThermalMonitor(app)
    val runtimeOptimizer = RuntimeOptimizer(app)
    private val pipeline = MangaPipeline(storyManager, thermalMonitor, runtimeOptimizer)
    // Mask thủ công (mục 21 TECHNICAL_STATUS.md) — ImagePipeline riêng, tách
    // khỏi cái MangaPipeline đang giữ (native context chỉ load thật khi gọi
    // loadSD(), không tốn gì thêm lúc khởi tạo — an toàn tạo instance riêng).
    private val manualMaskImagePipeline = ImagePipeline(storyManager)
    val manualMaskFixer by lazy { ManualMaskFixer(storyManager, manualMaskImagePipeline) }

    // mục 161 TECHNICAL_STATUS.md (đợt 8 — "#5 Multi-Process Isolation").
    // _pipelineState giờ là StateFlow RIÊNG của ViewModel (không còn = thẳng
    // pipeline.state) — hợp nhất 2 nguồn: (a) đường CŨ vẫn chạy in-process
    // (runIndustrialBatch, regeneratePanel... CHƯA chuyển qua IPC ở đợt
    // này) forward qua pipeline.state (collect trong init{} bên dưới), (b)
    // đường MỚI qua IPC (confirmRoutingAndGenerate(), xem
    // runGenerationViaService()) cập nhật trực tiếp từ PipelineState nhận
    // qua Messenger. UI (`vm.pipelineState`) KHÔNG cần biết đường nào đang
    // chạy — luôn đọc đúng 1 nguồn duy nhất, không đổi gì phía UI.
    private val _pipelineState = MutableStateFlow(PipelineState())
    val pipelineState: StateFlow<PipelineState> = _pipelineState.asStateFlow()
    val thermalState = thermalMonitor.state

    private val ipcGson = Gson()

    // --- mục 161 (đợt 8) — kết nối tới GenerationService (chạy tiến trình
    // riêng ":inference", xem AndroidManifest.xml + GenerationService.kt).
    // CHỈ dùng cho confirmRoutingAndGenerate() ở đợt này — các hàm khác của
    // pipeline (regeneratePanel, runIndustrialBatch, model download,
    // cleanup...) VẪN gọi trực tiếp in-process như cũ, CHƯA chuyển (cố ý
    // làm 1 đường ĐÚNG TRỌN VẸN trước, xem lý do đầy đủ ở
    // GenerationService.kt).
    private var serviceMessenger: Messenger? = null
    private var pendingResult: CompletableDeferred<Chapter>? = null
    private var pendingRequestId: String? = null
    // mục 161 (đợt 10) — MSG_RESULT chỉ mang chapterId (không còn nguyên
    // Chapter JSON, xem lý do ở GenerationProtocol.kt) — cần giữ lại đúng
    // storyId của request ĐANG chờ để gọi loadChapter(storyId, chapterId)
    // đúng cặp khi nhận được kết quả.
    private var pendingRequestStoryId: String? = null

    private val replyHandler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            when (msg.what) {
                GenerationProtocol.MSG_PROGRESS -> {
                    val p = GenerationProtocol.parseProgressMessage(msg) ?: return
                    if (p.requestId != pendingRequestId) return  // response trễ từ lượt đã bị thay thế/huỷ — bỏ qua
                    _pipelineState.value = ipcGson.fromJson(p.pipelineStateJson, PipelineState::class.java)
                }
                GenerationProtocol.MSG_RESULT -> {
                    val r = GenerationProtocol.parseResultMessage(msg) ?: return
                    if (r.requestId != pendingRequestId) return
                    // mục 161 (đợt 10) — đọc lại Chapter TỪ ĐĨA bằng ID
                    // (Service đã tự storyManager.saveChapter() trước khi
                    // gửi MSG_RESULT) thay vì Gson-deserialize JSON nhét
                    // Bundle — xem lý do đầy đủ (giới hạn Binder 1MB) ở
                    // GenerationProtocol.kt.
                    val pendingStoryId = pendingRequestStoryId
                    val loaded = if (pendingStoryId != null) storyManager.loadChapter(pendingStoryId, r.chapterId) else null
                    if (loaded != null) pendingResult?.complete(loaded)
                    else pendingResult?.completeExceptionally(IllegalStateException("Sinh ảnh xong nhưng không đọc lại được Chapter từ đĩa (storyId=$pendingStoryId, chapterId=${r.chapterId})"))
                }
                GenerationProtocol.MSG_ERROR -> {
                    val e = GenerationProtocol.parseErrorMessage(msg) ?: return
                    if (e.requestId != pendingRequestId) return
                    pendingResult?.completeExceptionally(Exception(e.error))
                }
            }
        }
    }
    private val replyMessenger = Messenger(replyHandler)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            serviceMessenger = Messenger(binder)
        }
        override fun onServiceDisconnected(name: ComponentName) {
            // mục 161 (đợt 8) — ĐÚNG mục tiêu cốt lõi của #5: tiến trình
            // :inference chết (crash native/OOM) -> CHỈ callback này chạy,
            // tiến trình UI (nơi code này đang chạy) VẪN SỐNG. Nếu đang có
            // 1 lượt generation đang chờ kết quả, báo lỗi rõ ràng thay vì
            // treo vô thời hạn — khác hành vi CŨ (mọi crash trước đây kéo
            // sập toàn bộ tiến trình UI cùng lúc, không có cơ hội báo lỗi
            // gì cả).
            serviceMessenger = null
            pendingResult?.completeExceptionally(
                IllegalStateException("Tiến trình sinh ảnh đã dừng đột ngột (có thể do lỗi native/hết bộ nhớ) — xem last_native_crash.txt để biết chi tiết.")
            )
        }
    }

    private suspend fun ensureServiceBound() {
        if (serviceMessenger != null) return
        withContext(Dispatchers.Main) {
            val intent = Intent(appCtx, GenerationService::class.java)
            androidx.core.content.ContextCompat.startForegroundService(appCtx, intent)
            appCtx.bindService(intent, serviceConnection, android.content.Context.BIND_AUTO_CREATE)
        }
        // bindService() BẤT ĐỒNG BỘ (không đảm bảo xong ngay khi hàm
        // return) — đợi chủ động onServiceConnected() gán serviceMessenger
        // thay vì giả định đã sẵn sàng ngay.
        withTimeout(10_000L) {
            while (serviceMessenger == null) kotlinx.coroutines.delay(50)
        }
    }

    // mục 161 (đợt 8) — THAY THẾ lời gọi trực tiếp pipeline.runGeneration()
    // trong confirmRoutingAndGenerate() bằng round-trip qua Messenger tới
    // tiến trình :inference. Story/Chapter/GenerationSettings serialize
    // qua Gson — TÁI DÙNG thư viện đã dùng khắp StoryManager.kt, không viết
    // Parcelable riêng cho từng data class (xem lý do đầy đủ ở
    // GenerationProtocol.kt).
    private suspend fun runGenerationViaService(
        story: Story, chapter: Chapter, settings: GenerationSettings, purgeAfter: Boolean = false
    ): Chapter {
        ensureServiceBound()
        // mục 161 (đợt 10) — LƯU chapter ra đĩa TRƯỚC khi gửi request —
        // giao thức giờ chỉ gửi storyId/chapterId (không phải nguyên JSON,
        // xem lý do đầy đủ ở GenerationProtocol.kt), Service ĐỌC LẠI từ
        // đĩa bằng ID nên đĩa PHẢI có bản "prepared" (đã parse scene, CHƯA
        // sinh ảnh) này trước khi Service kịp đọc. `chapter` truyền vào đây
        // (từ `_pendingChapter`/`prepared` ở 2 call site) trước giờ CHƯA
        // từng được save (chỉ tồn tại in-memory) — đây là save ĐẦU TIÊN của
        // bản draft này, không phải save dư thừa.
        storyManager.saveChapter(chapter)
        val requestId = UUID.randomUUID().toString()
        pendingRequestId = requestId
        pendingRequestStoryId = story.id
        val deferred = CompletableDeferred<Chapter>()
        pendingResult = deferred

        val msg = GenerationProtocol.buildRunGenerationMessage(
            requestId, story.id, chapter.id, ipcGson.toJson(settings), purgeAfter
        )
        msg.replyTo = replyMessenger
        try {
            serviceMessenger?.send(msg) ?: throw IllegalStateException("Chưa kết nối được tới tiến trình sinh ảnh")
        } catch (e: RemoteException) {
            throw IllegalStateException("Không gửi được yêu cầu sinh ảnh tới tiến trình :inference: ${e.message}")
        }
        return deferred.await()
    }

    private val _stories = MutableStateFlow(storyManager.loadAllStories())
    val stories: StateFlow<List<Story>> = _stories

    private val _currentStory = MutableStateFlow<Story?>(null)
    val currentStory: StateFlow<Story?> = _currentStory

    private val _currentChapter = MutableStateFlow<Chapter?>(null)
    val currentChapter: StateFlow<Chapter?> = _currentChapter
    // Chapter đã phân tích xong (scene + prompt + routing AUTO tính sẵn cho
    // từng panel) nhưng CHƯA sinh ảnh — chờ user duyệt/sửa tay ở
    // RoutingReviewScreen rồi mới bấm xác nhận sinh ảnh thật. null = không
    // có gì đang chờ duyệt.
    private val _pendingChapter = MutableStateFlow<Chapter?>(null)
    val pendingChapter: StateFlow<Chapter?> = _pendingChapter

    // mục 154 TECHNICAL_STATUS.md — "đảo pipeline nhân vật". Kết quả bước
    // phân tích sơ bộ (CharacterSummary thô, LLM tự đoán) — non-null =
    // đang chờ user xác nhận ở CharacterSummaryReviewScreen TRƯỚC khi viết
    // kịch bản chi tiết. null = không có gì chờ (bước phân tích chưa chạy,
    // đã xác nhận xong, hoặc bị bỏ qua vì không có nhân vật MỚI nào).
    private val _pendingCharacterSummary = MutableStateFlow<List<CharacterSummary>?>(null)
    val pendingCharacterSummary: StateFlow<List<CharacterSummary>?> = _pendingCharacterSummary
    // Giữ lại storyText TẠM (không lưu Chapter nào) trong lúc chờ user xác
    // nhận nhân vật — cần dùng lại nguyên văn để gọi prepareChapter() thật
    // sau khi xác nhận xong.
    private var pendingStoryTextForCharacterReview: String? = null
    val isAnalyzingCharacters = MutableStateFlow(false)

    // mục 70 TECHNICAL_STATUS.md — chế độ công nghiệp (batch nhiều chương
    // liên tiếp, KHÔNG dừng duyệt tay từng chương). Xem TextChunker.kt.
    private val _detectedChapters = MutableStateFlow<List<TextChunker.DetectedChapter>?>(null)
    val detectedChapters: StateFlow<List<TextChunker.DetectedChapter>?> = _detectedChapters
    private val _isBatchRunning = MutableStateFlow(false)
    val isBatchRunning: StateFlow<Boolean> = _isBatchRunning
    private val _batchProgress = MutableStateFlow(0 to 0)  // (đã xong, tổng)
    val batchProgress: StateFlow<Pair<Int, Int>> = _batchProgress
    // mục 142 TECHNICAL_STATUS.md — danh sách chương bị lỗi (error shunning)
    // trong lần chạy công nghiệp GẦN NHẤT, hiển thị cho user sau khi batch
    // kết thúc thay vì làm gãy toàn bộ batch vì 1 chương lỗi.
    private val _batchFailedChapters = MutableStateFlow<List<String>>(emptyList())
    val batchFailedChapters: StateFlow<List<String>> = _batchFailedChapters

    private val _settings = MutableStateFlow(GenerationSettings())
    val settings: StateFlow<GenerationSettings> = _settings

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // mục 93 TECHNICAL_STATUS.md — "So Sánh Thử" PromptStyle. null = chưa
    // chạy / đã đóng kết quả; giữ đơn giản (không dùng sealed Loading/Error
    // riêng) vì UI chỉ cần biết "đang chạy" (isRunningPromptStyleTest) hay
    // "có kết quả" (promptStyleTestResult), lỗi thì dùng chung _error sẵn có.
    private val _promptStyleTestResult = MutableStateFlow<MangaPipeline.PromptStyleTestResult?>(null)
    val promptStyleTestResult: StateFlow<MangaPipeline.PromptStyleTestResult?> = _promptStyleTestResult
    private val _isRunningPromptStyleTest = MutableStateFlow(false)
    val isRunningPromptStyleTest: StateFlow<Boolean> = _isRunningPromptStyleTest

    fun runPromptStyleComparisonTest(naturalDescription: String) {
        viewModelScope.launch {
            _isRunningPromptStyleTest.value = true
            _promptStyleTestResult.value = null
            try {
                val s = _settings.value
                val outDir = java.io.File(appCtx.cacheDir, "prompt_style_test").apply { mkdirs() }
                val result = pipeline.runPromptStyleComparisonTest(
                    naturalDescription = naturalDescription, worldRules = "", stylePrompt = s.imageStyle.stylePrompt,
                    settings = s, outDir = outDir
                )
                _promptStyleTestResult.value = result
            } catch (e: Exception) {
                _error.value = "Lỗi chạy So Sánh Thử: ${e.message}"
            } finally {
                _isRunningPromptStyleTest.value = false
            }
        }
    }

    fun dismissPromptStyleTestResult() { _promptStyleTestResult.value = null }

    // mục 107 TECHNICAL_STATUS.md — "So sánh thử" Pose/Depth/Decay cho 1
    // panel THẬT, cùng khuôn mẫu runPromptStyleComparisonTest() ở trên
    // (mục 93) nhưng dùng đường IP-Adapter/ControlNet thật thay vì txt2img
    // thường — xem MangaPipeline.runConditioningComparisonTest() cho lý do
    // + GIỚI HẠN THẬT (chỉ hỗ trợ đường 1-nhân-vật).
    private val _conditioningTestResult = MutableStateFlow<MangaPipeline.ConditioningTestResult?>(null)
    val conditioningTestResult: StateFlow<MangaPipeline.ConditioningTestResult?> = _conditioningTestResult
    private val _isRunningConditioningTest = MutableStateFlow(false)
    val isRunningConditioningTest: StateFlow<Boolean> = _isRunningConditioningTest

    fun runConditioningComparisonTest(panel: Panel) {
        viewModelScope.launch {
            val story = _currentStory.value ?: run {
                _error.value = "Chưa mở truyện nào."
                return@launch
            }
            _isRunningConditioningTest.value = true
            _conditioningTestResult.value = null
            try {
                val outDir = java.io.File(appCtx.cacheDir, "conditioning_test").apply { mkdirs() }
                val result = pipeline.runConditioningComparisonTest(panel, story, _settings.value, outDir)
                if (result == null) {
                    _error.value = "Không tìm thấy nhân vật nào có ảnh anchor trong panel này — chỉ so sánh " +
                        "được cho đường sinh 1-nhân-vật (IP-Adapter đơn), xem giới hạn thật mục 107."
                } else {
                    _conditioningTestResult.value = result
                }
            } catch (e: Exception) {
                _error.value = "Lỗi chạy So Sánh Thử Pose/Depth: ${e.message}"
            } finally {
                _isRunningConditioningTest.value = false
            }
        }
    }

    fun dismissConditioningTestResult() { _conditioningTestResult.value = null }

    // Lưu lựa chọn "chọn bản này" vào conditioningOverride của ĐÚNG panel
    // đó — thắng tuyệt đối trong resolveConditioning() (mục 107), kể cả
    // nếu sau này action_category đổi hoặc cờ auto tắt/bật.
    fun applyConditioningChoice(panelIndex: Int, preset: ConditioningPreset) {
        val ch = _currentChapter.value ?: return
        val updated = ch.panels.map { p ->
            if (p.index == panelIndex) {
                val ov = (p.overrideSettings ?: PanelOverrideSettings()).copy(conditioningOverride = preset)
                p.copy(overrideSettings = ov)
            } else p
        }
        _currentChapter.value = ch.copy(panels = updated)
        storyManager.saveChapter(ch.copy(panels = updated))
        dismissConditioningTestResult()
    }

    // mục 95 TECHNICAL_STATUS.md — tự động tạo ảnh tham chiếu "áo rách".
    private val _isGeneratingTornReference = MutableStateFlow(false)
    val isGeneratingTornReference: StateFlow<Boolean> = _isGeneratingTornReference

    fun generateTornReferenceImage(character: Character) {
        viewModelScope.launch {
            val story = _currentStory.value ?: run {
                _error.value = "Chưa mở truyện nào — không xác định được worldRules."
                return@launch
            }
            _isGeneratingTornReference.value = true
            try {
                val outDir = java.io.File(appCtx.cacheDir, "torn_reference").apply { mkdirs() }
                val result = pipeline.generateTornReferenceImage(character, story.worldRules, _settings.value, outDir)
                if (result != null) {
                    storyManager.saveCharacterTornAnchor(story.id, character.id, result)
                    refreshCurrentStory()
                } else {
                    _error.value = "Không tạo được ảnh tham chiếu áo rách — nhân vật cần có ảnh anchor trước (mục ② IP-Adapter)."
                }
            } catch (e: Exception) {
                _error.value = "Lỗi tạo ảnh tham chiếu áo rách: ${e.message}"
            } finally {
                _isGeneratingTornReference.value = false
            }
        }
    }



    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating
    // Cờ RIÊNG cho giai đoạn 1 (prepareChapter — phân tích kịch bản, chưa
    // sinh ảnh) — tách khỏi isGenerating (giai đoạn 2, sinh ảnh thật) để
    // điều hướng đúng màn hình: isPreparing -> routing_review,
    // isGenerating -> generating (xem StoryScreens.kt).
    private val _isPreparing = MutableStateFlow(false)
    val isPreparing: StateFlow<Boolean> = _isPreparing

    private val _sdModels  = MutableStateFlow<List<ModelInfo>>(emptyList())
    private val _llmModels = MutableStateFlow<List<ModelInfo>>(emptyList())
    private val _loras     = MutableStateFlow<List<ModelInfo>>(emptyList())
    val sdModels:  StateFlow<List<ModelInfo>> = _sdModels
    val llmModels: StateFlow<List<ModelInfo>> = _llmModels
    val loras:     StateFlow<List<ModelInfo>> = _loras

    fun rescanModels() {
        _sdModels.value  = storyManager.scanSdModels()
        _llmModels.value = storyManager.scanLlmModels()
        _loras.value     = storyManager.scanLoras()
    }

    // ── Nhập model từ UI (SAF picker — xem SettingsScreen.kt mục "Nhập model") ──
    private val appCtx get() = getApplication<android.app.Application>()

    fun importLlmModels(uris: List<android.net.Uri>) {
        val names = storyManager.importFiles(appCtx, uris, storyManager.modelsDir)
        rescanModels()
        _error.value = if (names.isNotEmpty()) "✅ Đã nhập ${names.size} file LLM: ${names.joinToString(", ")}"
            else "Không nhập được file nào."
    }

    fun importLoras(uris: List<android.net.Uri>) {
        val names = storyManager.importFiles(appCtx, uris, storyManager.lorasDir)
        rescanModels()
        _error.value = if (names.isNotEmpty()) "✅ Đã nhập ${names.size} LoRA: ${names.joinToString(", ")}"
            else "Không nhập được file nào."
    }

    // mục 69 TECHNICAL_STATUS.md — LoRA Addon (chất lượng chung, TOÀN CỤC).
    fun addonLoras() = storyManager.listAddonLoras()
    fun addAddonLora(uri: android.net.Uri, displayName: String) {
        val entry = storyManager.addAddonLora(appCtx, uri, displayName)
        _error.value = if (entry != null) "✅ Đã thêm Addon LoRA \"${entry.displayName}\" — CHỈ áp dụng cho model convert TỪ SAU thời điểm này, model cũ cần convert lại."
            else "Không thêm được file LoRA này."
    }
    fun removeAddonLora(id: String) = storyManager.removeAddonLora(id)
    fun setAddonLoraEnabled(id: String, enabled: Boolean) = storyManager.setAddonLoraEnabled(id, enabled)
    fun setAddonLoraWeight(id: String, weight: Float) = storyManager.setAddonLoraWeight(id, weight)

    fun importEmbeddingSources(uris: List<android.net.Uri>) {
        val names = storyManager.importFiles(appCtx, uris, storyManager.embeddingSourcesDir)
        rescanConsistencySources()
        _error.value = if (names.isNotEmpty()) "✅ Đã nhập ${names.size} embedding: ${names.joinToString(", ")}"
            else "Không nhập được file nào."
    }

    fun importYoloModels(uris: List<android.net.Uri>) {
        val names = storyManager.importFiles(appCtx, uris, storyManager.yoloDir)
        _error.value = if (names.isNotEmpty()) "✅ Đã nhập ${names.size} file YOLO: ${names.joinToString(", ")}"
            else "Không nhập được file nào."
    }

    fun importEsrganModels(uris: List<android.net.Uri>) {
        val names = storyManager.importFiles(appCtx, uris, storyManager.esrganDir)
        _error.value = if (names.isNotEmpty()) "✅ Đã nhập ${names.size} file ESRGAN: ${names.joinToString(", ")}"
            else "Không nhập được file nào."
    }

    /** modelId: tên thư mục con trong models/ — nên khớp đúng "id" trong model_manifest.json để app nhận diện được model. */
    fun importSdModelFolder(treeUri: android.net.Uri, modelId: String) {
        val count = storyManager.importSdModelFolder(appCtx, treeUri, modelId)
        rescanModels(); rescanConsistencySources()
        _error.value = if (count > 0) "✅ Đã nhập $count file vào models/$modelId/"
            else "Không nhập được file nào — kiểm tra lại thư mục đã chọn."
    }

    fun updateSettings(block: GenerationSettings.() -> GenerationSettings) {
        _settings.update { it.block() }
        thermalMonitor.updateThreshold(_settings.value.thermalThreshold)
    }

    // mục 75 TECHNICAL_STATUS.md — nút "Xoá kho seed" trong SettingsScreen.
    // Xoá kho seed "hoàn hảo" (SeedRegistry) của truyện đang mở — nên gọi
    // sau khi đổi SD model (seed model cũ không còn ý nghĩa với model mới).
    // Không tự động xoá khi đổi model (StoryDetailScreen mục 71) vì đó là
    // hành vi ÂM THẦM có thể gây bất ngờ — để user tự bấm khi họ muốn.
    fun clearSeedRegistry() {
        val story = _currentStory.value ?: return
        SeedRegistry(storyManager.storyDir(story.id)).clear()
        _error.value = "✅ Đã xoá kho seed hoàn hảo của truyện \"${story.title}\"."
    }

    // ── Story management ──────────────────────────────────────────────────
    fun createStory(title: String, description: String, style: ImageStyle, worldRules: String = "", promptGuideNotes: String = "") {
        val story = Story(id = UUID.randomUUID().toString(), title = title,
            description = description, style = style, worldRules = worldRules, promptGuideNotes = promptGuideNotes)
        storyManager.saveStory(story)
        _stories.value = storyManager.loadAllStories()
        _currentStory.value = story
    }

    fun updateWorldRules(worldRules: String) {
        val story = _currentStory.value ?: return
        val updated = story.copy(worldRules = worldRules)
        storyManager.saveStory(updated)
        _currentStory.value = updated
    }

    // Mục 54 TECHNICAL_STATUS.md — analog của updateWorldRules() ở trên.
    // ĐÍNH CHÍNH (mục 139 TECHNICAL_STATUS.md): comment gốc ở đây từng nói
    // "KHÔNG có UI gọi" — ĐÚNG tại thời điểm viết (mục 54), nhưng mục 66
    // (sau đó) đã thêm `EditStoryRulesSheet` (StoryScreens.kt) gọi CẢ
    // `updateWorldRules()` LẪN hàm này qua nút bút chì trên StoryDetailScreen
    // — comment cũ KHÔNG được cập nhật theo, gây hiểu lầm hàm này vẫn chưa
    // có UI dù thực tế đã có từ lâu. Phát hiện khi audit toàn diện (mục
    // 137-139) đối chiếu comment với code thật thay vì tin theo chữ.
    fun updatePromptGuideNotes(promptGuideNotes: String) {
        val story = _currentStory.value ?: return
        val updated = story.copy(promptGuideNotes = promptGuideNotes)
        storyManager.saveStory(updated)
        _currentStory.value = updated
    }

    // mục 78 TECHNICAL_STATUS.md — bật/tắt tra cứu Concept Dictionary khi
    // sinh prompt, gọi từ ConceptDictionarySheet (StoryScreens.kt).
    fun updateStoryConceptDictionaryEnabled(storyId: String, enabled: Boolean) {
        val story = _currentStory.value?.takeIf { it.id == storyId } ?: storyManager.loadStory(storyId) ?: return
        val updated = story.copy(conceptDictionaryEnabled = enabled)
        storyManager.saveStory(updated)
        if (_currentStory.value?.id == storyId) _currentStory.value = updated
    }

    fun selectStory(story: Story) {
        _currentStory.value = storyManager.loadStory(story.id) ?: story
    }

    // mục 71 TECHNICAL_STATUS.md — Model Binding. Gọi ĐẦU MỌI hàm sinh ảnh
    // (prepareChapter/runIndustrialBatch) TRƯỚC khi động tới native. Trả
    // null nếu OK (đã khoá hoặc vừa khoá xong), trả THÔNG BÁO LỖI nếu model
    // đang chọn khác model đã khoá của truyện — gọi nơi PHẢI return sớm.
    private fun bindOrCheckModel(story: Story, sdModelId: String): String? {
        if (story.boundSdModelId == null) {
            // Lần sinh ĐẦU TIÊN của truyện này -> tự khoá vào model đang
            // chọn, không cần user thao tác gì thêm (không có ma sát UX).
            val updated = story.copy(boundSdModelId = sdModelId)
            storyManager.saveStory(updated)
            _currentStory.value = updated
            return null
        }
        if (story.boundSdModelId != sdModelId) {
            return "Truyện \"${story.title}\" đã khoá vào model \"${story.boundSdModelId}\" từ lần sinh đầu tiên " +
                "(chống gãy phong cách giữa chừng). Model đang chọn trong Cài đặt (\"$sdModelId\") khác model đó. " +
                "Vào màn Truyện → nút \"Đổi model cho truyện này\" nếu THẬT SỰ muốn đổi (panel cũ sẽ KHÔNG tự convert lại)."
        }
        return null
    }

    /** Đổi tường minh model đã khoá — người dùng PHẢI chủ động bấm, không tự động. */
    fun rebindStoryModel(newSdModelId: String) {
        val story = _currentStory.value ?: return
        val updated = story.copy(boundSdModelId = newSdModelId)
        storyManager.saveStory(updated)
        _currentStory.value = updated
        _error.value = "✅ Đã đổi model khoá của truyện sang \"$newSdModelId\". Panel CŨ vẫn giữ nguyên, không tự vẽ lại."
    }

    fun deleteStory(storyId: String) {
        storyManager.deleteStory(storyId)
        _stories.value = storyManager.loadAllStories()
        if (_currentStory.value?.id == storyId) _currentStory.value = null
    }

    fun refreshCurrentStory() {
        _currentStory.value?.let { _currentStory.value = storyManager.loadStory(it.id) }
    }

    // ── Character management ──────────────────────────────────────────────
    fun addCharacter(name: String, anchor: String, neg: String, role: CharacterRole, loraPath: String?, seed: Long?) {
        val story = _currentStory.value ?: return
        val char = Character(
            id = UUID.randomUUID().toString(), name = name.trim(), anchorPrompt = anchor.trim(),
            negativePrompt = neg.ifBlank { "bad anatomy, bad hands, extra fingers" },
            seed = seed ?: (10000L..99999L).random(), role = role,
            loraPath = loraPath?.ifBlank { null }
        )
        storyManager.saveCharacter(story.id, char)
        refreshCurrentStory()
    }

    fun updateCharacter(character: Character) {
        val story = _currentStory.value ?: return
        storyManager.saveCharacter(story.id, character)
        refreshCurrentStory()
    }

    fun deleteCharacter(characterId: String) {
        val story = _currentStory.value ?: return
        storyManager.deleteCharacter(story.id, characterId)
        refreshCurrentStory()
    }

    fun convertCharacterPair(characters: List<Character>, checkpointPath: String) {
        val story = _currentStory.value ?: return
        if (characters.size < 2) { _error.value = "Cần chọn ít nhất 2 nhân vật để ghép cặp"; return }
        val baseModelId = _settings.value.sdModelId
        _convertBusy.value = characters.joinToString("+") { it.name }
        viewModelScope.launch {
            try {
                val ok = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    storyManager.convertAndRegisterPairModel(baseModelId, checkpointPath, characters)
                }
                if (ok) {
                    refreshCurrentStory()
                } else {
                    _error.value = "Ghép cặp LoRA thất bại — kiểm tra model mặc định ($baseModelId) đã convert xong " +
                        "chưa (cần file khung unet.mnn/vae_decoder.mnn/vae_encoder.mnn), và mỗi nhân vật đã có loraPath chưa."
                }
            } catch (ex: Exception) {
                _error.value = "Ghép cặp LoRA lỗi: ${ex.message}"
            } finally {
                _convertBusy.value = null
            }
        }
    }

    // mục 102 TECHNICAL_STATUS.md — implement thật (trước đây stub rỗng,
    // không nơi nào gọi — xem MangaPipeline.regenerateAnchorImage() cho
    // logic sinh ảnh + GIỚI HẠN THẬT đầy đủ). Cùng khuôn mẫu
    // generateTornReferenceImage() ở trên.
    private val _isGeneratingAnchor = MutableStateFlow(false)
    val isGeneratingAnchor: StateFlow<Boolean> = _isGeneratingAnchor

    fun regenerateAnchor(character: Character) {
        viewModelScope.launch {
            val story = _currentStory.value ?: run {
                _error.value = "Chưa mở truyện nào — không xác định được worldRules."
                return@launch
            }
            _isGeneratingAnchor.value = true
            try {
                val outDir = java.io.File(appCtx.cacheDir, "anchor_regen").apply { mkdirs() }
                val result = pipeline.regenerateAnchorImage(character, story.worldRules, _settings.value, outDir)
                if (result != null) {
                    storyManager.saveCharacterAnchor(story.id, character.id, result)
                    refreshCurrentStory()
                } else {
                    _error.value = "Tạo ảnh anchor bằng AI thất bại — kiểm tra anchorPrompt của nhân vật đã có mô tả chưa."
                }
            } catch (e: Exception) {
                _error.value = "Tạo ảnh anchor lỗi: ${e.message}"
            } finally {
                _isGeneratingAnchor.value = false
            }
        }
    }

    // mục 111 TECHNICAL_STATUS.md — CharacterApprovalSheet: "Máy tự động
    // phác thảo, người dùng duyệt chốt" (đúng triết lý đã ghi trong
    // thêm_sd1_5.txt) thay vì regenerateAnchor() gán thẳng 1 ảnh. Character
    // đang chờ duyệt (null = không có sheet nào đang mở) + danh sách path
    // ứng viên vừa sinh.
    private val _approvalCandidates = MutableStateFlow<List<String>>(emptyList())
    val approvalCandidates: StateFlow<List<String>> = _approvalCandidates
    private val _approvalCharacter = MutableStateFlow<Character?>(null)
    val approvalCharacter: StateFlow<Character?> = _approvalCharacter
    private val _isGeneratingCandidates = MutableStateFlow(false)
    val isGeneratingCandidates: StateFlow<Boolean> = _isGeneratingCandidates

    fun generateAnchorCandidates(character: Character, count: Int = 4) {
        viewModelScope.launch {
            val story = _currentStory.value ?: run {
                _error.value = "Chưa mở truyện nào — không xác định được worldRules."
                return@launch
            }
            _isGeneratingCandidates.value = true
            _approvalCharacter.value = character
            _approvalCandidates.value = emptyList()
            try {
                val outDir = java.io.File(appCtx.cacheDir, "anchor_candidates").apply { mkdirs() }
                val results = pipeline.regenerateAnchorCandidates(character, story.worldRules, _settings.value, outDir, count)
                _approvalCandidates.value = results
                if (results.isEmpty()) {
                    _error.value = "Tạo ảnh nháp thất bại — kiểm tra anchorPrompt của nhân vật đã có mô tả chưa."
                    _approvalCharacter.value = null
                }
            } catch (e: Exception) {
                _error.value = "Tạo ảnh nháp lỗi: ${e.message}"
                _approvalCharacter.value = null
            } finally {
                _isGeneratingCandidates.value = false
            }
        }
    }

    /** User bấm chọn 1 ảnh trong lưới duyệt — khoá làm anchorImagePath chính thức. */
    fun approveAnchorCandidate(path: String) {
        val character = _approvalCharacter.value ?: return
        val story = _currentStory.value ?: return
        storyManager.saveCharacterAnchor(story.id, character.id, path)
        refreshCurrentStory()
        dismissApprovalSheet()
    }

    fun dismissApprovalSheet() {
        _approvalCharacter.value = null
        _approvalCandidates.value = emptyList()
    }

    // mục 161 TECHNICAL_STATUS.md — "Dynamic Identity Bootstrap": Y HỆT
    // luồng CharacterApprovalSheet ở trên (không viết lại UI/state pattern
    // — chỉ nhân bản đúng cấu trúc cho "phiên bản ngoại hình theo chương"
    // thay vì "ảnh anchor gốc"), khác 2 chỗ: (1) cần thêm
    // `changeDescription` (mô tả cái gì đổi) + `fromChapterNumber` (áp
    // dụng từ chương nào), (2) bấm chọn ảnh gọi
    // `saveCharacterAnchorVersion()` thay vì `saveCharacterAnchor()`.
    private val _versionApprovalCandidates = MutableStateFlow<List<String>>(emptyList())
    val versionApprovalCandidates: StateFlow<List<String>> = _versionApprovalCandidates
    private val _versionApprovalCharacter = MutableStateFlow<Character?>(null)
    val versionApprovalCharacter: StateFlow<Character?> = _versionApprovalCharacter
    private val _isGeneratingVersionCandidates = MutableStateFlow(false)
    val isGeneratingVersionCandidates: StateFlow<Boolean> = _isGeneratingVersionCandidates
    // Ghi lại đúng tham số của lượt sinh gần nhất — để "Sinh lại 4 bản
    // khác" (nút trong sheet) không cần user gõ lại mô tả/số chương.
    private var _versionApprovalChangeDesc: String = ""
    private var _versionApprovalFromChapter: Int = 1
    private var _versionApprovalBoneOverride: BoneProportions? = null

    fun generateAnchorVersionCandidates(
        character: Character, changeDescription: String, fromChapterNumber: Int,
        boneProportionsOverride: BoneProportions? = null, count: Int = 4
    ) {
        viewModelScope.launch {
            val story = _currentStory.value ?: run {
                _error.value = "Chưa mở truyện nào — không xác định được worldRules."
                return@launch
            }
            _versionApprovalChangeDesc = changeDescription
            _versionApprovalFromChapter = fromChapterNumber
            _versionApprovalBoneOverride = boneProportionsOverride
            _isGeneratingVersionCandidates.value = true
            _versionApprovalCharacter.value = character
            _versionApprovalCandidates.value = emptyList()
            try {
                val outDir = java.io.File(appCtx.cacheDir, "anchor_version_candidates").apply { mkdirs() }
                val results = pipeline.generateAnchorVersionCandidates(
                    character, changeDescription, story.worldRules, _settings.value, outDir, count
                )
                _versionApprovalCandidates.value = results
                if (results.isEmpty()) {
                    _error.value = "Tạo ảnh nháp thất bại — kiểm tra anchorPrompt của nhân vật đã có mô tả chưa."
                    _versionApprovalCharacter.value = null
                }
            } catch (e: Exception) {
                _error.value = "Tạo ảnh nháp lỗi: ${e.message}"
                _versionApprovalCharacter.value = null
            } finally {
                _isGeneratingVersionCandidates.value = false
            }
        }
    }

    fun regenerateAnchorVersionCandidates() {
        val character = _versionApprovalCharacter.value ?: return
        generateAnchorVersionCandidates(
            character, _versionApprovalChangeDesc, _versionApprovalFromChapter, _versionApprovalBoneOverride
        )
    }

    /** User bấm chọn 1 ảnh — khoá làm phiên bản ngoại hình từ đúng chương đã chọn. */
    fun approveAnchorVersionCandidate(path: String) {
        val character = _versionApprovalCharacter.value ?: return
        val story = _currentStory.value ?: return
        storyManager.saveCharacterAnchorVersion(
            story.id, character.id, _versionApprovalFromChapter, path,
            label = _versionApprovalChangeDesc, boneProportionsOverride = _versionApprovalBoneOverride
        )
        refreshCurrentStory()
        dismissVersionApprovalSheet()
    }

    fun dismissVersionApprovalSheet() {
        _versionApprovalCharacter.value = null
        _versionApprovalCandidates.value = emptyList()
    }

    fun deleteAnchorVersion(character: Character, fromChapterNumber: Int) {
        val story = _currentStory.value ?: return
        storyManager.deleteCharacterAnchorVersion(story.id, character.id, fromChapterNumber)
        refreshCurrentStory()
    }

    // mục 161 TECHNICAL_STATUS.md (đợt 3) — "#4 Dynamic Model Delivery".
    // State per-file (key = destFile.absolutePath, tránh trùng tên file
    // giữa các model khác nhau) — đơn giản hơn nhiều so với 1 hệ thống
    // hàng đợi tổng quát, ĐỦ DÙNG cho quy mô thật (vài chục file, không
    // phải hàng nghìn) của tính năng này.
    private val _downloadProgress = MutableStateFlow<Map<String, Pair<Long, Long>>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, Pair<Long, Long>>> = _downloadProgress
    private val _downloadErrors = MutableStateFlow<Map<String, String>>(emptyMap())
    val downloadErrors: StateFlow<Map<String, String>> = _downloadErrors
    private val _isDownloading = MutableStateFlow(false)
    val isDownloading: StateFlow<Boolean> = _isDownloading

    fun listDownloadTargets(modelId: String? = null) = storyManager.listDownloadTargets(modelId)

    // mục 161 TECHNICAL_STATUS.md (đợt 4 — "#7 WebP/JPEG panel trung
    // gian"). Chỉ hoạt động trên chương ĐANG MỞ (`_currentChapter`) — xem
    // giới hạn an toàn thật (chỉ dọn khi cbzPath còn tồn tại) ở
    // `StoryManager.cleanupExportedChapterIntermediates()`.
    private val _cleanupResultMsg = MutableStateFlow<String?>(null)
    val cleanupResultMsg: StateFlow<String?> = _cleanupResultMsg

    fun cleanupExportedIntermediates(mode: StoryManager.CleanupMode) {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                storyManager.cleanupExportedChapterIntermediates(story.id, ch.id, mode)
            }
            val refreshed = storyManager.loadChapter(story.id, ch.id)
            if (refreshed != null) _currentChapter.value = refreshed
            _cleanupResultMsg.value = if (result.filesProcessed == 0) "Không có file nào cần dọn (đã dọn trước đó, hoặc chương chưa xuất .cbz)."
                else "Đã xử lý ${result.filesProcessed} file, giải phóng ~${result.bytesFreed / 1_000_000}MB."
        }
    }

    fun dismissCleanupResult() { _cleanupResultMsg.value = null }

    fun downloadModelFiles(targets: List<StoryManager.DownloadTarget>) {
        if (_isDownloading.value) return // đã có 1 lượt tải đang chạy — tránh bấm 2 lần chạy song song đè dữ liệu tiến trình lẫn nhau
        viewModelScope.launch {
            _isDownloading.value = true
            _downloadErrors.value = emptyMap()
            try {
                ModelDownloader.downloadAll(
                    targets,
                    onItemProgress = { t, done, total ->
                        _downloadProgress.value = _downloadProgress.value + (t.destFile.absolutePath to (done to total))
                    },
                    onItemDone = { t, result ->
                        if (result is ModelDownloader.DownloadResult.Failed) {
                            _downloadErrors.value = _downloadErrors.value + (t.destFile.absolutePath to result.message)
                        }
                    }
                )
            } finally {
                _isDownloading.value = false
            }
        }
    }

    // ── 3 phương pháp nhất quán nhân vật (mục 13 TECHNICAL_STATUS.md) ──────
    private val _checkpoints = MutableStateFlow<List<ModelInfo>>(emptyList())
    val checkpoints: StateFlow<List<ModelInfo>> = _checkpoints
    private val _embeddingSources = MutableStateFlow<List<ModelInfo>>(emptyList())
    val embeddingSources: StateFlow<List<ModelInfo>> = _embeddingSources
    private val _convertBusy = MutableStateFlow<String?>(null) // tên đang convert, null = rảnh
    val convertBusy: StateFlow<String?> = _convertBusy

    // SỬA (crash log thật: NullPointerException tại rescanConsistencySources,
    // gọi từ init{} — lúc đó _checkpoints/_embeddingSources CHƯA được khởi
    // tạo vì trước đây init{} nằm phía TRÊN 2 field này trong file. Kotlin
    // chạy property initializer và init{} theo ĐÚNG THỨ TỰ xuất hiện trong
    // class — init{} gọi hàm dùng field khai báo SAU nó thì field đó vẫn
    // còn null lúc đó, gây NPE ngay khi tạo ViewModel. Chuyển init{} xuống
    // đây — sau khi MỌI field nó cần (_error, _sdModels/_llmModels/_loras,
    // _checkpoints/_embeddingSources) đã có giá trị thật.
    init {
        // Nếu StoryManager không ghi được vào bộ nhớ ngoài (thiếu quyền
        // "Quản lý tất cả tệp" trên Android 11+), hiện thông báo rõ ràng
        // qua _error (đã có sẵn dialog hiện error này) thay vì để các hàm
        // bên dưới ném IOException không ai bắt -> crash cả app.
        storyManager.initError?.let { _error.value = it }
        storyManager.ensureManifestInitialized(app)
        storyManager.ensurePoseLibraryInitialized(app)
        rescanModels()
        rescanConsistencySources()
        // mục 161 (đợt 8) — forward pipeline.state (đường CŨ, in-process —
        // runIndustrialBatch/regeneratePanel/... CHƯA chuyển qua IPC) vào
        // _pipelineState CHUNG. Đường IPC MỚI (confirmRoutingAndGenerate())
        // ghi TRỰC TIẾP vào _pipelineState qua replyHandler ở trên — 2
        // nguồn cùng ghi 1 StateFlow, an toàn vì generationMutex đảm bảo
        // chỉ 1 đường chạy tại 1 thời điểm (không có 2 nguồn ghi ĐÈ nhau
        // cùng lúc trong thực tế).
        viewModelScope.launch { pipeline.state.collect { _pipelineState.value = it } }
    }

    fun rescanConsistencySources() {
        _checkpoints.value = storyManager.scanSdModels()
        _embeddingSources.value = storyManager.scanEmbeddingSources()
    }

    // LoRA: cần checkpoint gốc + file LoRA -> convert THẬT (tốn thời gian
    // CPU thật trên máy, không giả lập) -> đăng ký model riêng cho nhân vật.
    // sd_model_converter.cpp (đọc kỹ trước khi sửa): checkpointFile/loraFiles
    // PHẢI là TÊN FILE nằm NGAY TRONG modelDir (native tự nối dir+"/"+tên),
    // KHÔNG PHẢI đường dẫn tuyệt đối nơi khác — bản đầu tôi viết truyền
    // thẳng path tuyệt đối từ MangaLocal/models|loras, SẼ LUÔN THẤT BẠI.
    // Ngoài ra modelDir (thư mục riêng characterId, lần đầu convert sẽ RỖNG)
    // cần sẵn 3 file "khung" unet.mnn/vae_decoder.mnn/vae_encoder.mnn TRƯỚC
    // — copy từ model mặc định đang chọn trong settings (base model ĐÃ
    // convert sẵn, coi như nguồn khung dùng chung). Nếu base model đó CŨNG
    // chưa có 3 file khung này (vd chưa build/convert lần đầu bao giờ) thì
    // convert nhân vật cũng sẽ fail — phụ thuộc dây chuyền, không có cách
    // né, phải build/convert model mặc định trước.
    fun convertCharacterLora(character: Character, checkpointPath: String, loraFile: String) {
        val story = _currentStory.value ?: return
        val baseModelId = _settings.value.sdModelId
        _convertBusy.value = character.name
        viewModelScope.launch {
            try {
                val ok = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    val dir = java.io.File(storyManager.modelsDir, character.id).also { it.mkdirs() }
                    val baseDir = java.io.File(storyManager.modelsDir, baseModelId)
                    val templates = listOf("unet.mnn", "vae_decoder.mnn", "vae_encoder.mnn")
                    val missingTemplate = templates.firstOrNull { !java.io.File(baseDir, it).exists() }
                    if (missingTemplate != null) {
                        _error.value = "Model mặc định ($baseModelId) chưa có file khung '$missingTemplate' " +
                            "— phải có model gốc convert thành công trước khi convert riêng cho nhân vật."
                        return@withContext false
                    }
                    templates.forEach { java.io.File(baseDir, it).copyTo(java.io.File(dir, it), overwrite = true) }

                    val checkpointName = java.io.File(checkpointPath).name
                    java.io.File(checkpointPath).copyTo(java.io.File(dir, checkpointName), overwrite = true)
                    val loraName = java.io.File(loraFile).name
                    java.io.File(loraFile).copyTo(java.io.File(dir, loraName), overwrite = true)

                    storyManager.convertAndRegisterModel(
                        modelDirName = character.id, checkpointFile = checkpointName,
                        characterId = character.id, displayName = character.name,
                        loraFiles = listOf(loraName), loraWeights = listOf(character.loraWeight)
                    )
                }
                if (ok) {
                    storyManager.saveCharacter(story.id, character.copy(loraPath = loraFile))
                    refreshCurrentStory()
                } else if (_error.value == null) {
                    _error.value = "Convert LoRA cho ${character.name} thất bại — xem logcat tag MangaLocal_SDConverter"
                }
            } catch (ex: Exception) {
                _error.value = "Convert LoRA lỗi: ${ex.message}"
            } finally {
                _convertBusy.value = null
            }
        }
    }

    // IP-Adapter: chỉ cần copy ảnh vào đúng chỗ, KHÔNG cần convert gì —
    // encode lúc chạy (xem ip_adapter.cpp). uri từ ActivityResultContracts.OpenDocument().
    fun setCharacterAnchorImage(character: Character, uri: android.net.Uri) {
        val story = _currentStory.value ?: return
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val dest = java.io.File(storyManager.anchorsDir(story.id), "anchor_${character.id}.jpg")
                getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                    dest.outputStream().use { output -> input.copyTo(output) }
                }
                storyManager.saveCharacterAnchor(story.id, character.id, dest.absolutePath)
                refreshCurrentStory()
            } catch (ex: Exception) {
                _error.value = "Lưu ảnh anchor lỗi: ${ex.message}"
            }
        }
    }

    // Textual Inversion: copy .safetensors vào embeddingsDir của truyện,
    // đặt tên = trigger word (xem StoryManager.setCharacterEmbedding).
    fun setCharacterEmbeddingFromSource(character: Character, sourcePath: String) {
        val story = _currentStory.value ?: return
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val trigger = storyManager.setCharacterEmbedding(story.id, character.id, sourcePath)
            if (trigger == null) _error.value = "Gán Textual Inversion cho ${character.name} thất bại"
            refreshCurrentStory()
        }
    }

    fun setCharacterEmbeddingFromUri(character: Character, uri: android.net.Uri) {
        val story = _currentStory.value ?: return
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val tmp = java.io.File.createTempFile("ti_", ".safetensors", getApplication<Application>().cacheDir)
                getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                    tmp.outputStream().use { output -> input.copyTo(output) }
                }
                val trigger = storyManager.setCharacterEmbedding(story.id, character.id, tmp.absolutePath)
                tmp.delete()
                if (trigger == null) _error.value = "Gán Textual Inversion cho ${character.name} thất bại"
                refreshCurrentStory()
            } catch (ex: Exception) {
                _error.value = "Gán Textual Inversion lỗi: ${ex.message}"
            }
        }
    }

    fun clearConsistencyMethod(character: Character) {
        val story = _currentStory.value ?: return
        storyManager.saveCharacter(story.id, character.copy(
            loraPath = null, anchorImagePath = null, embeddingPath = null, embeddingTrigger = null
        ))
        refreshCurrentStory()
    }

    // ── Generation flow ──────────────────────────────────────────────────
    // GIAI ĐOẠN 1: phân tích kịch bản + tính sẵn routing local/remote cho
    // từng panel — CHƯA sinh ảnh gì. Kết quả vào _pendingChapter để
    // RoutingReviewScreen hiện cho user duyệt/sửa tay trước khi xác nhận.
    fun prepareChapter(storyText: String, extraIdentityHintNames: List<String> = emptyList()) {
        val story = _currentStory.value ?: run { _error.value = "Chưa chọn truyện"; return }
        val s = _settings.value
        if (s.sdModelPath.isEmpty())  { _error.value = "Chưa chọn SD Model"; return }
        if (s.llmModelPath.isEmpty()) { _error.value = "Chưa chọn LLM Model"; return }
        if (_isPreparing.value) return
        bindOrCheckModel(story, s.sdModelId)?.let { _error.value = it; return }

        _isPreparing.value = true
        viewModelScope.launch {
            try {
                generationMutex.withLock {
                    val chapterId = UUID.randomUUID().toString()
                    val chapterNum = (storyManager.loadAllChapters(story.id).maxOfOrNull { it.chapterNumber } ?: 0) + 1
                    _pendingChapter.value = pipeline.prepareChapter(story, storyText, s, chapterId, chapterNum, extraIdentityHintNames)
                }
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi không xác định"
            } finally {
                _isPreparing.value = false
            }
        }
    }

    // mục 154 TECHNICAL_STATUS.md — "đảo pipeline nhân vật" (đã ghi CHƯA
    // LÀM ở nhiều mục cũ, tự quyết định triển khai theo yêu cầu user).
    // BƯỚC 1: phân tích sơ bộ TRƯỚC khi viết kịch bản chi tiết. Nếu phát
    // hiện ĐỦ nhân vật MỚI (chưa có trong story.characters) -> dừng lại,
    // đẩy kết quả vào `pendingCharacterSummary` cho UI hiện màn xác nhận
    // (CharacterSummaryReviewScreen). Nếu KHÔNG có nhân vật mới nào (chương
    // 2 trở đi, mọi nhân vật đã biết từ trước — trường hợp PHỔ BIẾN NHẤT
    // sau chương 1) -> BỎ QUA màn xác nhận, gọi thẳng prepareChapter() như
    // TRƯỚC mục 154 — không thêm bước thừa cho case đã quen thuộc.
    fun analyzeCharactersFirst(rawText: String) {
        val story = _currentStory.value ?: run { _error.value = "Chưa chọn truyện"; return }
        val s = _settings.value
        if (s.sdModelPath.isEmpty())  { _error.value = "Chưa chọn SD Model"; return }
        if (s.llmModelPath.isEmpty()) { _error.value = "Chưa chọn LLM Model"; return }
        if (_isPreparing.value || isAnalyzingCharacters.value) return
        bindOrCheckModel(story, s.sdModelId)?.let { _error.value = it; return }
        if (rawText.isBlank()) { _error.value = "Chưa dán văn bản truyện"; return }

        isAnalyzingCharacters.value = true
        viewModelScope.launch {
            try {
                val existingNames = story.characters.map { it.name }
                val summaries = pipeline.analyzeCharacters(rawText, existingNames, s)
                    // Lọc lại LẦN NỮA ở tầng Kotlin (phòng LLM lỡ liệt kê lại
                    // tên đã dặn bỏ qua trong prompt — model yếu có thể
                    // không tuân lệnh, không tin tưởng tuyệt đối vào prompt).
                    .filter { summary -> existingNames.none { it.equals(summary.name, ignoreCase = true) } }
                if (summaries.isEmpty()) {
                    // Không có gì mới để hỏi — bỏ qua màn xác nhận, chạy
                    // thẳng luồng cũ (KHÔNG đổi hành vi cho case quen thuộc).
                    prepareChapter(rawText)
                } else {
                    pendingStoryTextForCharacterReview = rawText
                    _pendingCharacterSummary.value = summaries
                }
            } catch (e: Exception) {
                // Bước phân tích sơ bộ lỗi (LLM/JSON hỏng) -> KHÔNG chặn
                // người dùng lại — rơi về luồng cũ, coi như bước 154 không
                // tồn tại cho lượt này (đúng GIỚI HẠN THẬT đã ghi ở
                // LLMParser.extractCharacterSummary()). Không có kênh log
                // rời rạc ở tầng MainViewModel (chỉ MangaPipeline có, gắn
                // với phiên sinh ảnh đang chạy) — im lặng fallback là đủ,
                // hành động fallback TỰ NÓ đã là phản hồi cho user (màn
                // xác nhận không hiện ra, kịch bản vẫn được viết bình
                // thường).
                prepareChapter(rawText)
            } finally {
                isAnalyzingCharacters.value = false
            }
        }
    }

    /**
     * mục 154 TECHNICAL_STATUS.md — BƯỚC 2: user đã xem/sửa danh sách ở
     * CharacterSummaryReviewScreen, bấm xác nhận. [confirmed] = danh sách
     * CUỐI CÙNG (đã bỏ những cái user xoá, ROLE đã theo lựa chọn user chỉnh
     * — UI tự `.copy(suggestedRole = ...)` trước khi gọi hàm này).
     * [wantsIdentityNames] = tên những nhân vật user đánh dấu "cần giữ mặt
     * nhất quán" — CHỈ dùng làm hint TẠM cho `parseStory()` (xem
     * MangaPipeline.prepareChapter() `extraIdentityHintNames` — KHÔNG lưu
     * vào Character, method thật vẫn phải set sau ở CharactersScreen như
     * luồng cũ, đúng nguyên tắc StoryManager.currentConsistencyMethod()).
     */
    fun confirmCharacterSummaryAndProceed(confirmed: List<CharacterSummary>, wantsIdentityNames: Set<String>) {
        val story = _currentStory.value ?: return
        val text = pendingStoryTextForCharacterReview ?: return
        confirmed.forEach { summary ->
            if (story.characters.none { it.name.equals(summary.name, ignoreCase = true) }) {
                addCharacter(summary.name, summary.briefDescription.ifBlank { summary.name },
                    "", summary.suggestedRole, null, null)
            }
        }
        _pendingCharacterSummary.value = null
        pendingStoryTextForCharacterReview = null
        prepareChapter(text, wantsIdentityNames.toList())
    }

    /** Bấm "Huỷ" ở màn xác nhận nhân vật — quay lại ô dán văn bản, KHÔNG
     * làm gì cả (không tạo nhân vật, không viết kịch bản). */
    fun cancelCharacterSummaryReview() {
        _pendingCharacterSummary.value = null
        pendingStoryTextForCharacterReview = null
    }

    // mục 120 TECHNICAL_STATUS.md — bypass parseStory(), dùng kịch bản đã
    // chia scene sẵn từ LLM ngoài app (dán JSON, xem ExternalScriptImport.kt
    // cho format + giới hạn thật). Song song với prepareChapter() ở trên,
    // chỉ khác nguồn scenes — mọi bước sau đó (buildPrompt() vẫn cần LLM
    // on-device, routing, review) giống hệt.
    fun prepareChapterFromExternalScript(rawJson: String) {
        val story = _currentStory.value ?: run { _error.value = "Chưa chọn truyện"; return }
        val s = _settings.value
        if (s.sdModelPath.isEmpty())  { _error.value = "Chưa chọn SD Model"; return }
        if (s.llmModelPath.isEmpty()) { _error.value = "Chưa chọn LLM Model (vẫn cần — chỉ dịch prompt, xem giới hạn thật)"; return }
        if (_isPreparing.value) return
        bindOrCheckModel(story, s.sdModelId)?.let { _error.value = it; return }

        val parsed = try {
            ExternalScriptImport.parseFromRawJson(rawJson)
        } catch (e: IllegalArgumentException) {
            _error.value = e.message ?: "JSON không hợp lệ"
            return
        }

        _isPreparing.value = true
        viewModelScope.launch {
            try {
                generationMutex.withLock {
                    val chapterId = UUID.randomUUID().toString()
                    val chapterNum = (storyManager.loadAllChapters(story.id).maxOfOrNull { it.chapterNumber } ?: 0) + 1
                    _pendingChapter.value = pipeline.prepareChapterFromExternalScript(story, parsed, s, chapterId, chapterNum)
                }
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi không xác định"
            } finally {
                _isPreparing.value = false
            }
        }
    }

    // mục 70 TECHNICAL_STATUS.md — bước "phân tích trước khi quyết định
    // quy trình". Gọi khi người dùng dán văn bản vào ô nhập (KHÔNG tự động
    // chạy gì — chỉ đếm số chương phát hiện được, hiện thẻ hỏi người dùng
    // chọn "Thủ công" (giữ nguyên hành vi prepareChapter() cũ) hay
    // "Công nghiệp" (runIndustrialBatch() bên dưới) nếu số chương vượt
    // TextChunker.INDUSTRIAL_SUGGEST_THRESHOLD. Nếu chỉ 1 chương (hoặc
    // không đánh số) — không hiện thẻ gì, luồng cũ chạy y hệt trước đây.
    fun analyzeStoryText(rawText: String) {
        if (rawText.isBlank()) { _detectedChapters.value = null; return }
        val chapters = TextChunker.split(rawText)
        _detectedChapters.value = if (chapters.size >= TextChunker.INDUSTRIAL_SUGGEST_THRESHOLD) chapters else null
    }
    fun dismissBatchSuggestion() { _detectedChapters.value = null }

    /**
     * mục 70 TECHNICAL_STATUS.md — chế độ CÔNG NGHIỆP: chạy tuần tự N
     * chương liên tiếp, KHÔNG dừng lại chờ người dùng duyệt routing từng
     * chương (khác luồng thủ công — vẫn dùng ĐÚNG BackendRouter tự động
     * đã có, chỉ bỏ bước dừng tay). Tái dùng 100% pipeline.prepareChapter()
     * + pipeline.runGeneration() đã có (KHÔNG viết logic sinh ảnh riêng
     * cho batch — tránh 2 luồng generate khác nhau rồi lệch hành vi).
     * Vòng lặp for tuần tự bên trong 1 coroutine duy nhất tự đảm bảo mỗi
     * lúc chỉ 1 chương chạy UNet (khớp yêu cầu "đơn luồng cục bộ" ở mức cơ
     * bản — CHƯA có Mutex tường minh, xem "Vẫn CHƯA" ở TECHNICAL_STATUS.md
     * mục 70 để biết rủi ro nếu người dùng gọi prepareChapter() thủ công
     * TRÙNG lúc batch đang chạy).
     */
    fun runIndustrialBatch(chapters: List<TextChunker.DetectedChapter>) {
        val story = _currentStory.value ?: run { _error.value = "Chưa chọn truyện"; return }
        val s = _settings.value
        if (s.sdModelPath.isEmpty())  { _error.value = "Chưa chọn SD Model"; return }
        if (s.llmModelPath.isEmpty()) { _error.value = "Chưa chọn LLM Model"; return }
        if (_isBatchRunning.value) return
        bindOrCheckModel(story, s.sdModelId)?.let { _error.value = it; return }
        _detectedChapters.value = null
        _batchFailedChapters.value = emptyList()

        // mục 142 TECHNICAL_STATUS.md — kiểm tra checkpoint cũ (tiến trình
        // trước bị hệ điều hành giết giữa chừng — xem BatchStateRegistry.kt).
        // Chỉ resume khi ĐÚNG truyện + ĐÚNG danh sách văn bản chương gốc
        // (hash khớp) — khác thì coi như batch mới, KHÔNG resume nhầm.
        val chaptersHash = batchStateRegistry.hashChapters(chapters.map { it.text })
        val oldCheckpoint = batchStateRegistry.loadCheckpointOrNull()
        val resumeFromIndex = if (oldCheckpoint != null &&
            oldCheckpoint.storyId == story.id &&
            oldCheckpoint.chaptersHash == chaptersHash &&
            oldCheckpoint.completedCount in 0 until chapters.size
        ) oldCheckpoint.completedCount else 0

        _isBatchRunning.value = true
        _batchProgress.value = resumeFromIndex to chapters.size

        // mục 77 TECHNICAL_STATUS.md — khởi động GenerationService (đã có
        // sẵn trong project, đăng ký đúng trong AndroidManifest.xml với đủ
        // permission FOREGROUND_SERVICE/WAKE_LOCK) để giữ CPU/WiFi hoạt
        // động xuyên suốt batch dù màn hình tắt. Không cần bind() 2 chiều —
        // _batchProgress StateFlow ở trên đã đủ cho UI, Service chỉ cần
        // SỐNG (giữ WakeLock/WifiLock) + hiện notification, không cần lấy
        // dữ liệu ngược từ Service.
        val serviceIntent = Intent(appCtx, GenerationService::class.java)
        androidx.core.content.ContextCompat.startForegroundService(appCtx, serviceIntent)

        viewModelScope.launch {
            var done = resumeFromIndex
            val failed = ArrayList<String>()
            try {
                generationMutex.withLock {
                    for (idx in resumeFromIndex until chapters.size) {
                        if (!_isBatchRunning.value) break  // cancelIndustrialBatch() đã bấm
                        val ch = chapters[idx]
                        // mục 142 TECHNICAL_STATUS.md — ERROR SHUNNING: 1 chương
                        // lỗi (văn bản dị dạng gây crash TextChunker/LLM, ảnh input
                        // hỏng...) KHÔNG được phép làm chết đứng toàn bộ batch —
                        // trước mục này, exception ở BẤT KỲ chương nào rơi ra catch
                        // ngoài và dừng hẳn, mất luôn các chương CHƯA chạy dù chúng
                        // không liên quan gì tới lỗi của chương trước. Giờ: bắt lỗi
                        // NGAY TẠI chương đó, ghi log, nhảy sang chương tiếp theo.
                        // mục 161 (đợt 10) — chapterId hoist RA NGOÀI try{}
                        // (trước ở trong, catch{} không truy cập được) — cần
                        // dùng trong catch để dọn chương "nháp" nếu generation
                        // lỗi giữa chừng, xem discardFailedPreparedChapter().
                        val chapterId = UUID.randomUUID().toString()
                        try {
                            val chapterNum = (storyManager.loadAllChapters(story.id).maxOfOrNull { it.chapterNumber } ?: 0) + 1
                            val prepared = pipeline.prepareChapter(story, ch.text, s, chapterId, chapterNum)
                            // mục 161 TECHNICAL_STATUS.md (đợt 9 — hoàn thành
                            // #5 cho đường thứ 2, industrial batch). ĐỔI từ
                            // pipeline.runGeneration() thẳng (in-process)
                            // sang runGenerationViaService() (IPC, tiến
                            // trình :inference riêng) — CHỈ đổi bước sinh
                            // ảnh (native risk cao), KHÔNG đổi prepareChapter
                            // (LLM parsing text, risk khác hẳn, vẫn
                            // in-process). Nếu tiến trình :inference CRASH
                            // giữa batch, runGenerationViaService() ném
                            // exception (từ onServiceDisconnected() ở trên)
                            // → rơi vào catch (chapterEx) NGAY BÊN DƯỚI —
                            // ĐÚNG cơ chế ERROR SHUNNING mục 142 đã có sẵn
                            // (1 chương lỗi không giết cả batch) — TỰ ĐỘNG
                            // được cả trường hợp "service crash" mà KHÔNG
                            // cần viết thêm code đặc biệt nào, vì
                            // ensureServiceBound() ở chương KẾ TIẾP sẽ tự
                            // bind lại (serviceMessenger đã bị set null bởi
                            // onServiceDisconnected(), Android tự khởi động
                            // lại tiến trình :inference mới khi bindService()
                            // gọi lại với BIND_AUTO_CREATE).
                            // mục 161 (đợt 9) — purgeAfter = true khi CÒN
                            // chương tiếp theo (khớp đúng điều kiện gốc
                            // `done < chapters.size` ở dòng purge cũ bên
                            // dưới — purge THẬT giờ chuyển hẳn vào
                            // GenerationService, chạy đúng tiến trình
                            // :inference, xem lý do đầy đủ ở đó).
                            val result = runGenerationViaService(story, prepared, s, purgeAfter = idx < chapters.size - 1)
                            storyManager.saveChapter(result)
                            _currentChapter.value = result
                        } catch (chapterEx: Exception) {
                            failed.add("Chương #${idx + 1}: ${chapterEx.message}")
                            batchStateRegistry.appendErrorLog(story.id, idx, chapterEx.message ?: chapterEx.toString())
                            _batchFailedChapters.value = failed.toList()
                            // mục 161 (đợt 10) — khôi phục ĐÚNG hành vi trước
                            // đợt 8/9: generation lỗi thì không để lại chương
                            // rỗng nào trên đĩa (xem giải thích đầy đủ ở
                            // confirmRoutingAndGenerate()/
                            // discardFailedPreparedChapter()). An toàn gọi kể
                            // cả khi lỗi xảy ra TRƯỚC lúc save() (vd
                            // prepareChapter() ném lỗi) — hàm tự no-op nếu
                            // chapterId chưa từng được save.
                            storyManager.discardFailedPreparedChapter(story.id, chapterId)
                        }
                        done++
                        _batchProgress.value = done to chapters.size

                        // mục 142 — ghi checkpoint SAU MỖI chương (thành công hay
                        // lỗi đều tính "đã xử lý xong", không thử lại vô hạn cùng
                        // chương lỗi) để nếu tiến trình bị hệ điều hành giết giữa
                        // batch, lần chạy sau resume đúng từ chương kế tiếp thay vì
                        // chạy lại từ đầu toàn bộ batch.
                        batchStateRegistry.saveCheckpoint(
                            BatchStateRegistry.Checkpoint(story.id, chaptersHash, done, chapters.size)
                        )

                        // mục 77 TECHNICAL_STATUS.md — RAM Purge Loop: hạ
                        // nhiệt 3 giây giữa các chương (cadence xác nhận từ
                        // 4 bản review, mục 73). mục 161 (đợt 9) — phần "giải
                        // phóng SD/SAM engine + ép GC" đã CHUYỂN vào
                        // GenerationService (qua tham số `purgeAfter` ở lời
                        // gọi runGenerationViaService() phía trên) — gọi
                        // pipeline.purgeEnginesBetweenChapters()/System.gc()
                        // NGAY TẠI ĐÂY (tiến trình UI) từ giờ VÔ TÁC DỤNG với
                        // RAM native thật (nằm ở tiến trình :inference) nên
                        // đã BỎ, chỉ còn giữ delay hạ nhiệt (không cần đúng
                        // tiến trình nào, chỉ là khoảng nghỉ thời gian).
                        if (done < chapters.size && _isBatchRunning.value) {
                            kotlinx.coroutines.delay(3_000L)
                        }
                    }
                }
                val okCount = done - failed.size
                _error.value = when {
                    done < chapters.size -> "⏸️ Đã huỷ giữa chừng — hoàn thành $okCount/${chapters.size} chương" +
                        (if (failed.isNotEmpty()) ", ${failed.size} chương lỗi (xem chi tiết bên dưới)." else ".")
                    failed.isEmpty() -> "✅ Đã chạy xong $done/${chapters.size} chương (chế độ công nghiệp)."
                    else -> "⚠️ Đã chạy xong $done/${chapters.size} chương — ${failed.size} chương LỖI đã bị bỏ qua (xem chi tiết bên dưới), " +
                        "$okCount chương thành công."
                }
                // Batch coi như đã CHẠY HẾT (dù có chương lỗi) — không còn gì để
                // resume, xoá checkpoint. Nếu bị huỷ tay giữa chừng (_isBatchRunning
                // = false do user bấm huỷ) thì GIỮ checkpoint lại để có thể resume
                // sau nếu user muốn tiếp tục đúng batch này.
                if (done >= chapters.size) batchStateRegistry.clearCheckpoint()
            } catch (e: Exception) {
                // Lỗi ở TẦNG NGOÀI vòng lặp (vd Mutex/coroutine bị huỷ bất thường,
                // không phải lỗi của riêng 1 chương) — vẫn giữ checkpoint để resume.
                _error.value = "Lô công nghiệp dừng ở chương ${done + 1}/${chapters.size}: ${e.message}"
            } finally {
                _isBatchRunning.value = false
                // mục 77 — dừng service (giải phóng WakeLock/WifiLock) dù
                // batch thành công/lỗi/bị huỷ giữa chừng — try/catch riêng
                // vì stopService không được phép làm mất kết quả batch đã có.
                // mục 161 (đợt 9) — dừng service SAU KHI batch xong. `stopService()`
                // ĐƠN LẺ không đủ để service thực sự huỷ (giải phóng WakeLock/
                // Notification) — service này giờ CÒN đang bị bindService()
                // giữ (từ runGenerationViaService()/ensureServiceBound() ở
                // trên) — Android chỉ thực sự huỷ 1 Service khi CẢ 2 điều
                // kiện hết: đã stopService() VÀ không còn ai bind. Thiếu
                // unbindService() ở đây sẽ khiến tiến trình :inference SỐNG
                // TREO đến khi ViewModel bị huỷ hẳn (onCleared()) — ngược hẳn
                // triết lý "giải phóng RAM giữa các chương" đã có từ mục
                // 77/133. Đặt serviceMessenger = null SAU unbind để lần gọi
                // runGenerationViaService() kế tiếp (batch khác, hoặc
                // confirmRoutingAndGenerate()) tự bind lại sạch từ đầu, không
                // tưởng nhầm còn kết nối cũ.
                try { appCtx.stopService(serviceIntent) } catch (_: Exception) {}
                if (serviceMessenger != null) {
                    try { appCtx.unbindService(serviceConnection) } catch (_: IllegalArgumentException) {}
                    serviceMessenger = null
                }
            }
        }
    }
    fun cancelIndustrialBatch() { _isBatchRunning.value = false }

    /** mục 142 TECHNICAL_STATUS.md — cho UI hỏi "có batch dở dang muốn tiếp
     * tục không" khi mở màn hình công nghiệp, TRƯỚC khi user dán lại text
     * (nếu dán đúng lại y hệt lần trước, hash khớp, runIndustrialBatch() ở
     * trên tự resume; hàm này chỉ để UI hiển thị gợi ý, không tự làm gì). */
    fun peekResumableBatch(): Pair<Int, Int>? {
        val cp = batchStateRegistry.loadCheckpointOrNull() ?: return null
        val story = _currentStory.value ?: return null
        if (cp.storyId != story.id) return null
        return cp.completedCount to cp.totalCount
    }

    /** Đánh dấu HÀNG LOẠT các panel đã chọn (theo index) sang 1 backend — dùng ở RoutingReviewScreen. */
    fun setBatchBackend(panelIndices: Set<Int>, backend: GenerationBackend) {
        val ch = _pendingChapter.value ?: return
        val updated = ch.panels.map { p ->
            if (p.index in panelIndices)
                p.copy(
                    overrideSettings = (p.overrideSettings ?: PanelOverrideSettings()).copy(backendOverride = backend),
                    routingReason = "Người dùng chọn tay (duyệt hàng loạt)"
                )
            else p
        }
        _pendingChapter.value = ch.copy(panels = updated)
    }

    /** Huỷ, quay lại không sinh ảnh gì — xoá bản đang chờ duyệt. */
    fun cancelPendingChapter() { _pendingChapter.value = null }

    // GIAI ĐOẠN 2: user đã duyệt xong (hoặc không sửa gì, giữ nguyên AUTO) —
    // sinh ảnh thật theo ĐÚNG routing đã đóng băng ở _pendingChapter, KHÔNG
    // gọi lại LLM parseStory() (đã làm 1 lần ở prepareChapter(), xem lý do
    // trong MangaPipeline.kt).
    fun confirmRoutingAndGenerate() {
        val story = _currentStory.value ?: run { _error.value = "Chưa chọn truyện"; return }
        val chapter = _pendingChapter.value ?: run { _error.value = "Chưa có gì để sinh — duyệt routing trước"; return }
        val s = _settings.value
        if (_isGenerating.value) return

        _isGenerating.value = true
        viewModelScope.launch {
            try {
                // mục 161 TECHNICAL_STATUS.md (đợt 8) — ĐỔI từ gọi thẳng
                // pipeline.runGeneration() (chạy in-process, native crash
                // kéo sập cả app) sang round-trip qua Messenger tới tiến
                // trình :inference riêng — xem GenerationService.kt +
                // runGenerationViaService() ở trên. Service ĐÃ tự
                // storyManager.saveChapter() phía nó (tiến trình
                // :inference, cùng filesDir vật lý) — gọi lại ở đây là DƯ
                // NHƯNG VÔ HẠI (ghi đè đúng y hệt nội dung, cùng 1 file) —
                // giữ lại làm phòng thủ kép, không đổi hành vi lưu trữ đã
                // có từ trước.
                val result = generationMutex.withLock { runGenerationViaService(story, chapter, s) }
                storyManager.saveChapter(result)
                _currentChapter.value = result
                _pendingChapter.value = null
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi không xác định"
                // mục 161 (đợt 10) — dọn lại chương "nháp" đã save() trước
                // khi gửi IPC (bắt buộc để Service đọc bằng ID) — khôi phục
                // ĐÚNG hành vi trước đợt 8: generation lỗi thì không để lại
                // gì trên đĩa, không có chương rỗng kẹt trong danh sách.
                storyManager.discardFailedPreparedChapter(story.id, chapter.id)
            } finally {
                _isGenerating.value = false
            }
        }
    }

    fun approvePanel(panelIndex: Int) {
        val ch = _currentChapter.value ?: return
        val updated = ch.panels.map { if (it.index == panelIndex) it.copy(status = PanelStatus.APPROVED) else it }
        _currentChapter.value = ch.copy(panels = updated)
        storyManager.saveChapter(ch.copy(panels = updated))
    }

    // mục 144 TECHNICAL_STATUS.md — "import ảnh ngoài thay 1 panel" (mục
    // 140 archive đánh giá khả thi, cần quyết định sản phẩm — quyết định:
    // làm). Bỏ qua generatePanel() hoàn toàn, xem
    // MangaPipeline.importPanelImage() cho cách xử lý crop tỷ lệ +
    // resolvedBackend/routingReason/Quality Gate.
    private val _importPanelBusy = MutableStateFlow(false)
    val importPanelBusy: StateFlow<Boolean> = _importPanelBusy

    fun importPanelImage(panelIndex: Int, uri: android.net.Uri) {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        val panel = ch.panels.find { it.index == panelIndex } ?: return
        _importPanelBusy.value = true
        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                val imported = pipeline.importPanelImage(panel, uri, appCtx, _settings.value, outDir)
                val updated = ch.panels.map { if (it.index == panelIndex) imported else it }
                _currentChapter.value = ch.copy(panels = updated)
                storyManager.saveChapter(ch.copy(panels = updated))
            } catch (e: Exception) {
                _error.value = "Import ảnh thất bại: ${e.message}"
            } finally {
                _importPanelBusy.value = false
            }
        }
    }

    fun regeneratePanel(panelIndex: Int, newPrompt: String? = null, overrides: PanelOverrideSettings? = null) {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        val panel = ch.panels.find { it.index == panelIndex } ?: return
        var updatedPanel = if (newPrompt != null) panel.copy(prompt = newPrompt, userNote = newPrompt) else panel
        if (overrides != null) updatedPanel = updatedPanel.copy(overrideSettings = overrides)

        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                val regenerated = generationMutex.withLock { pipeline.regeneratePanel(updatedPanel, story, _settings.value, outDir, chapterNumber = ch.chapterNumber) }
                val updated = ch.panels.map { if (it.index == panelIndex) regenerated else it }
                _currentChapter.value = ch.copy(panels = updated)
                storyManager.saveChapter(ch.copy(panels = updated))
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi regenerate panel"
            }
        }
    }

    // Mask thủ công / "Inpaint Anything" (mục 21 TECHNICAL_STATUS.md) —
    // dùng cho PHASE CUỐI (ảnh đã upscale xong, panel.upscaledPath != null)
    // khi user thấy vẫn còn lỗi mà auto-fix không bắt/sửa đúng. clickX/
    // clickY: toạ độ PIXEL theo ảnh tại panel.upscaledPath (UI tự quy đổi
    // từ toạ độ chạm trên màn hình sang toạ độ pixel ảnh thật trước khi gọi).
    private val _manualFixBusy = MutableStateFlow(false)
    val manualFixBusy: StateFlow<Boolean> = _manualFixBusy

    fun manualMaskFixPanel(panelIndex: Int, clickX: Float, clickY: Float, denoiseStrength: Float = 0.4f) {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        val panel = ch.panels.find { it.index == panelIndex } ?: return
        val imagePath = panel.upscaledPath ?: panel.imagePath ?: return
        _manualFixBusy.value = true
        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                val maskPath = manualMaskFixer.clickToMask(imagePath, clickX, clickY, outDir, panelIndex)
                if (maskPath == null) {
                    _error.value = "MobileSAM chưa sẵn sàng (thiếu model mobile_sam_encoder.mnn/mobile_sam_decoder.mnn) hoặc không phân đoạn được điểm này"
                    return@launch
                }
                val bmp = android.graphics.BitmapFactory.decodeFile(imagePath)
                val w = bmp?.width ?: settings.value.width
                val h = bmp?.height ?: settings.value.height
                bmp?.recycle()
                val fixedPath = manualMaskFixer.inpaintMaskedRegion(
                    panelIndex, panel.prompt, panel.negativePrompt, settings.value.imageStyle.stylePrompt,
                    imagePath, maskPath, denoiseStrength, w, h, panel.index.toLong() + 3000L, outDir
                )
                val updated = ch.panels.map { if (it.index == panelIndex) it.copy(upscaledPath = fixedPath) else it }
                _currentChapter.value = ch.copy(panels = updated)
                storyManager.saveChapter(ch.copy(panels = updated))
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi mask thủ công"
            } finally {
                _manualFixBusy.value = false
            }
        }
    }

    // Dịch mô tả tự nhiên -> prompt SD1.5 (mục 24 TECHNICAL_STATUS.md) —
    // dùng cho GalleryReviewScreen, LLMParser instance NGẮN HẠN riêng cho
    // 1 lần dịch (không giữ lâu dài, khác pipeline chính).
    private val _translating = MutableStateFlow(false)
    val translating: StateFlow<Boolean> = _translating

    // mục 114 TECHNICAL_STATUS.md — cache parser cấp ViewModel, key theo
    // modelPath: nút "Dịch" trong GalleryReviewScreen có thể bị bấm NHIỀU
    // LẦN khi user tinh chỉnh mô tả — trước đây mỗi lần bấm tạo LLMParser
    // MỚI + init() (load lại TOÀN BỘ model .gguf/.mnn từ đĩa, có thể mất
    // vài giây tới vài chục giây tuỳ kích thước model) rồi free() ngay sau
    // — lãng phí hoàn toàn, đúng loại bug mà LocalNovel mục 27 đã gặp và
    // sửa (dự án THAM CHIẾU nhưng thực ra CHƯA áp dụng cho đường này).
    // Giữ instance sống xuyên suốt VM (chỉ free khi model path đổi, vd đổi
    // trong Settings), không free ngay sau mỗi lần dịch.
    private var cachedTranslateParser: LLMParser? = null
    private var cachedTranslateParserModelPath: String? = null

    fun translateNaturalDescription(naturalDesc: String, stage: PromptStage, onResult: (PromptResult) -> Unit) {
        if (naturalDesc.isBlank()) return
        _translating.value = true
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val worldRules = _currentStory.value?.worldRules ?: ""
                // BUG PHÁT HIỆN (mục 54 TECHNICAL_STATUS.md): promptGuideNotes
                // (ghi chú cách viết tag SD1.5 của user, mục 24/54) đã được
                // truyền đúng ở đường buildPrompt() chính (MangaPipeline) từ
                // trước, NHƯNG đường translateStagePrompt() này (dùng cho
                // GalleryReviewScreen dịch mô tả tay) lại QUÊN truyền —
                // promptGuideNotes bị IM LẶNG BỎ QUA trên đường này dù user
                // đã điền. Sửa lại cho khớp.
                val promptGuideNotes = _currentStory.value?.promptGuideNotes ?: ""
                val modelPath = _settings.value.llmModelPath
                var parser = cachedTranslateParser
                if (parser == null || cachedTranslateParserModelPath != modelPath) {
                    cachedTranslateParser?.free() // model cũ đổi -> giải phóng trước khi load model mới
                    val hw = runtimeOptimizer.detectHardware()
                    val cfg = runtimeOptimizer.computeOptimalConfig(hw)
                    parser = LLMParser(modelPath, cfg.nThreads, cfg.nGpuLayers)
                    parser.init()
                    cachedTranslateParser = parser
                    cachedTranslateParserModelPath = modelPath
                }
                val result = parser.translateStagePrompt(naturalDesc, stage, worldRules, _settings.value.imageStyle.stylePrompt, promptGuideNotes)
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onResult(result) }
            } catch (e: Exception) {
                _error.value = "Dịch LLM lỗi: ${e.message}"
                // Lỗi có thể do parser cache hỏng (model file bị đổi/xoá giữa
                // chừng) — xoá cache để lần bấm "Dịch" tiếp theo thử load lại
                // từ đầu thay vì lặp lại đúng lỗi cũ mãi mãi.
                cachedTranslateParser?.free()
                cachedTranslateParser = null
                cachedTranslateParserModelPath = null
            } finally {
                _translating.value = false
            }
        }
    }

    fun updatePanelBubbles(panelIndex: Int, bubbles: List<Bubble>) {
        val ch = _currentChapter.value ?: return
        val updated = ch.panels.map { if (it.index == panelIndex) it.copy(bubbles = bubbles) else it }
        _currentChapter.value = ch.copy(panels = updated)
        storyManager.saveChapter(ch.copy(panels = updated))
    }

    fun proceedToUpscale() {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        _isGenerating.value = true
        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                // mục 83 TECHNICAL_STATUS.md — PHÁT HIỆN KHI VÁ CÙNG BATCH bug
                // use-after-free: `upscaleApprovedPanels()` TRƯỚC ĐÂY KHÔNG được
                // khoá `generationMutex` như `runGeneration()`/`regeneratePanel()`
                // — có thể chạy chồng lấn (double-tap/race UI), làm biến
                // `currentJob` dùng CHUNG trong MangaPipeline (mới thêm để
                // `cancelSafely()` hoạt động đúng) bị ghi đè sai giữa 2 lời gọi
                // đồng thời. Thêm khoá cho nhất quán với 2 điểm gọi kia — không
                // đổi hành vi chức năng, chỉ đảm bảo tuần tự hoá đúng.
                val upscaled = generationMutex.withLock { pipeline.upscaleApprovedPanels(ch, _settings.value, outDir) }
                storyManager.saveChapter(upscaled)
                _currentChapter.value = upscaled
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi upscale"
            } finally { _isGenerating.value = false }
        }
    }

    fun runAutoBubble() {
        val ch = _currentChapter.value ?: return
        _isGenerating.value = true
        viewModelScope.launch {
            try {
                val updated = pipeline.autoPlaceBubbles(ch)
                storyManager.saveChapter(updated)
                _currentChapter.value = updated
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi auto bubble"
            } finally { _isGenerating.value = false }
        }
    }

    // SỬA (yêu cầu chọn định dạng + nơi xuất): trước đây LUÔN xuất cả PDF+CBZ
    // vào đúng 1 thư mục nội bộ cố định (storyManager.outputDir), không cho
    // chọn gì. Giờ nhận thêm cờ định dạng + destUri (thư mục do user tự
    // chọn qua SAF picker — xem PostProcessingScreen.kt) — vẫn xuất vào thư
    // mục nội bộ TRƯỚC (ExportEngine dùng java.io.File thường, không hiểu
    // Uri), rồi COPY file kết quả sang destUri qua DocumentFile nếu có chọn.
    // destUri = null -> giữ nguyên hành vi cũ (chỉ nằm trong thư mục nội bộ).
    fun exportChapter(exportPdf: Boolean = true, exportCbz: Boolean = true, destUri: android.net.Uri? = null) {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                val exported = pipeline.exportChapter(ch, outDir, exportPdf, exportCbz, _settings.value.cbzJpegQuality, story.title)
                storyManager.saveChapter(exported)
                _currentChapter.value = exported

                if (destUri != null) {
                    val destTree = androidx.documentfile.provider.DocumentFile.fromTreeUri(getApplication<android.app.Application>(), destUri)
                    if (destTree == null || !destTree.canWrite()) {
                        _error.value = "Không ghi được vào thư mục đã chọn — chọn lại nơi lưu khác."
                        return@launch
                    }
                    val resolver = getApplication<android.app.Application>().contentResolver
                    listOfNotNull(
                        exported.pdfPath?.takeIf { exportPdf }?.let { it to "application/pdf" },
                        exported.cbzPath?.takeIf { exportCbz }?.let { it to "application/vnd.comicbook+zip" }
                    ).forEach { (path, mime) ->
                        val srcFile = java.io.File(path)
                        if (!srcFile.exists()) return@forEach
                        val existing = destTree.findFile(srcFile.name)
                        val destDoc = existing ?: destTree.createFile(mime, srcFile.name)
                        if (destDoc != null) {
                            resolver.openOutputStream(destDoc.uri, "wt")?.use { out ->
                                srcFile.inputStream().use { it.copyTo(out) }
                            }
                        }
                    }
                    _error.value = "✅ Đã lưu vào thư mục đã chọn."
                }
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi export"
            }
        }
    }

    fun selectChapter(chapter: Chapter) { _currentChapter.value = chapter }

    // mục 83/84 TECHNICAL_STATUS.md — dùng `cancelSafely()` (đợi coroutine
    // đang chạy dừng HẲN trước khi giải phóng native pointer, có timeout
    // 30s thật cho trường hợp native call bị treo — mục 84), KHÔNG dùng
    // `pipeline.cancel()` cũ cho nút Huỷ người dùng bấm khi app đang chạy
    // bình thường — `cancel()` cũ (`job?.cancel()` no-op vì `job` chưa
    // từng được gán) giải phóng native pointer NGAY LẬP TỨC trong khi
    // coroutine `runGeneration()` (nếu đang chạy dở, ví dụ giữa 1 lời gọi
    // JNI blocking `sdImg2Img()`) vẫn tiếp tục dùng con trỏ đó — use-after-
    // free thật, có thể crash SIGSEGV. `viewModelScope.launch{}` ở đây
    // KHÔNG block UI thread — Compose vẫn tương tác được, `_isGenerating`
    // chỉ tắt SAU KHI cleanup native thật sự an toàn xong (hoặc sau khi
    // xác nhận timeout — xem nhánh `TimedOut` bên dưới).
    fun cancelGeneration() {
        viewModelScope.launch {
            // _settings.value.cancelTimeoutMs — trước đây LUÔN 30s cứng
            // (default param của cancelSafely()), giờ đọc từ Settings thật
            // (mục "đã code nhưng thiếu UI", xem SettingsScreen.kt).
            val timeoutMs = _settings.value.cancelTimeoutMs
            when (pipeline.cancelSafely(timeoutMs)) {
                is MangaPipeline.CancelResult.Success -> {
                    _isGenerating.value = false
                }
                is MangaPipeline.CancelResult.TimedOut -> {
                    // mục 84 — KHÔNG tắt `_isGenerating` ở đây: native call
                    // có thể vẫn đang chạy thật (không rõ có dừng sau đó
                    // không), tắt cờ này sẽ khiến UI cho phép người dùng
                    // bấm "Sinh ảnh" lần nữa trong khi native context cũ
                    // (chưa được free vì lý do an toàn) vẫn còn sống — dễ
                    // dẫn tới 2 lời gọi native chồng lấn. Giữ nguyên
                    // `_isGenerating=true`, chỉ hiển thị cảnh báo rõ ràng.
                    _error.value = "⚠️ Sinh ảnh có thể đang bị treo (quá ${timeoutMs / 1000} giây không phản hồi sau khi bấm Huỷ). " +
                        "Nếu tình trạng này kéo dài, hãy đóng và mở lại ứng dụng — an toàn hơn là tiếp tục dùng."
                }
            }
        }
    }

    fun clearError() { _error.value = null }
    fun modelSetupGuide() = storyManager.setupGuide()
    fun modelStatus() = storyManager.modelStatus()
    fun hardwareSummary() = runtimeOptimizer.getHardwareSummary()

    // mục 83 — `onCleared()` KHÔNG đổi sang `cancelSafely()`: đây là
    // callback lifecycle non-suspend, gọi khi Android đang huỷ ViewModel
    // (thường kèm huỷ luôn `viewModelScope`) — không còn "đường an toàn"
    // nào để đợi coroutine dừng hẳn nữa. Giữ nguyên `cancel()` cũ (giải
    // phóng ngay, chấp nhận rủi ro use-after-free nhỏ hơn nguy cơ leak
    // vĩnh viễn khi Activity/ViewModel bị destroy) — đánh đổi có chủ đích,
    // xem docstring đầy đủ ở `MangaPipeline.cancel()`.
    override fun onCleared() {
        super.onCleared()
        pipeline.cancel()
        cachedTranslateParser?.free() // mục 114 — giải phóng cache parser khi VM huỷ, tránh rò bộ nhớ native
        // mục 161 (đợt 8) — unbind ServiceConnection khi ViewModel huỷ,
        // tránh rò (leaked ServiceConnection warning + giữ tiến trình
        // :inference sống không cần thiết sau khi UI không còn dùng nữa).
        // try/catch vì unbindService() ném IllegalArgumentException nếu
        // CHƯA từng bindService() thành công (serviceMessenger vẫn null —
        // trường hợp user chưa từng sinh ảnh lần nào trong phiên này).
        if (serviceMessenger != null) {
            try { appCtx.unbindService(serviceConnection) } catch (_: IllegalArgumentException) {}
        }
    }
}
