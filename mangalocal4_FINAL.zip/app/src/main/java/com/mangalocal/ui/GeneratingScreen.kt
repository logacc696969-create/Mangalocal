package com.mangalocal.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeneratingScreen(nav: NavController, vm: MainViewModel) {
    val state by vm.pipelineState.collectAsState()
    val thermal by vm.thermalState.collectAsState()

    LaunchedEffect(state.stage) {
        if (state.stage == PipelineStage.REVIEW) nav.navigate("gallery_review") { popUpTo("stories") }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Đang sinh panel") },
                navigationIcon = { IconButton(onClick = { vm.cancelGeneration(); nav.popBackStack() }) { Icon(Icons.Default.Close, null) } },
                actions = {
                    ThermalBadge(thermal.currentTempC, thermal.thresholdC)
                    Spacer(Modifier.width(12.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumnContent(pad, state, thermal)
    }
}

@Composable
private fun LazyColumnContent(pad: PaddingValues, state: PipelineState, thermal: ThermalState) {
    androidx.compose.foundation.lazy.LazyColumn(
        modifier = Modifier.padding(pad).fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Thermal warning banner
        if (state.isPaused && state.pauseReason == PauseReason.THERMAL) item {
            Surface(color = C.RedDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Red.copy(0.5f))) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("🔥", fontSize = 24.sp)
                    Column {
                        Text("Máy đang nóng quá! (${thermal.currentTempC}°C)", color = C.Red, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Tạm dừng để bảo vệ máy. Sẽ tự tiếp tục khi nguội xuống ${thermal.thresholdC - 3}°C",
                            color = C.T2, fontSize = 12.sp, lineHeight = 16.sp)
                    }
                }
            }
        }

        item {
            MlCard {
                MlLabel("pipeline")
                PipelineIndicator(state.stage)
            }
        }

        item {
            MlCard {
                // mục 133 TECHNICAL_STATUS.md — Industrial Batch Upscale Mode:
                // khi đang chạy 2 giai đoạn tách biệt (ESRGAN rồi tới hires-
                // fix/auto-fix), hiện rõ đang ở giai đoạn nào để user không
                // hiểu nhầm "Panel 1/8" bị lặp lại là bị treo/lỗi.
                state.phaseLabel?.let { label ->
                    Text(label, color = C.Orange, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Panel ${state.currentPanel} / ${state.totalPanels}", color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    val e = state.elapsedMs / 1000
                    Text("${e / 60}m ${e % 60}s", color = C.T3, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = state.progressFraction,
                    modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
                    color = C.Blue, trackColor = C.Border)
                Spacer(Modifier.height(4.dp))
                Text("Step ${state.currentStep}/${state.totalSteps}", color = C.T3, fontSize = 11.sp)
            }
        }

        // Nhiệt độ chart đơn giản
        item {
            MlCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MlLabel("nhiệt độ máy")
                    ThermalBadge(thermal.currentTempC, thermal.thresholdC)
                }
                Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.Bottom) {
                    thermal.history.takeLast(30).forEach { temp ->
                        val ratio = (temp.toFloat() / 60f).coerceIn(0.1f, 1f)
                        val color = when {
                            temp >= thermal.thresholdC -> C.Red
                            temp >= thermal.thresholdC - 5 -> C.Orange
                            else -> C.Green
                        }
                        Box(Modifier.weight(1f).fillMaxHeight(ratio).padding(horizontal = 0.5.dp).background(color))
                    }
                }
                Text("Ngưỡng dừng: ${thermal.thresholdC}°C", color = C.T3, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }

        item {
            MlCard {
                MlLabel("log")
                Column(modifier = Modifier.fillMaxWidth().background(C.S0, RoundedCornerShape(8.dp))
                    .padding(10.dp).heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
                    state.log.takeLast(25).forEach { entry ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 1.dp)) {
                            Text(entry.time, color = C.T3, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text(entry.message, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                                color = when (entry.level) {
                                    LogLevel.OK -> C.Green; LogLevel.WARN -> C.Orange
                                    LogLevel.ERROR -> C.Red; else -> C.T2
                                })
                        }
                    }
                }
            }
        }
    }
}
