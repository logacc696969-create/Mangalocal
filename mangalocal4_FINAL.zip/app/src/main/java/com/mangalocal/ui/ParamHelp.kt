package com.mangalocal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// mục 257 TECHNICAL_STATUS.md — HỆ THỐNG TRỢ GIÚP THÔNG SỐ: mỗi công tắc/thanh trượt trong Cài đặt có dấu "?"; chạm vào hiện popup giải thích
// thông số LÀM GÌ, KHI CHỈNH THÌ ẢNH HƯỞNG RA SAO, NÊN CHỈNH THẾ NÀO và giá trị mặc định. Nội dung nằm ở đây (một chỗ) thay vì rải khắp
// SettingsScreen. Khoá = tên field của GenerationSettings (hoặc khoá ghép như "remoteEndpoint.enabled" cho field lồng nhau).
// `tools/test_param_help.py` kiểm: mọi dấu "?" trong Cài đặt đều có mục ở đây; mọi mục đều đủ 4 phần; "Mặc định" khớp Models.kt.
// Lưu ý khi sửa chữ: KHÔNG dùng dấu nháy kép, ký tự đô-la hay gạch chéo ngược trong nội dung (sẽ bị hiểu là chuỗi mẫu của Kotlin).
data class ParamHelpEntry(
    val title: String,
    val what: String,    // thông số làm gì
    val effect: String,  // chỉnh lên/xuống thì thấy gì
    val howTo: String,   // nên chỉnh thế nào cho phù hợp
    val default: String, // giá trị mặc định (test đối chiếu với Models.kt)
    val note: String = "" // giới hạn/điều kiện cần (tuỳ chọn)
)

object ParamHelp {
    private fun e(title: String, what: String, effect: String, howTo: String, default: String, note: String = "") =
        ParamHelpEntry(title, what, effect, howTo, default, note)

    val entries: Map<String, ParamHelpEntry> = mapOf(
        "nThreadsAutoDetect" to e(
            "Số luồng CPU: tự động",
            "Quyết định app tự chọn số luồng CPU cho mô hình ngôn ngữ (LLM) theo phần cứng, hay dùng đúng số bạn đặt.",
            "Bật: app tự dò theo máy. Tắt: dùng số ở thanh Threads bên dưới.",
            "Nên để BẬT. Chỉ tắt khi bạn muốn ép ít luồng hơn cho máy đỡ nóng, hoặc nhiều hơn khi chắc chắn máy còn dư lõi.",
            "Bật"
        ),
        "nThreads" to e(
            "Số luồng CPU: tự đặt",
            "Số luồng CPU được dùng khi tắt chế độ tự động.",
            "Nhiều luồng hơn thường nhanh hơn nhưng nóng và tốn pin hơn; vượt số lõi mạnh của máy có thể chậm đi vì tranh chấp.",
            "Bắt đầu bằng số lõi hiệu năng cao của máy (thường 4). Giảm xuống 2 đến 3 nếu máy nóng hoặc giật.",
            "4"
        ),
        "steps" to e(
            "Số bước (Steps)",
            "Số lần mô hình khử nhiễu để tạo một ảnh.",
            "Tăng: chi tiết ổn định hơn nhưng sinh lâu hơn gần như tỉ lệ thuận. Giảm: nhanh hơn, ảnh có thể thô.",
            "Mặc định 20 là cân bằng cho SD1.5. Tăng lên 25 đến 30 nếu mặt/tay còn lỗi; giảm xuống 12 đến 15 khi chỉ xem thử bố cục.",
            "20"
        ),
        "cfgScale" to e(
            "CFG Scale",
            "Mức độ mô hình bám sát prompt (mô tả).",
            "Cao: bám prompt chặt hơn nhưng dễ cháy màu, mất tự nhiên. Thấp: tự do hơn, có thể lệch mô tả.",
            "Khoảng 6 đến 8 cho đa số trường hợp. Chỉ tăng khi ảnh hay bỏ sót chi tiết có trong prompt.",
            "7.0"
        ),
        "defaultModelTier" to e(
            "Dùng SDXL thay vì SD1.5",
            "Chọn dòng model ảnh mặc định cho các panel không đặt riêng: SD1.5 hoặc SDXL.",
            "Bật: dùng SDXL, hiểu mô tả tốt hơn nhưng nặng RAM, chậm và dễ văng app trên máy yếu. Tắt: dùng SD1.5.",
            "Giữ TẮT trừ khi máy nhiều RAM và bạn sẵn sàng thử nghiệm.",
            "Tắt (dùng SD1.5)",
            "Cần có model SDXL đã nạp."
        ),
        "useOpenCL" to e(
            "Tăng tốc GPU (OpenCL)",
            "Cho MNN chạy suy luận trên GPU (Adreno/Mali) thay vì CPU.",
            "Bật: nhanh hơn rõ rệt trên đa số máy. Tắt: ép chạy CPU, chậm hơn nhưng loại trừ được lỗi do driver GPU.",
            "Giữ BẬT. Chỉ tắt để chẩn đoán khi ảnh ra hỏng hoặc app văng ở bước sinh ảnh.",
            "Bật"
        ),
        "useNpu" to e(
            "Tăng tốc NPU (QNN)",
            "Chạy mô hình trên NPU của chip Snapdragon.",
            "Chỉ có tác dụng với bản APK build riêng có QNN SDK và máy Snapdragon hỗ trợ. Bật trên bản thường vẫn an toàn (tự rơi về OpenCL/CPU) nhưng không nhanh hơn.",
            "Để TẮT nếu bạn dùng bản APK thường. Khi model đang chọn bắt buộc NPU, công tắc bị khoá ở trạng thái bật.",
            "Tắt"
        ),
        "externalLlm.enabled" to e(
            "Dùng LLM ngoài",
            "Dùng một dịch vụ LLM bên ngoài (qua mạng) thay vì model chạy trên máy để phân tích truyện và viết kịch bản.",
            "Bật: kịch bản thường tốt hơn model nhỏ trên máy, nhưng nội dung truyện được gửi ra ngoài. Tắt: luôn dùng model trên máy.",
            "Chỉ bật khi bạn chấp nhận gửi nội dung truyện tới dịch vụ đó.",
            "Tắt"
        ),
        "useUltrafixRedraw" to e(
            "Ultrafix: vẽ lại nhẹ toàn ảnh",
            "Sau khi phóng to bằng ESRGAN, vẽ lại nhẹ toàn ảnh theo từng ô để thêm chi tiết (kiểu Ultimate SD Upscale).",
            "Bật: ảnh sắc nét, nhiều chi tiết hơn nhưng mỗi panel tốn thêm thời gian đáng kể. Tắt: bỏ bước này.",
            "Bật khi cần ảnh độ phân giải cao và chấp nhận chậm. Mức thay đổi chỉnh ở thanh Denoising Strength bên dưới.",
            "Tắt",
            "Mặc định tắt; chưa đo chất lượng trên ảnh thật."
        ),
        "ultrafixDenoiseStrength" to e(
            "Ultrafix: Denoising Strength",
            "Mức vẽ lại của Ultrafix: 0 là giữ nguyên ảnh, càng cao càng thay đổi nhiều.",
            "Thấp: giữ bố cục, chỉ thêm chi tiết nhỏ. Cao: đổi nhiều chi tiết, dễ lệch khỏi ảnh gốc.",
            "Cộng đồng thường dùng 0.35 đến 0.45. Nếu khuôn mặt hay bố cục bị đổi thì giảm; nếu ảnh vẫn mờ thì tăng nhẹ.",
            "0.4",
            "Khuyến nghị cộng đồng, chưa đo trên ảnh của dự án."
        ),
        "industrialBatchUpscaleMode" to e(
            "Xử lý 4 giai đoạn (tiết kiệm RAM)",
            "Chạy cả chương theo 4 giai đoạn riêng thay vì làm lần lượt từng panel, để mỗi giai đoạn chỉ giữ một model trong RAM.",
            "Bật: không đổi ảnh ra, chỉ đổi thứ tự xử lý; hơi chậm hơn đôi chút nếu RAM dư dả nhưng giảm nguy cơ hết RAM.",
            "Bật nếu máy hay hết RAM giữa chừng khi làm cả chương.",
            "Tắt",
            "Chưa kiểm thử kỹ trên máy thật."
        ),
        "autoFixFacesHands" to e(
            "Tự sửa mặt và tay",
            "Tự dò vùng mặt và bàn tay trong ảnh rồi vẽ lại riêng các vùng đó.",
            "Bật: mặt/tay thường đẹp hơn nhưng tốn thêm thời gian mỗi panel. Tắt: giữ nguyên ảnh vừa sinh.",
            "Bật khi mặt/tay hay méo. Mức vẽ lại chỉnh ở thanh Denoising Strength bên dưới.",
            "Tắt"
        ),
        "autoFixDenoiseStrength" to e(
            "Sửa mặt/tay: Denoising Strength",
            "Mức vẽ lại vùng mặt và tay.",
            "Thấp: giữ nét gốc, sửa ít. Cao: sửa mạnh nhưng dễ đổi nét mặt thành người khác.",
            "Mặc định 0.45. Giảm xuống nếu mặt bị đổi người; tăng nhẹ nếu lỗi vẫn còn.",
            "0.45"
        ),
        "enableHistogramGuard" to e(
            "Histogram Guard (bù sáng)",
            "Đo độ sáng ảnh thô và chèn từ khoá bù nhẹ nếu ảnh quá tối hoặc quá sáng.",
            "Bật: tự chữa ảnh lỡ tối/sáng. Tắt: giữ nguyên.",
            "Tắt khi bạn cố ý dựng cảnh đêm.",
            "Tắt",
            "Không phân biệt được tối cố ý với tối do lỗi."
        ),
        "inpaintColorMatch" to e(
            "Khớp màu vùng vẽ lại",
            "Chỉnh màu vùng vừa vẽ lại cho khớp ảnh gốc, chống trôi màu da/tóc do vẽ lại.",
            "Bật: vùng sửa không lộ khác màu. Tắt: giữ nguyên màu model sinh ra.",
            "Giữ BẬT.",
            "Bật"
        ),
        "differentialInpaint" to e(
            "Differential Diffusion cho vẽ lại có mask",
            "Biến mask mềm thành mức độ thay đổi theo từng bước khử nhiễu thay vì trộn cố định, nên biên vùng vẽ lại chuyển tiếp mượt hơn.",
            "Bật: biên vùng sửa ít lộ vệt/viền. Tắt: dùng cách trộn cũ.",
            "Thử bật khi thấy viền vùng sửa (mặt, tay, điểm chạm) còn lộ. Nếu kết quả lạ hơn thì tắt.",
            "Tắt",
            "Mới, chưa chạy thật trên máy; mặc định tắt."
        ),
        "inpaintMatchedNoise" to e(
            "Khớp mức nhiễu khi vẽ lại vùng có mask",
            "Khi vẽ lại mặt, tay hoặc vùng chạm, phần giữ nguyên được trộn lại với ảnh gốc sau mỗi bước. Mặc định ảnh gốc được thêm nhiễu ở mức của bước trước, cao hơn phần đang vẽ một bậc. Bật tuỳ chọn này: dùng đúng mức nhiễu của bước hiện tại, và bước cuối dùng ảnh gốc sạch. Theo cách các pipeline inpaint hiện hành của thư viện diffusers làm.",
            "Bật: viền giữa vùng vẽ lại và phần giữ nguyên có thể ít hạt hoặc ít lệch tông hơn. Tắt: như cũ.",
            "Ảnh hưởng mọi lượt vẽ lại có mask, nên chỉ thử khi so được ảnh bật và tắt cùng seed. Nếu thấy viền vùng vẽ lại có hạt hoặc lệch tông thì thử bật.",
            "Tắt",
            "Mới, chưa chạy thật trên máy; mặc định tắt."
        ),
        "visionCountDetectorFirst" to e(
            "Ưu tiên bộ dò người khi đếm",
            "Khi giám khảo VLM đếm số người trong ảnh khác kịch bản, nhưng bộ dò người (YOLOv8-pose) đếm đúng kịch bản, thì bỏ cảnh báo đếm sai của VLM, vì VLM nhỏ đếm kém hơn nhiều so với bộ dò. Cảnh báo về tiếp xúc thân thể vẫn giữ.",
            "Bật: ít sinh lại ảnh oan vì VLM đếm nhầm. Tắt: mọi câu đếm lệch của VLM đều thành cảnh báo như trước.",
            "Chỉ có nghĩa khi đã đặt thư mục model cho giám khảo VLM. Cảnh vật lộn, quần nhau là chỗ bộ dò cũng đếm thiếu vì người che nhau, nên bật không cứu được các ca đó.",
            "Bật",
            "Mới, chưa chạy thật trên máy."
        ),
        "occCfgEnabled" to e(
            "CFG riêng cho vùng chồng/chạm nhau",
            "Panel có từ 2 người trở lên mà thân người chồng lên nhau hoặc chạm sát nhau (ôm, vật nhau): tăng độ bám prompt RIÊNG ở vùng đó, các vùng còn lại giữ nguyên. Dựa trên bài PersonaCraft; vùng chồng/chạm được tính từ khung xương 2D.",
            "Bật: chỗ hai người chạm nhau có xu hướng ít bị dính thành một khối và đúng giải phẫu hơn, nhưng quá tay có thể làm vùng đó bị cháy màu hoặc quá nét. Tắt: CFG đồng đều như cũ.",
            "Chỉ thử khi cảnh ôm hoặc vật nhau hay bị dính người. So ảnh bật và tắt cùng seed. Chỉ áp cho lượt sinh ảnh đầu của panel, không áp cho các lượt vá cục bộ.",
            "Tắt",
            "Mới, chưa chạy thật trên máy; mặc định tắt."
        ),
        "occCfgBoost" to e(
            "Hệ số tăng CFG ở vùng chạm",
            "CFG ở vùng chồng/chạm bằng CFG nền nhân hệ số này. Phạm vi 1.0 đến 2.0. Bài gốc dùng khoảng 1.7 lần trên SDXL với CFG nền thấp (3 lên 5).",
            "Thấp: ít khác biệt. Cao: vùng chạm bám prompt mạnh hơn nhưng dễ cháy màu, đặc biệt khi CFG nền đã cao.",
            "Giữ 1.4. CFG nền của SD1.5 thường đã cao (7), nên không nên đẩy quá 1.6. Nếu vùng chạm bị cháy màu thì giảm.",
            "1.4",
            "Con số ước lượng, chưa đo."
        ),
        "contactGradedMask" to e(
            "Mask vẽ lại theo cường độ tiếp xúc",
            "Khi vẽ lại vùng chạm bằng Differential Diffusion, thay mask phẳng bằng mask LIÊN TỤC: lõi chỗ hai người chạm nhau được vẽ lại đầy đủ, vùng rìa chỉ chỉnh chi tiết để giữ cấu trúc cũ.",
            "Bật: ít phá phần thân ngoài chỗ chạm mà vẫn sửa được chỗ dính. Tắt: mask lông vũ đồng đều như cũ.",
            "Cần bật cả Differential Diffusion thì mới có tác dụng. So ảnh bật và tắt cùng seed.",
            "Tắt",
            "Mới, chưa chạy thật trên máy; mặc định tắt."
        ),
        "contactMaskFloor" to e(
            "Mức tối thiểu của mask ở vùng rìa",
            "Với mask theo cường độ tiếp xúc: mức thay đổi ở vùng rìa (xa lõi chạm). Phạm vi 0.2 đến 0.9. 1.0 nghĩa là không phân biệt lõi và rìa.",
            "Thấp: vùng rìa gần như giữ nguyên, chỉ lõi chạm đổi nhiều. Cao: rìa cũng bị vẽ lại nhiều như lõi.",
            "Giữ 0.45. Nếu chỗ dính lan ra ngoài lõi mà không được sửa thì tăng lên 0.6.",
            "0.45",
            "Con số ước lượng, chưa đo."
        ),
        "loraCompose" to e(
            "Trộn LoRA nhân vật lúc sinh ảnh",
            "Panel có từ 2 nhân vật mà mỗi người có model LoRA riêng: thay vì gộp mọi LoRA vào một UNet, nạp mỗi LoRA một UNet và luân phiên hoặc lấy trung bình mỗi bước khử nhiễu (bài Multi-LoRA Composition). Giúp các LoRA ít lấn át nhau.",
            "Bật: mỗi nhân vật giữ nét riêng tốt hơn khi đứng chung khung, đổi lại tốn RAM gấp số nhân vật. Tắt: dùng model đã gộp sẵn như cũ.",
            "Chỉ áp cho đường sinh ảnh thường (không IP-Adapter hay ControlNet) và cần mỗi nhân vật đã có model LoRA chuyển đổi sẵn. Chỉ nên thử khi máy còn dư RAM. Không dùng được LoRA của text-encoder phụ.",
            "Tắt",
            "Mới, chưa chạy thật trên máy; mặc định tắt."
        ),
        "loraComposeOwnClip" to e(
            "Mã hoá prompt bằng CLIP của từng LoRA",
            "Khi trộn LoRA: mỗi UNet nhận điều kiện văn bản được mã hoá bằng CLIP của chính LoRA đó, thay vì dùng chung CLIP của nhân vật đầu. LoRA nhân vật thường được huấn luyện cả phần văn bản nên cách này đúng với cách dùng LoRA hơn.",
            "Bật: nhân vật thứ hai trở đi giữ được phần văn bản của LoRA mình, thêm vài giây mã hoá. Tắt: mọi UNet dùng chung CLIP chính như trước.",
            "Chỉ có nghĩa khi bật trộn LoRA. Nhân vật nào thiếu clip.mnn tự dùng CLIP chính. So ảnh bật và tắt cùng seed nếu thấy nhân vật thứ hai kém giống.",
            "Bật",
            "Mới, chưa chạy thật trên máy."
        ),
        "loraComposeRegional" to e(
            "Trộn LoRA theo vùng từng nhân vật",
            "Khi trộn LoRA: thay vì lấy trung bình toàn ảnh, mỗi vùng của ảnh nghiêng về LoRA của nhân vật đứng ở vùng đó (mask dựng từ khung xương), nền và vùng không thuộc ai thì lấy trung bình. Dựa trên cách Latent Couple và LoRA theo vùng mà cộng đồng dùng.",
            "Bật: mỗi nhân vật ít bị lẫn nét của LoRA kia, đổi lại mỗi bước chạy đủ mọi UNet nên chậm như Composite. Tắt: Switch hoặc Composite thường.",
            "Cần khung xương đủ khớp thân cho mọi nhân vật trong cảnh; thiếu thì tự quay về Switch hoặc Composite. Biên giữa hai người vẫn là chỗ dễ lẫn nét nhất.",
            "Tắt",
            "Mới, chưa chạy thật trên máy; mặc định tắt."
        ),
        "loraComposeComposite" to e(
            "Lấy trung bình mọi LoRA mỗi bước",
            "Khi trộn LoRA: thay vì mỗi bước chỉ bật một LoRA (Switch), chạy tất cả UNet mỗi bước rồi lấy trung bình (Composite). Chính xác hơn về lý thuyết nhưng chậm gấp số nhân vật.",
            "Bật: chậm gấp 2 hoặc 3 lần. Tắt: Switch, tốc độ gần như không đổi.",
            "Bài gốc cho thấy Switch tốt hơn khi có nhiều LoRA (từ 4 trở lên). Với 2 nhân vật có thể thử Composite nếu chịu được thời gian.",
            "Tắt",
            "Mới, chưa chạy thật trên máy; mặc định tắt."
        ),
        "loraSwitchTau" to e(
            "Bước đổi LoRA (Switch)",
            "Số bước khử nhiễu giữa hai lần đổi LoRA. Phạm vi 1 đến 10. Bài gốc: 5 là tốt nhất; đổi mỗi bước (1) làm ảnh méo.",
            "Thấp: đổi LoRA dày, dễ méo. Cao: mỗi LoRA giữ lâu hơn, nhưng với ít bước sinh ảnh thì có thể một LoRA chỉ được dùng một lần.",
            "Giữ 5 với 20 bước trở lên. Nếu đang dùng ít bước (8 đến 12) thì giảm còn 3.",
            "5",
            "Giá trị 5 lấy từ bài gốc chạy 100 đến 200 bước; với số bước ít của app chưa đo."
        ),
        "objectDepthBlockout" to e(
            "Khối độ sâu cho vật thể",
            "Với panel có nhân vật và có hộp vật thể (bàn, ghế, tủ...), vẽ mỗi hộp thành một mảng phẳng nằm SAU người lên bản đồ độ sâu mà ControlNet-Depth đã nhận, để ép vị trí và kích thước vật thể ngay lúc sinh ảnh.",
            "Bật: vật thể có xu hướng nằm đúng chỗ và đúng cỡ hơn, nhưng dễ ra hình vuông như hộp và luôn bị đặt phía sau người. Tắt: bản đồ độ sâu chỉ có người như cũ.",
            "Chỉ thử khi vật thể trong panel hay sai chỗ hoặc sai cỡ và đã có hộp vật thể. So ảnh bật và tắt cùng seed; nếu vật thể bị méo vuông thì tắt.",
            "Tắt",
            "Thử nghiệm, chưa có ảnh thật chứng minh. Chỉ có tác dụng ở nhánh Triple-Combo SD1.5; không ảnh hưởng panel không có nhân vật (đã có GLIGEN) hay SDXL."
        ),
        "enableQualityGate" to e(
            "Quality Gate (kiểm khung xương)",
            "Đánh giá khung xương tư thế MỘT lần trước khi sinh ảnh; nếu không đạt vẫn sinh một lần nhưng gắn cảnh báo vào panel.",
            "Bật: biết sớm panel có tư thế dễ lỗi, và các chức năng tự sửa vùng giao thoa dùng chung dữ liệu khung xương này. Tắt: không kiểm.",
            "Nên bật nếu dùng tự sửa vùng chạm hoặc kiểm tra sau sinh.",
            "Tắt"
        ),
        "useSeedRegistry" to e(
            "Ưu tiên seed đã đạt gate",
            "Dùng kho seed hoàn hảo (seed từng qua Quality Gate) để đề xuất seed cho panel có cấu trúc tương tự thay vì ngẫu nhiên hoàn toàn.",
            "Bật: tăng cơ hội panel đạt ngay. Tắt: seed ngẫu nhiên.",
            "Giữ bật. Xoá kho seed khi đổi model nền.",
            "Bật",
            "Chỉ có tác dụng khi bật Quality Gate."
        ),
        "seedInheritanceEnabled" to e(
            "Kế thừa seed cùng bối cảnh",
            "Các panel cùng bối cảnh dùng lại seed của panel gần nhất có cùng bối cảnh, để nền đứng yên qua nhiều panel.",
            "Bật: nền ổn định hơn. Tắt: mỗi panel seed ngẫu nhiên độc lập (chuẩn của Stable Diffusion).",
            "Bật cho cảnh nhiều panel cùng một nền, ví dụ một trận đánh kéo dài.",
            "Tắt"
        ),
        "slidingWindowSize" to e(
            "Cửa sổ kế thừa seed (số panel gần nhất)",
            "Khi kế thừa seed, app nhìn ngược lại tối đa bấy nhiêu panel gần nhất để tìm panel cùng bối cảnh.",
            "Nhiều: tìm được seed cũ ngay cả khi có panel khác bối cảnh chen giữa. Ít: chỉ so với vài panel sát trước.",
            "Mặc định 3. Tăng nếu truyện hay xen kẽ nhiều bối cảnh.",
            "3",
            "Chỉ có tác dụng khi bật Kế thừa seed cùng bối cảnh."
        ),
        "verifyOutputPose" to e(
            "Kiểm tra ảnh SAU khi sinh",
            "Sau khi sinh, dò lại tư thế bằng YOLOv8-pose rồi so với khung xương đầu vào: đếm người, độ lệch tư thế, tỉ lệ giữa các người. Chỉ cảnh báo, không tự sinh lại.",
            "Bật: panel có vấn đề được gắn cảnh báo ở badge Quality Gate. Độ nghiêm chỉnh bằng các thanh trượt bên dưới.",
            "Bật khi làm cảnh nhiều người hoặc vật lộn để biết panel nào cần xem lại.",
            "Tắt",
            "Cần model YOLOv8-pose."
        ),
        "verifyMaxPoseError" to e(
            "Độ lệch tư thế tối đa",
            "Sai số trung vị giữa khớp ở ảnh ra và khung xương, tính theo chiều dài thân người. Vượt ngưỡng thì cảnh báo lệch tư thế.",
            "Thấp: nghiêm, dễ báo lệch. Cao: dễ tính, ít báo.",
            "Nếu hay báo lệch dù ảnh nhìn ổn thì tăng lên 0.45 đến 0.6. Nếu bỏ sót panel hỏng rõ ràng thì giảm xuống 0.25 đến 0.3.",
            "0.35",
            "Con số ước lượng, chưa đo trên ảnh truyện thật. Hãy chỉnh theo ảnh của bạn."
        ),
        "verifyMaxScaleSpread" to e(
            "Chênh tỉ lệ giữa các người tối đa",
            "Mức chênh kích thước giữa các người trong cùng ảnh so với khung xương (người to nhất chia người nhỏ nhất, trừ 1). Vượt ngưỡng thì cảnh báo.",
            "Thấp: nghiêm. Cao: dễ tính.",
            "Cảnh có người gần/xa camera tự nhiên chênh nhiều thì tăng lên. Muốn các nhân vật cỡ ngang nhau thì giảm.",
            "0.3",
            "Con số ước lượng, chưa đo."
        ),
        "verifySingleScaleMin" to e(
            "Tỉ lệ kích thước tối thiểu (khi chỉ ghép được 1 người)",
            "Khi chỉ ghép được một người, chiều cao người trong ảnh ra so với khung xương phải không nhỏ hơn mức này.",
            "Cao: báo nhiều khi người nhỏ hơn khung xương. Thấp: ít báo.",
            "Hạ xuống nếu ảnh có người đứng xa nhưng vẫn bị báo oan.",
            "0.6",
            "Con số ước lượng, chưa đo."
        ),
        "verifySingleScaleMax" to e(
            "Tỉ lệ kích thước tối đa (khi chỉ ghép được 1 người)",
            "Khi chỉ ghép được một người, chiều cao người trong ảnh ra so với khung xương phải không lớn hơn mức này.",
            "Thấp: báo nhiều khi người to hơn khung xương. Cao: ít báo.",
            "Tăng lên nếu ảnh có người đứng sát camera nhưng vẫn bị báo oan.",
            "1.6",
            "Con số ước lượng, chưa đo."
        ),
        "verifyExtraPersonsAllowed" to e(
            "Số người thừa được bỏ qua",
            "Dò được nhiều hơn khung xương bao nhiêu người thì mới coi là thừa người; cho phép người nền xuất hiện ngoài ý muốn.",
            "0: báo ngay khi thừa dù chỉ 1 người. Cao: ít báo.",
            "Giữ 1 cho cảnh có nền đông. Đặt 0 nếu muốn đúng từng người.",
            "1"
        ),
        "autoFixInteractions" to e(
            "Tự sửa vùng giao thoa hông/tay",
            "Khi panel có từ 2 nhân vật, tự vẽ lại vùng người này chạm người kia (hông, tay).",
            "Bật: vùng giao thoa bớt dính liền/méo, tốn thêm thời gian. Tắt: không sửa.",
            "Bật cho cảnh ôm, vật nhau, đánh nhau. Mức vẽ lại chỉnh ở Denoise giao thoa.",
            "Tắt",
            "Dùng chung dữ liệu khung xương của Quality Gate."
        ),
        "autoFixInteractionStrength" to e(
            "Denoise giao thoa",
            "Mức vẽ lại vùng giao thoa giữa các nhân vật.",
            "Thấp: sửa nhẹ, giữ bố cục. Cao: dựng lại mạnh nhưng dễ lệch tư thế.",
            "Khuyến nghị 0.55 (cao hơn sửa mặt/tay vì vùng này cần dựng lại nhiều hơn).",
            "0.55"
        ),
        "autoFixLimbContacts" to e(
            "Mở rộng sang mọi điểm chạm thân thể",
            "Ngoài hông và tay, tìm cả khuỷu tay, đầu gối, bàn chân, đầu, tay chạm cổ/đầu người kia và vẽ lại các vùng đó.",
            "Bật: nhiều vùng chạm được sửa hơn. Tắt: chỉ hông/tay.",
            "Bật cho cảnh vật lộn/ôm. Giới hạn số vùng bằng thanh bên dưới; chỉnh độ nhạy bằng thanh Độ nhạy điểm chạm.",
            "Bật",
            "Chỉ có tác dụng khi bật Tự sửa vùng giao thoa."
        ),
        "contactSensitivity" to e(
            "Độ nhạy điểm chạm",
            "Hệ số nhân lên các khoảng cách đủ gần để tính là chạm (tay với cổ/đầu, đầu với đầu, chân với hông). Phạm vi 0.5 đến 1.5.",
            "Thấp: chỉ những chạm rất sát được tính, ít vùng sửa. Cao: tính cả chạm hơi xa, nhiều vùng sửa hơn (tốn thời gian, có thể sửa thừa).",
            "Giữ 1.0. Nếu bỏ sót điểm chạm rõ ràng thì tăng 1.2 đến 1.4. Nếu sửa cả chỗ không chạm thì giảm 0.7 đến 0.8.",
            "1.0",
            "Con số ước lượng, chưa đo."
        ),
        "maxContactFixRegions" to e(
            "Số vùng chạm tối đa mỗi panel",
            "Giới hạn số vùng điểm chạm được vẽ lại trong một panel (1 đến 8).",
            "Nhiều: sửa được nhiều chỗ nhưng mỗi vùng là một lượt vẽ lại nên chậm tỉ lệ thuận. Ít: nhanh, chỉ sửa chỗ ưu tiên (mặt/cổ trước).",
            "Mặc định 4. Giảm xuống 2 nếu máy chậm; tăng 6 đến 8 cho cảnh đông người.",
            "4"
        ),
        "useDepthForContacts" to e(
            "Lọc điểm chạm theo độ sâu (MiDaS)",
            "Dùng bản đồ độ sâu của ảnh vừa sinh để bỏ các điểm chạm giả: bộ phận nằm sát nhau trên ảnh nhưng thật ra người này đứng trước hoặc sau người kia.",
            "Bật: ít sửa oan. Tắt: chỉ dùng hình học 2D như trước.",
            "Giữ bật nếu có file midas_small_depth.mnn; thiếu file thì tự bỏ qua.",
            "Bật",
            "Cần midas_small_depth.mnn trong thư mục yolo."
        ),
        "autoFixCropInpaint" to e(
            "Vẽ vùng nhỏ ở độ phân giải đầy đủ",
            "Cắt riêng vùng cần sửa kèm lề, phóng lên kích thước model, vẽ lại rồi thu nhỏ và dán lại (kiểu only masked).",
            "Bật: vùng nhỏ như bàn tay, khuôn mặt sắc nét hơn. Tắt: vẽ ở độ phân giải của cả ảnh.",
            "Giữ BẬT.",
            "Bật"
        ),
        "autoFixRegionOnlyPrompt" to e(
            "Prompt chỉ mô tả vùng đang vẽ",
            "Khi vẽ vùng cắt, dùng prompt về đúng vùng đó (loại chạm và hai nhân vật liên quan) thay vì mô tả cả cảnh.",
            "Bật: model tập trung vào chi tiết vùng, ít bị phân tán. Tắt: dùng prompt cả cảnh.",
            "Giữ bật cùng chế độ vẽ vùng nhỏ.",
            "Bật"
        ),
        "autoFixPasteBack" to e(
            "Dán lại pixel gốc ngoài vùng sửa",
            "Sau khi vẽ lại, giữ nguyên pixel gốc ở ngoài mask, chỉ thay phần trong mask.",
            "Bật: tránh sai lệch nhỏ cộng dồn ra ngoài vùng sửa. Tắt: giữ nguyên kết quả model.",
            "Giữ BẬT.",
            "Bật"
        ),
        "autoTearClothingAtContactPoints" to e(
            "Mô tả quần áo xộc xệch tại điểm chạm",
            "Thêm mô tả trang phục xộc xệch/rách tại điểm chạm vào prompt vẽ lại vùng đó, dùng đúng mô tả của nhân vật bị chạm.",
            "Bật: cảnh giằng co chân thực hơn. Tắt: không thêm.",
            "Bật khi muốn hiệu ứng vật lộn mạnh; tắt nếu không cần hiệu ứng quần áo.",
            "Tắt"
        ),
        "sdxlFinishPass" to e(
            "Hậu kỳ bằng SDXL cho vùng chạm",
            "Panel vẫn sinh bằng SD1.5, nhưng các vùng chạm được vẽ lần cuối bằng SDXL vì SDXL hiểu mô tả điểm chạm tốt hơn.",
            "Bật: vùng chạm thường chính xác hơn nhưng nặng RAM và chậm. Tắt: dùng SD1.5 suốt.",
            "Chỉ bật khi đã có SDXL và máy nhiều RAM. Chỉ chạy cho panel vuông có từ 2 nhân vật và khi bật tự sửa vùng giao thoa.",
            "Tắt",
            "Chưa đo chất lượng trên ảnh thật."
        ),
        "sdxlFinishDenoise" to e(
            "Hậu kỳ SDXL: Denoise",
            "Mức vẽ lại của lượt SDXL cuối.",
            "Thấp: giữ sát ảnh SD1.5, SDXL chỉ tinh chỉnh. Cao: SDXL dựng lại nhiều, có thể lệch tư thế.",
            "Mặc định 0.35. Tăng nhẹ nếu vùng chạm vẫn sai; giảm nếu tư thế bị đổi.",
            "0.35"
        ),
        "enableMultiPassCascade" to e(
            "Sinh riêng từng nhân vật (Cascade)",
            "Với panel từ 2 nhân vật, sinh từng người trong lượt riêng để mỗi lượt chỉ có một danh tính rồi ghép lại, tránh lẫn mặt/trang phục giữa các người.",
            "Bật: các nhân vật khác nhau rõ hơn nhưng tốn nhiều lượt sinh. Tắt: sinh cả cảnh một lượt, dễ lẫn nhân vật.",
            "Giữ bật (khuyến nghị).",
            "Bật"
        ),
        "cascadeDenoiseStrength" to e(
            "Cascade: Denoise mỗi lượt",
            "Mức vẽ lại ở mỗi lượt riêng của từng nhân vật.",
            "Thấp: bám sát bố cục lượt đầu, ít lệch. Cao: tự do sửa nhiều hơn nhưng dễ lệch bố cục chung.",
            "Vùng khuyến nghị 0.4 đến 0.5; mặc định 0.45.",
            "0.45"
        ),
        "expressionFacePass" to e(
            "Vẽ lại biểu cảm từng khuôn mặt",
            "Vẽ lại từng khuôn mặt để biểu cảm đúng kịch bản (kiểu ADetailer).",
            "Bật: biểu cảm rõ hơn nhưng lượt vẽ lại có thể lệch khuôn mặt nếu không giữ danh tính; tốn thêm thời gian.",
            "Bật cùng Giữ danh tính bằng ảnh anchor và cổng danh tính ArcFace; so ảnh trước/sau trước khi tin dùng.",
            "Tắt",
            "Mặc định tắt."
        ),
        "expressionFaceDenoise" to e(
            "Vẽ lại mặt: Denoise",
            "Mức vẽ lại khuôn mặt.",
            "Thấp: giữ khuôn mặt gốc, biểu cảm đổi ít. Cao: biểu cảm đổi mạnh nhưng dễ lệch danh tính.",
            "Mặc định 0.42. Nếu biểu cảm chưa đủ rõ thì tăng lên khoảng 0.5; nếu mặt không giống nhân vật thì giảm.",
            "0.42"
        ),
        "maxExpressionFaces" to e(
            "Số mặt tối đa mỗi panel",
            "Giới hạn số khuôn mặt được vẽ lại biểu cảm trong một panel.",
            "Nhiều: mặt nào cũng được xử lý nhưng chậm. Ít: nhanh, bỏ bớt mặt phụ.",
            "Mặc định 3.",
            "3"
        ),
        "expressionFaceIdentity" to e(
            "Giữ danh tính bằng ảnh anchor",
            "Khi vẽ lại mặt, dùng ảnh anchor của nhân vật làm tham chiếu IP-Adapter để giữ khuôn mặt.",
            "Bật: mặt giống nhân vật hơn. Tắt: vẽ lại không tham chiếu nên dễ lệch danh tính.",
            "Giữ bật.",
            "Bật",
            "Cần model SD1.5 augmented đã nạp; không có thì tự rơi về cách thường."
        ),
        "expressionIdentityScale" to e(
            "Độ bám danh tính (IP-Adapter)",
            "Cường độ ảnh anchor khi vẽ lại mặt.",
            "Cao: giống nhân vật hơn nhưng prompt biểu cảm bị lấn át. Thấp: biểu cảm rõ hơn nhưng dễ lệch danh tính.",
            "Mặc định 0.6 (thấp để biểu cảm còn thắng). Biểu cảm đúng mà mặt lạ thì tăng; mặt giống mà biểu cảm không đổi thì giảm.",
            "0.6"
        ),
        "expressionIdentityMinSim" to e(
            "Ngưỡng giống danh tính (ArcFace)",
            "Sau khi vẽ lại mặt, đo độ giống với mặt cũ bằng ArcFace (cosine). Dưới ngưỡng: thử lại một lần với denoise thấp hơn; vẫn dưới ngưỡng thì giữ mặt cũ. Bằng 0 là tắt cổng.",
            "Cao: nghiêm, hay giữ mặt cũ (biểu cảm ít đổi). Thấp: dễ tính, nhiều mặt mới được nhận kể cả khi hơi lệch.",
            "Mặc định 0.4. Nếu biểu cảm hiếm khi đổi được thì giảm xuống 0.3 đến 0.35; nếu mặt hay không giống nhân vật thì tăng lên 0.45 đến 0.5.",
            "0.4",
            "Cần arcface_mbf.mnn. Con số ước lượng, chưa đo."
        ),
        "autoConditioningPresets" to e(
            "Tự chỉnh điều kiện theo hành động",
            "Tự đặt cường độ pose, depth, IP-Adapter theo loại hành động của panel (đánh, ôm, đứng...).",
            "Bật: không phải chỉnh tay từng panel. Tắt: dùng giá trị chung bạn đặt.",
            "Dùng nút So sánh thử ở màn duyệt ảnh để xác nhận trên panel của bạn trước khi tin dùng.",
            "Tắt",
            "Giá trị cài sẵn là suy luận, chưa đo. Model .mnn cũ sẽ bỏ qua an toàn."
        ),
        "poseConditioningScale" to e(
            "Mức bám khung xương (ControlNet Pose)",
            "Cường độ ControlNet-Pose ép ảnh theo khung xương.",
            "Cao: tư thế đúng khung xương hơn nhưng cứng. Thấp: tự nhiên hơn, dễ lệch tư thế.",
            "Mặc định 1.0. Giảm xuống 0.6 đến 0.8 khi ranh giới cơ thể bị loãng hoặc khi có depth đi kèm.",
            "1.0"
        ),
        "depthConditioningScale" to e(
            "Mức bám bản đồ độ sâu (ControlNet Depth)",
            "Cường độ ControlNet-Depth giữ thứ tự trước/sau giữa các người.",
            "Cao: ép đúng thứ tự trước/sau nhưng có thể cứng hình khối. Thấp: nhẹ, ít tác dụng.",
            "Mặc định 0.6. Tăng khi người bị chồng sai trước/sau.",
            "0.6",
            "Chỉ có tác dụng với model .mnn đã export lại có depth."
        ),
        "depthActiveMinTimestep" to e(
            "Depth chỉ tác động từ timestep",
            "Depth chỉ ảnh hưởng ở các bước đầu và giữa (timestep không nhỏ hơn giá trị này, thang 0 đến 999).",
            "Nhỏ: depth tác động lâu hơn nên cứng hơn. Lớn: depth chỉ tác động sớm, phần chi tiết cuối được tự do.",
            "Mặc định 300 (xấp xỉ dừng depth ở khoảng 70 phần trăm quá trình). Giảm nếu depth không giữ được, tăng nếu ảnh quá cứng.",
            "300.0",
            "Chỉ có tác dụng với model .mnn đã export lại có depth."
        ),
        "ipDecayFloor" to e(
            "Suy giảm IP-Adapter: mức sàn",
            "Làm cường độ ảnh tham chiếu giảm dần trong quá trình sinh, xuống tới mức sàn này.",
            "1.0 là không suy giảm. Thấp hơn: giai đoạn cuối ít bị ảnh tham chiếu níu, chi tiết theo prompt hơn.",
            "Giữ 1.0 nếu chưa cần. Thử 0.4 đến 0.6 khi nhân vật bị đóng băng theo ảnh tham chiếu.",
            "1.0",
            "Chỉ có tác dụng với model .mnn đã export lại; chưa đo hiệu quả."
        ),
        "ipDecayStartTimestep" to e(
            "Suy giảm IP-Adapter: mốc bắt đầu",
            "Timestep bắt đầu giảm cường độ (999 là giảm ngay từ đầu).",
            "Nhỏ: giữ nguyên cường độ lâu hơn rồi mới giảm. Lớn: giảm sớm.",
            "Chỉ có ý nghĩa khi mức sàn nhỏ hơn 1.0.",
            "999.0"
        ),
        "consistencyStrength" to e(
            "Độ nhất quán nhân vật",
            "Cường độ ảnh tham chiếu (IP-Adapter) giữ khuôn mặt và trang phục nhân vật qua các panel.",
            "Cao: nhân vật giống nhau hơn nhưng dễ cứng, lặp dáng. Thấp: tự do hơn nhưng dễ lệch.",
            "Mặc định 80 phần trăm. Tăng nếu nhân vật thay đổi giữa các panel; giảm nếu mọi panel copy tư thế từ ảnh tham chiếu.",
            "80%",
            "Chỉ có tác dụng với model .mnn đã export lại có đầu vào ip_static_scale; model cũ tự bỏ qua và giữ cường độ gốc."
        ),
        "useStoryDiffusion" to e(
            "Nhất quán mặt, trang phục, vóc dáng",
            "Dùng ảnh tham chiếu nhân vật để giữ mặt, trang phục và vóc dáng qua các panel.",
            "Bật: nhân vật nhất quán hơn. Tắt: mỗi panel tự do, nhanh hơn.",
            "Giữ bật cho truyện nhiều panel.",
            "Bật"
        ),
        "locationAnchorStrength" to e(
            "Độ bám bối cảnh (Location Anchor)",
            "Cường độ ảnh bối cảnh neo giữ nền nhất quán giữa các panel cùng địa điểm.",
            "Cao: nền giống nhau hơn nhưng dễ lặp y hệt bố cục panel neo. Thấp: nền tự do hơn.",
            "Mặc định 50 phần trăm. Tăng nếu nền đổi giữa các panel; giảm nếu panel nào cũng giống panel neo.",
            "50%",
            "Tác dụng đầy đủ nhất ở panel KHÔNG có nhân vật; panel có nhân vật chỉ dùng được ở đường Triple-Combo với model đã export lại. Giá trị khởi điểm theo suy luận, chưa có so sánh A/B thật."
        ),
        "checkObjectScale" to e(
            "Cảnh báo lệch tỉ lệ vật thể",
            "Ghi cảnh báo vào log khi vật thể hoặc người lệch quá ngưỡng giữa các panel cùng cảnh (cần khai hộp vật thể).",
            "Bật: biết panel nào vật thể to nhỏ bất thường. Ngưỡng chỉnh ở thanh bên dưới. Tắt: không kiểm.",
            "Bật khi truyện có nhiều panel cùng một cảnh.",
            "Bật"
        ),
        "continuityPlanFill" to e(
            "Tự điền bối cảnh bị bỏ trống",
            "Panel không khai bối cảnh nhưng nằm giữa các panel cùng một bối cảnh sẽ được gán bối cảnh đó TRƯỚC khi sinh ảnh, để ảnh neo bối cảnh được dùng cho cả panel đó (bước lập kế hoạch liên tục kiểu CANVAS). Không điền nhân vật hay vật thể.",
            "Bật: nền ít bị trôi giữa các panel liền nhau. Tắt: panel bỏ trống bối cảnh được sinh theo mô tả riêng như cũ, có thể ra nền khác.",
            "Bật khi thấy nền đổi lung tung giữa các panel cùng một cảnh. Tắt nếu kịch bản cố ý cắt sang nơi khác mà không khai địa điểm.",
            "Tắt",
            "Mới, chưa thử trên truyện thật; mặc định tắt."
        ),
        "rememberApiKeys" to e(
            "Nhớ khoá API trên máy này",
            "Cài đặt thường (công tắc, thanh trượt...) luôn được tự lưu và còn nguyên khi mở lại app. Khoá API và token (LLM ngoài, giám khảo thị giác, Cloudflare, Pollinations, token máy chủ Remote GPU) mặc định KHÔNG được lưu; bật mục này để lưu chúng.",
            "Bật: khỏi nhập lại khoá mỗi lần mở app; khoá được ghi dạng chữ thường vào một tệp riêng trong vùng riêng của app, không đi theo sao lưu tự động của Android. Tắt: khoá chỉ nằm trong bộ nhớ, đóng app là phải nhập lại, và tệp khoá đã lưu (nếu có) bị xoá.",
            "Bật nếu máy là của riêng bạn và có khoá màn hình. Tắt nếu dùng máy chung hoặc không muốn khoá nằm trên đĩa.",
            "Tắt",
            "Không mã hoá: máy đã root hoặc ai đọc được vùng riêng của app đều thấy khoá. Gỡ app là xoá hết. Chưa thử trên máy thật."
        ),
        "checkContinuity" to e(
            "Cảnh báo đứt quãng giữa các panel",
            "Ghi cảnh báo vào log khi kịch bản khai bối cảnh, nhân vật hoặc vật thể ở các panel liền nhau nhưng bị mất rồi hiện lại: panel chưa gán địa điểm nằm giữa hai panel cùng địa điểm, nhân vật vắng đúng một panel giữa hai panel có mặt, vật thể biến mất rồi xuất hiện lại.",
            "Bật: biết panel nào có thể bị trôi nền hoặc bị bỏ sót nhân vật hay vật thể để sửa kịch bản. Tắt: không kiểm. Không bao giờ tự đổi ảnh hay kịch bản.",
            "Bật khi truyện có nhiều panel cùng một cảnh. Cảnh cắt cố ý chỉ thấy một nhân vật thì cứ bỏ qua cảnh báo đó.",
            "Bật",
            "Chỉ kiểm cái đã khai; chưa hiệu chỉnh mức nhiễu trên truyện thật; chỉ so các panel có số thứ tự liên tiếp."
        ),
        "scaleConsistencyThreshold" to e(
            "Ngưỡng lệch tỉ lệ vật thể",
            "Độ lệch so với tỉ lệ vật/người trung bình của các panel cùng cảnh; vượt mức này thì cảnh báo.",
            "Thấp: nghiêm, nhiều cảnh báo. Cao: chỉ báo khi lệch lớn.",
            "Mặc định 20 phần trăm (mức cộng đồng hay dùng). Nếu báo quá nhiều do góc máy khác nhau thì tăng lên 30; muốn chặt hơn thì giảm xuống 15.",
            "20%",
            "Con số lấy từ cộng đồng, chưa đo trên ảnh của dự án."
        ),
        "thermalThreshold" to e(
            "Ngưỡng nhiệt để tạm dừng",
            "Nhiệt độ máy (độ C) mà khi đạt tới, app tạm dừng sinh ảnh để máy nguội.",
            "Thấp: dừng sớm, máy mát nhưng chậm. Cao: ít dừng nhưng nóng, có thể bị giảm xung nhịp.",
            "Mặc định 42. Tăng nhẹ nếu dừng quá nhiều; giảm nếu máy nóng ran.",
            "42 °C"
        ),
        "autoResume" to e(
            "Tự tiếp tục khi nguội",
            "Tự chạy tiếp khi nhiệt độ đã xuống dưới ngưỡng trừ độ lệch.",
            "Bật: không phải bấm tiếp. Tắt: phải tự bấm tiếp.",
            "Giữ bật nếu để máy chạy qua đêm.",
            "Bật"
        ),
        "thermalResumeOffset" to e(
            "Độ lệch nhiệt để tiếp tục",
            "Chỉ tiếp tục khi nhiệt độ không cao hơn (ngưỡng trừ giá trị này).",
            "Lớn: đợi nguội sâu hơn mới chạy lại (ít dừng rồi chạy liên tục). Nhỏ: tiếp tục sớm.",
            "Mặc định 3 độ C.",
            "3 °C"
        ),
        "cancelTimeoutMs" to e(
            "Thời gian chờ trước khi báo treo",
            "Sau khi bấm huỷ, đợi tối đa bấy nhiêu giây trước khi coi tiến trình bị treo.",
            "Dài: cho tiến trình nặng thêm thời gian dừng êm. Ngắn: báo treo sớm.",
            "Mặc định 30 giây. Tăng nếu máy chậm và hay bị báo treo oan.",
            "30 giây"
        ),
        "cbzJpegQuality" to e(
            "Chất lượng JPEG khi đóng gói CBZ",
            "Mức nén JPEG của ảnh trong file CBZ.",
            "Cao: nét hơn, file nặng. Thấp: nhẹ nhưng dưới 80 bắt đầu thấy vỡ khối ở nét mảnh (chữ thoại, viền bong bóng).",
            "Mặc định 92. Không cần hạ dưới 85 trừ khi dung lượng là vấn đề.",
            "92"
        ),
        "exportRightToLeft" to e(
            "Manga đọc phải sang trái",
            "Xuất PDF và CBZ theo chiều đọc manga (phải sang trái).",
            "Bật: thứ tự trang đảo và CBZ báo chiều đọc phải sang trái. Tắt: đọc trái sang phải.",
            "Bật cho manga kiểu Nhật.",
            "Tắt"
        ),
        "exportWebtoonZip" to e(
            "Xuất gói Webtoon",
            "Tạo gói ảnh JPEG rộng 800px, mỗi ảnh cao tối đa 1280px và không quá 2MB để tải lên nền tảng webtoon.",
            "Bật: có thêm file ZIP đúng khổ. Tắt: không tạo.",
            "Bật khi định đăng lên Webtoon hoặc Tapas.",
            "Tắt"
        ),
        "exportMetadataJson" to e(
            "Xuất metadata JSON",
            "Kèm file JSON (tên truyện, mô tả, nhân vật...) để tự điền khi tải lên nền tảng.",
            "Bật: có thêm file metadata. Tắt: không tạo.",
            "Bật khi định đăng truyện lên nền tảng.",
            "Tắt"
        ),
        "exportVideoPack" to e(
            "Gói ảnh cho công cụ video",
            "Xuất khung đầu sạch không bóng thoại, khung kết, prompt chuyển động, thoại và metadata để dùng với công cụ làm video bên ngoài.",
            "Bật: có thêm thư mục gói video. Tắt: không tạo.",
            "Bật khi định dựng video từ truyện.",
            "Tắt"
        ),
        "exportVideoSpeech" to e(
            "Kèm giọng đọc (TTS)",
            "Kèm file âm thanh đọc từng câu thoại bằng giọng đọc của máy trong gói video.",
            "Bật: có file âm thanh rời cho từng câu. Tắt: không có.",
            "Bật cùng Gói ảnh cho công cụ video.",
            "Tắt",
            "Cần bật Gói ảnh cho công cụ video; âm thanh là file rời, không tự ghép vào video."
        ),
        "exportVideoRemote" to e(
            "Clip chuyển động trên server (SVD)",
            "Tạo clip chuyển động từng panel bằng Stable Video Diffusion trên server từ xa và đưa clip.mp4 vào gói video.",
            "Bật: có clip chuyển động nhưng tốn thời gian GPU của server. Tắt: không tạo.",
            "Chỉ bật khi đã bật Remote GPU và dùng server bản mới.",
            "Tắt",
            "Cần Remote GPU và app.py bản mới."
        ),
        "remoteEndpoint.enabled" to e(
            "Remote GPU",
            "Gửi việc sinh ảnh tới máy chủ GPU của bạn thay vì chạy trên điện thoại.",
            "Bật: nhanh và dùng được model nặng; dữ liệu đi qua mạng (có mã hoá). Tắt: sinh trên máy.",
            "Bật khi đã dựng server theo hướng dẫn.",
            "Tắt"
        ),
        "remoteEndpoint.pagScale" to e(
            "PAG (Perturbed-Attention Guidance)",
            "Kỹ thuật tăng độ chắc cấu trúc ảnh bằng cách so sánh hai lượt attention (một bình thường, một bị phá nhiễu) trên server.",
            "0 là tắt. Cao hơn: cấu trúc/giải phẫu ổn định hơn nhưng sinh chậm gần gấp đôi và quá cao có thể làm ảnh lạ.",
            "Thử 1.5 đến 3.0 cho cảnh nhiều người chồng nhau. Đặt xong trước khi bấm Generate cho cả chương, đừng đổi giữa chừng.",
            "0 (tắt)",
            "Chạy trên server, không áp dụng cho sinh ảnh trên máy."
        ),
        "remoteFaceSwap" to e(
            "Hoán đổi mặt theo nhân vật (server)",
            "Hậu kỳ trên server: thay mặt trong ảnh bằng mặt của nhân vật đã khai (insightface và inswapper).",
            "Bật: mặt đúng nhân vật hơn. Chạy theo thứ tự Kontext, sửa tay, hoán đổi mặt.",
            "Chỉ bật khi đã bật Remote GPU và dùng server bản mới.",
            "Tắt",
            "Giấy phép inswapper và FLUX Kontext là phi thương mại: kiểm tra trước khi xuất bản."
        ),
        "remoteHandFix" to e(
            "Sửa tay (HandRefiner, server)",
            "Hậu kỳ trên server: dò và vẽ lại bàn tay lỗi.",
            "Bật: tay thường đúng hơn nhưng tốn thời gian GPU. Tắt: không sửa.",
            "Chỉ bật khi đã bật Remote GPU và dùng server bản mới.",
            "Tắt"
        ),
        "remoteKontext" to e(
            "Chỉnh danh tính bằng FLUX Kontext (server)",
            "Hậu kỳ trên server: dùng FLUX Kontext chỉnh ảnh theo ảnh tham chiếu nhân vật để giữ danh tính.",
            "Bật: có thể giữ nhân vật tốt hơn nhưng nặng VRAM và còn thử nghiệm. Tắt: không dùng.",
            "Chỉ thử khi server có đủ VRAM; kiểm tra bằng tập lệnh smoke_test.py trước.",
            "Tắt",
            "Thử nghiệm. Giấy phép FLUX Kontext là phi thương mại."
        ),
        "remoteInteractLayout" to e(
            "Bố cục tương tác (InteractDiffusion, server)",
            "Với panel 2 người ôm/hôn/đánh nhau, server sinh ảnh bố cục theo hành động, app trích khung xương rồi vẽ lại bằng pipeline của dự án.",
            "Bật: tư thế tiếp xúc có cơ sở hơn từ model hiểu tương tác. Tắt: dùng khung xương mẫu như thường.",
            "Chỉ bật cho cảnh 2 người có tiếp xúc rõ ràng.",
            "Tắt",
            "Thử nghiệm."
        ),
        "addonLora.enabled" to e(
            "LoRA phụ: bật/tắt",
            "Bật hoặc tắt LoRA phụ này khi sinh ảnh.",
            "Bật: LoRA tác động lên phong cách/chi tiết. Tắt: bỏ qua LoRA này.",
            "Tắt tạm để so sánh ảnh có và không có LoRA.",
            "Tuỳ từng LoRA"
        ),
        "addonLora.weight" to e(
            "LoRA phụ: trọng số",
            "Mức ảnh hưởng của LoRA phụ lên phong cách và chi tiết.",
            "Cao: ảnh hưởng mạnh, dễ lẫn nhân vật hoặc méo hình. Thấp: tác dụng nhẹ.",
            "Thường 0.6 đến 1.0; giảm bớt khi bật nhiều LoRA cùng lúc.",
            "Tuỳ từng LoRA"
        ),
        "bubbleFontScale" to e(
            "Cỡ chữ bubble",
            "Hệ số nhân lên cỡ chữ tự động của bubble này (cỡ gốc tự tính theo chiều cao panel).",
            "Lớn: chữ to dễ đọc nhưng bubble cao hơn và che nhiều tranh hơn; chữ quá dài bị cắt ở dòng thứ 8. Nhỏ: gọn nhưng khó đọc khi in nhỏ.",
            "Giữ 100 phần trăm cho hầu hết bubble. Tăng 120 đến 150 cho câu hét hoặc khi xuất cho màn hình nhỏ; giảm khoảng 80 cho câu dài.",
            "100% (cỡ tự động)",
            "Chỉ áp dụng cho bubble này khi xuất bằng bộ vẽ bubble của ứng dụng."
        ),
        "pageLayoutEditor" to e(
            "Bố cục trang PDF (sửa tay)",
            "Quyết định mỗi trang PDF gồm những panel nào và dùng mẫu ô nào (1 panel, 2 dọc, 1 rộng cộng 2 dưới, lưới 2x2, 4 dải dọc). Thứ tự đọc của truyện luôn được giữ nguyên.",
            "Đổi mẫu: ô của trang đổi hình dạng; mẫu ít ô hơn số panel thì panel thừa chuyển sang trang mới ngay sau, không bị mất. Đẩy hoặc tách hoặc gộp: dời chỗ ngắt trang. Khi đã sửa, bố cục này thắng mẫu chọn ở Cài đặt cho PDF của chương.",
            "Đặt panel cao trào một mình một trang, cảnh yên tĩnh nhiều thoại dùng lưới 2x2, cảnh hành động tối đa 3 ô. Bấm Dùng bố cục tự chọn để lấy gợi ý theo nhịp truyện rồi chỉnh tiếp từ đó.",
            "Chưa sửa (PDF theo mẫu ở Cài đặt)",
            "Chỉ ảnh hưởng PDF. CBZ, video và dải Webtoon vẫn theo thứ tự panel. Chưa đổi được kích thước ô tự do và chưa xem thử PDF thật trên máy."
        ),
        "bubbleFont" to e(
            "Font chữ bubble",
            "Họ font dùng cho chữ lời thoại của bubble này. Chỉ có 5 họ font sẵn có của Android.",
            "Thường: mặc định. Đậm: nhấn mạnh. Có chân: giọng sách hoặc dẫn truyện. Đơn cách: máy móc, robot. Nghiêng: thì thầm hoặc suy nghĩ.",
            "Dùng Thường cho hội thoại, Nghiêng cho suy nghĩ, Đậm cho câu hét. Chữ tiếng Việt có dấu hiển thị theo font hệ thống nên hình dạng có thể khác giữa các máy.",
            "Thường",
            "Chưa hỗ trợ font riêng (viết tay, kiểu truyện tranh) vì ứng dụng không đóng gói file font."
        ),
        "bubbleTail" to e(
            "Đuôi bong bóng",
            "Vẽ đuôi nhọn chỉ về người nói; kéo chấm cam trên ảnh để đổi đích đuôi.",
            "Bật: bubble chỉ rõ ai đang nói. Tắt: bubble không đuôi (hợp với lời dẫn truyện).",
            "Bật cho thoại, tắt cho lời dẫn; kéo đích về phía miệng người nói.",
            "Tuỳ bubble"
        ),
        "boneTorso" to e(
            "Tỉ lệ thân (cổ đến hông)",
            "Hệ số nhân chiều dài đoạn thân từ cổ đến hông so với mẫu người lớn trung bình (1.0 là đúng mẫu). Dùng để dựng khung xương riêng của nhân vật này.",
            "Lớn: đoạn này dài hơn mẫu. Nhỏ: ngắn hơn. Khung xương này điều khiển ControlNet-Pose nên ảnh sinh ra theo tỉ lệ đó.",
            "Chỉ chỉnh khi nhân vật có vóc dáng lệch rõ so với trung bình; mỗi lần đổi khoảng 0.05 đến 0.1 rồi xem thử. Đi xa khỏi 1.0 quá nhiều thì tư thế dễ méo.",
            "1.0",
            "Khoảng cho phép 0.6 đến 1.3. Con số ước lượng, chưa đo trên ảnh thật."
        ),
        "boneUpperArm" to e(
            "Tỉ lệ cánh tay trên (vai đến khuỷu)",
            "Hệ số nhân chiều dài đoạn cánh tay trên từ vai đến khuỷu so với mẫu người lớn trung bình (1.0 là đúng mẫu). Dùng để dựng khung xương riêng của nhân vật này.",
            "Lớn: đoạn này dài hơn mẫu. Nhỏ: ngắn hơn. Khung xương này điều khiển ControlNet-Pose nên ảnh sinh ra theo tỉ lệ đó.",
            "Chỉ chỉnh khi nhân vật có vóc dáng lệch rõ so với trung bình; mỗi lần đổi khoảng 0.05 đến 0.1 rồi xem thử. Đi xa khỏi 1.0 quá nhiều thì tư thế dễ méo.",
            "1.0",
            "Khoảng cho phép 0.6 đến 1.3. Con số ước lượng, chưa đo trên ảnh thật."
        ),
        "boneForearm" to e(
            "Tỉ lệ cẳng tay (khuỷu đến cổ tay)",
            "Hệ số nhân chiều dài đoạn cẳng tay từ khuỷu đến cổ tay so với mẫu người lớn trung bình (1.0 là đúng mẫu). Dùng để dựng khung xương riêng của nhân vật này.",
            "Lớn: đoạn này dài hơn mẫu. Nhỏ: ngắn hơn. Khung xương này điều khiển ControlNet-Pose nên ảnh sinh ra theo tỉ lệ đó.",
            "Chỉ chỉnh khi nhân vật có vóc dáng lệch rõ so với trung bình; mỗi lần đổi khoảng 0.05 đến 0.1 rồi xem thử. Đi xa khỏi 1.0 quá nhiều thì tư thế dễ méo.",
            "1.0",
            "Khoảng cho phép 0.6 đến 1.3. Con số ước lượng, chưa đo trên ảnh thật."
        ),
        "boneUpperLeg" to e(
            "Tỉ lệ đùi (hông đến gối)",
            "Hệ số nhân chiều dài đoạn đùi từ hông đến gối so với mẫu người lớn trung bình (1.0 là đúng mẫu). Dùng để dựng khung xương riêng của nhân vật này.",
            "Lớn: đoạn này dài hơn mẫu. Nhỏ: ngắn hơn. Khung xương này điều khiển ControlNet-Pose nên ảnh sinh ra theo tỉ lệ đó.",
            "Chỉ chỉnh khi nhân vật có vóc dáng lệch rõ so với trung bình; mỗi lần đổi khoảng 0.05 đến 0.1 rồi xem thử. Đi xa khỏi 1.0 quá nhiều thì tư thế dễ méo.",
            "1.0",
            "Khoảng cho phép 0.6 đến 1.3. Con số ước lượng, chưa đo trên ảnh thật."
        ),
        "boneLowerLeg" to e(
            "Tỉ lệ cẳng chân (gối đến mắt cá)",
            "Hệ số nhân chiều dài đoạn cẳng chân từ gối đến mắt cá so với mẫu người lớn trung bình (1.0 là đúng mẫu). Dùng để dựng khung xương riêng của nhân vật này.",
            "Lớn: đoạn này dài hơn mẫu. Nhỏ: ngắn hơn. Khung xương này điều khiển ControlNet-Pose nên ảnh sinh ra theo tỉ lệ đó.",
            "Chỉ chỉnh khi nhân vật có vóc dáng lệch rõ so với trung bình; mỗi lần đổi khoảng 0.05 đến 0.1 rồi xem thử. Đi xa khỏi 1.0 quá nhiều thì tư thế dễ méo.",
            "1.0",
            "Khoảng cho phép 0.6 đến 1.3. Con số ước lượng, chưa đo trên ảnh thật."
        ),
        "boneHeadSize" to e(
            "Kích thước đầu (ước lượng)",
            "Hệ số nhân chiều dài kích thước đầu so với mẫu người lớn trung bình (1.0 là đúng mẫu). Dùng để dựng khung xương riêng của nhân vật này.",
            "Lớn: đoạn này dài hơn mẫu. Nhỏ: ngắn hơn. Khung xương này điều khiển ControlNet-Pose nên ảnh sinh ra theo tỉ lệ đó.",
            "Chỉ chỉnh khi nhân vật có vóc dáng lệch rõ so với trung bình; mỗi lần đổi khoảng 0.05 đến 0.1 rồi xem thử. Đi xa khỏi 1.0 quá nhiều thì tư thế dễ méo.",
            "1.0",
            "Khoảng cho phép 0.7 đến 1.5. Con số ước lượng, chưa đo trên ảnh thật."
        ),
        "expressionIntensity" to e(
            "Cường độ biểu cảm",
            "Mức đậm của biểu cảm khi vẽ lại mặt: nhẹ, vừa hoặc mạnh.",
            "Mạnh: biểu cảm rõ nhưng có thể quá đà hoặc lệch nét mặt. Nhẹ: tinh tế nhưng khó nhận ra.",
            "Dùng vừa cho thoại thường; mạnh cho khoảnh khắc cao trào.",
            "Tuỳ biểu cảm"
        ),
        "panelSize" to e(
            "Kích thước ảnh của panel này",
            "Ghi đè chiều rộng và chiều cao (điểm ảnh) khi sinh lại riêng panel này.",
            "Lớn: nhiều chi tiết hơn nhưng chậm và tốn RAM; SD1.5 quen với khoảng 512 nên vượt xa thường làm lặp thân người. Nhỏ: nhanh nhưng thô.",
            "Giữ kích thước đã chọn cho cả truyện; chỉ đổi khi panel cần khổ dọc hoặc ngang rõ rệt.",
            "Theo cài đặt chung"
        ),
        "keypointVisible" to e(
            "Hiện khớp này",
            "Bật hoặc tắt việc vẽ khớp đang chọn vào khung xương gửi cho ControlNet-Pose.",
            "Ẩn: khung xương thiếu khớp đó nên mô hình tự quyết vị trí (hợp khi khớp bị che hoặc ngoài khung hình). Hiện: ép đúng vị trí khớp.",
            "Ẩn các khớp nằm sau vật che hoặc ngoài khung hình; còn lại để hiện.",
            "Hiện"
        ),
        "conceptDictionaryEnabled" to e(
            "Tra cứu từ điển khái niệm khi sinh prompt",
            "Chèn các cặp tên khái niệm và thẻ (tag) đã lưu trong từ điển của truyện vào prompt gửi cho LLM.",
            "Bật: các khái niệm lặp lại (tên vũ khí, địa danh...) được mô tả nhất quán. Tắt: LLM tự diễn giải mỗi lần. Từ điển rỗng thì bật hay tắt không khác gì.",
            "Giữ bật; thêm mục vào từ điển cho các khái niệm hay xuất hiện.",
            "Bật"
        ),
        "remoteFaceOcclusion" to e(
            "Giữ pixel gốc nơi tay che mặt",
            "Khi hoán đổi mặt, gửi cho server vị trí cổ tay nằm gần mặt để server giữ nguyên pixel gốc ở đó, tránh mặt hoán đổi xoá mất bàn tay đè lên mặt.",
            "Bật: tay che mặt vẫn thấy được; nếu mặt bị che hơn 85 phần trăm thì bỏ qua hoán đổi cho mặt đó. Tắt: mặt hoán đổi phủ lên cả bàn tay.",
            "Giữ bật. Tắt khi thấy có vệt tròn lạ quanh cổ tay.",
            "Bật",
            "Bàn tay được xấp xỉ bằng một hình tròn quanh cổ tay nên không khít từng ngón; chưa đo trên ảnh thật. Cần bật Hoán đổi mặt."
        ),
        "remoteFaceRestore" to e(
            "Khôi phục chi tiết mặt (GFPGAN)",
            "Sau khi hoán đổi, server làm nét mặt bằng GFPGAN (khuôn mặt hoán đổi thường mờ vì chạy ở 128 điểm ảnh).",
            "Bật: mặt nét hơn nhưng GFPGAN có thể làm mịn quá hoặc đổi nhẹ biểu cảm; app/server sẽ tự bỏ khôi phục cho mặt nào bị lệch biểu cảm. Tắt: giữ mặt hoán đổi nguyên trạng.",
            "Chỉ bật khi mặt hoán đổi quá mờ. Chỉnh Độ mạnh để cân giữa nét và tự nhiên.",
            "Tắt",
            "Cần server cài gói gfpgan và đặt biến môi trường MANGALOCAL_GFPGAN_MODEL trỏ tới file trọng số; thiếu thì vẫn trả ảnh hoán đổi bình thường. Kiểm tra giấy phép trọng số trước khi dùng thương mại."
        ),
        "remoteFaceRestoreStrength" to e(
            "Độ mạnh khôi phục mặt",
            "Tỉ lệ trộn giữa mặt vừa khôi phục và mặt hoán đổi gốc (100 phần trăm là dùng hẳn bản khôi phục).",
            "Cao: nét hơn nhưng dễ mịn như nhựa hoặc lệch nét. Thấp: giữ nét tự nhiên, ít khác biệt.",
            "Mặc định 70 phần trăm. Giảm xuống 40 đến 50 nếu da quá mịn; tăng lên 90 đến 100 nếu vẫn mờ.",
            "70%",
            "Con số ước lượng, chưa đo. Chỉ có tác dụng khi bật Khôi phục chi tiết mặt."
        ),
        "loraTiesMerge" to e(
            "Gộp LoRA kiểu TIES khi ghép nhiều nhân vật",
            "Khi ghép nhiều nhân vật vào một model, mỗi LoRA đóng góp một delta trọng số. Thay vì cộng thẳng (các LoRA cùng hoặc ngược dấu ở một phần tử cộng dồn hay triệt tiêu nhau), TIES chỉ giữ phần thay đổi lớn nhất của mỗi LoRA, bầu dấu thắng cho từng phần tử và chỉ lấy trung bình các LoRA đồng dấu.",
            "Bật: ít lẫn đặc điểm giữa các nhân vật hơn, nhưng mỗi nhân vật có thể nhạt hơn vì phần nhỏ của LoRA bị bỏ và phần trùng nhau được lấy trung bình thay vì cộng. Tắt: cộng thẳng và trực giao hoá như cũ.",
            "Thử bật khi ảnh nhiều nhân vật bị lẫn mặt, tóc hoặc trang phục. Phải convert lại model ghép cặp thì mới có tác dụng. So sánh cùng seed trước và sau; nếu nhân vật nhạt đi thì tăng Mật độ.",
            "Tắt",
            "Chỉ áp dụng khi convert model ghép cặp có từ 2 LoRA trở lên. Chưa đo trên ảnh truyện thật. Cùng cấu hình luôn cho cùng kết quả."
        ),
        "loraTiesDensity" to e(
            "Mật độ giữ lại mỗi LoRA (TIES)",
            "Tỉ lệ phần tử có độ lớn lớn nhất của MỖI LoRA được giữ lại trước khi gộp; phần còn lại bị bỏ.",
            "Thấp: bỏ nhiều chi tiết nhỏ nên ít nhiễu nhưng nhân vật dễ nhạt hoặc mất nét riêng. Cao: giữ gần đủ nên giống cộng thẳng hơn, nhiễu giữa nhân vật nhiều hơn. 100 phần trăm là không bỏ gì.",
            "Bài báo TIES dùng khoảng 20 phần trăm để gộp model; với LoRA nhân vật mặc định 50 phần trăm là mức dè dặt hơn. Nếu nhân vật nhạt đi thì tăng lên 70 đến 90; nếu vẫn lẫn nhau thì giảm xuống 30 đến 40.",
            "50%",
            "Con số ước lượng, chưa đo. Chỉ có tác dụng khi bật TIES."
        ),
        "loraDareDrop" to e(
            "Độ bỏ ngẫu nhiên (DARE)",
            "DARE: bỏ ngẫu nhiên một phần phần tử của mỗi LoRA rồi nhân phần còn lại lên để giữ độ lớn trung bình.",
            "Cao: giảm trùng lặp giữa các LoRA nhưng tăng nhiễu ngẫu nhiên. 0 là tắt. Kết quả lặp lại được vì dùng seed cố định theo tên trọng số.",
            "Để 0 trừ khi chỉ bật TIES mà nhân vật vẫn lẫn nhau; khi đó thử 10 đến 30 phần trăm.",
            "0%",
            "Chưa rõ hiệu quả với LoRA nhỏ, chưa đo. Chỉ có tác dụng khi bật TIES."
        ),
        "visionJudgeModelDir" to e(
            "Giám khảo ảnh bằng model nhìn-hiểu (VLM)",
            "Thư mục chứa model nhìn-hiểu ảnh đã convert sang MNN (có file config.json), ví dụ Qwen2.5-VL 3B. Sau khi sinh, model nhìn ảnh, đếm người và (với cảnh ôm, vật) cho biết có tiếp xúc thân thể không, như một ý kiến thứ hai ngoài YOLO.",
            "Đặt thư mục: panel nào VLM đếm khác kịch bản hoặc không thấy tiếp xúc sẽ có thêm cảnh báo ở badge Quality Gate; mỗi panel tốn thêm vài giây đến chục giây và khoảng 2 GB RAM. Để trống: tắt.",
            "Chỉ dùng khi đã có model VL dạng MNN và APK build với enable_vlm. Bắt đầu bằng vài panel để xem VLM đếm có đáng tin trên ảnh của bạn không; model nhỏ hay đếm sai khi cảnh đông hoặc bị che.",
            "Trống (tắt)",
            "Cần bật Kiểm tra ảnh SAU khi sinh. Chỉ cảnh báo, không tự sinh lại. Chưa chạy với model thật; kiểm tra giấy phép model trước khi dùng."
        )
    )
}

/** Nút tròn "?" — chạm để mở popup giải thích thông số [key]. Không có mục trợ giúp cho khoá này thì không hiện gì (test chặn trường hợp đó). */
@Composable
fun HelpDot(key: String) {
    val entry = ParamHelp.entries[key]
    var open by remember { mutableStateOf(false) }
    if (entry != null) {
        Box(Modifier.size(32.dp).clickable { open = true }, contentAlignment = Alignment.Center) {
            Box(Modifier.size(18.dp).clip(CircleShape).background(C.Border), contentAlignment = Alignment.Center) {
                Text("?", color = C.T1, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (open) HelpDialog(entry) { open = false }
    }
}

@Composable
private fun HelpDialog(entry: ParamHelpEntry, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = C.S1,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Đã hiểu", color = C.Blue) } },
        title = { Text(entry.title, color = C.T1, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                HelpBlock("Làm gì", entry.what)
                HelpBlock("Khi chỉnh", entry.effect)
                HelpBlock("Nên chỉnh thế nào", entry.howTo)
                if (entry.note.isNotBlank()) HelpBlock("Lưu ý", entry.note)
                Spacer(Modifier.height(4.dp))
                Text("Mặc định: " + entry.default, color = C.T3, fontSize = 12.sp)
            }
        }
    )
}

@Composable
private fun HelpBlock(head: String, body: String) {
    Text(head, color = C.Blue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    Text(body, color = C.T2, fontSize = 13.sp, lineHeight = 18.sp)
    Spacer(Modifier.height(8.dp))
}

/**
 * Nhãn thông số kèm dấu "?" ngay sau nhãn, dùng TRONG một Row (hàng nhãn + giá trị của thanh trượt). Là hàm mở rộng của RowScope để
 * nhóm nhãn nhận `weight(1f, fill = false)`: Compose đo phần tử không trọng số (giá trị bên phải) TRƯỚC, nhãn dài sẽ xuống dòng
 * thay vì đẩy giá trị ra khỏi màn hình nhỏ.
 */
@Composable
fun RowScope.LabelWithHelp(label: String, helpKey: String) {
    Row(Modifier.weight(1f, fill = false), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = C.T2, fontSize = 12.sp, modifier = Modifier.weight(1f, fill = false))
        HelpDot(helpKey)
    }
}

/** Công tắc kèm dấu "?" đứng ngay trước công tắc. Nhận đúng các tham số mà các chỗ gọi `Switch` trong Cài đặt đang dùng. */
@Composable
fun HelpSwitch(
    helpKey: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true,
    colors: SwitchColors = SwitchDefaults.colors()
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        HelpDot(helpKey)
        Switch(checked = checked, onCheckedChange = onCheckedChange, enabled = enabled, colors = colors)
    }
}

/** Hàng thanh trượt hoàn chỉnh: nhãn + dấu "?" + giá trị hiện tại + thanh trượt. Dùng cho các thông số mới thêm ở mục 257. */
@Composable
fun HelpSlider(
    label: String,
    helpKey: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    onChange: (Float) -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        LabelWithHelp(label, helpKey)
        Text(valueText, color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
    Slider(
        value = value, onValueChange = onChange, valueRange = range, steps = steps,
        colors = SliderDefaults.colors(thumbColor = C.Orange, activeTrackColor = C.Orange, inactiveTrackColor = C.Border)
    )
}
