package com.mangalocal.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mangalocal.model.CharacterRole
import com.mangalocal.model.CharacterSummary

/**
 * mục 154 TECHNICAL_STATUS.md — "đảo pipeline nhân vật" (tóm tắt trước →
 * chốt nhân vật → viết kịch bản chi tiết). Màn hình này chỉ hiện ra khi
 * [MainViewModel.analyzeCharactersFirst] phát hiện có nhân vật MỚI — case
 * phổ biến "không có gì mới" (chương 2 trở đi) KHÔNG đi qua màn này.
 *
 * Thiết kế mobile-first: 1 CỘT DUY NHẤT, mỗi nhân vật 1 card cuộn dọc
 * (không bảng/không cột song song — khó chạm đúng trên màn hình hẹp),
 * chip to dễ chạm cho vai trò + "giữ mặt nhất quán", CTA chính GHIM CỐ
 * ĐỊNH ở đáy màn hình (không cuộn mất, luôn thấy được dù danh sách dài),
 * có đường tắt "Dùng gợi ý, viết luôn" cho ai không muốn chỉnh gì.
 */
@Composable
fun CharacterSummaryReviewScreen(nav: NavController, vm: MainViewModel) {
    val summaries by vm.pendingCharacterSummary.collectAsState()

    if (summaries == null) {
        // Bị xoá (huỷ/đã xác nhận xong ở nơi khác) trong lúc màn này đang
        // mở — quay lại ngay, không hiện màn trống.
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    val list = summaries!!

    // State sửa tay CỤC BỘ của màn này — chỉ đẩy lên ViewModel lúc bấm xác
    // nhận (không sửa `pendingCharacterSummary` trực tiếp giữa chừng, tránh
    // vòng lặp re-compose khó lường).
    var removed by remember(list) { mutableStateOf(setOf<String>()) }
    var roles by remember(list) { mutableStateOf(list.associate { it.name to it.suggestedRole }) }
    // Mặc định "cần giữ mặt nhất quán" = TRUE cho MAIN/SUPPORTING, FALSE
    // cho ONETIME — khớp đúng gợi ý StoryManager.suggestConsistencyMethod()
    // (ONETIME -> NONE) để không hỏi thừa cho case rõ ràng không cần.
    var wantsIdentity by remember(list) {
        mutableStateOf(list.filter { it.suggestedRole != CharacterRole.ONETIME }.map { it.name }.toSet())
    }

    val visible = list.filter { it.name !in removed }

    Column(Modifier.fillMaxSize().background(C.Bg)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.cancelCharacterSummaryReview(); nav.popBackStack() }) {
                Icon(Icons.Default.ArrowBack, "Quay lại", tint = C.T1)
            }
            Spacer(Modifier.width(4.dp))
            Column {
                Text("Xác nhận nhân vật", color = C.T1, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("${visible.size} nhân vật mới phát hiện trong văn bản", color = C.T3, fontSize = 12.sp)
            }
        }

        Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = C.BlueDim, shape = RoundedCornerShape(10.dp)) {
            Text(
                "AI đã đọc truyện và đoán vai trò từng người. Xác nhận/chỉnh lại trước khi viết kịch bản chi tiết — " +
                "giúp AI né gộp chung 1 khung ảnh những người cần giữ mặt riêng biệt.",
                color = C.Blue, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(10.dp)
            )
        }
        Spacer(Modifier.height(10.dp))

        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.name }) { summary ->
                if (summary.name !in removed) {
                    CharacterSummaryCard(
                        summary = summary,
                        role = roles[summary.name] ?: summary.suggestedRole,
                        onRoleChange = { newRole -> roles = roles + (summary.name to newRole) },
                        wantsIdentity = summary.name in wantsIdentity,
                        onWantsIdentityChange = { want ->
                            wantsIdentity = if (want) wantsIdentity + summary.name else wantsIdentity - summary.name
                        },
                        onRemove = { removed = removed + summary.name }
                    )
                }
            }
            item { Spacer(Modifier.height(4.dp)) }
        }

        // CTA ghim đáy — mobile: luôn trong tầm tay, không phải cuộn xuống
        // cuối danh sách dài mới bấm được.
        Surface(color = C.S1, shadowElevation = 8.dp) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                MlBtn(
                    "✓ Xác nhận (${visible.size} nhân vật) → Viết kịch bản",
                    enabled = visible.isNotEmpty(),
                    onClick = {
                        val confirmed = visible.map { it.copy(suggestedRole = roles[it.name] ?: it.suggestedRole) }
                        vm.confirmCharacterSummaryAndProceed(confirmed, wantsIdentity intersect visible.map { it.name }.toSet())
                        nav.popBackStack()
                    }
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = {
                        // "Dùng gợi ý mặc định" — chấp nhận NGUYÊN VĂN gợi ý
                        // AI, không cần mở/sửa từng card — đường tắt cho ai
                        // không muốn fuss over chi tiết.
                        vm.confirmCharacterSummaryAndProceed(list, wantsIdentity)
                        nav.popBackStack()
                    }, modifier = Modifier.weight(1f)) {
                        Text("Dùng gợi ý mặc định, viết luôn", color = C.T2, fontSize = 12.sp)
                    }
                    TextButton(onClick = { vm.cancelCharacterSummaryReview(); nav.popBackStack() }) {
                        Text("Huỷ", color = C.T3, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun CharacterSummaryCard(
    summary: CharacterSummary,
    role: CharacterRole,
    onRoleChange: (CharacterRole) -> Unit,
    wantsIdentity: Boolean,
    onWantsIdentityChange: (Boolean) -> Unit,
    onRemove: () -> Unit
) {
    MlCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(summary.name, color = C.T1, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                if (summary.briefDescription.isNotBlank()) {
                    Text(summary.briefDescription, color = C.T2, fontSize = 12.sp, lineHeight = 16.sp,
                        fontStyle = FontStyle.Italic, modifier = Modifier.padding(top = 2.dp))
                }
            }
            // Icon xoá — phòng AI nhận nhầm tên (vd nhận nhầm địa danh/vật
            // thể thành tên người) — không bắt buộc dùng, chỉ hiện sẵn.
            IconButton(onClick = onRemove, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Close, "Không phải nhân vật, bỏ khỏi danh sách", tint = C.T3, modifier = Modifier.size(18.dp))
            }
        }
        Spacer(Modifier.height(10.dp))

        Text("Vai trò", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf(CharacterRole.MAIN to "Chính", CharacterRole.SUPPORTING to "Phụ", CharacterRole.ONETIME to "Một lần")
                .forEach { (r, label) ->
                    val sel = role == r
                    Surface(
                        onClick = { onRoleChange(r) }, color = if (sel) C.BlueDim else C.S0,
                        shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (sel) C.Blue else C.Border)
                    ) {
                        Text(label, color = if (sel) C.Blue else C.T2, fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                    }
                }
        }
        Spacer(Modifier.height(10.dp))

        // "Cần giữ mặt nhất quán?" — chip 2 trạng thái thay vì Switch nhỏ
        // (mobile: vùng chạm chip rộng hơn hẳn 1 cái Switch bé, đỡ bấm
        // nhầm). Chỉ ảnh hưởng HINT tạm cho lượt viết kịch bản này (xem
        // MainViewModel.confirmCharacterSummaryAndProceed()) — KHÔNG khoá
        // chết phương pháp thật, vẫn chỉnh lại bình thường ở màn Nhân vật
        // sau đó.
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()) {
            Text("Cần giữ mặt nhất quán qua nhiều khung ảnh?", color = C.T2, fontSize = 12.sp,
                modifier = Modifier.weight(1f).padding(end = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(true to "Có", false to "Không").forEach { (v, label) ->
                    val sel = wantsIdentity == v
                    Surface(
                        onClick = { onWantsIdentityChange(v) },
                        color = if (sel) (if (v) C.BlueDim else C.S0) else C.S0,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, if (sel) C.Blue else C.Border)
                    ) {
                        Text(label, color = if (sel) C.Blue else C.T3, fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                    }
                }
            }
        }
    }
}
