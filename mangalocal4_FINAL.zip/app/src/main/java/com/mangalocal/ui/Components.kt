package com.mangalocal.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.mangalocal.model.*

object C {
    val Bg = Color(0xFF0D0D0D); val S0 = Color(0xFF131313)
    val S1 = Color(0xFF1A1A1A); val S2 = Color(0xFF222222)
    val Border = Color(0xFF2C2C2C); val BorderHi = Color(0xFF3A3A3A)
    val Blue = Color(0xFF4A9ED6); val BlueDim = Color(0xFF162233)
    val Green = Color(0xFF4CAF50); val GreenDim = Color(0xFF122012)
    val Orange = Color(0xFFFF9800); val OrangeDim = Color(0xFF2A1A08)
    val Red = Color(0xFFEF5350); val RedDim = Color(0xFF2A1010)
    val Purple = Color(0xFF9C6FD6); val PurpleDim = Color(0xFF1E1030)
    val T1 = Color(0xFFEAEAEA); val T2 = Color(0xFF999999); val T3 = Color(0xFF505050)

    val scheme = darkColorScheme(
        background = Bg, surface = S1, surfaceVariant = S2,
        primary = Blue, onPrimary = Color.White,
        onBackground = T1, onSurface = T1, outline = Border
    )
}

@Composable
fun MlCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier = modifier.fillMaxWidth(), color = C.S1,
        shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, C.Border)) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun MlLabel(text: String) = Text(text.uppercase(), color = C.T3, fontSize = 10.sp,
    fontWeight = FontWeight.SemiBold, letterSpacing = 0.08.sp, modifier = Modifier.padding(bottom = 8.dp))

@Composable
fun MlChip(text: String, color: Color, bg: Color, modifier: Modifier = Modifier) =
    Surface(color = bg, shape = RoundedCornerShape(6.dp), modifier = modifier) {
        Text(text, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
    }

@Composable
fun MlBtn(text: String, onClick: () -> Unit, enabled: Boolean = true,
          icon: ImageVector = Icons.Default.AutoAwesome, modifier: Modifier = Modifier) =
    Button(onClick = onClick, enabled = enabled, modifier = modifier.fillMaxWidth().height(50.dp),
        colors = ButtonDefaults.buttonColors(containerColor = C.Blue, disabledContainerColor = C.S2)) {
        Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }

@Composable
fun MlOutlineBtn(text: String, onClick: () -> Unit, icon: ImageVector? = null,
                 color: Color = C.T2, modifier: Modifier = Modifier, enabled: Boolean = true) =
    OutlinedButton(onClick = onClick, modifier = modifier.fillMaxWidth().height(48.dp), enabled = enabled,
        border = BorderStroke(1.dp, C.Border),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = color)) {
        icon?.let { Icon(it, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)) }
        Text(text, fontSize = 13.sp)
    }

@Composable
fun CharAvatar(name: String, size: Dp = 38.dp) =
    Surface(Modifier.size(size), CircleShape, C.BlueDim) {
        Box(contentAlignment = Alignment.Center) {
            Text(name.firstOrNull()?.uppercase() ?: "?", color = C.Blue,
                fontWeight = FontWeight.Bold, fontSize = (size.value * 0.37f).sp)
        }
    }

@Composable
fun StatCard(v: String, l: String, modifier: Modifier = Modifier) =
    Surface(modifier = modifier, color = C.S0, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, C.Border)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(v, color = C.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(l, color = C.T3, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }

@Composable
fun RoleChip(role: CharacterRole) {
    val (text, color, bg) = when (role) {
        CharacterRole.MAIN -> Triple("Chính", C.Blue, C.BlueDim)
        CharacterRole.SUPPORTING -> Triple("Phụ", C.Purple, C.PurpleDim)
        CharacterRole.ONETIME -> Triple("Một lần", C.T3, C.S0)
    }
    MlChip(text, color, bg)
}

@Composable
fun ThermalBadge(tempC: Int, threshold: Int) {
    val color = when {
        tempC >= threshold -> C.Red
        tempC >= threshold - 5 -> C.Orange
        else -> C.Green
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.size(8.dp).background(color, CircleShape))
        Text("$tempC°C", color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PipelineIndicator(stage: PipelineStage) {
    val steps = listOf("LLM" to PipelineStage.LLM_PARSING, "Prompt" to PipelineStage.PROMPT_BUILDING,
        "SD" to PipelineStage.SD_GENERATING, "Review" to PipelineStage.REVIEW,
        "Upscale" to PipelineStage.UPSCALING, "Bubble" to PipelineStage.BUBBLE_AUTO,
        "Export" to PipelineStage.LAYOUT_EXPORT)
    val idx = steps.indexOfFirst { it.second == stage }.coerceAtLeast(
        if (stage == PipelineStage.DONE) steps.size else 0)

    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
        steps.forEachIndexed { i, (label, _) ->
            val done = i < idx || stage == PipelineStage.DONE
            val active = i == idx && stage != PipelineStage.DONE && stage != PipelineStage.IDLE
            Column(Modifier.width(56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(Modifier.size(26.dp), CircleShape,
                    color = when { done -> C.GreenDim; active -> C.BlueDim; else -> C.S0 },
                    border = BorderStroke(1.dp, when { done -> C.Green; active -> C.Blue; else -> C.Border })) {
                    Box(contentAlignment = Alignment.Center) {
                        if (done) Icon(Icons.Default.Check, null, tint = C.Green, modifier = Modifier.size(13.dp))
                        else Text("${i+1}", color = if (active) C.Blue else C.T3, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text(label, color = C.T3, fontSize = 8.sp, modifier = Modifier.padding(top = 3.dp))
            }
            if (i < steps.size - 1) Divider(Modifier.width(12.dp).padding(bottom = 13.dp),
                color = if (i < idx) C.Green else C.Border, thickness = 1.dp)
        }
    }
}

@Composable
fun ModelDropdown(label: String, selected: String, models: List<ModelInfo>,
                  onSelect: (ModelInfo) -> Unit, onRescan: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val name = if (selected.isEmpty()) "— chưa chọn —" else selected.substringAfterLast('/').take(36)
    Column {
        MlLabel(label)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Surface(onClick = { if (models.isNotEmpty()) expanded = true }, modifier = Modifier.weight(1f),
                color = C.S0, shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (selected.isEmpty()) C.Red.copy(0.5f) else C.Border)) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = if (selected.isEmpty()) C.Red else C.T1, fontSize = 12.sp,
                        modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Icon(Icons.Default.ArrowDropDown, null, tint = C.T3, modifier = Modifier.size(18.dp))
                }
            }
            IconButton(onClick = onRescan, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Refresh, null, tint = C.T2, modifier = Modifier.size(18.dp))
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            if (models.isEmpty()) DropdownMenuItem(text = { Text("Không tìm thấy", color = C.T3) }, onClick = { expanded = false })
            models.forEach { m ->
                DropdownMenuItem(text = { Column {
                    Text(m.name, color = C.T1, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(m.displaySize, color = C.T3, fontSize = 10.sp)
                }}, onClick = { onSelect(m); expanded = false },
                    trailingIcon = { if (selected == m.path) Icon(Icons.Default.Check, null, tint = C.Green, modifier = Modifier.size(14.dp)) })
            }
        }
    }
}

/**
 * mục 275 — lối tắt CÓ CHỮ tới các màn trước đây chỉ có icon trần trên thanh trên (Bối cảnh, Biểu cảm, Gia đình) hoặc chỉ mở được từ màn khác (Tư thế). Người dùng báo không tìm thấy
 * "nhập bối cảnh" và "nhập tư thế từ ảnh/video". KHÔNG đưa vào AppNavBar (giữ 3 mục, xem ghi chú mục 218): đặt ở đầu danh sách của màn Nhân vật và màn chi tiết truyện.
 */
@Composable
fun ToolShortcuts(nav: androidx.navigation.NavController) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        MlLabel("lối tắt")
        MlOutlineBtn("🏞 Bối cảnh — nhập/đổi ảnh nền từng địa điểm", icon = Icons.Default.Place, onClick = { nav.navigate("locations") })
        MlOutlineBtn("🧍 Tư thế — vẽ/sửa khung xương, nhập từ ảnh/video", icon = Icons.Default.Person, onClick = { nav.navigate("pose_editor") })
        MlOutlineBtn("😀 Biểu cảm — thư viện và bảng từng nhân vật", icon = Icons.Default.Face, onClick = { nav.navigate("expression_studio") })
        MlOutlineBtn("👪 Gia đình — nhân vật cùng họ", icon = Icons.Default.FamilyRestroom, onClick = { nav.navigate("family") })
    }
}

@Composable
fun AppNavBar(nav: androidx.navigation.NavController, current: String) =
    NavigationBar(containerColor = C.S0, tonalElevation = 0.dp) {
        listOf("stories" to (Icons.Default.AutoStories to "Truyện"),
               "characters" to (Icons.Default.People to "Nhân vật"),
               "settings" to (Icons.Default.Settings to "Cài đặt")).forEach { (route, pair) ->
            val (icon, label) = pair
            NavigationBarItem(selected = current == route,
                onClick = { if (current != route) nav.navigate(route) { launchSingleTop = true } },
                icon = { Icon(icon, null) }, label = { Text(label, fontSize = 9.sp) },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = C.Blue, selectedTextColor = C.Blue,
                    unselectedIconColor = C.T3, unselectedTextColor = C.T3, indicatorColor = C.BlueDim))
        }
    }

/**
 * mục 279 — màn cần truyện/chương ĐANG MỞ mà chưa có (chưa chọn, hoặc truyện/chương đang mở vừa bị xoá: MainViewModel gán currentStory = null). Trước đây 4 màn (Gia đình, Bối cảnh,
 * Bố cục trang, Hậu kỳ) chỉ vẽ Text("...") giữa màn trống không lối ra — cùng lỗi "màn trống trơn" đã sửa ở màn Nhân vật (mục 277). [what] = "truyện" hoặc "chương".
 */
@Composable
fun NoContextScreen(what: String, onBack: () -> Unit, onHome: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Chưa mở $what nào", color = C.T1, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text("Màn này cần một $what đang mở. Quay lại, mở một $what rồi vào lại màn này. (Nếu $what vừa bị xoá khi đang xem màn này thì cũng ra màn này.)",
            color = C.T3, fontSize = 12.sp, lineHeight = 16.sp)
        Spacer(Modifier.height(16.dp))
        MlOutlineBtn("← Quay lại", onClick = onBack)
        Spacer(Modifier.height(8.dp))
        MlOutlineBtn("Về danh sách truyện", onClick = onHome, icon = Icons.Default.AutoStories)
    }
}
