package com.mangalocal.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.navigation.NavController
import com.mangalocal.model.*
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharactersDetailScreen(nav: NavController, vm: MainViewModel) {
    val story by vm.currentStory.collectAsState()
    val loras by vm.loras.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var editingChar by remember { mutableStateOf<Character?>(null) }

    var newName by remember { mutableStateOf("") }
    var newAnchor by remember { mutableStateOf("") }
    var newNeg by remember { mutableStateOf("") }
    var newRole by remember { mutableStateOf(CharacterRole.MAIN) }
    var newSeed by remember { mutableStateOf("") }
    var selLora by remember { mutableStateOf<String?>(null) }

    if (story == null) { Box(Modifier.fillMaxSize()) { Text("...", color = C.T3) }; return }
    val chars = story!!.characters

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Nhân vật · ${story!!.title}") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    // mục 114 TECHNICAL_STATUS.md — nút vào FamilyRelationshipScreen
                    // (403 dòng, tính năng lai đặc điểm 2 nhân vật tạo "con" —
                    // FamilyManager.kt), trước đây tồn tại đầy đủ nhưng KHÔNG có
                    // đường vào nào từ UI. Đặt cạnh nút "+" thêm nhân vật vì cùng
                    // nhóm chức năng quản lý nhân vật.
                    IconButton(onClick = { nav.navigate("family") }) {
                        Icon(Icons.Default.FamilyRestroom, null, tint = C.T2)
                    }
                    IconButton(onClick = { showAdd = !showAdd }) {
                    Icon(if (showAdd) Icons.Default.ExpandLess else Icons.Default.Add, null, tint = C.Blue)
                }}, colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("🎯 Phân loại nhân vật", color = C.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("Chính: lưu anchor vĩnh viễn · Phụ: lưu tạm trong chương · Một lần: không lưu",
                            color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                }
            }

            // Ghép cặp LoRA cho nhóm nhân vật (mục 12/14/27 TECHNICAL_STATUS.md
            // — trước đây có API convertAndRegisterPairModel() nhưng KHÔNG có
            // UI nào gọi được, phát hiện khi rà lại toàn bộ việc tồn đọng).
            if (chars.count { it.loraPath != null } >= 2) {
                item {
                    var showPairDialog by remember { mutableStateOf(false) }
                    MlOutlineBtn("🔗 Ghép cặp LoRA cho nhóm nhân vật (nhiều người/panel)",
                        icon = Icons.Default.People, onClick = { showPairDialog = true })
                    if (showPairDialog) {
                        PairConvertDialog(chars.filter { it.loraPath != null }, vm, onDismiss = { showPairDialog = false })
                    }
                }
            }

            listOf(CharacterRole.MAIN to "Nhân vật chính", CharacterRole.SUPPORTING to "Nhân vật phụ",
                CharacterRole.ONETIME to "Xuất hiện một lần").forEach { (role, label) ->
                val list = chars.filter { it.role == role }
                if (list.isNotEmpty()) {
                    item { MlLabel(label + " (${list.size})") }
                    items(list) { c -> CharacterCard(c, onClick = { editingChar = c }, onDelete = { vm.deleteCharacter(c.id) }) }
                }
            }

            if (chars.isEmpty()) item {
                Box(Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                    Text("Chưa có nhân vật. LLM sẽ tự phát hiện khi sinh chương,\nhoặc bạn thêm thủ công.",
                        color = C.T3, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }

            if (showAdd) item {
                MlCard {
                    MlLabel("thêm nhân vật mới")
                    @Composable
                    fun Field(label: String, value: String, hint: String, lines: Int = 1, onChange: (String) -> Unit) {
                        Text(label, color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
                        OutlinedTextField(value = value, onValueChange = onChange,
                            modifier = Modifier.fillMaxWidth().let { if (lines > 1) it.height((lines*26+24).dp) else it },
                            placeholder = { Text(hint, color = C.T3, fontSize = 12.sp) }, singleLine = lines == 1,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                                focusedContainerColor = C.S0, unfocusedContainerColor = C.S0, focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp))
                        Spacer(Modifier.height(10.dp))
                    }
                    Field("Tên *", newName, "vd: Aria") { newName = it }
                    Field("Anchor prompt * (mô tả ngoại hình)", newAnchor,
                        "vd: young woman, long black hair, brown eyes, red jacket", lines = 3) { newAnchor = it }
                    Field("Negative prompt", newNeg, "tùy chọn") { newNeg = it }
                    Field("Seed", newSeed, "để trống = ngẫu nhiên") { newSeed = it }

                    Text("Vai trò", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                        CharacterRole.values().forEach { role ->
                            val sel = newRole == role
                            Surface(onClick = { newRole = role }, color = if (sel) C.BlueDim else C.S0,
                                shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (sel) C.Blue else C.Border)) {
                                Text(when(role) { CharacterRole.MAIN -> "Chính"; CharacterRole.SUPPORTING -> "Phụ"; CharacterRole.ONETIME -> "Một lần" },
                                    color = if (sel) C.Blue else C.T2, fontSize = 12.sp, modifier = Modifier.padding(10.dp, 7.dp))
                            }
                        }
                    }

                    if (loras.isNotEmpty()) {
                        Text("LoRA (tùy chọn)", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                            item {
                                Surface(onClick = { selLora = null }, color = if (selLora == null) C.BlueDim else C.S0,
                                    shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (selLora == null) C.Blue else C.Border)) {
                                    Text("Không", color = if (selLora == null) C.Blue else C.T2, fontSize = 12.sp, modifier = Modifier.padding(10.dp, 7.dp))
                                }
                            }
                            items(loras) { lora ->
                                Surface(onClick = { selLora = lora.path }, color = if (selLora == lora.path) C.BlueDim else C.S0,
                                    shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (selLora == lora.path) C.Blue else C.Border)) {
                                    Text(lora.name.take(18), color = if (selLora == lora.path) C.Blue else C.T2, fontSize = 12.sp, modifier = Modifier.padding(10.dp, 7.dp))
                                }
                            }
                        }
                    }

                    MlBtn("Lưu nhân vật", icon = Icons.Default.PersonAdd,
                        enabled = newName.isNotBlank() && newAnchor.isNotBlank(),
                        onClick = {
                            vm.addCharacter(newName, newAnchor, newNeg, newRole, selLora, newSeed.toLongOrNull())
                            newName = ""; newAnchor = ""; newNeg = ""; newSeed = ""; selLora = null; showAdd = false
                        })
                }
            }
        }
    }

    editingChar?.let { char ->
        EditCharacterDialog(character = char, vm = vm, onDismiss = { editingChar = null })
    }

    // mục 111 TECHNICAL_STATUS.md — CharacterApprovalSheet: đặt ở tầng
    // CharactersDetailScreen (không phải bên trong EditCharacterDialog) vì
    // vm.approvalCharacter là state TOÀN CỤC (generateAnchorCandidates()
    // chạy độc lập với dialog nào đang mở), cần hiện được kể cả nếu dialog
    // sửa nhân vật đã đóng trong lúc chờ AI sinh ảnh.
    val approvalChar by vm.approvalCharacter.collectAsState()
    approvalChar?.let { char ->
        CharacterApprovalSheet(character = char, vm = vm, onDismiss = { vm.dismissApprovalSheet() })
    }

    // mục 161 TECHNICAL_STATUS.md — cùng lý do đặt ở tầng ngoài (state
    // toàn cục, không phụ thuộc dialog sửa nhân vật nào đang mở).
    val versionApprovalChar by vm.versionApprovalCharacter.collectAsState()
    versionApprovalChar?.let { char ->
        CharacterAnchorVersionSheet(character = char, vm = vm, onDismiss = { vm.dismissVersionApprovalSheet() })
    }
}

// mục 161 TECHNICAL_STATUS.md — hỏi user 2 thứ TỐI THIỂU cần trước khi sinh
// ảnh: (1) cái gì đã đổi (mô tả tự nhiên, nối vào anchorPrompt gốc), (2) áp
// dụng từ chương số mấy. Mặc định số chương = chương đang mở (nếu có) — hầu
// hết trường hợp thật (user đang ở đúng chương xảy ra bước ngoặt) không cần
// sửa gì, chỉ gõ mô tả rồi bấm.
@Composable
private fun NewAnchorVersionDialog(
    character: Character, defaultFromChapter: Int,
    onDismiss: () -> Unit, onConfirm: (String, Int, BoneProportions?) -> Unit
) {
    var desc by remember { mutableStateOf("") }
    var chapterText by remember { mutableStateOf(defaultFromChapter.toString()) }
    // mục 161 TECHNICAL_STATUS.md (đợt 2) — 4 lựa chọn: null = KHÔNG đổi tỷ
    // lệ cơ thể (đúng cho sẹo/đổi trang phục, KHÔNG đúng cho "lớn lên"). 3
    // preset còn lại tái dùng NGUYÊN `BoneProportions.presetChild/Teen/Adult`
    // đã có sẵn (mục 121, dùng để build UI BoneProportionsEditor) — không
    // phát minh thang đo mới, tránh 2 nơi định nghĩa "trẻ em là tỷ lệ bao
    // nhiêu" rồi lệch nhau.
    var boneChoice by remember { mutableStateOf(0) } // 0=không đổi,1=trẻ em,2=thiếu niên,3=người lớn
    val boneOptions = listOf(
        "Không đổi" to null,
        "Trẻ em" to BoneProportions.presetChild(),
        "Thiếu niên" to BoneProportions.presetTeen(),
        "Người lớn" to BoneProportions.presetAdult()
    )
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.S1,
        title = { Text("Phiên bản ngoại hình mới — ${character.name}", color = C.T1) },
        text = {
            Column {
                Text(
                    "Mô tả NGẮN cái gì đã đổi vĩnh viễn (sẹo, băng bó, đổi màu tóc, trang phục mới...) — " +
                    "MangaLocal nối mô tả này vào mô tả nhân vật gốc rồi sinh ảnh nháp cho bạn chọn.",
                    color = C.T3, fontSize = 11.sp, lineHeight = 14.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = desc, onValueChange = { desc = it },
                    label = { Text("Ví dụ: có sẹo dài trên má trái") },
                    modifier = Modifier.fillMaxWidth(), maxLines = 3
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = chapterText, onValueChange = { chapterText = it.filter { c -> c.isDigit() } },
                    label = { Text("Áp dụng từ chương số") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                )
                Spacer(Modifier.height(10.dp))
                Text("Nhân vật có lớn lên không? (đổi tỷ lệ đầu/thân — riêng với ảnh, không bắt buộc)",
                    color = C.T2, fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    boneOptions.forEachIndexed { i, (label, _) ->
                        val selected = boneChoice == i
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (selected) C.Blue.copy(alpha = 0.2f) else C.S2,
                            border = BorderStroke(1.dp, if (selected) C.Blue else C.Border),
                            modifier = Modifier.clickable { boneChoice = i }
                        ) {
                            Text(label, color = if (selected) C.Blue else C.T2, fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Panel sinh từ chương $chapterText trở đi sẽ tự dùng ảnh này thay ảnh anchor gốc " +
                    (if (boneChoice != 0) "VÀ tỷ lệ khung xương \"${boneOptions[boneChoice].first}\" " else "") +
                    "— không ảnh hưởng chương trước đó.",
                    color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = desc.isNotBlank() && chapterText.toIntOrNull() != null,
                onClick = { onConfirm(desc, chapterText.toIntOrNull() ?: defaultFromChapter, boneOptions[boneChoice].second) }
            ) { Text("Sinh ảnh nháp", color = C.Blue) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Huỷ", color = C.T3) } }
    )
}

// mục 161 TECHNICAL_STATUS.md — lưới duyệt ảnh, Y HỆT CharacterApprovalSheet
// ở trên (nhân bản có chủ đích — 2 luồng độc lập nhau về state, không đáng
// trừu tượng hoá chung 1 Composable tổng quát cho lợi ích nhỏ, giữ code dễ
// đọc hơn).
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CharacterAnchorVersionSheet(character: Character, vm: MainViewModel, onDismiss: () -> Unit) {
    val candidates by vm.versionApprovalCandidates.collectAsState()
    val isGenerating by vm.isGeneratingVersionCandidates.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.S1,
        title = { Text("Chọn ảnh phiên bản mới cho ${character.name}", color = C.T1) },
        text = {
            Column {
                if (isGenerating) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(color = C.Blue, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Đang sinh ảnh nháp...", color = C.T2, fontSize = 12.sp)
                    }
                } else if (candidates.isEmpty()) {
                    Text("Không sinh được ảnh nào.", color = C.Orange, fontSize = 12.sp)
                } else {
                    Text("Chọn 1 tấm ưng ý nhất — panel từ chương đã chọn trở đi sẽ tự dùng ảnh này.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(10.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.height(340.dp)
                    ) {
                        items(candidates) { path ->
                            Surface(
                                shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, C.Border),
                                modifier = Modifier.fillMaxWidth().aspectRatio(1f).clickable { vm.approveAnchorVersionCandidate(path) }
                            ) {
                                AsyncCharacterImage(path)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!isGenerating) {
                TextButton(onClick = { vm.regenerateAnchorVersionCandidates() }) { Text("Sinh lại 4 bản khác", color = C.Blue) }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Đóng", color = C.T3) } }
    )
}

// mục 111 TECHNICAL_STATUS.md — lưới 4 ảnh nháp AI để user duyệt chọn, đúng
// triết lý "Máy tự động phác thảo, người dùng duyệt chốt" đã đề ra trong
// thêm_sd1_5.txt (trước đây regenerateAnchor() gán thẳng 1 ảnh, bỏ qua bước
// duyệt hoàn toàn).
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CharacterApprovalSheet(character: Character, vm: MainViewModel, onDismiss: () -> Unit) {
    val candidates by vm.approvalCandidates.collectAsState()
    val isGenerating by vm.isGeneratingCandidates.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.S1,
        title = { Text("Chọn khuôn mặt cho ${character.name}", color = C.T1) },
        text = {
            Column {
                if (isGenerating) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(color = C.Blue, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Đang sinh ảnh nháp...", color = C.T2, fontSize = 12.sp)
                    }
                } else if (candidates.isEmpty()) {
                    Text("Không sinh được ảnh nào — kiểm tra anchorPrompt của nhân vật.", color = C.Orange, fontSize = 12.sp)
                } else {
                    Text("Chọn 1 tấm ưng ý nhất — sẽ khoá làm ảnh anchor cố định cho nhân vật này.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(10.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.height(340.dp)
                    ) {
                        items(candidates) { path ->
                            Surface(
                                shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, C.Border),
                                modifier = Modifier.fillMaxWidth().aspectRatio(1f).clickable { vm.approveAnchorCandidate(path) }
                            ) {
                                AsyncCharacterImage(path)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!isGenerating) {
                TextButton(onClick = { vm.generateAnchorCandidates(character) }) { Text("Sinh lại 4 bản khác", color = C.Blue) }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Đóng", color = C.T3) } }
    )
}

@Composable
private fun AsyncCharacterImage(path: String) {
    val bitmap = remember(path) {
        try { android.graphics.BitmapFactory.decodeFile(path)?.asImageBitmap() } catch (e: Exception) { null }
    }
    if (bitmap != null) {
        androidx.compose.foundation.Image(bitmap = bitmap, contentDescription = null,
            contentScale = androidx.compose.ui.layout.ContentScale.Crop, modifier = Modifier.fillMaxSize())
    } else {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("?", color = C.T3, fontSize = 20.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PairConvertDialog(candidates: List<Character>, vm: MainViewModel, onDismiss: () -> Unit) {
    val checkpoints by vm.checkpoints.collectAsState()
    val convertBusy by vm.convertBusy.collectAsState()
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var selCheckpoint by remember { mutableStateOf<String?>(checkpoints.firstOrNull()?.path) }

    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.S1,
        title = { Text("Ghép cặp LoRA", color = C.T1) },
        text = {
            Column {
                Text("Chọn ≥2 nhân vật CÙNG xuất hiện chung 1 panel — merge LoRA của họ vào 1 checkpoint dùng " +
                    "chung, để cả nhóm được neo ngoại hình thay vì chỉ 1 người (xem mục 12 TECHNICAL_STATUS.md — " +
                    "có thể bị rò rỉ đặc điểm giữa 2 người, chưa build-test).",
                    color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                Spacer(Modifier.height(6.dp))
                Text("💡 Giảm rò rỉ đặc điểm (Identity Bleeding): chạy tools/lora_block_weight.py trên PC/Colab " +
                    "cho từng file LoRA TRƯỚC khi đặt vào MangaLocal/loras/ — giảm hệ số layer down_blocks (bố " +
                    "cục/trang phục, dễ tràn nhất), giữ nguyên up_blocks/mid_block (khuôn mặt). Xem mục 28 " +
                    "TECHNICAL_STATUS.md — tuỳ chọn, chưa kiểm chứng mức tối ưu.",
                    color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                Spacer(Modifier.height(10.dp))
                candidates.forEach { c ->
                    Row(Modifier.fillMaxWidth().clickable {
                        selected = if (c.id in selected) selected - c.id else selected + c.id
                    }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = c.id in selected, onCheckedChange = {
                            selected = if (it) selected + c.id else selected - c.id
                        }, colors = CheckboxDefaults.colors(checkedColor = C.Blue))
                        Text(c.name, color = C.T1, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (checkpoints.isEmpty()) {
                    Text("Chưa có checkpoint gốc (.safetensors) trong MangaLocal/models/", color = C.Orange, fontSize = 11.sp)
                } else {
                    Text("Checkpoint gốc:", color = C.T3, fontSize = 10.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(checkpoints) { ck ->
                            FilterChip(selected = selCheckpoint == ck.path, onClick = { selCheckpoint = ck.path },
                                label = { Text(ck.name.take(16), fontSize = 10.sp) })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selected.size >= 2 && selCheckpoint != null && convertBusy == null,
                onClick = {
                    vm.convertCharacterPair(candidates.filter { it.id in selected }, selCheckpoint!!)
                    onDismiss()
                }
            ) { Text(if (convertBusy != null) "Đang convert..." else "Ghép & Convert", color = C.Blue) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy", color = C.T3) } }
    )
}

@Composable
private fun CharacterCard(c: Character, onClick: () -> Unit, onDelete: () -> Unit) {
    MlCard(modifier = Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CharAvatar(c.name, 42.dp)
            Column(Modifier.weight(1f)) {
                Text(c.name, color = C.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("seed ${c.seed}", color = C.T3, fontSize = 11.sp)
                Text(c.anchorPrompt.take(50) + if (c.anchorPrompt.length > 50) "…" else "",
                    color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                RoleChip(c.role)
                Spacer(Modifier.height(6.dp))
                if (c.anchorImagePath != null) MlChip("anchor ✓", C.Green, C.GreenDim)
                Spacer(Modifier.height(6.dp))
                Icon(Icons.Default.Delete, null, tint = C.T3, modifier = Modifier.size(16.dp).clickable(onClick = onDelete))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditCharacterDialog(character: Character, vm: MainViewModel, onDismiss: () -> Unit) {
    var anchor by remember { mutableStateOf(character.anchorPrompt) }
    var seed by remember { mutableStateOf(character.seed.toString()) }
    // mục 110 TECHNICAL_STATUS.md — UI chỉnh tỷ lệ xương (BoneProportions).
    // Trước đây model+logic đã có sẵn (PoseRetargeter đọc field này) nhưng
    // không UI nào set được, mọi nhân vật mãi mãi dùng mặc định 1.0 (người
    // lớn). State cục bộ của dialog, chỉ ghi thật vào Character khi bấm "Lưu".
    var boneProps by remember { mutableStateOf(character.boneProportions) }
    val storyManager = vm.storyManager
    val checkpoints by vm.checkpoints.collectAsState()
    val embeddingSources by vm.embeddingSources.collectAsState()
    val convertBusy by vm.convertBusy.collectAsState()
    val current = storyManager.currentConsistencyMethod(character)
    val suggested = storyManager.suggestConsistencyMethod(character.role)
    var selCheckpoint by remember { mutableStateOf<String?>(checkpoints.firstOrNull()?.path) }
    var selLoraFile by remember { mutableStateOf<String?>(null) }
    var selEmbeddingSource by remember { mutableStateOf<String?>(null) }

    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.setCharacterAnchorImage(character, it) }
    }
    val pickEmbeddingLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.setCharacterEmbeddingFromUri(character, it) }
    }

    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.S1,
        title = { Text("Sửa: ${character.name}", color = C.T1) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(value = anchor, onValueChange = { anchor = it },
                    label = { Text("Anchor prompt") }, modifier = Modifier.fillMaxWidth().height(90.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
                Spacer(Modifier.height(8.dp))
                // mục 114 TECHNICAL_STATUS.md — bàn phím số + lọc ký tự: trước
                // đây dùng bàn phím chữ mặc định (chậm hơn nhiều khi nhập seed
                // dài trên di động) và không lọc gì (user gõ nhầm chữ sẽ khiến
                // toLongOrNull() ở nút Lưu âm thầm bỏ qua, seed KHÔNG đổi mà
                // không có cảnh báo nào — dễ gây hiểu lầm "đã lưu" trong khi
                // chưa). Cho phép dấu "-" ở đầu (seed âm hợp lệ) + tối đa 19
                // chữ số (biên Long.MAX_VALUE, không cần validate range chặt
                // hơn — toLongOrNull() ở nơi dùng đã tự chặn overflow).
                OutlinedTextField(value = seed, onValueChange = { new ->
                    val filtered = new.filterIndexed { i, c -> c.isDigit() || (c == '-' && i == 0) }
                    seed = filtered
                },
                    label = { Text("Seed") }, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))

                Spacer(Modifier.height(16.dp))
                Divider(color = C.Border)
                Spacer(Modifier.height(10.dp))

                // Gợi ý theo vai trò (mục 13 TECHNICAL_STATUS.md) — CHỈ GỢI Ý,
                // không tự ép. Vai trò của nhân vật này đang là ${character.role}.
                Text("Phương pháp nhất quán — vai trò \"${roleLabel(character.role)}\" → gợi ý ${methodLabel(suggested)}" +
                    (if (current == suggested) " (đang dùng đúng gợi ý)" else if (current != ConsistencyMethod.NONE) " (đang dùng ${methodLabel(current)}, khác gợi ý — không sao)" else ""),
                    color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                Spacer(Modifier.height(8.dp))

                // ── LoRA ──────────────────────────────────────────────
                MethodSection(
                    title = "① LoRA (~90-100%* — cần train sẵn trên PC + convert, tốn thời gian nhất)",
                    active = current == ConsistencyMethod.LORA
                ) {
                    val loraList by vm.loras.collectAsState()
                    if (checkpoints.isEmpty()) {
                        Text("Chưa có checkpoint gốc (.safetensors) trong MangaLocal/models/", color = C.Orange, fontSize = 11.sp)
                    } else if (loraList.isEmpty()) {
                        Text("Chưa có file LoRA (.safetensors) trong MangaLocal/loras/", color = C.Orange, fontSize = 11.sp)
                    } else {
                        Text("Checkpoint gốc:", color = C.T3, fontSize = 10.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(checkpoints) { ck ->
                                FilterChip(selected = selCheckpoint == ck.path, onClick = { selCheckpoint = ck.path },
                                    label = { Text(ck.name.take(16), fontSize = 10.sp) })
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("File LoRA nhân vật:", color = C.T3, fontSize = 10.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(loraList) { lr ->
                                FilterChip(selected = selLoraFile == lr.path, onClick = { selLoraFile = lr.path },
                                    label = { Text(lr.name.take(16), fontSize = 10.sp) })
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        MlBtn(if (convertBusy == character.name) "Đang convert..." else "Convert & dùng LoRA này",
                            icon = Icons.Default.Build,
                            enabled = selCheckpoint != null && selLoraFile != null && convertBusy == null,
                            onClick = { vm.convertCharacterLora(character, selCheckpoint!!, selLoraFile!!) })
                    }
                }

                Spacer(Modifier.height(10.dp))
                // ── IP-Adapter ────────────────────────────────────────
                MethodSection(
                    title = "② IP-Adapter (~80-90%* — chỉ cần 1 ảnh, không cần train)",
                    active = current == ConsistencyMethod.IP_ADAPTER
                ) {
                    if (character.anchorImagePath != null) {
                        Text("Đã có ảnh anchor ✓ (${File(character.anchorImagePath).name})", color = C.Green, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    MlOutlineBtn(if (character.anchorImagePath != null) "Đổi ảnh khác" else "Chọn ảnh nhân vật",
                        icon = Icons.Default.Image,
                        onClick = { pickImageLauncher.launch(arrayOf("image/*")) })

                    // mục 102 TECHNICAL_STATUS.md — thay thế/tạo ảnh anchor
                    // bằng AI (txt2img từ anchorPrompt) thay vì tự chọn ảnh
                    // — dành cho người không có sẵn ảnh tham chiếu. BẢN ĐƠN
                    // GIẢN HOÁ so với ý tưởng gốc mục 14 (gốc: sinh 3-4 bản
                    // cho chọn — đây chỉ 1 bản/lần, bấm lại để thử bản khác
                    // do seed nhân vật thường cố định giữa các lần gọi).
                    Spacer(Modifier.height(6.dp))
                    // mục 111 TECHNICAL_STATUS.md — CharacterApprovalSheet:
                    // "Máy tự động phác thảo, người dùng duyệt chốt" — sinh
                    // 4 biến thể cho user chọn thay vì gán thẳng 1 ảnh AI
                    // (nút regenerateAnchor() cũ vẫn giữ nguyên bên dưới cho
                    // ai muốn tạo nhanh 1 ảnh không cần duyệt).
                    val isGeneratingCandidates by vm.isGeneratingCandidates.collectAsState()
                    MlOutlineBtn(
                        if (isGeneratingCandidates) "Đang sinh 4 bản nháp (có thể mất 1-2 phút)..."
                        else "Tạo 4 bản nháp bằng AI để duyệt chọn",
                        icon = Icons.Default.GridView,
                        enabled = !isGeneratingCandidates,
                        onClick = { vm.generateAnchorCandidates(character) }
                    )
                    Spacer(Modifier.height(6.dp))
                    val isGeneratingAnchor by vm.isGeneratingAnchor.collectAsState()
                    MlOutlineBtn(
                        if (isGeneratingAnchor) "Đang tạo (có thể mất vài chục giây)..."
                        else if (character.anchorImagePath != null) "Tạo nhanh 1 ảnh (không duyệt, thay ảnh hiện tại)" else "Tạo nhanh 1 ảnh (không duyệt)",
                        icon = Icons.Default.Image,
                        enabled = !isGeneratingAnchor,
                        onClick = { vm.regenerateAnchor(character) }
                    )
                    Text(
                        "Dịch mô tả nhân vật (bên dưới) qua LLM rồi sinh ảnh — không cần ảnh thật, nhưng " +
                        "kết quả kém nhất quán hơn ảnh thật do bạn tự chọn.",
                        color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
                    )

                    // mục 95 TECHNICAL_STATUS.md — tự động tạo ảnh tham
                    // chiếu "áo rách" bằng img2img từ chính anchorImagePath,
                    // dùng cho panel hành động (action_category="combat",
                    // mục 86) thay vì ảnh anchor thường — CHỈ hiện khi đã có
                    // anchorImagePath (không có gì để img2img từ đó nếu chưa).
                    if (character.anchorImagePath != null) {
                        Spacer(Modifier.height(10.dp))
                        Divider(color = C.Border)
                        Spacer(Modifier.height(10.dp))
                        Text("Ảnh tham chiếu cho cảnh hành động (mục 95)", color = C.T2, fontSize = 11.sp)
                        Text(
                            "Tự sinh 1 ảnh biến thể \"vừa vật lộn/chiến đấu\" (áo xộc xệch/rách nhẹ) từ ảnh " +
                            "anchor hiện tại — MangaLocal tự dùng ảnh này thay ảnh anchor thường cho panel có " +
                            "action_category=\"combat\", không cần chỉnh gì thêm.",
                            color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        if (character.tornAnchorImagePath != null) {
                            Text("Đã có ảnh biến thể ✓ (${File(character.tornAnchorImagePath).name})", color = C.Green, fontSize = 11.sp)
                            Spacer(Modifier.height(4.dp))
                        }
                        val isGeneratingTorn by vm.isGeneratingTornReference.collectAsState()
                        MlOutlineBtn(
                            if (isGeneratingTorn) "Đang tạo (có thể mất vài chục giây)..."
                            else if (character.tornAnchorImagePath != null) "Tạo lại ảnh biến thể" else "Tạo ảnh biến thể tự động",
                            icon = Icons.Default.Image,
                            enabled = !isGeneratingTorn,
                            onClick = { vm.generateTornReferenceImage(character) }
                        )

                        // mục 161 TECHNICAL_STATUS.md — Dynamic Identity
                        // Bootstrap: KHÁC ảnh biến thể ở trên (tạm thời,
                        // theo action_category từng panel) — đây là ảnh
                        // thay thế LÂU DÀI theo mốc chương (bị sẹo, lớn
                        // lên, hắc hoá...). Kích hoạt THỦ CÔNG — xem lý do
                        // ở comment `Character.anchorVersions` (Models.kt).
                        Spacer(Modifier.height(10.dp))
                        Divider(color = C.Border)
                        Spacer(Modifier.height(10.dp))
                        Text("Phiên bản ngoại hình theo chương (mục 161)", color = C.T2, fontSize = 11.sp)
                        Text(
                            "Khi nhân vật đổi ngoại hình VĨNH VIỄN theo cốt truyện (sẹo, trưởng thành...), " +
                            "tạo 1 ảnh mới và chọn áp dụng từ chương nào — panel từ chương đó trở đi tự dùng " +
                            "ảnh mới, chương trước đó không đổi gì.",
                            color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        if (character.anchorVersions.isNotEmpty()) {
                            character.anchorVersions.sortedBy { it.fromChapterNumber }.forEach { v ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        "Từ chương ${v.fromChapterNumber}" +
                                        (if (v.label.isNotBlank()) ": ${v.label.take(30)}" else "") +
                                        (if (v.boneProportionsOverride != null) " 📏" else ""),
                                        color = C.Green, fontSize = 11.sp, modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = { vm.deleteAnchorVersion(character, v.fromChapterNumber) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Xoá", tint = C.T3, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                        }
                        var showNewVersionDialog by remember { mutableStateOf(false) }
                        MlOutlineBtn(
                            "Tạo phiên bản ngoại hình mới", icon = Icons.Default.Image,
                            onClick = { showNewVersionDialog = true }
                        )
                        if (showNewVersionDialog) {
                            val currentChapterNum by vm.currentChapter.collectAsState()
                            NewAnchorVersionDialog(
                                character = character,
                                defaultFromChapter = currentChapterNum?.chapterNumber ?: 1,
                                onDismiss = { showNewVersionDialog = false },
                                onConfirm = { desc, fromChapter, boneOverride ->
                                    vm.generateAnchorVersionCandidates(character, desc, fromChapter, boneOverride)
                                    showNewVersionDialog = false
                                }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                // ── Textual Inversion ─────────────────────────────────
                MethodSection(
                    title = "③ Textual Inversion (~40-65%* — nhẹ nhất, ghép nhiều người/panel thoải mái, KHÔNG bị giới hạn 1 người/panel như ②)",
                    active = current == ConsistencyMethod.TEXTUAL_INVERSION
                ) {
                    if (character.embeddingTrigger != null) {
                        Text("Trigger word: \"${character.embeddingTrigger}\" ✓", color = C.Green, fontSize = 11.sp)
                        Spacer(Modifier.height(4.dp))
                    }
                    if (embeddingSources.isNotEmpty()) {
                        Text("Chọn từ MangaLocal/embeddings_source/:", color = C.T3, fontSize = 10.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(embeddingSources) { es ->
                                FilterChip(selected = selEmbeddingSource == es.path, onClick = {
                                    selEmbeddingSource = es.path
                                    vm.setCharacterEmbeddingFromSource(character, es.path)
                                }, label = { Text(es.name.take(16), fontSize = 10.sp) })
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    MlOutlineBtn("Hoặc chọn file .safetensors khác", icon = Icons.Default.FileOpen,
                        onClick = { pickEmbeddingLauncher.launch(arrayOf("*/*")) })
                }

                Spacer(Modifier.height(10.dp))
                if (current != ConsistencyMethod.NONE) {
                    TextButton(onClick = { vm.clearConsistencyMethod(character) }) {
                        Text("④ Bỏ hết, chỉ dùng mô tả chữ (Không)", color = C.T3, fontSize = 12.sp)
                    }
                }

                Spacer(Modifier.height(16.dp))
                Divider(color = C.Border)
                Spacer(Modifier.height(10.dp))
                BoneProportionsEditor(value = boneProps, onChange = { boneProps = it })

                Spacer(Modifier.height(4.dp))
                Text("* % là ước lượng CHUNG của cộng đồng SD, KHÔNG PHẢI đo trên chính app này " +
                    "— chưa build-test thật để biết số liệu chính xác.", color = C.T3, fontSize = 9.sp, lineHeight = 12.sp)

                Spacer(Modifier.height(10.dp))
                if (character.anchorImagePath != null) {
                    Text("Ảnh anchor hiện tại đã lưu", color = C.Green, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.updateCharacter(character.copy(anchorPrompt = anchor, seed = seed.toLongOrNull() ?: character.seed,
                    boneProportions = boneProps))
                onDismiss()
            }) { Text("Lưu", color = C.Blue) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy", color = C.T3) } }
    )
}

// mục 110 TECHNICAL_STATUS.md — 3 preset nhanh (Trẻ em/Thiếu niên/Người
// lớn) + 6 slider chi tiết. Preset chỉ là điểm khởi đầu (ghi rõ trong
// comment BoneProportions.kt là KHÔNG PHẢI số liệu y văn đã kiểm chứng),
// user tự chỉnh tiếp bằng slider sau khi bấm preset nếu muốn.
// mục 159 TECHNICAL_STATUS.md — Build #97: thiếu @OptIn cho FilterChip
// (@ExperimentalMaterial3Api) — lỗi build thật, không phải warning.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BoneProportionsEditor(value: BoneProportions, onChange: (BoneProportions) -> Unit) {
    var expanded by remember { mutableStateOf(value != BoneProportions()) }
    Column {
        Row(Modifier.fillMaxWidth().clickable { expanded = !expanded },
            verticalAlignment = Alignment.CenterVertically) {
            Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = C.T2)
            Spacer(Modifier.width(6.dp))
            Text("Tỷ lệ xương (trẻ em / thiếu niên / người lớn)", color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        if (!expanded) return@Column
        Spacer(Modifier.height(6.dp))
        Text(
            "Ảnh hưởng tới CCD-IK/PoseRetargeter khi retarget khung xương sang nhân vật này " +
            "(sải tay/chân ngắn hơn người lớn sẽ chạm đúng vị trí thay vì hụt). 3 preset dưới đây " +
            "CHỈ là điểm khởi đầu tham khảo nhanh, không phải số liệu y văn đã kiểm chứng — " +
            "tự chỉnh slider bên dưới nếu cần chính xác hơn.",
            color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = value == BoneProportions.presetChild(), onClick = { onChange(BoneProportions.presetChild()) },
                label = { Text("Trẻ em", fontSize = 11.sp) })
            FilterChip(selected = value == BoneProportions.presetTeen(), onClick = { onChange(BoneProportions.presetTeen()) },
                label = { Text("Thiếu niên", fontSize = 11.sp) })
            FilterChip(selected = value == BoneProportions.presetAdult(), onClick = { onChange(BoneProportions.presetAdult()) },
                label = { Text("Người lớn (mặc định)", fontSize = 11.sp) })
        }
        Spacer(Modifier.height(10.dp))
        BoneRatioSlider("Thân (cổ → hông)", value.torsoRatio) { onChange(value.copy(torsoRatio = it)) }
        BoneRatioSlider("Cánh tay trên (vai → khuỷu)", value.upperArmRatio) { onChange(value.copy(upperArmRatio = it)) }
        BoneRatioSlider("Cẳng tay (khuỷu → cổ tay)", value.forearmRatio) { onChange(value.copy(forearmRatio = it)) }
        BoneRatioSlider("Đùi (hông → gối)", value.upperLegRatio) { onChange(value.copy(upperLegRatio = it)) }
        BoneRatioSlider("Cẳng chân (gối → mắt cá)", value.lowerLegRatio) { onChange(value.copy(lowerLegRatio = it)) }
        BoneRatioSlider("Kích thước đầu (ước lượng)", value.headSizeRatio, range = 0.7f..1.5f) { onChange(value.copy(headSizeRatio = it)) }
        if (value != BoneProportions()) {
            Spacer(Modifier.height(4.dp))
            TextButton(onClick = { onChange(BoneProportions()) }) {
                Text("Đặt lại về mặc định (1.0 mọi mặt)", color = C.T3, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun BoneRatioSlider(label: String, v: Float, range: ClosedFloatingPointRange<Float> = 0.6f..1.3f, onValueChange: (Float) -> Unit) {
    Column(Modifier.padding(vertical = 2.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = C.T2, fontSize = 11.sp)
            Text("%.2f".format(v), color = C.T1, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(value = v, onValueChange = onValueChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue))
    }
}

@Composable
private fun MethodSection(title: String, active: Boolean, content: @Composable ColumnScope.() -> Unit) {
    Surface(color = if (active) C.GreenDim else C.S0, shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (active) C.Green else C.Border)) {
        Column(Modifier.padding(10.dp)) {
            Text(title, color = if (active) C.Green else C.T2, fontSize = 11.sp, lineHeight = 14.sp,
                fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            content()
        }
    }
}

private fun roleLabel(r: CharacterRole) = when (r) {
    CharacterRole.MAIN -> "Chính (xuất hiện nhiều)"
    CharacterRole.SUPPORTING -> "Phụ (xuất hiện trung bình)"
    CharacterRole.ONETIME -> "Một lần / qua đường"
}
private fun methodLabel(m: ConsistencyMethod) = when (m) {
    ConsistencyMethod.LORA -> "① LoRA"
    ConsistencyMethod.IP_ADAPTER -> "② IP-Adapter"
    ConsistencyMethod.TEXTUAL_INVERSION -> "③ Textual Inversion"
    ConsistencyMethod.NONE -> "④ Không dùng (chỉ mô tả chữ)"
}
