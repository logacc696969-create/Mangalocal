package com.mangalocal.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mangalocal.model.GenerationBackend

/**
 * Duyệt lại lần cuối routing local/remote cho TỪNG panel TRƯỚC KHI sinh ảnh
 * thật — theo đúng yêu cầu: kịch bản (mô tả/thoại từng panel) đã được LLM
 * viết xong và CỐ ĐỊNH ở bước trước (MangaPipeline.prepareChapter) — màn
 * hình này chỉ đổi PANEL NÀO chạy ở đâu (local/remote), KHÔNG đổi lại nội
 * dung truyện chút nào, nên dù bạn đánh dấu 1 nhóm panel chạy remote (có
 * thể xong không theo đúng thứ tự do độ trễ mạng) rồi kết hợp lại với các
 * panel chạy local, KHÔNG có chuyện lẫn lộn logic truyện — panel nào vẫn
 * đúng nội dung/thoại của panel đó, và lúc ráp thành chương cuối cùng luôn
 * xếp lại theo đúng index gốc (panel_%03d), không theo thứ tự xong trước/sau.
 */
@OptIn(ExperimentalMaterial3Api::class)
// mục 159 TECHNICAL_STATUS.md — Build #97: thiếu @OptIn cho FilterChip
// (@ExperimentalMaterial3Api) — lỗi build thật, không phải warning.
@Composable
fun RoutingReviewScreen(nav: NavController, vm: MainViewModel) {
    val chapter by vm.pendingChapter.collectAsState()
    val settings by vm.settings.collectAsState()
    val selected = remember { mutableStateListOf<Int>() }

    if (chapter == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = C.Blue)
                Spacer(Modifier.height(12.dp))
                Text("Đang phân tích kịch bản...", color = C.T2, fontSize = 13.sp)
            }
        }
        return
    }
    val ch = chapter!!
    val localCount = ch.panels.count { it.overrideSettings?.backendOverride == GenerationBackend.LOCAL }
    val remoteCount = ch.panels.count { it.overrideSettings?.backendOverride == GenerationBackend.REMOTE }
    val remoteNotReady = remoteCount > 0 && !settings.remoteEndpoint.enabled

    Column(Modifier.fillMaxSize().background(C.Bg)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.cancelPendingChapter(); nav.popBackStack() }) {
                Icon(Icons.Default.ArrowBack, "Quay lại", tint = C.T1)
            }
            Spacer(Modifier.width(4.dp))
            Column {
                Text("Duyệt routing trước khi sinh ảnh", color = C.T1, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("${ch.panels.size} panel · $localCount local · $remoteCount remote", color = C.T3, fontSize = 12.sp)
            }
        }

        if (remoteNotReady) {
            Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = C.OrangeDim,
                shape = RoundedCornerShape(10.dp)) {
                Text("⚠ Có panel đánh dấu Remote nhưng Remote GPU đang tắt (Cài đặt) — bật lên hoặc đổi các panel này về Local trước khi sinh.",
                    color = C.Orange, fontSize = 11.sp, modifier = Modifier.padding(10.dp))
            }
            Spacer(Modifier.height(8.dp))
        }

        // Thanh thao tác hàng loạt — đúng yêu cầu "đánh dấu batch local để
        // chạy hàng loạt ở local, còn lại chạy hàng loạt remote".
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MlOutlineBtn(
                text = if (selected.size == ch.panels.size) "Bỏ chọn hết" else "Chọn hết",
                onClick = {
                    if (selected.size == ch.panels.size) selected.clear()
                    else { selected.clear(); selected.addAll(ch.panels.map { it.index }) }
                },
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MlBtn("📱 Đánh dấu đã chọn: Local", enabled = selected.isNotEmpty(),
                onClick = { vm.setBatchBackend(selected.toSet(), GenerationBackend.LOCAL); selected.clear() },
                modifier = Modifier.weight(1f))
            MlBtn("☁️ Đánh dấu đã chọn: Remote", enabled = selected.isNotEmpty(),
                onClick = { vm.setBatchBackend(selected.toSet(), GenerationBackend.REMOTE); selected.clear() },
                modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))

        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ch.panels, key = { it.index }) { panel ->
                val backend = panel.overrideSettings?.backendOverride ?: GenerationBackend.LOCAL
                val isSelected = panel.index in selected
                Surface(
                    color = C.S1, shape = RoundedCornerShape(10.dp),
                    border = if (isSelected) BorderStroke(1.5.dp, C.Blue) else BorderStroke(1.dp, C.Border),
                    onClick = { if (isSelected) selected.remove(panel.index) else selected.add(panel.index) }
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isSelected, onCheckedChange = {
                            if (it) selected.add(panel.index) else selected.remove(panel.index)
                        }, colors = CheckboxDefaults.colors(checkedColor = C.Blue))
                        Spacer(Modifier.width(4.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Panel ${panel.index + 1}", color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text(panel.scene.description.take(70), color = C.T2, fontSize = 12.sp, maxLines = 2)
                            Spacer(Modifier.height(2.dp))
                            Text(panel.routingReason, color = C.T3, fontSize = 10.sp, maxLines = 1)
                        }
                        Spacer(Modifier.width(8.dp))
                        // Chip đổi nhanh 1 panel riêng lẻ, không cần qua batch nếu chỉ sửa 1 cái
                        FilterChip(
                            selected = backend == GenerationBackend.REMOTE,
                            onClick = {
                                val next = if (backend == GenerationBackend.LOCAL) GenerationBackend.REMOTE else GenerationBackend.LOCAL
                                vm.setBatchBackend(setOf(panel.index), next)
                            },
                            label = { Text(if (backend == GenerationBackend.LOCAL) "Local" else "Remote", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = C.OrangeDim, selectedLabelColor = C.Orange,
                                containerColor = C.S2, labelColor = C.T2
                            )
                        )
                    }
                }
            }
            item { Spacer(Modifier.height(80.dp)) }
        }

        Surface(Modifier.fillMaxWidth(), color = C.S0, shadowElevation = 8.dp) {
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MlOutlineBtn("Huỷ", onClick = { vm.cancelPendingChapter(); nav.popBackStack() }, modifier = Modifier.weight(1f))
                MlBtn("✓ Xác nhận, sinh ảnh", enabled = !remoteNotReady,
                    onClick = { vm.confirmRoutingAndGenerate() }, modifier = Modifier.weight(1f))
            }
        }
    }
}
