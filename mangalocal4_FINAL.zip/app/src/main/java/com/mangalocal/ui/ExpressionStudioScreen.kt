@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mangalocal.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mangalocal.model.Character
import com.mangalocal.model.Panel
import com.mangalocal.model.PromptStyle
import com.mangalocal.pipeline.ExpressionLibrary
import com.mangalocal.pipeline.ExpressionPreset
import com.mangalocal.pipeline.ExpressionRegistry
import com.mangalocal.pipeline.ExpressionVocab
import com.mangalocal.pipeline.LLMParser
import com.mangalocal.pipeline.VideoTarget

// mục 240 TECHNICAL_STATUS.md — MÀN HÌNH QUẢN LÝ BIỂU CẢM / DIỄN XUẤT TẬP TRUNG (cùng vai trò thư viện tư thế
// khung xương cho phần "linh hồn" của ảnh). Ba tab:
//   1. Thư viện: xem 12 nhãn gốc + biểu cảm dựng sẵn mở rộng + tự tạo biểu cảm từ THÀNH PHẦN (mày/mắt/miệng/chi tiết
//      phụ/hướng nhìn/nghiêng đầu/cường độ), xem trước prompt ngay khi chỉnh.
//   2. Dàn diễn viên: "bảng biểu cảm" từng nhân vật — ảnh anchor được vẽ lại MẶT với biểu cảm khác, dùng làm ảnh tham
//      chiếu IP-Adapter khi panel yêu cầu đúng biểu cảm đó.
//   3. Diễn biến: biểu cảm từng nhân vật theo từng panel của chương đang mở, sửa tay + chép sang các panel sau.
// GIỚI HẠN THẬT: tab 2 cần anchor có mặt nhìn rõ và model YOLOv8-pose; ảnh biểu cảm vẽ bằng img2img không có IP-Adapter
// nên có thể lệch nhẹ khuôn mặt — xem ảnh rồi xoá nếu không đạt. CHƯA build-test, chưa có ảnh thật.

private fun effectiveKey(panel: Panel, name: String): String =
    (panel.scene.characterExpressions + (panel.overrideSettings?.characterExpressionOverrides ?: emptyMap()))[name]
        ?: panel.scene.expression ?: "neutral"

private fun hasManualOverride(panel: Panel, name: String): Boolean =
    panel.overrideSettings?.characterExpressionOverrides?.containsKey(name) == true

@Composable
private fun SheetThumb(path: String?, size: Int = 56) {
    val bitmap = remember(path) {
        if (path == null) null
        else try { android.graphics.BitmapFactory.decodeFile(path)?.asImageBitmap() } catch (e: Exception) { null }
    }
    Box(Modifier.size(size.dp).clip(RoundedCornerShape(8.dp)).background(C.S2), contentAlignment = Alignment.Center) {
        if (bitmap != null) Image(bitmap = bitmap, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Icon(Icons.Default.Image, null, tint = C.T3, modifier = Modifier.size(22.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpressionStudioScreen(nav: NavController, vm: MainViewModel) {
    var tab by remember { mutableStateOf(0) }
    val titles = listOf("Thư viện", "Dàn diễn viên", "Diễn biến", "Kiểm tra & biến thể")
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Biểu cảm & diễn xuất") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        containerColor = C.Bg
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = tab, containerColor = C.S0) {
                titles.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 12.sp) }) }
            }
            when (tab) {
                0 -> ExpressionLibraryTab(vm)
                1 -> ExpressionCastTab(vm)
                2 -> ExpressionTimelineTab(vm)
                else -> VideoReadyTab(vm)
            }
        }
    }
}

// ─────────────────────────────────────────────── Tab 1: Thư viện ───────────────────────────────────────────────

@Composable
private fun ExpressionLibraryTab(vm: MainViewModel) {
    val custom by vm.expressionPresets.collectAsState()
    val appSettings by vm.settings.collectAsState()
    val realistic = appSettings.imageStyle == com.mangalocal.model.ImageStyle.REALISTIC
    var editing by remember { mutableStateOf<ExpressionPreset?>(null) }
    var confirmDelete by remember { mutableStateOf<ExpressionPreset?>(null) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                Column(Modifier.padding(12.dp)) {
                    Text("🎭 Thư viện biểu cảm", color = C.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Biểu cảm được ghép từ thành phần nhỏ (lông mày, mắt, miệng, chi tiết phụ, hướng nhìn, nghiêng đầu) và cường độ — " +
                        "cùng cách cộng đồng ghép tag mặt cho SD1.5/SDXL. LLM sẽ chọn trong các biểu cảm dựng sẵn; biểu cảm bạn tự tạo " +
                        "dùng được ở màn hình Diễn biến và chỉnh từng panel.", color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(if (realistic)
                        "Bộ từ vựng đang dùng: ẢNH THỰC — mô tả giải phẫu cơ mặt (vd \"furrowed brows, clenched teeth and a tense jaw\"), không dùng tag riêng của anime. " +
                        "Đổi \"Phong cách ảnh\" trong Cài đặt sang Anime/Manga để dùng tag danbooru."
                    else
                        "Bộ từ vựng đang dùng: ANIME/MANGA — tag danbooru đã đối chiếu wiki. Chọn phong cách \"Siêu thực\" trong Cài đặt để chuyển sang mô tả giải phẫu cho ảnh thực.",
                        color = C.Green, fontSize = 10.sp, lineHeight = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Bộ từ vựng:", color = C.T2, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("AUTO" to "Tự động", "ANATOMICAL" to "Giải phẫu", "BOORU" to "Tag booru").forEach { (mode, label) ->
                            FilterChip(selected = appSettings.expressionVocabulary == mode,
                                onClick = { vm.updateSettings { copy(expressionVocabulary = mode) } },
                                label = { Text(label, fontSize = 11.sp) })
                        }
                    }
                    Text("Checkpoint có hiểu tag booru hay không tuỳ cách nó được huấn luyện, không chỉ ảnh thực/anime. Dùng nút \"So sánh\" ở tab Dàn diễn viên " +
                        "để xem checkpoint của bạn hiểu bộ nào tốt hơn.", color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Giới hạn thật: chưa đo trên checkpoint nào cụ thể; cả hai bộ từ vựng đều cần thử và chỉnh theo checkpoint của bạn.",
                        color = C.Orange, fontSize = 10.sp, lineHeight = 14.sp)
                }
            }
        }
        item {
            Button(onClick = { editing = ExpressionPreset(id = ExpressionRegistry.newCustomId(), name = "", lead = "") },
                colors = ButtonDefaults.buttonColors(containerColor = C.Blue), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Tạo biểu cảm mới")
            }
        }
        if (custom.isNotEmpty()) {
            item { Text("Của bạn (${custom.size})", color = C.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            items(custom, key = { it.id }) { p ->
                PresetCard(p, realistic, onEdit = { editing = p }, onDelete = { confirmDelete = p })
            }
        }
        item { Text("Dựng sẵn mở rộng (${ExpressionLibrary.EXTENDED_BUILTINS.size})", color = C.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        items(ExpressionLibrary.EXTENDED_BUILTINS, key = { it.id }) { p ->
            PresetCard(p, realistic, onEdit = { editing = p.copy(id = ExpressionRegistry.newCustomId(), name = p.name + " (bản của tôi)", builtIn = false) }, onDelete = null)
        }
        item { Text("Nhãn gốc (12)", color = C.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        items(LLMParser.VALID_EXPRESSIONS.filter { ExpressionLibrary.baseLabel(it) != null }, key = { "base_$it" }) { key ->
            Surface(color = C.S1, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, C.Border)) {
                Row(Modifier.padding(10.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${ExpressionLibrary.baseLabel(key)}  ·  $key", color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text(LLMParser.resolveExpressionTag(key, PromptStyle.TAG_BASED).orEmpty(), color = C.T3, fontSize = 10.sp)
                    }
                    // Nhãn gốc là chuỗi viết tay nên không sửa trực tiếp; "nhân bản" mở bản dựng theo thành phần (xấp xỉ) để tinh chỉnh.
                    ExpressionLibrary.BASE_CLONES[key]?.let { clone ->
                        IconButton(onClick = { editing = clone.copy(id = ExpressionRegistry.newCustomId(), name = clone.name + " (bản của tôi)", builtIn = false) }) {
                            Icon(Icons.Default.ContentCopy, "Nhân bản để chỉnh", tint = C.T2)
                        }
                    }
                }
            }
        }
    }

    editing?.let { cur ->
        PresetEditorDialog(initial = cur, onDismiss = { editing = null },
            onSave = { vm.saveExpressionPreset(it); editing = null })
    }
    confirmDelete?.let { p ->
        AlertDialog(onDismissRequest = { confirmDelete = null },
            title = { Text("Xoá biểu cảm \"${p.name}\"?") },
            text = { Text("Panel đang dùng biểu cảm này sẽ quay về nhãn mặc định của LLM khi sinh lại.") },
            confirmButton = { TextButton(onClick = { vm.deleteExpressionPreset(p.id); confirmDelete = null }) { Text("Xoá", color = C.Red) } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Huỷ") } })
    }
}

@Composable
private fun PresetCard(p: ExpressionPreset, realistic: Boolean, onEdit: () -> Unit, onDelete: (() -> Unit)?) {
    Surface(color = C.S1, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, C.Border)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(p.name.ifBlank { "(chưa đặt tên)" } + "  ·  cường độ ${p.intensity}/3", color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(ExpressionLibrary.compose(p, PromptStyle.TAG_BASED, realistic), color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
            }
            IconButton(onClick = onEdit) { Icon(if (p.builtIn) Icons.Default.ContentCopy else Icons.Default.Edit, null, tint = C.T2) }
            if (onDelete != null) IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = C.Red) }
        }
    }
}

@Composable
private fun PartChips(title: String, parts: List<ExpressionVocab.Part>, selected: String?, onPick: (String?) -> Unit) {
    Text(title, color = C.T2, fontSize = 11.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        FilterChip(selected = selected == null, onClick = { onPick(null) }, label = { Text("Không", fontSize = 10.sp) })
        parts.forEach { part ->
            FilterChip(selected = selected == part.key, onClick = { onPick(part.key) },
                label = { Text(part.label + if (part.verified) "" else " *", fontSize = 10.sp) })
        }
    }
}

@Composable
private fun PresetEditorDialog(initial: ExpressionPreset, onDismiss: () -> Unit, onSave: (ExpressionPreset) -> Unit) {
    var name by remember { mutableStateOf(initial.name) }
    var lead by remember { mutableStateOf(initial.lead) }
    var brows by remember { mutableStateOf(initial.brows) }
    var eyes by remember { mutableStateOf(initial.eyes) }
    var mouth by remember { mutableStateOf(initial.mouth) }
    var extras by remember { mutableStateOf(initial.extras.orEmpty()) }
    var gaze by remember { mutableStateOf(initial.gaze) }
    var head by remember { mutableStateOf(initial.head) }
    var intensity by remember { mutableStateOf(initial.intensity) }

    val draft = initial.copy(name = name.trim(), lead = lead.trim(), brows = brows, eyes = eyes, mouth = mouth,
        extras = extras, gaze = gaze, head = head, intensity = intensity)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.name.isBlank()) "Biểu cảm mới" else "Sửa biểu cảm") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Tên (tiếng Việt)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = lead, onValueChange = { lead = it },
                    label = { Text("Cụm tiếng Anh mô tả chính, vd: pained expression") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                PartChips("Lông mày", ExpressionVocab.BROWS, brows) { brows = it }
                PartChips("Mắt", ExpressionVocab.EYES, eyes) { eyes = it }
                PartChips("Miệng", ExpressionVocab.MOUTH, mouth) { mouth = it }
                Text("Chi tiết phụ (chọn nhiều)", color = C.T2, fontSize = 11.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    ExpressionVocab.EXTRAS.forEach { part ->
                        FilterChip(selected = part.key in extras,
                            onClick = { extras = if (part.key in extras) extras - part.key else extras + part.key },
                            label = { Text(part.label + if (part.verified) "" else " *", fontSize = 10.sp) })
                    }
                }
                PartChips("Hướng nhìn", ExpressionVocab.GAZE, gaze) { gaze = it }
                PartChips("Đầu", ExpressionVocab.HEAD, head) { head = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Cường độ: ${listOf("", "nhẹ", "vừa", "mạnh")[intensity.coerceIn(1, 3)]}", color = C.T2, fontSize = 11.sp)
                    HelpDot("expressionIntensity")
                }
                Slider(value = intensity.toFloat(), onValueChange = { intensity = it.toInt().coerceIn(1, 3) }, valueRange = 1f..3f, steps = 1)
                Text("* = tag chưa tìm thấy trong wiki Danbooru đã tra (${ExpressionVocab.unverifiedTags().joinToString(", ")}); " +
                    "các tag còn lại đã đối chiếu với tag_group:face_tags / eyes_tags / posture.", color = C.Orange, fontSize = 10.sp, lineHeight = 13.sp)
                Text("Xem trước — ANIME (tag danbooru):", color = C.T2, fontSize = 11.sp)
                Text(ExpressionLibrary.compose(draft, PromptStyle.TAG_BASED), color = C.Green, fontSize = 11.sp)
                Text("Xem trước — ẢNH THỰC (giải phẫu, dạng danh sách):", color = C.T2, fontSize = 11.sp)
                Text(ExpressionLibrary.compose(draft, PromptStyle.TAG_BASED, realistic = true), color = C.Green, fontSize = 11.sp)
                Text("Xem trước — ẢNH THỰC (câu tự nhiên):", color = C.T2, fontSize = 11.sp)
                Text(ExpressionLibrary.compose(draft, PromptStyle.NATURAL_LANGUAGE, realistic = true), color = C.Green, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && lead.isNotBlank(), onClick = { onSave(draft) }) { Text("Lưu") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Huỷ") } }
    )
}

// ─────────────────────────────────────────────── Tab 2: Dàn diễn viên ───────────────────────────────────────────────

private val BASIC_SHEET = listOf("smile", "sad", "angry", "surprised", "scared", "determined")

@Composable
private fun ExpressionCastTab(vm: MainViewModel) {
    val story by vm.currentStory.collectAsState()
    val busy by vm.expressionBusy.collectAsState()
    val s = story
    if (s == null) { Box(Modifier.fillMaxSize().padding(20.dp)) { Text("Chưa mở truyện nào.", color = C.T3) }; return }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                Column(Modifier.padding(12.dp)) {
                    Text("🎬 Bảng biểu cảm từng nhân vật", color = C.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Vẽ lại MẶT của ảnh anchor với từng biểu cảm. Khi panel yêu cầu đúng biểu cảm đó, ảnh tương ứng được dùng làm ảnh " +
                        "tham chiếu IP-Adapter — nhờ vậy danh tính VÀ biểu cảm cùng được mang theo (cách cộng đồng dùng expression sheet).",
                        color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Giới hạn thật: cần anchor có mặt nhìn rõ + model YOLOv8-pose; ảnh vẽ bằng img2img không có IP-Adapter nên có thể lệch " +
                        "nhẹ khuôn mặt — xem ảnh và xoá nếu không đạt. Không áp dụng khi nhân vật đang dùng phiên bản ngoại hình theo chương " +
                        "hoặc ảnh áo rách (ưu tiên cao hơn).", color = C.Orange, fontSize = 10.sp, lineHeight = 14.sp)
                    if (busy != null) { Spacer(Modifier.height(6.dp)); Text("⏳ Đang vẽ: $busy", color = C.Green, fontSize = 11.sp) }
                }
            }
        }
        item { CompareResultCard(vm) }
        if (s.characters.isEmpty()) item { Text("Truyện chưa có nhân vật.", color = C.T3, fontSize = 12.sp) }
        items(s.characters, key = { it.id }) { ch -> CastCard(vm, ch, busy != null) }
    }
}

@Composable
private fun CastCard(vm: MainViewModel, ch: Character, busy: Boolean) {
    val sheet = ch.expressionAnchors.orEmpty()
    Surface(color = C.S1, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Border)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SheetThumb(ch.anchorImagePath, 52)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(ch.name, color = C.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(if (ch.anchorImagePath == null) "Chưa có ảnh anchor" else "${sheet.size} biểu cảm trong bảng",
                        color = if (ch.anchorImagePath == null) C.Red else C.T3, fontSize = 11.sp)
                }
            }
            if (sheet.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    sheet.entries.toList().forEach { (key, path) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            SheetThumb(path, 64)
                            Text(ExpressionRegistry.labelOf(key), color = C.T2, fontSize = 10.sp)
                            TextButton(onClick = { vm.deleteExpressionAnchor(ch, key) }, contentPadding = PaddingValues(0.dp)) {
                                Text("xoá", color = C.Red, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
            if (ch.anchorImagePath != null) {
                Spacer(Modifier.height(8.dp))
                Button(enabled = !busy, onClick = { vm.generateExpressionAnchors(ch, BASIC_SHEET.filter { it !in sheet }) },
                    colors = ButtonDefaults.buttonColors(containerColor = C.Blue), modifier = Modifier.fillMaxWidth()) {
                    Text("Tạo bộ cơ bản (6 biểu cảm còn thiếu)", fontSize = 12.sp)
                }
                Spacer(Modifier.height(6.dp))
                Text("Hoặc tạo từng biểu cảm:", color = C.T2, fontSize = 11.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    ExpressionRegistry.selectableKeys().filter { it != "neutral" }.forEach { key ->
                        AssistChip(enabled = !busy, onClick = { vm.generateExpressionAnchor(ch, key) },
                            label = { Text(ExpressionRegistry.labelOf(key) + if (key in sheet) " ✓" else "", fontSize = 10.sp) })
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("So sánh cách viết prompt (cùng ảnh, cùng seed, chỉ khác bộ từ vựng):", color = C.T2, fontSize = 11.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    ExpressionRegistry.selectableKeys().filter { it != "neutral" }.forEach { key ->
                        AssistChip(enabled = !busy, onClick = { vm.compareExpressionVocab(ch, key) },
                            label = { Text("⇄ " + ExpressionRegistry.labelOf(key), fontSize = 10.sp) })
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────── Tab 3: Diễn biến ───────────────────────────────────────────────

@Composable
private fun ExpressionTimelineTab(vm: MainViewModel) {
    val chapter by vm.currentChapter.collectAsState()
    val ch = chapter
    if (ch == null || ch.panels.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(20.dp)) {
            Text("Chưa mở chương nào (hoặc chương chưa có panel). Mở một chương rồi quay lại để chỉnh biểu cảm theo panel.", color = C.T3)
        }
        return
    }
    val names = ch.panels.flatMap { it.scene.characters }.distinct()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                Column(Modifier.padding(12.dp)) {
                    Text("📈 Diễn biến cảm xúc · ${ch.title}", color = C.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Biểu cảm hiệu lực của từng nhân vật qua các panel (LLM chọn, bạn chỉnh tay đè lên). Chỉnh ở đây có hiệu lực ở lần " +
                        "sinh/sinh lại panel kế tiếp; bật \"Vẽ lại biểu cảm từng khuôn mặt\" trong Cài đặt để biểu cảm hiện rõ ở mặt nhỏ.",
                        color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
                }
            }
        }
        items(names, key = { "arc_$it" }) { name ->
            Surface(color = C.S1, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, C.Border)) {
                Column(Modifier.padding(10.dp)) {
                    Text(name, color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        ch.panels.filter { name in it.scene.characters }.forEach { p ->
                            val key = effectiveKey(p, name)
                            AssistChip(onClick = {}, label = { Text("${p.index + 1}: ${ExpressionRegistry.labelOf(key)}", fontSize = 10.sp) })
                        }
                    }
                }
            }
        }
        item {
            val planMsg by vm.planMessage.collectAsState()
            val busyNow by vm.expressionBusy.collectAsState()
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(enabled = busyNow == null, onClick = { vm.planExpressionArcWithLlm() },
                    colors = ButtonDefaults.buttonColors(containerColor = C.Blue), modifier = Modifier.fillMaxWidth()) {
                    Text("Lập kế hoạch cảm xúc cả chương bằng LLM", fontSize = 12.sp)
                }
                Text("Nạp LLM trên máy, chọn biểu cảm từng nhân vật từng panel theo luật quán tính (giữ nguyên trừ khi văn bản cho lý do đổi). " +
                    "Chỉ là ĐỀ XUẤT: không đè chỉnh tay của bạn, hoàn tác được. Chất lượng phụ thuộc LLM nhỏ trên máy — chưa đo.",
                    color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                planMsg?.let { Text(it, color = C.Green, fontSize = 11.sp) }
                OutlinedButton(onClick = { vm.undoExpressionPlan() }, modifier = Modifier.fillMaxWidth()) { Text("Hoàn tác kế hoạch", fontSize = 12.sp) }
            }
        }
        item {
            var info by remember { mutableStateOf<String?>(null) }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { val n = vm.fillExpressionInertia(); info = if (n > 0) "Đã điền $n ô — xem lại bên dưới." else "Không có ô nào cần điền." },
                    colors = ButtonDefaults.buttonColors(containerColor = C.Blue), modifier = Modifier.fillMaxWidth()) {
                    Text("Điền chỗ trống theo quán tính (tối đa 2 panel)", fontSize = 12.sp)
                }
                Text("Panel mà LLM không cho biểu cảm (trung tính) sẽ giữ biểu cảm mạnh của panel liền trước. Chỉ là quy tắc quán tính, " +
                    "không hiểu cốt truyện — hãy xem lại.", color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                info?.let { Text(it, color = C.Green, fontSize = 11.sp) }
                OutlinedButton(onClick = { vm.clearAllPanelExpressionOverrides() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Xoá mọi chỉnh tay (về theo LLM)", fontSize = 12.sp)
                }
            }
        }
        items(ch.panels, key = { "panel_${it.index}" }) { panel ->
            TimelinePanelCard(vm, ch.panels, panel)
        }
    }
}

@Composable
private fun TimelinePanelCard(vm: MainViewModel, all: List<Panel>, panel: Panel) {
    Surface(color = C.S1, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, C.Border)) {
        Column(Modifier.padding(10.dp)) {
            Text("Panel ${panel.index + 1} · ${panel.scene.description.take(70)}", color = C.T2, fontSize = 11.sp)
            if (panel.scene.characters.isEmpty()) {
                Text("Không có nhân vật", color = C.T3, fontSize = 11.sp)
            }
            panel.scene.characters.forEach { name ->
                var menu by remember(panel.index, name) { mutableStateOf(false) }
                val key = effectiveKey(panel, name)
                val manual = hasManualOverride(panel, name)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(name, color = C.T1, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Box {
                        OutlinedButton(onClick = { menu = true }) {
                            Text(ExpressionRegistry.labelOf(key) + if (manual) " ✎" else "", fontSize = 11.sp,
                                color = if (manual) C.Green else C.T1)
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Theo LLM") },
                                onClick = { vm.setPanelCharacterExpression(panel.index, name, null); menu = false })
                            ExpressionRegistry.selectableKeys().forEach { k ->
                                DropdownMenuItem(text = { Text(ExpressionRegistry.labelOf(k)) },
                                    onClick = { vm.setPanelCharacterExpression(panel.index, name, k); menu = false })
                            }
                        }
                    }
                    IconButton(onClick = {
                        // Chép biểu cảm hiệu lực này sang các panel SAU có nhân vật đó mà CHƯA chỉnh tay.
                        all.filter { it.index > panel.index && name in it.scene.characters && !hasManualOverride(it, name) }
                            .forEach { vm.setPanelCharacterExpression(it.index, name, key) }
                    }) { Icon(Icons.Default.ArrowDownward, "Chép xuống các panel sau", tint = C.T2) }
                }
            }
        }
    }
}

// ─────────────────────────────────────── Tab 4: Làm video (ảnh = khung hình đầu/cuối) ───────────────────────────────────────

@Composable
private fun VideoReadyTab(vm: MainViewModel) {
    val chapter by vm.currentChapter.collectAsState()
    val infos by vm.videoReadiness.collectAsState()
    val busy by vm.expressionBusy.collectAsState()
    val appSettings by vm.settings.collectAsState()
    val ch = chapter
    if (ch == null || ch.panels.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(20.dp)) { Text("Chưa mở chương nào. Mở một chương rồi quay lại để kiểm tra ảnh làm khung hình video.", color = C.T3) }
        return
    }
    LaunchedEffect(ch.chapterNumber) { vm.analyzeVideoReadiness() }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                Column(Modifier.padding(12.dp)) {
                    Text("🔍 Kiểm tra ảnh & biến thể biểu cảm", color = C.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Ứng dụng này tạo ẢNH. Phần này lấy bài học từ cộng đồng làm video — nơi ảnh tĩnh là khung hình đầu, nên phải sạch lỗi, mặt rõ, ít người, " +
                        "không chữ — để kiểm tra chất lượng từng panel. \"Biểu cảm kết\" tạo một BIẾN THỂ của cùng panel (cùng bố cục, cùng seed, chỉ vẽ lại mặt) " +
                        "để bạn chọn diễn xuất đẹp nhất; ai dùng công cụ video bên ngoài có thể xuất thành cặp khung đầu/kết (tuỳ chọn trong Cài đặt).",
                        color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Giới hạn thật: ngưỡng cảnh báo (mặt nhỏ, đông người) là heuristic suy từ khuyến nghị định tính, chưa hiệu chỉnh với model video nào; " +
                        "ứng dụng KHÔNG chạy model video — chỉ chuẩn bị ảnh + prompt.", color = C.Orange, fontSize = 10.sp, lineHeight = 14.sp)
                    if (busy != null) { Spacer(Modifier.height(6.dp)); Text("⏳ Đang vẽ: $busy", color = C.Green, fontSize = 11.sp) }
                }
            }
        }
        item {
            Text("Khung đích khi xuất cho công cụ video bên ngoài (tuỳ chọn)", color = C.T2, fontSize = 11.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                VideoTarget.values().forEach { t ->
                    FilterChip(selected = appSettings.videoPackTarget == t.name,
                        onClick = { vm.updateSettings { copy(videoPackTarget = t.name) }; vm.analyzeVideoReadiness() },
                        label = { Text(t.label, fontSize = 10.sp) })
                }
            }
            Spacer(Modifier.height(4.dp))
            Text("Để xuất: bật \"Gói ảnh cho model video\" trong Cài đặt → Xuất bản nâng cao rồi xuất chương như bình thường.", color = C.T3, fontSize = 10.sp)
        }
        items(ch.panels, key = { "vp_${it.index}" }) { panel ->
            val info = infos.firstOrNull { it.panel.index == panel.index }
            VideoPanelCard(vm, panel, info, busy != null)
        }
    }
}

@Composable
private fun VideoPanelCard(vm: MainViewModel, panel: Panel, info: com.mangalocal.pipeline.MangaPipeline.PanelVideoInfo?, busy: Boolean) {
    Surface(color = C.S1, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, C.Border)) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SheetThumb(info?.imagePath ?: panel.imagePath, 56)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Panel ${panel.index + 1} · ${panel.scene.description.take(60)}", color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    if (info != null) Text("${info.imgW}×${info.imgH} · ${info.personCount} người · ${info.faces.size} mặt dò được",
                        color = C.T3, fontSize = 10.sp)
                    else Text("Chưa có ảnh", color = C.Red, fontSize = 10.sp)
                }
                panel.overrideSettings?.videoEndFramePath?.let { SheetThumb(it, 56) }
            }
            info?.issues?.forEach { issue ->
                Text((if (issue.severity >= 2) "⚠ " else "ℹ ") + issue.message,
                    color = if (issue.severity >= 2) C.Orange else C.T3, fontSize = 10.sp, lineHeight = 13.sp)
            }
            if (info != null && info.issues.isEmpty()) Text("✓ Không có cảnh báo", color = C.Green, fontSize = 10.sp)

            if (panel.scene.characters.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("Biểu cảm của biến thể (khung kết):", color = C.T2, fontSize = 11.sp)
                panel.scene.characters.forEach { name ->
                    var menu by remember(panel.index, name) { mutableStateOf(false) }
                    val endKey = panel.overrideSettings?.videoEndExpressions?.get(name)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text(name, color = C.T1, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Box {
                            OutlinedButton(onClick = { menu = true }) {
                                Text(if (endKey == null) "Không đổi" else ExpressionRegistry.labelOf(endKey), fontSize = 11.sp,
                                    color = if (endKey == null) C.T2 else C.Green)
                            }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(text = { Text("Không đổi") }, onClick = { vm.setPanelVideoEndExpression(panel.index, name, null); menu = false })
                                ExpressionRegistry.selectableKeys().forEach { k ->
                                    DropdownMenuItem(text = { Text(ExpressionRegistry.labelOf(k)) },
                                        onClick = { vm.setPanelVideoEndExpression(panel.index, name, k); menu = false })
                                }
                            }
                        }
                    }
                }
                val hasEndSel = panel.overrideSettings?.videoEndExpressions?.isNotEmpty() == true
                val hasEndImg = panel.overrideSettings?.videoEndFramePath != null
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = hasEndSel && !busy, onClick = { vm.generatePanelVideoEndFrame(panel.index) },
                        colors = ButtonDefaults.buttonColors(containerColor = C.Blue)) {
                        Text(if (hasEndImg) "Tạo lại khung kết" else "Tạo khung kết", fontSize = 11.sp)
                    }
                    if (hasEndImg) OutlinedButton(enabled = !busy, onClick = { vm.clearPanelVideoEndFrame(panel.index) }) { Text("Xoá khung kết", fontSize = 11.sp) }
                }
            }
        }
    }
}

@Composable
private fun CompareResultCard(vm: MainViewModel) {
    val cmp by vm.expressionCompare.collectAsState()
    val c = cmp ?: return
    Surface(color = C.S1, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Blue.copy(0.4f))) {
        Column(Modifier.padding(12.dp)) {
            Text("So sánh: ${c.characterName} · ${ExpressionRegistry.labelOf(c.key)}", color = C.T1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) {
                    SheetThumb(c.boorPath, 110)
                    Text("Tag booru", color = C.T2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text(c.boorPrompt, color = C.T3, fontSize = 9.sp, lineHeight = 12.sp)
                    TextButton(onClick = { vm.updateSettings { copy(expressionVocabulary = "BOORU") } }, contentPadding = PaddingValues(0.dp)) {
                        Text("Dùng bộ này", fontSize = 11.sp, color = C.Green)
                    }
                }
                Column(Modifier.weight(1f)) {
                    SheetThumb(c.anatomicalPath, 110)
                    Text("Giải phẫu", color = C.T2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text(c.anatomicalPrompt, color = C.T3, fontSize = 9.sp, lineHeight = 12.sp)
                    TextButton(onClick = { vm.updateSettings { copy(expressionVocabulary = "ANATOMICAL") } }, contentPadding = PaddingValues(0.dp)) {
                        Text("Dùng bộ này", fontSize = 11.sp, color = C.Green)
                    }
                }
            }
            Text("Hai ảnh dùng cùng ảnh anchor, cùng seed, cùng cài đặt — chỉ khác cách viết biểu cảm. Chọn bộ cho biểu cảm thể hiện rõ hơn mà khuôn mặt không lệch.",
                color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
            TextButton(onClick = { vm.clearExpressionCompare() }) { Text("Đóng", fontSize = 11.sp) }
        }
    }
}
