package com.mangalocal.ui

import android.graphics.BitmapFactory
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mangalocal.pipeline.PoseExtractor
import com.mangalocal.pipeline.AgeCategory
import com.mangalocal.pipeline.StoryManager
import com.mangalocal.pipeline.PoseRetargeter
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot

// ─────────────────────────────────────────────────────────────────────────
// Cùng bảng cặp khớp + màu như pose_templates::kBonePairs/kBoneColors trong
// ip_adapter.cpp (C++) — ĐỔI 1 BÊN PHẢI ĐỔI CẢ 2 BÊN, chỉ để hiển thị cho
// khớp với đúng thứ tự vẽ/màu native dùng, không ảnh hưởng logic sinh ảnh.
// ─────────────────────────────────────────────────────────────────────────
private val BONE_PAIRS = listOf(
    1 to 2, 1 to 5, 2 to 3, 3 to 4, 5 to 6, 6 to 7, 1 to 8, 8 to 9, 9 to 10,
    1 to 11, 11 to 12, 12 to 13, 1 to 0, 0 to 14, 14 to 16, 0 to 15, 15 to 17
)
private val BONE_COLORS = listOf(
    Color(0xFFFF0000), Color(0xFFFF5500), Color(0xFFFFAA00), Color(0xFFFFFF00),
    Color(0xFFAAFF00), Color(0xFF55FF00), Color(0xFF00FF00), Color(0xFF00FF55),
    Color(0xFF00FFAA), Color(0xFF00FFFF), Color(0xFF00AAFF), Color(0xFF0055FF),
    Color(0xFF0000FF), Color(0xFF5500FF), Color(0xFFAA00FF), Color(0xFFFF00FF), Color(0xFFFF00AA)
)
private val JOINT_NAMES = listOf(
    "Mũi", "Cổ", "Vai phải", "Khuỷu phải", "Cổ tay phải",
    "Vai trái", "Khuỷu trái", "Cổ tay trái", "Hông phải", "Gối phải",
    "Cổ chân phải", "Hông trái", "Gối trái", "Cổ chân trái",
    "Mắt phải", "Mắt trái", "Tai phải", "Tai trái"
)

private fun defaultSkeleton(offsetX: Float = 0.5f): MutableList<StoryManager.PoseKeypoint> {
    val coords = listOf(
        0.10f to 0f, 0.20f to 0f, 0.22f to -0.08f, 0.35f to -0.11f, 0.48f to -0.14f,
        0.22f to 0.08f, 0.35f to 0.11f, 0.48f to 0.14f, 0.50f to -0.04f, 0.68f to -0.05f,
        0.85f to -0.06f, 0.50f to 0.04f, 0.68f to 0.05f, 0.85f to 0.06f,
        0.09f to -0.02f, 0.09f to 0.02f, 0.10f to -0.04f, 0.10f to 0.04f
    )
    return coords.map { (y, dx) -> StoryManager.PoseKeypoint(x = offsetX + dx, y = y, z = 0f, visible = true) }.toMutableList()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PoseEditorScreen(nav: NavController, vm: MainViewModel) {
    val storyManager = vm.storyManager
    val onBack: () -> Unit = { nav.popBackStack() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val poseExtractor = remember { PoseExtractor(context, storyManager) }
    DisposableEffect(Unit) { onDispose { poseExtractor.close() } }

    var isExtracting by remember { mutableStateOf(false) }
    var extractedCount by remember { mutableStateOf<Int?>(null) }
    var extractTargetTemplate by remember { mutableStateOf("") }
    var pendingVariants by remember { mutableStateOf<List<PoseExtractor.ExtractedVariant>>(emptyList()) }

    fun handlePickedMedia(uri: Uri) {
        if (!poseExtractor.isReady()) {
            extractedCount = null
            return
        }
        isExtracting = true
        scope.launch {
            val mime = context.contentResolver.getType(uri) ?: ""
            val variants = withContext(Dispatchers.Default) {
                if (mime.startsWith("video")) {
                    poseExtractor.extractFromVideo(context, uri, fpsSample = 2f)
                } else {
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        val bmp = BitmapFactory.decodeStream(input)
                        val people = poseExtractor.extractFromImage(bmp)
                        if (people != null) {
                            val validations = people.map { poseExtractor.validatePerson(it) }
                            val anyNeedsReview = validations.any { it.needsReview }
                            val allReasons = validations.flatMapIndexed { idx, v ->
                                v.reasons.map { r -> if (people.size > 1) "Người ${idx+1}: $r" else r }
                            }
                            listOf(PoseExtractor.ExtractedVariant(
                                poseExtractor.estimateAngle(people[0]), people, anyNeedsReview, allReasons
                            ))
                        } else emptyList()
                    } ?: emptyList()
                }
            }
            pendingVariants = variants
            extractedCount = variants.size
            isExtracting = false
        }
    }

    val pickMediaLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { handlePickedMedia(it) } }
    var templateNames by remember { mutableStateOf(storyManager.listPoseTemplateNames()) }
    var selectedTemplate by remember { mutableStateOf(templateNames.firstOrNull() ?: "") }
    var newTemplateName by remember { mutableStateOf("") }
    var angle by remember { mutableStateOf("front") }
    var people by remember { mutableStateOf(mutableListOf(defaultSkeleton())) }
    var activePerson by remember { mutableIntStateOf(0) }
    var selectedJoint by remember { mutableStateOf<Int?>(null) }
    // mục 128 TECHNICAL_STATUS.md — user chỉ ra ĐÚNG: màn hình chỉnh khớp
    // xương KHÔNG có cách nào phóng to để thao tác chính xác, đặc biệt cần
    // thiết cho tư thế nhiều khớp cụm sát nhau (vd chân vòng qua eo người
    // kia — đúng ví dụ user nêu). "Chấp nhận ưu tiên bỏ UI để lấy UX" — vá
    // bằng zoom/pan 2 ngón tay, đơn giản, không thêm nút bấm rườm rà.
    var canvasScale by remember { mutableFloatStateOf(1f) }
    var canvasOffsetX by remember { mutableFloatStateOf(0f) }
    var canvasOffsetY by remember { mutableFloatStateOf(0f) }
    var loadedVariantIndex by remember { mutableStateOf<Int?>(null) }
    var showSavedMsg by remember { mutableStateOf(false) }

    fun loadVariant(templateName: String, index: Int) {
        val lib = storyManager.loadPoseLibrary()
        val variant = lib[templateName]?.getOrNull(index) ?: return
        angle = variant.angle
        people = variant.people.map { it.toMutableList() }.toMutableList()
        activePerson = 0; selectedJoint = null; loadedVariantIndex = index
    }

    Scaffold(
        containerColor = C.Bg,
        topBar = {
            TopAppBar(
                title = { Text("Vẽ / sửa khung xương", color = C.T1, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null, tint = C.T1) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {

            // ── Trích khung xương từ ảnh/video trong thư viện (MediaPipe,
            //    chạy ngay trên máy, không cần máy tính) ─────────────────
            MlCard {
                Column(Modifier.padding(12.dp)) {
                    Text("Trích tư thế từ ảnh/video có sẵn", color = C.T1, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    if (!poseExtractor.isReady()) {
                        Text(
                            "⚠ Thiếu model yolov8_pose.mnn trong thư mục MangaLocal/yolo/ — " +
                            "chạy prepare_models.yml (GitHub Actions) hoặc tools/export_yolo_pose.py để tạo",
                            color = C.Red, fontSize = 11.sp
                        )
                    } else {
                        Text("Chọn 1 ảnh hoặc video — video sẽ tự lấy mẫu 2 frame/giây, lọc bớt frame gần trùng.",
                            color = C.T2, fontSize = 11.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { pickMediaLauncher.launch(arrayOf("image/*", "video/*")) },
                            enabled = !isExtracting, modifier = Modifier.fillMaxWidth()
                        ) {
                            if (isExtracting) {
                                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp)); Text("Đang trích xuất...")
                            } else {
                                Icon(Icons.Filled.PhotoLibrary, null); Spacer(Modifier.width(6.dp))
                                Text("Chọn ảnh / video từ thư viện")
                            }
                        }
                    }
                    extractedCount?.let { count ->
                        Spacer(Modifier.height(8.dp))
                        if (count == 0) {
                            Text("Không phát hiện được người nào trong media này.", color = C.Red, fontSize = 12.sp)
                        } else {
                            Text("✓ Trích được $count biến thể tư thế.", color = C.Green, fontSize = 12.sp)
                            val needReviewCount = pendingVariants.count { it.needsReview }
                            if (needReviewCount > 0) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "⚠ $needReviewCount/$count biến thể CẦN KIỂM TRA KỸ (che khuất/thiếu chi/dị dạng) " +
                                    "— YOLOv8-pose tự phát hiện nghi ngờ, không có nghĩa chắc chắn sai, nhưng nên tự " +
                                    "xem lại bằng tay trước khi tin dùng, nhất là với cảnh nhiều người ôm/vật lộn.",
                                    color = C.Orange, fontSize = 10.sp, lineHeight = 13.sp
                                )
                                Spacer(Modifier.height(4.dp))
                                pendingVariants.filter { it.needsReview }.take(5).forEach { ev ->
                                    ev.reviewReasons.forEach { reason ->
                                        Text("· $reason", color = C.T3, fontSize = 9.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            OutlinedTextField(
                                value = extractTargetTemplate, onValueChange = { extractTargetTemplate = it },
                                label = { Text("Lưu vào template tên gì?") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(6.dp))
                            Button(
                                onClick = {
                                    if (extractTargetTemplate.isNotBlank()) {
                                        pendingVariants.forEach { ev ->
                                            storyManager.savePoseVariant(
                                                extractTargetTemplate,
                                                StoryManager.PoseVariant(
                                                    angle = ev.angle, people = ev.people.toMutableList(),
                                                    needsReview = ev.needsReview, reviewReasons = ev.reviewReasons
                                                )
                                            )
                                        }
                                        templateNames = storyManager.listPoseTemplateNames()
                                        selectedTemplate = extractTargetTemplate
                                        extractedCount = null; pendingVariants = emptyList(); extractTargetTemplate = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = C.Green),
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Lưu $count biến thể vào thư viện") }
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // ── Import từ nguồn khác (mục 34 TECHNICAL_STATUS.md) ──────
            MlCard {
                Column(Modifier.padding(12.dp)) {
                    MlLabel("import từ nguồn khác (OpenPose BODY_18)")
                    Text(
                        "Chỉ hỗ trợ định dạng OpenPose BODY_18 chuẩn (18 điểm, đúng thứ tự CMU OpenPose gốc — " +
                        "TRÙNG với thứ tự app đang dùng). KHÔNG hỗ trợ BODY_25 (25 điểm, thứ tự khác — sẽ báo lỗi " +
                        "thay vì đoán map sai). Kết quả import LUÔN đánh dấu \"cần kiểm tra kỹ\" vì chưa qua 3 cơ chế " +
                        "validate tự động của app (mục 19) — tự xem lại trước khi dùng.",
                        color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    var importCanvasW by remember { mutableStateOf("512") }
                    var importCanvasH by remember { mutableStateOf("512") }
                    var importTemplateName by remember { mutableStateOf("") }
                    var importResult by remember { mutableStateOf<Int?>(null) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = importCanvasW, onValueChange = { importCanvasW = it },
                            label = { Text("Rộng ảnh gốc (px)", fontSize = 10.sp) }, modifier = Modifier.weight(1f),
                            singleLine = true)
                        OutlinedTextField(value = importCanvasH, onValueChange = { importCanvasH = it },
                            label = { Text("Cao ảnh gốc (px)", fontSize = 10.sp) }, modifier = Modifier.weight(1f),
                            singleLine = true)
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = importTemplateName, onValueChange = { importTemplateName = it },
                        label = { Text("Lưu vào template tên gì?", fontSize = 11.sp) }, singleLine = true,
                        modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    val pickJsonLauncher = rememberLauncherForActivityResult(
                        contract = ActivityResultContracts.OpenDocument()
                    ) { uri ->
                        if (uri != null && importTemplateName.isNotBlank()) {
                            val w = importCanvasW.toIntOrNull() ?: 512
                            val h = importCanvasH.toIntOrNull() ?: 512
                            val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                            if (text != null) {
                                importResult = storyManager.importOpenPoseJson(text, w, h, importTemplateName)
                                if (importResult!! > 0) templateNames = storyManager.listPoseTemplateNames()
                            }
                        }
                    }
                    MlOutlineBtn("Chọn file .json OpenPose", icon = Icons.Default.FileOpen,
                        enabled = importTemplateName.isNotBlank(),
                        onClick = { pickJsonLauncher.launch(arrayOf("application/json", "*/*")) })
                    importResult?.let { count ->
                        Spacer(Modifier.height(6.dp))
                        if (count > 0) Text("✓ Import được $count người vào \"$importTemplateName\".", color = C.Green, fontSize = 12.sp)
                        else Text("✗ Import thất bại — không phải BODY_18 hợp lệ, hoặc JSON sai định dạng.", color = C.Red, fontSize = 12.sp)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // ── Chọn template + tên mới ────────────────────────────────
            MlCard {
                Column(Modifier.padding(12.dp)) {
                    Text("Tên tư thế (template)", color = C.T2, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { expanded = true }) {
                                Text(selectedTemplate.ifBlank { "-- chọn --" }, color = C.T1)
                            }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                templateNames.forEach { name ->
                                    DropdownMenuItem(text = { Text(name) }, onClick = {
                                        selectedTemplate = name; expanded = false; loadedVariantIndex = null
                                    })
                                }
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        OutlinedTextField(
                            value = newTemplateName, onValueChange = { newTemplateName = it },
                            label = { Text("hoặc tên mới") }, singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // ── Danh sách biến thể có sẵn của template đang chọn ───────
            if (selectedTemplate.isNotBlank()) {
                val variants = storyManager.loadPoseLibrary()[selectedTemplate].orEmpty()
                if (variants.isNotEmpty()) {
                    Text("Biến thể có sẵn (bấm để sửa lại tư thế lỗi):", color = C.T2, fontSize = 12.sp)
                    LazyRowVariants(variants) { idx -> loadVariant(selectedTemplate, idx) }
                    Spacer(Modifier.height(8.dp))
                }
            }

            // ── Chọn góc nhìn ────────────────────────────────────────
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Góc nhìn:", color = C.T2, fontSize = 12.sp)
                Spacer(Modifier.width(8.dp))
                listOf("front", "side_left", "side_right", "unknown").forEach { a ->
                    FilterChip(
                        selected = angle == a, onClick = { angle = a },
                        label = { Text(a, fontSize = 11.sp) },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // ── Chọn người đang sửa (nhiều nhân vật trong 1 khung) ─────
            Row(verticalAlignment = Alignment.CenterVertically) {
                people.forEachIndexed { idx, _ ->
                    FilterChip(
                        selected = activePerson == idx, onClick = { activePerson = idx; selectedJoint = null },
                        label = { Text("Người ${idx + 1}") }, modifier = Modifier.padding(end = 4.dp)
                    )
                }
                IconButton(onClick = {
                    people = (people + mutableListOf(defaultSkeleton(0.7f))).toMutableList()
                    activePerson = people.size - 1
                }) { Icon(Icons.Filled.PersonAdd, "Thêm người", tint = C.Blue) }
                if (people.size > 1) {
                    IconButton(onClick = {
                        people = people.toMutableList().also { it.removeAt(activePerson) }
                        activePerson = 0
                    }) { Icon(Icons.Filled.PersonRemove, "Xoá người", tint = C.Red) }
                }
            }

            Spacer(Modifier.height(8.dp))
            // Scale theo tuổi (mục 30 TECHNICAL_STATUS.md) — user tự chọn
            // ĐÚNG người đang active để scale, KHÔNG tự động đoán (native
            // không biết skeleton nào ứng với nhân vật nào). CHỈ scale được
            // chuỗi CHÂN đáng tin (không có điểm đỉnh đầu trong 18 khớp để
            // scale tỷ lệ đầu chính xác — giới hạn thật của bộ khớp OpenPose-18).
            var fromAge by remember { mutableStateOf(AgeCategory.ADULT) }
            var toAge by remember { mutableStateOf(AgeCategory.CHILD) }
            Text("Scale tỷ lệ chân cho \"Người ${activePerson + 1}\" (chỉ chân — xem giới hạn ở mục 30)",
                color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                Text("Từ:", color = C.T3, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically))
                AgeCategory.values().forEach { age ->
                    FilterChip(selected = fromAge == age, onClick = { fromAge = age },
                        label = { Text(age.label.take(10), fontSize = 10.sp) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                Text("Sang:", color = C.T3, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterVertically))
                AgeCategory.values().forEach { age ->
                    FilterChip(selected = toAge == age, onClick = { toAge = age },
                        label = { Text(age.label.take(10), fontSize = 10.sp) })
                }
            }
            Spacer(Modifier.height(6.dp))
            MlOutlineBtn("Áp dụng scale chân", icon = Icons.Default.Straighten, onClick = {
                val updated = people.toMutableList()
                updated[activePerson] = poseExtractor.rescaleLegsForAge(updated[activePerson], fromAge, toAge)
                people = updated
            })

            Spacer(Modifier.height(8.dp))

            // mục 127 TECHNICAL_STATUS.md — audit UX di động chưa từng làm
            // cho màn hình thao tác tay PHỨC TẠP NHẤT app (kéo khớp xương).
            // Bán kính bắt trúng khớp (hit-test) TRƯỚC ĐÂY hardcode 60f —
            // đây là 60 PIXEL THÔ (raw px của Canvas.pointerInput, KHÔNG
            // PHẢI dp), trên màn hình mật độ cao (3x density phổ biến
            // Android hiện nay) chỉ tương đương ~20dp bán kính (40dp đường
            // kính) — dưới xa ngưỡng 48dp khuyến nghị touch-target của
            // Android, đúng LOẠI bug đã sửa cho MlOutlineBtn (mục 109/114)
            // nhưng NGUY HIỂM HƠN ở đây vì đây là thao tác KÉO chính xác
            // (không phải bấm nút) — bán kính quá nhỏ khiến user khó chọn
            // đúng khớp, đặc biệt các khớp gần nhau (cổ tay gần khuỷu tay).
            // Đã sửa: tính theo dp thật qua LocalDensity, neo đúng 24dp
            // bán kính (48dp đường kính, đúng chuẩn Android) bất kể mật độ
            // màn hình.
            val density = LocalDensity.current
            val hitRadiusPx = with(density) { 24.dp.toPx() }

            // ── Canvas vẽ/kéo khung xương ───────────────────────────────
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(Color.Black, RoundedCornerShape(8.dp))
                    .clip(RoundedCornerShape(8.dp)) // giữ nội dung zoom trong khung, không tràn ra ngoài bo góc
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        // mục 128 — áp transform zoom/pan LÊN CHÍNH Canvas.
                        // Compose tự động nghịch-biến-đổi toạ độ chạm cho
                        // MỌI pointerInput gắn SAU graphicsLayer trong cùng
                        // node — 2 khối pointerInput bên dưới (zoom 2 ngón +
                        // kéo khớp 1 ngón) tiếp tục nhận toạ độ ĐÚNG không
                        // gian gốc (0..size), KHÔNG cần tự tính nghịch đảo
                        // scale/offset thủ công trong logic kéo khớp hiện
                        // có (giữ nguyên, không sửa).
                        .graphicsLayer(
                            scaleX = canvasScale, scaleY = canvasScale,
                            translationX = canvasOffsetX, translationY = canvasOffsetY
                        )
                        // Khối 1: cử chỉ 2 NGÓN TAY (zoom/pan) — GATE tường
                        // minh event.changes.size >= 2, chỉ tiêu thụ
                        // (consume) khi thật sự 2+ ngón, để KHÔNG chặn cử
                        // chỉ kéo 1 ngón (khối pointerInput riêng bên dưới)
                        // — 2 khối pointerInput độc lập trên CÙNG node vẫn
                        // nhận được cùng luồng sự kiện nếu không ai consume
                        // trước, đây là kỹ thuật Compose chuẩn để tách 2
                        // loại cử chỉ không xung đột nhau.
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                do {
                                    val event = awaitPointerEvent(PointerEventPass.Main)
                                    if (event.changes.size >= 2) {
                                        val zoomChange = event.calculateZoom()
                                        val panChange = event.calculatePan()
                                        canvasScale = (canvasScale * zoomChange).coerceIn(1f, 5f)
                                        // panChange đo trong không gian ĐÃ ZOOM (bên trong
                                        // graphicsLayer), nhưng translationX/Y của graphicsLayer
                                        // áp dụng ở không gian CHA (chưa zoom) — nhân thêm
                                        // canvasScale để tốc độ pan khớp đúng ngón tay, không bị
                                        // "ì" khi đã phóng to (suy luận từ cơ chế graphicsLayer,
                                        // CHƯA kiểm chứng trên thiết bị thật — không có máy/emulator
                                        // trong sandbox này để test cảm giác thao tác thật).
                                        canvasOffsetX += panChange.x * canvasScale
                                        canvasOffsetY += panChange.y * canvasScale
                                        event.changes.forEach { it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                        // Khối 2: kéo 1 NGÓN TAY di chuyển khớp — GIỮ NGUYÊN
                        // logic cũ hoàn toàn không đổi (đã sửa hitRadiusPx ở
                        // mục 127), chỉ khác là giờ nhận toạ độ đã tự động
                        // nghịch-biến-đổi đúng theo zoom hiện tại nhờ
                        // graphicsLayer ở trên.
                        .pointerInput(activePerson, people.size) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    val size = size
                                    val current = people[activePerson]
                                    var closest: Int? = null; var closestDist = Float.MAX_VALUE
                                    current.forEachIndexed { i, kp ->
                                        if (!kp.visible) return@forEachIndexed
                                        val px = kp.x * size.width; val py = kp.y * size.height
                                        val d = hypot(offset.x - px, offset.y - py)
                                        if (d < closestDist && d < hitRadiusPx) { closestDist = d; closest = i }
                                    }
                                    selectedJoint = closest
                                },
                                onDrag = { change, _ ->
                                    val idx = selectedJoint ?: return@detectDragGestures
                                    val size = size
                                    val nx = (change.position.x / size.width).coerceIn(0f, 1f)
                                    val ny = (change.position.y / size.height).coerceIn(0f, 1f)
                                    val updated = people.toMutableList()
                                    val personList = updated[activePerson].toMutableList()
                                    personList[idx] = personList[idx].copy(x = nx, y = ny)
                                    updated[activePerson] = personList
                                    people = updated
                                }
                            )
                        }
                ) {
                    val w = size.width; val h = size.height
                    // Vẽ TẤT CẢ người (mờ cho người không active, rõ cho người active)
                    people.forEachIndexed { pIdx, person ->
                        val alpha = if (pIdx == activePerson) 1f else 0.35f
                        BONE_PAIRS.forEachIndexed { i, (a, b) ->
                            val ka = person.getOrNull(a); val kb = person.getOrNull(b)
                            if (ka?.visible == true && kb?.visible == true) {
                                drawLine(
                                    color = BONE_COLORS[i % BONE_COLORS.size].copy(alpha = alpha),
                                    start = Offset(ka.x * w, ka.y * h), end = Offset(kb.x * w, kb.y * h),
                                    strokeWidth = 6f
                                )
                            }
                        }
                        if (pIdx == activePerson) {
                            person.forEachIndexed { i, kp ->
                                if (!kp.visible) return@forEachIndexed
                                val isSelected = selectedJoint == i
                                // mục 127 TECHNICAL_STATUS.md — cùng loại bug
                                // hitRadiusPx ở trên: bán kính VẼ trước đây
                                // hardcode px thô (9f/14f) — trên màn hình mật
                                // độ cao chỉ ~3dp/4.7dp, gần như vô hình. Đổi
                                // sang dp thật qua .dp.toPx() (DrawScope kế
                                // thừa Density, dùng trực tiếp không cần
                                // truyền density từ ngoài vào).
                                drawCircle(
                                    color = if (isSelected) Color.Yellow else Color.White,
                                    radius = if (isSelected) 10.dp.toPx() else 6.dp.toPx(),
                                    center = Offset(kp.x * w, kp.y * h),
                                    style = Stroke(width = 3.dp.toPx())
                                )
                            }
                        }
                    }
                }
            }

            // mục 128 — hint cử chỉ + nút reset, chỉ hiện khi ĐANG zoom/pan
            // (không chiếm chỗ lúc bình thường — "ưu tiên bỏ UI để lấy UX",
            // không thêm nút thường trực nếu không cần thiết ngay lúc đó).
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Text("Chụm/kéo 2 ngón để phóng to, 1 ngón để kéo khớp",
                    color = C.T3, fontSize = 10.sp)
                if (canvasScale != 1f || canvasOffsetX != 0f || canvasOffsetY != 0f) {
                    TextButton(onClick = { canvasScale = 1f; canvasOffsetX = 0f; canvasOffsetY = 0f }) {
                        Text("Reset zoom", color = C.Blue, fontSize = 11.sp)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // ── Điều khiển khớp đang chọn: đưa trước/sau, ẩn/hiện ──────
            selectedJoint?.let { idx ->
                val kp = people[activePerson][idx]
                MlCard {
                    Column(Modifier.padding(12.dp)) {
                        Text(JOINT_NAMES.getOrElse(idx) { "Khớp $idx" }, color = C.T1, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // z càng NHỎ = càng gần camera (đúng quy ước MediaPipe
                            // đã xác nhận) — "đưa ra trước" = giảm z.
                            OutlinedButton(onClick = {
                                val updated = people.toMutableList()
                                val personList = updated[activePerson].toMutableList()
                                personList[idx] = personList[idx].copy(z = personList[idx].z - 0.05f)
                                updated[activePerson] = personList; people = updated
                            }) { Text("◀ Đưa ra trước") }
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(onClick = {
                                val updated = people.toMutableList()
                                val personList = updated[activePerson].toMutableList()
                                personList[idx] = personList[idx].copy(z = personList[idx].z + 0.05f)
                                updated[activePerson] = personList; people = updated
                            }) { Text("Đưa ra sau ▶") }
                            Spacer(Modifier.width(8.dp))
                            Text("z=%.2f".format(kp.z), color = C.T2, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Hiện khớp này", color = C.T2, fontSize = 12.sp)
                            Switch(checked = kp.visible, onCheckedChange = { v ->
                                val updated = people.toMutableList()
                                val personList = updated[activePerson].toMutableList()
                                personList[idx] = personList[idx].copy(visible = v)
                                updated[activePerson] = personList; people = updated
                            })
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            // Nhãn tương tác (mục 6.4/34 TECHNICAL_STATUS.md) — dùng để tự
            // động chọn tư thế khớp mô tả kịch bản sau này. VD: "hug",
            // "fight_lock", "standing_talk". Không bắt buộc, nhưng nếu để
            // trống thì tư thế này chỉ được chọn qua so khớp tên template
            // thô (kém chính xác hơn).
            //
            // mục 129 TECHNICAL_STATUS.md — GỢI Ý TỰ ĐỘNG khi vừa nạp tư
            // thế mới (từ trích ảnh/video HOẶC mở template có sẵn): nếu
            // phát hiện 2+ người chồng lấn hình học (dùng CHUNG hàm
            // PoseRetargeter.detectBboxContact() — không viết logic lần 2,
            // xem mục 113/129), điền sẵn "contact" — CHỈ gợi ý CHUNG CHUNG
            // (không đoán bừa "hug" hay "fight" — hình học đơn thuần không
            // đủ để phân biệt 2 loại đó, đoán sai còn TỆ HƠN để trống, xem
            // GIỚI HẠN THẬT ở docstring PoseExtractor.kt). User XEM/SỬA lại
            // cho đúng loại tương tác cụ thể trước khi lưu — đây là GỢI Ý,
            // KHÔNG PHẢI tự động hoá hoàn toàn (đúng tinh thần "verify with
            // human" xuyên suốt dự án, không giả vờ máy hiểu được ngữ nghĩa
            // hành động từ thuần hình học tĩnh).
            var tagsInput by remember(loadedVariantIndex, selectedTemplate) {
                val suggested = if (PoseRetargeter.detectBboxContact(people)) "contact" else ""
                mutableStateOf(suggested)
            }
            OutlinedTextField(
                value = tagsInput, onValueChange = { tagsInput = it },
                label = { Text("Nhãn tương tác (cách nhau bởi dấu phẩy, vd: hug, embrace)", fontSize = 10.sp) },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            if (tagsInput == "contact") {
                Text("💡 Tự gợi ý \"contact\" (phát hiện 2+ người chồng lấn hình học) — sửa lại cho đúng " +
                     "loại tương tác cụ thể nếu biết (hug/fight/kiss...), hoặc giữ nguyên nếu không chắc.",
                    color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
            }
            Spacer(Modifier.height(8.dp))

            // ── Lưu ─────────────────────────────────────────────────────
            Button(
                onClick = {
                    val finalName = newTemplateName.ifBlank { selectedTemplate }
                    if (finalName.isBlank()) return@Button
                    val tags = tagsInput.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    val variant = StoryManager.PoseVariant(angle = angle, people = people, actionTags = tags)
                    storyManager.savePoseVariant(finalName, variant, loadedVariantIndex)
                    templateNames = storyManager.listPoseTemplateNames()
                    selectedTemplate = finalName; newTemplateName = ""
                    showSavedMsg = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = C.Blue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Save, null); Spacer(Modifier.width(6.dp))
                Text(if (loadedVariantIndex != null) "Lưu đè biến thể này" else "Lưu thành biến thể mới")
            }

            if (showSavedMsg) {
                Spacer(Modifier.height(6.dp))
                Text("✓ Đã lưu vào pose_library.json", color = C.Green, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun LazyRowVariants(variants: List<StoryManager.PoseVariant>, onPick: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        variants.forEachIndexed { idx, v ->
            OutlinedButton(onClick = { onPick(idx) }, modifier = Modifier.padding(end = 6.dp)) {
                Text("#$idx (${v.angle})", fontSize = 11.sp)
            }
        }
    }
}
