package com.mangalocal.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import com.mangalocal.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryReviewScreen(nav: NavController, vm: MainViewModel) {
    val chapter by vm.currentChapter.collectAsState()
    val isGenerating by vm.isGenerating.collectAsState()
    var selectedPanelIndex by remember { mutableStateOf<Int?>(null) }

    if (chapter == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Không có chapter", color = C.T3) }
        return
    }
    val ch = chapter!!
    val allApproved = ch.panels.all { it.status == PanelStatus.APPROVED }
    val isReviewStage = ch.status == ChapterStatus.REVIEW

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(ch.title) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        },
        containerColor = C.Bg
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(span = { GridItemSpan(2) }) {
                if (isReviewStage) {
                    Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                        Column(Modifier.padding(12.dp)) {
                            Text("📋 Duyệt panel trước khi upscale", color = C.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Đã duyệt: ${ch.approvedCount}/${ch.panels.size}. Nhấn vào panel để xem chi tiết, sửa, hoặc tạo lại.",
                                color = C.T2, fontSize = 12.sp, lineHeight = 16.sp)
                        }
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("${ch.panels.size}", "panel", Modifier.weight(1f))
                        StatCard(ch.status.name, "trạng thái", Modifier.weight(1f))
                    }
                }
            }

            items(ch.panels) { panel ->
                PanelCard(panel, onClick = { selectedPanelIndex = panel.index })
            }

            if (isReviewStage) item(span = { GridItemSpan(2) }) {
                Spacer(Modifier.height(4.dp))
                MlBtn(
                    text = if (allApproved) "➡️ Tiếp tục Upscale" else "Duyệt tất cả còn lại trước",
                    onClick = {
                        if (allApproved) { vm.proceedToUpscale(); nav.navigate("post_processing") }
                    },
                    enabled = allApproved && !isGenerating,
                    icon = Icons.Default.ArrowForward
                )
            }

            if (ch.status == ChapterStatus.DONE) item(span = { GridItemSpan(2) }) {
                Spacer(Modifier.height(4.dp))
                MlBtn("➡️ Tiếp theo: Hội thoại & Xuất file",
                    onClick = { nav.navigate("post_processing") }, icon = Icons.Default.ArrowForward)
            }
        }
    }

    selectedPanelIndex?.let { idx ->
        val panel = ch.panels.find { it.index == idx }
        if (panel != null) {
            EditPanelSheet(panel = panel, vm = vm, nav = nav, onDismiss = { selectedPanelIndex = null })
        }
    }
}

@Composable
private fun PanelCard(panel: Panel, onClick: () -> Unit) {
    Surface(onClick = onClick, color = C.S0, shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.5.dp, when (panel.status) {
            PanelStatus.APPROVED -> C.Green
            PanelStatus.REJECTED -> C.Red
            else -> C.Border
        }), modifier = Modifier.aspectRatio(3f/4f)) {
        Box {
            // mục 140 TECHNICAL_STATUS.md — SỬA BUG NGHIÊM TRỌNG: TRƯỚC ĐÂY
            // ô này chỉ hiện emoji "🖼️" + chữ, KHÔNG hiện ảnh thật — nghĩa
            // là toàn bộ lưới duyệt ảnh (chức năng CHÍNH của màn hình này)
            // không cho user xem được ảnh nào trước khi duyệt/từ chối. Dùng
            // ĐÚNG `coil.compose.AsyncImage` đã có sẵn pattern ở nơi khác
            // trong CHÍNH file này (dòng ~454/463, tính năng so sánh A/B) —
            // ưu tiên `upscaledPath` (nếu đã qua hoàn thiện) rồi mới tới
            // `imagePath` (ảnh thô 512px).
            //
            // mục 141 TECHNICAL_STATUS.md — THUMBNAIL THẬT (theo yêu cầu
            // user): panel sau upscale 4x có thể tới ~2048x2048px PNG —
            // decode NGUYÊN ẢNH đó chỉ để hiện trong 1 ô lưới ~100-150dp là
            // lãng phí RAM/CPU rõ rệt, đặc biệt khi lưới có NHIỀU panel
            // cùng lúc (cuộn giật, có thể OOM trên máy yếu nếu nhiều ảnh
            // lớn giải mã cùng lúc). Dùng `ImageRequest` với `.size()` cố
            // định NHỎ (200x200px, đủ nét cho ô lưới, dư biên cho màn hình
            // mật độ điểm ảnh cao) — Coil dùng size này để tính
            // `inSampleSize` NGAY LÚC DECODE (BitmapFactory), không giải
            // mã full-res rồi mới thu nhỏ như hành vi ngầm định nếu chỉ
            // truyền `File` thẳng. `.crossfade(true)` cho hiệu ứng mượt khi
            // ảnh tải xong, tránh giật cứng. Coil tự cache cả bộ nhớ lẫn đĩa
            // theo (path, size) — cuộn qua lại KHÔNG giải mã lại từ đầu.
            val displayPath = panel.upscaledPath ?: panel.imagePath
            if (displayPath != null) {
                val context = androidx.compose.ui.platform.LocalContext.current
                val thumbRequest = remember(displayPath) {
                    coil.request.ImageRequest.Builder(context)
                        .data(java.io.File(displayPath))
                        .size(200, 200)
                        .crossfade(true)
                        .build()
                }
                coil.compose.AsyncImage(
                    model = thumbRequest, contentDescription = "Panel ${panel.index + 1}",
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                )
                // Lớp phủ mờ dưới đáy để số panel/mô tả vẫn đọc được trên nền ảnh
                Box(Modifier.fillMaxSize().align(Alignment.BottomCenter)
                    .background(androidx.compose.ui.graphics.Brush.verticalGradient(
                        colors = listOf(androidx.compose.ui.graphics.Color.Transparent, androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.75f)),
                        startY = 0.55f)))
                Column(Modifier.fillMaxSize().padding(bottom = 8.dp), verticalArrangement = Arrangement.Bottom) {
                    Text("Panel ${panel.index + 1}", color = androidx.compose.ui.graphics.Color.White, fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 8.dp))
                }
            } else {
                // Chưa sinh ảnh lần nào (panel lỗi/chưa chạy tới) — placeholder
                // CÓ Ý NGHĨA thật (không phải vỏ rỗng che giấu ảnh có sẵn).
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("🖼️", fontSize = 30.sp)
                    Text("Panel ${panel.index + 1}", color = C.T2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text("Chưa có ảnh", color = C.T3, fontSize = 10.sp)
                }
            }
            if (panel.status == PanelStatus.APPROVED) {
                Surface(modifier = Modifier.align(Alignment.TopEnd).padding(6.dp), color = C.GreenDim, shape = RoundedCornerShape(6.dp)) {
                    Icon(Icons.Default.Check, null, tint = C.Green, modifier = Modifier.padding(4.dp).size(14.dp))
                }
            }
            // mục 66 TECHNICAL_STATUS.md — đối chiếu review: đúng thật là
            // resolvedBackend/routingReason (Models.kt) trước đây chỉ hiện ở
            // RoutingReviewScreen (TRƯỚC khi sinh), GalleryReviewScreen (SAU khi
            // sinh) không hề hiện lại — user duyệt ảnh xong không biết ảnh này
            // chạy Local hay bay lên Remote. Thêm badge góc trái + null-safe
            // (chưa sinh lần nào thì resolvedBackend=null, không hiện gì).
            panel.resolvedBackend?.let { backend ->
                Surface(modifier = Modifier.align(Alignment.TopStart).padding(6.dp),
                    color = if (backend == GenerationBackend.LOCAL) C.BlueDim else C.OrangeDim,
                    shape = RoundedCornerShape(6.dp)) {
                    Text(if (backend == GenerationBackend.LOCAL) "📱 Local" else "☁️ Remote",
                        color = if (backend == GenerationBackend.LOCAL) C.Blue else C.Orange,
                        fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }
            // mục 144 TECHNICAL_STATUS.md — "import ảnh ngoài thay 1 panel".
            // resolvedBackend=null CŨNG dùng cho "chưa sinh lần nào" (xem
            // comment mục 66 phía trên) — phân biệt bằng routingReason
            // (chỉ ảnh import mới có giá trị cố định này, panel chưa sinh có
            // routingReason rỗng).
            if (panel.resolvedBackend == null && panel.routingReason.isNotBlank()) {
                Surface(modifier = Modifier.align(Alignment.TopStart).padding(6.dp),
                    color = C.S0, shape = RoundedCornerShape(6.dp)) {
                    Text("🖼️ Nhập tay", color = C.T2, fontSize = 9.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditPanelSheet(panel: Panel, vm: MainViewModel, nav: NavController, onDismiss: () -> Unit) {
    var showPanelSettings by remember { mutableStateOf(false) }
    val isGenerating by vm.isGenerating.collectAsState()
    val story by vm.currentStory.collectAsState()

    // ── Setting riêng ảnh này (tầng "riêng") — TẤT CẢ thông số sinh ảnh
    // gộp chung 1 chỗ (prompt, negative, nhân vật, tư thế, steps, cfg,
    // width/height, seed) — khởi tạo từ override đã lưu (nếu có), fallback
    // về giá trị hiện tại của panel/tầng chung để người xem thấy đúng cái
    // ĐANG dùng, không phải ô trống.
    val ov = panel.overrideSettings
    val globalSettings by vm.settings.collectAsState()
    var promptOverride by remember(panel.index) { mutableStateOf(ov?.promptOverride ?: panel.prompt) }
    // TRƯỚC: khởi tạo rỗng, placeholder ghi "để trống = dùng chung" — SAI,
    // vì cái thực sự dùng khi không override là panel.negativePrompt (LLM
    // tự sinh riêng cho panel này, xem LLMParser.buildPrompt) + style
    // negative, không phải "chung" chung chung. Giờ hiện đúng gợi ý LLM để
    // người dùng THẤY và sửa trực tiếp, thay vì đoán mù hoặc để trống.
    var negOverride by remember(panel.index) { mutableStateOf(ov?.negativePrompt ?: panel.negativePrompt) }
    var charOverride by remember(panel.index) { mutableStateOf(ov?.characterOverride ?: panel.scene.characters.firstOrNull() ?: "") }
    var poseTemplateOverride by remember(panel.index) { mutableStateOf(ov?.poseTemplate ?: "") }
    var poseAngleOverride by remember(panel.index) { mutableStateOf(ov?.poseAngle ?: "any") }
    var widthOverride by remember(panel.index) { mutableStateOf((ov?.width ?: globalSettings.width).toFloat()) }
    var heightOverride by remember(panel.index) { mutableStateOf((ov?.height ?: globalSettings.height).toFloat()) }
    var stepsOverride by remember(panel.index) { mutableStateOf((ov?.steps ?: globalSettings.steps).toFloat()) }
    var cfgOverride by remember(panel.index) { mutableStateOf(ov?.cfgScale ?: globalSettings.cfgScale) }
    var seedText by remember(panel.index) { mutableStateOf(ov?.seed?.toString() ?: "") }
    // mục 88 TECHNICAL_STATUS.md — canvas kéo-thả Regional Prompting.
    // Khởi tạo từ override đã lưu nếu có, ngược lại = thứ tự GỐC
    // panel.scene.characters (đúng hành vi mặc định trước mục 88).
    var regionalOrder by remember(panel.index) {
        mutableStateOf(ov?.regionalColumnOrder ?: panel.scene.characters)
    }
    var regionalPromptOverrides by remember(panel.index) {
        mutableStateOf(ov?.regionalPromptOverrides ?: emptyMap())
    }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = C.S1) {
        Column(Modifier.fillMaxWidth().padding(16.dp).verticalScroll(rememberScrollState())) {
            Text("Panel ${panel.index + 1}", color = C.T1, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Text(panel.scene.description, color = C.T2, fontSize = 13.sp, lineHeight = 18.sp)

            // mục 66 TECHNICAL_STATUS.md — chi tiết đầy đủ backend + lý do
            // routing (ngắn gọn chỉ có badge ở PanelCard, đây là bản đầy đủ).
            if (panel.resolvedBackend != null) {
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (panel.resolvedBackend == GenerationBackend.LOCAL) "📱 Đã sinh: Local (điện thoại)" else "☁️ Đã sinh: Remote (GPU cloud)",
                        color = if (panel.resolvedBackend == GenerationBackend.LOCAL) C.Blue else C.Orange,
                        fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                if (panel.routingReason.isNotBlank()) {
                    Text(panel.routingReason, color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                }
            } else if (panel.routingReason.isNotBlank()) {
                // mục 144 — panel đã IMPORT ẢNH TAY (không phải Local/Remote nào
                // cả), xem MangaPipeline.importPanelImage().
                Spacer(Modifier.height(6.dp))
                Text("🖼️ ${panel.routingReason}", color = C.T2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }

            // mục 144 TECHNICAL_STATUS.md — "import ảnh ngoài thay 1 panel"
            // (thay vì để AI sinh — vd artist vẽ tay 1 khung, muốn chèn thẳng).
            // Bỏ qua generatePanel() hoàn toàn — xem
            // MangaPipeline.importPanelImage() cho cách xử lý crop tỷ lệ +
            // resolvedBackend/routingReason/Quality Gate = "N/A".
            run {
                val importBusy by vm.importPanelBusy.collectAsState()
                val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) vm.importPanelImage(panel.index, uri)
                }
                Spacer(Modifier.height(8.dp))
                MlOutlineBtn(
                    if (importBusy) "Đang import..." else "🖼️ Import ảnh ngoài thay panel này",
                    onClick = { pickImage.launch(arrayOf("image/*")) },
                    enabled = !importBusy && !isGenerating
                )
                Text(
                    "Dùng khi bạn đã có ảnh vẽ tay/lấy từ nơi khác cho khung này — ảnh sẽ được " +
                    "cắt giữa (center-crop) về đúng tỷ lệ ${globalSettings.width}x${globalSettings.height}, " +
                    "bỏ qua bước AI sinh ảnh. Vẫn qua được upscale/auto-fix bình thường ở bước sau.",
                    color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
                )
            }

            Spacer(Modifier.height(14.dp))
            // mục 140 TECHNICAL_STATUS.md — SỬA BUG NGHIÊM TRỌNG: TRƯỚC ĐÂY
            // ô này chỉ hiện chữ "[preview ảnh 512px]" — KHÔNG hiện ảnh
            // thật, dù đây là màn hình user quyết định duyệt/sửa/từ chối 1
            // panel cụ thể (không xem được ảnh thì không thể quyết định
            // đúng). Dùng ĐÚNG AsyncImage đã có sẵn pattern trong file này.
            // mục 141 — size(800,800) đủ nét cho preview lớn (khác 200x200
            // của thumbnail lưới ở PanelCard) nhưng vẫn tránh decode full
            // ảnh 2048px sau upscale 4x — cùng lý do RAM/hiệu năng.
            val previewPath = panel.upscaledPath ?: panel.imagePath
            Surface(modifier = Modifier.fillMaxWidth().aspectRatio(1f), color = C.S0, shape = RoundedCornerShape(12.dp)) {
                if (previewPath != null) {
                    val previewContext = androidx.compose.ui.platform.LocalContext.current
                    val previewRequest = remember(previewPath) {
                        coil.request.ImageRequest.Builder(previewContext)
                            .data(java.io.File(previewPath))
                            .size(800, 800)
                            .crossfade(true)
                            .build()
                    }
                    coil.compose.AsyncImage(
                        model = previewRequest, contentDescription = "Panel ${panel.index + 1}",
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit
                    )
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Panel này chưa có ảnh (chưa sinh lần nào)", color = C.T3, fontSize = 13.sp)
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // ── Kịch bản LLM cho panel này — hiện ra để người dùng xem
            // trước khi quyết định có cần sửa gì không.
            Surface(modifier = Modifier.fillMaxWidth(), color = C.S0, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, C.Border)) {
                Column(Modifier.padding(12.dp)) {
                    MlLabel("kịch bản LLM tạo cho panel này")
                    Spacer(Modifier.height(6.dp))
                    SceneField("Mô tả cảnh", panel.scene.description)
                    SceneField("Hành động", panel.scene.action)
                    SceneField("Bối cảnh", panel.scene.setting)
                    SceneField("Tâm trạng", panel.scene.mood)
                    SceneField("Góc máy", panel.scene.cameraAngle)
                    SceneField("Nhân vật", panel.scene.characters.joinToString(", "))
                }
            }

            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MlBtn("✓ Duyệt", onClick = { vm.approvePanel(panel.index); onDismiss() },
                    icon = Icons.Default.Check, modifier = Modifier.weight(1f))
                MlOutlineBtn(
                    text = if (showPanelSettings) "Ẩn cài đặt" else "⚙️ Sửa prompt / cài đặt riêng",
                    onClick = { showPanelSettings = !showPanelSettings }, modifier = Modifier.weight(1f)
                )
            }

            if (showPanelSettings) {
                Spacer(Modifier.height(10.dp))
                Surface(modifier = Modifier.fillMaxWidth(), color = C.S0, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, C.Border)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Mọi thông số dưới đây do LLM/setting chung tự đặt — SỬA THOẢI MÁI nếu " +
                            "không ưng ý. Setting riêng ảnh này ƯU TIÊN hơn setting chung. " +
                            "Không có LoRA ở đây — LoRA chỉ đổi được qua chọn nhân vật đã convert riêng.",
                            color = C.T3, fontSize = 10.sp, lineHeight = 14.sp)
                        Spacer(Modifier.height(10.dp))

                        Spacer(Modifier.height(10.dp))
                        // Mô tả tự nhiên -> LLM dịch sang prompt SD (mục 24
                        // TECHNICAL_STATUS.md) — KHÁC promptOverride (tag SD
                        // gõ tay trực tiếp): đây là câu tiếng Việt tự nhiên,
                        // LLM tự dịch ra rồi HIỆN kết quả vào ô prompt SD bên
                        // dưới để user xem/sửa trước khi lưu — không tự động
                        // áp dụng thẳng, đúng nguyên tắc minh bạch đã theo từ
                        // đầu (không giấu kết quả LLM).
                        var naturalDesc by remember(panel.index) { mutableStateOf(ov?.naturalDescriptionOverride ?: "") }
                        val translating by vm.translating.collectAsState()
                        MlLabel("mô tả tự nhiên (tùy chọn) — LLM dịch sang prompt SD bên dưới")
                        OutlinedTextField(
                            value = naturalDesc, onValueChange = { naturalDesc = it },
                            placeholder = { Text("vd: cận cảnh cô gái mỉm cười dưới mưa, ánh đèn neon", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth().height(60.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                                focusedContainerColor = C.S1, unfocusedContainerColor = C.S1,
                                focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                        )
                        Spacer(Modifier.height(6.dp))
                        MlOutlineBtn(if (translating) "Đang dịch..." else "Dịch qua LLM → điền vào prompt SD dưới",
                            icon = Icons.Default.Translate, enabled = naturalDesc.isNotBlank() && !translating,
                            onClick = {
                                vm.translateNaturalDescription(naturalDesc, PromptStage.TXT2IMG) { result ->
                                    promptOverride = result.positive
                                    if (result.negative.isNotBlank()) negOverride = result.negative
                                }
                            })

                        Spacer(Modifier.height(10.dp))
                        MlLabel("prompt SD (sửa tay nếu LLM tạo không ưng ý)")
                        OutlinedTextField(
                            value = promptOverride, onValueChange = { promptOverride = it },
                            modifier = Modifier.fillMaxWidth().height(90.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                                focusedContainerColor = C.S1, unfocusedContainerColor = C.S1,
                                focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                        )

                        Spacer(Modifier.height(10.dp))
                        MlLabel("negative prompt — LLM đã gợi ý riêng cho panel này, sửa thoải mái")
                        OutlinedTextField(
                            value = negOverride, onValueChange = { negOverride = it },
                            placeholder = { Text("để trống = không dùng negative gì cả", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth().height(70.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                                focusedContainerColor = C.S1, unfocusedContainerColor = C.S1,
                                focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                        )

                        Spacer(Modifier.height(10.dp))
                        MlLabel("nhân vật được NEO danh tính (đổi model nếu đã convert riêng)")
                        if (panel.ipAdapterConflictNames.size >= 2) {
                            Text("⚠ Panel này có ${panel.ipAdapterConflictNames.size} nhân vật CÙNG dùng IP-Adapter " +
                                "(${panel.ipAdapterConflictNames.joinToString(", ")}) — chỉ 1 người được neo ảnh " +
                                "thật, người còn lại chỉ theo mô tả chữ. Convert model ghép LoRA cho cả nhóm " +
                                "(nếu họ có LoRA riêng) để né hẳn giới hạn này, hoặc chọn ai quan trọng hơn ở panel này.",
                                color = C.Orange, fontSize = 10.sp, lineHeight = 13.sp)
                            Spacer(Modifier.height(4.dp))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (story?.characters?.map { it.name } ?: emptyList()).forEach { name ->
                                FilterChip(selected = charOverride == name, onClick = { charOverride = name },
                                    label = { Text(name, fontSize = 11.sp) })
                            }
                        }

                        Spacer(Modifier.height(10.dp))
                        MlLabel("tư thế (từ pose_library.json)")
                        // mục 66 TECHNICAL_STATUS.md — đối chiếu review: đúng thật là
                        // `remember { }` không key khiến danh sách này không refresh
                        // khi quay lại từ PoseEditorScreen (dù về lý thuyết Compose
                        // Navigation mặc định huỷ+tạo lại composable khi back, hành vi
                        // đó KHÔNG đảm bảo chắc chắn tuỳ cấu hình NavHost — sửa theo
                        // hướng CHẮC CHẮN đúng bằng lifecycle observer, không phụ thuộc
                        // giả định về thời điểm recompose). Refetch mỗi khi màn hình
                        // resume (ví dụ quay lại từ pose_editor).
                        val lifecycleOwner = LocalLifecycleOwner.current
                        var poseTemplates by remember { mutableStateOf(vm.storyManager.listPoseTemplateNames()) }
                        DisposableEffect(lifecycleOwner) {
                            val observer = LifecycleEventObserver { _, event ->
                                if (event == Lifecycle.Event.ON_RESUME) {
                                    poseTemplates = vm.storyManager.listPoseTemplateNames()
                                }
                            }
                            lifecycleOwner.lifecycle.addObserver(observer)
                            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
                        }
                        if (panel.suggestedPoseTemplate != null) {
                            Text("LLM gợi ý: \"${panel.suggestedPoseTemplate}\" (góc: ${panel.suggestedPoseAngle})",
                                color = C.T3, fontSize = 10.sp)
                        } else {
                            Text("LLM không tìm thấy template khớp — \"Tự động\" sẽ dò theo tên gần đúng, " +
                                "hoặc dùng dáng đứng mặc định nếu không tìm ra gì.", color = C.T3, fontSize = 10.sp)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = poseTemplateOverride.isBlank(), onClick = { poseTemplateOverride = "" },
                                label = { Text("Tự động", fontSize = 11.sp) })
                            poseTemplates.forEach { t ->
                                FilterChip(selected = poseTemplateOverride == t, onClick = { poseTemplateOverride = t },
                                    label = { Text(t, fontSize = 11.sp) })
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("any", "front", "side_left", "side_right").forEach { a ->
                                FilterChip(selected = poseAngleOverride == a, onClick = { poseAngleOverride = a },
                                    label = { Text(a, fontSize = 11.sp) })
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        MlOutlineBtn("✏️ Vẽ / sửa khung xương (mở trang riêng, tự lưu vào kho dùng chung)",
                            onClick = { nav.navigate("pose_editor") })

                        Spacer(Modifier.height(10.dp))
                        MlLabel("kích thước: ${widthOverride.toInt()}×${heightOverride.toInt()}")
                        Slider(value = widthOverride, onValueChange = { widthOverride = it }, valueRange = 384f..768f, steps = 7,
                            colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                        Slider(value = heightOverride, onValueChange = { heightOverride = it }, valueRange = 384f..768f, steps = 7,
                            colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))

                        MlLabel("steps: ${stepsOverride.toInt()}")
                        Slider(value = stepsOverride, onValueChange = { stepsOverride = it }, valueRange = 10f..40f,
                            colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                        MlLabel("CFG: %.1f".format(cfgOverride))
                        Slider(value = cfgOverride, onValueChange = { cfgOverride = it }, valueRange = 3f..12f,
                            colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))

                        Spacer(Modifier.height(10.dp))
                        MlLabel("seed (để trống = tự chọn theo nhân vật)")
                        OutlinedTextField(
                            value = seedText, onValueChange = { seedText = it.filter { c -> c.isDigit() } },
                            placeholder = { Text("vd: 123456", fontSize = 11.sp) }, singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                                focusedContainerColor = C.S1, unfocusedContainerColor = C.S1,
                                focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                        )

                        // mục 88 TECHNICAL_STATUS.md — canvas kéo-thả Regional
                        // Prompting, CHỈ hiện khi scene có 2-4 nhân vật (đúng
                        // điều kiện `useRegional` ở MangaPipeline.kt — dưới 2
                        // hoặc trên 4 người, model regional không tồn tại/không
                        // dùng nhánh này, hiện editor ra cũng vô tác dụng nên
                        // ẩn hẳn thay vì hiện editor "chết"). KHÔNG kiểm tra
                        // thêm điều kiện `storyManager.hasRegionalUnet()` ở đây
                        // vì cần load Story đầy đủ — chấp nhận hiện editor cho
                        // vài trường hợp scene 2-4 người nhưng chưa convert
                        // model regional (khi đó MangaPipeline tự rơi về nhánh
                        // khác, override này đơn giản không có tác dụng, không
                        // gây lỗi gì — an toàn hơn là ẩn nhầm cả trường hợp hợp
                        // lệ vì phải đoán trạng thái model từ UI).
                        if (panel.scene.characters.size in 2..4) {
                            Spacer(Modifier.height(14.dp))
                            Divider(color = C.Border)
                            Spacer(Modifier.height(14.dp))
                            MlLabel("regional prompting — canvas kéo-thả (chỉ có tác dụng nếu panel này thật sự dùng nhánh Regional Prompting)")
                            RegionalColumnEditor(
                                order = regionalOrder,
                                onOrderChange = { regionalOrder = it },
                                promptOverrides = regionalPromptOverrides,
                                onPromptOverrideChange = { name, text ->
                                    regionalPromptOverrides = regionalPromptOverrides.toMutableMap().apply {
                                        if (text.isBlank()) remove(name) else put(name, text)
                                    }
                                },
                                autoPromptFor = { name ->
                                    val ch = story?.characters?.find { it.name == name }
                                    (ch?.anchorPrompt?.let { "$it, " } ?: "") + promptOverride + ", ..."
                                }
                            )
                        }

                        Spacer(Modifier.height(14.dp))
                        Divider(color = C.Border)
                        Spacer(Modifier.height(14.dp))

                        // mục 107 TECHNICAL_STATUS.md — "So sánh thử" Pose/Depth/Decay
                        // cho ĐÚNG panel này (khác mục 93 dùng mô tả tự do — ở đây
                        // dùng ảnh nhân vật + skeleton THẬT của panel). CHỈ hiện nếu
                        // panel có ít nhất 1 nhân vật (mọi panel thật đều có, nhưng
                        // runConditioningComparisonTest() có thể trả null nếu không
                        // ai có anchorImagePath — xử lý qua _error, không cần check
                        // điều kiện phức tạp ở đây, để MangaPipeline tự quyết).
                        MlLabel("🎯 so sánh thử: preset tự động vs cài đặt chung (mục 107)")
                        Text("Sinh 2 ảnh 384×384 nhanh, CÙNG seed, chỉ khác 6 tham số Pose/Depth/Decay — " +
                            "để tự mắt chọn thay vì đoán số. Chỉ áp dụng đường sinh 1-nhân-vật.",
                            color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
                        Spacer(Modifier.height(6.dp))
                        val isRunningCondTest by vm.isRunningConditioningTest.collectAsState()
                        MlOutlineBtn(
                            if (isRunningCondTest) "Đang chạy thử..." else "🔬 So sánh thử",
                            icon = Icons.Default.Refresh,
                            enabled = !isRunningCondTest,
                            onClick = { vm.runConditioningComparisonTest(panel) }
                        )
                        val condTestResult by vm.conditioningTestResult.collectAsState()
                        condTestResult?.let { r ->
                            Spacer(Modifier.height(10.dp))
                            Text("action_category dùng để tra preset tự động: ${r.actionCategoryUsed ?: "không nhận diện được (dùng neutral)"}",
                                color = C.T3, fontSize = 10.sp)
                            Spacer(Modifier.height(6.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text("Tự động (preset)", color = C.T2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    Box(Modifier.fillMaxWidth().aspectRatio(1f).background(C.S0, RoundedCornerShape(8.dp)).clip(RoundedCornerShape(8.dp))) {
                                        coil.compose.AsyncImage(model = java.io.File(r.autoImagePath), contentDescription = null, modifier = Modifier.fillMaxSize())
                                    }
                                    MlBtn(text = "Chọn bản này", icon = Icons.Default.Refresh, onClick = {
                                        vm.applyConditioningChoice(panel.index, r.autoPreset)
                                    })
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("Cài đặt chung", color = C.T2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    Box(Modifier.fillMaxWidth().aspectRatio(1f).background(C.S0, RoundedCornerShape(8.dp)).clip(RoundedCornerShape(8.dp))) {
                                        coil.compose.AsyncImage(model = java.io.File(r.globalImagePath), contentDescription = null, modifier = Modifier.fillMaxSize())
                                    }
                                    MlBtn(text = "Chọn bản này", icon = Icons.Default.Refresh, onClick = {
                                        vm.applyConditioningChoice(panel.index, r.globalPreset)
                                    })
                                }
                            }
                        }

                        Spacer(Modifier.height(12.dp))
                        MlBtn(
                            text = "🔄 Áp dụng + Tạo lại ảnh này",
                            icon = Icons.Default.Refresh,
                            onClick = {
                                vm.regeneratePanel(panel.index, overrides = PanelOverrideSettings(
                                    promptOverride = promptOverride.ifBlank { null }.let { if (it == panel.prompt) null else it },
                                    naturalDescriptionOverride = naturalDesc.ifBlank { null },
                                    // Không dùng .ifBlank{null}: nếu người dùng CỐ TÌNH xoá trắng ô này,
                                    // họ muốn KHÔNG có negative gì cả, khác với "không đổi gì" (giữ
                                    // nguyên gợi ý LLM). Chỉ collapse về null khi giá trị y hệt gợi ý
                                    // gốc của LLM (nghĩa là user không sửa, không cần đóng băng override).
                                    negativePrompt = if (negOverride == panel.negativePrompt) null else negOverride,
                                    characterOverride = charOverride.ifBlank { null },
                                    poseTemplate = poseTemplateOverride.ifBlank { null },
                                    poseAngle = poseAngleOverride,
                                    width = widthOverride.toInt(), height = heightOverride.toInt(),
                                    steps = stepsOverride.toInt(), cfgScale = cfgOverride,
                                    seed = seedText.toLongOrNull(),
                                    // null khi = thứ tự gốc (không cần lưu override thừa) —
                                    // giữ đúng bất biến "null = mặc định" như mọi field khác.
                                    regionalColumnOrder = regionalOrder.takeIf { it != panel.scene.characters },
                                    regionalPromptOverrides = regionalPromptOverrides
                                ))
                                showPanelSettings = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Divider(color = C.Border)
            Spacer(Modifier.height(14.dp))

            MlLabel("hội thoại trong panel này")
            if (panel.scene.dialogue.isEmpty()) {
                Text("Không có hội thoại được trích xuất", color = C.T3, fontSize = 12.sp)
            } else {
                panel.scene.dialogue.forEach { d ->
                    Row(Modifier.padding(vertical = 4.dp)) {
                        Text("${d.characterName}: ", color = C.Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(d.text, color = C.T2, fontSize = 12.sp)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SceneField(label: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.padding(vertical = 2.dp)) {
        Text("$label: ", color = C.T3, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Text(value, color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
    }
}
