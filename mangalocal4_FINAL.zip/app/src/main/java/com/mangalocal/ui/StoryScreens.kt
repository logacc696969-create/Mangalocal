package com.mangalocal.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*
import com.mangalocal.pipeline.ConceptDictionary
import com.mangalocal.pipeline.ExternalScriptImport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ── STORY LIST ────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryListScreen(nav: NavController, vm: MainViewModel) {
    val stories by vm.stories.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newDesc by remember { mutableStateOf("") }
    var newStyle by remember { mutableStateOf(ImageStyle.REALISTIC) }
    // Quy tắc bối cảnh chung (mục 24 TECHNICAL_STATUS.md) — LLM dùng làm
    // ngữ cảnh nền khi dịch mô tả cảnh sang prompt SD1.5, áp dụng CẢ 3 giai
    // đoạn (txt2img/upscale-redraw/inpaint).
    var newWorldRules by remember { mutableStateOf("") }
    // Ghi chú cách viết tag cho checkpoint SD1.5 đang dùng (mục 54
    // TECHNICAL_STATUS.md — KHÁC worldRules ở trên: đây là PHONG CÁCH VIẾT
    // TAG, vd "checkpoint này thích tag danbooru", không phải bối cảnh
    // truyện). Field đã có sẵn trong model Story + đã nối tới LLMParser từ
    // trước (mục 54) nhưng CHƯA có ô nhập UI nào — thêm ở đây, theo đúng
    // pattern newWorldRules ngay trên.
    var newPromptGuideNotes by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("MangaLocal", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("v3 · Multi-story", color = C.T3, fontSize = 10.sp)
                }
            }, actions = {
                // mục 155 TECHNICAL_STATUS.md — nút Trợ giúp ngay từ màn đầu
                // tiên user thấy (trước khi tạo truyện nào) — dễ tìm nhất có
                // thể cho người mới dùng lần đầu.
                IconButton(onClick = { nav.navigate("help") }) {
                    Icon(Icons.Default.Help, "Trợ giúp", tint = C.T2)
                }
                IconButton(onClick = { showNew = !showNew }) {
                    Icon(if (showNew) Icons.Default.Close else Icons.Default.Add, null, tint = C.Blue)
                }
            }, colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        bottomBar = { AppNavBar(nav, "stories") },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            if (showNew) item {
                MlCard {
                    MlLabel("tạo truyện mới")
                    OutlinedTextField(value = newTitle, onValueChange = { newTitle = it },
                        label = { Text("Tên truyện", fontSize = 12.sp) }, modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                            focusedTextColor = C.T1, unfocusedTextColor = C.T1), singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newDesc, onValueChange = { newDesc = it },
                        label = { Text("Mô tả (tùy chọn)", fontSize = 12.sp) }, modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                            focusedTextColor = C.T1, unfocusedTextColor = C.T1))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newWorldRules, onValueChange = { newWorldRules = it },
                        label = { Text("Quy tắc bối cảnh chung (tùy chọn — LLM dùng khi dịch mọi prompt: text2img/upscale/inpaint)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 70.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                            focusedTextColor = C.T1, unfocusedTextColor = C.T1))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newPromptGuideNotes, onValueChange = { newPromptGuideNotes = it },
                        label = { Text("Ghi chú cách viết tag SD1.5 (tùy chọn — vd \"thích tag kiểu danbooru\", \"luôn thêm 'watercolor style'\" — khác quy tắc bối cảnh ở trên, đây là PHONG CÁCH VIẾT TAG cho checkpoint đang dùng)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 70.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                            focusedTextColor = C.T1, unfocusedTextColor = C.T1))
                    Spacer(Modifier.height(8.dp))
                    Text("Style mặc định", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(ImageStyle.values()) { style ->
                            val sel = newStyle == style
                            Surface(onClick = { newStyle = style },
                                color = if (sel) C.BlueDim else C.S0, shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (sel) C.Blue else C.Border)) {
                                Text("${style.emoji} ${style.label}", color = if (sel) C.Blue else C.T2,
                                    fontSize = 11.sp, modifier = Modifier.padding(10.dp, 7.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    MlBtn("Tạo truyện", icon = Icons.Default.Add, enabled = newTitle.isNotBlank(),
                        onClick = {
                            vm.createStory(newTitle, newDesc, newStyle, newWorldRules, newPromptGuideNotes)
                            newTitle = ""; newDesc = ""; newWorldRules = ""; newPromptGuideNotes = ""; showNew = false
                            nav.navigate("story_detail")
                        })
                }
            }

            if (stories.isEmpty() && !showNew) item {
                Box(Modifier.fillMaxWidth().padding(top = 60.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("📚", fontSize = 48.sp)
                        Text("Chưa có truyện nào", color = C.T3, fontSize = 15.sp)
                        MlBtn("Tạo truyện đầu tiên", onClick = { showNew = true }, modifier = Modifier.width(200.dp))
                    }
                }
            }

            items(stories) { story ->
                MlCard(modifier = Modifier.clickable {
                    vm.selectStory(story); nav.navigate("story_detail")
                }) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(story.style.emoji, fontSize = 28.sp)
                        Column(Modifier.weight(1f)) {
                            Text(story.title, color = C.T1, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("${story.chapterIds.size} chương · ${story.characters.size} nhân vật",
                                color = C.T3, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = C.T3)
                    }
                }
            }
        }
    }
}

// ── STORY DETAIL ──────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryDetailScreen(nav: NavController, vm: MainViewModel) {
    val story by vm.currentStory.collectAsState()
    val chapters = remember(story) { story?.let { vm.storyManager.loadAllChapters(it.id) } ?: emptyList() }
    var storyText by remember { mutableStateOf("") }
    val isGenerating by vm.isGenerating.collectAsState()
    val isPreparing by vm.isPreparing.collectAsState()
    val isAnalyzingCharacters by vm.isAnalyzingCharacters.collectAsState()
    val pendingCharSummary by vm.pendingCharacterSummary.collectAsState()
    // mục 70/142 TECHNICAL_STATUS.md — HOISTED ra ngoài LazyColumn: các lời
    // gọi @Composable (collectAsState/remember/LaunchedEffect) này TRƯỚC ĐÂY
    // nằm thẳng trong nội dung LazyColumn (LazyListScope.() -> Unit — KHÔNG
    // phải ngữ cảnh @Composable, chỉ item{} bên trong mới là) — lỗi build
    // thật "@Composable invocations can only happen from the context of a
    // @Composable function". Chuyển lên đây (ngữ cảnh @Composable đúng của
    // hàm StoryDetailScreen), dùng lại giá trị bên trong LazyColumn phía dưới.
    val detected by vm.detectedChapters.collectAsState()
    val isBatchRunning by vm.isBatchRunning.collectAsState()
    val batchProgress by vm.batchProgress.collectAsState()
    val batchFailedChapters by vm.batchFailedChapters.collectAsState()
    var resumable by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    LaunchedEffect(Unit) { resumable = vm.peekResumableBatch() }

    // SỬA (yêu cầu duyệt routing local/remote trước khi sinh ảnh): bấm "Sinh
    // panel" giờ chỉ PHÂN TÍCH kịch bản trước (isPreparing) -> qua màn hình
    // duyệt routing_review -> user xác nhận (hoặc sửa tay) mới THẬT SỰ sinh
    // ảnh (isGenerating) -> qua màn hình generating như cũ.
    LaunchedEffect(isPreparing) { if (isPreparing) nav.navigate("routing_review") }
    LaunchedEffect(isGenerating) { if (isGenerating) nav.navigate("generating") }
    // mục 154 TECHNICAL_STATUS.md — "đảo pipeline nhân vật": nếu bước phân
    // tích sơ bộ phát hiện nhân vật MỚI, dừng lại ở màn xác nhận TRƯỚC khi
    // vào routing_review (không navigate nếu rỗng — case phổ biến "không có
    // gì mới" tự chảy thẳng vào isPreparing→routing_review như cũ, không
    // qua màn này).
    LaunchedEffect(pendingCharSummary) { if (pendingCharSummary != null) nav.navigate("character_summary_review") }

    if (story == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Đang tải...", color = C.T3) }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(story!!.title, fontSize = 16.sp) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { nav.navigate("characters_detail") }) {
                        Icon(Icons.Default.People, null, tint = C.Blue)
                    }
                    // mục 66 TECHNICAL_STATUS.md — đối chiếu review: đúng thật là
                    // updateWorldRules()/updatePromptGuideNotes() có sẵn trong
                    // ViewModel từ mục 14/54 nhưng chưa có UI nào gọi sau khi
                    // truyện đã tạo (chỉ nhập được lúc tạo mới). Thêm nút này.
                    var showEditStorySheet by remember { mutableStateOf(false) }
                    IconButton(onClick = { showEditStorySheet = true }) {
                        Icon(Icons.Default.Edit, null, tint = C.T2)
                    }
                    if (showEditStorySheet) {
                        EditStoryRulesSheet(story = story!!, vm = vm, onDismiss = { showEditStorySheet = false })
                    }
                    // mục 68 TECHNICAL_STATUS.md — đối chiếu review: đúng là
                    // UI xuất dataset (ảnh panel + caption chuẩn để train LoRA
                    // trên máy tính, mục 9 lịch sử) chưa hề có, kể cả tầng dữ
                    // liệu. Thêm nút này + StoryManager.exportDataset() (mới).
                    var showExportSheet by remember { mutableStateOf(false) }
                    IconButton(onClick = { showExportSheet = true }) {
                        Icon(Icons.Default.Share, null, tint = C.T2)
                    }
                    if (showExportSheet) {
                        ExportDatasetSheet(story = story!!, vm = vm, onDismiss = { showExportSheet = false })
                    }
                    // mục 78 TECHNICAL_STATUS.md — UI Concept Dictionary,
                    // đóng gap "CHƯA CÓ UI" đã ghi trong tài liệu (trước đó
                    // ConceptDictionary.kt đã nối dây thật vào LLMParser
                    // nhưng chỉ sửa được bằng cách sửa tay file JSON).
                    var showConceptDictSheet by remember { mutableStateOf(false) }
                    IconButton(onClick = { showConceptDictSheet = true }) {
                        Icon(Icons.Default.MenuBook, null, tint = C.T2)
                    }
                    if (showConceptDictSheet) {
                        ConceptDictionarySheet(story = story!!, vm = vm, onDismiss = { showConceptDictSheet = false })
                    }
                    // mục 155 TECHNICAL_STATUS.md — nút Trợ giúp, dẫn tới màn
                    // HelpScreen (bản rút gọn HUONG_DAN_SU_DUNG.md, thiết kế
                    // mobile: card gập/mở, đúng pattern "Hướng dẫn đặt model"
                    // đã có sẵn trong SettingsScreen.kt).
                    IconButton(onClick = { nav.navigate("help") }) {
                        Icon(Icons.Default.Help, "Trợ giúp", tint = C.T2)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            // mục 71 TECHNICAL_STATUS.md — Model Binding. Hiện model đã khoá
            // + nút đổi tường minh (KHÔNG có migration tự động convert lại
            // panel cũ — xem cảnh báo trong dialog bên dưới).
            story!!.boundSdModelId?.let { boundId ->
                item {
                    var showRebindDialog by remember { mutableStateOf(false) }
                    MlCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, null, tint = C.T3, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Model đã khoá cho truyện này", color = C.T2, fontSize = 11.sp)
                                Text(boundId, color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            TextButton(onClick = { showRebindDialog = true }) { Text("Đổi", color = C.Orange, fontSize = 12.sp) }
                        }
                    }
                    if (showRebindDialog) {
                        val models = remember { vm.storyManager.listConvertedModels() }
                        AlertDialog(
                            onDismissRequest = { showRebindDialog = false },
                            title = { Text("Đổi model khoá?", color = C.T1) },
                            text = {
                                Column {
                                    Text("⚠️ Panel CŨ đã sinh sẽ giữ nguyên, KHÔNG tự vẽ lại. Phong cách chương mới sẽ khác chương cũ. Chỉ đổi nếu bạn CHỦ Ý muốn vậy (ví dụ nâng cấp checkpoint giữa chừng).",
                                        color = C.Orange, fontSize = 12.sp, lineHeight = 16.sp)
                                    Spacer(Modifier.height(10.dp))
                                    models.forEach { m ->
                                        TextButton(onClick = { vm.rebindStoryModel(m.id); showRebindDialog = false }) {
                                            Text(m.display_name, color = C.T1, fontSize = 13.sp)
                                        }
                                    }
                                }
                            },
                            confirmButton = { TextButton(onClick = { showRebindDialog = false }) { Text("Huỷ", color = C.T2) } },
                            containerColor = C.S1
                        )
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("${chapters.size}", "chương", Modifier.weight(1f))
                    StatCard("${story!!.characters.size}", "nhân vật", Modifier.weight(1f))
                    StatCard(story!!.style.emoji, "style", Modifier.weight(1f))
                }
            }

            item {
                MlCard {
                    MlLabel("viết chương mới")
                    OutlinedTextField(value = storyText, onValueChange = { storyText = it; vm.analyzeStoryText(it) },
                        modifier = Modifier.fillMaxWidth().height(140.dp),
                        placeholder = { Text("Dán nội dung chương vào đây... (dán cả truyện nhiều chương cũng được, app tự phát hiện)", color = C.T3, fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                            focusedContainerColor = C.S0, unfocusedContainerColor = C.S0,
                            focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp))
                    Spacer(Modifier.height(10.dp))
                    MlBtn(if (isAnalyzingCharacters) "Đang phân tích nhân vật..." else "✨ Sinh panel",
                        onClick = { vm.analyzeCharactersFirst(storyText) },
                        enabled = storyText.isNotBlank() && !isAnalyzingCharacters)

                    // mục 120 TECHNICAL_STATUS.md — bypass parseStory(): user
                    // đã có kịch bản chia scene sẵn từ LLM ngoài app (dán vào
                    // đây thay vì gõ lại truyện chữ thô). Đặt NGAY DƯỚI nút
                    // chính, không giấu trong menu phụ — đây là thao tác tay
                    // đúng nghĩa (dán JSON, dễ gõ sai), cần dễ tìm thấy.
                    Spacer(Modifier.height(6.dp))
                    var showImportDialog by remember { mutableStateOf(false) }
                    TextButton(onClick = { showImportDialog = true }) {
                        Text("📥 Đã có kịch bản chia sẵn từ LLM ngoài? Dán JSON tại đây",
                            color = C.T3, fontSize = 11.sp)
                    }
                    if (showImportDialog) {
                        ExternalScriptImportDialog(vm = vm, onDismiss = { showImportDialog = false })
                    }
                }
            }

            // mục 70/142 TECHNICAL_STATUS.md — detected/isBatchRunning/
            // batchProgress/batchFailedChapters/resumable đã HOISTED lên
            // đầu hàm StoryDetailScreen (xem comment ở đó) — dùng lại trực
            // tiếp ở đây.
            resumable?.takeIf { !isBatchRunning }?.let { (completedCount, totalCount) ->
                item {
                    MlCard {
                        Text("⏸️ Có lô công nghiệp dở dang: đã xong $completedCount/$totalCount chương",
                            color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("Dán lại ĐÚNG văn bản đã dùng lần trước rồi bấm \"Chạy công nghiệp\" để tiếp tục từ chương ${completedCount + 1} (không chạy lại các chương đã xong).",
                            color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                }
            }
            detected?.let { detectedList ->
                item {
                    MlCard {
                        Text("⚙️ Phát hiện ${detectedList.size} chương trong văn bản này", color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Chạy CÔNG NGHIỆP: xử lý tuần tự cả ${detectedList.size} chương liên tiếp, không dừng lại chờ duyệt routing từng chương (vẫn tự động chọn Local/Remote như bình thường). Hoặc chỉ SINH CHƯƠNG ĐẦU (thủ công, giữ nguyên nút bên trên).",
                            color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MlBtn("Chạy công nghiệp (${detectedList.size} chương)", modifier = Modifier.weight(1f),
                                onClick = { vm.runIndustrialBatch(detectedList) })
                            MlOutlineBtn("Bỏ qua", modifier = Modifier.weight(1f), onClick = { vm.dismissBatchSuggestion() })
                        }
                    }
                }
            }
            if (isBatchRunning) {
                item {
                    MlCard {
                        Text("Đang chạy công nghiệp: ${batchProgress.first}/${batchProgress.second} chương", color = C.T1, fontSize = 13.sp)
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = if (batchProgress.second > 0) batchProgress.first.toFloat() / batchProgress.second else 0f,
                            modifier = Modifier.fillMaxWidth(), color = C.Blue, trackColor = C.Border)
                        // mục 142 — hiện số chương lỗi đã bị bỏ qua (error
                        // shunning) NGAY LÚC ĐANG CHẠY, không cần đợi hết batch
                        // mới biết có chương nào hỏng.
                        if (batchFailedChapters.isNotEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            Text("⚠️ ${batchFailedChapters.size} chương lỗi đã bị bỏ qua, các chương khác vẫn tiếp tục chạy.",
                                color = C.Red, fontSize = 11.sp, lineHeight = 15.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        MlOutlineBtn("Huỷ", onClick = { vm.cancelIndustrialBatch() })
                    }
                }
            }

            if (chapters.isNotEmpty()) item {
                MlCard {
                    MlLabel("các chương (${chapters.size})")
                    chapters.forEach { ch ->
                        Row(Modifier.fillMaxWidth().clickable {
                            vm.selectChapter(ch); nav.navigate("gallery_review")
                        }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(ch.title, color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("${ch.panels.size} panel · ${ch.status.name.lowercase()}", color = C.T3, fontSize = 11.sp)
                            }
                            MlChip(ch.status.name, when (ch.status) {
                                ChapterStatus.DONE -> C.Green; ChapterStatus.REVIEW -> C.Orange
                                else -> C.T2
                            }, when (ch.status) {
                                ChapterStatus.DONE -> C.GreenDim; ChapterStatus.REVIEW -> C.OrangeDim
                                else -> C.S0
                            })
                        }
                        if (ch != chapters.last()) Divider(color = C.Border)
                    }
                }
            }
        }
    }
}

// mục 66 TECHNICAL_STATUS.md — vá gap "updateWorldRules()/updatePromptGuideNotes()
// có sẵn trong ViewModel nhưng chưa có UI gọi sau khi truyện đã tạo". Bottom
// sheet riêng, mở từ nút bút chì trên StoryDetailScreen, giữ đúng label/placeholder
// như lúc tạo mới (dòng ~70-79 ở trên) để nhất quán UX.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditStoryRulesSheet(story: Story, vm: MainViewModel, onDismiss: () -> Unit) {
    var worldRules by remember(story.id) { mutableStateOf(story.worldRules) }
    var promptGuideNotes by remember(story.id) { mutableStateOf(story.promptGuideNotes) }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = C.S1) {
        Column(Modifier.fillMaxWidth().padding(16.dp).verticalScroll(rememberScrollState())) {
            Text("Sửa bối cảnh & phong cách prompt", color = C.T1, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Áp dụng cho các panel sinh SAU thời điểm lưu — panel đã sinh trước đó không tự đổi lại.",
                color = C.T3, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = worldRules, onValueChange = { worldRules = it },
                label = { Text("Quy tắc bối cảnh chung (LLM dùng khi dịch mọi prompt: text2img/upscale/inpaint)", fontSize = 11.sp) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                    focusedTextColor = C.T1, unfocusedTextColor = C.T1))
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = promptGuideNotes, onValueChange = { promptGuideNotes = it },
                label = { Text("Ghi chú cách viết tag SD1.5 (vd \"thích tag kiểu danbooru\" — PHONG CÁCH VIẾT TAG cho checkpoint đang dùng)", fontSize = 11.sp) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                    focusedTextColor = C.T1, unfocusedTextColor = C.T1))
            Spacer(Modifier.height(14.dp))
            MlBtn("Lưu", onClick = {
                vm.updateWorldRules(worldRules)
                vm.updatePromptGuideNotes(promptGuideNotes)
                onDismiss()
            })
            Spacer(Modifier.height(8.dp))
        }
    }
}

// mục 78 TECHNICAL_STATUS.md — UI thêm/sửa/xoá entry Concept Dictionary
// (storyDir/concept_dictionary.json qua ConceptDictionary.kt, mục 78, đã
// nối dây thật vào LLMParser trước đó — sheet này là bước UI còn thiếu).
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConceptDictionarySheet(story: Story, vm: MainViewModel, onDismiss: () -> Unit) {
    // Đọc trực tiếp qua storyManager.storyDir() — ConceptDictionary tự
    // load/lưu file JSON, không cần thêm state riêng trong ViewModel.
    val dict = remember(story.id) { ConceptDictionary(vm.storyManager.storyDir(story.id)) }
    var entries by remember(story.id) { mutableStateOf(dict.getAll().toList()) }
    var newConcept by remember { mutableStateOf("") }
    var newTag by remember { mutableStateOf("") }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = C.S1) {
        Column(Modifier.fillMaxWidth().padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
            Text("📖 Từ điển khái niệm", color = C.T1, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Cặp [tên riêng tiếng Việt → SD tag tiếng Anh] — LLM ưu tiên dùng lại đúng bản này khi dịch " +
                "prompt, tránh dịch cùng 1 khái niệm thành nhiều tag khác nhau qua nhiều chương (mục 78).",
                color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Bật tra cứu từ điển khi sinh prompt", color = C.T1, fontSize = 13.sp)
                }
                Switch(checked = story.conceptDictionaryEnabled,
                    onCheckedChange = { vm.updateStoryConceptDictionaryEnabled(story.id, it) },
                    colors = SwitchDefaults.colors(checkedThumbColor = C.Orange, checkedTrackColor = C.Orange.copy(0.3f)))
            }
            Spacer(Modifier.height(12.dp))
            Divider(color = C.Border)
            Spacer(Modifier.height(12.dp))

            Text("Thêm entry mới", color = C.T2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(value = newConcept, onValueChange = { newConcept = it },
                label = { Text("Tên riêng (vd: Kiếm Bình Thiên Hạ)", fontSize = 11.sp) },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                    focusedTextColor = C.T1, unfocusedTextColor = C.T1))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = newTag, onValueChange = { newTag = it },
                label = { Text("SD tag (vd: legendary straight sword, golden blade)", fontSize = 11.sp) },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                    focusedTextColor = C.T1, unfocusedTextColor = C.T1))
            Spacer(Modifier.height(8.dp))
            MlBtn("+ Thêm", onClick = {
                if (newConcept.isNotBlank() && newTag.isNotBlank()) {
                    dict.put(newConcept, newTag)
                    entries = dict.getAll().toList()
                    newConcept = ""; newTag = ""
                }
            })

            Spacer(Modifier.height(14.dp))
            Divider(color = C.Border)
            Spacer(Modifier.height(10.dp))
            Text("Đã có ${entries.size} entry" + if (entries.size > 30) " (chỉ 30 đầu tiên được gửi cho LLM mỗi lần — mục 78)" else "",
                color = C.T3, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))

            if (entries.isEmpty()) {
                Text("Chưa có entry nào — thêm ở trên, hoặc để trống nếu chưa cần (không có tác dụng phụ).",
                    color = C.T3, fontSize = 11.sp)
            }
            entries.forEach { (concept, tag) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(concept, color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(tag, color = C.T3, fontSize = 11.sp, lineHeight = 14.sp)
                    }
                    IconButton(onClick = {
                        dict.remove(concept)
                        entries = dict.getAll().toList()
                    }) { Icon(Icons.Default.Delete, null, tint = C.T3, modifier = Modifier.size(18.dp)) }
                }
                Divider(color = C.Border.copy(0.5f))
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
// Chọn "Tất cả" hoặc 1 nhân vật cụ thể -> nén .zip (ảnh .png + caption .txt
// cùng tên/panel, chuẩn kohya_ss/sd-scripts) -> mở share sheet Android
// ngay (FileProvider — đã nằm sẵn trong phạm vi file_paths.xml, không cần
// khai báo path riêng, xem StoryManager.exportDataset() để biết vì sao).
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExportDatasetSheet(story: Story, vm: MainViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var exporting by remember { mutableStateOf(false) }
    var resultMsg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun doExport(characterName: String?) {
        exporting = true; resultMsg = null
        scope.launch(Dispatchers.IO) {
            val zip = try { vm.storyManager.exportDataset(story.id, characterName) } catch (e: Exception) { null }
            withContext(Dispatchers.Main) {
                exporting = false
                if (zip == null) {
                    resultMsg = "Không có panel nào đã duyệt xong" +
                        (if (characterName != null) " của \"$characterName\"" else "") + " để xuất."
                } else {
                    try {
                        val uri = androidx.core.content.FileProvider.getUriForFile(
                            context, "${context.packageName}.provider", zip)
                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "application/zip"
                            putExtra(android.content.Intent.EXTRA_STREAM, uri)
                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(android.content.Intent.createChooser(intent, "Chia sẻ dataset"))
                        onDismiss()
                    } catch (e: Exception) {
                        resultMsg = "Đã tạo file (${zip.absolutePath}) nhưng không mở được hộp thoại chia sẻ: ${e.message}"
                    }
                }
            }
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = C.S1) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Xuất dataset (ảnh + caption train LoRA)", color = C.T1, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Gom các panel ĐÃ DUYỆT thành cặp ảnh.png + ảnh.txt (caption = đúng prompt SD đã dùng), nén .zip, đúng chuẩn kohya_ss/sd-scripts. Panel bị từ chối (REJECTED) không được gộp vào.",
                color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
            Spacer(Modifier.height(14.dp))
            if (exporting) {
                CircularProgressIndicator(color = C.Blue, modifier = Modifier.size(24.dp))
            } else {
                MlBtn("Xuất TẤT CẢ panel của truyện", onClick = { doExport(null) })
                Spacer(Modifier.height(8.dp))
                if (story.characters.isNotEmpty()) {
                    Text("Hoặc xuất riêng theo nhân vật:", color = C.T2, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(story.characters) { ch ->
                            FilterChip(selected = false, onClick = { doExport(ch.name) },
                                label = { Text(ch.name.take(16), fontSize = 11.sp) })
                        }
                    }
                }
            }
            resultMsg?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, color = C.Orange, fontSize = 11.sp, lineHeight = 15.sp)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

// mục 120 TECHNICAL_STATUS.md — dán JSON kịch bản đã chia scene sẵn từ LLM
// ngoài app (ChatGPT/Claude dùng trên web...), bypass LLMParser.parseStory()
// nội bộ. Thiết kế 2 bước rõ ràng cho thao tác tay trên di động: (1) dán +
// XEM TRƯỚC (đếm scene, báo lỗi JSON RÕ RÀNG trước khi tốn LLM+SD compute
// thật) — (2) mới xác nhận chạy. Có nút "Copy mẫu JSON" để user gửi thẳng
// cho LLM ngoài làm khung yêu cầu định dạng, không phải tự nhớ/gõ tay.
//
// mục 141 TECHNICAL_STATUS.md — ĐỔI từ AlertDialog sang ModalBottomSheet
// (theo yêu cầu tối ưu UX di động): AlertDialog co hẹp giữa màn hình,
// `heightIn(max = 480.dp)` không tận dụng hết chiều cao khả dụng — với 1 ô
// nhập JSON dài (dán từ ChatGPT, có thể vài KB text), user phải cuộn nhiều
// trong 1 khung nhỏ. ModalBottomSheet trượt từ dưới lên, chiếm gần hết màn
// hình khi cần — ĐÚNG pattern đã dùng cho MỌI sheet sửa tay khác trong dự
// án (EditPanelSheet, EditStoryRulesSheet...), nhất quán UX toàn app.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExternalScriptImportDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var jsonText by remember { mutableStateOf("") }
    var previewError by remember { mutableStateOf<String?>(null) }
    var previewSceneCount by remember { mutableStateOf<Int?>(null) }
    val clipboard = LocalClipboardManager.current

    fun runPreview() {
        previewError = null
        previewSceneCount = null
        try {
            val parsed = ExternalScriptImport.parseFromRawJson(jsonText)
            previewSceneCount = parsed.scenes.size
        } catch (e: IllegalArgumentException) {
            previewError = e.message
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = C.S1) {
        Column(Modifier.fillMaxWidth().padding(16.dp).verticalScroll(rememberScrollState())) {
            Text("Import kịch bản từ LLM ngoài", color = C.T1, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "Bỏ qua bước LLM trên máy tự chia truyện — dùng khi bạn đã có kịch bản " +
                "chia sẵn theo scene (vd nhờ ChatGPT/Claude viết ngoài app). Bước dịch sang " +
                "prompt ảnh SD1.5 vẫn cần LLM trên máy chạy như bình thường.",
                color = C.T3, fontSize = 11.sp, lineHeight = 15.sp
            )
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = {
                clipboard.setText(AnnotatedString(
                    "Hãy viết kịch bản truyện tranh chia theo scene, trả về ĐÚNG định dạng JSON sau " +
                    "(không thêm chữ nào khác ngoài JSON):\n\n${ExternalScriptImport.EXAMPLE_JSON}"
                ))
            }) {
                Text("📋 Copy mẫu prompt+JSON để gửi cho LLM ngoài", color = C.Blue, fontSize = 12.sp)
            }
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = jsonText,
                onValueChange = { jsonText = it; previewError = null; previewSceneCount = null },
                // mục 141 — cao hơn hẳn bản AlertDialog cũ (160dp -> 280dp),
                // ModalBottomSheet có chỗ để cho khung nhập rộng rãi hơn mà
                // vẫn còn chỗ cho nút bên dưới, không cần cuộn lồng cuộn.
                modifier = Modifier.fillMaxWidth().height(280.dp),
                placeholder = { Text("Dán JSON kịch bản vào đây...", color = C.T3, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                    focusedContainerColor = C.S0, unfocusedContainerColor = C.S0,
                    focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
            )
            Spacer(Modifier.height(8.dp))
            MlOutlineBtn("Xem trước (kiểm tra JSON hợp lệ)", onClick = { runPreview() },
                enabled = jsonText.isNotBlank())
            previewError?.let {
                Spacer(Modifier.height(6.dp))
                Text("⚠ $it", color = C.Orange, fontSize = 11.sp, lineHeight = 15.sp)
            }
            previewSceneCount?.let {
                Spacer(Modifier.height(6.dp))
                Text("✓ JSON hợp lệ — $it scene sẽ được import.", color = C.Green, fontSize = 12.sp)
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MlOutlineBtn("Huỷ", onClick = onDismiss, modifier = Modifier.weight(1f))
                MlBtn(
                    "Import & Sinh panel",
                    onClick = { vm.prepareChapterFromExternalScript(jsonText); onDismiss() },
                    enabled = previewSceneCount != null, // bắt buộc xem trước thành công mới cho xác nhận — tránh bấm nhầm JSON hỏng
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
