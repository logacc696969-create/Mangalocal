package com.mangalocal.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

/**
 * mục 155 TECHNICAL_STATUS.md — mục Help trong app, bản RÚT GỌN của
 * `HUONG_DAN_SU_DUNG.md` (file gốc đầy đủ hơn, đọc trên máy tính/GitHub
 * tiện hơn — màn này chỉ cần đủ để tra cứu nhanh ngay trong lúc dùng app,
 * không cần chép lại 100% chi tiết).
 *
 * Thiết kế mobile-first (đúng yêu cầu đã áp dụng cho
 * CharacterSummaryReviewScreen, mục 154): card GẬP/MỞ (đúng pattern
 * "Hướng dẫn đặt model" đã có sẵn trong SettingsScreen.kt — nhất quán
 * toàn app, không phát minh pattern mới) thay vì 1 khối text dài cuộn vô
 * tận — mỗi chủ đề tự đóng lại khi không đọc, đỡ ngợp trên màn hình nhỏ.
 * Mặc định GẬP hết trừ mục đầu tiên (thường cần nhất lúc mới mở app).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(nav: NavController, @Suppress("UNUSED_PARAMETER") vm: MainViewModel) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Trợ giúp", fontSize = 16.sp) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {

            item {
                Text("MangaLocal sinh truyện tranh từ văn bản, chạy ngay trên điện thoại " +
                    "(không bắt buộc mạng). Chạm vào từng mục dưới để xem chi tiết.",
                    color = C.T2, fontSize = 12.sp, lineHeight = 17.sp,
                    modifier = Modifier.padding(bottom = 4.dp))
            }

            item {
                HelpSection(
                    icon = "📦", title = "1. Chuẩn bị model (bắt buộc trước khi dùng)",
                    accent = C.Purple, accentDim = C.PurpleDim, startExpanded = true
                ) {
                    HelpBullet("App KHÔNG tự tải model qua mạng (bảo mật offline) — phải tự copy vào máy trước, qua Cài đặt.")
                    HelpBullet("Bắt buộc: LLM model (đọc hiểu truyện) + SD model (sinh ảnh, SD1.5 hoặc SDXL).")
                    HelpBullet("Tuỳ chọn: LoRA (giữ mặt nhân vật), YOLO (bong bóng thoại + tư thế), ESRGAN (nâng độ phân giải).")
                    HelpBullet("Cài đặt tự báo còn thiếu model nào — mở Cài đặt xem trạng thái trực tiếp.")
                    HelpBullet("Máy dưới 8GB RAM: bật \"Chế độ 4 Giai đoạn Công nghiệp\" trong Cài đặt.")
                }
            }

            item {
                HelpSection(
                    icon = "📖", title = "2. Luồng chính — từ văn bản tới ảnh truyện tranh",
                    accent = C.Blue, accentDim = C.BlueDim
                ) {
                    HelpStep(1, "Tạo truyện", "Đặt tên, chọn phong cách ảnh (anime/manga hay điện ảnh).")
                    HelpStep(2, "Tạo nhân vật (tuỳ chọn, làm trước nếu muốn)", "Đặt vai trò + chọn cách giữ mặt nhất quán (LoRA/IP-Adapter/Textual Inversion).")
                    HelpStep(3, "Dán văn bản truyện", "Dán trực tiếp, hoặc dán JSON kịch bản đã chia scene sẵn từ LLM ngoài (ChatGPT/Gemini...).")
                    HelpStep(4, "Xác nhận nhân vật mới (nếu có)", "Chỉ hiện khi phát hiện nhân vật CHƯA từng thêm — xác nhận vai trò + đánh dấu ai cần giữ mặt nhất quán. Chương sau không hiện lại.")
                    HelpStep(5, "Duyệt định tuyến Local/Remote", "Chỉ có ý nghĩa nếu đã cấu hình GPU thuê ngoài — không thì bỏ qua, mọi panel chạy Local.")
                    HelpStep(6, "Sinh ảnh", "App tự chạy AI sinh từng panel, có thể huỷ giữa chừng.")
                    HelpStep(7, "Duyệt từng panel", "Duyệt / Sinh lại / Sửa tay 1 vùng lỗi / Import ảnh ngoài thay hẳn panel / Sửa tư thế.")
                    HelpStep(8, "Hậu kỳ", "Nâng độ phân giải + sửa mặt/tay tự động + đặt bong bóng thoại.")
                    HelpStep(9, "Xuất file", "PDF và/hoặc CBZ — chọn 1 hoặc cả 2, có thể lưu thêm ra Google Drive/thư mục khác.")
                }
            }

            item {
                HelpSection(
                    icon = "🎭", title = "3. Giữ mặt nhân vật nhất quán",
                    accent = C.Green, accentDim = C.GreenDim
                ) {
                    HelpBullet("LoRA — giống mặt nhất, cần \"convert\" trước khi dùng. Hợp nhân vật chính.")
                    HelpBullet("IP-Adapter — chỉ cần 1 ảnh neo, không cần convert. Hợp nhân vật phụ.")
                    HelpBullet("Textual Inversion — nhẹ nhất, không giống mặt bằng 2 cách trên. Hợp nhân vật xuất hiện ít.")
                    HelpBullet("2 nhân vật hay đứng chung 1 khung ảnh? Cân nhắc \"convert ghép cặp\" — giảm hẳn tình trạng 2 người bị lẫn mặt nhau.")
                    HelpBullet("Muốn xem thử mặt nhân vật trước khi dùng thật? Dùng nút sinh ảnh thử ở màn Nhân vật, chọn 1 ảnh ưng ý làm chính thức.")
                }
            }

            item {
                HelpSection(
                    icon = "🏭", title = "4. Chế độ Công nghiệp — sinh hàng loạt nhiều chương",
                    accent = C.Orange, accentDim = C.OrangeDim
                ) {
                    HelpBullet("Dùng khi có sẵn cả truyện dài (hàng chục/trăm chương), muốn chạy xuyên đêm không cần ngồi duyệt từng chương.")
                    HelpBullet("App tự đề nghị chế độ này khi dán văn bản đủ dài.")
                    HelpBullet("1 chương lỗi KHÔNG làm hỏng cả lô — tự ghi log, chuyển sang chương tiếp theo.")
                    HelpBullet("Nếu app bị tắt giữa chừng: mở lại, dán ĐÚNG văn bản cũ — app tự nhận ra và tiếp tục từ chỗ dở dang, không sinh lại từ đầu.")
                    HelpBullet("Sau khi chạy xong lô, vẫn cần vào từng chương để duyệt panel/xuất file như bình thường — chế độ này chỉ tự động hoá bước SINH ẢNH.")
                }
            }

            item {
                HelpSection(
                    icon = "☁️", title = "5. GPU thuê ngoài (tuỳ chọn — máy yếu hoặc muốn nhanh hơn)",
                    accent = C.Blue, accentDim = C.BlueDim
                ) {
                    HelpBullet("Không bắt buộc — bỏ qua nếu chỉ chạy trên điện thoại.")
                    HelpBullet("Cần dựng server riêng trên máy có GPU (vd Colab miễn phí) rồi nhập địa chỉ vào Cài đặt.")
                    HelpBullet("App LUÔN cho xem trước panel nào chạy Local/Remote trước khi sinh ảnh thật, có thể sửa tay.")
                    HelpBullet("⚠️ Giới hạn bảo mật thật: mã hoá chỉ chống người thứ 3 nghe lén trên mạng — KHÔNG chống được chính chủ máy chủ GPU đang thuê. Chỉ dùng cho nội dung sẵn sàng để lộ cho họ thấy.")
                }
            }

            item {
                HelpSection(
                    icon = "🛠️", title = "6. Xử lý sự cố thường gặp",
                    accent = C.Red, accentDim = C.RedDim
                ) {
                    HelpBullet("\"Chưa chọn SD Model\"/\"Chưa chọn LLM Model\" — vào Cài đặt kiểm tra đã import + quét model chưa.")
                    HelpBullet("Huỷ sinh ảnh mà lâu không phản hồi — app đợi tối đa 30 giây rồi báo có thể đang treo ở tầng xử lý ảnh sâu, đây là giới hạn đã biết (không ép dừng ngay để tránh lỗi nặng hơn).")
                    HelpBullet("2 nhân vật trong 1 khung ảnh bị lẫn mặt nhau — dùng \"convert ghép cặp\" thay vì để 2 LoRA độc lập chồng lên nhau (xem mục 3).")
                    HelpBullet("Lô công nghiệp dừng giữa chừng — mở lại đúng truyện, dán lại đúng văn bản gốc, app tự hỏi tiếp tục (xem mục 4).")
                    HelpBullet("App bị hệ điều hành tự tắt khi chạy nền lâu — mở lại app, tiến độ được giữ lại (checkpoint), không cần lo mất công.")
                }
            }

            item {
                Surface(color = C.S1, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Border)) {
                    Text(
                        "Tài liệu đầy đủ hơn (kèm tên hàm/kiến trúc kỹ thuật): xem file " +
                        "HUONG_DAN_SU_DUNG.md và TECHNICAL_STATUS.md đi kèm dự án.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun HelpSection(
    icon: String, title: String, accent: Color, accentDim: Color,
    startExpanded: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by remember { mutableStateOf(startExpanded) }
    Surface(onClick = { expanded = !expanded }, color = accentDim, shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.4f))) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(icon, fontSize = 16.sp)
                Text(title, color = accent, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                    modifier = Modifier.weight(1f))
                Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = accent)
            }
            if (expanded) {
                Spacer(Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { content() }
            }
        }
    }
}

@Composable
private fun HelpBullet(text: String) {
    Row {
        Text("•  ", color = C.T3, fontSize = 12.sp)
        Text(text, color = C.T2, fontSize = 12.sp, lineHeight = 17.sp)
    }
}

@Composable
private fun HelpStep(number: Int, title: String, detail: String) {
    Row(Modifier.padding(vertical = 2.dp)) {
        Surface(color = C.S2, shape = RoundedCornerShape(50)) {
            Text("$number", color = C.T1, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Text(title, color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}
