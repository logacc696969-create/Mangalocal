package com.mangalocal.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

/**
 * mục 155 TECHNICAL_STATUS.md — mục Help trong app, bản RÚT GỌN của
 * `HUONG_DAN_SU_DUNG.md` (file gốc đầy đủ hơn, đọc trên máy tính/GitHub
 * tiện hơn — màn này chỉ cần đủ để tra cứu nhanh ngay trong lúc dùng app,
 * không cần chép lại 100% chi tiết).
 * Cập nhật mục 203 — file này từng dừng lại ở mục 184, đã bổ sung phần
 * badge Quality Gate + ô model tier/biểu cảm riêng panel (mục 185-197)
 * vào HelpStep(7,...) cho khớp `HUONG_DAN_SU_DUNG.md` Bước 6.
 *
 * Thiết kế mobile-first (đúng yêu cầu đã áp dụng cho
 * CharacterSummaryReviewScreen, mục 154): card GẬP/MỞ (đúng pattern
 * "Hướng dẫn đặt model" đã có sẵn trong SettingsScreen.kt — nhất quán
 * toàn app, không phát minh pattern mới) thay vì 1 khối text dài cuộn vô
 * tận — mỗi chủ đề tự đóng lại khi không đọc, đỡ ngợp trên màn hình nhỏ.
 * Mặc định GẬP hết trừ mục đầu tiên (thường cần nhất lúc mới mở app).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(nav: NavController, @Suppress("UNUSED_PARAMETER") vm: MainViewModel) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Trợ giúp", fontSize = 16.sp) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {

            item {
                Text("MangaLocal sinh truyện tranh từ văn bản, chạy ngay trên điện thoại " +
                    "(không bắt buộc mạng). Chạm vào từng mục dưới để xem chi tiết.",
                    color = C.T2, fontSize = 12.sp, lineHeight = 17.sp,
                    modifier = Modifier.padding(bottom = 4.dp))
            }

            item {
                HelpSection(
                    icon = "📦", title = "1. Chuẩn bị model (bắt buộc trước khi dùng)",
                    accent = C.Purple, accentDim = C.PurpleDim, startExpanded = true
                ) {
                    HelpBullet("App mặc định KHÔNG tự tải model qua mạng (bảo mật offline) — phải tự copy vào máy trước, qua Cài đặt. (Có thêm nút tải tự động TUỲ CHỌN nếu tự cấu hình URL riêng — xem tài liệu đầy đủ.)")
                    HelpBullet("Bắt buộc: LLM model (đọc hiểu truyện) + SD model (sinh ảnh). SD1.5 có đầy đủ tính năng (giữ mặt, tư thế, nhiều nhân vật — mục 3 dưới), đã build-test qua CI thật. SDXL Local (thử nghiệm, thẻ riêng trong Cài đặt) đã có đủ 5 pipeline giữ mặt/tư thế/nhiều nhân vật ở tầng code — NHƯNG CHƯA build-test/CHƯA chạy thử thật lần nào, bật lên có thể lỗi/chậm/crash — chỉ bật nếu chấp nhận rủi ro.")
                    HelpBullet("Tuỳ chọn: LoRA (giữ mặt nhân vật), YOLO (bong bóng thoại + tư thế), ESRGAN (nâng độ phân giải).")
                    HelpBullet("Cài đặt tự báo còn thiếu model nào — mở Cài đặt xem trạng thái trực tiếp.")
                    HelpBullet("Máy dưới 8GB RAM: bật \"Chế độ 4 Giai đoạn Công nghiệp\" trong Cài đặt.")
                }
            }

            item {
                HelpSection(
                    icon = "📖", title = "2. Luồng chính — từ văn bản tới ảnh truyện tranh",
                    accent = C.Blue, accentDim = C.BlueDim
                ) {
                    HelpStep(1, "Tạo truyện", "Đặt tên, chọn phong cách ảnh (anime/manga hay điện ảnh).")
                    HelpStep(2, "Tạo nhân vật (tuỳ chọn, làm trước nếu muốn)", "Đặt vai trò + chọn cách giữ mặt nhất quán (LoRA/IP-Adapter/Textual Inversion). Nhân vật lớn lên/đổi trang phục giữa truyện? Có nút \"Tạo phiên bản ngoại hình mới\" áp dụng từ chương chỉ định.")
                    HelpStep(3, "Dán văn bản truyện", "Dán trực tiếp, hoặc dán JSON kịch bản đã chia scene sẵn từ LLM ngoài (ChatGPT/Gemini...).")
                    HelpStep(4, "Xác nhận nhân vật mới (nếu có)", "Chỉ hiện khi phát hiện nhân vật CHƯA từng thêm — xác nhận vai trò + đánh dấu ai cần giữ mặt nhất quán. Chương sau không hiện lại.")
                    HelpStep(5, "Duyệt định tuyến Local/Remote", "Chỉ có ý nghĩa nếu đã cấu hình GPU thuê ngoài — không thì bỏ qua, mọi panel chạy Local.")
                    HelpStep(6, "Sinh ảnh", "App tự chạy AI sinh từng panel, có thể huỷ giữa chừng. Cài đặt cho chọn tỷ lệ khung ảnh (vuông mặc định, hoặc khác vuông NẾU checkpoint đang dùng hỗ trợ — chưa xác nhận chạy đúng trên mọi máy).")
                    HelpStep(7, "Duyệt từng panel", "Duyệt / Sinh lại / Sửa tay 1 vùng lỗi / Import ảnh ngoài thay hẳn panel / Sửa tư thế. Panel nghi khung xương có vấn đề hiện badge ⚠ (chỉ là gợi ý, cần tự xem ảnh). Mở sheet sửa còn cho chọn model tier riêng (SD1.5/SDXL) và, với panel ≥2 người, chọn biểu cảm riêng từng nhân vật.")
                    HelpStep(8, "Hậu kỳ", "Nâng độ phân giải + sửa mặt/tay tự động + đặt bong bóng thoại.")
                    HelpStep(9, "Xuất file", "PDF và/hoặc CBZ — chọn 1 hoặc cả 2, có thể lưu thêm ra Google Drive/thư mục khác. Sau khi xuất .cbz xong, có tuỳ chọn dọn dẹp file ảnh gốc để đỡ tốn bộ nhớ máy.")
                }
            }

            item {
                HelpSection(
                    icon = "🎭", title = "3. Giữ mặt nhân vật nhất quán",
                    accent = C.Green, accentDim = C.GreenDim
                ) {
                    HelpBullet("LoRA — giống mặt nhất, cần \"convert\" trước khi dùng. Hợp nhân vật chính.")
                    HelpBullet("IP-Adapter — chỉ cần 1 ảnh neo, không cần convert. Hợp nhân vật phụ.")
                    HelpBullet("Textual Inversion — nhẹ nhất, không giống mặt bằng 2 cách trên. Hợp nhân vật xuất hiện ít.")
                    HelpBullet("2 nhân vật hay đứng chung 1 khung ảnh? Cân nhắc \"convert ghép cặp\" — giảm hẳn tình trạng 2 người bị lẫn mặt nhau.")
                    HelpBullet("Có sẵn model riêng (xem tài liệu đầy đủ, mục 3.5)? App tự chọn 1 trong 5 cách sinh ảnh nhiều-nhân-vật (mask riêng từng người / Regional Prompting / Attention Couple / Triple-Combo Pose+Depth+IP-Adapter) thay vì chỉ ghép cặp LoRA — tự động, không cần bật tay.")
                    HelpBullet("Muốn xem thử mặt nhân vật trước khi dùng thật? Dùng nút sinh ảnh thử ở màn Nhân vật, chọn 1 ảnh ưng ý làm chính thức.")
                }
            }

            item {
                HelpSection(
                    icon = "🏭", title = "4. Chế độ Công nghiệp — sinh hàng loạt nhiều chương",
                    accent = C.Orange, accentDim = C.OrangeDim
                ) {
                    HelpBullet("Dùng khi có sẵn cả truyện dài (hàng chục/trăm chương), muốn chạy xuyên đêm không cần ngồi duyệt từng chương.")
                    HelpBullet("App tự đề nghị chế độ này khi dán văn bản đủ dài.")
                    HelpBullet("1 chương lỗi KHÔNG làm hỏng cả lô — tự ghi log, chuyển sang chương tiếp theo.")
                    HelpBullet("Bước sinh ảnh chạy tách biệt khỏi giao diện chính — về lý thuyết giúp app không bị văng hẳn nếu có lỗi sâu lúc sinh ảnh, nhưng đây là thay đổi MỚI, CHƯA xác nhận chạy đúng trên mọi máy.")
                    HelpBullet("Nếu app bị tắt giữa chừng: mở lại, dán ĐÚNG văn bản cũ — app tự nhận ra và tiếp tục từ chỗ dở dang, không sinh lại từ đầu.")
                    HelpBullet("Sau khi chạy xong lô, vẫn cần vào từng chương để duyệt panel/xuất file như bình thường — chế độ này chỉ tự động hoá bước SINH ẢNH.")
                }
            }

            item {
                HelpSection(
                    icon = "☁️", title = "5. GPU thuê ngoài (tuỳ chọn — máy yếu hoặc muốn nhanh hơn)",
                    accent = C.Blue, accentDim = C.BlueDim
                ) {
                    HelpBullet("Không bắt buộc — bỏ qua nếu chỉ chạy trên điện thoại.")
                    HelpBullet("Cần dựng server riêng trên máy có GPU (vd Colab miễn phí) rồi nhập địa chỉ vào Cài đặt.")
                    HelpBullet("App LUÔN cho xem trước panel nào chạy Local/Remote trước khi sinh ảnh thật, có thể sửa tay.")
                    HelpBullet("SDXL đầy đủ tính năng (giữ mặt + tư thế 1 nhân vật) qua GPU thuê ngoài vẫn KHÔNG hỗ trợ LoRA hay pipeline nhiều-nhân-vật dù chạy kiểu nào. SDXL chạy TRÊN MÁY (Local) giờ cũng thử nghiệm được qua thẻ \"SDXL (thử nghiệm)\" trong Cài đặt — CHƯA build-test lần nào, độ tin cậy thấp hơn hẳn đường GPU thuê ngoài này.")
                    HelpBullet("⚠️ Giới hạn bảo mật thật: mã hoá chỉ chống người thứ 3 nghe lén trên mạng — KHÔNG chống được chính chủ máy chủ GPU đang thuê. Chỉ dùng cho nội dung sẵn sàng để lộ cho họ thấy.")
                }
            }

            item {
                HelpSection(
                    icon = "🛠️", title = "6. Xử lý sự cố thường gặp",
                    accent = C.Red, accentDim = C.RedDim
                ) {
                    HelpBullet("\"Chưa chọn SD Model\"/\"Chưa chọn LLM Model\" — vào Cài đặt kiểm tra đã import + quét model chưa.")
                    HelpBullet("Huỷ sinh ảnh mà lâu không phản hồi — app đợi tối đa 30 giây rồi báo có thể đang treo ở tầng xử lý ảnh sâu, đây là giới hạn đã biết (không ép dừng ngay để tránh lỗi nặng hơn).")
                    HelpBullet("2 nhân vật trong 1 khung ảnh bị lẫn mặt nhau — nếu đã có model nhiều-nhân-vật (mục 3) app tự dùng, nếu không thì dùng \"convert ghép cặp\" thay vì để 2 LoRA độc lập chồng lên nhau.")
                    HelpBullet("Lô công nghiệp dừng giữa chừng — mở lại đúng truyện, dán lại đúng văn bản gốc, app tự hỏi tiếp tục (xem mục 4).")
                    HelpBullet("App bị hệ điều hành tự tắt khi chạy nền lâu — mở lại app, tiến độ được giữ lại (checkpoint), không cần lo mất công. Nếu chỉ 1 chương báo lỗi giữa lô dài mà app không bị tắt hẳn, đó là cơ chế cách ly lỗi mới hoạt động đúng — không phải bug.")
                }
            }

            // mục 275 — các tính năng thêm sau mục 155 chưa có trong Trợ giúp (người dùng hỏi "tính năng mới đã có hướng dẫn chưa")
            item {
                HelpSection(
                    icon = "🏞", title = "7. Bối cảnh (ảnh nền) — nhập ở đâu, dùng thế nào",
                    accent = C.Green, accentDim = C.GreenDim
                ) {
                    HelpBullet("Mở: màn chi tiết truyện hoặc tab Nhân vật → nút \"🏞 Bối cảnh\" ở phần \"Lối tắt\" (cũng có icon địa điểm ở thanh trên màn Nhân vật).")
                    HelpBullet("Gõ tên địa điểm → thêm. Chọn ảnh từ thư viện làm ảnh neo: ảnh bạn chọn LUÔN được ưu tiên, máy không ghi đè. Hoặc bấm tạo ảnh nền và chọn nguồn (SD trên máy / GPU thuê ngoài / API miễn phí).")
                    HelpBullet("Trong nội dung truyện gõ @Tên bối cảnh để dùng đúng địa điểm đã tạo.")
                    HelpBullet("Giới hạn: đầy đủ nhất cho panel KHÔNG có nhân vật; panel có nhân vật cần model riêng cho bối cảnh (xuất riêng, chi tiết ở TECHNICAL_STATUS.md mục 217).")
                }
            }

            item {
                HelpSection(
                    icon = "🧍", title = "8. Tư thế — vẽ/sửa khung xương, nhiều người, nhập từ ảnh/video",
                    accent = C.Blue, accentDim = C.BlueDim
                ) {
                    HelpBullet("Mở: nút \"🧍 Tư thế\" ở phần \"Lối tắt\" (màn Nhân vật / chi tiết truyện), hoặc trong Cài đặt, hoặc từ màn xem ảnh.")
                    HelpBullet("Trang cuộn được: kéo ở vùng NGOÀI khung vẽ, hoặc chạm ngoài các khớp, để cuộn. Chạm TRÚNG một khớp rồi kéo để sửa; hai ngón để phóng to/dịch khung.")
                    HelpBullet("Nhiều người trong một khung: bấm \"Thêm người\", chọn \"Người N\" để sửa người đó, \"Xoá người N\" để bỏ. Người đang sửa vẽ rõ, người khác vẽ mờ.")
                    HelpBullet("Nhập: bấm \"▸ Nhập tư thế từ ảnh / video / OpenPose\" → chọn ảnh hoặc video (video tự lấy 2 khung/giây). Cần file yolov8_pose.mnn trong MangaLocal/yolo/ — nếu thiếu, màn hình chỉ cách tạo và có nút \"Kiểm tra lại model\".")
                    HelpBullet("Chưa có model vẫn nhập được file JSON OpenPose BODY_18 (không hỗ trợ BODY_25), hoặc tự vẽ khung xương. Kết quả nhập luôn đánh dấu \"cần kiểm tra\" — tự xem lại trước khi dùng.")
                    HelpBullet("Độ sâu 3D THẬT khi trích từ ảnh (thẻ \"Trích tư thế từ ảnh/video có sẵn\"): model BlazePose được ĐÓNG SẴN trong APK và tự chép ra thư mục model (MangaLocal/yolo/) ở lần đầu mở màn này — không cần chép tay (nếu bạn tự đặt blazepose_*.mnn vào đó thì app dùng của bạn, không ghi đè). Bật công tắc \"Độ sâu 3D thật (BlazePose)\" rồi chọn một ẢNH: mỗi người được thêm độ sâu thật cho từng khớp (không đoán), nên thanh trượt xoay camera dùng đúng độ sâu đó, kể cả tay chân vươn ra trước và thân xoay vừa. Chỉ làm khi trích từ ảnh (video chưa báo kết quả). Mỗi người thêm vài chục mili-giây (chưa đo trên máy). Tranh vẽ cách điệu hoặc người bị che nhiều có thể không dựng được — khi đó khung xương giữ z = 0. Khung xương có z thật sẽ bật các chỗ dùng độ sâu (lọc điểm chạm, ảnh độ sâu) cho tư thế đó; chưa kiểm khi sinh ảnh thật.")
                    HelpBullet("Tỷ lệ cơ thể theo tuổi (thẻ ngay DƯỚI khung vẽ): chọn Từ và Sang (Trẻ em ≈ 8 tuổi / Thiếu niên ≈ 14 / Người lớn) rồi bấm \"Áp dụng tỷ lệ cho Người N\". Mỗi ĐOẠN có hệ số riêng: đầu, thân, vai/hông, cánh tay trên, cẳng tay, đùi, cẳng chân (giữ nguyên tổng chiều cao và vị trí hông); bảng ngay trên nút cho biết % chiều cao và hệ số từng đoạn trước khi bấm; có nút Hoàn tác. Tay, chân, thân lấy từ số đo thật 6–18 tuổi (Schmid 2019, trung bình nam-nữ); đầu và vai là ước lượng.")
                    HelpBullet("Vị trí & góc nhìn (thẻ \"Vị trí & góc nhìn\", dưới khung vẽ): bật \"Kéo cả người trên khung vẽ\" để một ngón kéo cả người (hoặc cả nhóm nếu chọn \"Tất cả\"); nút ◀ ▲ ▼ ▶ dời 2% khung, ⌖ Giữa đưa về giữa, −10% / +10% thu phóng, ⟲ ⟳ xoay phẳng 5°, ⇋ Lật đổi trái-phải (đổi cả nhãn tay trái/phải và tự đặt lại nhãn góc nhìn của mẫu). Hai thanh trượt \"Xoay ngang\" (±90°) và \"Nghiêng camera\" (±45°) xoay camera quanh hông như phần mềm 3D, nhưng khung xương vẫn là 2D. MẶC ĐỊNH chỉ xoay THÂN và ĐẦU bằng độ sâu đáng tin (vai hẹp khi nhìn ngang, mũi lệch); tay và chân xoay như người phẳng. Chip \"Đoán độ sâu tay/chân (thử nghiệm)\" đoán thêm từ độ co ngắn của tay chân, nhưng một ảnh 2D không cho biết tay/chân ra TRƯỚC hay SAU camera: đoán sai chiều thì tệ hơn xoay phẳng (bật chip lật của chi đó), và với người đứng thẳng cũng có thể tệ hơn — đo trên dữ liệu giả lập, chưa đo trên khung xương thật. Bấm \"Chốt góc này\" để giữ (mặc định BỎ z đoán để không đụng các chỗ dùng độ sâu; bật \"Giữ z đoán khi chốt\" nếu muốn giữ), \"Về 0°\" để bỏ, \"Hoàn tác\" để quay lại bước trước (tối đa 30 bước).")
                    HelpBullet("Tỷ lệ xương của NHÂN VẬT (màn Nhân vật → mở nhân vật → \"Tỷ lệ xương\"): chọn TUỔI 6–18 để điền sẵn mọi thanh trượt (thân, cánh tay trên, cẳng tay, đùi, cẳng chân, đầu) theo cùng bảng số đo thật; số là độ dài tuyệt đối so với người lớn (1,00). Cùng tuổi vẫn có người cao/thấp nên có thể tự chỉnh từng thanh trượt.")
                    HelpBullet("Đặt tên template, thêm nhãn tương tác (hug, fight...) nếu biết, rồi \"Lưu thành biến thể mới\". Cảnh nhiều người ôm/vật nhau là chỗ AI khó nhất: nên kiểm tay.")
                }
            }

            item {
                HelpSection(
                    icon = "🆓", title = "9. API ảnh miễn phí, nút \"Thử gọi\" và hạn mức ngày",
                    accent = C.Orange, accentDim = C.OrangeDim
                ) {
                    HelpBullet("Cài đặt → \"API ảnh miễn phí\": nhập Cloudflare Workers AI (Account ID + API token) hoặc Pollinations (khoá tuỳ chọn — bỏ trống = bậc ẩn danh, có thể có logo và giới hạn tần suất).")
                    HelpBullet("Bấm \"Thử gọi\" dưới từng nhà cung cấp để gọi THẬT một ảnh nhỏ 256×256 (tốn một ít hạn mức). Kết quả xanh/đỏ hiện ngay dưới nút — đây là cách kiểm khoá và tham số trên máy bạn.")
                    HelpBullet("Hết hạn mức MIỄN PHÍ trong ngày: màn đang tạo hiện MỘT biểu ngữ cam kèm số lần ghi nhận. Các bước dùng API miễn phí đã chạy bằng cách dự phòng nên kết quả có thể kém hơn. Thử lại ngày mai hoặc đổi nhà cung cấp.")
                }
            }

            item {
                HelpSection(
                    icon = "💾", title = "10. Sao lưu truyện và các tuỳ chọn build riêng",
                    accent = C.Purple, accentDim = C.PurpleDim
                ) {
                    HelpBullet("Sao lưu/xoá truyện: màn chi tiết truyện → menu ba chấm. Khôi phục: màn danh sách truyện → \"Khôi phục từ file\".")
                    HelpBullet("Giám khảo VLM (xét ảnh bằng mô hình nhìn ảnh) và module LoRA tách rời là tuỳ chọn BUILD riêng, mặc định tắt (workflow Build APK: enable_vlm, enable_lora_module). Bản cài thường không có hai tính năng này.")
                    HelpBullet("Chi tiết kỹ thuật và giới hạn từng tính năng: HUONG_DAN_SU_DUNG.md và TECHNICAL_STATUS.md.")
                }
            }

            item {
                HelpSection(
                    icon = "🧩", title = "11. Bố cục trang PDF — chọn mẫu và sửa từng trang",
                    accent = C.Blue, accentDim = C.BlueDim
                ) {
                    HelpBullet("Cài đặt → \"Bố cục trang PDF\": chọn mẫu (2 dọc / lưới 2×2 / 1 rộng + 2 dưới / 4-koma / 1 panel mỗi trang / Tự chọn theo cảnh) và khổ trang (A4 / KDP 6×9 / KDP 6×9 có bleed). Mặc định giữ PDF như cũ.")
                    HelpBullet("Muốn sửa riêng từng chương: màn Hậu kỳ của chương → thẻ \"bố cục trang PDF\" → \"🧩 Sửa bố cục trang\" (chọn chỗ ngắt trang và mẫu từng trang trước khi xuất). Không sửa thì PDF theo mẫu ở Cài đặt.")
                    HelpBullet("Khổ KDP: lề trong (gáy) tự theo bảng chính thức của KDP theo số trang PDF.")
                }
            }

            item {
                HelpSection(
                    icon = "🔁", title = "12. Hoán đổi mặt (hậu kỳ trên server)",
                    accent = C.Purple, accentDim = C.PurpleDim
                ) {
                    HelpBullet("Cài đặt → Remote GPU → \"Hậu kỳ trên server\": ba công tắc chạy SAU bước Phóng to theo thứ tự Kontext → sửa tay → hoán đổi mặt (insightface + inswapper_128, dán danh tính từ ảnh neo của nhân vật).")
                    HelpBullet("Cần Remote GPU đang bật và server bản mới (xem tools/remote_server/README.md, có cả điều khoản giấy phép của model). Kết quả ghi thành file mới panel_NNN_srv.png, ảnh gốc giữ nguyên; lỗi một panel thì panel đó giữ ảnh cũ.")
                    HelpBullet("Hợp với cảnh nhiều người/tiếp xúc, nơi mặt dễ bị lẫn danh tính. Tính năng thử nghiệm.")
                }
            }

            item {
                HelpSection(
                    icon = "📐", title = "13. GLIGEN — ép đúng vị trí/kích thước vật thể (nâng cao, thử nghiệm)",
                    accent = C.Orange, accentDim = C.OrangeDim
                ) {
                    HelpBullet("Là pipeline model RIÊNG và TUỲ CHỌN: tạo model bằng workflow \"Export GLIGEN UNet (tuỳ chọn)\" (có thêm biến thể \"_char\" = GLIGEN + IP-Adapter cho cảnh có nhân vật). Bản cài thường không có model này nên không bị ảnh hưởng.")
                    HelpBullet("Dùng các hộp vật thể do mô hình chữ gán cho cảnh (tên vật + toạ độ/kích thước) để ÉP bằng hình học, thay vì hy vọng mô hình tự hiểu từ câu chữ.")
                    HelpBullet("CHƯA build-test và chưa có ảnh thật chứng minh hiệu quả; panel đi nhánh này không có khung xương nên bóng thoại đặt theo cách cũ (vẫn bật đuôi tay được).")
                }
            }

            item {
                Surface(color = C.S1, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Border)) {
                    Text(
                        "Tài liệu đầy đủ hơn (kèm tên hàm/kiến trúc kỹ thuật): xem file " +
                        "HUONG_DAN_SU_DUNG.md và TECHNICAL_STATUS.md đi kèm dự án.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun HelpSection(
    icon: String, title: String, accent: Color, accentDim: Color,
    startExpanded: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by remember { mutableStateOf(startExpanded) }
    Surface(onClick = { expanded = !expanded }, color = accentDim, shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.4f))) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(icon, fontSize = 16.sp)
                Text(title, color = accent, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                    modifier = Modifier.weight(1f))
                Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = accent)
            }
            if (expanded) {
                Spacer(Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { content() }
            }
        }
    }
}

@Composable
private fun HelpBullet(text: String) {
    Row {
        Text("•  ", color = C.T3, fontSize = 12.sp)
        Text(text, color = C.T2, fontSize = 12.sp, lineHeight = 17.sp)
    }
}

@Composable
private fun HelpStep(number: Int, title: String, detail: String) {
    Row(Modifier.padding(vertical = 2.dp)) {
        Surface(color = C.S2, shape = RoundedCornerShape(50)) {
            Text("$number", color = C.T1, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Text(title, color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}
