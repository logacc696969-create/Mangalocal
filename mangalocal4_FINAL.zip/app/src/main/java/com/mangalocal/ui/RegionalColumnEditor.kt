package com.mangalocal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * mục 88 TECHNICAL_STATUS.md — canvas kéo-thả cho Regional Prompting,
 * đóng gap ghi rõ ở mục 69 ("CHƯA có canvas cho user tự kéo thả chia
 * vùng khác nhau").
 *
 * GIỚI HẠN THẬT — ĐỌC TRƯỚC KHI SỬA GÌ Ở FILE NÀY, không giấu trong
 * TECHNICAL_STATUS.md mà thôi: model `unet_regional_controlnet_{N}col.mnn`
 * (xem `regional_prompting.cpp`, hàm `sdTxt2ImgRegional` ở `NativeBridge.kt`)
 * CHỈ nhận `regionEmbeds` — đúng N text embedding, KHÔNG có tham số bề
 * rộng/vị trí vùng nào truyền được xuống native cả. Nghĩa là 1 canvas kiểu
 * Photoshop cho phép kéo-thả ĐỔI ĐỘ RỘNG vùng tự do là KHÔNG THỂ làm thật
 * với kiến trúc model hiện tại — ảnh sinh ra vẫn LUÔN chia N cột đều nhau
 * bất kể canvas có vẽ khác đi hay không. Làm 1 canvas "trông như" chỉnh
 * được độ rộng nhưng model bỏ qua hoàn toàn là lừa người dùng — đúng loại
 * rủi ro đã né ở mục 87 khi quyết định không viết bừa `convert_qnn_offline.yml`.
 *
 * CÁI THẬT LÀM ĐƯỢC, và là đúng cái file này làm: kéo-thả để ĐỔI THỨ TỰ
 * nhân vật vào cột nào (cột vẫn đều nhau — khớp 100% điều model thực sự
 * làm) + sửa tay prompt riêng cho từng cột (model vẫn nhận đúng N text
 * embedding riêng biệt, phần NÀY hoàn toàn thật, không có giới hạn gì).
 *
 * [order]: danh sách tên nhân vật, đúng thứ tự cột trái->phải HIỆN TẠI.
 * [onOrderChange]: gọi lại với thứ tự MỚI sau khi người dùng kéo-thả xong
 * (chưa lưu — nơi gọi tự quyết định khi nào ghi vào PanelOverrideSettings,
 * đúng nguyên tắc "chỉ ghi khi bấm Áp dụng" của EditPanelSheet).
 * [promptOverrides]: map tên -> prompt riêng cột đó, RỖNG hoặc thiếu key =
 * dùng tự động ([autoPromptFor]).
 */
@Composable
fun RegionalColumnEditor(
    order: List<String>,
    onOrderChange: (List<String>) -> Unit,
    promptOverrides: Map<String, String>,
    onPromptOverrideChange: (String, String) -> Unit,
    autoPromptFor: (String) -> String
) {
    var containerWidthPx by remember { mutableStateOf(0f) }
    var draggedIndex by remember { mutableStateOf(-1) }
    var dragOffsetX by remember { mutableStateOf(0f) }
    val n = order.size.coerceAtLeast(1)

    Column(Modifier.fillMaxWidth()) {
        Text(
            "Giữ lâu (long-press) rồi kéo 1 chip sang trái/phải để đổi CỘT của " +
                "nhân vật đó — cột luôn ĐỀU NHAU (đúng khả năng thật của model, " +
                "không phải hạn chế của canvas này).",
            color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
        )
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .height(64.dp)
                .onGloballyPositioned { containerWidthPx = it.size.width.toFloat() }
        ) {
            order.forEachIndexed { index, name ->
                val isDragged = index == draggedIndex
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(3.dp)
                        .graphicsLayer {
                            translationX = if (isDragged) dragOffsetX else 0f
                            shadowElevation = if (isDragged) 10f else 0f
                        }
                        .background(
                            if (isDragged) C.Blue.copy(alpha = 0.22f) else C.S0,
                            RoundedCornerShape(8.dp)
                        )
                        .border(1.dp, if (isDragged) C.Blue else C.Border, RoundedCornerShape(8.dp))
                        .pointerInput(order) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = { draggedIndex = index; dragOffsetX = 0f },
                                onDragEnd = {
                                    // Quy đổi khoảng cách kéo (px) ra số cột đã dịch —
                                    // roundToInt để chỉ cần kéo QUÁ NỬA 1 cột là đổi chỗ,
                                    // giống cảm giác kéo-thả thông thường (không cần kéo
                                    // hẳn tới rìa cột kế tiếp).
                                    val slotWidth = (containerWidthPx / n).coerceAtLeast(1f)
                                    val shift = (dragOffsetX / slotWidth).roundToInt()
                                    val targetIndex = (index + shift).coerceIn(0, n - 1)
                                    if (targetIndex != index) {
                                        val mut = order.toMutableList()
                                        val item = mut.removeAt(index)
                                        mut.add(targetIndex, item)
                                        onOrderChange(mut)
                                    }
                                    draggedIndex = -1
                                    dragOffsetX = 0f
                                },
                                onDragCancel = { draggedIndex = -1; dragOffsetX = 0f },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    dragOffsetX += dragAmount.x
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Cột ${index + 1}", color = C.T3, fontSize = 9.sp)
                        Text(name, color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        order.forEach { name ->
            Spacer(Modifier.height(6.dp))
            MlLabel("prompt riêng cột \"$name\" (để trống = tự động, xem gợi ý mờ bên dưới)")
            OutlinedTextField(
                value = promptOverrides[name] ?: "",
                onValueChange = { onPromptOverrideChange(name, it) },
                placeholder = { Text(autoPromptFor(name), fontSize = 10.sp, color = C.T3) },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                    focusedContainerColor = C.S1, unfocusedContainerColor = C.S1,
                    focusedTextColor = C.T1, unfocusedTextColor = C.T1
                ),
                textStyle = LocalTextStyle.current.copy(fontSize = 11.sp)
            )
        }
    }
}
