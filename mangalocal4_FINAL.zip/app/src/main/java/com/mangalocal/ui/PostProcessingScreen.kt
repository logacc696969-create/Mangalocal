package com.mangalocal.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import com.mangalocal.pipeline.BubbleOps
import com.mangalocal.pipeline.StoryManager
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostProcessingScreen(nav: NavController, vm: MainViewModel) {
    val context = LocalContext.current
    val chapter by vm.currentChapter.collectAsState()
    val isGenerating by vm.isGenerating.collectAsState()
    var selectedPanelIdx by remember { mutableStateOf(0) }

    if (chapter == null) { NoContextScreen("chương", onBack = { nav.popBackStack() }, onHome = { nav.navigate("stories") { launchSingleTop = true } }); return }
    val ch = chapter!!
    val panel = ch.panels.getOrNull(selectedPanelIdx) ?: ch.panels.firstOrNull()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Hội thoại & Xuất file") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                MlCard {
                    MlLabel("hội thoại tự động (yolov8n)")
                    Text("Tải model nhận diện vị trí nhân vật → đặt bubble không che mặt.\nLoad xong sẽ được giải phóng RAM ngay.",
                        color = C.T2, fontSize = 12.sp, lineHeight = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    MlBtn("🤖 Tự động đặt hội thoại", onClick = { vm.runAutoBubble() },
                        enabled = !isGenerating, icon = Icons.Default.AutoFixHigh)
                }
            }

            item {
                MlCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        MlLabel("chỉnh thủ công · panel ${selectedPanelIdx + 1}")
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                        items(ch.panels) { p ->
                            Box {
                                Surface(onClick = { selectedPanelIdx = p.index },
                                    color = if (p.index == selectedPanelIdx) C.BlueDim else C.S0,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, if (p.index == selectedPanelIdx) C.Blue else C.Border)) {
                                    Text("${p.index + 1}", color = if (p.index == selectedPanelIdx) C.Blue else C.T2,
                                        fontSize = 12.sp, modifier = Modifier.padding(10.dp, 6.dp))
                                }
                                if (p.autoFixApplied) {
                                    Box(Modifier.size(8.dp).align(Alignment.TopEnd)
                                        .background(C.Orange, RoundedCornerShape(4.dp)))
                                }
                            }
                        }
                    }

                    if (panel != null) {
                        BubbleEditCanvas(panel = panel,
                            onBubblesChanged = { vm.updatePanelBubbles(panel.index, it) })
                    }
                }
            }

            item {
                MlOutlineBtn("➕ Thêm hội thoại mới", icon = Icons.Default.Add, onClick = {
                    panel?.let { p ->
                        val newBubble = Bubble(UUID.randomUUID().toString(), "Nhân vật", "Nhập lời thoại...",
                            BubbleType.SPEECH, 0.3f, 0.3f, 0.4f, false)
                        vm.updatePanelBubbles(p.index, p.bubbles + newBubble)
                    }
                })
            }

            // Mask thủ công / "Inpaint Anything" (mục 21 TECHNICAL_STATUS.md)
            // — dùng ẢNH CUỐI (panel.upscaledPath, sau ESRGAN+Ultrafix+auto-fix
            // mặt/tay) vì đây là PHASE CUỐI theo đúng yêu cầu: nếu mọi quy
            // trình tự động vẫn sai (dính người, giải phẫu lạ), chạm vào
            // đúng chỗ lỗi để MobileSAM tự phân đoạn, rồi vẽ lại qua CÙNG 1
            // inpainting đã dùng cho auto-fix mặt/tay (ManualMaskFixer tái
            // dùng ImagePipeline.img2imgFix, không viết pipeline riêng).
            item {
                MlCard {
                    MlLabel("sửa tay vùng lỗi (dính người/giải phẫu sai) — phase cuối")
                    if (panel?.autoFixApplied == true) {
                        Text(
                            "⚠ Panel này ĐÃ được auto-fix (Ultrafix/mặt-tay) tự động — nên xem kỹ trước khi qua bước đắp bubble.",
                            color = C.Orange, fontSize = 11.sp, lineHeight = 14.sp
                        )
                        Spacer(Modifier.height(4.dp))
                    }
                    Text(
                        "Nếu ảnh vẫn còn lỗi sau khi ESRGAN + Ultrafix + auto-fix mặt/tay tự động chạy xong, " +
                        "chạm vào đúng khối lỗi bên dưới — MobileSAM tự tách vùng đó ra mask, rồi vẽ lại qua " +
                        "cùng 1 inpainting đang dùng cho auto-fix. CHƯA build-test — có thể chưa hoạt động đúng lần đầu.",
                        color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    if (panel != null) {
                        ManualMaskFixCanvas(panel = panel, vm = vm)
                    }
                }
            }

            // mục 260 TECHNICAL_STATUS.md — sửa bố cục trang PDF (ngắt trang + mẫu từng trang) trước khi xuất.
            item {
                MlCard {
                    MlLabel("bố cục trang PDF (mục 260)")
                    Text(
                        if (ch.pageLayout != null) "Đang dùng bố cục TUỲ CHỈNH của bạn (${ch.pageLayout!!.size} trang)."
                        else "Chưa tuỳ chỉnh: PDF theo mẫu ở Cài đặt.",
                        color = C.T2, fontSize = 12.sp, lineHeight = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    MlOutlineBtn("🧩 Sửa bố cục trang", icon = Icons.Default.GridView, onClick = { nav.navigate("page_layout") })
                }
            }

            item {
                Divider(color = C.Border)
                Spacer(Modifier.height(4.dp))
                MlLabel("xuất file")

                // SỬA (yêu cầu chọn định dạng + nơi xuất): trước đây bấm 1
                // nút là xuất cứng cả PDF+CBZ vào thư mục nội bộ, không cho
                // chọn gì khác.
                var wantPdf by remember { mutableStateOf(true) }
                var wantCbz by remember { mutableStateOf(true) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = wantPdf, onCheckedChange = { wantPdf = it },
                        colors = CheckboxDefaults.colors(checkedColor = C.Blue))
                    Text("PDF", color = C.T2, fontSize = 12.sp)
                    Spacer(Modifier.width(16.dp))
                    Checkbox(checked = wantCbz, onCheckedChange = { wantCbz = it },
                        colors = CheckboxDefaults.colors(checkedColor = C.Blue))
                    Text("CBZ", color = C.T2, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))

                // Chọn thư mục lưu qua SAF (Storage Access Framework) — hoạt
                // động trên MỌI phiên bản Android kể cả 11+ (khác hẳn ghi
                // trực tiếp File thường hay bị chặn bởi scoped storage), vì
                // user TỰ chọn thư mục qua trình chọn hệ thống nên Android
                // luôn cấp quyền ghi vào đúng thư mục đó cho app.
                val pickFolder = rememberLauncherForActivityResult(
                    androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()
                ) { uri: android.net.Uri? ->
                    if (uri != null) {
                        context.contentResolver.takePersistableUriPermission(
                            uri,
                            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                        vm.exportChapter(wantPdf, wantCbz, uri)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MlBtn("💾 Xuất (trong app)", onClick = { vm.exportChapter(wantPdf, wantCbz, null) },
                        icon = Icons.Default.Download, modifier = Modifier.weight(1f))
                    MlBtn("📤 Xuất tới...", onClick = { pickFolder.launch(null) },
                        icon = Icons.Default.FolderOpen, modifier = Modifier.weight(1f))
                }
            }

            if (ch.pdfPath != null) item {
                Surface(color = C.GreenDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Green.copy(0.4f))) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("✅", fontSize = 24.sp)
                        Column {
                            Text("Hoàn thành!", color = C.Green, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("PDF và CBZ đã sẵn sàng trong thư viện", color = C.T2, fontSize = 12.sp)
                        }
                    }
                }
            }

            // mục 161 TECHNICAL_STATUS.md (đợt 4) — chỉ hiện khi ĐÃ xuất
            // .cbz thành công (đúng điều kiện an toàn của
            // cleanupExportedChapterIntermediates() — file .cbz đã có ảnh
            // JPEG nướng sẵn, panel gốc PNG giờ chỉ còn cần cho việc SỬA
            // LẠI, không còn cần cho việc ĐỌC/xuất nữa).
            if (ch.cbzPath != null) item {
                var showCleanupConfirm by remember { mutableStateOf<StoryManager.CleanupMode?>(null) }
                val cleanupMsg by vm.cleanupResultMsg.collectAsState()
                MlCard {
                    MlLabel("dọn dẹp file trung gian (mục 161)")
                    Text(
                        "Chương đã xuất .cbz — file panel gốc (PNG, thường vài trăm MB–1GB/chương) " +
                        "không còn cần để ĐỌC nữa, chỉ cần nếu bạn muốn SỬA LẠI panel sau này.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 14.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MlOutlineBtn("Nén còn sửa được", icon = Icons.Default.Compress,
                            modifier = Modifier.weight(1f),
                            onClick = { showCleanupConfirm = StoryManager.CleanupMode.COMPRESS_TO_JPEG })
                        MlOutlineBtn("Xoá hẳn (tối đa)", icon = Icons.Default.DeleteForever, color = C.Red,
                            modifier = Modifier.weight(1f),
                            onClick = { showCleanupConfirm = StoryManager.CleanupMode.DELETE })
                    }
                    if (cleanupMsg != null) {
                        Spacer(Modifier.height(6.dp))
                        Text(cleanupMsg!!, color = C.Green, fontSize = 11.sp)
                    }
                }
                showCleanupConfirm?.let { mode ->
                    AlertDialog(
                        onDismissRequest = { showCleanupConfirm = null }, containerColor = C.S1,
                        title = { Text("Xác nhận dọn dẹp", color = C.T1) },
                        text = {
                            Text(
                                if (mode == StoryManager.CleanupMode.DELETE)
                                    "XOÁ HẲN file panel gốc của chương này. Sau khi xoá, nút \"Tạo lại\" cho các panel " +
                                    "sẽ phải sinh ảnh MỚI HOÀN TOÀN (mất ảnh gốc để sửa tiếp). File .cbz/.pdf đã xuất KHÔNG bị ảnh hưởng."
                                else
                                    "Nén file panel gốc sang JPEG (chất lượng 92, giống hệt chất lượng dùng trong .cbz). " +
                                    "Vẫn sửa lại được sau này, chỉ giảm nhẹ chất lượng 1 lần. File .cbz/.pdf đã xuất KHÔNG bị ảnh hưởng.",
                                color = C.T2, fontSize = 12.sp, lineHeight = 16.sp
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = { vm.cleanupExportedIntermediates(mode); showCleanupConfirm = null }) {
                                Text("Xác nhận", color = if (mode == StoryManager.CleanupMode.DELETE) C.Red else C.Blue)
                            }
                        },
                        dismissButton = { TextButton(onClick = { showCleanupConfirm = null }) { Text("Huỷ", color = C.T3) } }
                    )
                }
            }
        }
    }
}

@Composable
private fun ManualMaskFixCanvas(panel: Panel, vm: MainViewModel) {
    val imagePath = panel.upscaledPath ?: panel.imagePath
    val busy by vm.manualFixBusy.collectAsState()
    // Kích thước ảnh thật (pixel) — cần để quy đổi toạ độ chạm trên Compose
    // (dp, theo khung hiển thị vuông aspectRatio 1f) sang toạ độ pixel thật
    // của ảnh, vì MobileSAM cần toạ độ pixel THEO ẢNH GỐC (xem
    // ManualMaskFixer.clickToMask doc).
    var imgSize by remember(imagePath) { mutableStateOf<androidx.compose.ui.geometry.Size?>(null) }
    LaunchedEffect(imagePath) {
        imgSize = imagePath?.let {
            val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(it, opts)
            if (opts.outWidth > 0) androidx.compose.ui.geometry.Size(opts.outWidth.toFloat(), opts.outHeight.toFloat()) else null
        }
    }

    if (imagePath == null) {
        Text("Panel chưa có ảnh để sửa.", color = C.T3, fontSize = 12.sp)
        return
    }

    Box(Modifier.fillMaxWidth().aspectRatio(1f).background(C.S0, RoundedCornerShape(12.dp)).clip(RoundedCornerShape(12.dp))) {
        coil.compose.AsyncImage(
            model = java.io.File(imagePath), contentDescription = null,
            modifier = Modifier.fillMaxSize()
                .pointerInput(imagePath) {
                    detectTapGestures { tapOffset ->
                        val size = imgSize ?: return@detectTapGestures
                        // size.width/height ở đây LÀ kích thước Box hiển thị
                        // (Compose layout), lấy qua onSizeChanged bên dưới —
                        // KHÔNG dùng nhầm với imgSize (kích thước ẢNH THẬT).
                    }
                },
            contentScale = androidx.compose.ui.layout.ContentScale.Fit
        )

        var boxSizePx by remember { mutableStateOf(androidx.compose.ui.geometry.Size.Zero) }
        Box(
            Modifier.fillMaxSize()
                .onSizeChanged { boxSizePx = androidx.compose.ui.geometry.Size(it.width.toFloat(), it.height.toFloat()) }
                .pointerInput(imagePath, imgSize) {
                    detectTapGestures { tapOffset ->
                        val real = imgSize ?: return@detectTapGestures
                        if (boxSizePx.width <= 0f || real.width <= 0f) return@detectTapGestures
                        // ContentScale.Fit -> ảnh giữ tỷ lệ, căn giữa trong Box.
                        val scale = minOf(boxSizePx.width / real.width, boxSizePx.height / real.height)
                        val dispW = real.width * scale; val dispH = real.height * scale
                        val offX = (boxSizePx.width - dispW) / 2f; val offY = (boxSizePx.height - dispH) / 2f
                        val px = (tapOffset.x - offX) / scale
                        val py = (tapOffset.y - offY) / scale
                        if (px in 0f..real.width && py in 0f..real.height && !busy) {
                            vm.manualMaskFixPanel(panel.index, px, py)
                        }
                    }
                }
        )

        if (busy) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(0.4f)), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = C.Blue)
            }
        }
    }
    Spacer(Modifier.height(6.dp))
    Text("Chạm vào ảnh ở đúng chỗ lỗi để tự động phân đoạn + vẽ lại.", color = C.T3, fontSize = 10.sp)
}


@Composable
private fun BubbleEditCanvas(panel: Panel, onBubblesChanged: (List<Bubble>) -> Unit) {
    var bubbles by remember(panel.index) { mutableStateOf(panel.bubbles) }
    var editingBubble by remember { mutableStateOf<Bubble?>(null) }

    BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1f).background(C.S0, RoundedCornerShape(12.dp))
        .clip(RoundedCornerShape(12.dp))) {
        // mục 249: cạnh THẬT của khung (dp) thay cho hằng 300 cũ; kéo tay (px) đổi sang dp trước khi chuẩn hoá. Trước đây
        // vị trí hiển thị = norm*300dp trong khung rộng ~W dp và độ dời kéo chia px cho 300 -> bubble hiển thị lệch so với
        // vị trí xuất file và di chuyển nhanh gấp ~mật độ-điểm-ảnh lần ngón tay.
        val side = maxWidth.value

        // mục 140 TECHNICAL_STATUS.md — SỬA BUG NGHIÊM TRỌNG: TRƯỚC ĐÂY
        // canvas kéo-thả bong bóng thoại chỉ hiện chữ placeholder, KHÔNG
        // hiện ảnh panel thật — user KHÔNG THỂ thấy mặt/miệng nhân vật ở
        // đâu để đặt bong bóng đúng chỗ, biến tính năng kéo-thả gần như vô
        // dụng trên thực tế (đặt mù theo trí nhớ). Dùng ĐÚNG AsyncImage đã
        // có sẵn pattern ở `ManualFixCanvas` ngay phía trên trong CHÍNH file
        // này.
        val bubbleImgPath = panel.upscaledPath ?: panel.imagePath
        if (bubbleImgPath != null) {
            coil.compose.AsyncImage(
                model = java.io.File(bubbleImgPath), contentDescription = "Panel ${panel.index + 1}",
                modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Fit
            )
        } else {
            Text("🖼️ [ảnh panel ${panel.index + 1}]", color = C.T3, fontSize = 12.sp,
                modifier = Modifier.align(Alignment.Center))
        }

        // mục 249 — đuôi: đường từ giữa bubble tới đích đuôi (đích kéo được bằng chấm cam bên dưới)
        Canvas(Modifier.fillMaxSize()) {
            bubbles.forEach { b ->
                val tx = b.tailXNorm; val ty = b.tailYNorm
                if (tx != null && ty != null) {
                    val from = Offset((b.xNorm + b.widthNorm / 2f) * size.width, (b.yNorm + 0.08f) * size.height)
                    val to = Offset(tx * size.width, ty * size.height)
                    drawLine(Color.Black, from, to, strokeWidth = 7f)
                    drawLine(Color.White, from, to, strokeWidth = 3f)
                }
            }
        }

        bubbles.forEach { bubble ->
            var offset by remember(bubble.id) { mutableStateOf(Offset(bubble.xNorm, bubble.yNorm)) }
            Surface(
                color = Color.White.copy(0.92f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Color.Black),
                modifier = Modifier
                    .fillMaxWidth(bubble.widthNorm)
                    .offset(x = (offset.x * side).dp, y = (offset.y * side).dp)
                    .pointerInput(bubble.id) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            val newX = (offset.x + drag.x.toDp().value / side).coerceIn(0f, 1f - bubble.widthNorm)
                            val newY = (offset.y + drag.y.toDp().value / side).coerceIn(0f, 0.85f)
                            offset = Offset(newX, newY)
                            bubbles = bubbles.map {
                                if (it.id == bubble.id) it.copy(xNorm = newX, yNorm = newY) else it
                            }
                            onBubblesChanged(bubbles)
                        }
                    }
                    .clickable { editingBubble = bubble }
            ) {
                Column(Modifier.padding(6.dp)) {
                    Text(bubble.characterName, color = Color.DarkGray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(bubble.text.take(30), color = Color.Black, fontSize = 10.sp, maxLines = 2)
                }
            }
        }

        // mục 249 — chấm kéo đích đuôi (chỉ bubble đang có đuôi)
        bubbles.forEach { b ->
            val tx = b.tailXNorm; val ty = b.tailYNorm
            if (tx != null && ty != null) {
                Box(Modifier
                    .offset(x = (tx * side - 9f).dp, y = (ty * side - 9f).dp)
                    .size(18.dp)
                    .background(C.Orange, CircleShape)
                    .pointerInput(b.id) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            bubbles = bubbles.map {
                                if (it.id == b.id) BubbleOps.moveTail(it, drag.x.toDp().value / side, drag.y.toDp().value / side) else it
                            }
                            onBubblesChanged(bubbles)
                        }
                    })
            }
        }
    }
    Text("Kéo bubble để di chuyển · nhấn để sửa (loại, đuôi, lớp) · kéo chấm cam để chỉ đích đuôi", color = C.T3, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))

    editingBubble?.let { b ->
        BubbleTextEditDialog(bubble = b,
            onMove = { delta ->
                bubbles = BubbleOps.moveInStack(bubbles, b.id, delta)
                onBubblesChanged(bubbles)
            },
            onSave = { updated ->
                bubbles = bubbles.map { if (it.id == updated.id) updated else it }
                onBubblesChanged(bubbles)
                editingBubble = null
            },
            onDelete = {
                bubbles = bubbles.filter { it.id != b.id }
                onBubblesChanged(bubbles)
                editingBubble = null
            },
            onDismiss = { editingBubble = null })
    }
}

@Composable
private fun BubbleTextEditDialog(bubble: Bubble, onSave: (Bubble) -> Unit, onDelete: () -> Unit, onDismiss: () -> Unit, onMove: (Int) -> Unit = {}) {
    var name by remember { mutableStateOf(bubble.characterName) }
    var text by remember { mutableStateOf(bubble.text) }
    var type by remember { mutableStateOf(bubble.type) }                      // mục 249
    var hasTail by remember { mutableStateOf(bubble.tailXNorm != null) }      // mục 249
    var fontScale by remember { mutableStateOf(BubbleOps.scaleOf(bubble)) }     // mục 258
    var font by remember { mutableStateOf(BubbleOps.fontOf(bubble.fontStyle)) } // mục 258

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = C.S1,
        title = { Text("Sửa hội thoại", color = C.T1) },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it },
                    label = { Text("Tên nhân vật") }, modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = text, onValueChange = { text = it },
                    label = { Text("Lời thoại") }, modifier = Modifier.fillMaxWidth().height(80.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
                // mục 249 — loại bubble (bộ vẽ khi xuất đã phân biệt: thoại / suy nghĩ / dẫn truyện / hét)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    listOf(BubbleType.SPEECH to "Thoại", BubbleType.THOUGHT to "Nghĩ", BubbleType.NARRATION to "Dẫn", BubbleType.SHOUT to "Hét").forEach { (t, label) ->
                        TextButton(onClick = { type = t }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                            Text(label, color = if (type == t) C.Blue else C.T3, fontSize = 12.sp,
                                fontWeight = if (type == t) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
                // mục 258 — cỡ chữ + font riêng cho bubble này (mỗi thông số có dấu "?" giải thích)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    LabelWithHelp("Cỡ chữ", "bubbleFontScale")
                    Text("%.0f%%".format(fontScale * 100), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                Slider(value = fontScale, onValueChange = { fontScale = it },
                    valueRange = BubbleOps.FONT_SCALE_MIN..BubbleOps.FONT_SCALE_MAX,
                    colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                    HelpDot("bubbleFont")
                    BubbleOps.BubbleFont.values().forEach { f ->
                        TextButton(onClick = { font = f }, contentPadding = PaddingValues(horizontal = 6.dp)) {
                            Text(f.label, color = if (font == f) C.Blue else C.T3, fontSize = 12.sp,
                                fontWeight = if (font == f) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Có đuôi (kéo chấm cam để chỉ đích)", color = C.T2, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    HelpSwitch(helpKey = "bubbleTail", checked = hasTail, onCheckedChange = { hasTail = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Lớp", color = C.T2, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = { onMove(-1) }) { Text("Xuống dưới", color = C.T3, fontSize = 12.sp) }
                    TextButton(onClick = { onMove(1) }) { Text("Lên trên", color = C.T3, fontSize = 12.sp) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(BubbleOps.withFont(BubbleOps.withTail(bubble.copy(characterName = name, text = text, type = type), hasTail), fontScale, font)) }) { Text("Lưu", color = C.Blue) }
        },
        dismissButton = {
            TextButton(onClick = onDelete) { Text("Xóa", color = C.Red) }
        }
    )
}
