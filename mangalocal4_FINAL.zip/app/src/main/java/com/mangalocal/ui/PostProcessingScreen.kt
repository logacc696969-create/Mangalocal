package com.mangalocal.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostProcessingScreen(nav: NavController, vm: MainViewModel) {
    val context = LocalContext.current
    val chapter by vm.currentChapter.collectAsState()
    val isGenerating by vm.isGenerating.collectAsState()
    var selectedPanelIdx by remember { mutableStateOf(0) }

    if (chapter == null) { Box(Modifier.fillMaxSize()) { Text("...", color = C.T3) }; return }
    val ch = chapter!!
    val panel = ch.panels.getOrNull(selectedPanelIdx) ?: ch.panels.firstOrNull()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Hội thoại & Xuất file") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                MlCard {
                    MlLabel("hội thoại tự động (yolov8n)")
                    Text("Tải model nhận diện vị trí nhân vật → đặt bubble không che mặt.\nLoad xong sẽ được giải phóng RAM ngay.",
                        color = C.T2, fontSize = 12.sp, lineHeight = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    MlBtn("🤖 Tự động đặt hội thoại", onClick = { vm.runAutoBubble() },
                        enabled = !isGenerating, icon = Icons.Default.AutoFixHigh)
                }
            }

            item {
                MlCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        MlLabel("chỉnh thủ công · panel ${selectedPanelIdx + 1}")
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                        items(ch.panels) { p ->
                            Box {
                                Surface(onClick = { selectedPanelIdx = p.index },
                                    color = if (p.index == selectedPanelIdx) C.BlueDim else C.S0,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, if (p.index == selectedPanelIdx) C.Blue else C.Border)) {
                                    Text("${p.index + 1}", color = if (p.index == selectedPanelIdx) C.Blue else C.T2,
                                        fontSize = 12.sp, modifier = Modifier.padding(10.dp, 6.dp))
                                }
                                if (p.autoFixApplied) {
                                    Box(Modifier.size(8.dp).align(Alignment.TopEnd)
                                        .background(C.Orange, RoundedCornerShape(4.dp)))
                                }
                            }
                        }
                    }

                    if (panel != null) {
                        BubbleEditCanvas(panel = panel,
                            onBubblesChanged = { vm.updatePanelBubbles(panel.index, it) })
                    }
                }
            }

            item {
                MlOutlineBtn("➕ Thêm hội thoại mới", icon = Icons.Default.Add, onClick = {
                    panel?.let { p ->
                        val newBubble = Bubble(UUID.randomUUID().toString(), "Nhân vật", "Nhập lời thoại...",
                            BubbleType.SPEECH, 0.3f, 0.3f, 0.4f, false)
                        vm.updatePanelBubbles(p.index, p.bubbles + newBubble)
                    }
                })
            }

            // Mask thủ công / "Inpaint Anything" (mục 21 TECHNICAL_STATUS.md)
            // — dùng ẢNH CUỐI (panel.upscaledPath, sau ESRGAN+Ultrafix+auto-fix
            // mặt/tay) vì đây là PHASE CUỐI theo đúng yêu cầu: nếu mọi quy
            // trình tự động vẫn sai (dính người, giải phẫu lạ), chạm vào
            // đúng chỗ lỗi để MobileSAM tự phân đoạn, rồi vẽ lại qua CÙNG 1
            // inpainting đã dùng cho auto-fix mặt/tay (ManualMaskFixer tái
            // dùng ImagePipeline.img2imgFix, không viết pipeline riêng).
            item {
                MlCard {
                    MlLabel("sửa tay vùng lỗi (dính người/giải phẫu sai) — phase cuối")
                    if (panel?.autoFixApplied == true) {
                        Text(
                            "⚠ Panel này ĐÃ được auto-fix (Ultrafix/mặt-tay) tự động — nên xem kỹ trước khi qua bước đắp bubble.",
                            color = C.Orange, fontSize = 11.sp, lineHeight = 14.sp
                        )
                        Spacer(Modifier.height(4.dp))
                    }
                    Text(
                        "Nếu ảnh vẫn còn lỗi sau khi ESRGAN + Ultrafix + auto-fix mặt/tay tự động chạy xong, " +
                        "chạm vào đúng khối lỗi bên dưới — MobileSAM tự tách vùng đó ra mask, rồi vẽ lại qua " +
                        "cùng 1 inpainting đang dùng cho auto-fix. CHƯA build-test — có thể chưa hoạt động đúng lần đầu.",
                        color = C.T3, fontSize = 10.sp, lineHeight = 13.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    if (panel != null) {
                        ManualMaskFixCanvas(panel = panel, vm = vm)
                    }
                }
            }

            item {
                Divider(color = C.Border)
                Spacer(Modifier.height(4.dp))
                MlLabel("xuất file")

                // SỬA (yêu cầu chọn định dạng + nơi xuất): trước đây bấm 1
                // nút là xuất cứng cả PDF+CBZ vào thư mục nội bộ, không cho
                // chọn gì khác.
                var wantPdf by remember { mutableStateOf(true) }
                var wantCbz by remember { mutableStateOf(true) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = wantPdf, onCheckedChange = { wantPdf = it },
                        colors = CheckboxDefaults.colors(checkedColor = C.Blue))
                    Text("PDF", color = C.T2, fontSize = 12.sp)
                    Spacer(Modifier.width(16.dp))
                    Checkbox(checked = wantCbz, onCheckedChange = { wantCbz = it },
                        colors = CheckboxDefaults.colors(checkedColor = C.Blue))
                    Text("CBZ", color = C.T2, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))

                // Chọn thư mục lưu qua SAF (Storage Access Framework) — hoạt
                // động trên MỌI phiên bản Android kể cả 11+ (khác hẳn ghi
                // trực tiếp File thường hay bị chặn bởi scoped storage), vì
                // user TỰ chọn thư mục qua trình chọn hệ thống nên Android
                // luôn cấp quyền ghi vào đúng thư mục đó cho app.
                val pickFolder = rememberLauncherForActivityResult(
                    androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()
                ) { uri: android.net.Uri? ->
                    if (uri != null) {
                        context.contentResolver.takePersistableUriPermission(
                            uri,
                            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                        vm.exportChapter(wantPdf, wantCbz, uri)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MlBtn("💾 Xuất (trong app)", onClick = { vm.exportChapter(wantPdf, wantCbz, null) },
                        icon = Icons.Default.Download, modifier = Modifier.weight(1f))
                    MlBtn("📤 Xuất tới...", onClick = { pickFolder.launch(null) },
                        icon = Icons.Default.FolderOpen, modifier = Modifier.weight(1f))
                }
            }

            if (ch.pdfPath != null) item {
                Surface(color = C.GreenDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Green.copy(0.4f))) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("✅", fontSize = 24.sp)
                        Column {
                            Text("Hoàn thành!", color = C.Green, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("PDF và CBZ đã sẵn sàng trong thư viện", color = C.T2, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManualMaskFixCanvas(panel: Panel, vm: MainViewModel) {
    val imagePath = panel.upscaledPath ?: panel.imagePath
    val busy by vm.manualFixBusy.collectAsState()
    // Kích thước ảnh thật (pixel) — cần để quy đổi toạ độ chạm trên Compose
    // (dp, theo khung hiển thị vuông aspectRatio 1f) sang toạ độ pixel thật
    // của ảnh, vì MobileSAM cần toạ độ pixel THEO ẢNH GỐC (xem
    // ManualMaskFixer.clickToMask doc).
    var imgSize by remember(imagePath) { mutableStateOf<androidx.compose.ui.geometry.Size?>(null) }
    LaunchedEffect(imagePath) {
        imgSize = imagePath?.let {
            val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(it, opts)
            if (opts.outWidth > 0) androidx.compose.ui.geometry.Size(opts.outWidth.toFloat(), opts.outHeight.toFloat()) else null
        }
    }

    if (imagePath == null) {
        Text("Panel chưa có ảnh để sửa.", color = C.T3, fontSize = 12.sp)
        return
    }

    Box(Modifier.fillMaxWidth().aspectRatio(1f).background(C.S0, RoundedCornerShape(12.dp)).clip(RoundedCornerShape(12.dp))) {
        coil.compose.AsyncImage(
            model = java.io.File(imagePath), contentDescription = null,
            modifier = Modifier.fillMaxSize()
                .pointerInput(imagePath) {
                    detectTapGestures { tapOffset ->
                        val size = imgSize ?: return@detectTapGestures
                        // size.width/height ở đây LÀ kích thước Box hiển thị
                        // (Compose layout), lấy qua onSizeChanged bên dưới —
                        // KHÔNG dùng nhầm với imgSize (kích thước ẢNH THẬT).
                    }
                },
            contentScale = androidx.compose.ui.layout.ContentScale.Fit
        )

        var boxSizePx by remember { mutableStateOf(androidx.compose.ui.geometry.Size.Zero) }
        Box(
            Modifier.fillMaxSize()
                .onSizeChanged { boxSizePx = androidx.compose.ui.geometry.Size(it.width.toFloat(), it.height.toFloat()) }
                .pointerInput(imagePath, imgSize) {
                    detectTapGestures { tapOffset ->
                        val real = imgSize ?: return@detectTapGestures
                        if (boxSizePx.width <= 0f || real.width <= 0f) return@detectTapGestures
                        // ContentScale.Fit -> ảnh giữ tỷ lệ, căn giữa trong Box.
                        val scale = minOf(boxSizePx.width / real.width, boxSizePx.height / real.height)
                        val dispW = real.width * scale; val dispH = real.height * scale
                        val offX = (boxSizePx.width - dispW) / 2f; val offY = (boxSizePx.height - dispH) / 2f
                        val px = (tapOffset.x - offX) / scale
                        val py = (tapOffset.y - offY) / scale
                        if (px in 0f..real.width && py in 0f..real.height && !busy) {
                            vm.manualMaskFixPanel(panel.index, px, py)
                        }
                    }
                }
        )

        if (busy) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(0.4f)), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = C.Blue)
            }
        }
    }
    Spacer(Modifier.height(6.dp))
    Text("Chạm vào ảnh ở đúng chỗ lỗi để tự động phân đoạn + vẽ lại.", color = C.T3, fontSize = 10.sp)
}


@Composable
private fun BubbleEditCanvas(panel: Panel, onBubblesChanged: (List<Bubble>) -> Unit) {
    var bubbles by remember(panel.index) { mutableStateOf(panel.bubbles) }
    var editingBubble by remember { mutableStateOf<Bubble?>(null) }

    Box(Modifier.fillMaxWidth().aspectRatio(1f).background(C.S0, RoundedCornerShape(12.dp))
        .clip(RoundedCornerShape(12.dp))) {

        // mục 140 TECHNICAL_STATUS.md — SỬA BUG NGHIÊM TRỌNG: TRƯỚC ĐÂY
        // canvas kéo-thả bong bóng thoại chỉ hiện chữ placeholder, KHÔNG
        // hiện ảnh panel thật — user KHÔNG THỂ thấy mặt/miệng nhân vật ở
        // đâu để đặt bong bóng đúng chỗ, biến tính năng kéo-thả gần như vô
        // dụng trên thực tế (đặt mù theo trí nhớ). Dùng ĐÚNG AsyncImage đã
        // có sẵn pattern ở `ManualFixCanvas` ngay phía trên trong CHÍNH file
        // này.
        val bubbleImgPath = panel.upscaledPath ?: panel.imagePath
        if (bubbleImgPath != null) {
            coil.compose.AsyncImage(
                model = java.io.File(bubbleImgPath), contentDescription = "Panel ${panel.index + 1}",
                modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Fit
            )
        } else {
            Text("🖼️ [ảnh panel ${panel.index + 1}]", color = C.T3, fontSize = 12.sp,
                modifier = Modifier.align(Alignment.Center))
        }

        bubbles.forEach { bubble ->
            var offset by remember(bubble.id) { mutableStateOf(Offset(bubble.xNorm, bubble.yNorm)) }
            Surface(
                color = Color.White.copy(0.92f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Color.Black),
                modifier = Modifier
                    .fillMaxWidth(bubble.widthNorm)
                    .offset(x = (offset.x * 300).dp, y = (offset.y * 300).dp)
                    .pointerInput(bubble.id) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            val newX = (offset.x + drag.x / 300f).coerceIn(0f, 1f - bubble.widthNorm)
                            val newY = (offset.y + drag.y / 300f).coerceIn(0f, 0.85f)
                            offset = Offset(newX, newY)
                            bubbles = bubbles.map {
                                if (it.id == bubble.id) it.copy(xNorm = newX, yNorm = newY) else it
                            }
                            onBubblesChanged(bubbles)
                        }
                    }
                    .clickable { editingBubble = bubble }
            ) {
                Column(Modifier.padding(6.dp)) {
                    Text(bubble.characterName, color = Color.DarkGray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(bubble.text.take(30), color = Color.Black, fontSize = 10.sp, maxLines = 2)
                }
            }
        }
    }
    Text("Kéo bubble để di chuyển · nhấn để sửa text", color = C.T3, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))

    editingBubble?.let { b ->
        BubbleTextEditDialog(bubble = b,
            onSave = { updated ->
                bubbles = bubbles.map { if (it.id == updated.id) updated else it }
                onBubblesChanged(bubbles)
                editingBubble = null
            },
            onDelete = {
                bubbles = bubbles.filter { it.id != b.id }
                onBubblesChanged(bubbles)
                editingBubble = null
            },
            onDismiss = { editingBubble = null })
    }
}

@Composable
private fun BubbleTextEditDialog(bubble: Bubble, onSave: (Bubble) -> Unit, onDelete: () -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(bubble.characterName) }
    var text by remember { mutableStateOf(bubble.text) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = C.S1,
        title = { Text("Sửa hội thoại", color = C.T1) },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it },
                    label = { Text("Tên nhân vật") }, modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = text, onValueChange = { text = it },
                    label = { Text("Lời thoại") }, modifier = Modifier.fillMaxWidth().height(80.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(bubble.copy(characterName = name, text = text)) }) { Text("Lưu", color = C.Blue) }
        },
        dismissButton = {
            TextButton(onClick = onDelete) { Text("Xóa", color = C.Red) }
        }
    )
}
