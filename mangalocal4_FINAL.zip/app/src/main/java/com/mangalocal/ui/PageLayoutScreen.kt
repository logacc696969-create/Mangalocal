package com.mangalocal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mangalocal.model.PageSpec
import com.mangalocal.model.Panel
import com.mangalocal.pipeline.PageLayoutEditor
import com.mangalocal.pipeline.PageTemplate
import java.io.File

// mục 260 TECHNICAL_STATUS.md — SỬA BỐ CỤC TRANG PDF trước khi xuất (PDF/MangaFlow: bố cục là biến trung gian tường minh, chỉnh được).
// Logic nằm ở pipeline/PageLayoutEditor.kt (hàm thuần, có test); màn hình này chỉ vẽ + gọi hàm đó + lưu qua vm.updatePageLayout().
// Mọi thao tác GIỮ NGUYÊN THỨ TỰ ĐỌC của panel (chỉ đổi chỗ ngắt trang và mẫu từng trang) nên PDF không lệch thứ tự với CBZ/video.
// GIỚI HẠN THẬT: chưa thử trên máy (chưa biên dịch bởi kotlinc), chưa xem PDF thật; ô xem trước vẽ theo sơ đồ ô, không phải PDF thật.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PageLayoutScreen(nav: NavController, vm: MainViewModel) {
    val chapter by vm.currentChapter.collectAsState()
    val settings by vm.settings.collectAsState()

    if (chapter == null) { Box(Modifier.fillMaxSize()) { Text("...", color = C.T3) }; return }
    val ch = chapter!!
    val ok = remember(ch.panels) { PageLayoutEditor.usable(ch.panels) }
    val pages = remember(ch.pageLayout, ch.panels, settings.exportPageTemplate) {
        PageLayoutEditor.currentOrBase(ch, settings.exportPageTemplate)
    }
    val byIdx = remember(ok) { ok.associateBy { it.index } }
    val rtl = settings.exportRightToLeft

    // Chỉ ghi khi thật sự có thay đổi (thao tác không hợp lệ trả nguyên bản cũ).
    fun commit(newPages: List<PageSpec>) { if (newPages != pages) vm.updatePageLayout(newPages) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Bố cục trang PDF") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                MlCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        MlLabel("bố cục hiện tại")
                        HelpDot("pageLayoutEditor")
                    }
                    Text(
                        if (ch.pageLayout != null) "Đang dùng bố cục TUỲ CHỈNH: ${pages.size} trang cho ${ok.size} panel. Bố cục này thắng mẫu ở Cài đặt khi xuất PDF."
                        else "Chưa tuỳ chỉnh: PDF theo mẫu ở Cài đặt (${pages.size} trang cho ${ok.size} panel). Sửa bất kỳ trang nào bên dưới để bắt đầu tuỳ chỉnh.",
                        color = C.T2, fontSize = 12.sp, lineHeight = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    MlOutlineBtn("Dùng bố cục tự chọn theo nhịp truyện", icon = Icons.Default.AutoAwesome,
                        enabled = ok.isNotEmpty(), onClick = { commit(PageLayoutEditor.fromAuto(ok)) })
                    Spacer(Modifier.height(6.dp))
                    MlOutlineBtn("Mỗi trang 2 panel dọc", icon = Icons.Default.MenuBook,
                        enabled = ok.isNotEmpty(), onClick = { commit(PageLayoutEditor.fromTemplate(PageTemplate.STACK_2, ok)) })
                    Spacer(Modifier.height(6.dp))
                    MlOutlineBtn("Xoá tuỳ chỉnh (về mẫu ở Cài đặt)", icon = Icons.Default.Restore,
                        enabled = ch.pageLayout != null, onClick = { vm.updatePageLayout(null) })
                }
            }

            if (ok.isEmpty()) item {
                Text("Chưa có panel nào có ảnh để xếp trang.", color = C.T3, fontSize = 12.sp)
            }

            itemsIndexed(pages) { pi, pg ->
                PageCard(
                    number = pi + 1, total = pages.size, pg = pg, panels = byIdx, rtl = rtl,
                    onTemplate = { t -> commit(PageLayoutEditor.setTemplate(pages, pi, t)) },
                    onSplit = { at -> commit(PageLayoutEditor.splitPage(pages, pi, at)) },
                    onMerge = { commit(PageLayoutEditor.mergeWithNext(pages, pi)) },
                    onMoveLastDown = { commit(PageLayoutEditor.moveLastToNext(pages, pi)) },
                    onMoveFirstUp = { commit(PageLayoutEditor.moveFirstToPrev(pages, pi)) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PageCard(
    number: Int, total: Int, pg: PageSpec, panels: Map<Int, Panel>, rtl: Boolean,
    onTemplate: (PageTemplate) -> Unit, onSplit: (Int) -> Unit, onMerge: () -> Unit,
    onMoveLastDown: () -> Unit, onMoveFirstUp: () -> Unit
) {
    val tpl = PageLayoutEditor.templateOf(pg.template)
    val n = pg.panelIndexes.size
    MlCard {
        MlLabel("trang $number / $total · $n panel")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PagePreview(pg, panels, rtl, Modifier.width(120.dp).aspectRatio(0.7f))
            Column(Modifier.weight(1f)) {
                PageAction("⬆ Đẩy panel đầu lên trang trước", number > 1 && n >= 2, onMoveFirstUp)
                PageAction("⬇ Đẩy panel cuối xuống trang sau", number < total && n >= 2, onMoveLastDown)
                PageAction("Gộp với trang sau", number < total, onMerge)
                for (at in 1 until n) {
                    val labelNo = (panels[pg.panelIndexes[at - 1]]?.index ?: (at - 1)) + 1
                    PageAction("Tách sau panel $labelNo", true, { onSplit(at) })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(PageLayoutEditor.PAGE_TEMPLATES) { t ->
                FilterChip(selected = tpl == t, onClick = { onTemplate(t) },
                    label = { Text(t.label, fontSize = 11.sp) })
            }
        }
    }
}

@Composable
private fun PageAction(text: String, enabled: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, contentPadding = PaddingValues(horizontal = 6.dp)) {
        Text(text, color = if (enabled) C.Blue else C.T3, fontSize = 12.sp)
    }
}

// Sơ đồ ô theo PageLayoutEditor.cellRows (khớp thứ tự ô của PageLayout.cells, có kiểm ở tools/test_page_editor.py); rtl lật từng hàng.
@Composable
private fun PagePreview(pg: PageSpec, panels: Map<Int, Panel>, rtl: Boolean, modifier: Modifier) {
    val n = pg.panelIndexes.size
    val rows = PageLayoutEditor.cellRows(PageLayoutEditor.templateOf(pg.template), n, rtl)
    Column(
        modifier.clip(RoundedCornerShape(6.dp)).background(C.S0).padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                row.forEach { pos ->
                    val panel = pg.panelIndexes.getOrNull(pos)?.let { panels[it] }
                    PageCell(panel, Modifier.weight(1f).fillMaxHeight())
                }
            }
        }
    }
}

@Composable
private fun PageCell(panel: Panel?, modifier: Modifier) {
    val path = panel?.let { it.upscaledPath ?: it.imagePath }
    Box(modifier.clip(RoundedCornerShape(3.dp)).background(C.S2), contentAlignment = Alignment.Center) {
        if (path != null) {
            coil.compose.AsyncImage(model = File(path), contentDescription = null,
                contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        }
        Text(if (panel != null) "${panel.index + 1}" else "?", color = C.T1, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.TopStart).background(C.Bg.copy(alpha = 0.6f)).padding(horizontal = 3.dp))
    }
}
