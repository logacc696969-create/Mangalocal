package com.mangalocal.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mangalocal.model.Location
import com.mangalocal.pipeline.ImageSource
import java.io.File

// mục 218 TECHNICAL_STATUS.md — user hỏi thẳng: "nếu ảnh bối cảnh máy tự
// tạo (mục 216/217) không đúng ý thì sao" — trả lời bằng UI THẬT thay vì
// chỉ trả lời bằng lời. Màn hình này cho phép:
//   1. Tạo bối cảnh THỦ CÔNG trước khi LLM gặp tên đó (findOrCreateLocation()
//      so khớp tên không phân biệt hoa/thường — LLM đặt tên trùng sau này
//      sẽ tự khớp vào đúng Location đã tạo tay, KHÔNG tạo trùng).
//   2. Tự chọn ẢNH BÊN NGOÀI (thư viện ảnh máy, KHÔNG phải model tự vẽ)
//      làm ảnh neo — vì MangaPipeline.kt chỉ tự bootstrap khi
//      anchorImagePath == null (mục 217), gán ảnh tay ở đây TRƯỚC khi sinh
//      panel nào của bối cảnh đó khiến ảnh người dùng chọn LUÔN THẮNG, máy
//      không bao giờ tự ghi đè.
//   3. Đổi ảnh khác / xoá ảnh neo (quay lại trạng thái "chưa có anchor" để
//      máy tự bootstrap lại từ đầu) bất kỳ lúc nào.
// CỐ Ý làm ĐƠN GIẢN hơn nhiều so với CharactersDetailScreen — Location chỉ
// có 3 field (id/name/anchorImagePath, xem Models.kt), không có LoRA/
// Textual Inversion/pose gì để quản lý.
//
// GIỚI HẠN THẬT cần nói rõ ngay trong UI (không chỉ trong tài liệu): ảnh
// neo bối cảnh tự chọn ở đây CHỈ có tác dụng cho (a) panel KHÔNG có nhân
// vật nào (mục 217 đợt 1, luôn đúng với mọi model đã có sẵn), hoặc (b)
// panel CÓ nhân vật NẾU đã export/convert riêng model "_loc" cho đúng số
// nhân vật của panel đó (mục 217 đợt 2 — việc export riêng, KHÔNG tự có
// chỉ vì chọn ảnh ở đây).
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationsScreen(nav: NavController, vm: MainViewModel) {
    val story by vm.currentStory.collectAsState()
    var newName by remember { mutableStateOf("") }
    var pickingFor by remember { mutableStateOf<Location?>(null) }
    var confirmDeleteFor by remember { mutableStateOf<Location?>(null) }
    // mục 266 — chọn NGUỒN tạo ảnh nền ngay tại chỗ tạo: hộp thoại cho bối cảnh đang chọn, và id bối cảnh đang tạo (khoá nút)
    var chooseSourceFor by remember { mutableStateOf<Location?>(null) }
    val bgBusyId by vm.locationBgBusy.collectAsState()
    val settingsNow by vm.settings.collectAsState()

    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val loc = pickingFor
        if (uri != null && loc != null) vm.setLocationAnchorImage(loc, uri)
        pickingFor = null
    }

    if (story == null) { Box(Modifier.fillMaxSize()) { Text("...", color = C.T3) }; return }
    val locations = story!!.locations

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Bối cảnh · ${story!!.title}") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("📍 Ảnh neo bối cảnh", color = C.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("Mặc định máy tự lấy panel THÀNH CÔNG ĐẦU TIÊN của 1 bối cảnh làm ảnh neo. " +
                            "Nếu ảnh đó không đúng ý — tự chọn ảnh khác (từ thư viện ảnh) ở đây, máy sẽ " +
                            "KHÔNG bao giờ tự ghi đè ảnh bạn đã chọn tay.",
                            color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("Giới hạn thật: ảnh neo CHỈ chắc chắn có tác dụng ở panel KHÔNG có nhân vật " +
                            "nào (cảnh toàn cảnh). Panel có nhân vật cần model \"_loc\" riêng đã export " +
                            "(mục 217 đợt 2 TECHNICAL_STATUS.md) — chưa export thì chọn ảnh ở đây vẫn lưu " +
                            "được nhưng panel có nhân vật sẽ chưa thấy khác biệt.",
                            color = C.Orange, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                }
            }

            item {
                Surface(color = C.S1, shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = newName, onValueChange = { newName = it },
                            label = { Text("Tên bối cảnh mới") }, modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                                focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
                        Spacer(Modifier.width(8.dp))
                        IconButton(onClick = {
                            if (newName.isNotBlank()) { vm.addLocationManually(newName); newName = "" }
                        }) { Icon(Icons.Default.Add, null, tint = C.Blue) }
                    }
                }
            }
            item {
                Text("Mẹo: đặt tên TRÙNG (không phân biệt hoa/thường) với tên bối cảnh LLM sẽ dùng " +
                    "(location_name khi phân tích kịch bản) để máy tự khớp vào đúng chỗ này — nếu không " +
                    "chắc tên chính xác, tạo trước rồi kiểm tra/đổi tên lại sau khi sinh thử 1 chương.",
                    color = C.T3, fontSize = 10.sp, lineHeight = 13.sp)
            }

            if (locations.isEmpty()) {
                item {
                    Text("Chưa có bối cảnh nào — máy sẽ tự tạo khi LLM phát hiện qua location_name lúc " +
                        "phân tích kịch bản, hoặc tạo tay ở khung phía trên.",
                        color = C.T3, fontSize = 12.sp)
                }
            }

            items(locations, key = { it.id }) { loc ->
                Surface(color = C.S1, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Border)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LocationThumb(loc.anchorImagePath)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(loc.name, color = C.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    if (loc.anchorImagePath != null) "Đã có ảnh neo ✓" else "Chưa có ảnh neo — máy tự lấy ở panel đầu tiên",
                                    color = if (loc.anchorImagePath != null) C.Green else C.T3, fontSize = 11.sp)
                            }
                            IconButton(onClick = { confirmDeleteFor = loc }) {
                                Icon(Icons.Default.Delete, null, tint = C.Red)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MlOutlineBtn(if (loc.anchorImagePath != null) "Đổi ảnh khác" else "Chọn ảnh bối cảnh",
                                icon = Icons.Default.Image, modifier = Modifier.weight(1f),
                                onClick = { pickingFor = loc; pickImageLauncher.launch(arrayOf("image/*")) })
                            if (loc.anchorImagePath != null) {
                                MlOutlineBtn("Xoá ảnh neo", icon = Icons.Default.Close, color = C.Orange,
                                    modifier = Modifier.weight(1f),
                                    onClick = { vm.clearLocationAnchor(loc) })
                            }
                        }
                        // mục 266 TECHNICAL_STATUS.md — TẠO ẢNH NỀN KHÔNG CÓ NGƯỜI bằng AI ngay tại đây, chọn nguồn: theo cấu hình hiện tại (SD trên máy/Remote GPU)
                        // hoặc API MIỄN PHÍ (Cloudflare Workers AI / Pollinations). Ảnh tạo xong thành ảnh neo của bối cảnh (người dùng vẫn đổi/xoá được như trước).
                        Spacer(Modifier.height(8.dp))
                        MlOutlineBtn(
                            if (bgBusyId == loc.id) "Đang tạo ảnh nền..." else "Tạo ảnh nền bằng AI (chọn nguồn)",
                            icon = Icons.Default.AutoAwesome, color = C.Blue,
                            enabled = bgBusyId == null,
                            onClick = { chooseSourceFor = loc })
                        // mục 220 TECHNICAL_STATUS.md — ghi chú khung hình
                        // tường minh, trả lời câu hỏi user "làm sao cho tỷ
                        // lệ/góc máy/xa-gần hợp lý khi ghép bối cảnh với
                        // nhân vật" — xem giải thích đầy đủ (VÀ giới hạn
                        // thật — đây KHÔNG PHẢI giải bài toán phối cảnh 3D
                        // tự động, chỉ là ghi chú chữ cho LLM tham khảo) ở
                        // Location.referenceFraming, Models.kt.
                        var framingText by remember(loc.id) { mutableStateOf(loc.referenceFraming ?: "") }
                        Spacer(Modifier.height(8.dp))
                        Text("Ghi chú khung hình (giúp LLM giữ tỷ lệ nhất quán qua nhiều panel)",
                            color = C.T3, fontSize = 10.sp)
                        Row(verticalAlignment = Alignment.Top) {
                            OutlinedTextField(value = framingText, onValueChange = { framingText = it },
                                placeholder = { Text("vd: chụp ngang hông, cửa ra vào bên trái, người đứng sát cửa cao ~60% khung hình", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f), minLines = 2, maxLines = 4,
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                                    focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
                            if (framingText.trim() != (loc.referenceFraming ?: "")) {
                                IconButton(onClick = { vm.setLocationFraming(loc, framingText) }) {
                                    Icon(Icons.Default.Check, null, tint = C.Green)
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    chooseSourceFor?.let { loc ->
        ImageSourceDialog(
            title = "Tạo ảnh nền — ${loc.name}",
            freeImage = settingsNow.freeImage,
            onPick = { src -> chooseSourceFor = null; vm.generateLocationBackground(loc, src) },
            onDismiss = { chooseSourceFor = null }
        )
    }

    confirmDeleteFor?.let { loc ->
        AlertDialog(
            onDismissRequest = { confirmDeleteFor = null }, containerColor = C.S1,
            title = { Text("Xoá bối cảnh \"${loc.name}\"?", color = C.T1) },
            text = { Text("Xoá cả ảnh neo (nếu có). Panel đã sinh trước đó KHÔNG bị xoá — chỉ Location " +
                "này không còn để tra cứu/tham chiếu nữa. Nếu LLM còn dùng đúng tên này ở chương sau, " +
                "1 Location mới (không ảnh neo) sẽ tự được tạo lại.", color = C.T2, fontSize = 12.sp) },
            confirmButton = {
                TextButton(onClick = { vm.deleteLocation(loc); confirmDeleteFor = null }) {
                    Text("Xoá", color = C.Red)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDeleteFor = null }) { Text("Huỷ", color = C.T3) } }
        )
    }
}

@Composable
private fun LocationThumb(path: String?) {
    val bitmap = remember(path) {
        if (path == null) null
        else try { android.graphics.BitmapFactory.decodeFile(path)?.asImageBitmap() } catch (e: Exception) { null }
    }
    Box(Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)).background(C.S2), contentAlignment = Alignment.Center) {
        if (bitmap != null) {
            Image(bitmap = bitmap, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Icon(Icons.Default.Image, null, tint = C.T3, modifier = androidx.compose.ui.Modifier.size(22.dp))
        }
    }
}
