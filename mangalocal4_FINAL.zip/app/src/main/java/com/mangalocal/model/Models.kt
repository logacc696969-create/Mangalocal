package com.mangalocal.model

import java.io.File

// ── Nhân vật ──────────────────────────────────────────────────────────────
enum class CharacterRole { MAIN, SUPPORTING, ONETIME }

// Tỷ lệ xương THẬT theo TỪNG NHÂN VẬT (mục 31 TECHNICAL_STATUS.md) — thay
// AgeCategory chung chung (mục 30, đã lùi thành PRESET tham khảo, không
// còn là nguồn dữ liệu chính). User chỉ ra đúng: cùng tuổi có thể cao/thấp/
// dậy thì sớm-muộn khác nhau — nên tỷ lệ phải gán được RIÊNG từng nhân
// vật, không chỉ chọn 1 trong 3 nhóm tuổi cứng.
//
// Đơn vị: hệ số NHÂN so với tỷ lệ chuẩn (1.0 = trung bình người lớn dùng
// làm mốc). Ví dụ đùi ngắn hơn trung bình 20% -> upperLegRatio = 0.8.
// 5 đoạn xương chính đủ cho FK retargeting 2D (mục 32) — KHÔNG chia nhỏ
// hơn (vd đốt ngón tay) vì OpenPose-18 không có đủ khớp để phân biệt.
data class BoneProportions(
    val torsoRatio: Float = 1.0f,      // neck -> hip-center (trục thân)
    val upperArmRatio: Float = 1.0f,   // shoulder -> elbow
    val forearmRatio: Float = 1.0f,    // elbow -> wrist
    val upperLegRatio: Float = 1.0f,   // hip -> knee
    val lowerLegRatio: Float = 1.0f,   // knee -> ankle
    val headSizeRatio: Float = 1.0f    // xấp xỉ qua khoảng cách mắt-mũi (KHÔNG chính xác tuyệt đối — xem mục 30 giới hạn OpenPose-18 không có điểm đỉnh đầu)
) {
    companion object {
        // Preset tham khảo NHANH (mục 30), KHÔNG PHẢI số liệu y văn đã kiểm
        // chứng riêng — chỉ là điểm khởi đầu hợp lý để user tự tinh chỉnh
        // tiếp bằng slider trong UI, không nên tin tuyệt đối.
        fun presetChild() = BoneProportions(torsoRatio = 0.85f, upperArmRatio = 0.8f, forearmRatio = 0.8f,
            upperLegRatio = 0.75f, lowerLegRatio = 0.75f, headSizeRatio = 1.3f)
        fun presetTeen() = BoneProportions(torsoRatio = 0.93f, upperArmRatio = 0.9f, forearmRatio = 0.9f,
            upperLegRatio = 0.88f, lowerLegRatio = 0.88f, headSizeRatio = 1.1f)
        fun presetAdult() = BoneProportions() // 1.0 mọi mặt = mốc chuẩn
    }

    // mục 123 TECHNICAL_STATUS.md — user chỉ ra ĐÚNG: tham khảo (không bê
    // nguyên xi) kỹ thuật thật cộng đồng AI-comic dùng để giữ tỷ lệ nhân
    // vật ổn định — "reference sheet đo bằng ĐƠN VỊ ĐẦU" (vd "7.5-head-
    // tall, shoulder width exactly 2.1 heads") + "anchor prompting" (nhúng
    // tỷ lệ THẲNG vào text prompt làm kênh CỦNG CỐ THỨ 2, song song với
    // điều kiện hình học ControlNet-Pose — không chỉ dựa 1 kênh duy nhất).
    // Đây là quy ước "N đầu" cổ điển trong dạy vẽ nhân vật (người lớn ~7.5
    // đầu, thiếu niên ~6-6.5 đầu, trẻ em ~5 đầu, chibi ~2-3 đầu) — tính
    // GẦN ĐÚNG từ chính 5 tỷ lệ xương đã có (không cần dữ liệu mới), neo
    // mốc "người lớn = 7.5 đầu" (giá trị tham khảo phổ biến trong sách dạy
    // vẽ, KHÔNG PHẢI số đo y văn tuyệt đối — cùng tinh thần "GIỚI HẠN THẬT"
    // đã ghi cho preset trên).
    //
    // GIỚI HẠN THẬT: đây là XẤP XỈ tuyến tính đơn giản (trung bình có trọng
    // số các tỷ lệ ảnh hưởng chiều cao tổng — thân+đùi+cẳng chân, KHÔNG
    // tính tay vì tay không ảnh hưởng "chiều cao đứng"), không phải phép
    // đo hình học chính xác từ khung xương thật. Mục đích DUY NHẤT là tạo
    // 1 cụm mô tả PROMPT TEXT nhất quán với khung xương ControlNet-Pose,
    // không phải số liệu để tính toán hình học nào khác trong pipeline.
    fun approxHeadsTall(): Float {
        val heightRatio = (torsoRatio * 0.4f + upperLegRatio * 0.3f + lowerLegRatio * 0.3f)
        return 7.5f * heightRatio
    }

    /** Cụm tag prompt củng cố tỷ lệ cơ thể — nhúng vào text SONG SONG với
     * khung xương ControlNet-Pose (không thay thế), đúng kỹ thuật "anchor
     * prompting" đã tra cứu. Trả về "" nếu xấp xỉ 7.5 đầu (người lớn chuẩn,
     * không cần nhấn mạnh gì thêm — tránh làm prompt dài không cần thiết
     * cho trường hợp phổ biến nhất). */
    fun headsTallPromptTag(): String {
        val heads = approxHeadsTall()
        if (heads > 7.0f) return "" // ~người lớn chuẩn — không cần tag thêm
        val roundedHeads = (heads * 2).let { kotlin.math.round(it) / 2 } // làm tròn 0.5 đầu — đủ mượt, không giả vờ chính xác hơn thật có
        return when {
            heads < 3.5f -> "($roundedHeads heads tall, chibi proportions, oversized head, short limbs:1.1)"
            heads < 5.5f -> "($roundedHeads heads tall, child body proportions, large head relative to body:1.1)"
            else -> "($roundedHeads heads tall, youthful body proportions:1.1)"
        }
    }
}

// 3 phương pháp nhất quán nhân vật (mục 12/13 TECHNICAL_STATUS.md) + NONE
// (chỉ mô tả bằng chữ, không neo gì — dùng cho vai phụ/qua đường không cần
// đầu tư). Độ nhất quán ước lượng CỘNG ĐỒNG SD nói chung (CHƯA đo trên
// chính pipeline này — xem ghi chú tại nơi hiển thị cho user):
// LORA ~90-100% > IP_ADAPTER ~80-90% > TEXTUAL_INVERSION ~40-65% > NONE (0%,
// chỉ dựa mô tả chữ + seed cố định).
enum class ConsistencyMethod { LORA, IP_ADAPTER, TEXTUAL_INVERSION, NONE }

// mục 69 TECHNICAL_STATUS.md — "LoRA Addon" (chất lượng chung, áp dụng
// TOÀN CỤC cho mọi nhân vật/model, khác loraPath của Character ở dưới —
// đó là LoRA RIÊNG 1 nhân vật). Xác nhận trước mục này: khái niệm này
// KHÔNG tồn tại ở bất kỳ đâu trong app (grep mục 67), review nói sai khi
// bảo "tầng dữ liệu đã có, chỉ thiếu UI" — giờ mới thêm từ đầu.
// GIỚI HẠN THẬT (không tô hồng): pipeline C++ CHỈ hỗ trợ merge LoRA vào
// checkpoint tại THỜI ĐIỂM CONVERT (sd_model_converter.cpp), KHÔNG có cơ
// chế nạp/gỡ LoRA lúc SINH ẢNH (generate) — xem PipelineSd15Cpu.hpp/
// PipelineSdxlCpu.hpp, không có bất kỳ hàm loadLora() nào ở tầng inference.
// Nghĩa là: bật/tắt hoặc đổi weight 1 addon LoRA KHÔNG áp dụng ngay cho
// các model ĐÃ convert trước đó — phải CONVERT LẠI (StoryManager.
// convertAndRegisterModel() tự động gộp addon LoRA đang enabled vào MỌI
// lần convert TỪ SAU KHI thêm addon, xem StoryManager.listAddonLoras()).
data class AddonLora(
    val id: String,
    val displayName: String,
    val fileName: String,      // tên file trong lorasDir/addons/ (đã copy từ URI người dùng chọn)
    val weight: Float = 0.7f,
    val enabled: Boolean = true,
)

// mục 154 TECHNICAL_STATUS.md — "đảo pipeline nhân vật" (đã ghi CHƯA LÀM ở
// nhiều mục cũ, quyết định tự triển khai). KHÔNG phải Character đầy đủ —
// chỉ dữ liệu THÔ từ bước phân tích SƠ BỘ (rẻ, nhanh) trước khi viết kịch
// bản chi tiết, để user xác nhận/chỉnh vai trò TRƯỚC khi LLM viết panel
// thật. `briefDescription` là câu mô tả 1 dòng LLM tự tóm tắt (có thể sai/
// thiếu — user xem trước, không phải anchor prompt chính thức).
data class CharacterSummary(
    val name: String,
    val suggestedRole: CharacterRole,
    val briefDescription: String
)

data class Character(
    val id: String,
    val name: String,
    val anchorPrompt: String,
    val negativePrompt: String = "bad anatomy, deformed, ugly, blurry",
    val seed: Long,
    val role: CharacterRole = CharacterRole.MAIN,
    val loraPath: String? = null,
    val loraWeight: Float = 0.75f,
    val anchorImagePath: String? = null,   // ảnh gốc nhân vật, dùng làm reference thật cho IP-Adapter
    // mục 95 TECHNICAL_STATUS.md — ảnh tham chiếu THAY THẾ khi nhân vật ở
    // trạng thái vừa vật lộn/chiến đấu (trang phục xộc xệch/rách), tự sinh
    // qua StoryManager.generateTornReferenceImage() bằng img2img từ chính
    // anchorImagePath — null = chưa từng tạo, MangaPipeline tự rơi về
    // anchorImagePath thường (không có gì đổi hành vi cũ nếu chưa tạo).
    val tornAnchorImagePath: String? = null,
    // Textual Inversion (mục 12 TECHNICAL_STATUS.md) — phương pháp thứ 3,
    // độc lập với loraPath/anchorImagePath, có thể dùng CÙNG LÚC với 1
    // trong 2 cái kia hoặc đứng riêng. embeddingTrigger = tên file (không
    // đuôi) trong StoryManager.embeddingsDir — chính là từ cần gõ trong
    // prompt để kích hoạt (xem StoryManager.setCharacterEmbedding).
    val embeddingPath: String? = null,
    val embeddingTrigger: String? = null,
    // Tỷ lệ xương THẬT của nhân vật này (mục 31 TECHNICAL_STATUS.md — thay
    // AgeCategory chung chung bằng số đo RIÊNG từng nhân vật, vì user chỉ
    // ra đúng: cùng tuổi vẫn có thể cao/thấp/dậy thì sớm-muộn khác nhau,
    // "profile theo nhóm tuổi" không đủ chính xác). Đơn vị: TỶ LỆ so với
    // 1 đơn vị tham chiếu cố định (khoảng cách vai-hông = 1.0), không phải
    // cm thật — vì ControlNet-Pose làm việc trên toạ độ ảnh 0..1, không
    // cần biết chiều cao thật bằng cm.
    val boneProportions: BoneProportions = BoneProportions()
)

// ── Truyện ────────────────────────────────────────────────────────────────
data class Story(
    val id: String,
    val title: String,
    val description: String = "",
    val style: ImageStyle = ImageStyle.REALISTIC,
    val characters: List<Character> = emptyList(),
    val chapterIds: List<String> = emptyList(),
    // Quy tắc bối cảnh chung (tiếng Việt tự nhiên, user tự viết) — LLM dùng
    // làm ngữ cảnh nền khi dịch mô tả cảnh sang prompt SD1.5, áp dụng cho
    // CẢ 3 giai đoạn (txt2img/upscale-redraw/inpaint), xem PromptStage.
    val worldRules: String = "",
    // Ghi chú hướng dẫn LLM VIẾT PROMPT cho SD1.5 (mục 54 TECHNICAL_STATUS.md
    // — khác worldRules ở trên: worldRules là NGỮ CẢNH TRUYỆN (nhân vật, thế
    // giới...), còn field này là PHONG CÁCH VIẾT TAG mà user muốn LLM áp
    // dụng riêng cho checkpoint SD1.5 đang dùng — vd "checkpoint này thích
    // tag kiểu danbooru", "luôn thêm 'watercolor style'", "nhân vật lính
    // cứu hỏa cần tag 'firefighter uniform, yellow helmet' mới lên đúng
    // ngoại hình dù đã tả trong worldRules". LỚP THÊM VÀO, không thay thế,
    // bộ hướng dẫn CỐ ĐỊNH đã kiểm chứng (cú pháp emphasis/weight thật của
    // PromptProcessor.hpp) — xem LLMParser.SD15_PROMPT_GUIDE.
    val promptGuideNotes: String = "",
    // mục 71 TECHNICAL_STATUS.md — Model Binding (item #5 còn treo mục 70).
    // null = truyện CHƯA sinh ảnh lần nào, chưa khoá model gì (tự khoá vào
    // model đang chọn ở lần sinh ĐẦU TIÊN — xem MainViewModel.bindModelIfNeeded()).
    // Sau khi khoá: nếu settings.sdModelId khác giá trị này lúc sinh/vẽ lại,
    // app CHẶN và báo lỗi rõ ràng thay vì âm thầm đổi phong cách giữa
    // chương — đúng cảnh báo "đổi checkpoint giữa chừng 1000 chương sẽ làm
    // gãy phong cách" của review. Đổi được qua nút "Đổi model cho truyện
    // này" tường minh (StoryDetailScreen) — không có "Migration" tự động
    // convert lại panel cũ (CHƯA làm, xem TECHNICAL_STATUS.md mục 71).
    val boundSdModelId: String? = null,
    // mục 78 TECHNICAL_STATUS.md — Concept Dictionary: bật/tắt tra cứu từ
    // điển khái niệm (storyDir/concept_dictionary.json, quản lý qua
    // ConceptDictionary.kt) khi build prompt cho LLM. Mặc định BẬT — không
    // có tác dụng phụ khi dict rỗng (buildInjectionText() trả "" nếu trống).
    val conceptDictionaryEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

// 3 giai đoạn cần dịch prompt khác nhau (mục 24 TECHNICAL_STATUS.md) — mỗi
// giai đoạn cần trọng tâm khác nhau khi LLM dịch mô tả tự nhiên sang tag
// SD1.5: TXT2IMG cần mô tả ĐẦY ĐỦ cảnh; UPSCALE_REDRAW chỉ cần tag về CHẤT
// LƯỢNG BỀ MẶT (không mô tả lại toàn cảnh — ảnh đã có bố cục, chỉ cần làm
// nét/sửa texture); INPAINT chỉ cần mô tả HÀNH ĐỘNG/VÙNG cụ thể đang sửa,
// không nhắc lại toàn bộ scene (theo đúng nguyên tắc "prompt tập trung vào
// hành động" đã thống nhất).
enum class PromptStage { TXT2IMG, UPSCALE_REDRAW, INPAINT }

// ── Model file ────────────────────────────────────────────────────────────
data class ModelInfo(
    val path: String,
    val name: String,
    val type: ModelType,
    val sizeBytes: Long
) {
    val displaySize: String get() {
        val gb = sizeBytes / 1_073_741_824.0
        val mb = sizeBytes / 1_048_576.0
        return if (gb >= 1.0) "%.1fGB".format(gb) else "%.0fMB".format(mb)
    }
}
enum class ModelType { SD15, LLM, LORA, ESRGAN, YOLO }

// mục 93 TECHNICAL_STATUS.md — kiểu prompt checkpoint MONG ĐỢI, KHÔNG phải
// "SD1.5 vs SDXL" như hiểu lầm ban đầu — phụ thuộc checkpoint CỤ THỂ nào
// được nạp (checkpoint anime-tag như Illustrious/Pony VẪN cần TAG_BASED dù
// chạy trên SDXL; checkpoint ảnh thực như Realistic Vision/RealVisXL cần
// NATURAL_LANGUAGE dù chạy trên SD1.5). File checkpoint (.mnn) KHÔNG mang
// theo thông tin này — không có cách tự dò chắc chắn, phải người dùng tự
// khai báo (xem chú thích UI ở SettingsScreen.kt) hoặc chạy So Sánh Thử
// (MainViewModel.runPromptStyleComparison()) để mắt tự quyết.
enum class PromptStyle {
    TAG_BASED,          // "1girl, blue hair, torn shirt, wrinkled fabric" — SD1.5/SDXL anime-tag (Illustrious, Pony, đa số checkpoint anime cộng đồng)
    NATURAL_LANGUAGE     // "a girl with blue hair wearing a torn shirt, fabric wrinkled at the shoulder" — SDXL base, RealVisXL, Juggernaut XL, checkpoint ảnh thực
}

// ── Local/Remote GPU routing (tính năng mới) ───────────────────────────────
// Cho phép sinh ảnh chạy trên GPU thuê ngoài (Colab miễn phí / RunPod-Vast.ai
// trả phí) thay vì bắt buộc chạy local trên điện thoại. QUAN TRỌNG — đã bàn
// kỹ với user: KHÔNG có cách nào đảm bảo tuyệt đối "chủ GPU không soi được"
// với GPU thuê thông thường — chủ hạ tầng (hypervisor) luôn có khả năng đọc
// VRAM/RAM của VM đang chạy, mã hoá ngay sau khi sinh không chặn được việc
// này (không phải vấn đề tốc độ/thời gian). Chỉ Confidential Computing (TEE
// phần cứng, vd NVIDIA H100/H200 chế độ CC) mới thật sự chặn được cả chủ
// hạ tầng — 2 tier dưới đây phản ánh đúng 2 mức thật, KHÔNG quảng cáo quá.
enum class RemoteSecurityTier {
    // TLS trên đường truyền + không lưu log/file phía server + xoá ngay sau
    // khi trả kết quả (ephemeral). CHỈ chống được: người đứng giữa mạng,
    // và (nếu server thật sự tuân thủ code đã viết) chống rò rỉ qua log/đĩa.
    // KHÔNG chống được: chính chủ hạ tầng (Google/chủ máy RunPod) nếu họ cố
    // tình soi VM đang chạy. Phù hợp: Colab miễn phí, GPU rental thường.
    TLS_EPHEMERAL,
    // GPU hỗ trợ Confidential Computing (TEE) thật + attestation xác minh
    // trước khi gửi dữ liệu. Chống được cả chủ hạ tầng. Chỉ khả dụng ở 1 số
    // nhà cung cấp đặc thù (vd Azure Confidential VM với H100 CC), CHƯA
    // triển khai thật trong bản này — cờ có sẵn để bật khi có provider phù hợp.
    CONFIDENTIAL_COMPUTING
}

enum class GenerationBackend { LOCAL, REMOTE }

// Chế độ chọn backend cho TỪNG panel:
// MANUAL: người dùng tự chọn qua PanelOverrideSettings.backendOverride
//         (hoặc mặc định GenerationSettings.defaultBackend nếu panel không
//         override riêng).
// AUTO:   LLM (MNN-LLM local, cùng model đang dùng để parse kịch bản) tự
//         quyết định LOCAL hay REMOTE cho từng panel, dựa theo
//         GenerationSettings.autoRoutingPolicyPrompt do NGƯỜI DÙNG tự viết
//         (vd "cảnh nhạy cảm/riêng tư thì local, còn lại remote cho nhanh").
//         Xem BackendRouter.kt. Quyết định LUÔN có thể bị override tay qua
//         backendOverride của panel đó (override tay ưu tiên tuyệt đối hơn AUTO).
enum class RoutingMode { MANUAL, AUTO }

// Quy tắc khai báo TRƯỚC cho chế độ MANUAL (mục "phân chia thủ công theo
// nhân vật/từ khoá", KHÔNG áp dụng cho AUTO — AUTO chỉ dùng LLM đọc
// autoRoutingPolicyPrompt, xem AutoBackendRouter, không hardcode theo
// nhân vật/scene ở tầng Kotlin để giữ đúng yêu cầu "quy tắc do người dùng
// nêu trong prompt, không hardcode"). Ở MANUAL thì NGƯỢC LẠI — đây chính là
// nơi user khai báo cứng theo ý mình (vd "nhân vật Lan luôn local"), xử lý
// bằng code Kotlin thuần (deterministic), không qua LLM — vì MANUAL nghĩa
// là user muốn chắc chắn 100%, không phụ thuộc LLM có hiểu đúng ý hay không.
enum class RoutingMatchType { CHARACTER, KEYWORD }

data class ManualRoutingRule(
    val id: String = java.util.UUID.randomUUID().toString(),
    val matchType: RoutingMatchType = RoutingMatchType.CHARACTER,
    // CHARACTER: khớp khi tên này có trong panel.scene.characters (so khớp
    // không phân biệt hoa/thường). KEYWORD: khớp khi cụm này xuất hiện
    // (contains, không phân biệt hoa/thường) trong description/action/setting
    // của scene — dùng cho quy tắc không gắn với 1 nhân vật cụ thể (vd "cảnh
    // trong nhà tắm luôn local").
    val value: String,
    val backend: GenerationBackend
)
// Thứ tự trong list QUYẾT ĐỊNH ưu tiên khi 1 panel khớp ≥2 rule mâu thuẫn
// nhau (vd panel có cả nhân vật "luôn local" VÀ khớp từ khoá "luôn remote")
// — rule đứng TRƯỚC trong list thắng. Xem ManualBackendRouter.decide().

// Cấu hình endpoint remote — 1 cấu hình DÙNG CHUNG cho cả Story (không phải
// riêng từng panel, vì đổi server giữa chừng 1 chapter không hợp lý — nếu
// cần nhiều server khác nhau, đổi ở SettingsScreen rồi chạy lại panel cần đổi).
// Cấu hình LLM NGOÀI qua API chuẩn OpenAI-compatible (chat completions) —
// thay thế cho LLM local (.gguf qua llama.cpp) khi máy yếu hoặc muốn dùng
// model mạnh hơn. KHÁC với RemoteEndpointConfig (đó là cho SINH ẢNH qua
// server tự host + mã hoá riêng) — đây là API THẬT của bên thứ 3 (OpenAI,
// OpenRouter, Groq...) hoặc server tương thích OpenAI tự host (LM Studio,
// Ollama...), chỉ có TLS chuẩn, KHÔNG có lớp mã hoá thêm nào. Xem
// ExternalLlmClient.kt.
data class ExternalLlmConfig(
    val enabled: Boolean = false,
    val baseUrl: String = "",      // vd "https://api.openai.com/v1", "https://openrouter.ai/api/v1", hoặc URL server tự host tương thích OpenAI
    val apiKey: String = "",
    val modelName: String = "",    // vd "gpt-4o-mini", "anthropic/claude-3.5-sonnet" (OpenRouter), tên model server tự host...
    val timeoutSeconds: Int = 60
)

data class RemoteEndpointConfig(
    val enabled: Boolean = false,
    val baseUrl: String = "",           // vd "https://xxxx.ngrok-free.app" (Colab+tunnel) hoặc IP:port (RunPod)
    val authToken: String = "",         // Bearer token — do user tự đặt khi chạy remote_server/app.py, KHÔNG hardcode
    val securityTier: RemoteSecurityTier = RemoteSecurityTier.TLS_EPHEMERAL,
    val timeoutSeconds: Int = 180,      // Colab free có thể chậm lúc cold-start model — timeout dài hơn HTTP thường
    // Ghim public key/cert của server (certificate pinning) — RỖNG = không
    // ghim (chỉ dựa vào CA hệ thống, chấp nhận được cho Colab/ngrok vì domain
    // đổi mỗi lần chạy lại). Điền vào nếu dùng server cố định (RunPod/VPS
    // riêng) để chống MITM kể cả khi 1 CA nào đó trong hệ thống bị xâm phạm.
    val pinnedCertSha256: String = "",

    // Chọn model TRƯỚC KHI generate (không phải giữa chừng từng panel) — để
    // trống = server dùng đúng --model đặt lúc khởi động (hành vi cũ). Điền
    // vào nếu muốn đổi sang model KHÁC mà không cần khởi động lại cả server
    // (server tự phát hiện model_id đổi so với lần trước, tự load lại; giữ
    // nguyên nếu giống lần trước, không tốn thời gian mỗi panel). Áp dụng
    // cho CẢ chương truyện, đặt 1 lần ở Cài đặt trước khi generate.
    val remoteModelId: String = "",      // HuggingFace repo id hoặc đường dẫn checkpoint trên server, vd "stabilityai/stable-diffusion-xl-base-1.0"
    val remoteModelType: RemoteModelType = RemoteModelType.SD15
)

// Kiến trúc model remote — KHÔNG giới hạn ở SD1.5 nữa (đó là giới hạn của
// pipeline LOCAL trên điện thoại, không phải giới hạn vốn có của remote GPU
// mạnh hơn nhiều). SDXL cần ControlNet/IP-Adapter RIÊNG (checkpoint khác hẳn
// SD1.5, không dùng chung được) — server tự chọn đúng bộ theo giá trị này.
enum class RemoteModelType(val label: String) {
    SD15("SD 1.5 (mặc định, tương thích LoRA/pose local)"),
    SDXL("SDXL (chất lượng cao hơn, cần GPU khoẻ hơn, LoRA/ControlNet SD1.5 KHÔNG dùng chung được)")
}

// ── Cài đặt ───────────────────────────────────────────────────────────────
data class GenerationSettings(
    // sdModelPath/loraPath/loraWeight: CÒN GIỮ (đánh dấu @Deprecated) để
    // KHÔNG phá tương thích ngược nếu có settings JSON cũ đã lưu field
    // này trên máy user — Gson bỏ qua field lạ khi parse, không cần field
    // rỗng vẫn tồn tại trong data class, nhưng giữ lại rõ ràng hơn là để
    // Gson âm thầm bỏ qua. KHÔNG còn được `ImagePipeline.loadSD()` dùng —
    // engine mới dùng `sdModelId` (khớp "id" trong model_manifest.json) +
    // `storyManager.modelsDir` (thư mục CỐ ĐỊNH trong app, không phải field
    // settings) — xem `sdModelId` bên dưới.
    @Deprecated("Dùng sdModelId + storyManager.modelsDir (thư mục cố định, không còn là field settings)") val sdModelPath: String = "",
    val llmModelPath: String = "",
    @Deprecated("LoRA giờ merge sẵn lúc convert .mnn (offline), không nạp runtime nữa — xem NOTICE_local-dream.md") val loraPath: String = "",
    @Deprecated("Không dùng ở engine mới") val loraWeight: Float = 0.75f,
    // ── Engine mới (MNN, xem model_manifest.json trong assets) ──────────
    // mục 137/138 TECHNICAL_STATUS.md — ĐÃ XOÁ 2 field chết ở đây:
    // `sdModelDir` (String, comment cũ tự nhận là "cách làm MỚI" nhưng
    // `loadSD()` thật luôn dùng `storyManager.modelsDir.absolutePath` cố
    // định, KHÔNG BAO GIỜ đọc field này — comment SAI SỰ THẬT so với code,
    // xác nhận bằng audit mục 137) và `useVulkan` (Boolean, không UI,
    // không ai đọc — cơ chế Vulkan thật đi qua
    // `RuntimeOptimizer.OptimalConfig.sdUseVulkan` tự dò phần cứng, hoàn
    // toàn tách biệt khỏi field này). Xoá thay vì thêm UI cho field không
    // ai đọc — thêm UI chỉ tạo thêm 1 lớp vỏ rỗng mới.
    val sdModelId: String = "sd15_manga_base", // phải khớp "id" trong model_manifest.json
    val useOpenCL: Boolean = true, // GPU Adreno; false = ép CPU (chẩn đoán lỗi)
    // mục 60 TECHNICAL_STATUS.md — fallback NPU(QNN)->GPU->CPU thật cho
    // diffusion. Mặc định FALSE (khác useOpenCL mặc định TRUE) vì CHỈ có
    // tác dụng khi build với MANGALOCAL_ENABLE_QNN=ON (mặc định OFF) + máy
    // có QNN runtime libs — bật mặc định TRUE sẽ gây hiểu lầm "có tăng tốc"
    // trên build/máy không hỗ trợ, dù về mặt an toàn vẫn tự rớt về CPU/
    // OpenCL bình thường.
    val useNpu: Boolean = false,
    val imageStyle: ImageStyle = ImageStyle.REALISTIC,
    val panelCount: Int = 6,
    val width: Int = 512,
    val height: Int = 512,
    val steps: Int = 20,
    val cfgScale: Float = 7f,
    val upscaleOption: UpscaleOption = UpscaleOption.X4,
    // mục 138 TECHNICAL_STATUS.md — SỬA BUG THẬT: TRƯỚC ĐÂY field này có
    // UI (Slider "Threads") nhưng KHÔNG AI ĐỌC — mọi nơi cần số thread LLM
    // đều dùng `optimalConfig.nThreads` (tự tính từ phần cứng dò được qua
    // `RuntimeOptimizer`, bỏ qua hoàn toàn giá trị field này) — UI VỎ RỖNG
    // xác nhận 100%. Đã nối thật: `nThreadsAutoDetect=true` (mặc định) →
    // GIỮ NGUYÊN hành vi tự tối ưu theo phần cứng như trước (không đổi gì
    // cho ai chưa đụng Settings); tắt cờ này → dùng ĐÚNG giá trị `nThreads`
    // dưới đây làm override tay, ghi đè `optimalConfig.nThreads` (xem
    // `MangaPipeline.effectiveNThreads()`). Không xoá tính năng tự tối ưu
    // (đã ghi rõ trong docstring `RuntimeOptimizer` là tính năng có chủ
    // đích) — chỉ thêm lối thoát cho user muốn tự chỉnh tay.
    val nThreadsAutoDetect: Boolean = true,
    val nThreads: Int = 4,
    val useStoryDiffusion: Boolean = true,
    // mục 71 TECHNICAL_STATUS.md — Seed Propagation (kế thừa seed giữa các
    // panel LIÊN TIẾP cùng scene.setting, tạo cảm giác góc máy/ánh sáng
    // nền đứng yên xuyên nhiều panel — vd 1 trận đánh kéo dài 3 panel
    // cùng bối cảnh). Mặc định FALSE (mỗi panel seed ngẫu nhiên độc lập,
    // đúng hành vi chuẩn SD — xem MangaPipeline.resolveEffective() để biết
    // BUG THẬT đã sửa cùng lúc: trước mục 71, seed mặc định bị tính CỨNG
    // theo hash tên nhân vật, khiến MỌI panel của cùng 1 nhân vật luôn ra
    // đúng 1 seed — bố cục/góc máy lặp lại y hệt nhau bất kể bối cảnh).
    val seedInheritanceEnabled: Boolean = false,
    val consistencyStrength: Float = 0.8f,
    val slidingWindowSize: Int = 3,
    // Nhiệt độ
    val thermalThreshold: Int = 42,       // °C dừng lại
    val thermalResumeOffset: Int = 3,     // resume khi xuống threshold - offset
    val autoResume: Boolean = true,
    // Auto-fix mặt/tay (mục 17 TECHNICAL_STATUS.md, ADetailer-style) — dùng
    // MediaPipe FaceDetector+HandLandmarker (ĐÃ có sẵn cho pose, tái dùng,
    // không thêm dependency mới) để tự dò vùng mặt/tay rồi inpaint lại qua
    // sdImg2Img() vừa nối dây (mục 16). Mặc định TẮT vì CHƯA build-test lần
    // nào, và tốn thêm thời gian sinh (1 lượt img2img nữa/panel có phát
    // hiện được vùng). Không bắt được lỗi "dính người" tổng quát — CHỈ mặt/
    // tay (xem giới hạn đã bàn với user).
    val autoFixFacesHands: Boolean = false,
    val autoFixDenoiseStrength: Float = 0.45f,
    // Ultrafix (Hires-fix kiểu Ultimate SD Upscale — mục 16/20
    // TECHNICAL_STATUS.md): vẽ lại NHẸ toàn ảnh SAU khi ESRGAN phóng to,
    // trước auto-fix mặt/tay. Mặc định TẮT (chưa build-test, tốn thêm thời
    // gian đáng kể mỗi panel — chạy full tiled img2img ở độ phân giải cao).
    val useUltrafixRedraw: Boolean = false,
    val ultrafixDenoiseStrength: Float = 0.4f, // "thông số vàng" 0.35-0.45 theo khuyến nghị cộng đồng

    // mục 133 TECHNICAL_STATUS.md — Industrial Batch Mode (đúng nghĩa công
    // nghiệp: TOÀN BỘ ảnh đi qua ĐÚNG 1 model trước khi chuyển sang model
    // kế tiếp, không phải 1 ảnh đi qua HẾT các model rồi mới tới ảnh sau).
    // `upscaleApprovedPanels()` vốn xử lý XEN KẼ từng panel (ESRGAN →
    // Ultrafix → dò mặt/tay → inpaint, LẶP LẠI cho từng panel) — nghĩa là
    // ESRGAN/SD/MobileSAM/LLM đều phải resident CÙNG LÚC suốt cả vòng lặp.
    // Bật cờ này để tách thành 4 GIAI ĐOẠN tuần tự, MỖI giai đoạn xử lý
    // TẤT CẢ panel bằng ĐÚNG 1 loại model:
    //   1. ESRGAN (phóng to) cho tất cả panel → giải phóng ESRGAN.
    //   2. Ultrafix (SD, không cần mask) cho tất cả panel.
    //   3. Dò vùng mặt/tay + build mask (MobileSAM) cho tất cả panel →
    //      giải phóng MobileSAM.
    //   4. SD inpaint dùng mask đã build ở bước 3, cho tất cả panel.
    // Thứ tự chất lượng "ESRGAN trước, vẽ lại chi tiết sau" (mục 20 —
    // chuẩn Hires-fix-trước/ADetailer-sau) được GIỮ NGUYÊN cho TỪNG panel —
    // chỉ đổi thứ tự VÒNG LẶP NGOÀI (theo giai đoạn/model thay vì theo
    // panel), không đổi kết quả ảnh ra.
    // Lợi ích thật: RAM đỉnh giảm rõ hơn bản đầu (mục 133 bản đầu chỉ tách
    // ESRGAN) — giờ MobileSAM cũng không còn resident cùng lúc với SD nữa,
    // chỉ resident đúng trong giai đoạn 3 của nó. KHÔNG giảm RAM đỉnh của
    // SD (SD đã resident từ giai đoạn sinh ảnh trước đó, không bị đụng tới
    // ở đây).
    // Đánh đổi: chậm hơn ĐÔI CHÚT so với chế độ cũ nếu máy RAM dư dả (4
    // vòng lặp riêng thay vì 1 — KHÔNG phải nạp lại model nhiều lần, chỉ là
    // duyệt list panel 4 lần, chi phí rất nhỏ so với thời gian inference
    // thật). Mặc định TẮT — bật lên KHÔNG đổi ảnh ra (chỉ đổi trình tự
    // resident model), an toàn bật thử. CHƯA BUILD-TEST (như quy ước toàn
    // dự án — xem hoàn_thiện_sd1_5.txt Phần 2).
    val industrialBatchUpscaleMode: Boolean = false,

    // mục 74 TECHNICAL_STATUS.md — Quality Gate: tự động đếm chi/đo tỷ lệ
    // xương từ skeleton YOLOv8-pose đã có sẵn (KHÔNG chạy inference thêm),
    // auto-regenerate tối đa QualityGateChecker.MAX_RETRY lần nếu phát hiện
    // lỗi giải phẫu rõ ràng. Mặc định TẮT — làm chậm đáng kể (thêm 1-3 lần
    // forward UNet/panel), CHƯA build-test.
    val enableQualityGate: Boolean = false,
    // mục 74 — auto-fix vùng giao thoa hông/tay khi panel có ≥2 nhân vật
    // (tận dụng tryAutoFixInteractions() trong MangaPipeline). Chỉ có ý
    // nghĩa khi enableQualityGate=true (dùng chung skeleton data đã tính).
    val autoFixInteractions: Boolean = false,
    val autoFixInteractionStrength: Float = 0.55f, // cao hơn auto-fix mặt/tay (0.45)
    // mục 75 — dùng SeedRegistry (kho seed "hoàn hảo") để đề xuất seed cho
    // panel cấu trúc tương tự thay vì random hoàn toàn. Chỉ có tác dụng khi
    // enableQualityGate=true (seed chỉ được ghi vào registry khi pass gate).
    val useSeedRegistry: Boolean = true,

    // mục 81 TECHNICAL_STATUS.md — cân bằng Pose/Depth ControlNet khi dùng
    // Multi-ControlNet (mục 51). Default = giá trị khuyến nghị tài liệu
    // diffusers (controlnet_conditioning_scale 0.5-0.8 cho vai trò hỗ trợ,
    // 1.0-1.5 cho vai trò chính) — Pose là điều kiện CHÍNH (giữ nguyên
    // 1.0), Depth là HỖ TRỢ (giảm còn 0.6 để không "loãng" ranh giới cơ
    // thể Pose đã định). depthActiveMinTimestep: Depth chỉ tác động ở
    // early-to-mid step (timestep >= giá trị này trong thang 0-999) —
    // xấp xỉ tương đương control_guidance_end≈0.7. CHỈ có tác dụng với
    // model .mnn đã export lại theo mục 81 (export_ipa_controlnet_depth_
    // unet.py bản mới) — model cũ tự bỏ qua an toàn (native tự phát hiện
    // thiếu input tương ứng).
    val poseConditioningScale: Float = 1.0f,
    val depthConditioningScale: Float = 0.6f,
    val depthActiveMinTimestep: Float = 300.0f,

    // Smooth Timestep Decay cho IP-Adapter — MỞ RỘNG nguyên lý mục 81 (tham
    // số cân bằng ControlNet runtime) sang IP-Adapter. Đề xuất gốc trong
    // bổ_sung_sd1_5.txt/thêm_sd1_5.txt ("Smooth Timestep Decay Multiplier
    // cho IP-Adapter") — mục tiêu: identity IP-Adapter YẾU DẦN ở step cuối
    // quá trình sinh ảnh (thay vì giữ nguyên cường độ suốt), nhường chỗ cho
    // biểu cảm/chi tiết mặt do prompt text quyết định thay vì bị khoá cứng
    // theo ảnh tham chiếu. KHÁC depth_gate (cổng CỨNG bật/tắt): đây là suy
    // giảm TUYẾN TÍNH mượt — xem export_ipa_controlnet_unet.py/forward()
    // cho công thức đầy đủ.
    // GIỚI HẠN THẬT (đọc trước khi chỉnh số): scale ĐÚNG output attention
    // (đúng ý nghĩa set_ip_adapter_scale()) qua attention processor đã bọc
    // lúc export (xem tools/ip_adapter_decay.py) — KHÔNG còn là xấp xỉ
    // scale-input như bản đầu tiên của tính năng này. Còn lại: phụ thuộc
    // cấu trúc nội bộ diffusers cài lúc export (đã xác nhận khớp 0.39.0,
    // script tự dừng lỗi rõ ràng nếu không bọc được, không âm thầm sai) và
    // CHƯA xác nhận mức độ ảnh hưởng cảm nhận được trên ảnh thật bằng so
    // sánh A/B (chưa build-test được lần nào). CHỈ có
    // tác dụng với model .mnn đã export lại thêm 2 input này — model cũ tự
    // bỏ qua an toàn (native tự phát hiện thiếu input).
    // ipDecayFloor=1.0 (mặc định) = KHÔNG suy giảm gì, tương thích ngược
    // tuyệt đối. Giảm xuống (vd 0.4-0.6) để bật hiệu ứng; ipDecayStartTimestep
    // = mốc timestep BẮT ĐẦU suy giảm (999 = suy giảm ngay từ đầu, số nhỏ
    // hơn = giữ nguyên cường độ lâu hơn trước khi bắt đầu giảm).
    val ipDecayFloor: Float = 1.0f,
    val ipDecayStartTimestep: Float = 999.0f,

    // mục 107 TECHNICAL_STATUS.md — Tự động chỉnh Pose/Depth/Decay THEO
    // TỪNG CẢNH thay vì 1 bộ số cố định cho CẢ TRUYỆN. Trước đây 5 slider
    // ở trên (poseConditioningScale/depthConditioningScale/
    // depthActiveMinTimestep/ipDecayFloor/ipDecayStartTimestep) +
    // consistencyStrength bên dưới là GIÁ TRỊ TOÀN CỤC — cảnh đánh nhau và
    // cảnh 2 người tâm sự dùng CHUNG 1 bộ số, dù `Scene.actionCategory`
    // (mục 86) đã tự động phân loại khác nhau cho từng cảnh. Bật cờ này —
    // `MangaPipeline.resolveConditioning()` tự tra `ACTION_CONDITIONING_PRESETS`
    // theo `actionCategory` của TỪNG panel thay vì luôn dùng 6 giá trị tĩnh
    // ở trên. THỨ TỰ ƯU TIÊN: override tay từng panel
    // (`PanelOverrideSettings.conditioningOverride`, ĐÃ CÓ UI thật — xem
    // đính chính mục 139: nút "So Sánh Thử Pose/Depth" ở GalleryReviewScreen,
    // ghi qua `MainViewModel.applyConditioningChoice()`)
    // > preset tự động (nếu bật cờ này + actionCategory nhận diện được)
    // > 6 giá trị tĩnh ở trên (hành vi CŨ, khi tắt cờ hoặc actionCategory
    // null/lạ).
    // GIỚI HẠN THẬT — QUAN TRỌNG: các con số trong ACTION_CONDITIONING_PRESETS
    // là ƯỚC LƯỢNG HỢP LÝ dựa trên Ý NGHĨA của từng tham số (đã ghi ở mục
    // 81/97/99), KHÔNG PHẢI số liệu đã kiểm chứng bằng so sánh ảnh thật —
    // dùng cơ chế "So sánh thử" mới (mục 107, nút trong GalleryReviewScreen)
    // để tự xác nhận/tinh chỉnh trên panel thật của bạn trước khi tin
    // tưởng tuyệt đối. Mặc định TẮT (false) — bật lên KHÔNG đổi gì nếu
    // model .mnn chưa export lại theo mục 97/99 (input mới bị bỏ qua an
    // toàn), nhưng vẫn cần hiểu rõ trước khi bật cho truyện thật.
    val autoConditioningPresets: Boolean = false,

    // mục 79/80 TECHNICAL_STATUS.md — Auto-Histogram Guard: đo độ sáng ảnh
    // RAW trước Ultrafix, chèn tag bù trừ NHẸ nếu quá tối/quá sáng. Thuần
    // phân tích pixel-level (HistogramGuard.kt), KHÔNG cần model mới, chi
    // phí gần như 0. Mặc định TẮT — CHƯA BUILD-TEST như mọi tính năng mới
    // khác, và có giới hạn thật: không phân biệt được "tối cố ý" (cảnh
    // đêm) với "tối do lỗi" — xem docstring HistogramGuard.kt.
    val enableHistogramGuard: Boolean = false,

    // ── Local/Remote GPU routing (xem RemoteEndpointConfig/BackendRouter.kt) ──
    val routingMode: RoutingMode = RoutingMode.MANUAL,
    val defaultBackend: GenerationBackend = GenerationBackend.LOCAL, // dùng khi panel không override riêng VÀ routingMode=MANUAL
    val remoteEndpoint: RemoteEndpointConfig = RemoteEndpointConfig(),
    // Chỉ dùng khi routingMode=AUTO — hướng dẫn tự nhiên (tiếng Việt) cho LLM
    // quyết định panel nào local/remote. RỖNG = AutoBackendRouter dùng quy tắc
    // an toàn mặc định (fail-safe LOCAL, xem BackendRouter.kt), không tự bịa
    // tiêu chí khi user chưa nói rõ muốn gì.
    val autoRoutingPolicyPrompt: String = "",
    // Quy tắc khai báo trước cho MANUAL (xem ManualRoutingRule ở trên) — CHỈ
    // dùng khi routingMode=MANUAL, không ảnh hưởng AUTO.
    val manualRoutingRules: List<ManualRoutingRule> = emptyList(),

    // Hướng dẫn VIẾT KỊCH BẢN cho LLM (tiếng Việt tự nhiên) — user tự mô tả
    // văn phong, nhịp độ/tốc độ, thiết lập bối cảnh, biến tấu/twist mong
    // muốn, v.v. RỖNG = LLM tự quyết hoàn toàn theo mỗi câu chuyện, không
    // áp thêm quy tắc nào (giống đúng quy ước autoRoutingPolicyPrompt ở
    // trên — rỗng không có nghĩa là mất tính năng, chỉ là không ép thêm gì).
    // Dùng trong LLMParser.parseStory()/scenePrompt() — áp dụng cho MỌI
    // truyện, không riêng truyện nào.
    val llmStoryGuidance: String = "",

    // LLM ngoài qua API (xem ExternalLlmConfig/ExternalLlmClient.kt) — khi
    // enabled=true, LLMParser dùng API này THAY VÌ model .gguf local, không
    // cần llmModelPath nữa cho tác vụ viết kịch bản.
    val externalLlm: ExternalLlmConfig = ExternalLlmConfig(),

    // Phiên làm việc hiện tại (đóng gap "đã code nhưng thiếu UI" —
    // TECHNICAL_STATUS.md mục 82/84): trước đây 2 giá trị này hardcode ở
    // nơi gọi (ExportEngine.exportCbz mặc định 92, MangaPipeline.
    // cancelSafely mặc định 30_000L) — vẫn GIỮ NGUYÊN 2 default đó ở đây để
    // không đổi hành vi cho user chưa từng mở Settings, chỉ thêm đường cho
    // UI (SettingsScreen.kt) ghi đè.
    // Chất lượng nén JPEG khi đóng gói CBZ (ExportEngine.exportCbz) — 100 =
    // không nén (ảnh nặng hơn nhiều), 92 = mặc định cũ, thấp hơn 80 bắt đầu
    // thấy rõ artefact khối trên nét mảnh (lời thoại/viền bong bóng).
    val cbzJpegQuality: Int = 92,
    // Thời gian tối đa `cancelSafely()` (MangaPipeline.kt) đợi coroutine
    // sinh ảnh đang chạy dở dừng HẲN sau khi user bấm "Huỷ", trước khi báo
    // TimedOut thay vì Success — xem docstring đầy đủ ở cancelSafely().
    // Máy yếu/model to có thể cần hơn 30s cho 1 bước UNet blocking hoàn
    // tất; máy khoẻ có thể muốn rút ngắn để phát hiện treo sớm hơn.
    // mục 93 TECHNICAL_STATUS.md — key = tên file checkpoint (sdModelId hoặc
    // tên file .safetensors gốc dùng để convert, KHÔNG phải đường dẫn đầy
    // đủ — đường dẫn đổi khi convert lại, tên file thường ổn định hơn).
    // Thiếu key = mặc định TAG_BASED (giữ nguyên hành vi cũ 100% cho user
    // chưa từng khai báo gì — đa số checkpoint SD1.5 cộng đồng manga/anime
    // hiện có là tag-based, xem SD15_PROMPT_GUIDE cũ).
    val promptStyleOverrides: Map<String, PromptStyle> = emptyMap(),
    // mục 94 TECHNICAL_STATUS.md — bật thì tryAutoFixInteractions() build
    // THÊM mô tả trang phục xộc xệch/rách tại điểm chạm (dùng đúng
    // anchorPrompt của NHÂN VẬT BỊ CHẠM, dịch qua LLM theo PromptStyle
    // đang chọn) — mặc định TẮT, vì đây là lựa chọn NỘI DUNG (không phải
    // fix chất lượng chung như hand_over_body/hip_overlap luôn bật), user
    // tự quyết có muốn tính năng này hay không.
    val autoTearClothingAtContactPoints: Boolean = false,
    // mục 115/117 TECHNICAL_STATUS.md — Multi-Pass Inpainting Cascade: sau
    // lượt sinh bố cục chung (đa nhân vật, IP-Adapter mask), chạy THÊM 1
    // lượt img2img RIÊNG cho từng nhân vật (khoanh vùng cơ thể người đó,
    // denoise vừa phải, chỉ dùng ĐÚNG ảnh tham chiếu của người đó ở cường
    // độ cao) — cải thiện độ giống khuôn mặt/thân hình khi cảnh có từ 2
    // người trở lên (nhiều người cùng lúc trong 1 lượt IP-Adapter mask có
    // xu hướng hoà lẫn danh tính/tỷ lệ, đã ghi nhận từ mục 52b/123/124).
    //
    // mục 126 TECHNICAL_STATUS.md — user chỉ ra ĐÚNG: mặc định TẮT (yêu
    // cầu user tự đi soát từng ảnh cảnh đông người rồi mới bật switch toàn
    // cục) là thiết kế TỆ cho 1 vấn đề ĐÚNG-SAI (không phải sở thích nội
    // dung như autoTearClothingAtContactPoints ở trên). Đã đổi mặc định
    // thành BẬT — đúng khuôn mẫu đã dùng cho fix chất lượng chung khác
    // (hand_over_body/hip_overlap luôn bật, không hỏi ý kiến). Điều kiện
    // kích hoạt THẬT SỰ nằm ở nơi gọi (sceneChars.size >= 2, xem
    // MangaPipeline.runGeneration()) — field này giờ chỉ còn ý nghĩa "cho
    // phép TẮT thủ công" (opt-out cho máy yếu ưu tiên tốc độ hơn độ chính
    // xác từng người), KHÔNG còn là "cho phép BẬT thủ công" (opt-in) nữa.
    val enableMultiPassCascade: Boolean = true,
    // Denoise cho từng lượt cascade — thấp = giữ sát bố cục lượt 1 (an
    // toàn, ít đổi), cao = tự do sửa nhiều hơn nhưng rủi ro lệch khỏi bố
    // cục chung. 0.4-0.5 là vùng khuyến nghị (đủ để "khoá" identity mà
    // không vẽ lại toàn bộ vùng cơ thể).
    val cascadeDenoiseStrength: Float = 0.45f,
    val cancelTimeoutMs: Long = 30_000L
)

enum class UpscaleOption(val label: String, val factor: Int, val sharpen: Boolean) {
    NONE("Không upscale", 1, false),
    X2("2× · 1024px", 2, false),
    X4("4× · 2048px", 4, false),
    X4_SHARP("4× · 2048px · Nét hơn", 4, true)
}

enum class ImageStyle(val label: String, val emoji: String, val stylePrompt: String, val negPrompt: String) {
    REALISTIC("Siêu thực", "📷",
        "RAW photo, 8k uhd, dslr, soft lighting, high quality, film grain, photorealistic, sharp focus",
        "cartoon, anime, illustration, 3d render, cgi, lowres, bad quality, watermark, blurry, deformed"),
    ANIME("Anime / Moe", "✨",
        "masterpiece, best quality, ultra-detailed, illustration, vibrant colors, sharp lines, anime style",
        "lowres, bad anatomy, bad hands, text, error, worst quality, jpeg artifacts, watermark, blurry, 3d"),
    MANHWA("Manhwa / Webtoon", "📱",
        "manhwa style, webtoon, clean lineart, flat colors, high contrast, korean comic, professional",
        "blurry, lowres, bad anatomy, photorealistic, 3d render, rough sketch"),
    MANGA("Manga", "📖",
        "manga style, black and white, high contrast, detailed lineart, japanese comic, professional manga",
        "colored, blurry, lowres, bad anatomy, photorealistic"),
    COMIC("Comic / Western", "💥",
        "comic book style, bold lines, vibrant colors, american comic, professional illustration, dynamic",
        "blurry, lowres, bad anatomy, photorealistic, 3d render"),
    CINEMATIC("Điện ảnh", "🎬",
        "cinematic lighting, epic composition, dramatic shadows, movie still, 35mm film, anamorphic lens",
        "cartoon, anime, illustration, amateur, blurry, lowres")
}

// ── Scene & Panel ─────────────────────────────────────────────────────────
data class Scene(
    val index: Int,
    val description: String,
    val characters: List<String>,
    val mood: String,
    val cameraAngle: String,
    val action: String = "",
    val setting: String = "",
    val dialogue: List<DialogueLine> = emptyList(),
    // mục 85 TECHNICAL_STATUS.md — đóng gap "classifyAction() có thể miss
    // mô tả hoa mỹ của LLM" (bảng "đã code nhưng thiếu mảnh"). Trước đây
    // SeedRegistry.classifyAction() CHỈ đoán qua regex trên chuỗi `action`
    // tiếng Anh/Việt cứng — LLM viết hoa mỹ ("hai người siết chặt lấy
    // nhau trong nước mắt" thay vì có chữ "ôm") sẽ rơi tọt về "neutral"
    // dù đúng ra là "embrace", khiến Seed Registry (mục 75) gộp nhầm
    // key, gợi ý seed sai bản chất hành động. Field này để LLM (vốn hiểu
    // ngữ nghĩa tốt hơn regex rất nhiều) TỰ phân loại ngay lúc viết scene,
    // cùng lúc với action/mood/cameraAngle — null = LLM không trả (model
    // cũ/lỗi parse) hoặc parse ra giá trị lạ không khớp enum đã định
    // nghĩa, cả 2 trường hợp đều rơi về heuristic regex cũ làm fallback
    // (xem SeedRegistry.resolveActionCategory()) — KHÔNG có gì hỏng thêm
    // so với hành vi trước đây, chỉ cải thiện độ chính xác khi LLM trả
    // đúng field.
    val actionCategory: String? = null,

    // Kiến trúc phân loại BIỂU CẢM NHÂN VẬT — CÙNG khuôn mẫu actionCategory
    // ở trên (LLM tự phân loại vào 1 tập đóng lúc viết scene, KHÔNG bịa tự
    // do, LLMParser.extractPrompts()/promptTemplate() sau đó dịch category
    // này thành tag/cụm mô tả CỤ THỂ theo đúng PromptStyle checkpoint đang
    // active — xem LLMParser.EXPRESSION_TAGS). Trước đây "biểu cảm" chỉ là
    // 1 CÂU DẶN CHUNG CHUNG trong promptTemplate() ("must include a concrete
    // facial-expression detail matching the mood") — LLM có thể quên hoặc
    // viết mơ hồ ("sad expression" thay vì tag cụ thể). Field này tách biểu
    // cảm thành 1 QUYẾT ĐỊNH RIÊNG của LLM, tương tự action_category, để:
    //   1) LLMParser tự nối tag biểu cảm CỤ THỂ (không phụ thuộc LLM nhớ dặn)
    //   2) Nối được với Smooth Timestep Decay IP-Adapter (ipDecayFloor ở
    //      trên) — khi IP-Adapter yếu dần cuối step, tag biểu cảm CẦN được
    //      nhấn mạnh hơn (đặt gần đầu câu + có thể tăng trọng số) để THẬT
    //      SỰ tận dụng được khoảng trống mà decay tạo ra, thay vì decay chạy
    //      nhưng vẫn không có tag biểu cảm nào đủ mạnh để "thắng" identity.
    // null = LLM không trả (model cũ/lỗi parse) hoặc giá trị lạ không khớp
    // EXPRESSION_TAGS — rơi về hành vi CŨ (câu dặn chung chung trong prompt,
    // không có gì hỏng thêm).
    val expression: String? = null,

    // mục 121 TECHNICAL_STATUS.md — "Depth Scale", vá đúng phần "phối cảnh
    // gần-xa" mà mục 118 ghi nhận chưa giải quyết. ĐÃ TRA CỨU cách cộng
    // đồng thật sự làm việc này (cả ComfyUI OpenPose-editor workflow lẫn
    // sách dạy vẽ manga chuyên nghiệp — "Sketching Manga Style Vol 4: All
    // About Perspective"): KHÔNG PHẢI suy luận 3D tự động từ 1 giá trị z
    // mơ hồ (bài toán thiếu thông tin — không có hiệu chuẩn camera thật,
    // không giải được đáng tin cậy), mà là NGƯỜI VẼ/LLM TỰ CHỈ ĐỊNH tỷ lệ
    // tương đối tường minh ("vẽ nhân vật thứ 2 bằng NỬA kích thước nhân
    // vật thứ nhất để tạo ảo giác khoảng cách" — nguyên văn kỹ thuật trong
    // sách). Field này CHÍNH LÀ phiên bản số hoá của kỹ thuật đó.
    //
    // Map tên nhân vật -> hệ số scale tương đối (1.0 = mặc định, không
    // ghi đè gì — giữ nguyên tỷ lệ THẬT của template gốc; >1.0 = gần máy
    // quay hơn/to hơn; <1.0 = xa hơn/nhỏ hơn). LLM CHỈ điền khi văn bản
    // scene có ý gần-xa RÕ RÀNG (vd "A đứng sát máy quay, B đứng xa phía
    // sau mờ nhạt") — phần LỚN panel để rỗng (map rỗng = hành vi CŨ, không
    // đổi gì). Áp dụng SAU bước retarget tỷ lệ xương (PoseRetargeter, vốn
    // chỉ chỉnh hình dạng RIÊNG từng người) — đây là quyết định ĐẠO DIỄN/
    // BỐ CỤC KHUNG HÌNH, tách biệt hoàn toàn khỏi tỷ lệ xương CỦA nhân vật
    // (2 khái niệm khác nhau: "người này cao/thấp" vs "người này đứng gần/
    // xa máy quay trong CẢNH NÀY").
    val depthScale: Map<String, Float> = emptyMap()
)

data class DialogueLine(
    val characterName: String,
    val text: String,
    val type: BubbleType = BubbleType.SPEECH
)

// Kết quả LLMParser.buildPrompt() cho 1 panel — mở rộng từ Pair<String,String>
// cũ (positive, negative) để LLM tự chọn thêm pose template THẬT trong
// pose_library.json của user (mục 6 TECHNICAL_STATUS.md — "LLM orchestration").
// poseTemplate = null nghĩa là LLM không thấy template nào hợp, hoặc thư viện
// đang rỗng — MangaPipeline sẽ tự rơi về fallback theo heuristic đơn giản.
data class PromptResult(
    val positive: String,
    val negative: String,
    val poseTemplate: String?,
    val poseAngle: String = "any",
    // mục 101 TECHNICAL_STATUS.md — đóng gap "recordFromLlmOutput() không
    // ai gọi" (ConceptDictionary.kt, mục 78): thay vì viết heuristic dò
    // chữ hoa/trích xuất riêng (dễ vỡ, không đáng tin), dùng ĐÚNG khuôn mẫu
    // đã có ở action_category/expression (mục 86/98) — LLM TỰ trả về cặp
    // [khái niệm gốc → SD tag đã dùng] ngay trong JSON response của chính
    // buildPrompt(), không cần lần gọi LLM riêng hay heuristic đoán mò.
    // Rỗng nếu LLM không thấy khái niệm mới nào (đa số trường hợp) hoặc
    // model cũ/parse lỗi — không có gì hỏng thêm.
    val newConcepts: List<Pair<String, String>> = emptyList()
)

// ── Bubble hội thoại ──────────────────────────────────────────────────────
enum class BubbleType { SPEECH, THOUGHT, NARRATION, SHOUT }

data class Bubble(
    val id: String,
    val characterName: String,
    val text: String,
    val type: BubbleType = BubbleType.SPEECH,
    // Vị trí trên ảnh (normalized 0.0-1.0)
    val xNorm: Float = 0.1f,
    val yNorm: Float = 0.05f,
    val widthNorm: Float = 0.4f,
    val isAutoPlaced: Boolean = false  // true = YOLOv8 đặt, false = người dùng đặt
)

// ── Panel ─────────────────────────────────────────────────────────────────
enum class PanelStatus { PENDING, GENERATING, DONE, FAILED, APPROVED, REJECTED }
enum class PanelReviewAction { APPROVE, REJECT, REGENERATE, EDIT_PROMPT }

// ── Setting riêng cho 1 ảnh (tầng "riêng", ưu tiên hơn GenerationSettings
// tầng "chung" khi field khác null). KHÔNG có field LoRA/model — theo
// quyết định đã chốt: LoRA merge chết vào .mnn, không bật/tắt per-ảnh
// được, chỉ chọn được NHÂN VẬT (qua đó gián tiếp chọn model đã convert
// sẵn cho nhân vật đó, xem MangaPipeline.resolveModelIdForCharacter()).
// mục 107 TECHNICAL_STATUS.md — bộ 6 tham số điều khiển Pose/Depth/Decay
// CHO 1 LƯỢT SINH ẢNH, gộp chung để tra bảng/truyền tay dễ hơn thay vì 6
// tham số rời rạc. Dùng cho CẢ auto-preset (ACTION_CONDITIONING_PRESETS
// trong MangaPipeline.kt) LẪN override tay từng panel
// (PanelOverrideSettings.conditioningOverride bên dưới) — 1 kiểu dữ liệu
// duy nhất cho cả 2 nguồn, để resolveConditioning() không phải xử lý 2
// dạng khác nhau.
data class ConditioningPreset(
    val poseConditioningScale: Float,
    val depthConditioningScale: Float,
    val depthActiveMinTimestep: Float,
    val ipDecayFloor: Float,
    val ipDecayStartTimestep: Float,
    val ipStaticScale: Float
)

data class PanelOverrideSettings(
    val promptOverride: String? = null,      // sửa tay prompt SD nếu không ưng ý bản LLM tạo
    // Mô tả tự nhiên tiếng Việt cho RIÊNG panel này (mục 24
    // TECHNICAL_STATUS.md) — nếu set, LLM dịch câu này sang tag SD1.5 thay
    // vì dùng mô tả tự động từ parseStory(). Khác promptOverride: đây là
    // NGÔN NGỮ TỰ NHIÊN cần LLM dịch, không phải tag SD1.5 gõ tay trực
    // tiếp. Nếu CẢ HAI đều set, promptOverride (tag SD1.5 tay) ưu tiên hơn
    // — dịch tự nhiên chỉ có tác dụng khi promptOverride để trống.
    val naturalDescriptionOverride: String? = null,
    val negativePrompt: String? = null,
    val characterOverride: String? = null,   // tên nhân vật, override tự-nhận-diện từ LLMParser
    val poseTemplate: String? = null,        // tên template trong pose_library.json
    val poseAngle: String? = null,           // "front"/"side_left"/"side_right"/"any"
    val width: Int? = null,
    val height: Int? = null,
    val steps: Int? = null,
    val cfgScale: Float? = null,
    val seed: Long? = null,
    // null = dùng quyết định của routingMode (MANUAL: defaultBackend; AUTO:
    // LLM tự quyết). Set giá trị cụ thể = ép cứng panel này, LUÔN ưu tiên
    // tuyệt đối hơn AUTO — kể cả AUTO đã quyết định khác, override tay này
    // vẫn thắng (xem BackendRouter.resolve()).
    val backendOverride: GenerationBackend? = null,

    // ── Regional Prompting — canvas kéo-thả (mục 88 TECHNICAL_STATUS.md,
    // đóng gap ghi ở mục 69). CHỈ áp dụng khi panel thật sự đi nhánh
    // Regional Prompting (MangaPipeline.useRegional == true — 2-4 nhân
    // vật, không có model ghép LoRA/mask sẵn cho scene này); vô tác dụng
    // ở mọi nhánh khác, không cần kiểm tra gì thêm ở nơi gọi ngoài nhánh
    // đó vì MangaPipeline chỉ đọc 2 field này bên trong nhánh `useRegional`.
    //
    // Thứ tự CỘT trái->phải cho Regional Prompting, ĐÃ đổi qua canvas kéo-
    // thả (RegionalColumnEditor.kt) — null = giữ nguyên thứ tự mặc định
    // (đúng thứ tự panel.scene.characters, hành vi gốc trước mục 88).
    // PHẢI là hoán vị (permutation) ĐÚNG BỘ panel.scene.characters — nếu
    // không khớp (thiếu người/thừa người/tên lạ do sửa kịch bản sau khi đã
    // set override này), MangaPipeline bỏ qua field này và LOG CẢNH BÁO,
    // rơi về thứ tự mặc định — KHÔNG throw, không chặn sinh ảnh vì 1 field
    // UI lệch, xem MangaPipeline.resolveRegionalColumnOrder().
    val regionalColumnOrder: List<String>? = null,
    // Prompt riêng cho từng CỘT (key = tên nhân vật), ĐÃ sửa tay qua canvas
    // kéo-thả — rỗng hoặc thiếu key = dùng tự động (anchorPrompt nhân vật
    // + prompt cảnh chung, hành vi gốc trước mục 88). Map rỗng (mặc định)
    // = không override gì, giữ nguyên hành vi cũ 100%.
    val regionalPromptOverrides: Map<String, String> = emptyMap(),

    // mục 107 TECHNICAL_STATUS.md — kết quả người dùng CHỌN qua "So sánh
    // thử" (GalleryReviewScreen) giữa preset tự động vs cài đặt chung, HOẶC
    // override tay tuỳ ý sau này. null = KHÔNG override — dùng
    // resolveConditioning() (auto-preset nếu bật cờ, hoặc cài đặt chung
    // toàn cục nếu tắt/không nhận diện được actionCategory). Ưu tiên CAO
    // NHẤT trong resolveConditioning() — kể cả actionCategory có preset
    // tự động, field này (nếu set) vẫn thắng.
    val conditioningOverride: ConditioningPreset? = null
)

data class Panel(
    val index: Int,
    val scene: Scene,
    val prompt: String,
    val negativePrompt: String,
    // Gợi ý của LLM (mục 6 TECHNICAL_STATUS.md: "LLM orchestration") — LLM tự
    // chọn tên template khớp nhất trong pose_library.json THẬT của user (không
    // đoán mù tên cố định như trước), null = không tìm thấy template nào hợp/
    // thư viện rỗng. Đây là gợi ý, override tầng riêng vẫn ưu tiên hơn.
    val suggestedPoseTemplate: String? = null,
    val suggestedPoseAngle: String = "any",
    // Xung đột IP-Adapter THẬT của panel này (đếm bằng Kotlin, xem
    // StoryManager.detectIpAdapterConflicts) — khác cảnh báo cũ "≥2 nhân
    // vật" chung chung: chỉ true khi ≥2 người trong panel THỰC SỰ dùng
    // IP-Adapter (anchorImagePath) và chưa có model ghép cặp che được.
    val ipAdapterConflictNames: List<String> = emptyList(),
    // Đánh dấu panel này ĐÃ qua auto-fix (Ultrafix và/hoặc auto-fix mặt/tay)
    // ở bước upscale — để Gallery cuối (PostProcessingScreen, mục 22
    // TECHNICAL_STATUS.md) biết panel nào cần user kiểm tra kỹ hơn, thay vì
    // im lặng không báo gì (theo đúng yêu cầu "trong tự động nếu có lỗi thì
    // báo cho người dùng").
    val autoFixApplied: Boolean = false,
    // mục 74 TECHNICAL_STATUS.md — Quality Gate: kết quả tự động kiểm tra
    // giải phẫu (đếm chi + tỷ lệ xương qua QualityGateChecker). passed=true
    // mặc định (không phạt panel cũ sinh trước khi có tính năng này / panel
    // sinh khi settings.enableQualityGate=false).
    val qualityGatePassed: Boolean = true,
    val qualityGateReasons: List<String> = emptyList(),
    val qualityGateRetryCount: Int = 0,
    val imagePath: String? = null,           // 512px raw
    val upscaledPath: String? = null,        // sau upscale
    val bubbles: List<Bubble> = emptyList(), // hội thoại
    val status: PanelStatus = PanelStatus.PENDING,
    val generationTimeMs: Long = 0,
    val userNote: String = "",               // ghi chú của người dùng khi edit
    val overrideSettings: PanelOverrideSettings? = null,  // setting riêng ảnh này, null = dùng hết tầng chung
    // Backend THẬT ĐÃ DÙNG để sinh panel này (null = chưa sinh lần nào).
    // Lưu lại kể cả khi routingMode=AUTO đổi policy sau đó — Gallery cần biết
    // ảnh NÀY đã sinh ở đâu (local hay remote) để user quyết định có tin
    // tưởng/regenerate hay không, không suy ngược từ setting hiện tại (có
    // thể đã đổi từ lúc sinh ảnh này).
    val resolvedBackend: GenerationBackend? = null,
    val routingReason: String = ""           // lý do BackendRouter chọn (hiện cho user thấy, đặc biệt quan trọng ở AUTO)
)

// ── Chapter ───────────────────────────────────────────────────────────────
data class Chapter(
    val id: String,
    val storyId: String,
    val title: String,
    val chapterNumber: Int,
    val storyText: String,
    val style: ImageStyle,
    val panels: List<Panel>,
    val pdfPath: String? = null,
    val cbzPath: String? = null,
    val status: ChapterStatus = ChapterStatus.DRAFT,
    val createdAt: Long = System.currentTimeMillis()
) {
    val doneCount get() = panels.count { it.status == PanelStatus.DONE || it.status == PanelStatus.APPROVED }
    val approvedCount get() = panels.count { it.status == PanelStatus.APPROVED }
    val allApproved get() = panels.isNotEmpty() && panels.all { it.status == PanelStatus.APPROVED }
}

enum class ChapterStatus { DRAFT, GENERATING, REVIEW, UPSCALING, DONE }

// ── Pipeline state ────────────────────────────────────────────────────────
data class PipelineState(
    val stage: PipelineStage = PipelineStage.IDLE,
    val currentPanel: Int = 0,
    val totalPanels: Int = 0,
    val currentStep: Int = 0,
    val totalSteps: Int = 20,
    val log: List<LogEntry> = emptyList(),
    val error: String? = null,
    val startTimeMs: Long = 0L,
    val isPaused: Boolean = false,
    val pauseReason: PauseReason? = null,
    val currentTempC: Int = 0,
    // mục 133 TECHNICAL_STATUS.md — Industrial Batch Upscale Mode. Khi
    // `GenerationSettings.industrialBatchUpscaleMode=true`,
    // `upscaleApprovedPanels()` chạy 2 GIAI ĐOẠN tách biệt (ESRGAN cho TẤT
    // CẢ panel trước, giải phóng ESRGAN, rồi Ultrafix+auto-fix mặt/tay cho
    // TẤT CẢ panel sau) thay vì xen kẽ từng panel một như trước — nhãn này
    // cho UI biết đang ở giai đoạn nào. null = không ở chế độ 2 giai đoạn
    // (hành vi cũ, hoặc đang ở bước khác ngoài upscale).
    val phaseLabel: String? = null
) {
    val elapsedMs get() = if (startTimeMs == 0L) 0L else System.currentTimeMillis() - startTimeMs
    val progressFraction get() = if (totalPanels == 0) 0f else currentPanel.toFloat() / totalPanels
}

enum class PipelineStage {
    IDLE, LLM_PARSING, PROMPT_BUILDING,
    SD_GENERATING, REVIEW,
    UPSCALING, BUBBLE_AUTO,
    LAYOUT_EXPORT, DONE, ERROR
}

enum class PauseReason { THERMAL, USER }

data class LogEntry(val time: String, val message: String, val level: LogLevel = LogLevel.INFO)
enum class LogLevel { INFO, OK, WARN, ERROR }

// ── Thermal state ─────────────────────────────────────────────────────────
data class ThermalState(
    val currentTempC: Int = 0,
    val thresholdC: Int = 42,
    val isOverheating: Boolean = false,
    val history: List<Int> = emptyList() // lịch sử nhiệt độ để vẽ chart
)
