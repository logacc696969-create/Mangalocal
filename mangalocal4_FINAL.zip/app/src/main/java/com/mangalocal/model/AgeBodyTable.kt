package com.mangalocal.model

/**
 * mục 278 TECHNICAL_STATUS.md — BẢNG TỶ LỆ TỪNG ĐOẠN CHI THEO TUỔI: MỘT nguồn dữ liệu duy nhất cho (a) preset tỷ lệ xương của NHÂN VẬT (`BoneProportions.forAge`) và
 * (b) nút đổi tuổi ở màn Tư thế (`AgeBodyScaler`). Trước đây hai nơi này mỗi nơi một bộ số tự đặt, và hai preset nhân vật dùng CHUNG một hệ số cho cánh tay trên+cẳng tay
 * (0,8) và đùi+cẳng chân (0,75) — không có đoạn nào riêng.
 *
 * NGUỒN (số đo thật, tuổi 6–18, từng năm, nam và nữ): Schmid S., Burkhart K.A., Allaire B.T., Grindle D., Anderson D.E. (2019), J Biomech, DOI 10.1016/j.jbiomech.2019.07.049,
 * Bảng A1 — tổng hợp từ các bảng tham chiếu nhi khoa (Fryar 2012, Zhang & Li 2015, Zhu 2015, Gleiss 2013...). Bản chép nguyên văn: tools/data/schmid2019_tableA1.txt
 * (test_age_body_table.py kiểm bảng dưới đây khớp từng số với file đó). Ở đây lấy TRUNG BÌNH nam-nữ; bài gốc có tách giới nếu sau này cần.
 *
 * NGUỒN BỀ NGANG (mục 284; số đo thật, từng tuổi, nam và nữ, đơn vị cm): (A) CDC/NCHS NHANES III 1988–1994, bảng 53 (biacromial = bề ngang vai, 3–19 tuổi) và bảng 56 (biiliac = bề ngang hông,
 * 2–19 tuổi), ~200–560 người mỗi ô — bản chép: tools/data/nhanes3_breadth_t53_t56.txt; (B) Zivicnjak M. và cs. (2008), Coll. Antropol. 32(2):419–431, 5.260 trẻ Zagreb 2–18 tuổi, bảng 1 (biacromial)
 * và 4 (biiliocristal) — bản chép: tools/data/zivicnjak2008_tables1_4.txt. Bảng BREADTH dưới đây SINH TỰ ĐỘNG từ hai tệp đó (tools/gen_age_breadth_table.py --check kiểm khớp).
 *
 * KHÔNG CÓ SỐ ĐO THẬT (ước lượng, ghi rõ để không ai tưởng là số y văn):
 *  - ĐẦU: bảng không có chiều cao đầu. Ước lượng theo KÍCH THƯỚC TUYỆT ĐỐI của đầu so với người lớn: 0,87 lúc 6 tuổi (khớp quy ước ~6 số đầu ở 6 tuổi của mục 277) tăng tuyến tính tới 1,0 lúc
 *    13 tuổi rồi giữ 1,0; người lớn = 7,5 số đầu. Mốc 13 tuổi và "từ ~5 tuổi đầu đã sát trưởng thành" lấy từ Cleft Palate-Craniofac J 1992;29(4):303-8 (PMID 1643057); đường nội suy giữa hai mốc
 *    là giả định đơn giản. (Bản đầu của mục 278 dùng "6,5 số đầu lúc 12 tuổi" của mục 277: nhân với chiều cao thật cho đầu thiếu niên LỚN HƠN đầu người lớn 5% — vô lý, đã bỏ.)
 *  - (mục 284) VAI/HÔNG (bề ngang) KHÔNG còn là ước lượng về XU HƯỚNG theo tuổi: lấy từ SỐ ĐO THẬT của HAI quần thể độc lập (xem BREADTH bên dưới). Bản cũ (0,215 → 0,245 chiều cao,
 *    nội suy tuyến tính) thấp hơn số đo 11% lúc 6 tuổi, 8% lúc 8, 6% lúc 10 (giảm dần về 0 lúc 18). Còn lại là ƯỚC LƯỢNG: MỐC NGƯỜI LỚN 0,245 chiều cao vẫn là giá trị cũ chưa hiệu chỉnh
 *    (số đo biacromial/chiều cao người lớn tính từ chính các bảng này chỉ ~0,22–0,23; điểm vai của khung xương không trùng mỏm cùng vai nên KHÔNG tự ý đổi mốc khi chưa hiệu chỉnh trên khung xương thật).
 *  - THÂN (cổ → hông) = (thân+đầu+cổ) − đầu: thừa hưởng sai số của số đầu. Thân gần như không đổi theo tuổi (±5% so với chiều cao).
 * Ngoài khoảng 6–18 tuổi: kẹp về 6 hoặc 18 (KHÔNG ngoại suy xuống trẻ nhỏ — bài không có số liệu).
 *
 * GIỚI (mục 285): cả bảng Schmid lẫn hai bảng bề ngang ĐÃ tách nam/nữ từ đầu; trước mục 285 chỉ lấy trung bình. Mọi hàm nay nhận `sex` (mặc định UNSPECIFIED = trung bình, y hệt cũ).
 * Với MALE/FEMALE: (a) độ dài các đoạn thân/đùi/cẳng chân/cánh tay/cẳng tay lấy CỘT RIÊNG của giới đó (Schmid); (b) bề ngang vai/hông lấy cột nam hoặc nữ của cả HAI quần thể;
 * (c) ĐẦU — quy ước "N đầu" phụ thuộc TUỔI chứ không phụ thuộc giới (người lớn 7,5 đầu cả nam lẫn nữ) nên phần đầu theo chiều cao là MỘT chuỗi theo tuổi dùng chung; nhờ đó nhóm tag prompt
 * (child / youthful / không tag) KHÔNG đổi theo giới ở bất kỳ tuổi nào. (Thử cách khác — đầu theo kích thước tuyệt đối — làm bé gái 12 tuổi mất tag "youthful" vì cao hơn nên "nhiều đầu hơn": bị loại.)
 * MỐC THAM CHIẾU của mọi tỷ lệ tuyệt đối vẫn là NGƯỜI LỚN TRUNG BÌNH nam–nữ (= 1,0), nên nữ trưởng thành thấp hơn 1,0 khoảng 4–5% và nam cao hơn ~4–5%: đúng chiều cao thật (163,4 / 175,5 cm).
 */
/**
 * mục 285 TECHNICAL_STATUS.md — giới dùng để chọn cột NAM / NỮ của bảng số đo. UNSPECIFIED = TRUNG BÌNH nam–nữ = hành vi từ trước mục 285 (mặc định, giữ đúng từng bit; xem
 * tools/data/age_body_unisex_golden.txt). Lưu theo tên (chuỗi) ở thư viện nhân vật nên đổi tên hằng số = mất dữ liệu cũ: KHÔNG đổi tên.
 */
enum class BodySex(val label: String) {
    UNSPECIFIED("Không rõ (trung bình)"), MALE("Nam"), FEMALE("Nữ");

    companion object {
        /** Giá trị an toàn: Gson có thể để null (JSON ghi null) dù kiểu khai báo không null. */
        fun safe(s: BodySex?): BodySex = s ?: UNSPECIFIED
        /** Từ chuỗi đã lưu (thiếu, null hoặc tên lạ → UNSPECIFIED). */
        fun parse(raw: String?): BodySex = runCatching { valueOf(raw ?: "") }.getOrDefault(UNSPECIFIED)
    }
}

object AgeBodyTable {
    const val MIN_AGE = 6
    const val MAX_AGE = 18
    /** Neo tuổi cho 3 nhóm của app: Trẻ em ≈ 8, Thiếu niên ≈ 14, Người lớn = 18 trở lên. */
    const val CHILD_AGE = 8
    const val TEEN_AGE = 14
    const val ADULT_AGE = MAX_AGE

    /** Độ dài từng đoạn. Cùng kiểu dùng cho: phần trăm chiều cao đứng, hệ số đổi tuổi, hoặc tỷ lệ so với người lớn. */
    data class Segments(
        val head: Float, val trunk: Float, val shoulder: Float,
        val thigh: Float, val shank: Float, val upperArm: Float, val forearm: Float,
        /** mục 285 — bề ngang HÔNG tách riêng khỏi vai (dị biệt giới ngược chiều nhau). Mặc định = [shoulder] (hành vi cũ: một hệ số chung). */
        val hip: Float = shoulder
    )

    // [chiều cao cm, thân+đầu+cổ, đùi, cẳng chân, cánh tay trên, cẳng tay] — hàng i ứng với tuổi MIN_AGE + i. Sinh tự động từ tools/data/schmid2019_tableA1.txt.
    private val MALE = arrayOf(
        floatArrayOf(118.2f, 0.484f, 0.234f, 0.233f, 0.183f, 0.141f),  // 6
        floatArrayOf(123.8f, 0.478f, 0.235f, 0.238f, 0.183f, 0.141f),  // 7
        floatArrayOf(129.2f, 0.472f, 0.233f, 0.243f, 0.183f, 0.143f),  // 8
        floatArrayOf(134.5f, 0.469f, 0.233f, 0.247f, 0.186f, 0.144f),  // 9
        floatArrayOf(140.1f, 0.464f, 0.235f, 0.250f, 0.187f, 0.144f),  // 10
        floatArrayOf(145.4f, 0.457f, 0.236f, 0.255f, 0.188f, 0.144f),  // 11
        floatArrayOf(150.9f, 0.453f, 0.242f, 0.255f, 0.191f, 0.146f),  // 12
        floatArrayOf(158.7f, 0.450f, 0.240f, 0.257f, 0.194f, 0.149f),  // 13
        floatArrayOf(165.2f, 0.451f, 0.240f, 0.258f, 0.194f, 0.146f),  // 14
        floatArrayOf(170.2f, 0.453f, 0.241f, 0.256f, 0.196f, 0.146f),  // 15
        floatArrayOf(172.6f, 0.455f, 0.240f, 0.256f, 0.199f, 0.147f),  // 16
        floatArrayOf(174.6f, 0.457f, 0.238f, 0.257f, 0.197f, 0.148f),  // 17
        floatArrayOf(175.5f, 0.458f, 0.239f, 0.256f, 0.200f, 0.149f),  // 18
    )
    private val FEMALE = arrayOf(
        floatArrayOf(117.4f, 0.480f, 0.220f, 0.248f, 0.182f, 0.139f),  // 6
        floatArrayOf(123.0f, 0.472f, 0.223f, 0.254f, 0.182f, 0.140f),  // 7
        floatArrayOf(128.3f, 0.467f, 0.227f, 0.254f, 0.183f, 0.140f),  // 8
        floatArrayOf(134.0f, 0.462f, 0.230f, 0.256f, 0.186f, 0.144f),  // 9
        floatArrayOf(140.3f, 0.458f, 0.233f, 0.257f, 0.187f, 0.142f),  // 10
        floatArrayOf(146.6f, 0.455f, 0.238f, 0.257f, 0.188f, 0.141f),  // 11
        floatArrayOf(152.6f, 0.454f, 0.235f, 0.261f, 0.192f, 0.144f),  // 12
        floatArrayOf(157.0f, 0.454f, 0.238f, 0.260f, 0.195f, 0.144f),  // 13
        floatArrayOf(160.3f, 0.455f, 0.238f, 0.257f, 0.193f, 0.145f),  // 14
        floatArrayOf(161.9f, 0.457f, 0.237f, 0.257f, 0.193f, 0.144f),  // 15
        floatArrayOf(162.7f, 0.459f, 0.239f, 0.254f, 0.195f, 0.145f),  // 16
        floatArrayOf(163.6f, 0.460f, 0.236f, 0.255f, 0.194f, 0.143f),  // 17
        floatArrayOf(163.4f, 0.462f, 0.234f, 0.256f, 0.196f, 0.144f),  // 18
    )

    /**
     * [vai nam, vai nữ, hông nam, hông nữ] của NHANES III rồi của Zivicnjak 2008 (8 cột, cm) — hàng i ứng với tuổi MIN_AGE + i. SINH TỰ ĐỘNG từ hai tệp chép nguyên văn trong tools/data (tools/gen_age_breadth_table.py).
     * Hai quần thể (Mỹ 1988–94, Croatia 1997–2001) và hai kỹ thuật đo khác nhau nên GIÁ TRỊ TUYỆT ĐỐI lệch nhau 3–5%; chỉ dùng TỶ LỆ so với chính quần thể đó lúc 18 tuổi.
     */
    private val BREADTH = arrayOf(
        floatArrayOf(26.3f, 26.1f, 18.4f, 18.4f, 26.46f, 26.33f, 19.07f, 18.97f),   // 6
        floatArrayOf(27.6f, 27.2f, 19.6f, 19.4f, 27.87f, 27.76f, 20.16f, 19.88f),   // 7
        floatArrayOf(29.0f, 28.8f, 20.0f, 20.4f, 28.62f, 28.31f, 20.5f, 20.17f),   // 8
        floatArrayOf(30.5f, 30.2f, 21.3f, 21.4f, 29.94f, 29.34f, 21.32f, 21.04f),   // 9
        floatArrayOf(31.2f, 31.1f, 21.7f, 22.4f, 30.55f, 30.64f, 21.77f, 22.19f),   // 10
        floatArrayOf(32.6f, 33.0f, 22.8f, 23.5f, 31.74f, 31.94f, 22.55f, 23.36f),   // 11
        floatArrayOf(34.4f, 34.1f, 24.3f, 24.4f, 33.14f, 33.04f, 23.54f, 24.21f),   // 12
        floatArrayOf(35.9f, 35.5f, 25.3f, 26.1f, 34.48f, 33.72f, 24.47f, 25.23f),   // 13
        floatArrayOf(37.7f, 36.0f, 26.6f, 26.5f, 36.4f, 34.54f, 25.57f, 26.4f),   // 14
        floatArrayOf(38.8f, 36.3f, 27.0f, 26.8f, 37.67f, 34.9f, 27.62f, 27.22f),   // 15
        floatArrayOf(39.9f, 36.7f, 27.4f, 27.1f, 39.02f, 34.8f, 28.26f, 27.3f),   // 16
        floatArrayOf(40.8f, 36.7f, 27.7f, 27.2f, 39.3f, 34.98f, 28.28f, 27.46f),   // 17
        floatArrayOf(41.0f, 36.6f, 27.6f, 26.8f, 39.37f, 34.95f, 28.38f, 27.64f),   // 18
    )

    private fun idx(age: Int) = age.coerceIn(MIN_AGE, MAX_AGE) - MIN_AGE
    private fun avg(i: Int, col: Int): Float = (MALE[i][col] + FEMALE[i][col]) / 2f
    /** Cột [col] của hàng [i] theo giới: UNSPECIFIED = trung bình nam–nữ (như cũ), MALE/FEMALE = cột riêng. */
    private fun v(i: Int, col: Int, sex: BodySex): Float = when (sex) {
        BodySex.MALE -> MALE[i][col]
        BodySex.FEMALE -> FEMALE[i][col]
        BodySex.UNSPECIFIED -> avg(i, col)
    }

    /** Chiều cao (cm) ở tuổi [age]: trung bình nam-nữ (mặc định) hoặc riêng từng giới. */
    fun heightCm(age: Int, sex: BodySex = BodySex.UNSPECIFIED): Float = v(idx(age), 0, sex)

    /** Tuổi đầu đạt kích thước người lớn (mốc thật, xem ghi chú) và kích thước đầu lúc 6 tuổi (ước lượng) — đều so với người lớn = 1,0. */
    const val HEAD_MATURE_AGE = 13
    private const val HEAD_SIZE_AT_MIN_AGE = 0.87f

    /** Kích thước TUYỆT ĐỐI của đầu so với người lớn (1,0) — ƯỚC LƯỢNG: 0,87 lúc 6 tuổi tăng tuyến tính tới 1,0 lúc 13 tuổi. */
    fun headSizeVsAdult(age: Int): Float {
        val a = age.coerceIn(MIN_AGE, MAX_AGE)
        if (a >= HEAD_MATURE_AGE) return 1f
        return HEAD_SIZE_AT_MIN_AGE + (a - MIN_AGE).toFloat() / (HEAD_MATURE_AGE - MIN_AGE) * (1f - HEAD_SIZE_AT_MIN_AGE)
    }

    /** Số đầu/chiều cao (người lớn = 7,5) — suy ra từ kích thước đầu ở trên, chỉ để hiển thị. */
    fun headsTall(age: Int): Float = heightCm(age) / (headSizeVsAdult(age) * heightCm(ADULT_AGE) / 7.5f)

    /** Mốc NGƯỜI LỚN của bề ngang vai/hông theo chiều cao đứng — giá trị CŨ chưa hiệu chỉnh (xem ghi chú đầu tệp). Chỉ xu hướng theo tuổi (widthVsAdult) là số đo thật. */
    private const val ADULT_WIDTH_FRACTION = 0.245f

    /** Bốn chuỗi độc lập (2 quần thể × vai/hông), mỗi chuỗi lấy TRUNG BÌNH nam–nữ rồi chia cho chính nó lúc 18 tuổi: tỷ lệ TUYỆT ĐỐI so với người lớn (18 tuổi = 1). */
    private fun widthSeries(age: Int, sex: BodySex = BodySex.UNSPECIFIED): FloatArray {
        val i = idx(age); val a = BREADTH[i]; val adult = BREADTH[MAX_AGE - MIN_AGE]
        // MẪU SỐ luôn là người lớn TRUNG BÌNH nam–nữ của chính quần thể đó (mốc 1,0); tử số: trung bình (như cũ) hoặc cột riêng của giới (mục 285).
        return FloatArray(4) { k ->
            val now = when (sex) { BodySex.MALE -> a[2 * k]; BodySex.FEMALE -> a[2 * k + 1]; BodySex.UNSPECIFIED -> (a[2 * k] + a[2 * k + 1]) / 2f }
            now / ((adult[2 * k] + adult[2 * k + 1]) / 2f)
        }
    }

    /** Bề ngang vai/hông TUYỆT ĐỐI của người [age] tuổi so với người lớn (18 tuổi = 1,0) — SỐ ĐO THẬT: trung bình của bốn chuỗi ở [widthSeries]. Trẻ 6 tuổi ≈ 0,685; 12 tuổi ≈ 0,88. */
    fun widthVsAdult(age: Int, sex: BodySex = BodySex.UNSPECIFIED): Float { val s = widthSeries(age, sex); return (s[0] + s[1] + s[2] + s[3]) / 4f }

    /**
     * mục 285 — bề ngang RIÊNG của vai (hai quần thể: NHANES III bảng 53, Zivicnjak bảng 1) hoặc RIÊNG của hông (NHANES III bảng 56, Zivicnjak bảng 4), tuyệt đối so với người lớn TRUNG BÌNH (1,0).
     * UNSPECIFIED = trung bình cả bốn chuỗi (đúng y hệt [widthVsAdult] cũ — vai và hông dùng CHUNG một số, vì lấy trung bình nam–nữ thì hai chuỗi lệch nhau ≤ 0,04). MALE/FEMALE tách riêng vì khi
     * tách giới thì vai và hông KHÔNG còn song song: nam vai/hông 1,42 → 1,49, nữ 1,41 → 1,37 từ 8 → 18 tuổi (284.2); một hệ số chung sẽ xoá mất nét dị biệt giới rõ nhất của khung xương nhìn thẳng.
     */
    fun shoulderVsAdult(age: Int, sex: BodySex = BodySex.UNSPECIFIED): Float { val s = widthSeries(age, sex); return if (sex == BodySex.UNSPECIFIED) (s[0] + s[1] + s[2] + s[3]) / 4f else (s[0] + s[2]) / 2f }
    fun hipVsAdult(age: Int, sex: BodySex = BodySex.UNSPECIFIED): Float { val s = widthSeries(age, sex); return if (sex == BodySex.UNSPECIFIED) (s[0] + s[1] + s[2] + s[3]) / 4f else (s[1] + s[3]) / 2f }

    /** Độ lệch lớn nhất giữa bốn chuỗi ở một tuổi (max − min, so với người lớn = 1): đo MỨC ĐỒNG THUẬN của hai quần thể và của vai với hông; ≤ 0,06 ở mọi tuổi 6–18. */
    fun widthSpread(age: Int, sex: BodySex = BodySex.UNSPECIFIED): Float { val s = widthSeries(age, sex); return s.max() - s.min() }

    /** Bề ngang vai/hông theo CHIỀU CAO đứng của chính người đó. Xu hướng theo tuổi = số đo thật; mốc người lớn [ADULT_WIDTH_FRACTION] giữ nguyên (tuổi 18 cho đúng giá trị cũ 0,245). */
    fun shoulderFraction(age: Int, sex: BodySex = BodySex.UNSPECIFIED): Float = ADULT_WIDTH_FRACTION * shoulderVsAdult(age, sex) * heightCm(ADULT_AGE) / heightCm(age, sex)

    /** Như [shoulderFraction] nhưng cho HÔNG (cùng mốc 0,245 để có đơn vị; chỉ TỶ LỆ giữa các tuổi/giới được dùng). Không chọn giới ⇒ bằng đúng [shoulderFraction]. */
    fun hipFraction(age: Int, sex: BodySex = BodySex.UNSPECIFIED): Float = ADULT_WIDTH_FRACTION * hipVsAdult(age, sex) * heightCm(ADULT_AGE) / heightCm(age, sex)

    /** Độ dài từng đoạn theo PHẦN TRĂM (0..1) CHIỀU CAO ĐỨNG của chính người đó ở tuổi [age]. */
    fun heightFractions(age: Int, sex: BodySex = BodySex.UNSPECIFIED): Segments {
        val i = idx(age)
        // ĐẦU: phần trăm chiều cao theo QUY ƯỚC "N đầu" — chỉ phụ thuộc TUỔI (chiều cao trung bình nam–nữ ở cả tử lẫn mẫu), cố ý KHÔNG theo giới (xem ghi chú đầu tệp, mục 285).
        val head = headSizeVsAdult(age) * (heightCm(ADULT_AGE) / 7.5f) / heightCm(age)
        return Segments(
            head = head, trunk = v(i, 1, sex) - head, shoulder = shoulderFraction(age, sex),
            thigh = v(i, 2, sex), shank = v(i, 3, sex), upperArm = v(i, 4, sex), forearm = v(i, 5, sex),
            hip = hipFraction(age, sex)
        )
    }

    /** Hệ số TƯƠNG ĐỐI từng đoạn khi đổi tỷ lệ từ tuổi [fromAge] sang [toAge] (so theo phần trăm chiều cao — chưa chuẩn hoá chiều cao tổng). */
    fun factors(fromAge: Int, toAge: Int, sex: BodySex = BodySex.UNSPECIFIED): Segments {
        val a = heightFractions(fromAge, sex); val b = heightFractions(toAge, sex)
        return Segments(b.head / a.head, b.trunk / a.trunk, b.shoulder / a.shoulder, b.thigh / a.thigh, b.shank / a.shank, b.upperArm / a.upperArm, b.forearm / a.forearm, b.hip / a.hip)
    }

    /** Độ dài TUYỆT ĐỐI từng đoạn của người [age] tuổi so với người lớn (18 tuổi) — gồm cả việc trẻ thấp hơn. Dùng cho `BoneProportions` (1,0 = người lớn). */
    fun ratiosVsAdult(age: Int, sex: BodySex = BodySex.UNSPECIFIED): Segments {
        // MỐC (a, ha) luôn là người lớn TRUNG BÌNH nam–nữ: nữ trưởng thành < 1,0 và nam > 1,0 (mục 285); tử (c, hc) theo giới được chọn.
        val c = heightFractions(age, sex); val a = heightFractions(ADULT_AGE)
        val hc = heightCm(age, sex); val ha = heightCm(ADULT_AGE)
        fun r(x: Float, y: Float) = (x * hc) / (y * ha)
        return Segments(r(c.head, a.head), r(c.trunk, a.trunk), r(c.shoulder, a.shoulder), r(c.thigh, a.thigh), r(c.shank, a.shank), r(c.upperArm, a.upperArm), r(c.forearm, a.forearm), r(c.hip, a.hip))
    }
}
