package com.mangalocal.model

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.InstanceCreator

/**
 * mục 286 TECHNICAL_STATUS.md — Gson CHUNG cho mọi tệp JSON mô hình do StoryManager lưu/nạp (characters.json, story.json, chapter.json, addon_loras.json).
 *
 * VẤN ĐỀ: các lớp dữ liệu dưới đây có tham số BẮT BUỘC nên Kotlin không sinh hàm tạo không đối số; Gson dựng chúng bằng Unsafe và mọi trường VẮNG trong JSON thành null/0/false chứ KHÔNG lấy
 * giá trị mặc định. Với tệp lưu bởi bản cũ (thiếu các trường thêm về sau) đó là null ở kiểu không-null → NPE, hoặc giá trị sai (Bubble.xNorm 0 thay vì 0,1; AddonLora.enabled false thay vì true).
 * Đo bằng tools/test_gson_old_json.py: Gson trần làm hỏng 69/89 trường thử (13 lớp); nghiêm trọng nhất là StoryManager.loadStory nuốt NPE bằng `catch → null` nên TRUYỆN BIẾN MẤT khỏi danh sách.
 *
 * CÁCH SỬA: đăng ký InstanceCreator trả BẢN TRỐNG (hàm tạo Kotlin với giá trị trống cho tham số bắt buộc, mọi trường khác lấy mặc định thật). Trường nào có trong JSON thì Gson ghi đè.
 * KHI THÊM lớp dữ liệu mới được lưu bằng gson của StoryManager mà có tham số bắt buộc: THÊM nó vào đây VÀ vào tools/kotlin_tests/GsonOldJsonProbe.kt (test sẽ đỏ nếu quên cái sau).
 */
object ModelJson {
    private inline fun <reified T : Any> GsonBuilder.blank(crossinline make: () -> T): GsonBuilder = registerTypeAdapter(T::class.java, InstanceCreator<T> { make() })

    fun builder(): GsonBuilder = GsonBuilder()
        .blank { Character.blankForGson() }
        .blank { Story(id = "", title = "") }
        .blank { Chapter(id = "", storyId = "", title = "", chapterNumber = 0, storyText = "", style = ImageStyle.REALISTIC, panels = emptyList()) }
        .blank { Panel(index = 0, scene = blankScene(), prompt = "", negativePrompt = "") }
        .blank { blankScene() }
        .blank { Bubble(id = "", characterName = "", text = "") }
        .blank { DialogueLine(characterName = "", text = "") }
        .blank { ObjectBox(label = "", xmin = 0f, ymin = 0f, xmax = 0f, ymax = 0f) }
        .blank { Location(id = "", name = "") }
        .blank { CharacterAnchorVersion(fromChapterNumber = 0, imagePath = "") }
        .blank { AddonLora(id = "", displayName = "", fileName = "") }
        .blank { PageSpec(template = "", panelIndexes = emptyList()) }
        .blank { ConditioningPreset(0f, 0f, 0f, 0f, 0f, 0f) }   // 6 tham số Float bắt buộc, không có mặc định theo thiết kế

    private fun blankScene() = Scene(index = 0, description = "", characters = emptyList(), mood = "", cameraAngle = "")

    fun gson(): Gson = builder().create()
}
