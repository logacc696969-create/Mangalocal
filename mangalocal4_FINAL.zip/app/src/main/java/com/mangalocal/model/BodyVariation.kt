package com.mangalocal.model

import kotlin.math.floor

/**
 * mục 288 (triển khai 287.4) — HAI nguồn biến thiên ĐỘC LẬP giữa những người cùng tuổi, cùng giới (đo ở mục 287, tools/test_growth_variability.py):
 *  1. NHỊP (tempoYears): tuổi SINH HỌC = tuổi + tempo. Dịch cả bảng số đo theo trục tuổi của CHÍNH giới đó; kích thước người lớn KHÔNG đổi theo nhịp
 *     (chiều cao trưởng thành giữa nhóm sớm/muộn tương tự nhau — Kangwha/PMC4428512, mục 287.2). Độ lệch nhịp cá nhân cỡ ±1 năm (1 SD, mục 287.3a)
 *     nên mặc định kẹp ±3 năm (≈ ±3 SD). Chỉ có tác dụng trong dải bảng (6–18 tuổi); ngoài dải KHÔNG ngoại suy (kẹp vào đầu/cuối bảng).
 *  2. KÍCH THƯỚC (heightZ): vị trí so với bạn cùng tuổi cùng giới, đơn vị SD. Nhân MỌI độ dài với 1 + z·CV(tuổi, giới); CV = cột S của bảng LMS
 *     CDC 2000 (tools/data/cdc2000_stature_lms.txt, tuổi nguyên 6–18; 4,0–5,05%). Bảng CV trong mã này được test so TỪNG SỐ với tệp đó.
 *
 * Mọi hàm nhận TUỔI PHÂN SỐ (Float) và nội suy tuyến tính giữa hai tuổi nguyên kề nhau của [AgeBodyTable]. Tại tuổi nguyên, tempo 0 cho KẾT QUẢ Y HỆT
 * các hàm Int cũ của AgeBodyTable (test kiểm bằng ==, không phải gần đúng) — thêm tính năng mà không đổi hành vi hiện có.
 *
 * GIỚI HẠN THẬT: (a) CV chỉ lấy ở tuổi nguyên rồi nội suy (đủ vì CV đổi chậm: ≤ 0,2%/năm); (b) bảng LMS CDC là dân số Mỹ — chưa đối chiếu cho dân số khác;
 * (c) heightZ nhân đồng đều mọi độ dài (không mô hình hoá người cao-chân-dài khác người cao-thân-dài — chưa có số đo); (d) CHƯA nối vào UI/Character/BoneProportions:
 * đây mới là lớp tính toán đã kiểm; nối dây là bước sau (xem mục 288).
 */
object BodyVariation {
    /** Kẹp nhịp: ±3 năm (≈ ±3 SD của độ lệch PHV ~1 năm). */
    const val MAX_TEMPO_YEARS = 3f
    /** Kẹp kích thước: ±3 SD. */
    const val MAX_HEIGHT_Z = 3f
    private const val MIN_SCALE = 0.5f   // chặn an toàn: không bao giờ nhân ≤ 0 dù CV/z bị sửa sai

    // Hệ số biến thiên chiều cao cùng tuổi cùng giới theo tuổi nguyên 6..18 = cột S của CDC 2000 stature-for-age (LMS). Sinh từ tools/data/cdc2000_stature_lms.txt.
    private val CV_MALE = floatArrayOf(0.043673f, 0.044403f, 0.045127f, 0.046217f, 0.047610f, 0.048938f, 0.049948f, 0.050333f, 0.048945f, 0.045890f, 0.043086f, 0.041408f, 0.040644f)
    private val CV_FEMALE = floatArrayOf(0.044964f, 0.045461f, 0.045968f, 0.046884f, 0.048705f, 0.050524f, 0.048599f, 0.043859f, 0.041022f, 0.040084f, 0.039821f, 0.039732f, 0.039687f)

    private fun clampAge(age: Float): Float = if (age.isNaN()) AgeBodyTable.MIN_AGE.toFloat() else age.coerceIn(AgeBodyTable.MIN_AGE.toFloat(), AgeBodyTable.MAX_AGE.toFloat())

    /** Tuổi sinh học = tuổi + tempo (kẹp ±[MAX_TEMPO_YEARS]), rồi kẹp vào dải bảng [MIN_AGE, MAX_AGE]. */
    fun biologicalAge(age: Float, tempoYears: Float = 0f): Float {
        val t = if (tempoYears.isNaN()) 0f else tempoYears.coerceIn(-MAX_TEMPO_YEARS, MAX_TEMPO_YEARS)
        return clampAge(age + t)
    }

    /** Tuổi nguyên dưới/trên + trọng số nội suy; tại tuổi nguyên w = 0 và lo == hi (để kết quả BẰNG HỆT hàm Int, không qua phép nhân thừa). */
    private class Frac(val lo: Int, val hi: Int, val w: Float)
    private fun frac(a: Float): Frac {
        val c = clampAge(a); val lo = floor(c).toInt().coerceIn(AgeBodyTable.MIN_AGE, AgeBodyTable.MAX_AGE)
        val w = c - lo
        return if (w <= 0f || lo >= AgeBodyTable.MAX_AGE) Frac(lo, lo, 0f) else Frac(lo, lo + 1, w)
    }
    private fun lerp(a: Float, b: Float, w: Float): Float = if (w == 0f) a else a + (b - a) * w

    /** Chiều cao (cm) tại tuổi PHÂN SỐ [age] của người có nhịp [tempoYears]: bằng chiều cao bảng tại tuổi sinh học (người lớn không đổi: 18+ kẹp vào hàng 18). */
    fun heightCmAt(age: Float, sex: BodySex = BodySex.UNSPECIFIED, tempoYears: Float = 0f): Float {
        val f = frac(biologicalAge(age, tempoYears))
        return lerp(AgeBodyTable.heightCm(f.lo, sex), AgeBodyTable.heightCm(f.hi, sex), f.w)
    }

    /** Tỷ lệ từng đoạn theo % chiều cao đứng tại tuổi sinh học (nội suy tuyến tính từng trường). */
    fun heightFractionsAt(age: Float, sex: BodySex = BodySex.UNSPECIFIED, tempoYears: Float = 0f): AgeBodyTable.Segments {
        val f = frac(biologicalAge(age, tempoYears))
        val a = AgeBodyTable.heightFractions(f.lo, sex); val b = AgeBodyTable.heightFractions(f.hi, sex)
        return AgeBodyTable.Segments(
            head = lerp(a.head, b.head, f.w), trunk = lerp(a.trunk, b.trunk, f.w), shoulder = lerp(a.shoulder, b.shoulder, f.w),
            thigh = lerp(a.thigh, b.thigh, f.w), shank = lerp(a.shank, b.shank, f.w), upperArm = lerp(a.upperArm, b.upperArm, f.w),
            forearm = lerp(a.forearm, b.forearm, f.w), hip = lerp(a.hip, b.hip, f.w)
        )
    }

    /** Hệ số biến thiên chiều cao cùng tuổi cùng giới (CV, ví dụ 0,05 = 5%). UNSPECIFIED = trung bình hai giới. Dùng TUỔI THỰC (kích thước là đặc tính theo tuổi thực, không theo nhịp). */
    fun cv(age: Float, sex: BodySex = BodySex.UNSPECIFIED): Float {
        val f = frac(age)
        fun at(i: Int): Float { val k = i - AgeBodyTable.MIN_AGE; return when (sex) { BodySex.MALE -> CV_MALE[k]; BodySex.FEMALE -> CV_FEMALE[k]; else -> (CV_MALE[k] + CV_FEMALE[k]) / 2f } }
        return lerp(at(f.lo), at(f.hi), f.w)
    }

    /** Hệ số nhân MỌI độ dài của người cao/thấp [heightZ] SD so với bạn cùng tuổi cùng giới: 1 + z·CV. z = 0 -> đúng 1,0. */
    fun sizeScale(age: Float, sex: BodySex = BodySex.UNSPECIFIED, heightZ: Float = 0f): Float {
        val z = if (heightZ.isNaN()) 0f else heightZ.coerceIn(-MAX_HEIGHT_Z, MAX_HEIGHT_Z)
        return (1f + z * cv(age, sex)).coerceAtLeast(MIN_SCALE)
    }
}
