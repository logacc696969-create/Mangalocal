package com.mangalocal.pipeline

import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * mục 244 TECHNICAL_STATUS.md — CHUẨN BỊ ẢNH TĨNH LÀM KHUNG HÌNH ĐẦU/CUỐI cho model image-to-video (Wan 2.x, Kling, LTX, Runway...).
 *
 * Cộng đồng làm gì (đã tra cứu, xem mục 244):
 * - Ảnh vào là khung hình ĐẦU: "chọn khung đầu đã giải quyết xong danh tính, trang phục, bố cục; nếu ảnh lộn xộn, prompt phải vừa sửa vừa tạo
 *   chuyển động" (naviya.chat); ảnh phải chất lượng cao, KHÔNG có lỗi — "mặt/tay mờ sẽ bị khuếch đại khi thành video" (Runway Help);
 *   ảnh đông người, nhiều chữ, gợi ý chuyển động mơ hồ làm video khó hơn (PixVerse); chủ thể rõ, sáng (Wink/Wan 2.2).
 * - Prompt chỉ mô tả CHUYỂN ĐỘNG, không lặp lại cái đã thấy trong ảnh: công thức "hành động chủ thể + camera + chuyển động môi trường + tốc độ",
 *   hành động của chủ thể đặt ĐẦU CÂU; chỉ làm động thứ có trong ảnh; negative: morphing, warping, distortion, flickering, jittering,
 *   face deformation, body distortion, changing identity (VEED, Wink, Unifically — hướng dẫn Wan 2.2).
 * - Đổi BIỂU CẢM trong video: dùng First-Last-Frame (FLF2V/Kling Start-End/Luma Keyframes): hai khung cùng góc máy, cùng khung hình, cùng ánh sáng
 *   — chỉ MỘT biến đổi lớn (zsky.ai); prompt mô tả quá trình "emotional expression shift from neutral to gentle smile" (workflow Wan 2.2 FLF) và
 *   "Start exactly from the first image and end exactly at the last image" (WaveSpeed). Nhiều người dựng hai khung bằng Qwen Image Edit (Wan2GP) —
 *   ở đây khung kết được tạo bằng chính lượt vẽ lại MẶT (inpaint) nên bố cục/khung hình/ánh sáng GIỐNG HỆT khung đầu theo cách xây dựng.
 * - Độ phân giải đích: 512×512, 480×832, 832×480, 720×720, 720×1280, 1280×720 (README FlashPortrait/Wan); ảnh nên khớp tỉ lệ khung đích.
 *
 * GIỚI HẠN THẬT: các ngưỡng cảnh báo (mặt nhỏ < 6% cạnh ngắn, ≥ 4 người) là heuristic của tôi suy ra từ khuyến nghị ĐỊNH TÍNH ở trên — nguồn không
 * nêu con số; chưa hiệu chỉnh với model video nào. Dự án KHÔNG tự chạy model video; đây chỉ là bước chuẩn bị đầu vào + prompt.
 */
enum class VideoTarget(val label: String, val w: Int, val h: Int) {
    KEEP("Giữ nguyên tỉ lệ ảnh", 0, 0),
    LANDSCAPE_480("832×480 (ngang, 480p)", 832, 480),
    PORTRAIT_480("480×832 (dọc, 480p)", 480, 832),
    LANDSCAPE_720("1280×720 (ngang, HD)", 1280, 720),
    PORTRAIT_720("720×1280 (dọc, HD)", 720, 1280),
    SQUARE_720("720×720 (vuông)", 720, 720),
    SQUARE_512("512×512 (vuông)", 512, 512)
}

object VideoPrep {
    const val SMALL_FACE_FRACTION = 0.06f   // đầu rộng < 6% cạnh ngắn -> mặt nhỏ (heuristic)
    const val CROWD_PERSONS = 4             // >= 4 người -> đông (heuristic)
    const val MIN_SIDE_PX = 512             // README Wan 2.2 I2V GGUF: "recommended 512x512 or higher"

    const val NEGATIVE_PROMPT =
        "morphing, warping, distortion, flickering, jittering, face deformation, body distortion, changing identity, extra fingers, text, watermark"

    data class Crop(val rect: Rect, val containsAll: Boolean)

    /**
     * Cắt vùng tỉ lệ [targetW]:[targetH] LỚN NHẤT trong ảnh, đặt sao cho chứa trọn [keep] (các hộp đầu, đã nới) nếu có thể.
     * targetW/H <= 0 -> toàn ảnh. [containsAll] = false khi các hộp không vừa trong vùng cắt (mặt bị cắt).
     */
    fun cropForAspect(imgW: Int, imgH: Int, targetW: Int, targetH: Int, keep: List<Rect>): Crop {
        if (imgW <= 0 || imgH <= 0) return Crop(Rect(0, 0, max(imgW, 0), max(imgH, 0)), false)
        if (targetW <= 0 || targetH <= 0) return Crop(Rect(0, 0, imgW, imgH), true)
        val aspect = targetW.toFloat() / targetH
        val cropW: Int; val cropH: Int
        if (imgW.toFloat() / imgH > aspect) { cropH = imgH; cropW = min(imgW, (imgH * aspect).roundToInt()) }
        else { cropW = imgW; cropH = min(imgH, (imgW / aspect).roundToInt()) }
        val valid = keep.filter { it.width() > 0 && it.height() > 0 }
        val cx: Float; val cy: Float
        if (valid.isEmpty()) { cx = imgW / 2f; cy = imgH / 2f }
        else {
            val ul = valid.minOf { it.left }; val ur = valid.maxOf { it.right }
            val ut = valid.minOf { it.top }; val ub = valid.maxOf { it.bottom }
            cx = (ul + ur) / 2f; cy = (ut + ub) / 2f
        }
        val left = (cx - cropW / 2f).roundToInt().coerceIn(0, imgW - cropW)
        val top = (cy - cropH / 2f).roundToInt().coerceIn(0, imgH - cropH)
        val r = Rect(left, top, left + cropW, top + cropH)
        val all = valid.all { it.left >= r.left && it.right <= r.right && it.top >= r.top && it.bottom <= r.bottom }
        return Crop(r, all)
    }

    data class Issue(val code: String, val severity: Int, val message: String) // 1 = thông tin, 2 = cảnh báo

    data class FaceInfo(val headWidthPx: Float, val threeQuarter: Boolean)

    fun readiness(
        imgW: Int, imgH: Int, personCount: Int, faces: List<FaceInfo>, qualityPassed: Boolean,
        cropContainsFaces: Boolean, wantsEndFrame: Boolean, hasEndFrame: Boolean
    ): List<Issue> {
        val out = ArrayList<Issue>()
        val minSide = min(imgW, imgH)
        if (minSide in 1 until MIN_SIDE_PX)
            out += Issue("small_image", 2, "Ảnh nhỏ (${imgW}×${imgH}) — khuyến nghị cạnh ngắn ≥ $MIN_SIDE_PX; ảnh kém chất lượng thì lỗi mặt/tay bị khuếch đại thành video.")
        if (!qualityPassed) out += Issue("quality_gate", 2, "Panel chưa đạt Quality Gate — lỗi giải phẫu sẽ bị video khuếch đại, nên sửa trước.")
        if (personCount > 0 && faces.isEmpty())
            out += Issue("no_face", 1, "Không dò được mặt rõ (quay lưng/che mặt/không có khung xương) — khó diễn biểu cảm bằng video.")
        if (faces.any { it.headWidthPx < SMALL_FACE_FRACTION * minSide })
            out += Issue("small_face", 2, "Có mặt quá nhỏ (đầu < ${(SMALL_FACE_FRACTION * 100).toInt()}% cạnh ngắn) — biểu cảm khó thể hiện trong video; cân nhắc khung cận hơn.")
        if (faces.any { it.threeQuarter }) out += Issue("three_quarter", 1, "Có mặt chỉ thấy 1 mắt (3/4 hoặc nghiêng) — biểu cảm kém ổn định hơn mặt chính diện.")
        if (personCount >= CROWD_PERSONS)
            out += Issue("crowded", 2, "Đông người ($personCount) — ảnh đông người làm model video khó giữ danh tính/chuyển động; cân nhắc tách thành nhiều đoạn.")
        if (!cropContainsFaces) out += Issue("crop_cuts_face", 2, "Khung đích cắt mất một phần mặt — chọn tỉ lệ khác hoặc 'Giữ nguyên'.")
        if (wantsEndFrame && !hasEndFrame) out += Issue("end_frame_missing", 1, "Đã chọn biểu cảm kết nhưng chưa tạo khung kết.")
        return out
    }

    // Từ chỉ cảm xúc dạng văn thường cho prompt video (KHÔNG dùng tag): prompt video mô tả chuyển động, không phải tag.
    private val EMOTION_WORDS = mapOf(
        "neutral" to "a calm look", "smile" to "a warm smile", "sad" to "sadness", "angry" to "anger", "surprised" to "surprise",
        "scared" to "fear", "disgust" to "disgust", "contempt" to "contempt", "crying" to "tears", "smirk" to "a smug smirk",
        "determined" to "determination", "blush" to "embarrassment", "pain" to "pain", "exertion" to "strain and effort",
        "shouting" to "a furious shout", "terrified" to "terror", "exhausted" to "exhaustion", "triumphant" to "triumph",
        "menacing" to "menace", "shocked" to "shock", "anguished" to "anguish", "pleading" to "desperate pleading",
        "suspicious" to "suspicion", "laughing" to "laughter", "serene" to "serenity", "dazed" to "a dazed blankness",
        "winking" to "a playful wink"
    )

    fun emotionWord(key: String?): String =
        if (key == null) "a calm look"
        else EMOTION_WORDS[key] ?: ExpressionRegistry.presetOf(key)?.lead ?: "a calm look"

    /**
     * Prompt chuyển động: hành động chủ thể TRƯỚC, rồi camera, rồi nhịp. Chỉ nhắc nhân vật có trong ảnh ([names]); không mô tả ngoại hình.
     * [end] có và khác [start] -> mô tả quá trình đổi biểu cảm (FLF2V). Trả (positive, negative).
     */
    fun buildPrompt(
        names: List<String>, start: Map<String, String>, end: Map<String, String>, speakers: Set<String>,
        hasEndFrame: Boolean, faceFocus: Boolean
    ): Pair<String, String> {
        val parts = ArrayList<String>()
        for (n in names.take(3)) {
            val s = start[n]; val e = end[n]
            val speaks = speakers.any { it.equals(n, ignoreCase = true) }
            var line = if (hasEndFrame && e != null && e != (s ?: "neutral"))
                "$n's expression shifts from ${emotionWord(s)} to ${emotionWord(e)}, with a natural blink and a subtle head movement"
            else if (s != null && s != "neutral")
                "$n holds ${emotionWord(s)} with subtle natural motion, blinking and slow breathing"
            else "$n stays calm with natural blinking and slow breathing"
            if (speaks) line += ", lips moving naturally as $n speaks"
            parts += line
        }
        val camera = if (faceFocus) "the camera makes a slow gentle push-in toward the face" else "the camera stays mostly static with a very slight drift"
        val sb = StringBuilder()
        sb.append(parts.joinToString(". ")).append(". ").append(camera.replaceFirstChar { it.uppercase() }).append(", calm natural pace.")
        if (hasEndFrame) sb.append(" Start exactly from the first image and end exactly at the last image.")
        return sb.toString() to NEGATIVE_PROMPT
    }
}
