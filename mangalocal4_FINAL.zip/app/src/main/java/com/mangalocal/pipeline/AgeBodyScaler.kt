package com.mangalocal.pipeline

import com.mangalocal.model.AgeBodyTable
import kotlin.math.hypot

/**
 * mục 278 TECHNICAL_STATUS.md — đổi tỷ lệ cơ thể theo tuổi cho TỪNG ĐOẠN: đầu, thân, vai/hông, cánh tay trên, cẳng tay, đùi, cẳng chân (mục 277 trước đây gộp cả tay làm một,
 * cả chân làm một). Tách khỏi PoseExtractor để biên dịch và chạy thử độc lập (không phụ thuộc Android/Context).
 *
 * Mỗi đoạn có HỆ SỐ RIÊNG (xem AgeBodyTable.factors). Hệ số được nhân thêm một số chuẩn hoá chung `norm` sao cho TỔNG độ dài các đoạn đứng (đầu + thân + đùi + cẳng chân) KHÔNG ĐỔI:
 * chỉ đổi TỶ LỆ, không phóng to/thu nhỏ cả người. Mỗi đoạn giữ NGUYÊN HƯỚNG, chỉ đổi độ dài, gắn vào khớp cha đã dời; tâm hông đứng yên; khớp đang ẩn không bị động;
 * thiếu cổ hoặc một trong hai hông thì trả đúng danh sách cũ (cùng đối tượng — UI dựa vào `===` để biết "không áp dụng được"). Đổi A→B→A về đúng hình cũ.
 *
 * Độ dài đoạn đo THEO TỪNG ĐOẠN (không phải khoảng cách thẳng hông→cổ chân) nên chân đang gập vẫn co giãn đúng từng đoạn; chiều cao "tổng" ở đây là tổng độ dài các đoạn,
 * bằng chiều cao đứng khi người đứng thẳng. Chỉ số OpenPose BODY_18: 0 mũi, 1 cổ, 2/5 vai P/T, 3/6 khuỷu, 4/7 cổ tay, 8/11 hông P/T, 9/12 gối, 10/13 cổ chân, 14/15 mắt, 16/17 tai.
 */
object AgeBodyScaler {
    fun rescale(
        person: MutableList<StoryManager.PoseKeypoint>, f: AgeBodyTable.Segments
    ): MutableList<StoryManager.PoseKeypoint> {
        if (person.size < 18) return person
        val neck = person[1]; val rHip = person[8]; val lHip = person[11]
        if (!neck.visible || !rHip.visible || !lHip.visible) return person

        val hx = (rHip.x + lHip.x) / 2f; val hy = (rHip.y + lHip.y) / 2f
        val nose = person[0]
        val headLen0 = if (nose.visible) hypot(nose.x - neck.x, nose.y - neck.y) else 0f
        val trunkLen0 = hypot(neck.x - hx, neck.y - hy)
        // độ dài trung bình của một đoạn trên các bên đang hiện (cả hai khớp đầu mút phải hiện)
        fun meanLen(pairs: List<Pair<Int, Int>>): Float {
            val l = pairs.filter { (a, b) -> person[a].visible && person[b].visible }
                .map { (a, b) -> hypot(person[b].x - person[a].x, person[b].y - person[a].y) }
            return if (l.isEmpty()) 0f else l.sum() / l.size
        }
        val thighLen0 = meanLen(listOf(8 to 9, 11 to 12))
        val shankLen0 = meanLen(listOf(9 to 10, 12 to 13))
        val before = headLen0 + trunkLen0 + thighLen0 + shankLen0
        val after = headLen0 * f.head + trunkLen0 * f.trunk + thighLen0 * f.thigh + shankLen0 * f.shank
        val norm = if (after > 1e-6f) before / after else 1f
        val fh = f.head * norm; val ft = f.trunk * norm; val fs = f.shoulder * norm
        val fHip = f.hip * norm   // mục 285: hông có hệ số riêng; mặc định (Segments.hip = shoulder) ⇒ y hệt cũ
        val fTh = f.thigh * norm; val fSh = f.shank * norm; val fUa = f.upperArm * norm; val fFa = f.forearm * norm

        val out = person.toMutableList()
        // hông: giữ tâm hông, đổi bề ngang; cổ: thân đổi dài quanh tâm hông
        out[8] = rHip.copy(x = hx + (rHip.x - hx) * fHip, y = hy + (rHip.y - hy) * fHip)
        out[11] = lHip.copy(x = hx + (lHip.x - hx) * fHip, y = hy + (lHip.y - hy) * fHip)
        out[1] = neck.copy(x = hx + (neck.x - hx) * ft, y = hy + (neck.y - hy) * ft)
        // gắn khớp con vào khớp cha ĐÃ dời: vectơ cha→con (gốc) × hệ số
        fun place(child: Int, parent: Int, factor: Float) {
            val c = person[child]; val p = person[parent]
            if (!c.visible || !p.visible) return
            val np = out[parent]
            out[child] = c.copy(x = np.x + (c.x - p.x) * factor, y = np.y + (c.y - p.y) * factor)
        }
        place(2, 1, fs); place(5, 1, fs)                 // vai
        place(3, 2, fUa); place(6, 5, fUa)               // cánh tay trên (vai → khuỷu)
        place(4, 3, fFa); place(7, 6, fFa)               // cẳng tay (khuỷu → cổ tay)
        place(9, 8, fTh); place(12, 11, fTh)             // đùi (hông → gối)
        place(10, 9, fSh); place(13, 12, fSh)            // cẳng chân (gối → cổ chân)
        place(0, 1, fh)                                  // mũi theo cổ
        place(14, 0, fh); place(15, 0, fh); place(16, 0, fh); place(17, 0, fh) // mắt, tai theo mũi
        return out
    }
}
