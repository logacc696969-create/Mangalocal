package com.mangalocal.pipeline

/**
 * mục 266 TECHNICAL_STATUS.md — dựng body + đọc phản hồi của API kiểu OpenAI `POST {base}/chat/completions`, thuần Kotlin để kiểm thử bằng kotlinc
 * (tools/test_openai_json.py). Dùng cho ExternalLlmClient (chữ) và nhánh nhìn ảnh (giám khảo VLM qua API, ví dụ Gemini bậc miễn phí).
 *
 * Định dạng ảnh theo chuẩn OpenAI vision: `content` là MẢNG phần tử {type:"text"} + {type:"image_url", image_url:{url:"data:<mime>;base64,<...>"}}.
 * GIỚI HẠN THẬT: chưa gọi thử với dịch vụ thật nào (sandbox không ra Internet) — định dạng bám theo chuẩn công khai; mỗi nhà cung cấp có thể lệch
 * (tên model hỗ trợ ảnh, kích thước ảnh tối đa, có nhận data: URL không). Không có chế độ JSON/response_format, không có role "system" (như bản cũ).
 */
object OpenAiChatJson {
    private fun temp(t: Float): String = if (t.isNaN() || t.isInfinite()) "0" else t.toString()

    fun textBody(model: String, prompt: String, maxTokens: Int, temperature: Float): String =
        "{\"model\":" + MiniJson.quote(model) + ",\"temperature\":" + temp(temperature) + ",\"max_tokens\":" + maxTokens +
            ",\"messages\":[{\"role\":\"user\",\"content\":" + MiniJson.quote(prompt) + "}]}"

    /** [imageBase64] đã là base64 THUẦN (không kèm tiền tố data:). [mime] vd "image/jpeg". */
    fun visionBody(model: String, prompt: String, imageBase64: String, mime: String, maxTokens: Int, temperature: Float): String =
        "{\"model\":" + MiniJson.quote(model) + ",\"temperature\":" + temp(temperature) + ",\"max_tokens\":" + maxTokens +
            ",\"messages\":[{\"role\":\"user\",\"content\":[" +
            "{\"type\":\"text\",\"text\":" + MiniJson.quote(prompt) + "}," +
            "{\"type\":\"image_url\",\"image_url\":{\"url\":" + MiniJson.quote("data:$mime;base64,$imageBase64") + "}}" +
            "]}]}"

    /**
     * Văn bản trả lời từ phản hồi thành công. `content` có thể là chuỗi hoặc mảng phần tử {type:"text", text} (một số nhà cung cấp) -> nối các phần chữ.
     * Ném IllegalArgumentException (thông báo tiếng Việt) khi: JSON hỏng, có đối tượng "error", không có choices, hoặc content rỗng/null.
     */
    fun extractContent(responseText: String): String {
        val root = MiniJson.parse(responseText)
        val err = MiniJson.path(root, "error")
        if (err != null) {
            val msg = (MiniJson.path(err, "message") as? String) ?: err.toString()
            throw IllegalArgumentException("API trả lỗi: " + msg.take(300))
        }
        val choices = MiniJson.arr(MiniJson.path(root, "choices"))
        if (choices == null || choices.isEmpty()) throw IllegalArgumentException("Phản hồi không có 'choices' (kiểm tra lại Base URL/model)")
        val content = MiniJson.path(choices, 0, "message", "content")
        val text = when (content) {
            is String -> content
            is List<*> -> content.joinToString("") { part ->
                val m = MiniJson.obj(part)
                if (m != null && (m["type"] == null || m["type"] == "text")) (m["text"] as? String).orEmpty() else ""
            }
            else -> ""
        }
        if (text.isBlank()) {
            val why = MiniJson.path(choices, 0, "finish_reason") as? String
            throw IllegalArgumentException("Phản hồi rỗng" + (if (why != null) " (finish_reason=$why)" else "") + " — có thể model cần nhiều max_tokens hơn hoặc không hỗ trợ đầu vào này")
        }
        return text
    }
}
