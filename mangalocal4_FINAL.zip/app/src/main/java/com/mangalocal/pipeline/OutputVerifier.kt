package com.mangalocal.pipeline

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * mục 248 TECHNICAL_STATUS.md — KIỂM TRA ẢNH SAU KHI SINH (generate → detect → verify).
 *
 * Vì sao có: cổng chất lượng cũ (QualityGateChecker, mục 74/187) chỉ xét KHUNG XƯƠNG ĐẦU VÀO, không nhìn pixel ảnh
 * đầu ra. Các kỹ thuật "ép" layout/tỉ lệ/vật lý trong lúc khử nhiễu (FOCAL, CoT-Diff, reward vật lý, MoFu...) cần
 * can thiệp sampler/attention nên không chạy được trên MNN (mục 124/230). Cộng đồng có hướng thay thế KHÔNG cần sửa
 * sampler: sinh xong → chạy bộ phát hiện trên ảnh ra → so với ý đồ → báo/thử lại (vd. "Self-correcting LLM-controlled
 * Diffusion", CVPR 2024, dùng bộ phát hiện đối tượng trong vòng sinh–kiểm–sửa; tra cứu mục 248). Ở đây bộ phát hiện
 * là YOLOv8-pose ĐÃ có sẵn trong ứng dụng (`PoseExtractor.extractFromImage`).
 *
 * Kiểm tra gì (đều so ảnh ra với khung xương đưa vào ControlNet-Pose, cùng hệ toạ độ chuẩn hoá 0..1):
 *  1. ĐẾM NGƯỜI: thiếu người (dò được ít hơn khung xương) hoặc thừa người (dò được nhiều hơn kỳ vọng + 1).
 *  2. LỆCH TƯ THẾ: với mỗi cặp người ghép được, trung vị khoảng cách khớp-ảnh-ra vs khớp-khung-xương, chia cho
 *     chiều dài thân (cổ → giữa hông) của khung xương.
 *  3. TỈ LỆ GIỮA CÁC NGƯỜI: chiều cao người trong ảnh ra / chiều cao trong khung xương, so GIỮA các người — nếu một
 *     người to/nhỏ bất thường hơn người kia (vd. khung xương ghi xa/gần nhưng ảnh ra bằng nhau) thì cảnh báo.
 *
 * GIỚI HẠN THẬT:
 *  - Mọi ngưỡng ở `Thresholds` là ƯỚC LƯỢNG, CHƯA hiệu chỉnh trên ảnh thật của dự án.
 *  - Khung xương dùng để so là kết quả `resolveSkeletonData()` — có thể KHÔNG trùng 100% khung xương cuối cùng mà
 *    native nhận (nếu có bước chỉnh sau đó), nên sai số tư thế có thể bị thổi phồng; vì vậy đây là CẢNH BÁO để người
 *    xem lại, không tự thử lại/không chặn.
 *  - Bộ phát hiện chạy trên ảnh 512px; người bị che nhiều/nằm sát nhau (vật lộn!) có thể bị dò thiếu hoặc ghép nhầm
 *    ngay cả khi ảnh đúng — đây chính là trường hợp khó nhất, kết quả cần đọc thận trọng.
 *  - Ghép cặp tham lam theo khoảng cách trọng tâm (không tối ưu toàn cục); đủ cho ≤ 4–5 người.
 *  - CHƯA build-test.
 */
object OutputVerifier {

    object Thresholds {
        /** Số khớp tối thiểu cùng thấy được ở cả hai bên mới đánh giá lệch tư thế. */
        const val MIN_SHARED_JOINTS = 6
        /** Trung vị sai số khớp (đơn vị: chiều dài thân khung xương) — trên mức này coi là lệch tư thế. */
        const val MAX_MEDIAN_ERROR = 0.35f
        /** Chênh lệch tỉ lệ giữa người: max/min - 1 tối đa. (cộng đồng dùng 20% cho vật thể giữa các panel — mục 235) */
        const val MAX_SCALE_SPREAD = 0.30f
        /** Khi chỉ có 1 người ghép được: tỉ lệ cao ảnh-ra/khung-xương nằm trong [MIN, MAX]. */
        const val SINGLE_SCALE_MIN = 0.60f
        const val SINGLE_SCALE_MAX = 1.60f
        /** Khoảng y tối thiểu (chuẩn hoá) của khung xương để tính tỉ lệ cao. */
        const val MIN_SPAN = 0.05f
        /** Thừa người: dò được > kỳ vọng + EXTRA_PERSONS_ALLOWED mới cảnh báo (người nền hợp lệ). */
        const val EXTRA_PERSONS_ALLOWED = 1
        /** Chiều dài thân tối thiểu (chuẩn hoá) để dùng làm đơn vị đo. */
        const val MIN_TORSO = 0.03f
    }

    const val JOINTS = 18
    const val FLOATS_PER_JOINT = 4   // x, y, z, visible — cùng bố cục với ContactDetector / native Keypoint (mục 231)

    class Joint(val x: Float, val y: Float, val visible: Boolean)
    class Person(val joints: List<Joint>)

    data class PersonMatch(
        val targetIdx: Int, val detectedIdx: Int,
        val medianError: Float, val scaleRatio: Float, val sharedJoints: Int
    )

    data class Result(
        val passed: Boolean,
        val reasons: List<String>,
        val matches: List<PersonMatch>,
        val expected: Int,
        val detected: Int
    )

    /** Mảng phẳng 18 khớp × 4 float mỗi người (x, y, z, visible 0/1) → danh sách người. */
    fun targetsFromSkeleton(data: FloatArray): List<Person> {
        val per = JOINTS * FLOATS_PER_JOINT
        if (data.isEmpty() || data.size % per != 0) return emptyList()
        val out = ArrayList<Person>()
        var p = 0
        while (p < data.size / per) {
            val base = p * per
            out.add(Person(List(JOINTS) { j ->
                val o = base + j * FLOATS_PER_JOINT
                Joint(data[o], data[o + 1], data[o + 3] > 0.5f)
            }))
            p++
        }
        return out
    }

    private fun centroid(p: Person): Pair<Float, Float>? {
        var sx = 0f; var sy = 0f; var n = 0
        for (j in p.joints) if (j.visible) { sx += j.x; sy += j.y; n++ }
        return if (n == 0) null else Pair(sx / n, sy / n)
    }

    /** Chiều dài thân: cổ (1) → trung điểm hai hông (8, 11); thiếu thì 0.35 × chiều cao hộp các khớp thấy được. */
    private fun torsoLength(p: Person): Float {
        val neck = p.joints[1]; val rh = p.joints[8]; val lh = p.joints[11]
        if (neck.visible && rh.visible && lh.visible) {
            val mx = (rh.x + lh.x) / 2f; val my = (rh.y + lh.y) / 2f
            val dx = neck.x - mx; val dy = neck.y - my
            return sqrt(dx * dx + dy * dy)
        }
        var lo = Float.MAX_VALUE; var hi = -Float.MAX_VALUE; var n = 0
        for (j in p.joints) if (j.visible) { lo = min(lo, j.y); hi = max(hi, j.y); n++ }
        return if (n < 2) 0f else 0.35f * (hi - lo)
    }

    private fun median(v: List<Float>): Float {
        val s = v.sorted()
        val n = s.size
        return if (n % 2 == 1) s[n / 2] else (s[n / 2 - 1] + s[n / 2]) / 2f
    }

    /** Ghép tham lam theo khoảng cách trọng tâm nhỏ nhất; trả về danh sách (chỉ số đích, chỉ số dò được). */
    internal fun greedyMatch(targets: List<Person>, detected: List<Person>): List<Pair<Int, Int>> {
        data class Cand(val t: Int, val d: Int, val dist: Float)
        val cands = ArrayList<Cand>()
        for (ti in targets.indices) {
            val tc = centroid(targets[ti]) ?: continue
            for (di in detected.indices) {
                val dc = centroid(detected[di]) ?: continue
                val dx = tc.first - dc.first; val dy = tc.second - dc.second
                cands.add(Cand(ti, di, sqrt(dx * dx + dy * dy)))
            }
        }
        cands.sortBy { it.dist }
        val usedT = HashSet<Int>(); val usedD = HashSet<Int>()
        val out = ArrayList<Pair<Int, Int>>()
        for (c in cands) {
            if (c.t in usedT || c.d in usedD) continue
            usedT.add(c.t); usedD.add(c.d)
            out.add(Pair(c.t, c.d))
        }
        return out
    }

    fun verify(targets: List<Person>, detected: List<Person>): Result {
        val reasons = ArrayList<String>()
        val expected = targets.size
        if (expected == 0) return Result(true, emptyList(), emptyList(), 0, detected.size)

        if (detected.size < expected) {
            reasons.add("Ảnh sau sinh: chỉ dò được ${detected.size}/$expected người (có thể thiếu người hoặc bị dính vào nhau)")
        } else if (detected.size > expected + Thresholds.EXTRA_PERSONS_ALLOWED) {
            reasons.add("Ảnh sau sinh: dò được ${detected.size} người, khung xương chỉ có $expected (thừa người?)")
        }

        val matches = ArrayList<PersonMatch>()
        for ((ti, di) in greedyMatch(targets, detected)) {
            val t = targets[ti]; val d = detected[di]
            val torso = torsoLength(t)
            val errs = ArrayList<Float>()
            var tLo = Float.MAX_VALUE; var tHi = -Float.MAX_VALUE
            var dLo = Float.MAX_VALUE; var dHi = -Float.MAX_VALUE
            for (j in 0 until JOINTS) {
                val tj = t.joints[j]; val dj = d.joints[j]
                if (!tj.visible || !dj.visible) continue
                val dx = tj.x - dj.x; val dy = tj.y - dj.y
                if (torso >= Thresholds.MIN_TORSO) errs.add(sqrt(dx * dx + dy * dy) / torso)
                tLo = min(tLo, tj.y); tHi = max(tHi, tj.y)
                dLo = min(dLo, dj.y); dHi = max(dHi, dj.y)
            }
            val shared = if (torso >= Thresholds.MIN_TORSO) errs.size else 0
            val med = if (errs.size >= Thresholds.MIN_SHARED_JOINTS) median(errs) else -1f
            val tSpan = tHi - tLo
            val ratio = if (tSpan >= Thresholds.MIN_SPAN && dHi >= dLo) (dHi - dLo) / tSpan else -1f
            matches.add(PersonMatch(ti, di, med, ratio, shared))
            if (med > Thresholds.MAX_MEDIAN_ERROR) {
                reasons.add("Ảnh sau sinh: người #${ti + 1} lệch tư thế so với khung xương (sai số ${"%.2f".format(med)}× chiều dài thân)")
            }
        }

        val ratios = matches.filter { it.scaleRatio > 0f }.map { it.scaleRatio }
        if (ratios.size >= 2) {
            val spread = ratios.maxOrNull()!! / ratios.minOrNull()!! - 1f
            if (spread > Thresholds.MAX_SCALE_SPREAD) {
                reasons.add("Ảnh sau sinh: tỉ lệ giữa các người lệch ${"%.0f".format(spread * 100)}% so với khung xương (ngưỡng ${"%.0f".format(Thresholds.MAX_SCALE_SPREAD * 100)}%)")
            }
        } else if (ratios.size == 1) {
            val r = ratios[0]
            if (r < Thresholds.SINGLE_SCALE_MIN || r > Thresholds.SINGLE_SCALE_MAX) {
                reasons.add("Ảnh sau sinh: kích thước người khác khung xương (tỉ lệ ${"%.2f".format(r)})")
            }
        }
        return Result(reasons.isEmpty(), reasons, matches, expected, detected.size)
    }

    /** `PoseExtractor.extractFromImage` trả OpenPose-18 với x,y chuẩn hoá và cờ visible → danh sách người. */
    fun detectedFromKeypoints(people: List<List<StoryManager.PoseKeypoint>>): List<Person> =
        people.filter { it.size >= JOINTS }.map { kps ->
            Person(List(JOINTS) { j -> Joint(kps[j].x, kps[j].y, kps[j].visible) })
        }
}
