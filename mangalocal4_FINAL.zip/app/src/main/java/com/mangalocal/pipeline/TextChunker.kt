package com.mangalocal.pipeline

/**
 * mục 70 TECHNICAL_STATUS.md — Bộ phân mảnh văn bản (Text Chunking), bước
 * đầu tiên để app TỰ ĐỘNG chọn quy trình thủ công (1 chương/lượt, người
 * dùng duyệt từng chương) hay công nghiệp (hàng loạt N chương liên tiếp,
 * không dừng duyệt tay) khi người dùng dán 1 khối văn bản lớn vào ô nhập.
 *
 * CHỈ làm việc PHÂN MẢNH — không quyết định thay người dùng chạy chế độ
 * nào (xem MainViewModel.kt.onStoryTextChanged/runIndustrialBatch — luôn
 * HỎI người dùng xác nhận qua UI, không tự ý chạy hàng loạt).
 */
object TextChunker {

    // Regex nhận diện "Chương 12", "Chương 12:", "CHƯƠNG 12 -", "Quyển 3"...
    // — khoan dung hoa/thường và dấu câu sau số, không khoan dung việc
    // thiếu số (để tránh khớp nhầm từ "chương trình", "chương hồi"...).
    private val chapterHeaderRegex = Regex(
        """(?im)^\s*(chương|quyển|hồi)\s+(\d+)\s*[:\-.]?\s*(.*)$"""
    )

    data class DetectedChapter(val number: Int, val title: String, val text: String)

    /**
     * Trả danh sách chương tách được. Nếu KHÔNG tìm thấy header nào khớp
     * (văn bản không đánh số chương, hoặc chỉ paste đúng 1 chương không
     * ghi tiêu đề) → trả về list có ĐÚNG 1 phần tử chứa toàn bộ text gốc,
     * number=0 — coi như "1 chương duy nhất", KHÔNG coi là lỗi.
     */
    fun split(rawText: String): List<DetectedChapter> {
        val matches = chapterHeaderRegex.findAll(rawText).toList()
        if (matches.isEmpty()) {
            return listOf(DetectedChapter(0, "", rawText.trim()))
        }
        val result = mutableListOf<DetectedChapter>()
        for (i in matches.indices) {
            val m = matches[i]
            val start = m.range.first
            val end = if (i + 1 < matches.size) matches[i + 1].range.first else rawText.length
            val num = m.groupValues[2].toIntOrNull() ?: (i + 1)
            val title = m.groupValues[3].trim()
            val body = rawText.substring(start, end).trim()
            if (body.isNotBlank()) result.add(DetectedChapter(num, title, body))
        }
        return if (result.isEmpty()) listOf(DetectedChapter(0, "", rawText.trim())) else result
    }

    // mục 70 — ngưỡng đề xuất chế độ công nghiệp. CỐ Ý để thấp (3) vì
    // "công nghiệp" ở bản này CHỈ khác "thủ công" ở chỗ KHÔNG dừng lại chờ
    // người dùng duyệt routing từng chương (vẫn chạy Local/Remote tự động
    // theo đúng BackendRouter đã có) — chưa phải kiến trúc hàng đợi
    // Foreground Service/WakeLock/RAM-purge đầy đủ như tài liệu mục 70 mô
    // tả (phần đó CHƯA làm, xem TECHNICAL_STATUS.md mục 70 "Vẫn CHƯA").
    const val INDUSTRIAL_SUGGEST_THRESHOLD = 3
}
