package com.mangalocal.pipeline

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import com.mangalocal.model.Panel
import java.io.File
import kotlin.math.min

/**
 * mục 234 TECHNICAL_STATUS.md — Xuất VIDEO slideshow Ken Burns (zoom/pan) từ các panel.
 * Thực hiện hạng mục "Export video slideshow Ken Burns" mà PDF bổ sung đề xuất, dùng
 * MediaCodec (H.264, đầu vào Surface) + MediaMuxer có sẵn trong Android — KHÔNG thêm
 * thư viện nào (PDF nhắc FFmpeg, nhưng thêm FFmpeg là phụ thuộc nặng, không cần).
 *
 * Cách làm: mỗi panel = secondsPerPanel giây; panel chẵn zoom vào giữa, panel lẻ trượt
 * ngang ở mức zoom cố định; 10 khung đầu mỗi panel mờ dần từ đen. Bubble được vẽ sẵn vào
 * ảnh (engine.renderPanelWithBubbles) nên hiện trong video.
 *
 * GIỚI HẠN THẬT (đọc kỹ trước khi dùng):
 * - Dấu thời gian: khung vẽ bằng Canvas lên Surface của encoder không có mốc thời gian
 *   do mình đặt, nên mã này GHI ĐÈ presentationTimeUs tuần tự (frame * 1/fps) khi ghi vào
 *   muxer. Đúng khi encoder xuất 1 mẫu/khung và KHÔNG sắp xếp lại khung (không B-frame).
 *   Một số encoder có thể khác -> video có thể sai tốc độ. CHƯA thử trên máy thật.
 * - Video vuông size x size (mặc định 1080), không có âm thanh, không có lồng tiếng (TTS)
 *   — thêm audio cần thêm track + đồng bộ, chưa làm.
 * - Chuyển cảnh giữa panel là cắt thẳng (chỉ có mờ dần từ đen ở đầu mỗi panel).
 * - Lỗi encoder (thiết bị không hỗ trợ cấu hình) -> ném IllegalStateException kèm lý do.
 * - CHƯA build-test, chưa chạy trên thiết bị.
 */
class VideoExporter(private val engine: ExportEngine) {

    fun exportKenBurns(
        panels: List<Panel>, outDir: File, fileBaseName: String,
        sizePx: Int = 1080, fps: Int = 30, secondsPerPanel: Float = 3f
    ): String {
        val items = panels.mapNotNull { p ->
            val path = p.upscaledPath ?: p.imagePath
            if (path != null && File(path).exists()) path to p.bubbles else null
        }
        if (items.isEmpty()) throw IllegalStateException("Không có panel nào có ảnh để làm video")

        val size = (sizePx / 2) * 2 // encoder H.264 yêu cầu kích thước chẵn
        val framesPerPanel = (secondsPerPanel.coerceIn(1f, 10f) * fps).toInt().coerceAtLeast(fps)
        val frameDurUs = 1_000_000L / fps
        val safeName = fileBaseName.replace(Regex("[/\\\\:*?\"<>|]"), "_").take(100).ifBlank { "chapter" }
        val out = File(outDir, "$safeName.mp4")

        val mime = MediaFormat.MIMETYPE_VIDEO_AVC
        val format = MediaFormat.createVideoFormat(mime, size, size).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 6_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var surface: android.view.Surface? = null
        var muxerStarted = false
        try {
            val enc = MediaCodec.createEncoderByType(mime)
            encoder = enc
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surf: android.view.Surface = enc.createInputSurface()
            surface = surf
            enc.start()
            val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux
            val info = MediaCodec.BufferInfo()
            var track = -1
            var ptsUs = 0L

            fun drain(endOfStream: Boolean) {
                if (endOfStream) enc.signalEndOfInputStream()
                var idleRounds = 0
                while (true) {
                    val idx = enc.dequeueOutputBuffer(info, 10_000)
                    if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!endOfStream) return
                        idleRounds++
                        if (idleRounds > 500) throw IllegalStateException("Encoder không kết thúc luồng (treo > 5s)")
                    } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = mux.addTrack(enc.outputFormat)
                        mux.start()
                        muxerStarted = true
                    } else if (idx >= 0) {
                        idleRounds = 0
                        val buf = enc.getOutputBuffer(idx)
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0 && buf != null && muxerStarted) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            info.presentationTimeUs = ptsUs
                            ptsUs += frameDurUs
                            mux.writeSampleData(track, buf, info)
                        }
                        enc.releaseOutputBuffer(idx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                }
            }

            val paint = Paint(Paint.FILTER_BITMAP_FLAG)
            val dst = Rect(0, 0, size, size)
            val fadeFrames = 10

            items.forEachIndexed { pIdx, (path, bubbles) ->
                val bmp: Bitmap = engine.renderPanelWithBubbles(path, bubbles) ?: return@forEachIndexed
                val side = min(bmp.width, bmp.height)
                val zoomInStyle = pIdx % 2 == 0
                for (f in 0 until framesPerPanel) {
                    val t = f.toFloat() / (framesPerPanel - 1).coerceAtLeast(1)
                    val zoom = if (zoomInStyle) 1.0f + 0.18f * t else 1.15f
                    val crop = (side / zoom).toInt().coerceAtLeast(2)
                    val cx: Float; val cy: Float
                    if (zoomInStyle) { cx = bmp.width / 2f; cy = bmp.height / 2f }
                    else {
                        val travel = (bmp.width - crop).coerceAtLeast(0) / 2f
                        cx = bmp.width / 2f - travel + 2f * travel * t
                        cy = bmp.height / 2f
                    }
                    val left = (cx - crop / 2f).toInt().coerceIn(0, (bmp.width - crop).coerceAtLeast(0))
                    val top = (cy - crop / 2f).toInt().coerceIn(0, (bmp.height - crop).coerceAtLeast(0))
                    val src = Rect(left, top, left + crop, top + crop)

                    val canvas = surf.lockHardwareCanvas() // minSdk 28 >= 23
                    try {
                        canvas.drawColor(Color.BLACK)
                        canvas.drawBitmap(bmp, src, dst, paint)
                        if (f < fadeFrames) {
                            val a = (255f * (1f - f.toFloat() / fadeFrames)).toInt().coerceIn(0, 255)
                            canvas.drawColor(Color.argb(a, 0, 0, 0))
                        }
                    } finally {
                        surf.unlockCanvasAndPost(canvas)
                    }
                    drain(false)
                }
                bmp.recycle()
            }
            drain(true)
        } catch (e: Exception) {
            out.delete()
            throw IllegalStateException("Xuất video lỗi: ${e.message}", e)
        } finally {
            try { if (muxerStarted) muxer?.stop() } catch (_: Exception) { }
            try { muxer?.release() } catch (_: Exception) { }
            try { encoder?.stop() } catch (_: Exception) { }
            try { encoder?.release() } catch (_: Exception) { }
            try { surface?.release() } catch (_: Exception) { }
        }
        return out.absolutePath
    }
}
