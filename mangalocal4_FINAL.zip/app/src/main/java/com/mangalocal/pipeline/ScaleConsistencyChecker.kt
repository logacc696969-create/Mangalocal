package com.mangalocal.pipeline

import kotlin.math.abs

/**
 * mục 235 TECHNICAL_STATUS.md — Kiểm tra NHẤT QUÁN TỈ LỆ VẬT THỂ giữa các panel (chuẩn
 * cộng đồng mà PDF bổ sung nêu: "cái bàn cao tới thắt lưng ở panel 2 thì không được cao
 * tới ngực ở panel 5; cờ khi lệch > 20%").
 *
 * Cách đo: với mỗi (nhóm cảnh, nhãn vật thể) lấy tỉ số
 *   ratio = chiều cao hộp vật thể (chuẩn hoá theo panel) / kích thước thân người trong cùng panel
 * rồi so giữa các panel CÙNG nhóm cảnh. Dùng tỉ số vật thể/người chứ không dùng cỡ tuyệt đối
 * vì panel cận/toàn cảnh đổi cả hai cùng lúc.
 *
 * GIỚI HẠN THẬT:
 * - Dữ liệu vào là Scene.objectBoxes (mục 223) — hộp LLM/người dùng khai, không phải hộp
 *   phát hiện từ ảnh đã sinh; chỉ kiểm được cái đã khai. Không phát hiện vật thể tự xuất hiện.
 * - Chỉ CẢNH BÁO (ghi log), không tự sửa ảnh, không chặn Quality Gate: vật ở gần camera
 *   hơn hợp lý to hơn, nên lệch > 20% chưa chắc là lỗi.
 * - Hộp khai cho GLIGEN (mục 223–225) mô tả vùng MONG MUỐN, không phải cỡ thật trong ảnh.
 * - Ngưỡng 20% lấy từ chuẩn cộng đồng, chưa hiệu chỉnh trên dự án này. CHƯA build-test.
 */
object ScaleConsistencyChecker {

    const val THRESHOLD = 0.20f
    const val MIN_TORSO = 0.05f

    data class Box(val label: String, val height: Float)
    data class Entry(val panelIndex: Int, val group: String, val torso: Float, val boxes: List<Box>)
    data class Warning(
        val label: String, val group: String, val panelIndex: Int,
        val ratio: Float, val reference: Float, val deviation: Float
    )

    fun check(entries: List<Entry>, threshold: Float = THRESHOLD): List<Warning> {
        data class Obs(val panelIndex: Int, val ratio: Float)
        val byKey = LinkedHashMap<Pair<String, String>, MutableList<Obs>>()
        for (e in entries) {
            if (e.torso < MIN_TORSO) continue
            for (b in e.boxes) {
                if (b.height <= 0f) continue
                byKey.getOrPut(e.group to b.label.trim().lowercase()) { mutableListOf() }
                    .add(Obs(e.panelIndex, b.height / e.torso))
            }
        }
        val out = mutableListOf<Warning>()
        for ((key, obs) in byKey) {
            if (obs.size < 2) continue
            val sorted = obs.map { it.ratio }.sorted()
            // 2 quan sát: không biết bên nào đúng -> lấy panel ĐẦU làm chuẩn (cũng là cách ảnh neo hoạt động).
            val ref = if (obs.size == 2) obs.first().ratio
                      else if (sorted.size % 2 == 1) sorted[sorted.size / 2]
                      else (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2f
            if (ref <= 0f) continue
            for (o in obs) {
                if (obs.size == 2 && o === obs.first()) continue
                val dev = abs(o.ratio - ref) / ref
                if (dev > threshold) out += Warning(key.second, key.first, o.panelIndex, o.ratio, ref, dev)
            }
        }
        return out.sortedBy { it.panelIndex }
    }
}
