package com.mangalocal.pipeline

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.mangalocal.model.GenerationSettings
import java.io.File

/**
 * mục 267 TECHNICAL_STATUS.md — LƯU BỀN cài đặt (`GenerationSettings`) qua các lần mở app.
 *
 * VÌ SAO CẦN: trước mục này `MainViewModel._settings` chỉ nằm trong bộ nhớ (mục 266.5 đã ghi nhận) — đóng app là mất MỌI công tắc/thanh trượt/khoá API,
 * trong khi danh sách thử trên máy thật (mục 255.3) bắt người dùng bật hàng chục cờ thử nghiệm.
 *
 * THIẾT KẾ (mỗi điểm đều có lý do, đều có test trong `tools/test_settings_store.py`):
 * 1. KHÔNG nạp thẳng `gson.fromJson(file, GenerationSettings)`. Gson chỉ áp giá trị mặc định của Kotlin khi lớp có hàm khởi tạo không tham số;
 *    cộng thêm trường mới ở bản app sau, trường đổi kiểu, enum bị đổi tên đều có thể cho ra Float = 0, hoặc enum = null trong trường không-null
 *    (NPE ở nơi dùng, rất xa chỗ nạp). Nên: dựng cây JSON của bản mặc định THẬT, rồi CHỒNG phần đã lưu lên, từng khoá một, kiểm kiểu từng giá trị.
 * 2. Khoá API / token là BÍ MẬT: không bao giờ vào `settings.json`. Mặc định KHÔNG lưu (người dùng không đồng ý thì không ghi xuống đĩa).
 *    Chỉ khi `rememberApiKeys = true` mới ghi vào tệp riêng đặt ở `noBackupFilesDir` (Android loại thư mục này khỏi Auto Backup — manifest có
 *    `allowBackup="true"`). Dạng chữ thường trong vùng riêng của app (như SharedPreferences), KHÔNG mã hoá.
 * 3. Ghi nguyên tử: ghi tệp tạm rồi đổi tên, nên mất điện/bị kill giữa chừng không để lại tệp nửa vời.
 * 4. Tệp hỏng cú pháp -> đổi tên thành `.bad` (giữ để xem lại) và dùng mặc định; KHÔNG ném ngoại lệ, KHÔNG làm app không mở được.
 * 5. Không có hiệu ứng phụ phá huỷ lúc nạp (chỉ đổi tên tệp hỏng). Việc xoá tệp bí mật khi người dùng tắt "nhớ khoá" xảy ra ở lần LƯU kế tiếp.
 *
 * Thuần Kotlin + Gson + java.io (không Android) để biên dịch và chạy trên JVM trong test.
 */
class SettingsStore(private val mainFile: File, private val secretsFile: File) {

    /** `notes`: các điều đáng báo (khoá bị bỏ qua, tệp hỏng...). `quarantined`: tệp chính hỏng cú pháp và đã bị đổi tên. */
    data class Loaded(val settings: GenerationSettings, val notes: List<String>, val quarantined: Boolean)

    companion object {
        const val MAIN_NAME = "settings.json"
        const val SECRETS_NAME = "settings_secrets.json"
        const val FORMAT_VERSION = 1
        private const val VERSION_KEY = "_v"
        private const val REMEMBER_KEY = "rememberApiKeys"

        /** Đường dẫn khoá lồng nhau của MỌI trường bí mật trong `GenerationSettings`. test_settings_store.py đối chiếu với Models.kt. */
        val SECRET_PATHS: List<List<String>> = listOf(
            listOf("externalLlm", "apiKey"),
            listOf("visionJudgeApi", "apiKey"),
            listOf("freeImage", "cfAccountId"),
            listOf("freeImage", "cfApiToken"),
            listOf("freeImage", "pollinationsKey"),
            listOf("remoteEndpoint", "authToken")
        )

        /** "20" là số nguyên; "7.0" / "1.0E-5" là số thực (cách Gson ghi Int và Float). */
        private fun isIntegralText(s: String): Boolean {
            if (s.isEmpty()) return false
            val start = if (s[0] == '-') 1 else 0
            if (start >= s.length) return false
            for (i in start until s.length) if (!s[i].isDigit()) return false
            return true
        }

        /**
         * Chồng giá trị đã lưu `saved` lên giá trị hiện có `base` (cùng vị trí trong cây). Trả null = BỎ QUA giá trị đã lưu (kiểu không khớp / null).
         * - base không có (trường nullable mặc định null, hoặc trường lạ): nhận nguyên giá trị đã lưu (Gson sẽ bỏ qua trường lạ).
         * - đối tượng KHÔNG rỗng: đệ quy từng khoá (cấu hình lồng như `externalLlm`). Đối tượng RỖNG mặc định (là Map): bản đã lưu thay hẳn — nếu
         *   trộn hợp thì mục người dùng đã xoá sẽ sống lại từ mặc định.
         * - mảng: bản đã lưu thay hẳn. Nguyên thuỷ: phải CÙNG LOẠI (bool/số/chuỗi); số nguyên mặc định không nhận số thực.
         */
        fun overlay(base: JsonElement?, saved: JsonElement): JsonElement? {
            if (saved.isJsonNull) return null
            if (base == null || base.isJsonNull) return saved.deepCopy()
            if (base.isJsonObject) {
                if (!saved.isJsonObject) return null
                val b = base.asJsonObject
                if (b.size() == 0) return saved.deepCopy()
                val out = b.deepCopy()
                for ((k, v) in saved.asJsonObject.entrySet()) {
                    val m = overlay(out.get(k), v)
                    if (m != null) out.add(k, m)
                }
                return out
            }
            if (base.isJsonArray) return if (saved.isJsonArray) saved.deepCopy() else null
            if (base.isJsonPrimitive) {
                if (!saved.isJsonPrimitive) return null
                val bp = base.asJsonPrimitive
                val sp = saved.asJsonPrimitive
                return when {
                    bp.isBoolean -> if (sp.isBoolean) sp.deepCopy() else null
                    bp.isString -> if (sp.isString) sp.deepCopy() else null
                    bp.isNumber -> when {
                        !sp.isNumber -> null
                        isIntegralText(bp.asString) && !isIntegralText(sp.asString) -> null
                        else -> sp.deepCopy()
                    }
                    else -> null
                }
            }
            return null
        }

        /**
         * Bù lại mọi khoá mà `got` thiếu so với `def` (đệ quy vào đối tượng cấu hình không rỗng). Dùng SAU khi nạp: một enum đã bị đổi tên cho Gson ra
         * null, `toJsonTree` bỏ khoá null, nên khoá biến mất — bù bằng giá trị mặc định thay vì để null trong trường không-null. Trả true nếu đã bù.
         */
        fun fillMissing(def: JsonObject, got: JsonObject): Boolean {
            var changed = false
            for ((k, dv) in def.entrySet()) {
                val gv = got.get(k)
                if (gv == null || gv.isJsonNull) {
                    got.add(k, dv.deepCopy()); changed = true
                } else if (dv.isJsonObject && dv.asJsonObject.size() > 0 && gv.isJsonObject) {
                    if (fillMissing(dv.asJsonObject, gv.asJsonObject)) changed = true
                }
            }
            return changed
        }

        private fun numEq(a: String, b: String): Boolean {
            return try {
                val x = java.math.BigDecimal(a); val y = java.math.BigDecimal(b)
                if (isIntegralText(a) && isIntegralText(b)) x.compareTo(y) == 0
                else Math.abs(x.toDouble() - y.toDouble()) <= 1e-6 * maxOf(1.0, Math.abs(x.toDouble()), Math.abs(y.toDouble()))
            } catch (e: NumberFormatException) { false }
        }

        /**
         * Tìm các lá mà Gson ĐÃ ĐỔI NGHĨA khi nạp: `merged` (giá trị ta định nạp) khác `got` (cây ghi lại từ đối tượng đã nạp). Gson KHÔNG ném lỗi khi
         * số nguyên tràn Int (99999999999 -> 1215752191 do cuộn vòng) hay cắt phần thập phân (1.5 -> 1) — chỉ có so sánh sau-nạp mới bắt được.
         * Số thực so với sai số tương đối 1e-6 (Float có ~7 chữ số) để không đánh oan số do người dùng gõ nhiều chữ số.
         */
        fun findCoerced(merged: JsonElement, got: JsonElement, path: String, out: MutableList<String>) {
            if (merged.isJsonObject && got.isJsonObject) {
                for ((k, mv) in merged.asJsonObject.entrySet()) {
                    val gv = got.asJsonObject.get(k) ?: continue
                    findCoerced(mv, gv, if (path.isEmpty()) k else "$path.$k", out)
                }
                return
            }
            if (merged.isJsonPrimitive && got.isJsonPrimitive) {
                val a = merged.asJsonPrimitive; val b = got.asJsonPrimitive
                val same = if (a.isNumber && b.isNumber) numEq(a.asString, b.asString) else a == b
                if (!same) out.add(path)
            }
        }

        /** Đưa lá ở `path` (khoá cách nhau bằng dấu chấm) về giá trị mặc định; mặc định không có thì xoá khoá. */
        fun revertPath(merged: JsonObject, def: JsonObject, path: String) {
            val keys = path.split('.')
            var m: JsonObject = merged
            var d: JsonObject? = def
            for (i in 0 until keys.size - 1) {
                m = m.get(keys[i])?.takeIf { it.isJsonObject }?.asJsonObject ?: return
                d = d?.get(keys[i])?.takeIf { it.isJsonObject }?.asJsonObject
            }
            val dv = d?.get(keys.last())
            if (dv != null) m.add(keys.last(), dv.deepCopy()) else m.remove(keys.last())
        }

        /** Rút mọi trường bí mật khỏi `tree` (sửa tại chỗ) và đặt vào đối tượng trả về theo CÙNG đường dẫn lồng nhau. */
        fun extractSecrets(tree: JsonObject): JsonObject {
            val secrets = JsonObject()
            for (path in SECRET_PATHS) {
                var parent: JsonObject = tree
                var ok = true
                for (i in 0 until path.size - 1) {
                    val c = parent.get(path[i])
                    if (c == null || !c.isJsonObject) { ok = false; break }
                    parent = c.asJsonObject
                }
                if (!ok) continue
                val last = path.last()
                val v = parent.get(last) ?: continue
                parent.remove(last)
                var dest: JsonObject = secrets
                for (i in 0 until path.size - 1) {
                    val c = dest.get(path[i])
                    dest = if (c != null && c.isJsonObject) c.asJsonObject else JsonObject().also { dest.add(path[i], it) }
                }
                dest.add(last, v)
            }
            return secrets
        }

        /** Có ít nhất một bí mật không rỗng không (tệp bí mật chỉ đáng ghi khi có gì để nhớ). */
        fun hasAnySecret(secrets: JsonObject): Boolean {
            fun walk(e: JsonElement): Boolean = when {
                e.isJsonObject -> e.asJsonObject.entrySet().any { walk(it.value) }
                e.isJsonPrimitive -> e.asJsonPrimitive.isString && e.asString.isNotEmpty()
                else -> false
            }
            return walk(secrets)
        }
    }

    private val gson: Gson = GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create()
    private var lastMainText: String? = null
    private var lastSecretsText: String? = null

    private fun parseObject(f: File): JsonObject? {
        val el = JsonParser.parseString(f.readText(Charsets.UTF_8))
        return if (el.isJsonObject) el.asJsonObject else null
    }

    private fun tryParse(tree: JsonObject): GenerationSettings? =
        try { gson.fromJson(tree, GenerationSettings::class.java) } catch (e: Exception) { null }

    private fun quarantine(f: File) {
        try {
            val bad = File(f.parentFile, f.name + ".bad")
            if (bad.exists()) bad.delete()
            if (!f.renameTo(bad)) f.delete()
        } catch (_: Exception) { /* không có gì thêm để làm: lần lưu kế tiếp sẽ ghi đè */ }
    }

    /** Nạp cài đặt đã lưu, chồng lên mặc định. KHÔNG BAO GIỜ ném ngoại lệ — trường hợp xấu nhất trả về mặc định. */
    @Synchronized
    fun load(): Loaded {
        val notes = ArrayList<String>()
        var quarantined = false
        var savedMain: JsonObject? = null
        if (mainFile.isFile) {
            try {
                savedMain = parseObject(mainFile)
                if (savedMain == null) { quarantine(mainFile); quarantined = true; notes.add("${mainFile.name}: không phải đối tượng JSON — đã đổi tên .bad, dùng mặc định") }
            } catch (e: Exception) {
                quarantine(mainFile); quarantined = true
                notes.add("${mainFile.name}: không đọc được (${e.javaClass.simpleName}) — đã đổi tên .bad, dùng mặc định")
            }
        }
        val remember = savedMain?.get(REMEMBER_KEY)?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && it.asBoolean } ?: false
        var savedSecrets: JsonObject? = null
        if (remember && secretsFile.isFile) {
            try { savedSecrets = parseObject(secretsFile) } catch (e: Exception) { notes.add("${secretsFile.name}: không đọc được — khoá API phải nhập lại") }
        }

        val defTree = gson.toJsonTree(GenerationSettings()).asJsonObject
        var merged = defTree.deepCopy()
        for (src in listOf(savedMain, savedSecrets)) {
            if (src == null) continue
            for ((k, v) in src.entrySet()) {
                if (k == VERSION_KEY) continue
                val m = overlay(merged.get(k), v)
                if (m != null) merged.add(k, m) else notes.add("bỏ qua '$k': kiểu giá trị không khớp bản hiện tại")
            }
        }

        var settings: GenerationSettings
        val first = tryParse(merged)
        if (first != null) {
            settings = first
        } else {
            // Gson ném lỗi dù giá trị cùng LOẠI (vd đối tượng lồng nhau thiếu cấu trúc): lọc từng khoá cấp cao, giữ khoá đọc được.
            val safe = defTree.deepCopy()
            for ((k, v) in merged.entrySet()) {
                val cand = safe.deepCopy(); cand.add(k, v.deepCopy())
                if (tryParse(cand) != null) safe.add(k, v.deepCopy()) else notes.add("bỏ qua '$k': giá trị không đọc được")
            }
            merged = safe
            settings = tryParse(safe) ?: GenerationSettings()
        }
        // Gson KHÔNG ném lỗi khi đổi nghĩa âm thầm (số nguyên tràn Int cuộn vòng, 1.5 -> 1): so cây ghi lại với cây đã nạp, lá nào khác thì về mặc định.
        val check0 = try { gson.toJsonTree(settings).asJsonObject } catch (e: Exception) { null }
        if (check0 != null) {
            val coerced = ArrayList<String>()
            findCoerced(merged, check0, "", coerced)
            if (coerced.isNotEmpty()) {
                for (p in coerced) { revertPath(merged, defTree, p); notes.add("bỏ qua '$p': Gson đọc ra giá trị khác (số tràn hoặc bị cắt)") }
                settings = tryParse(merged) ?: settings
            }
        }
        // Enum bị đổi tên/xoá: Gson cho null vào trường không-null. Phát hiện bằng cách ghi lại thành cây rồi bù khoá thiếu bằng mặc định.
        val check = try { gson.toJsonTree(settings).asJsonObject } catch (e: Exception) { null }
        if (check != null && fillMissing(defTree, check)) {
            val fixed = tryParse(check)
            if (fixed != null) { settings = fixed; notes.add("một số giá trị cũ (vd tên enum đã đổi) không còn hợp lệ — dùng mặc định cho phần đó") }
        }
        return Loaded(settings, notes, quarantined)
    }

    /** Ghi nhớ rằng `s` chính là cái vừa nạp, để lần lưu đầu không ghi lại y hệt (và không tạo tệp khi người dùng chưa đổi gì). */
    @Synchronized
    fun noteLoaded(s: GenerationSettings) {
        val tree = gson.toJsonTree(s).asJsonObject
        val secrets = extractSecrets(tree)
        tree.addProperty(VERSION_KEY, FORMAT_VERSION)
        lastMainText = gson.toJson(tree)
        lastSecretsText = if (s.rememberApiKeys && hasAnySecret(secrets)) gson.toJson(secrets) else null
    }

    private fun writeAtomic(target: File, text: String) {
        target.parentFile?.mkdirs()
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeText(text, Charsets.UTF_8)
        if (!tmp.renameTo(target)) {
            target.writeText(text, Charsets.UTF_8)
            tmp.delete()
        }
    }

    /**
     * Lưu `s`. Trả null nếu thành công (hoặc không có gì thay đổi), ngược lại thông báo lỗi. KHÔNG ném ngoại lệ.
     * Khoá bí mật CHỈ được ghi khi `s.rememberApiKeys`; tắt cờ này thì tệp bí mật bị XOÁ.
     */
    @Synchronized
    fun save(s: GenerationSettings): String? {
        return try {
            val tree = gson.toJsonTree(s).asJsonObject
            val secrets = extractSecrets(tree)
            tree.addProperty(VERSION_KEY, FORMAT_VERSION)
            val mainText = gson.toJson(tree)
            if (mainText != lastMainText) { writeAtomic(mainFile, mainText); lastMainText = mainText }
            if (s.rememberApiKeys && hasAnySecret(secrets)) {
                val sText = gson.toJson(secrets)
                if (sText != lastSecretsText || !secretsFile.isFile) { writeAtomic(secretsFile, sText); lastSecretsText = sText }
            } else {
                if (secretsFile.exists()) secretsFile.delete()
                lastSecretsText = null
            }
            null
        } catch (e: Exception) {
            "không lưu được cài đặt: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    /** Xoá mọi thứ đã lưu (cả tệp bí mật, tệp tạm, tệp .bad) và trả về cài đặt mặc định. */
    @Synchronized
    fun reset(): GenerationSettings {
        for (f in listOf(mainFile, secretsFile, File(mainFile.parentFile, mainFile.name + ".tmp"), File(secretsFile.parentFile, secretsFile.name + ".tmp"),
            File(mainFile.parentFile, mainFile.name + ".bad"))) {
            try { if (f.exists()) f.delete() } catch (_: Exception) { }
        }
        lastMainText = null; lastSecretsText = null
        return GenerationSettings()
    }
}
