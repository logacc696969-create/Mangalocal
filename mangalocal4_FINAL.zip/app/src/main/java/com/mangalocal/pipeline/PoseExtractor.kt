package com.mangalocal.pipeline

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.mangalocal.model.AgeBodyTable
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

// PHỤC HỒI CÓ CHỦ ĐÍCH (log build #41): AgeCategory toàn cục đã bị XOÁ khỏi
// Models.kt ở mục 31 (thay bằng BoneProportions RIÊNG từng nhân vật, chính
// xác hơn) — nhưng rescaleLegsForAge() bên dưới + PoseEditorScreen.kt vẫn
// tham chiếu type đó, không được cập nhật theo lúc refactor, khiến build
// Kotlin gãy (Unresolved reference). ĐÂY KHÔNG PHẢI phục hồi lại hệ thống
// AgeCategory toàn cục cũ — đây là enum RIÊNG, phạm vi hẹp, chỉ phục vụ
// đúng 1 thao tác "scale nhanh chuỗi chân theo ước lượng tuổi thô" trong
// Pose Editor (không lưu trữ lâu dài, không phải nguồn dữ liệu chính cho
// nhân vật — nguồn chính vẫn là BoneProportions per-character như mục 31
// đã quyết định đúng). legToHeightRatio là XẤP XỈ nhân trắc học thô, không
// phải số liệu y văn đã kiểm chứng riêng cho pipeline này.
// mục 278: thêm `years` — tuổi neo của từng nhóm, trỏ vào bảng số đo thật AgeBodyTable (dùng chung với BoneProportions.forAge). `legToHeightRatio` chỉ còn phục vụ
// rescaleLegsForAge() cũ (không còn nút nào gọi); màn Tư thế dùng rescaleBodyForAge → AgeBodyScaler.
enum class AgeCategory(val label: String, val legToHeightRatio: Float, val years: Int) {
    CHILD("Trẻ em", 0.42f, AgeBodyTable.CHILD_AGE),
    TEEN("Thiếu niên", 0.47f, AgeBodyTable.TEEN_AGE),
    ADULT("Người lớn", 0.50f, AgeBodyTable.ADULT_AGE)
}

/**
 * Trích khung xương NGAY TRÊN ĐIỆN THOẠI — dùng YOLOv8-pose qua MNN (mục 19
 * TECHNICAL_STATUS.md), THAY cho MediaPipe Pose Landmarker trước đây.
 *
 * LÝ DO ĐỔI: MediaPipe Pose Landmarker vốn thiết kế cho 1 người/khung — đã
 * xác nhận qua tài liệu chính thức + báo cáo lỗi GitHub thật (issue #5806:
 * "ảo giác" khớp sai khi bị occlusion) rằng nó KHÔNG đáng tin cho đúng cảnh
 * MangaLocal cần nhất: nhiều người ôm/vật lộn/quần nhau. YOLOv8-pose là
 * kiến trúc single-stage (không tách "detect người rồi crop-riêng-từng-
 * người" như MediaPipe), phù hợp hơn cho occlusion nhiều người. Việc này
 * KHÔNG tự động "sửa hết" — vẫn cần 3 cơ chế cảnh báo dưới đây để biết khi
 * nào phải sửa tay, xem PoseValidation.
 *
 * VỀ VIỆC ĐỔI PHIÊN BẢN YOLO SAU NÀY (đã tra cứu xác nhận, không đoán):
 * YOLOv8/YOLO11/YOLO26 (cùng hãng Ultralytics) ĐỀU có biến thể "-pose" cùng
 * quy ước output (COCO-17 keypoint, cùng layout tensor 4+1+17*3) — đổi
 * model chỉ cần sửa 1 dòng trong tools/export_yolo_pose.py (tên model), tên
 * file .mnn giữ nguyên "yolov8_pose.mnn" (đặt tên theo VAI TRÒ không theo
 * đúng version, để không phải sửa code Kotlin/C++ khi đổi bản). RIÊNG
 * YOLOv9 KHÔNG có biến thể "-pose" chính thức (chỉ detect/segment) — không
 * phải lựa chọn khả dụng, không phải tôi bỏ qua nó.
 *
 * Model cần: "yolov8_pose.mnn" trong thư mục StoryManager.yoloDir (tự tải/
 * convert 1 lần qua prepare_models.yml hoặc tools/export_yolo_pose.py).
 */
class PoseExtractor(private val context: Context, private val storyManager: StoryManager) {

    private val ctx: Long = try {
        NativeBridge.yoloPoseInit(storyManager.yoloDir.absolutePath)
    } catch (e: Exception) { 0L }

    fun isReady() = ctx != 0L

    private val coco17ToOpenPose18 = mapOf(
        0 to 0,
        6 to 2, 8 to 3, 10 to 4,
        5 to 5, 7 to 6, 9 to 7,
        12 to 8, 14 to 9, 16 to 10,
        11 to 11, 13 to 12, 15 to 13,
        2 to 14, 1 to 15,
        4 to 16, 3 to 17
    )

    private val boneConnections = listOf(
        1 to 2, 2 to 3, 3 to 4,
        1 to 5, 5 to 6, 6 to 7,
        1 to 8, 8 to 9, 9 to 10,
        1 to 11, 11 to 12, 12 to 13
    )

    data class PersonRaw(val box: FloatArray, val coco17: List<StoryManager.PoseKeypoint>)

    private fun bytesToTempFile(bitmap: Bitmap): File {
        val f = File.createTempFile("posefx_", ".png", context.cacheDir)
        FileOutputStream(f).use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
        return f
    }

    private fun detectRaw(bitmap: Bitmap, confThresh: Float = 0.35f, iouThresh: Float = 0.3f): List<PersonRaw> {
        if (!isReady()) return emptyList()
        val tmp = bytesToTempFile(bitmap)
        try {
            val flat = NativeBridge.yoloPoseDetect(ctx, tmp.absolutePath, confThresh, iouThresh)
            val stride = 5 + 17 * 3
            if (flat.isEmpty() || flat.size % stride != 0) return emptyList()
            val people = mutableListOf<PersonRaw>()
            var i = 0
            while (i < flat.size) {
                val box = floatArrayOf(flat[i], flat[i+1], flat[i+2], flat[i+3], flat[i+4])
                val kps = (0 until 17).map { k ->
                    val base = i + 5 + k * 3
                    StoryManager.PoseKeypoint(flat[base], flat[base+1], 0f,
                        visible = flat[base+2] >= 0.5f, confidence = flat[base+2])
                }
                people.add(PersonRaw(box, kps))
                i += stride
            }
            return people
        } finally {
            tmp.delete()
        }
    }

    private fun coco17ToOpenPose18(coco17: List<StoryManager.PoseKeypoint>): MutableList<StoryManager.PoseKeypoint> {
        val out = MutableList(18) { StoryManager.PoseKeypoint() }
        coco17ToOpenPose18.forEach { (srcIdx, dstIdx) -> out[dstIdx] = coco17[srcIdx] }
        if (out[2].visible && out[5].visible) {
            out[1] = StoryManager.PoseKeypoint(
                (out[2].x + out[5].x) / 2, (out[2].y + out[5].y) / 2, 0f,
                visible = true, confidence = minOf(out[2].confidence, out[5].confidence)
            )
        }
        return out
    }

    fun validatePerson(person: List<StoryManager.PoseKeypoint>): PoseValidation {
        val reasons = mutableListOf<String>()

        val importantIdx = listOf(3, 4, 6, 7, 9, 10, 12, 13)
        val lowConf = importantIdx.filter { person.getOrNull(it)?.let { p -> p.visible && p.confidence < 0.5f } == true }
        if (lowConf.isNotEmpty()) reasons += "Điểm tự tin thấp ở ${lowConf.size} khớp (có thể do che khuất) — kiểm tra kỹ vùng tay/chân"

        val visibleCount = person.filterIndexed { idx, p -> idx != 1 && p.visible }.size
        if (visibleCount < 17) reasons += "Chỉ nhận diện $visibleCount/17 khớp — nghi ngờ bị 'nuốt mất' 1 tay/chân, cần tự vẽ thêm"

        val refShoulder = person.getOrNull(2); val refHip = person.getOrNull(8)
        val refUnit = if (refShoulder?.visible == true && refHip?.visible == true) {
            val dx = refShoulder.x - refHip.x; val dy = refShoulder.y - refHip.y
            sqrt(dx*dx + dy*dy).takeIf { it > 1e-4f }
        } else null
        if (refUnit != null) {
            var anomalyCount = 0
            boneConnections.forEach { (a, b) ->
                val pa = person.getOrNull(a); val pb = person.getOrNull(b)
                if (pa?.visible == true && pb?.visible == true) {
                    val dx = pa.x - pb.x; val dy = pa.y - pb.y
                    val dist = sqrt(dx*dx + dy*dy)
                    if (dist > refUnit * 3.0f) anomalyCount++
                }
            }
            if (anomalyCount > 0) reasons += "Cấu trúc xương dị thường ở $anomalyCount điểm nối — khoảng cách khớp vượt xa tỷ lệ cơ thể bình thường"
        }

        return PoseValidation(reasons.isNotEmpty(), reasons)
    }

    data class PoseValidation(val needsReview: Boolean, val reasons: List<String>)

    private fun resultToCoco18People(raw: List<PersonRaw>): List<MutableList<StoryManager.PoseKeypoint>>? {
        if (raw.isEmpty()) return null
        val sorted = raw.sortedByDescending { (it.box[1] + it.box[3]) / 2 }
        return sorted.map { coco17ToOpenPose18(it.coco17) }.toMutableList()
    }

    fun estimateAngle(person: List<StoryManager.PoseKeypoint>): String {
        val nose = person.getOrNull(0)
        val rightSh = person.getOrNull(2); val leftSh = person.getOrNull(5)
        if (nose == null || rightSh == null || leftSh == null ||
            !nose.visible || !rightSh.visible || !leftSh.visible) return "unknown"
        val midX = (rightSh.x + leftSh.x) / 2
        val shoulderWidth = abs(rightSh.x - leftSh.x) + 1e-6f
        val ratio = (nose.x - midX) / shoulderWidth
        return when {
            abs(ratio) < 0.15f -> "front"
            ratio > 0 -> "side_left"
            else -> "side_right"
        }
    }

    // mục 280 TECHNICAL_STATUS.md — ĐỘ SÂU 3D THẬT bằng BlazePose (thay cho đoán độ sâu của Pose3D, mục 279). Chỉ có tác dụng khi có blazepose_lite.mnn / blazepose_full.mnn trong thư mục
    // model; thiếu thì extractFromImage trả y như trước (z = 0). x, y GIỮ NGUYÊN (do YOLO); chỉ thêm z. Tắt được: liftDepth = false.
    // mục 281: model đóng trong APK (assets/blazepose/) được chép ra yoloDir ở lần đầu nếu chưa có (prepareBundledModels, gọi trên luồng nền).
    private val blazePose by lazy {
        BlazePoseEstimator(storyManager.yoloDir) { name -> try { context.assets.open("blazepose/$name") } catch (e: Exception) { null } }
    }
    /** Chép model BlazePose từ APK nếu thư mục chưa có. LUỒNG NỀN. Trả số tệp đã chép (0 = đã có sẵn / không chép được). */
    fun prepareBundledModels(): Int = blazePose.copyBundledIfMissing()
    @Volatile var liftDepth: Boolean = true
    /** Số người ở lần trích GẦN NHẤT đã được thêm z thật (UI dùng để báo kết quả). */
    @Volatile var lastDepthLifted: Int = 0
    fun depthLiftReady(): Boolean = blazePose.isReady()

    fun extractFromImage(bitmap: Bitmap): List<MutableList<StoryManager.PoseKeypoint>>? {
        val raw = detectRaw(bitmap)
        val people = resultToCoco18People(raw) ?: return null
        return withRealDepth(bitmap, raw.sortedByDescending { (it.box[1] + it.box[3]) / 2 }, people)   // cùng thứ tự với resultToCoco18People
    }

    private fun withRealDepth(
        bitmap: Bitmap, sortedRaw: List<PersonRaw>, people: List<MutableList<StoryManager.PoseKeypoint>>
    ): List<MutableList<StoryManager.PoseKeypoint>> {
        lastDepthLifted = 0
        if (liftDepth && !blazePose.isReady()) blazePose.copyBundledIfMissing()   // đang ở luồng nền của quá trình trích; chỉ thử một lần
        if (!liftDepth || sortedRaw.size != people.size || !blazePose.isReady()) return people
        val w = bitmap.width; val h = bitmap.height
        if (w.toLong() * h > 12_000_000L) return people        // ảnh quá lớn: không nạp cả ảnh vào IntArray (chưa thu nhỏ)
        val px = IntArray(w * h)
        bitmap.getPixels(px, 0, w, 0, 0, w, h)
        return people.mapIndexed { i, p ->
            val d = blazePose.lift(px, w, h, p, sortedRaw[i].box)
            if (d != null) { lastDepthLifted++; d } else p
        }
    }

    data class ExtractedVariant(
        val angle: String, val people: List<MutableList<StoryManager.PoseKeypoint>>,
        val needsReview: Boolean = false, val reviewReasons: List<String> = emptyList()
    )

    fun extractFromVideo(
        context: Context, videoUri: Uri, fpsSample: Float = 2f,
        dedupeThreshold: Float = 0.03f, maxVariants: Int = 60
    ): List<ExtractedVariant> {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(context, videoUri)
        val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        val frameIntervalUs = (1_000_000L / fpsSample).toLong()

        val results = mutableListOf<ExtractedVariant>()
        var lastPeople: List<StoryManager.PoseKeypoint>? = null
        var t = 0L
        while (t < durationMs * 1000 && results.size < maxVariants) {
            val frame = retriever.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            if (frame != null) {
                val people = extractFromImage(frame)
                if (!people.isNullOrEmpty()) {
                    val main = people[0]
                    val isDuplicate = lastPeople?.let { prev -> poseDistance(prev, main) < dedupeThreshold } ?: false
                    if (!isDuplicate) {
                        val angle = estimateAngle(main)
                        val validations = people.map { validatePerson(it) }
                        val anyNeedsReview = validations.any { it.needsReview }
                        val allReasons = validations.flatMapIndexed { idx, v ->
                            v.reasons.map { r -> if (people.size > 1) "Người ${idx+1}: $r" else r }
                        }
                        results.add(ExtractedVariant(angle, people, anyNeedsReview, allReasons))
                        lastPeople = main
                    }
                }
            }
            t += frameIntervalUs
        }
        retriever.release()
        return results
    }

    private fun poseDistance(a: List<StoryManager.PoseKeypoint>, b: List<StoryManager.PoseKeypoint>): Float {
        var sum = 0f; var n = 0
        for (i in a.indices) {
            if (i >= b.size) continue
            if (a[i].visible && b[i].visible) {
                val dx = a[i].x - b[i].x; val dy = a[i].y - b[i].y
                sum += sqrt(dx * dx + dy * dy); n++
            }
        }
        return if (n > 0) sum / n else Float.MAX_VALUE
    }

    fun close() { if (ctx != 0L) NativeBridge.yoloPoseFree(ctx); blazePose.close() }

    // ── Scale khung xương theo tỷ lệ tuổi (mục 30 TECHNICAL_STATUS.md) ──
    // User phát hiện: khung xương trích từ người thật có tỷ lệ CHÂN/THÂN
    // khác hẳn theo tuổi (trẻ em chân ngắn hơn theo tỷ lệ). CHỈ scale được
    // chuỗi CHÂN (hip-knee-ankle) một cách đáng tin — OpenPose-18 KHÔNG có
    // điểm "đỉnh đầu" (chỉ có mũi/mắt/tai ở mức mặt), nên KHÔNG tính chính
    // xác được tỷ lệ đầu:thân thật — đây là GIỚI HẠN THẬT của bộ 18 khớp,
    // không phải tôi bỏ sót. Không tự động đoán "người nào cần scale" —
    // user tự chọn người trong PoseEditorScreen (đã có UI đa người sẵn).
    fun rescaleLegsForAge(
        person: MutableList<StoryManager.PoseKeypoint>, from: AgeCategory, to: AgeCategory
    ): MutableList<StoryManager.PoseKeypoint> {
        if (from == to) return person
        val neck = person.getOrNull(1); val rHip = person.getOrNull(8); val lHip = person.getOrNull(11)
        if (neck?.visible != true || rHip?.visible != true || lHip?.visible != true) return person // thiếu điểm tham chiếu, không scale mù

        val hipCenterX = (rHip.x + lHip.x) / 2f; val hipCenterY = (rHip.y + lHip.y) / 2f
        // Xấp xỉ: tỷ lệ chân/thân thay đổi theo legToHeightRatio, dùng làm
        // hệ số scale TƯƠNG ĐỐI cho chuỗi chân quanh điểm hông — XẤP XỈ,
        // không phải phép đo nhân trắc học chính xác tuyệt đối.
        val scaleFactor = to.legToHeightRatio / from.legToHeightRatio
        val out = person.toMutableList()
        // Scale từng điểm chân quanh gốc hông tương ứng bên (phải: 8-9-10, trái: 11-12-13)
        fun scaleChain(hipIdx: Int, kneeIdx: Int, ankleIdx: Int) {
            val hip = out[hipIdx]
            listOf(kneeIdx, ankleIdx).forEach { idx ->
                val p = out[idx]
                if (p.visible) {
                    val newX = hip.x + (p.x - hip.x) * scaleFactor
                    val newY = hip.y + (p.y - hip.y) * scaleFactor
                    out[idx] = p.copy(x = newX, y = newY)
                }
            }
        }
        scaleChain(8, 9, 10); scaleChain(11, 12, 13)
        return out
    }

    /**
     * mục 277/278 — đổi tỷ lệ CẢ CƠ THỂ từ nhóm tuổi [from] sang [to], TỪNG ĐOẠN riêng (đầu, thân, vai/hông, cánh tay trên, cẳng tay, đùi, cẳng chân) theo bảng số đo thật
     * AgeBodyTable (hình học: AgeBodyScaler). Giữ tâm hông và tổng độ dài các đoạn đứng; A→B→A về đúng hình cũ. Trả đúng danh sách cũ (cùng đối tượng) khi không áp dụng được.
     */
    fun rescaleBodyForAge(
        person: MutableList<StoryManager.PoseKeypoint>, from: AgeCategory, to: AgeCategory
    ): MutableList<StoryManager.PoseKeypoint> {
        if (from == to) return person
        return AgeBodyScaler.rescale(person, AgeBodyTable.factors(from.years, to.years))
    }
}
