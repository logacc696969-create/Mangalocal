package com.mangalocal.pipeline

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * mục 261 TECHNICAL_STATUS.md — BẢN ĐỒ CHE KHUẤT / TIẾP XÚC (contact map) dựng từ khung xương 2D, bản "tự viết" cho đồ thị MNN cố định.
 *
 * Bối cảnh: PDF bổ sung đề xuất "sinh contact map từ skeleton làm ControlNet input mới". Mục 260.5 kết luận KHÔNG có ControlNet contact map
 * 2D dùng ngay cho SD1.5. Đọc TOÀN VĂN PersonaCraft (arXiv 2411.18068) cho thấy phần chạy được KHÔNG cần huấn luyện là OccCFG (công thức 4):
 * tăng CFG riêng ở vùng che khuất M_occ. Bài lấy M_occ bằng cách đếm giao điểm mặt lưới SMPL-X 3D (> 2 mặt = bị che). Ở đây không có lưới 3D,
 * nên xấp xỉ bằng 2D: mỗi người = hợp các "capsule" bám theo xương (thân, tay, chân, đầu) có độ dày tỉ lệ kích thước thân; M_occ = nơi
 * ≥ 2 NGƯỜI KHÁC NHAU cùng phủ (kể cả sát nhau trong một biên nhỏ — cảnh ôm/vật nhau chạm nhau dọc đường biên).
 *
 * Đầu ra dùng cho 2 việc: (1) OccCFG native (`NativeBridge.setOccCfg`, xem sd_engine/OccCfg.hpp); (2) mask LIÊN TỤC theo cường độ tiếp xúc
 * cho Differential Diffusion (`gradedWeight`).
 *
 * Hàm THUẦN: không đọc file, không native, không Android — chạy được bằng kotlinc (tools/test_contact_map.py).
 * Bố cục khung xương = struct Keypoint native / `MangaPipeline.resolveSkeletonData()`: 18 khớp × 4 float (x, y, z, visible), x/y chuẩn hoá
 * 0..1, OpenPose-18 (0 mũi, 1 cổ, 2/5 vai, 3/6 khuỷu, 4/7 cổ tay, 8/11 hông, 9/12 gối, 10/13 mắt cá, 14/15 mắt, 16/17 tai).
 *
 * GIỚI HẠN THẬT: (a) hình học 2D, không có chiều sâu — "hai người cùng phủ" gồm cả trường hợp một người đứng TRƯỚC người kia không chạm;
 * (b) capsule là xấp xỉ thô của cơ thể (không có quần áo/tóc/vóc người); (c) độ dày/biên là hằng số kinh nghiệm CHƯA hiệu chỉnh trên ảnh thật;
 * (d) chưa thử trên ảnh thật nên chưa biết OccCFG làm ảnh tốt hơn hay chỉ tăng bão hoà — vì vậy mặc định TẮT.
 */
object ContactMap {

    const val JOINTS = 18
    const val FLOATS_PER_PERSON = JOINTS * 4

    /** Hằng số hình học (đơn vị: nhân với kích thước thân của chính người đó). */
    object Params {
        const val VISIBLE_FLAG = 0.5f
        const val MIN_SIZE_PX = 8f            // thân nhỏ hơn mức này (pixel ảnh gốc) coi như không đủ dữ liệu
        const val R_UPPER_ARM = 0.14f
        const val R_FOREARM = 0.11f
        const val R_THIGH = 0.17f
        const val R_SHIN = 0.13f
        const val R_NECK = 0.10f
        const val R_HEAD = 0.34f
        const val TORSO_PAD = 0.12f           // nới thân (bốn khớp vai/hông tạo hình tứ giác)
        const val CONTACT_MARGIN = 0.10f      // vùng "sát nhau" ngoài biên capsule còn tính là tiếp xúc (× kích thước thân)
        const val MIN_PEAK = 0.25f            // đỉnh bản đồ nhỏ hơn mức này => coi như không có tiếp xúc
        const val REGION_MARGIN = 0.35f       // mục 261.11: biên mềm của mask vùng từng người (× kích thước thân) — rộng hơn biên tiếp xúc để trộn LoRA mượt
        const val MIN_REGION_PEAK = 0.5f      // mask của một người có đỉnh nhỏ hơn mức này (ngoài khung/quá nhỏ) => không dựng được mask vùng
    }

    class Result(val map: FloatArray, val w: Int, val h: Int, val peak: Float, val area: Float) {
        /** Cường độ trong [0,1] tại điểm (x, y) chuẩn hoá [0,1] của ảnh gốc — nội suy song tuyến. */
        fun intensityAt(nx: Float, ny: Float): Float {
            if (w <= 0 || h <= 0 || map.size != w * h) return 0f
            val fx = (nx * w - 0.5f).coerceIn(0f, (w - 1).toFloat())
            val fy = (ny * h - 0.5f).coerceIn(0f, (h - 1).toFloat())
            val x0 = fx.toInt(); val y0 = fy.toInt()
            val x1 = min(x0 + 1, w - 1); val y1 = min(y0 + 1, h - 1)
            val tx = fx - x0; val ty = fy - y0
            val a = map[y0 * w + x0]; val b = map[y0 * w + x1]
            val c = map[y1 * w + x0]; val d = map[y1 * w + x1]
            val top = a + (b - a) * tx; val bot = c + (d - c) * tx
            return (top + (bot - top) * ty).coerceIn(0f, 1f)
        }
    }

    private class Person(
        val links: List<FloatArray>,   // mỗi link: ax, ay, bx, by, r (pixel)
        val quad: FloatArray?,         // 8 số: 4 đỉnh thân (pixel), null nếu thiếu khớp
        val head: FloatArray?,         // cx, cy, r (pixel)
        val pad: Float                 // nới thân (pixel)
    )

    // Cặp khớp tạo capsule: (khớp a, khớp b, hệ số bán kính)
    private val LINKS = listOf(
        Triple(2, 3, Params.R_UPPER_ARM), Triple(3, 4, Params.R_FOREARM),
        Triple(5, 6, Params.R_UPPER_ARM), Triple(6, 7, Params.R_FOREARM),
        Triple(8, 9, Params.R_THIGH), Triple(9, 10, Params.R_SHIN),
        Triple(11, 12, Params.R_THIGH), Triple(12, 13, Params.R_SHIN),
        Triple(1, 0, Params.R_NECK), Triple(1, 2, Params.R_NECK), Triple(1, 5, Params.R_NECK)
    )

    private fun buildPerson(data: FloatArray, idx: Int, imgW: Int, imgH: Int): Person? {
        val base = idx * FLOATS_PER_PERSON
        if (idx < 0 || base + FLOATS_PER_PERSON > data.size) return null
        fun vis(j: Int) = data[base + j * 4 + 3] > Params.VISIBLE_FLAG &&
            data[base + j * 4].isFinite() && data[base + j * 4 + 1].isFinite()
        fun px(j: Int) = data[base + j * 4] * imgW
        fun py(j: Int) = data[base + j * 4 + 1] * imgH
        // Kích thước thân (pixel) = trung bình (bề rộng vai, chiều cao thân) — cùng cách ContactDetector đo; cần đủ 4 khớp thân.
        val torsoOk = vis(2) && vis(5) && vis(8) && vis(11)
        if (!torsoOk) return null
        val shoulderW = sqrt((px(2) - px(5)) * (px(2) - px(5)) + (py(2) - py(5)) * (py(2) - py(5)))
        val torsoH = abs((py(8) + py(11)) / 2f - (py(2) + py(5)) / 2f)
        val size = (shoulderW + torsoH) / 2f
        if (size < Params.MIN_SIZE_PX) return null

        val links = ArrayList<FloatArray>()
        for ((a, b, rk) in LINKS) {
            if (vis(a) && vis(b)) links.add(floatArrayOf(px(a), py(a), px(b), py(b), rk * size))
        }
        val quad = floatArrayOf(px(2), py(2), px(5), py(5), px(11), py(11), px(8), py(8))
        val headIdx = listOf(0, 14, 15, 16, 17).filter { vis(it) }
        val head = if (headIdx.isNotEmpty()) {
            floatArrayOf(headIdx.map { px(it) }.average().toFloat(), headIdx.map { py(it) }.average().toFloat(), Params.R_HEAD * size)
        } else null
        return Person(links, quad, head, Params.TORSO_PAD * size)
    }

    private fun sizeOf(data: FloatArray, idx: Int, imgW: Int, imgH: Int): Float {
        val base = idx * FLOATS_PER_PERSON
        fun px(j: Int) = data[base + j * 4] * imgW
        fun py(j: Int) = data[base + j * 4 + 1] * imgH
        val shoulderW = sqrt((px(2) - px(5)) * (px(2) - px(5)) + (py(2) - py(5)) * (py(2) - py(5)))
        val torsoH = abs((py(8) + py(11)) / 2f - (py(2) + py(5)) / 2f)
        return (shoulderW + torsoH) / 2f
    }

    // khoảng cách từ điểm tới đoạn thẳng
    private fun distSeg(x: Float, y: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax; val dy = by - ay
        val len2 = dx * dx + dy * dy
        val t = if (len2 <= 1e-9f) 0f else (((x - ax) * dx + (y - ay) * dy) / len2).coerceIn(0f, 1f)
        val cx = ax + t * dx; val cy = ay + t * dy
        val ex = x - cx; val ey = y - cy
        return sqrt(ex * ex + ey * ey)
    }

    // khoảng cách có dấu tới tứ giác lồi/lõm (dùng chẵn-lẻ để biết trong/ngoài): âm = trong
    private fun signedDistQuad(x: Float, y: Float, q: FloatArray): Float {
        var inside = false
        var minD = Float.MAX_VALUE
        var j = 3
        for (i in 0 until 4) {
            val xi = q[i * 2]; val yi = q[i * 2 + 1]; val xj = q[j * 2]; val yj = q[j * 2 + 1]
            if (((yi > y) != (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi + 1e-12f) + xi)) inside = !inside
            minD = min(minD, distSeg(x, y, xi, yi, xj, yj))
            j = i
        }
        return if (inside) -minD else minD
    }

    /** Khoảng cách có dấu tới HỢP hình của 1 người (âm = trong thân). */
    private fun signedDist(p: Person, x: Float, y: Float): Float {
        var best = Float.MAX_VALUE
        for (l in p.links) best = min(best, distSeg(x, y, l[0], l[1], l[2], l[3]) - l[4])
        p.quad?.let { best = min(best, signedDistQuad(x, y, it) - p.pad) }
        p.head?.let { h ->
            val dx = x - h[0]; val dy = y - h[1]
            best = min(best, sqrt(dx * dx + dy * dy) - h[2])
        }
        return best
    }

    /**
     * Dựng bản đồ (mapW × mapH). Với mỗi người, độ phủ c_p(x) = 1 trong thân, giảm tuyến tính về 0 trong biên CONTACT_MARGIN ngoài thân;
     * bản đồ M(x) = max trên mọi cặp người (p<q) của c_p(x) * c_q(x), rồi làm mượt 3x3. Trả null nếu < 2 người dùng được hoặc không có tiếp xúc
     * (đỉnh < MIN_PEAK) — khi đó KHÔNG nên bật OccCFG (không có gì để tăng).
     *
     * @param skeletons   mảng khung xương nhiều người (xem mô tả bố cục ở đầu file)
     * @param numPersons  số người cần xét (không vượt quá số người có trong mảng)
     * @param imgW,imgH   kích thước ảnh gốc (pixel) — dùng để giữ capsule TRÒN trên ảnh không vuông
     */
    fun build(skeletons: FloatArray, numPersons: Int, imgW: Int, imgH: Int, mapW: Int, mapH: Int): Result? {
        if (imgW <= 0 || imgH <= 0 || mapW <= 0 || mapH <= 0) return null
        if (mapW.toLong() * mapH > 4096L * 4096L) return null
        val n = min(numPersons, skeletons.size / FLOATS_PER_PERSON)
        if (n < 2) return null
        val persons = ArrayList<Person>()
        val sizes = ArrayList<Float>()
        for (i in 0 until n) {
            val p = buildPerson(skeletons, i, imgW, imgH) ?: continue
            persons.add(p); sizes.add(sizeOf(skeletons, i, imgW, imgH))
        }
        if (persons.size < 2) return null
        val margins = sizes.map { it * Params.CONTACT_MARGIN }

        val raw = FloatArray(mapW * mapH)
        val cov = FloatArray(persons.size)
        for (my in 0 until mapH) {
            val y = (my + 0.5f) / mapH * imgH
            for (mx in 0 until mapW) {
                val x = (mx + 0.5f) / mapW * imgW
                for (i in persons.indices) {
                    val sd = signedDist(persons[i], x, y)
                    cov[i] = if (sd <= 0f) 1f else max(0f, 1f - sd / max(margins[i], 1e-3f))
                }
                var m = 0f
                for (i in 0 until persons.size) {
                    if (cov[i] <= 0f) continue
                    for (j in i + 1 until persons.size) {
                        val v = cov[i] * cov[j]
                        if (v > m) m = v
                    }
                }
                raw[my * mapW + mx] = m
            }
        }
        // làm mượt 3x3 (hộp) để biên không răng cưa; giữ giá trị trong [0,1]
        val out = FloatArray(raw.size)
        var peak = 0f; var area = 0f
        for (y in 0 until mapH) for (x in 0 until mapW) {
            var s = 0f; var c = 0
            for (dy in -1..1) for (dx in -1..1) {
                val yy = y + dy; val xx = x + dx
                if (yy in 0 until mapH && xx in 0 until mapW) { s += raw[yy * mapW + xx]; c++ }
            }
            val v = (s / c).coerceIn(0f, 1f)
            out[y * mapW + x] = v
            if (v > peak) peak = v
            area += v
        }
        if (peak < Params.MIN_PEAK) return null
        return Result(out, mapW, mapH, peak, area / out.size)
    }

    /** mục 261.11 — k mask vùng liên tiếp (k*w*h, [0,1]) theo THỨ TỰ người trong khung xương. */
    class RegionMasks(val data: FloatArray, val k: Int, val w: Int, val h: Int)

    /**
     * mục 261.11 — độ phủ MỀM của TỪNG người (mapW × mapH, [0,1]) theo thứ tự khung xương: 1 trong thân, giảm tuyến tính về 0 trong biên
     * `marginFactor × kích thước thân` ngoài thân. Phần tử null = người đó thiếu khớp thân (không dựng được). Cùng định nghĩa hình học với `build`.
     */
    fun personCoverage(skeletons: FloatArray, numPersons: Int, imgW: Int, imgH: Int, mapW: Int, mapH: Int, marginFactor: Float): List<FloatArray?> {
        if (imgW <= 0 || imgH <= 0 || mapW <= 0 || mapH <= 0 || mapW.toLong() * mapH > 4096L * 4096L) return emptyList()
        val n = min(numPersons, skeletons.size / FLOATS_PER_PERSON)
        val mf = if (marginFactor.isFinite() && marginFactor > 0f) marginFactor else Params.REGION_MARGIN
        val out = ArrayList<FloatArray?>()
        for (i in 0 until n) {
            val person = buildPerson(skeletons, i, imgW, imgH)
            if (person == null) { out.add(null); continue }
            val margin = max(sizeOf(skeletons, i, imgW, imgH) * mf, 1e-3f)
            val cov = FloatArray(mapW * mapH)
            for (my in 0 until mapH) {
                val y = (my + 0.5f) / mapH * imgH
                for (mx in 0 until mapW) {
                    val x = (mx + 0.5f) / mapW * imgW
                    val sd = signedDist(person, x, y)
                    cov[my * mapW + mx] = if (sd <= 0f) 1f else max(0f, 1f - sd / margin)
                }
            }
            out.add(cov)
        }
        return out
    }

    /**
     * mục 261.11 — mask vùng cho Regional Composite: ĐÚNG `numPersons` người đều dựng được (đủ khớp thân, đỉnh >= MIN_REGION_PEAK), mask thứ i = người i.
     * Thiếu một người -> null (không đoán: gán sai LoRA cho sai người tệ hơn không trộn theo vùng).
     */
    fun regionMasks(skeletons: FloatArray, numPersons: Int, imgW: Int, imgH: Int, mapW: Int, mapH: Int,
                    marginFactor: Float = Params.REGION_MARGIN): RegionMasks? {
        if (numPersons < 2) return null
        val covs = personCoverage(skeletons, numPersons, imgW, imgH, mapW, mapH, marginFactor)
        if (covs.size != numPersons) return null
        val data = FloatArray(numPersons * mapW * mapH)
        for ((i, c) in covs.withIndex()) {
            if (c == null) return null
            if ((c.maxOrNull() ?: 0f) < Params.MIN_REGION_PEAK) return null
            System.arraycopy(c, 0, data, i * mapW * mapH, c.size)
        }
        return RegionMasks(data, numPersons, mapW, mapH)
    }

    /** Kích thước latent tương ứng ảnh (cạnh/8, tối thiểu 1) — khớp `sample_width/sample_height` native. */
    fun latentSize(imgW: Int, imgH: Int): Pair<Int, Int> = Pair(max(1, imgW / 8), max(1, imgH / 8))

    /**
     * Trọng số mask LIÊN TỤC cho Differential Diffusion: `floor` ở nơi không có tiếp xúc (chỉ chỉnh chi tiết, giữ cấu trúc), tăng tới 1 ở lõi tiếp
     * xúc (vẽ lại đầy đủ). floor kẹp [0,1]; intensity kẹp [0,1]. Đơn điệu theo cường độ.
     */
    fun gradedWeight(intensity: Float, floor: Float): Float {
        val f = if (floor.isFinite()) floor.coerceIn(0f, 1f) else 0.5f
        val i = if (intensity.isFinite()) intensity.coerceIn(0f, 1f) else 0f
        return f + (1f - f) * i
    }
}
