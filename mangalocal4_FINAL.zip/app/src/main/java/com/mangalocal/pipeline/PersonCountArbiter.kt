package com.mangalocal.pipeline

/**
 * mục 262 TECHNICAL_STATUS.md — PHÂN XỬ số người: bộ phát hiện (YOLOv8-pose) làm tín hiệu CHÍNH, VLM chỉ kiểm chéo (việc "VLM đếm người" treo từ 259.5).
 *
 * Căn cứ (tra cứu 261.15-D, [WEB], chưa đọc toàn văn): đếm là điểm yếu có hệ thống của VLM; đưa kết quả bộ phát hiện vào VLM tăng độ chính xác đếm.
 * Vấn đề hiện tại [MÃ]: `VisionJudge.reasons` THÊM lý do "VLM đếm c người" và `verifyOutputPose` đặt `passed = false` -> một câu đếm sai của VLM có thể
 * kéo cổng chất lượng sinh lại ảnh OAN, dù detector đếm khớp kịch bản.
 *
 * Quy tắc (chỉ quyết định có CẢNH BÁO câu đếm của VLM hay không; KHÔNG đụng lý do của detector — `OutputVerifier` giữ nguyên):
 *  - detector khớp kịch bản (expected <= D <= expected + extraAllowed) mà VLM lệch -> DETECTOR_OVERRIDES_VLM: bỏ cảnh báo VLM (ghi log).
 *  - detector lệch, VLM lệch CÙNG HƯỚNG (cùng thiếu hoặc cùng thừa) -> BOTH_SAY_FEW/MANY: giữ cảnh báo (hai nguồn độc lập đồng ý).
 *  - detector lệch, VLM lệch NGƯỢC hướng -> UNCERTAIN: giữ cảnh báo như cũ (không đủ cơ sở để bỏ).
 *  - VLM đếm đúng mà detector lệch -> UNCERTAIN: không có cảnh báo VLM nào để thêm; chỉ ghi chú (người che nhau làm detector đếm thiếu).
 *  - thiếu một trong hai tín hiệu: NO_VLM (không làm gì) / VLM_ONLY (như cũ: cảnh báo khi lệch).
 *
 * GIỚI HẠN THẬT: cảnh vật lộn/quần nhau là chỗ DETECTOR cũng đếm thiếu (người che nhau) — bộ phân xử này chỉ bỏ cảnh báo VLM khi detector ĐẾM ĐÚNG kịch bản,
 * không cứu được ca detector đếm thiếu; ngưỡng/độ tin cậy cần hiệu chỉnh trên ảnh thật. Hàm thuần: chạy được bằng kotlinc (tools/test_person_count_arbiter.py).
 */
object PersonCountArbiter {

    enum class Kind { NO_VLM, VLM_ONLY, CONSISTENT, DETECTOR_OVERRIDES_VLM, BOTH_SAY_FEW, BOTH_SAY_MANY, UNCERTAIN }

    class Decision(val kind: Kind, val warnVlmCount: Boolean, val note: String)

    /** Cùng quy tắc `OutputVerifier`: thiếu người là lỗi; thừa tới `extraAllowed` người vẫn chấp nhận. */
    fun detectorOk(expected: Int, detected: Int, extraAllowed: Int): Boolean =
        detected >= expected && detected <= expected + maxOf(extraAllowed, 0)

    fun decide(expected: Int, detected: Int?, vlm: Int?, extraAllowed: Int): Decision {
        if (vlm == null) return Decision(Kind.NO_VLM, false, "")
        if (detected == null) return Decision(Kind.VLM_ONLY, vlm != expected, "")
        val dOk = detectorOk(expected, detected, extraAllowed)
        if (vlm == expected) {
            return if (dOk) Decision(Kind.CONSISTENT, false, "")
            else Decision(Kind.UNCERTAIN, false, "Đếm người: detector $detected, VLM $vlm, kịch bản $expected — VLM đúng còn detector lệch (có thể người che nhau hoặc detector nhận thừa)")
        }
        if (dOk) {
            return Decision(Kind.DETECTOR_OVERRIDES_VLM, false,
                "Đếm người: VLM đếm $vlm nhưng detector đếm $detected khớp kịch bản ($expected) — ưu tiên detector, bỏ cảnh báo của VLM")
        }
        val dSign = Integer.signum(detected - expected)
        val vSign = Integer.signum(vlm - expected)
        return if (dSign == vSign) {
            Decision(if (vSign < 0) Kind.BOTH_SAY_FEW else Kind.BOTH_SAY_MANY, true,
                "Đếm người: detector ($detected) và VLM ($vlm) cùng lệch so với kịch bản ($expected)")
        } else {
            Decision(Kind.UNCERTAIN, true, "Đếm người: detector ($detected) và VLM ($vlm) lệch NGƯỢC hướng so với kịch bản ($expected) — giữ cảnh báo của VLM")
        }
    }
}
