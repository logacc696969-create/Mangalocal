package com.mangalocal.pipeline

/**
 * mục 266 TECHNICAL_STATUS.md — JSON tối giản, THUẦN Kotlin (không dùng org.json của Android) để các lớp gọi API ngoài (LLM/VLM/ảnh miễn phí) có phần
 * dựng body và đọc phản hồi KIỂM THỬ ĐƯỢC bằng kotlinc ngoài máy (tools/test_openai_json.py, test_free_image_api.py). Không phải thư viện JSON đa năng:
 * chỉ đủ cho phản hồi API (đối tượng/mảng/chuỗi/số/true/false/null), giới hạn độ sâu để không tràn ngăn xếp.
 */
object MiniJson {
    const val MAX_DEPTH = 64

    /** Chuỗi JSON đã thoát (có dấu nháy kép bao ngoài). Ký tự điều khiển < 0x20 thoát dạng \uXXXX; Unicode khác giữ nguyên. */
    fun quote(s: String): String {
        val sb = StringBuilder(s.length + 2)
        sb.append('"')
        for (ch in s) {
            when (ch) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                else -> if (ch < ' ') {
                    sb.append("\\u")
                    val h = Integer.toHexString(ch.code)
                    for (i in h.length until 4) sb.append('0')
                    sb.append(h)
                } else sb.append(ch)
            }
        }
        sb.append('"')
        return sb.toString()
    }

    /**
     * Phân tích văn bản JSON -> Map<String, Any?> (đối tượng) / List<Any?> (mảng) / String / Long (số nguyên) / Double / Boolean / null.
     * Ném IllegalArgumentException (thông báo tiếng Việt, có vị trí) nếu sai cú pháp hoặc còn ký tự thừa.
     */
    fun parse(text: String): Any? {
        val p = Parser(text)
        p.skipWs()
        val v = p.value(0)
        p.skipWs()
        if (p.pos != text.length) p.fail("còn ký tự thừa sau giá trị JSON")
        return v
    }

    @Suppress("UNCHECKED_CAST")
    fun obj(x: Any?): Map<String, Any?>? = x as? Map<String, Any?>

    @Suppress("UNCHECKED_CAST")
    fun arr(x: Any?): List<Any?>? = x as? List<Any?>

    /** Đi theo đường dẫn: khoá chuỗi cho đối tượng, chỉ số Int cho mảng. Thiếu/sai kiểu ở bất kỳ bước nào -> null. */
    fun path(root: Any?, vararg keys: Any): Any? {
        var cur: Any? = root
        for (k in keys) {
            cur = when (k) {
                is String -> obj(cur)?.get(k)
                is Int -> arr(cur)?.getOrNull(k)
                else -> null
            }
            if (cur == null) return null
        }
        return cur
    }

    private class Parser(val s: String) {
        var pos = 0

        fun fail(msg: String): Nothing = throw IllegalArgumentException("JSON lỗi ở vị trí $pos: $msg")

        fun skipWs() {
            while (pos < s.length) {
                val c = s[pos]
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t') pos++ else break
            }
        }

        fun value(depth: Int): Any? {
            if (depth > MAX_DEPTH) fail("lồng quá sâu (> $MAX_DEPTH)")
            if (pos >= s.length) fail("hết dữ liệu khi đang đọc giá trị")
            return when (val c = s[pos]) {
                '{' -> obj(depth)
                '[' -> arr(depth)
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || (c in '0'..'9')) num() else fail("ký tự không hợp lệ '$c'")
            }
        }

        fun lit(word: String, v: Any?): Any? {
            if (!s.startsWith(word, pos)) fail("mong đợi '$word'")
            pos += word.length
            return v
        }

        fun obj(depth: Int): Map<String, Any?> {
            val m = LinkedHashMap<String, Any?>()
            pos++ // {
            skipWs()
            if (pos < s.length && s[pos] == '}') { pos++; return m }
            while (true) {
                skipWs()
                if (pos >= s.length || s[pos] != '"') fail("mong đợi khoá chuỗi")
                val k = str()
                skipWs()
                if (pos >= s.length || s[pos] != ':') fail("mong đợi ':'")
                pos++
                skipWs()
                m[k] = value(depth + 1)
                skipWs()
                if (pos >= s.length) fail("hết dữ liệu trong đối tượng")
                val c = s[pos]
                if (c == ',') { pos++; continue }
                if (c == '}') { pos++; return m }
                fail("mong đợi ',' hoặc '}'")
            }
        }

        fun arr(depth: Int): List<Any?> {
            val l = ArrayList<Any?>()
            pos++ // [
            skipWs()
            if (pos < s.length && s[pos] == ']') { pos++; return l }
            while (true) {
                skipWs()
                l.add(value(depth + 1))
                skipWs()
                if (pos >= s.length) fail("hết dữ liệu trong mảng")
                val c = s[pos]
                if (c == ',') { pos++; continue }
                if (c == ']') { pos++; return l }
                fail("mong đợi ',' hoặc ']'")
            }
        }

        fun str(): String {
            pos++ // dấu nháy mở
            // đường nhanh (chuỗi base64 ảnh có thể dài hàng MB): không có '\' thì cắt thẳng
            var i = pos
            while (i < s.length) {
                val c = s[i]
                if (c == '"') { val r = s.substring(pos, i); pos = i + 1; return r }
                if (c == '\\') break
                if (c < ' ') fail("ký tự điều khiển trong chuỗi")
                i++
            }
            val sb = StringBuilder()
            while (true) {
                if (pos >= s.length) fail("chuỗi không đóng")
                val c = s[pos++]
                when {
                    c == '"' -> return sb.toString()
                    c == '\\' -> {
                        if (pos >= s.length) fail("thoát dở dang")
                        when (val e = s[pos++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 4 > s.length) fail("\\u thiếu chữ số")
                                val hex = s.substring(pos, pos + 4)
                                val code = hex.toIntOrNull(16) ?: fail("\\u không phải số hex: $hex")
                                sb.append(code.toChar())
                                pos += 4
                            }
                            else -> fail("thoát không hợp lệ \\$e")
                        }
                    }
                    c < ' ' -> fail("ký tự điều khiển trong chuỗi")
                    else -> sb.append(c)
                }
            }
        }

        fun num(): Any {
            val start = pos
            if (s[pos] == '-') pos++
            if (pos >= s.length || s[pos] !in '0'..'9') fail("số không hợp lệ")
            if (s[pos] == '0') pos++ else while (pos < s.length && s[pos] in '0'..'9') pos++
            var isDouble = false
            if (pos < s.length && s[pos] == '.') {
                isDouble = true; pos++
                if (pos >= s.length || s[pos] !in '0'..'9') fail("số thập phân thiếu chữ số")
                while (pos < s.length && s[pos] in '0'..'9') pos++
            }
            if (pos < s.length && (s[pos] == 'e' || s[pos] == 'E')) {
                isDouble = true; pos++
                if (pos < s.length && (s[pos] == '+' || s[pos] == '-')) pos++
                if (pos >= s.length || s[pos] !in '0'..'9') fail("mũ thiếu chữ số")
                while (pos < s.length && s[pos] in '0'..'9') pos++
            }
            val t = s.substring(start, pos)
            return if (isDouble) t.toDouble() else (t.toLongOrNull() ?: t.toDouble())
        }
    }
}
