package com.mangalocal.pipeline

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.mangalocal.model.Panel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * mục 248 TECHNICAL_STATUS.md — LỒNG TIẾNG lời thoại (TTS) cho gói video (mục 244), dùng TextToSpeech CÓ SẴN của Android
 * (không thêm model, chạy offline nếu giọng đã tải trên máy). Mỗi câu thoại → 1 file `pPPP_lLL.wav` kèm độ dài.
 *
 * API đã đối chiếu tài liệu Android (mục 248): `synthesizeToFile(CharSequence, Bundle, File, String)` (API 21+),
 * `UtteranceProgressListener.onDone` = file đã ghi xong, `isLanguageAvailable(Locale)`, và Android 11+ cần khai báo
 * `<queries>` cho TTS_SERVICE trong manifest (đã thêm).
 *
 * GIỚI HẠN THẬT:
 *  - Chất lượng/độ tự nhiên do engine TTS của máy quyết định; thiết bị KHÔNG có giọng Tiếng Việt thì KHÔNG tạo được
 *    (hàm trả rỗng và ghi log, không ném lỗi).
 *  - Mỗi nhân vật chỉ khác nhau ở cao độ (pitch 0.85–1.20, suy từ tên) — KHÔNG phải giọng riêng.
 *  - Chỉ xuất file âm thanh RỜI cho từng câu; KHÔNG ghép vào video, KHÔNG đồng bộ khẩu hình (cần model video có âm thanh).
 *  - Định dạng file do engine ghi; thường là WAV (RIFF) — nếu không phải RIFF thì không đọc được độ dài (seconds = null).
 *  - CHƯA build-test, chưa thử trên thiết bị thật.
 */
object DialogueAudio {

    /** Giới hạn ký tự mỗi câu gửi TTS (engine có giới hạn riêng, thường lớn hơn nhiều). */
    const val MAX_CHARS = 400
    const val PITCH_MIN = 0.85f
    const val PITCH_MAX = 1.20f
    const val INIT_TIMEOUT_MS = 10_000L
    const val ITEM_TIMEOUT_MS = 30_000L

    data class Item(val panelIndex: Int, val lineIndex: Int, val character: String, val text: String, val fileName: String)
    data class Clip(val item: Item, val file: File, val seconds: Float?)

    /** Thứ tự đọc = thứ tự panel rồi thứ tự thoại; bỏ câu rỗng; tên file 1-based, ổn định. */
    fun plan(panels: List<Panel>): List<Item> {
        val out = ArrayList<Item>()
        for (p in panels.sortedBy { it.index }) {
            p.scene.dialogue.forEachIndexed { li, d ->
                val text = d.text.trim().take(MAX_CHARS)
                if (text.isNotEmpty()) {
                    out.add(Item(p.index, li, d.characterName, text, "p%03d_l%02d.wav".format(p.index + 1, li + 1)))
                }
            }
        }
        return out
    }

    /** Cao độ ổn định theo tên nhân vật (không phân biệt hoa thường) trong [PITCH_MIN, PITCH_MAX]. */
    fun pitchFor(character: String): Float {
        var h = 7
        for (c in character.trim().lowercase()) h = h * 31 + c.code
        val u = ((h and 0x7fffffff) % 1000) / 999f
        return PITCH_MIN + u * (PITCH_MAX - PITCH_MIN)
    }

    private fun le16(b: ByteArray, o: Int) = (b[o].toInt() and 0xff) or ((b[o + 1].toInt() and 0xff) shl 8)
    private fun le32(b: ByteArray, o: Int): Long =
        (b[o].toLong() and 0xff) or ((b[o + 1].toLong() and 0xff) shl 8) or
            ((b[o + 2].toLong() and 0xff) shl 16) or ((b[o + 3].toLong() and 0xff) shl 24)

    /** Độ dài (giây) của file WAV PCM từ phần đầu RIFF; null nếu không phải WAV hợp lệ. */
    fun wavSeconds(b: ByteArray): Float? {
        if (b.size < 44 || String(b, 0, 4, Charsets.US_ASCII) != "RIFF" || String(b, 8, 4, Charsets.US_ASCII) != "WAVE") return null
        var o = 12
        var rate = 0L; var channels = 0; var bits = 0
        while (o + 8 <= b.size) {
            val id = String(b, o, 4, Charsets.US_ASCII)
            val size = le32(b, o + 4)
            val body = o + 8
            if (id == "fmt " && body + 16 <= b.size) {
                channels = le16(b, body + 2); rate = le32(b, body + 4); bits = le16(b, body + 14)
            } else if (id == "data") {
                val remaining = (b.size - body).toLong()
                val dataBytes = if (size == 0L || size > remaining) remaining else size
                val bytesPerSec = rate * channels * (bits / 8)
                return if (bytesPerSec <= 0L) null else dataBytes.toFloat() / bytesPerSec.toFloat()
            }
            val next = body.toLong() + size + (size and 1L)
            if (next > b.size) return null
            o = next.toInt()
        }
        return null
    }

    /**
     * Tạo file âm thanh cho từng câu. Trả danh sách clip tạo được (có thể rỗng). KHÔNG ném lỗi vì thiếu giọng/TTS —
     * ghi log và trả rỗng để việc xuất gói video vẫn tiếp tục.
     */
    suspend fun synthesize(
        context: Context, items: List<Item>, dir: File,
        locale: Locale = Locale("vi", "VN"), log: (String) -> Unit = {}
    ): List<Clip> = withContext(Dispatchers.Main) {
        if (items.isEmpty()) return@withContext emptyList()
        dir.mkdirs()
        val ready = CompletableDeferred<Int>()
        val tts = TextToSpeech(context.applicationContext) { status -> ready.complete(status) }
        try {
            if (withTimeoutOrNull(INIT_TIMEOUT_MS) { ready.await() } != TextToSpeech.SUCCESS) {
                log("  ⚠ Lồng tiếng: không khởi tạo được TextToSpeech của máy — bỏ qua")
                return@withContext emptyList()
            }
            if (tts.isLanguageAvailable(locale) < TextToSpeech.LANG_AVAILABLE) {
                log("  ⚠ Lồng tiếng: máy chưa có giọng ${locale.displayName} (cài trong Cài đặt Android > Chuyển văn bản thành giọng nói) — bỏ qua")
                return@withContext emptyList()
            }
            tts.setLanguage(locale)
            val pending = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { utteranceId?.let { pending[it]?.complete(true) } }
                @Deprecated("Dùng onError(String, Int)")
                override fun onError(utteranceId: String?) { utteranceId?.let { pending[it]?.complete(false) } }
                override fun onError(utteranceId: String?, errorCode: Int) { utteranceId?.let { pending[it]?.complete(false) } }
            })
            val clips = ArrayList<Clip>()
            for (item in items) {
                val file = File(dir, item.fileName)
                val id = item.fileName
                val done = CompletableDeferred<Boolean>()
                pending[id] = done
                tts.setPitch(pitchFor(item.character))
                val rc = tts.synthesizeToFile(item.text, Bundle(), file, id)
                if (rc != TextToSpeech.SUCCESS) { pending.remove(id); log("  ⚠ Lồng tiếng: không gửi được câu ${item.fileName}"); continue }
                val okSynth = withTimeoutOrNull(ITEM_TIMEOUT_MS) { done.await() } == true
                pending.remove(id)
                if (okSynth && file.exists() && file.length() > 44L) {
                    clips.add(Clip(item, file, wavSeconds(file.readBytes())))
                } else {
                    log("  ⚠ Lồng tiếng: câu ${item.fileName} không tạo được (quá thời gian hoặc engine báo lỗi)")
                    file.delete()
                }
            }
            clips
        } finally {
            tts.stop()
            tts.shutdown()
        }
    }
}
