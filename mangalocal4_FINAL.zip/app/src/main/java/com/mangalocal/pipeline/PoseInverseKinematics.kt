package com.mangalocal.pipeline

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * CCD-IK (Cyclic Coordinate Descent Inverse Kinematics) — mục 118
 * TECHNICAL_STATUS.md, vá đúng giới hạn đã ghi trong docstring
 * [PoseRetargeter] ("không giải điểm chạm bắt buộc — cần thêm metadata
 * điểm chạm mới làm được"). Metadata đó chính là TOẠ ĐỘ GỐC của khớp cuối
 * chi (bàn tay) TRƯỚC khi retarget — template gốc (tỷ lệ 1.0/1.0) đã đặt
 * đúng vị trí chạm theo THIẾT KẾ (vd tay người A đặt đúng vai người B),
 * nên coi toạ độ gốc đó LÀ mục tiêu cần giữ nguyên, bất kể tỷ lệ xương mới
 * khiến độ dài chi thay đổi.
 *
 * Thuật toán 2D thuần (không cần 3D/quaternion — đúng không gian làm việc
 * hiện có của toàn bộ PoseRetargeter): với 1 chuỗi khớp (vd vai->khuỷu->
 * cổ tay), quay từng khớp từ NGOÀI VÀO GỐC, mỗi lần quay khớp hiện tại sao
 * cho đầu chi (end-effector) tiến gần mục tiêu nhất — lặp lại tới khi hội
 * tụ hoặc hết số vòng cho phép.
 *
 * GIỚI HẠN THẬT: chỉ áp dụng cho chuỗi 2 xương (vai-khuỷu-cổ tay hoặc
 * hông-gối-mắt cá) — đủ cho tay/chân người, KHÔNG tổng quát cho chuỗi
 * nhiều khớp hơn dù thuật toán CCD về lý thuyết hỗ trợ (chưa cần, không
 * over-engineer). Nếu mục tiêu NGOÀI TẦM VỚI (tổng độ dài xương mới ngắn
 * hơn khoảng cách gốc->mục tiêu — có thể xảy ra khi tỷ lệ tay quá nhỏ),
 * thuật toán vẫn hội tụ về hướng ĐÚNG (chi duỗi thẳng hướng mục tiêu) chỉ
 * là KHÔNG chạm tới — đây là giới hạn vật lý thật (chi ngắn hơn không thể
 * với xa hơn chính nó), không phải lỗi thuật toán.
 */
object PoseInverseKinematics {
    private const val MAX_ITERATIONS = 8
    private const val TOLERANCE = 0.003f // toạ độ chuẩn hoá 0..1 — ~3px trên ảnh 1024

    private fun dist(ax: Float, ay: Float, bx: Float, by: Float) =
        sqrt((ax - bx) * (ax - bx) + (ay - by) * (ay - by))

    /** Xoay [points] (danh sách toạ độ) quanh ([px],[py]) 1 góc [angle] (radian). */
    private fun rotateAround(px: Float, py: Float, points: MutableList<Pair<Float, Float>>, angle: Float) {
        val c = cos(angle); val s = sin(angle)
        for (i in points.indices) {
            val (x, y) = points[i]
            val dx = x - px; val dy = y - py
            points[i] = (px + dx * c - dy * s) to (py + dx * s + dy * c)
        }
    }

    /**
     * Giải IK cho chuỗi 2 xương (3 khớp: root - mid - end). [rootX]/[rootY]
     * CỐ ĐỊNH (không di chuyển — đúng vai/hông đã tính từ bước FK trước
     * đó). [boneLen1]/[boneLen2] là độ dài 2 xương MỚI (đã nhân tỷ lệ nhân
     * vật — xem retargetArm/retargetLeg trong PoseRetargeter). Trả về vị
     * trí mới của (mid, end) — root giữ nguyên, gọi nơi dùng tự gán lại.
     *
     * Thuật toán CCD CHUẨN (không phải heuristic tự chế): lặp qua từng
     * khớp từ GẦN END-EFFECTOR NHẤT lùi dần về ROOT, mỗi bước xoay pivot
     * đó (và MỌI khớp sau nó trong chuỗi) 1 góc đúng bằng góc lệch giữa
     * "hướng hiện tại từ pivot tới end-effector" và "hướng từ pivot tới
     * target" — end-effector LUÔN tiến gần target hơn (không bao giờ xa
     * hơn) sau mỗi bước xoay đơn lẻ, đảm bảo hội tụ đơn điệu.
     */
    fun solveTwoBoneChain(
        rootX: Float, rootY: Float,
        midX: Float, midY: Float,
        endX: Float, endY: Float,
        boneLen1: Float, boneLen2: Float,
        targetX: Float, targetY: Float
    ): Pair<Pair<Float, Float>, Pair<Float, Float>> {
        if (boneLen1 <= 0.0001f || boneLen2 <= 0.0001f) return (midX to midY) to (endX to endY)

        // chain[0]=root (cố định, không bao giờ là pivot), chain[1]=mid, chain[2]=end
        val chain = mutableListOf(rootX to rootY, midX to midY, endX to endY)

        for (iter in 0 until MAX_ITERATIONS) {
            val (ex, ey) = chain[2]
            if (dist(ex, ey, targetX, targetY) < TOLERANCE) break

            // i=1 (pivot=mid, chỉ xoay chain[2]=end) rồi i=0 (pivot=root, xoay chain[1],chain[2])
            for (i in 1 downTo 0) {
                val (px, py) = chain[i]
                val (curEx, curEy) = chain[2]
                val curAngle = atan2(curEy - py, curEx - px)
                val targetAngle = atan2(targetY - py, targetX - px)
                var delta = targetAngle - curAngle
                // Chuẩn hoá delta về (-PI, PI] — tránh xoay vòng dư 1 vòng
                // đầy khi 2 góc lệch nhau qua ranh giới -PI/PI.
                while (delta > Math.PI) delta -= (2 * Math.PI).toFloat()
                while (delta < -Math.PI) delta += (2 * Math.PI).toFloat()

                val sub = mutableListOf(chain[i + 1])
                if (i + 2 < chain.size) sub.add(chain[i + 2])
                rotateAround(px, py, sub, delta)
                chain[i + 1] = sub[0]
                if (i + 2 < chain.size) chain[i + 2] = sub[1]
            }
        }
        return chain[1] to chain[2]
    }
}
