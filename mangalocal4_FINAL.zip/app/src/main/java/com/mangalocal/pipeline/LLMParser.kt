package com.mangalocal.pipeline

import com.mangalocal.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class LLMParser(
    private val modelPath: String,
    private val nThreads: Int = 4,
    private val nGpuLayers: Int = 0,
    // Rỗng/null hoặc enabled=false = dùng model .gguf local như cũ (hành vi
    // mặc định, không đổi gì). enabled=true = MỌI lời gọi generate() bên
    // dưới đi qua ExternalLlmClient (API ngoài) thay vì llama.cpp local —
    // xem GenerationSettings.externalLlm/SettingsScreen.kt mục "LLM ngoài".
    private val externalConfig: ExternalLlmConfig? = null
) {

    // ── Mục 54 TECHNICAL_STATUS.md: "hệ sinh thái SD1.5" — LLM tạo prompt
    // TỐI ƯU cho SD1.5, vì SD1.5 dùng CLIP ViT-L/14 (KHÔNG hiểu câu tự nhiên
    // như model text-to-image thế hệ sau/LLM-based) — cần tag ngắn, phân
    // tách bằng dấu phẩy, ưu tiên từ khoá QUAN TRỌNG lên ĐẦU câu.
    //
    // CÁC QUY TẮC DƯỚI ĐÂY ĐÃ ĐỐI CHIẾU THẬT với
    // app/src/main/jni/sd_engine/PromptProcessor.hpp (không đoán cú pháp):
    //   - `(tag)`      -> nhân trọng số ×1.1 (lồng nhiều lớp nhân dồn, vd
    //                     `((tag))` = ×1.21) — đọc thẳng từ parsePromptTree().
    //   - `(tag:1.3)`  -> đặt trọng số CHÍNH XÁC 1.3, ghi đè mặc định ×1.1.
    //   - `[tag]`      -> giảm trọng số ×0.9 (nhấn NHẸ đi, không phải xoá).
    //   - Textual Inversion trigger (mục 13): chỉ cần gõ ĐÚNG tên file
    //     (không phân biệt hoa/thường, khớp qua `embeddings_` map bằng so
    //     khớp chuỗi thường) như 1 tag bình thường trong câu, KHÔNG cần cú
    //     pháp đặc biệt (không phải `<name>` như A1111/ComfyUI — dự án này
    //     KHÔNG dùng cú pháp góc nhọn, xác nhận qua flattenTree()).
    //   - KHÔNG có bằng chứng dự án hỗ trợ từ khoá `BREAK` (chia embedding
    //     theo khối 75 token như A1111 webui) — KHÔNG dạy LLM dùng, tránh
    //     đoán API không xác nhận được.
    //
    // Các quy tắc CÒN LẠI (giới hạn 75 token hiệu dụng của CLIP ViT-L/14,
    // trọng số token đầu câu ảnh hưởng mạnh hơn, quy ước quality/negative
    // tag cộng đồng SD1.5) là KIẾN THỨC NỀN CÔNG KHAI về kiến trúc CLIP/SD1.5
    // (không riêng gì repo này), không phải suy đoán riêng cho dự án.
    // mục 93 TECHNICAL_STATUS.md — sửa lại thành 2 biến thể LUẬT NỀN, chọn
    // theo PromptStyle của checkpoint đang active, thay vì 1 hằng số cố
    // định luôn ép tag-style. `promptGuideNotes` (mục 54, xem
    // guideNotesBlock bên dưới) vẫn là LỚP TINH CHỈNH THÊM lên TRÊN luật
    // nền đã chọn — KHÔNG thay thế việc chọn luật nền đúng trước, chỉ tinh
    // chỉnh chi tiết trong cùng 1 luật nền (ví dụ 2 checkpoint cùng tag-based
    // nhưng khác quy ước đặt tên tag, promptGuideNotes vẫn hữu ích cho việc
    // đó — 2 cơ chế bổ trợ nhau, không chồng chéo).
    private val TAG_BASED_GUIDE = """
SD1.5/SDXL tag-based checkpoint prompt rules (Danbooru/booru-style, e.g. Illustrious, Pony, most anime community checkpoints — NOT a natural-language model, obey strictly):
- Write SHORT comma-separated tags/phrases, NEVER full grammatical sentences. Bad: "a girl who is walking sadly through the rain at night". Good: "1girl, walking, sad expression, rain, night, wet street".
- Text encoder effectively reads ~75 tokens; put the MOST IMPORTANT tags (subject, character identity, main action) FIRST — tags near the end have weaker effect and may be truncated entirely.
- Emphasis syntax that actually works in this app's renderer (verified in source, use ONLY these): "(tag)" = weight x1.1 per nesting level (e.g. "((tag))" = x1.21), "(tag:1.3)" = exact weight, "[tag]" = weight x0.9 (de-emphasis). Use sparingly (1-3 emphasized tags max) — overusing weights makes output unstable.
- Character Textual-Inversion trigger words (if given) must appear as a PLAIN tag, spelled exactly as given — no special brackets or angle-bracket syntax.
- Keep positive prompt under ~70 tokens total; keep negative prompt short and SPECIFIC to this scene's actual risks, not a generic wall of boilerplate.
""".trimIndent()

    // mục 93 — checkpoint ảnh thực/base SDXL/SD3.5 (RealVisXL, Juggernaut XL,
    // Realistic Vision...) hiểu câu văn mô tả TỐT HƠN tag rời rạc — ép tag
    // vào loại checkpoint này khiến text encoder thiếu ngữ cảnh câu, ra ảnh
    // rời rạc/thiếu liên kết (đã tra chéo nhiều nguồn cộng đồng, mục 93).
    private val NATURAL_LANGUAGE_GUIDE = """
Natural-language checkpoint prompt rules (e.g. SDXL base, RealVisXL, Juggernaut XL, Realistic Vision — the text encoder was trained on descriptive sentences, NOT terse tags, obey strictly):
- Write full, coherent descriptive sentences/clauses, NOT comma-separated tag lists. Bad: "1girl, blue hair, torn shirt, wrinkled fabric, standing". Good: "a girl with blue hair, wearing a torn shirt with wrinkled fabric at the shoulder, standing in the rain".
- Structure loosely as: [main subject + action], [appearance details], [setting/background], [lighting/mood], [style]. Keep it as PROSE, not a keyword dump.
- The text encoder handles longer context better than tag-based models — you may use 1-2 full sentences rather than truncating to keywords, but stay concise (under ~150 words) to keep the most important details from being diluted.
- Emphasis syntax "(tag)"/"(tag:1.3)"/"[tag]" still works technically in this app's renderer, but use SPARINGLY on natural-language checkpoints — heavy weighting breaks sentence coherence more than it does for tag-based checkpoints.
- Negative prompt: short, specific phrases are fine here too (this convention carries over from tag-based practice and works on most natural-language checkpoints as well).
""".trimIndent()

    // Kiến trúc phân loại BIỂU CẢM NHÂN VẬT — cùng khuôn mẫu action_category
    // (Scene.actionCategory): LLM tự phân loại vào 1 TẬP ĐÓNG lúc viết scene
    // (parseScenes(), field "expression"), sau đó buildPrompt() TRA BẢNG ra
    // tag CỤ THỂ đã viết sẵn thay vì để LLM tự bịa mô tả biểu cảm mỗi lần
    // (trước đây chỉ là 1 câu dặn chung chung "must include a concrete
    // facial-expression detail" — LLM có thể quên/viết mơ hồ). 2 biến thể/
    // category (tag-based / natural-language) khớp đúng PromptStyle (mục 93).
    // Đặt gần đầu block emphasis vì token đầu câu có trọng số mạnh hơn với
    // CLIP ViT-L/14 (xem TAG_BASED_GUIDE ở trên) — buildPrompt() dặn LLM
    // đặt cụm này gần đầu "positive", không phải cuối câu.
    //
    // CƠ SỞ CHỌN 12 CATEGORY — VÀ VÌ SAO KHÔNG "ĐẦY ĐỦ" (đọc trước khi thêm
    // bớt category, hoặc trước khi tưởng đây là danh sách chuẩn hoàn chỉnh):
    //   Tâm lý học cảm xúc KHÔNG có đồng thuận về "danh sách đầy đủ". 2
    //   trường phái chính: (1) mô hình RỜI RẠC (Ekman, ~1970s — 6 cảm xúc
    //   cơ bản: anger/disgust/fear/happiness/sadness/surprise, dùng làm cơ
    //   sở cho hầu hết dataset FER thật như FER2013/RAF-DB/AffectNet — bản
    //   AffectNet 8-lớp = 6 của Ekman + neutral + contempt); (2) mô hình
    //   LIÊN TỤC (Russell's Circumplex — valence×arousal, KHÔNG rời rạc,
    //   tồn tại chính vì giới học thuật nhận ra bất kỳ tập rời rạc nào cũng
    //   MẤT THÔNG TIN). Không có "N cảm xúc cơ bản" nào đúng tuyệt đối.
    //   6 category ĐẦU trong map dưới đây khớp ĐÚNG 6 cảm xúc Ekman (angry=
    //   anger, disgust=disgust, scared=fear, smile=happiness, sad=sadness,
    //   surprised=surprise) + neutral + contempt = phủ đúng chuẩn AffectNet
    //   8-lớp (chuẩn thực dụng được validate rộng nhất hiện có, KHÔNG phải
    //   "đầy đủ tuyệt đối" — không tồn tại thứ đó). 4 category CÒN LẠI
    //   (crying, smirk, determined, blush) KHÔNG nằm trong bất kỳ chuẩn học
    //   thuật nào — thêm vì tần suất xuất hiện cao trong QUY ƯỚC THỂ LOẠI
    //   manga cụ thể (blush gần như là quy ước bắt buộc của thể loại lãng
    //   mạn, smirk/determined là beat tự sự phổ biến) — chọn theo QUY ƯỚC
    //   THỂ LOẠI, không theo tâm lý học phổ quát, ghi rõ để không nhầm.
    //
    //   HỆ QUẢ THẬT của việc không có gì "đầy đủ": vì "expression" là 1
    //   enum ĐÓNG trong JSON schema (xem scenePrompt() bên dưới), LLM BỊ ÉP
    //   chọn category GẦN NHẤT ngay cả khi cảm xúc thật của cảnh không khớp
    //   hoàn hảo category nào (vd 1 cảm xúc phức hợp như "ghen tuông" phải
    //   quy về "angry" hoặc "sad" tuỳ ngữ cảnh) — đây là ĐÁNH ĐỔI CÓ CHỦ Ý:
    //   "tag cụ thể của category gần nhất" vẫn tốt hơn "không có tag cụ thể
    //   nào cả" (hành vi cũ trước khi có field này), nhưng KHÔNG claim là
    //   luôn chính xác 100% với mọi sắc thái cảm xúc có thể có trong 1 câu
    //   chuyện. Scene.expression=null (model cũ/parse lỗi) rơi về câu dặn
    //   chung chung cũ — không có gì hỏng thêm, chỉ mất phần cải thiện.
    // mục 168 TECHNICAL_STATUS.md — EXPRESSION_TAGS/VALID_EXPRESSIONS/
    // resolveExpressionTag() chuyển vào `companion object` (TRƯỚC ĐÂY là
    // property riêng của instance, y hệt logic, chỉ đổi CHỖ khai báo) để
    // MangaPipeline.runMultiPassCascade() gọi được `LLMParser.resolveExpressionTag()`
    // KHÔNG cần tạo hẳn 1 instance LLMParser (vốn cần modelPath/nThreads —
    // không có sẵn ở nơi cascade chạy, sau khi LLM đã free() từ trước, xem
    // mục 168 phần "Per-Character Expression"). Toàn bộ usage private cũ
    // trong class (promptTemplate(), parseScenes()) vẫn gọi KHÔNG CẦN tiền
    // tố `Companion.`/`LLMParser.` như trước — Kotlin cho phép truy cập
    // thành viên companion object không tiền tố từ bên trong class, nên
    // hành vi CŨ 100% không đổi, chỉ thêm entrypoint public mới.
    companion object {
        private data class ExpressionTagSet(val tagBased: String, val naturalLanguage: String)

        private val EXPRESSION_TAGS: Map<String, ExpressionTagSet> = mapOf(
        // 6 cảm xúc cơ bản Ekman + neutral + contempt = chuẩn AffectNet 8-lớp
        "neutral" to ExpressionTagSet(
            "neutral calm expression",
            "a calm, neutral expression"),
        "smile" to ExpressionTagSet( // = "happiness" của Ekman
            "(gentle smile:1.2), soft eyes",
            "a gentle, warm smile with soft eyes"),
        "sad" to ExpressionTagSet( // = "sadness" của Ekman
            "(sad expression:1.2), downturned mouth, glistening eyes",
            "a sad expression, with a downturned mouth and glistening eyes"),
        "angry" to ExpressionTagSet( // = "anger" của Ekman
            "(angry expression:1.2), furrowed brows, clenched jaw",
            "an angry expression, with furrowed brows and a clenched jaw"),
        "surprised" to ExpressionTagSet( // = "surprise" của Ekman
            "(surprised expression:1.2), widened eyes, parted lips",
            "a surprised expression, with widened eyes and parted lips"),
        "scared" to ExpressionTagSet( // = "fear" của Ekman
            "(scared expression:1.2), wide fearful eyes, pale face",
            "a scared expression, with wide, fearful eyes and a pale face"),
        "disgust" to ExpressionTagSet( // = "disgust" của Ekman — TRƯỚC ĐÂY THIẾU, đã bổ sung
            "(disgusted expression:1.2), wrinkled nose, curled lip",
            "a disgusted expression, with a wrinkled nose and curled lip"),
        "contempt" to ExpressionTagSet( // lớp thứ 8 của AffectNet — TRƯỚC ĐÂY THIẾU, đã bổ sung
            "(contemptuous smirk:1.2), one-sided raised lip, cold eyes",
            "a contemptuous look, with one side of the lip raised and cold, dismissive eyes"),
        // Dưới đây: KHÔNG thuộc chuẩn học thuật nào — chọn theo quy ước thể
        // loại manga (đọc ghi chú "CƠ SỞ CHỌN" ở trên).
        "crying" to ExpressionTagSet(
            "(crying:1.3), tears streaming, trembling lips",
            "crying, with tears streaming down her face and trembling lips"),
        "smirk" to ExpressionTagSet(
            "(smirk:1.2), one eyebrow raised, confident",
            "a confident smirk, with one eyebrow slightly raised"),
        "determined" to ExpressionTagSet(
            "(determined expression:1.2), narrowed eyes, set jaw",
            "a determined expression, with narrowed eyes and a set jaw"),
        "blush" to ExpressionTagSet(
            "(blushing:1.2), flushed cheeks, averted gaze",
            "blushing, with flushed cheeks and an averted gaze")
        )
        val VALID_EXPRESSIONS = EXPRESSION_TAGS.keys

        // mục 168 TECHNICAL_STATUS.md — entrypoint public dùng bởi
        // MangaPipeline.runMultiPassCascade() để tiêm tag biểu cảm RIÊNG
        // cho từng nhân vật trong prompt cô lập của lượt cascade đó (xem
        // Scene.characterExpressions ở Models.kt). Trả null nếu `expression`
        // không khớp key nào trong EXPRESSION_TAGS (an toàn dùng `?:` ở nơi
        // gọi, không throw) — CÙNG hành vi dung thứ đã áp dụng cho mọi field
        // enum-đóng khác trong file này (action_category, cameraAngle...).
        fun resolveExpressionTag(expression: String, promptStyle: PromptStyle): String? {
            val tagSet = EXPRESSION_TAGS[expression] ?: return null
            return if (promptStyle == PromptStyle.TAG_BASED) tagSet.tagBased else tagSet.naturalLanguage
        }
    }

    // mục 104 TECHNICAL_STATUS.md — kiến trúc bố cục khung hình (tỷ lệ
    // nhân vật/khung, chiều sâu, phối cảnh) — CÙNG lỗi kiến trúc đã sửa
    // cho biểu cảm ở mục 98: `Scene.cameraAngle` đã có nhãn phân loại (6
    // loại) từ đầu dự án, nhưng CHỈ được đưa vào prompt dưới dạng NHÃN
    // TRẦN ("Camera: wide-shot") — không có mô tả bố cục CỤ THỂ nào đi
    // kèm (tỷ lệ nhân vật chiếm bao nhiêu khung, có thấy chân/nửa người/
    // toàn thân, độ sâu trường ảnh, các lớp tiền-trung-hậu cảnh...) — để
    // LLM tự bịa mỗi lần, y hệt vấn đề biểu cảm trước khi sửa. Tra bảng ra
    // mô tả bố cục CỤ THỂ đã viết sẵn, cùng khuôn mẫu EXPRESSION_TAGS.
    //
    // GIỚI HẠN THẬT (khác biểu cảm — đọc kỹ): đây CHỈ sửa được phần MÔ TẢ
    // TRONG PROMPT (composition cues trong "positive"), KHÔNG sửa được
    // phần THẬT SỰ cần đổi theo góc máy: TỶ LỆ KHUNG ẢNH (aspect ratio).
    // Truyện tranh thật thường đổi hình dạng khung theo cảnh (toàn cảnh
    // thường khung NGANG/RỘNG hơn, cận cảnh thường khung DỌC/hẹp hơn) —
    // pipeline này hiện SINH MỌI PANEL CÙNG 1 KÍCH THƯỚC CỐ ĐỊNH
    // (GenerationSettings.width/height toàn cục, hoặc PanelOverrideSettings.
    // width/height NGƯỜI DÙNG tự chỉnh tay từng panel — KHÔNG có cơ chế tự
    // động chọn theo cameraAngle). Đây là gap THẬT, quy mô lớn hơn nhiều
    // (đụng vào toàn bộ luồng kích thước ảnh + UI hiển thị trang truyện
    // dạng lưới đều), CHƯA làm trong mục này — chỉ ghi nhận rõ, không giả
    // vờ đã giải quyết bằng cách thêm mô tả prompt.
    private data class CompositionTagSet(val tagBased: String, val naturalLanguage: String)

    private val CAMERA_COMPOSITION_TAGS: Map<String, CompositionTagSet> = mapOf(
        "extreme-close-up" to CompositionTagSet(
            "(extreme close-up:1.2), tightly cropped on face, eyes fill upper frame, no background visible, shallow depth of field",
            "an extreme close-up tightly cropped on the face, with the eyes filling the upper part of the frame and no background visible"),
        "close-up" to CompositionTagSet(
            "(close-up shot:1.2), head and shoulders framing, character fills most of frame, blurred background, shallow depth of field",
            "a close-up shot framing the head and shoulders, with the character filling most of the frame and the background softly blurred"),
        "medium-shot" to CompositionTagSet(
            "(medium shot:1.1), waist-up framing, character occupies center of frame, background visible but secondary, moderate depth of field",
            "a medium shot framing the character from the waist up, positioned in the center of the frame with the background visible but out of primary focus"),
        "wide-shot" to CompositionTagSet(
            "(wide shot:1.1), full body visible, character occupies lower third of frame, detailed background environment, establishing shot, foreground midground background layers",
            "a wide establishing shot showing the character's full body occupying the lower third of the frame, with a detailed, layered background environment stretching into the distance"),
        "overhead" to CompositionTagSet(
            "(bird's-eye view:1.2), high angle looking straight down, foreshortened figure, ground plane fills frame, dramatic top-down perspective",
            "a bird's-eye view looking straight down at the scene, with the figure foreshortened and the ground plane dominating the frame"),
        "low-angle" to CompositionTagSet(
            "(low angle shot:1.2), camera looking up at character, dramatic upward perspective, character appears tall and imposing, sky or ceiling visible above",
            "a low-angle shot looking up at the character from below, making them appear tall and imposing against the sky or ceiling above")
    )
    private val VALID_CAMERA_ANGLES = CAMERA_COMPOSITION_TAGS.keys

    private var ctx: Long = 0
    private val useExternal get() = externalConfig?.enabled == true
    private val externalClient by lazy { ExternalLlmClient(externalConfig!!) }

    // Điểm gọi DUY NHẤT cho mọi lời sinh văn bản LLM trong file này — quyết
    // định local hay external ngay tại đây, các hàm parseStory/buildPrompt/
    // translateStagePrompt bên dưới không cần biết đang dùng loại nào.
    private suspend fun generate(prompt: String, maxTokens: Int, temperature: Float): String =
        if (useExternal) externalClient.generate(prompt, maxTokens, temperature)
        else NativeBridge.llamaGenerate(ctx, prompt, maxTokens, temperature)

    // BUG PHÁT HIỆN KHI ĐỘNG VÀO FILE NÀY (không liên quan tính năng routing
    // mới): MangaPipeline.generatePanels()/regeneratePanel() gọi parser.init()
    // nhưng hàm này CHƯA TỪNG TỒN TẠI — nghĩa là ctx luôn = 0, mọi lời gọi
    // llamaGenerate() bên dưới thực chất chạy trên handle rỗng (native trả
    // về "" ngay từ dòng đầu `if (!h) return ""`, xem jni_bridge.cpp) — parse
    // kịch bản/prompt build LẼ RA đã fail-silent về nhánh catch{} (câu Scene
    // rỗng / PromptResult fallback) từ đầu, không phải lỗi mới do tôi gây ra.
    // Thêm hàm init() còn thiếu này để đúng như MangaPipeline đang mong đợi.
    suspend fun init() = withContext(Dispatchers.IO) {
        if (useExternal) return@withContext  // dùng API ngoài -> khỏi nạp model local
        if (ctx != 0L) return@withContext
    // SỬA (yêu cầu bỏ giới hạn panel/chương): 2048 quá chật để chứa cả
    // prompt input LẪN toàn bộ JSON output khi panelCount lớn. Nâng lên
    // 4096 — hầu hết model .gguf nhỏ chạy trên điện thoại (Qwen/Phi/Gemma
    // cỡ 1-4B thường dùng cho use-case này) đều hỗ trợ tối thiểu 4096 qua
    // RoPE của kiến trúc gốc, nhưng KHÔNG phải model nào cũng chắc chắn —
    // nếu model cụ thể bạn dùng không hỗ trợ, llamaInit() sẽ báo lỗi rõ
    // ràng (ctx=0) thay vì âm thầm sai. Kết hợp với chunked generation ở
    // parseStory() bên dưới — 2 lớp phòng thủ thay vì chỉ dựa vào 1 con số.
        ctx = NativeBridge.llamaInit(modelPath, nThreads, 4096, nGpuLayers)
        if (ctx == 0L) throw RuntimeException(
            "Không load được LLM tại $modelPath.\n(xem logcat tag MangaLocal để biết lý do cụ thể)")
    }

    // Dịch mô tả tự nhiên (tiếng Việt, user tự viết) sang tag SD1.5, riêng
    // theo từng giai đoạn (mục 24 TECHNICAL_STATUS.md — theo đúng yêu cầu
    // "1 setting áp dụng riêng từng giai đoạn + 1 setting riêng từng ảnh").
    // worldRules: quy tắc bối cảnh chung của Story (Story.worldRules) — LLM
    // dùng làm ngữ cảnh nền, KHÔNG lặp lại nguyên văn vào prompt (tránh
    // prompt quá dài) — chỉ dùng để hiểu đúng ý khi dịch.
    suspend fun translateStagePrompt(
        naturalDescription: String, stage: PromptStage, worldRules: String, styleHint: String,
        promptGuideNotes: String = "", promptStyle: PromptStyle = PromptStyle.TAG_BASED
    ): PromptResult = withContext(Dispatchers.IO) {
        val raw = generate(stageTranslatePrompt(naturalDescription, stage, worldRules, styleHint, promptGuideNotes, promptStyle), 350, 0.15f)
        extractStageTranslation(raw)
    }

    private fun stageTranslatePrompt(
        desc: String, stage: PromptStage, worldRules: String, styleHint: String, promptGuideNotes: String,
        promptStyle: PromptStyle = PromptStyle.TAG_BASED
    ): String {
        // mục 93 — mỗi stage cần hướng dẫn HƠI khác nhau tuỳ luật nền đang
        // chọn (vd UPSCALE_REDRAW: "trả về TAG chất lượng" vs "trả về CỤM
        // TỪ MÔ TẢ chất lượng") — tách theo cả stage LẪN promptStyle.
        val isTag = promptStyle == PromptStyle.TAG_BASED
        val stageGuide = when (stage) {
            PromptStage.TXT2IMG ->
                if (isTag) "Dịch ĐẦY ĐỦ mô tả cảnh sau sang tag SD1.5 (bối cảnh, nhân vật, hành động, camera, ánh sáng)."
                else "Dịch ĐẦY ĐỦ mô tả cảnh sau sang câu văn mô tả tiếng Anh mạch lạc (bối cảnh, nhân vật, hành động, camera, ánh sáng)."
            PromptStage.UPSCALE_REDRAW ->
                if (isTag)
                    "Đây là bước upscale-vẽ-lại (KHÔNG phải sinh cảnh mới) — bố cục ảnh gốc đã đúng, KHÔNG mô tả " +
                    "lại toàn cảnh. Chỉ trả về tag về CHẤT LƯỢNG BỀ MẶT/CHI TIẾT (vd \"detailed skin texture, " +
                    "sharp focus, fine details\"), tối đa 15 từ, không nhắc lại nhân vật/hành động."
                else
                    "Đây là bước upscale-vẽ-lại (KHÔNG phải sinh cảnh mới) — bố cục ảnh gốc đã đúng, KHÔNG mô tả " +
                    "lại toàn cảnh. Chỉ trả về 1 cụm mô tả NGẮN về chất lượng bề mặt/chi tiết (vd \"with detailed " +
                    "skin texture and sharp fine details\"), tối đa 15 từ, không nhắc lại nhân vật/hành động."
            PromptStage.INPAINT ->
                if (isTag)
                    "Đây là bước inpaint 1 VÙNG LỖI cụ thể (KHÔNG phải toàn ảnh) — CHỈ mô tả đúng hành động/chi " +
                    "tiết của vùng đang sửa, KHÔNG lặp lại mô tả toàn cảnh, KHÔNG nhắc bối cảnh/màu tóc/trang phục " +
                    "không liên quan trực tiếp vùng lỗi."
                else
                    "Đây là bước inpaint 1 VÙNG LỖI cụ thể (KHÔNG phải toàn ảnh) — CHỈ mô tả đúng hành động/chi " +
                    "tiết của vùng đang sửa bằng câu văn ngắn mạch lạc, KHÔNG lặp lại mô tả toàn cảnh, KHÔNG nhắc " +
                    "bối cảnh/màu tóc/trang phục không liên quan trực tiếp vùng lỗi."
        }
        val rulesBlock = if (worldRules.isNotBlank()) "\nBối cảnh chung của truyện (chỉ để HIỂU ý, đừng chép nguyên văn): $worldRules\n" else ""
        // Ghi chú riêng của user về CÁCH VIẾT PROMPT cho checkpoint đang
        // dùng (mục 54) — LỚP TINH CHỈNH THÊM trên luật nền đã chọn theo
        // promptStyle (mục 93), KHÔNG thay thế việc chọn đúng luật nền —
        // 2 cơ chế bổ trợ nhau: promptStyle chọn ĐÚNG LOẠI luật (tag hay
        // câu văn), promptGuideNotes tinh chỉnh CHI TIẾT trong loại đó (vd
        // 2 checkpoint cùng tag-based nhưng khác quy ước đặt tên).
        val guideNotesBlock = if (promptGuideNotes.isNotBlank())
            "\nGhi chú riêng của user về cách viết prompt cho checkpoint đang dùng (áp dụng CÙNG với quy tắc ở trên, không thay thế): $promptGuideNotes\n"
        else ""
        val baseGuide = if (isTag) TAG_BASED_GUIDE else NATURAL_LANGUAGE_GUIDE
        return """
$baseGuide

$stageGuide
Return ONLY JSON, no markdown: {"positive":"...","negative":"..."}
Style: $styleHint
$rulesBlock$guideNotesBlock
Mô tả cần dịch (tiếng Việt): $desc
""".trimIndent()
    }

    private fun extractStageTranslation(raw: String): PromptResult {
        return try {
            val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
            val o = JSONObject(if (s != -1 && e > s) raw.substring(s, e + 1) else raw.trim())
            PromptResult(o.getString("positive"), o.optString("negative", ""), null, "any")
        } catch (ex: Exception) {
            PromptResult(raw.trim().take(200), "", null, "any")
        }
    }


    // ipAdapterCharacterNames: tên các nhân vật ĐÃ được set anchorImagePath
    // (đã có sẵn trong Story TRƯỚC lúc gọi, ví dụ user tự thêm qua
    // CharactersScreen từ trước) — mỗi người trong nhóm này chỉ neo được
    // ngoại hình khi là NGƯỜI DUY NHẤT trong nhóm xuất hiện ở 1 panel (xem
    // TECHNICAL_STATUS.md mục 12). Đây là gợi ý MỀM cho LLM lúc viết kịch
    // bản — không ép buộc cốt truyện, vì nhiều khi 2 nhân vật BẮT BUỘC phải
    // gặp nhau. detectIpAdapterConflicts() ở StoryManager mới là nơi phát
    // hiện THẬT SỰ đáng tin (đếm code Kotlin, không dựa vào LLM có nghe lời
    // hay không).
    // SỬA (yêu cầu bỏ giới hạn panel/chương — bỏ trần UI mà vẫn bị chặn
    // ngầm bởi ngân sách token thì vô nghĩa, đúng như user chỉ ra): thay vì
    // xin LLM viết TOÀN BỘ panelCount panel trong 1 lần gọi (dễ vượt ngân
    // sách token khi panelCount lớn, JSON bị cắt giữa chừng), giờ CHIA NHỎ
    // thành từng đợt tối đa BATCH_SIZE panel/lần gọi, lặp lại tới khi đủ.
    // Mỗi đợt vẫn nằm an toàn trong ngân sách token (4096 ctx ở init()),
    // nên panelCount lớn cỡ nào cũng chỉ tốn nhiều LẦN GỌI hơn (chậm hơn),
    // không còn bị cắt JSON nữa — đây là fix THẬT, không phải chỉ bỏ số
    // trên UI cho có.
    private val BATCH_SIZE = 12

    suspend fun parseStory(
        text: String, panelCount: Int, ipAdapterCharacterNames: List<String> = emptyList(),
        storyGuidance: String = ""
    ): List<Scene> = withContext(Dispatchers.IO) {
        if (panelCount <= BATCH_SIZE) {
            val raw = generate(
                scenePrompt(text, panelCount, ipAdapterCharacterNames, storyGuidance, 0), 1800, 0.1f
            )
            return@withContext parseScenes(raw, panelCount, startIndex = 0)
        }
        // panelCount lớn hơn 1 đợt an toàn -> chia nhiều lần gọi. Mỗi đợt
        // vẫn được cho xem TOÀN BỘ story text + hướng dẫn (để LLM hiểu mạch
        // truyện xuyên suốt), chỉ khác startIndex/số panel cần viết trong
        // đợt đó — tránh lặp lại y hệt các panel đã viết ở đợt trước.
        val allScenes = mutableListOf<Scene>()
        var remaining = panelCount
        var startIndex = 0
        while (remaining > 0) {
            val thisBatch = remaining.coerceAtMost(BATCH_SIZE)
            val raw = generate(
                scenePrompt(text, thisBatch, ipAdapterCharacterNames, storyGuidance, startIndex, allScenes), 1800, 0.1f
            )
            allScenes += parseScenes(raw, thisBatch, startIndex = startIndex)
            startIndex += thisBatch
            remaining -= thisBatch
        }
        allScenes
    }

    /**
     * mục 154 TECHNICAL_STATUS.md — "đảo pipeline nhân vật" — bước phân
     * tích SƠ BỘ, RẺ (maxTokens thấp hơn hẳn parseStory, KHÔNG chia panel
     * chi tiết) để phát hiện tên + vai trò ước lượng + mô tả 1 dòng của
     * từng nhân vật, cho user xác nhận TRƯỚC khi tốn 1 lượt LLM đầy đủ viết
     * kịch bản panel-by-panel. [existingNames] — nhân vật ĐÃ có trong
     * truyện (chương trước) — loại khỏi kết quả, không hỏi lại cái đã biết.
     *
     * GIỚI HẠN THẬT: đây là bước LLM RIÊNG, độc lập hoàn toàn với
     * parseStory() sau đó (2 lượt gọi LLM khác nhau, không chia sẻ context)
     * — role/mô tả suy luận ở đây có thể KHÔNG khớp 100% cách parseStory()
     * dùng nhân vật đó (vd LLM ở bước này đoán 1 nhân vật là ONETIME nhưng
     * bước sau lại cho xuất hiện nhiều panel) — đây là ĐÁNH ĐỔI CHẤP NHẬN
     * ĐƯỢC (user xem trước là gợi ý, tự sửa vai trò thật ở CharactersScreen
     * bất kỳ lúc nào sau đó, không phải giá trị cố định), không phải bug.
     * Lỗi parse JSON (model yếu/lỗi) -> trả danh sách RỖNG, KHÔNG tự chế
     * nhân vật giả — ViewModel tự hiểu rỗng = bỏ qua bước xác nhận, rơi về
     * luồng cũ (tạo nhân vật sau khi parseStory() xong, đúng hành vi TRƯỚC
     * mục 154, không có gì tệ hơn hiện tại).
     */
    suspend fun extractCharacterSummary(text: String, existingNames: List<String> = emptyList()): List<CharacterSummary> =
        withContext(Dispatchers.IO) {
            val raw = generate(characterSummaryPrompt(text, existingNames), 500, 0.1f)
            parseCharacterSummaries(raw)
        }

    suspend fun buildPrompt(
        scene: Scene,
        charPrompts: Map<String, String>,
        stylePrompt: String,
        availablePoseTemplates: List<String> = emptyList(),
        worldRules: String = "", // mục 24 TECHNICAL_STATUS.md — quy tắc bối cảnh chung, đồng bộ với 2 giai đoạn còn lại
        templateTags: Map<String, List<String>> = emptyMap(), // mục 6.4/34 — nhãn tương tác user tự gắn, giúp LLM chọn tư thế khớp kịch bản hơn
        promptGuideNotes: String = "", // mục 54 — ghi chú riêng user về cách viết tag cho checkpoint SD1.5 đang dùng
        conceptDictText: String = "", // mục 78 — Concept Dictionary, xem ConceptDictionary.buildInjectionText()
        promptStyle: PromptStyle = PromptStyle.TAG_BASED, // mục 93 — kiểu prompt checkpoint đang active mong đợi
        // true khi GenerationSettings.ipDecayFloor < 1.0 (Smooth Timestep
        // Decay IP-Adapter đang BẬT cho panel này, xem Models.kt) — chỉ
        // dùng để NHẤN MẠNH THÊM cụm biểu cảm (đặt gần đầu hơn, gợi ý tăng
        // trọng số) vì decay tạo ra "khoảng trống" cuối step để biểu cảm
        // thắng identity-lock — KHÔNG đổi gì khác trong prompt. false =
        // hành vi y hệt trước khi có decay.
        ipAdapterDecayActive: Boolean = false
    ): PromptResult =
        withContext(Dispatchers.IO) {
            val charDesc = scene.characters.mapNotNull { charPrompts[it] }.joinToString(", ")
            val raw = generate(
                promptTemplate(scene, charDesc, stylePrompt, availablePoseTemplates, worldRules, templateTags,
                    promptGuideNotes, conceptDictText, promptStyle, ipAdapterDecayActive), 400, 0.2f
            )
            extractPrompts(raw, scene, stylePrompt, availablePoseTemplates)
        }

    /**
     * Phân tích tất cả nhân vật xuất hiện trong scenes, đếm tần suất
     * để StoryManager tự động phân loại MAIN/SUPPORTING/ONETIME
     */
    fun extractCharacterFrequency(scenes: List<Scene>): Map<String, Int> {
        val freq = mutableMapOf<String, Int>()
        scenes.forEach { scene ->
            scene.characters.forEach { name ->
                freq[name] = (freq[name] ?: 0) + 1
            }
        }
        return freq
    }

    fun free() { if (!useExternal && ctx != 0L) { NativeBridge.llamaFree(ctx); ctx = 0 } }

    // ── Templates ─────────────────────────────────────────────────────────

    private fun scenePrompt(
        text: String, count: Int, ipAdapterCharacterNames: List<String>, storyGuidance: String = "",
        startIndex: Int = 0, previousScenes: List<Scene> = emptyList()
    ): String {
        val ipaBlock = if (ipAdapterCharacterNames.isNotEmpty())
            "\nLƯU Ý: các nhân vật sau chỉ giữ được ngoại hình nhất quán khi họ là NGƯỜI DUY NHẤT " +
                "thuộc nhóm này xuất hiện trong 1 panel: ${ipAdapterCharacterNames.joinToString(", ")}. " +
                "Khi có thể, TRÁNH để 2+ người trong nhóm này cùng xuất hiện chung 1 panel — tách thành " +
                "2 panel liên tiếp nếu hợp lý. Nếu cốt truyện THẬT SỰ cần họ gặp nhau cùng lúc, cứ viết " +
                "bình thường, đừng bẻ cong nội dung truyện chỉ để né việc này.\n"
        else ""
        // Hướng dẫn kịch bản do user tự viết (văn phong, nhịp độ, thiết lập,
        // biến tấu/twist...) — GenerationSettings.llmStoryGuidance, xem
        // SettingsScreen.kt mục LLM. Rỗng = không áp thêm quy tắc gì, LLM tự
        // quyết như trước (giữ đúng hành vi cũ khi user chưa điền gì).
        val guidanceBlock = if (storyGuidance.isNotBlank())
            "\nHướng dẫn thêm từ tác giả về CÁCH VIẾT kịch bản (văn phong, nhịp độ, thiết lập, biến tấu...) " +
                "— áp dụng xuyên suốt truyện này, ưu tiên theo đúng tinh thần dưới đây khi viết description/" +
                "action/dialogue cho từng panel:\n$storyGuidance\n"
        else ""
        // Chia nhiều đợt (panelCount lớn, xem parseStory()) — tóm tắt NGẮN
        // các panel đã viết ở đợt trước để LLM nối mạch tiếp, không lặp lại
        // hoặc quên diễn biến. Chỉ tóm tắt (mood + action), không dán lại
        // nguyên văn description đầy đủ để không tốn thêm token input.
        val continuityBlock = if (previousScenes.isNotEmpty()) {
            val summary = previousScenes.takeLast(6).joinToString("\n") { s ->
                "- Panel ${s.index}: ${s.action.take(80)} (${s.mood})"
            }
            "\nCác panel ĐÃ VIẾT ở đợt trước (chỉ để nối mạch tiếp, KHÔNG lặp lại nội dung này, " +
                "bắt đầu viết từ panel index ${startIndex} trở đi):\n$summary\n"
        } else ""
        val indexNote = if (startIndex > 0)
            "\nĐây là phần TIẾP THEO của truyện (không phải từ đầu) — đánh số \"index\" bắt đầu từ " +
                "$startIndex (panel đầu tiên đợt này index=$startIndex, panel thứ 2 index=${startIndex + 1}, v.v.).\n"
        else ""
        return """
Split this story into exactly $count visual comic panels.
Return ONLY a JSON array, no markdown, no explanation.

[{"index":$startIndex,"description":"visual scene description","characters":["name1","name2"],"mood":"dark","cameraAngle":"medium-shot","action":"what happens","action_category":"embrace|combat|kiss|run|neutral","expression":"neutral|smile|sad|angry|surprised|scared|disgust|contempt|crying|smirk|determined|blush","setting":"location","dialogue":[{"character":"name1","text":"spoken words","type":"SPEECH"}],"depth_scale":{},"character_expressions":{}}]

Mood: dark|bright|tense|calm|dramatic|romantic|comedic|mysterious
Camera: extreme-close-up|close-up|medium-shot|wide-shot|overhead|low-angle
Dialogue type: SPEECH|THOUGHT|NARRATION|SHOUT
action_category: classify the physical action in "action" into EXACTLY ONE of embrace|combat|kiss|run|neutral
(embrace = hugging/holding each other closely, combat = fighting/hitting/wrestling, kiss = kissing,
run = running/fleeing/sprinting, neutral = anything else, including calm talking/standing/sitting).
Judge by MEANING, not just keywords — e.g. "hai người siết chặt lấy nhau trong nước mắt" is "embrace"
even without the literal word "ôm". If genuinely ambiguous, use "neutral".
expression: classify the DOMINANT facial expression of the main character(s) in this panel into EXACTLY ONE
of neutral|smile|sad|angry|surprised|scared|disgust|contempt|crying|smirk|determined|blush — judge by MEANING
from the whole scene (mood + action + dialogue tone), not just the literal word for the mood. E.g. mood "tense"
during a standoff before a fight is usually "determined" or "angry", not "neutral"; mood "romantic" during a
confession is often "blush" or "smile" depending on who is reacting; a character reacting to something vile or
morally repulsive is "disgust"; a character looking down on someone with cold superiority is "contempt". This
list is NOT exhaustive of every possible human emotion — if the true feeling is a complex mix (e.g. jealousy,
guilt, nostalgia) that doesn't cleanly fit any category, pick whichever ONE listed category is closest in
context rather than leaving it out; a close approximation is still more useful than none. If several characters
have different expressions, pick the one belonging to whoever the camera/description focuses on. If genuinely
ambiguous, use "neutral".
List ALL character names that appear, even minor ones.

depth_scale: OPTIONAL object mapping character name -> relative size multiplier
(1.0 = default, do not include unless needed). ONLY include a character here
when the scene TEXT explicitly implies a strong near/far camera distance
difference between characters in the SAME panel (e.g. "A đứng sát máy quay
trong khi B mờ dần phía xa", "cận cảnh khuôn mặt A, B chỉ là 1 bóng nhỏ
đằng sau") — e.g. {"A": 1.4, "B": 0.6}. This is a DIRECTOR/COMPOSITION
decision, NOT a character trait — leave this object EMPTY {} for the vast
majority of panels (normal medium/wide shots where everyone is at roughly
the same distance). Do not use this to express height differences between
characters (that is handled separately by each character's own body data).

character_expressions: OPTIONAL object mapping character name -> ONE of the same expression
values as the "expression" field above. Leave this object EMPTY {} for the vast majority of
panels (the shared top-level "expression" already covers 1-2 characters, or a group that all
share roughly the same mood). ONLY populate this when the panel genuinely needs 2+ characters
to show VISIBLY DIFFERENT dominant expressions at once — the clearest case is a multi-person
brawl/melee ("combat" with 3+ characters) where each participant has their own distinct
psychology (e.g. one is furious, one is terrified, one is smirking with contempt). Characters
NOT listed here still use the shared "expression" as their default — you do not need to list
every character, only the ones whose expression genuinely differs from that shared default.
This only has real effect when the app's Multi-Pass Cascade renders each character in an
isolated pass; for ordinary 1-2 person panels, leave it empty and rely on "expression".

LƯU Ý VỀ CAMERA khi 2+ nhân vật chạm thân thể trực tiếp (ôm, vật nhau, đánh
nhau tay đôi, kéo/giằng co...): ưu tiên "wide-shot" hoặc "overhead" thay vì
"close-up"/"extreme-close-up" — khung rộng cho model nhiều không gian hơn để
vẽ tách bạch 2 thân người, giảm (KHÔNG loại bỏ hẳn) rủi ro dính/lẫn tay chân
khi render. Đây chỉ là giảm nhẹ, không phải giải pháp triệt để — cảnh chạm
thân thể sát vẫn là trường hợp khó nhất của SD nói chung, có thể vẫn cần sửa
tay ở bước Gallery Review. KHÔNG đổi nội dung/action của cảnh chỉ để né việc
này — chỉ đổi cameraAngle khi hợp lý với ý truyện.
$ipaBlock
$guidanceBlock
$continuityBlock
$indexNote
Story:
$text
""".trimIndent()
    }

    // Gợi ý rủi ro cụ thể theo thuộc tính scene — để LLM không chỉ lặp lại
    // 1 câu negative chung chung, mà thực sự nghĩ đến lỗi SD1.5 hay gặp
    // trong tình huống NÀY. Đây là phần "mở rộng" đã ghi ở mục 6.3 —
    // heuristic gợi ý, không phải quy tắc cứng, LLM vẫn tự quyết câu chữ.
    private val contactKeywords = listOf(
        "ôm", "hug", "vật nhau", "vật lộn", "grapple", "wrestl", "đánh nhau", "fight",
        "đấm", "punch", "kéo", "giằng", "ghì", "siết", "đè", "pin down", "tay đôi"
    )

    private fun negativeRiskHints(scene: Scene): List<String> {
        val hints = mutableListOf<String>()
        if (scene.characters.size >= 2) hints += "nhiều người đứng gần nhau dễ dính/lẫn tay chân, cân nhắc thêm từ khoá tránh thừa chi/dính người"
        if (scene.cameraAngle in listOf("extreme-close-up", "close-up")) hints += "cận mặt/tay dễ lỗi ngón tay, mắt lệch — cân nhắc thêm từ khoá tránh biến dạng ngón/mắt"
        if (scene.mood in listOf("dark", "tense", "mysterious")) hints += "cảnh tối dễ bị SD kéo sáng bù — cân nhắc từ khoá tránh ánh sáng/không khí không hợp tông tối"
        if (scene.cameraAngle == "wide-shot" || scene.cameraAngle == "overhead") hints += "toàn cảnh dễ lộ nhân vật phụ bị biến dạng ở nền — cân nhắc từ khoá tránh người/vật thể nền bị méo"
        // Chạm thân thể trực tiếp (ôm/vật/đánh nhau tay đôi...) — rủi ro
        // dính người NẶNG NHẤT trong tất cả các trường hợp, kể cả với
        // wide-shot/overhead đã ưu tiên từ scenePrompt(). KHÔNG có cách giải
        // quyết triệt để (đã bàn với user) — đây chỉ là giảm nhẹ thêm ở tầng
        // prompt, không phải fix thật.
        val hasContact = scene.characters.size >= 2 &&
            contactKeywords.any { scene.action.contains(it, ignoreCase = true) || scene.description.contains(it, ignoreCase = true) }
        if (hasContact) hints += "2 người chạm thân thể trực tiếp (ôm/vật/đánh nhau) — RỦI RO DÍNH NGƯỜI CAO NHẤT, " +
            "cân nhắc thêm từ khoá tránh dính liền cơ thể/thừa chi/tay chân sai vị trí; nhắc rõ ranh giới 2 cơ thể trong positive prompt nếu có thể (vd \"two distinct bodies, clear silhouette separation\")"
        return hints
    }

    // Hardcode CỨNG (không chỉ gợi ý cho LLM — LLM có thể quên) — theo đúng
    // đề xuất user: bộ negative chuyên trị dính người/giải phẫu dị thường,
    // TỰ ĐỘNG nối vào MỌI lần sinh có ≥2 người, người dùng không cần gõ.
    // Chỉ áp dụng CÓ ĐIỀU KIỆN (không phải mọi ảnh) — panel 1 người không
    // cần cụm từ "conjoined twins" làm loãng negative prompt, đúng khuyến
    // nghị chung "negative prompt càng có mục tiêu càng tốt".
    private val hardcodedAntiFusionTerms =
        "fused bodies, deformed limbs, extra arms, extra legs, conjoined twins, monstrous body, messy anatomy, merged bodies"

    private fun appendHardcodedNegativeIfNeeded(scene: Scene, llmNegative: String): String {
        if (scene.characters.size < 2) return llmNegative
        // Tránh lặp nếu LLM đã tự viết đúng cụm này rồi (hiếm nhưng có thể xảy ra).
        return if (llmNegative.contains("fused bodies", ignoreCase = true)) llmNegative
        else "$llmNegative, $hardcodedAntiFusionTerms"
    }

    private fun promptTemplate(
        scene: Scene, charDesc: String, styleHint: String, availablePoseTemplates: List<String>,
        worldRules: String = "", templateTags: Map<String, List<String>> = emptyMap(),
        promptGuideNotes: String = "", conceptDictText: String = "", promptStyle: PromptStyle = PromptStyle.TAG_BASED,
        ipAdapterDecayActive: Boolean = false
    ): String {
        val risks = negativeRiskHints(scene)
        val riskBlock = if (risks.isNotEmpty())
            "\nRủi ro cần lưu ý khi viết 'negative' cho CẢNH NÀY (không phải câu negative chung chung):\n" +
                risks.joinToString("\n") { "- $it" }
        else ""
        val worldRulesBlock = if (worldRules.isNotBlank())
            "\nBối cảnh chung của truyện (chỉ để HIỂU ý, đừng chép nguyên văn vào prompt): $worldRules\n"
        else ""
        // mục 93 TECHNICAL_STATUS.md — chọn luật nền theo checkpoint đang
        // active, xem giải thích đầy đủ ở PromptStyle (Models.kt)/
        // stageTranslatePrompt(). promptGuideNotes (mục 54, block ngay
        // trên) vẫn là lớp tinh chỉnh THÊM, không thay thế việc chọn đúng
        // luật nền này.
        val guideNotesBlock = if (promptGuideNotes.isNotBlank())
            "\nGhi chú riêng của user về cách viết prompt cho checkpoint đang dùng (áp dụng CÙNG với quy tắc ở trên, không thay thế): $promptGuideNotes\n"
        else ""
        // Mục 78 TECHNICAL_STATUS.md — Concept Dictionary: cặp [khái niệm
        // riêng ↔ SD tag] đã dùng ở chương trước, ép LLM dùng LẠI đúng bản
        // này thay vì tự dịch khác mỗi lần. conceptDictText rỗng nếu dict
        // trống hoặc tính năng tắt (ConceptDictionary.buildInjectionText()).
        val conceptDictBlock = if (conceptDictText.isNotBlank()) "\n$conceptDictText\n" else ""
        // Danh sách pose THẬT của user (từ pose_library.json, sinh bởi
        // extract_pose_library.py) — LLM chỉ được chọn trong danh sách này,
        // không được bịa tên. Rỗng thì báo "none", đừng đoán. Kèm actionTags
        // (mục 6.4/34 TECHNICAL_STATUS.md, user tự gắn lúc lưu) nếu có, giúp
        // LLM chọn khớp kịch bản hơn thay vì chỉ đoán theo tên.
        val poseBlock = if (availablePoseTemplates.isNotEmpty()) {
            val listWithTags = availablePoseTemplates.joinToString(", ") { name ->
                val tags = templateTags[name]
                if (!tags.isNullOrEmpty()) "$name [${tags.joinToString(",")}]" else name
            }
            "\nAvailable pose templates (choose the ONE that best matches the action/character " +
                "count above, or \"none\" if nothing fits — do NOT invent a name not in this list; " +
                "tags in [brackets] describe the interaction, use them to pick the best match):\n" +
                listWithTags
        } else "\nNo pose templates available yet — always answer poseTemplate:\"none\"."
        val baseGuide2 = if (promptStyle == PromptStyle.TAG_BASED) TAG_BASED_GUIDE else NATURAL_LANGUAGE_GUIDE

        // Kiến trúc phân loại biểu cảm (Scene.expression, mục "Smooth
        // Timestep Decay" mục 97 TECHNICAL_STATUS.md) — scene.expression đã được
        // LLM tự phân loại vào tập đóng NGAY LÚC VIẾT KỊCH BẢN (parseScenes,
        // field "expression"), TRA BẢNG ra tag cụ thể ở EXPRESSION_TAGS thay
        // vì để LLM bịa lại mỗi lần dịch prompt. null (model cũ/parse lỗi/
        // giá trị lạ) -> fallback về câu dặn chung chung CŨ (hành vi không
        // đổi so với trước khi có field này).
        val expressionBlock = if (scene.expression != null) {
            val tagSet = EXPRESSION_TAGS.getValue(scene.expression)
            val resolvedTag = if (promptStyle == PromptStyle.TAG_BASED) tagSet.tagBased else tagSet.naturalLanguage
            // ipAdapterDecayActive: xem docstring buildPrompt() — khi decay
            // BẬT, identity IP-Adapter yếu dần cuối step, nên biểu cảm CẦN
            // được nhấn mạnh hơn để thật sự "thắng" trong khoảng trống đó,
            // không chỉ có mặt cho có.
            val emphasisNote = if (ipAdapterDecayActive)
                "This panel uses IP-Adapter identity decay (character-reference lock fades in the later " +
                    "denoising steps) — the expression tag below is what actually gets to \"win\" during that " +
                    "window, so place it PROMINENTLY near the front of \"positive\" (not buried at the end), " +
                    "exactly as given, do not water it down."
            else
                "Place it near the front of \"positive\" (not buried at the end) — front tokens carry more " +
                    "weight for this checkpoint's text encoder (see rules above)."
            "\nCharacter expression for this panel has been classified as \"${scene.expression}\" — you MUST " +
                "include this EXACT phrase in \"positive\", adapted only for grammar/word order if needed but " +
                "keeping the same emphasis syntax and meaning: \"$resolvedTag\". $emphasisNote\n"
        } else {
            "\nThe \"positive\" field must include a concrete facial-expression / body-language detail matching " +
                "the mood (e.g. \"clenched jaw, narrowed eyes\" for tense, not just the word \"tense\" itself).\n"
        }

        // mục 104 — tra bảng bố cục khung hình cho scene.cameraAngle, cùng
        // nguyên tắc expressionBlock ở trên (tag cụ thể thay câu dặn chung
        // chung). scene.cameraAngle LUÔN nằm trong 1 trong 6 giá trị của
        // schema (không nullable, không như expression) nhưng vẫn kiểm tra
        // `in VALID_CAMERA_ANGLES` phòng model cũ/dữ liệu lạ trả giá trị
        // khác — rơi về câu dặn chung chung nếu không khớp, không crash.
        val compositionBlock = if (scene.cameraAngle in VALID_CAMERA_ANGLES) {
            val compTagSet = CAMERA_COMPOSITION_TAGS.getValue(scene.cameraAngle)
            val resolvedComp = if (promptStyle == PromptStyle.TAG_BASED) compTagSet.tagBased else compTagSet.naturalLanguage
            "\nCamera/composition for this panel has been classified as \"${scene.cameraAngle}\" — you MUST " +
                "include this EXACT phrase in \"positive\" (adapted only for grammar/word order if needed, keep " +
                "the same emphasis syntax and meaning): \"$resolvedComp\".\n"
        } else {
            "\nThe \"positive\" field must include a concrete framing/composition detail matching the camera " +
                "angle \"${scene.cameraAngle}\" (e.g. how much of the character is visible, how much background " +
                "is shown), not just naming the angle itself.\n"
        }

        return """
$baseGuide2

Write a Stable Diffusion prompt for this comic panel.
Return ONLY JSON, no markdown: {"positive":"...","negative":"...","poseTemplate":"...","poseAngle":"front|side_left|side_right|any","new_concepts":[{"concept":"...","tag":"..."}]}

Scene: ${scene.description}
Action: ${scene.action}
Setting: ${scene.setting}
Mood: ${scene.mood}
Camera: ${scene.cameraAngle}
Characters: $charDesc
Style: $styleHint
$worldRulesBlock$guideNotesBlock$conceptDictBlock
$riskBlock
The "negative" field must be SPECIFIC to this scene's actual risks above (in English,
comma-separated SD keywords), not a generic list. Keep it under 25 words.
new_concepts: if this scene mentions any PROPER NOUN specific to this story (a named weapon,
place, technique/skill, or object — NOT a generic noun) that you had to invent an English SD tag
for, AND it is not already listed in the fixed concept dictionary above, list it here as
{"concept": the original name exactly as written in the scene, "tag": the exact English tag
phrase you used for it in "positive"} so future panels reuse the same tag instead of inventing a
new one. Most scenes have NO such concept — return an empty array [] in that case, do not force an
entry. Do not list generic character names or common nouns, only distinctive named things.
$expressionBlock
$compositionBlock
$poseBlock
""".trimIndent()
    }

    // ── Parsers ───────────────────────────────────────────────────────────

    // mục 154 TECHNICAL_STATUS.md — prompt RIÊNG, NGẮN hơn scenePrompt() rất
    // nhiều (không cần chia panel/pose/expression — chỉ cần danh sách tên +
    // vai trò ước lượng + mô tả ngắn). "vai trò ước lượng" dựa trên TẦN SUẤT
    // xuất hiện dự đoán qua đọc lướt văn bản — cùng logic MAIN/SUPPORTING/
    // ONETIME đã dùng ở StoryManager.suggestConsistencyMethod(), chỉ khác
    // là LLM tự đoán ở đây thay vì đếm thật sau khi có scenes.
    private fun characterSummaryPrompt(text: String, existingNames: List<String>): String {
        val existingBlock = if (existingNames.isNotEmpty())
            "\nĐã biết trước (KHÔNG liệt kê lại các tên này, chỉ liệt kê nhân vật MỚI chưa có trong danh sách này): ${existingNames.joinToString(", ")}."
        else ""
        return """Đọc đoạn truyện dưới đây, liệt kê TỪNG NHÂN VẬT CÓ TÊN xuất hiện (bỏ qua nhân vật quần chúng không tên).
Với mỗi nhân vật, ước lượng vai trò dựa trên mức độ xuất hiện/quan trọng trong đoạn truyện:
- "MAIN": nhân vật chính, xuất hiện nhiều, trung tâm cốt truyện.
- "SUPPORTING": nhân vật phụ, xuất hiện vài lần, có vai trò rõ ràng.
- "ONETIME": chỉ xuất hiện thoáng qua 1 lần, không quan trọng.
Và viết 1 câu ngắn (dưới 20 từ) mô tả ngoại hình/đặc điểm nhận dạng nếu văn bản có nhắc tới (để trống "" nếu văn bản không mô tả gì).$existingBlock

CHỈ trả về JSON array, không giải thích gì thêm, đúng format:
[{"name":"Tên nhân vật","role":"MAIN","description":"mô tả ngắn hoặc rỗng"}]

Văn bản truyện:
$text"""
    }

    private fun parseCharacterSummaries(raw: String): List<CharacterSummary> {
        return try {
            val s = raw.indexOf('['); val e = raw.lastIndexOf(']')
            val arr = JSONArray(if (s != -1 && e > s) raw.substring(s, e + 1) else raw.trim())
            (0 until arr.length()).mapNotNull { i ->
                try {
                    val o = arr.getJSONObject(i)
                    val name = o.optString("name", "").trim()
                    if (name.isBlank()) return@mapNotNull null
                    val role = try { CharacterRole.valueOf(o.optString("role", "SUPPORTING").uppercase()) }
                        catch (ex: Exception) { CharacterRole.SUPPORTING }
                    CharacterSummary(name, role, o.optString("description", "").trim())
                } catch (ex: Exception) { null }
            }.distinctBy { it.name.lowercase() }
        } catch (e: Exception) {
            emptyList()  // xem GIỚI HẠN THẬT ở extractCharacterSummary() — rỗng, KHÔNG tự chế
        }
    }


    private fun parseScenes(raw: String, count: Int, startIndex: Int = 0): List<Scene> {
        return try {
            val s = raw.indexOf('['); val e = raw.lastIndexOf(']')
            val arr = JSONArray(if (s != -1 && e > s) raw.substring(s, e + 1) else raw.trim())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val chars = o.optJSONArray("characters")
                    ?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
                val dialogue = o.optJSONArray("dialogue")
                    ?.let { a -> (0 until a.length()).mapNotNull { j ->
                        try {
                            val d = a.getJSONObject(j)
                            DialogueLine(d.getString("character"), d.getString("text"),
                                enumValueOf(d.optString("type", "SPEECH")))
                        } catch (ex: Exception) { null }
                    }} ?: emptyList()
                // action_category: field mới LLM tự trả (mục 85
                // TECHNICAL_STATUS.md) — optString trả "" nếu model cũ/lỗi
                // không có field này, Scene.actionCategory nhận "" thay vì
                // null trong trường hợp đó; SeedRegistry.resolveActionCategory()
                // đã tự xử lý "" (không nằm trong VALID_CATEGORIES) bằng
                // cách rơi về heuristic — không cần convert "" -> null ở
                // đây, giữ code đơn giản.
                // expression: field mới (kiến trúc phân loại biểu cảm, xem
                // EXPRESSION_TAGS/Scene.expression) — cùng nguyên tắc dung
                // thứ với action_category: optString trả "" nếu model
                // cũ/lỗi không có field này; "" không nằm trong
                // VALID_EXPRESSIONS nên rơi về null qua takeIf bên dưới,
                // buildPrompt() tự fallback về câu dặn chung chung cũ.
                val rawExpression = o.optString("expression", "")
                // mục 121 TECHNICAL_STATUS.md — depth_scale: object tuỳ
                // chọn, optJSONObject trả null nếu model cũ/lỗi không có
                // field này -> map rỗng (hành vi CŨ, không đổi gì). Lọc bỏ
                // giá trị <= 0 (vô nghĩa vật lý, coi như model trả bậy) và
                // giá trị NaN/vô cực (JSON không hợp lệ nhưng optDouble có
                // thể trả NaN nếu key tồn tại nhưng value không phải số).
                val depthScaleMap = o.optJSONObject("depth_scale")?.let { dobj ->
                    val m = mutableMapOf<String, Float>()
                    dobj.keys().forEach { key ->
                        val v = dobj.optDouble(key, 1.0).toFloat()
                        if (v > 0f && v.isFinite()) m[key] = v
                    }
                    m
                } ?: emptyMap()
                // mục 168 TECHNICAL_STATUS.md — character_expressions: CÙNG
                // khuôn mẫu depth_scale ngay trên (object tuỳ chọn,
                // optJSONObject trả null nếu model cũ/lỗi không có field
                // này -> map rỗng, hành vi CŨ 100%). Lọc value không nằm
                // trong VALID_EXPRESSIONS (LLM bịa/gõ sai enum) — entry hỏng
                // bị BỎ QUA thay vì làm hỏng cả object, đúng nguyên tắc dung
                // thứ đã áp dụng cho `rawExpression` ở trên. KHÔNG lọc theo
                // `chars` (danh sách nhân vật của scene) ở đây — cố tình để
                // MangaPipeline.runMultiPassCascade() tự bỏ qua tên không
                // khớp `sceneChars[i]` lúc dùng, tránh 2 nơi phải đồng bộ
                // định nghĩa "tên hợp lệ".
                val characterExpressionsMap = o.optJSONObject("character_expressions")?.let { ceObj ->
                    val m = mutableMapOf<String, String>()
                    ceObj.keys().forEach { key ->
                        val v = ceObj.optString(key, "")
                        if (v in VALID_EXPRESSIONS) m[key] = v
                    }
                    m
                } ?: emptyMap()
                Scene(startIndex + i, o.optString("description","Scene ${startIndex + i + 1}"), chars,
                    o.optString("mood","neutral"), o.optString("cameraAngle","medium-shot"),
                    o.optString("action",""), o.optString("setting",""), dialogue,
                    o.optString("action_category", ""),
                    rawExpression.takeIf { it in VALID_EXPRESSIONS },
                    depthScaleMap,
                    characterExpressions = characterExpressionsMap)
            }
        } catch (e: Exception) {
            val chunk = (raw.length / count).coerceAtLeast(1)
            raw.chunked(chunk).take(count).mapIndexed { i, s ->
                Scene(startIndex + i, s.take(120), emptyList(), "neutral", "medium-shot")
            }
        }
    }

    private fun extractPrompts(
        raw: String, scene: Scene, style: String, availablePoseTemplates: List<String>
    ): PromptResult {
        return try {
            val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
            val o = JSONObject(if (s != -1 && e > s) raw.substring(s, e + 1) else raw.trim())
            val rawPose = o.optString("poseTemplate", "none")
            // KHÔNG tin thẳng — LLM có thể bịa tên không tồn tại trong
            // pose_library.json thật. Chỉ nhận nếu khớp CHÍNH XÁC 1 key có
            // thật trong danh sách; sai/rỗng/"none" đều -> null (để
            // MangaPipeline tự rơi về fallback heuristic).
            val pose = rawPose.takeIf { it.isNotBlank() && it != "none" && it in availablePoseTemplates }
            val angle = o.optString("poseAngle", "any").let {
                if (it in listOf("front", "side_left", "side_right", "any")) it else "any"
            }
            // new_concepts (mục 101) — parse DUNG THỨ: 1 entry lỗi format
            // không được làm hỏng toàn bộ PromptResult (positive/negative
            // vẫn quan trọng hơn nhiều) — bọc try riêng, bỏ qua entry hỏng.
            val newConcepts = try {
                val arr = o.optJSONArray("new_concepts")
                if (arr == null) emptyList() else buildList {
                    for (i in 0 until arr.length()) {
                        try {
                            val entry = arr.getJSONObject(i)
                            val concept = entry.optString("concept", "").trim()
                            val tag = entry.optString("tag", "").trim()
                            if (concept.isNotBlank() && tag.isNotBlank()) add(concept to tag)
                        } catch (_: Exception) { /* bỏ qua entry hỏng, không phá cả list */ }
                    }
                }
            } catch (_: Exception) { emptyList() }
            PromptResult(o.getString("positive"), appendHardcodedNegativeIfNeeded(scene, o.getString("negative")), pose, angle, newConcepts)
        } catch (ex: Exception) {
            PromptResult(
                "${scene.description}, ${scene.mood} mood, ${scene.cameraAngle}, $style",
                appendHardcodedNegativeIfNeeded(scene, "bad quality, blurry, deformed"),
                null, "any"
            )
        }
    }
}
