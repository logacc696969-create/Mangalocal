package com.mangalocal.pipeline

import java.io.File

/**
 * mục 280 TECHNICAL_STATUS.md — lớp nối Android cho BlazePose GHUM 3D: tải model qua NativeBridge (blazepose_wrapper.cpp, MNN CPU) và chạy MỘT người đã cắt ROI.
 * Toàn bộ phần toán (ROI có xoay, cắt ảnh, ánh xạ ngược, 33 điểm → OpenPose-18, đặt z) nằm ở BlazePoseLift.kt — thuần Kotlin, ĐÃ chạy với model thật trên ảnh thật.
 * Lớp này chỉ giữ ngữ cảnh native và KHÔNG ném lỗi: thiếu model / lỗi native / người không rõ → trả null để PoseExtractor giữ nguyên khung xương cũ (z = 0).
 *
 * Model: blazepose_lite.mnn (~2,8 MB) và/hoặc blazepose_full.mnn (~6,4 MB — wrapper ưu tiên full) trong thư mục model (cùng chỗ yolov8_pose.mnn). Tạo bằng tools/export_blazepose.py
 * (workflow export_blazepose.yml) hoặc dùng tệp đã xuất sẵn.
 */
class BlazePoseEstimator(private val modelDir: File, private val openBundled: ((String) -> java.io.InputStream?)? = null) {
    private var ctx: Long = 0L
    private var initTried = false
    private var bundledTried = false

    /**
     * mục 281: chép model đóng trong APK (assets/blazepose/) ra [modelDir] nếu thư mục CHƯA có blazepose_*.mnn (xem BundledModels). Gọi trên luồng NỀN. Trả số tệp đã chép; 0 nếu đã có sẵn,
     * không có assets, hoặc lỗi ghi. Chỉ thử một lần mỗi lần chạy app (kể cả "Kiểm tra lại" sau đó không chép lại khi ghi đã hỏng).
     */
    @Synchronized
    fun copyBundledIfMissing(): Int {
        val open = openBundled ?: return 0
        if (bundledTried || isReady()) return 0
        bundledTried = true
        return BundledModels.copyIfNoneExist(modelDir, listOf("blazepose_lite.mnn", "blazepose_full.mnn"), open)
    }

    /** Có tệp model trong thư mục (chưa chắc nạp được — kiểm thật ở lần chạy đầu). */
    fun isReady(): Boolean = File(modelDir, "blazepose_full.mnn").exists() || File(modelDir, "blazepose_lite.mnn").exists()

    @Synchronized
    private fun ensureInit(): Boolean {
        if (ctx != 0L) return true
        if (initTried || !isReady()) return false      // đã thử và hỏng: không nạp lại mỗi người/khung hình
        initTried = true
        ctx = try { NativeBridge.blazePoseInit(modelDir.absolutePath) } catch (e: Throwable) { 0L }
        return ctx != 0L
    }

    /**
     * Trả BẢN SAO [person] (OpenPose-18, x/y chuẩn hoá theo ảnh) có z thật; null nếu không dựng được (thiếu model, ROI không dựng được, cờ "có người" thấp, không khớp được tỷ lệ).
     * [argb] = pixel ảnh (Bitmap.getPixels) w×h; [box] = hộp YOLO chuẩn hoá (x1, y1, x2, y2, …) dùng khi thiếu hông/vai để dựng ROI.
     */
    @Synchronized
    fun lift(argb: IntArray, w: Int, h: Int, person: List<StoryManager.PoseKeypoint>, box: FloatArray?): MutableList<StoryManager.PoseKeypoint>? {
        if (!ensureInit()) return null
        return try {
            val roi = BlazePoseLift.roiFromPerson(person, w, h, box) ?: return null
            val raw = NativeBridge.blazePoseRun(ctx, BlazePoseLift.sampleCrop(argb, w, h, roi))
            if (raw.size != BlazePoseLift.RESULT_FLOATS) return null
            val lifted = BlazePoseLift.parseOutput(raw, roi) ?: return null
            BlazePoseLift.depthFor(person, lifted, if (h > 0) w.toFloat() / h else 1f)   // mục 282: z đúng đơn vị với ảnh không vuông
        } catch (e: Throwable) { null }
    }

    fun close() {
        if (ctx != 0L) { try { NativeBridge.blazePoseFree(ctx) } catch (_: Throwable) {} ; ctx = 0L }
    }
}
