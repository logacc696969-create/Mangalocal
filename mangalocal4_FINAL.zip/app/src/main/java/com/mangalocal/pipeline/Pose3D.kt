package com.mangalocal.pipeline

import com.mangalocal.model.AgeBodyTable
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * mục 279 TECHNICAL_STATUS.md — VỊ TRÍ + GÓC NHÌN cho màn Tư thế (trước đây chỉ kéo được từng khớp trong mặt phẳng 2D: không dời/xoay/phóng/lật cả người, không có góc camera).
 * Thuần Kotlin (không Android) để biên dịch và chạy thử độc lập — xem tools/kotlin_tests/Pose3DTest.kt.
 *
 * (1) BIẾN ĐỔI CẢ NGƯỜI 2D: [translate], [scaleAbout], [roll], [mirror], [fitInside]. Tâm xoay/phóng = tâm hông. [mirror] hoán đổi cả nhãn trái–phải (vai P↔T, khuỷu, cổ tay, hông, gối, cổ chân,
 *     mắt, tai) chứ không chỉ lật x — nếu không "vai phải" sẽ nằm sai bên.
 * (2) DỰNG ĐỘ SÂU TỪ KHUNG XƯƠNG 2D: [reconstructDepth] theo Taylor (CVIU 2000, "Reconstruction of articulated objects from point correspondences in a single uncalibrated image"):
 *     dưới phép chiếu trực giao có tỷ lệ, một đoạn xương dài thật L (biết trước từ AgeBodyTable) mà trên ảnh chỉ dài l < s·L thì hai đầu lệch độ sâu dz = ±√((s·L)² − l²);
 *     s (tỷ lệ) lấy từ đoạn ít bị co nhất. ĐỘ MẬP MỜ KHÔNG THỂ BỎ: dấu ± của từng đoạn (ra trước hay ra sau camera) — một ảnh 2D không cho biết; mã chỉ ĐOÁN mặc định
 *     (tay và đùi ra trước camera, cẳng chân ra sau) và để người dùng lật từng chi ([FLIP_R_ARM]...). Đây là giả định của mình, không phải kết quả đo.
 *     Thêm hai ước lượng của mình: (a) vai/hông chỉ coi là xoay quanh trục dọc khi vai trên ảnh hẹp rõ rệt (< 70% bề rộng vai thật, tăng dần tới 30%), vì bề rộng vai thật (AgeBodyTable.shoulder)
 *     chỉ là ước lượng và khung xương tự vẽ thường có vai hẹp; (b) đầu: mô hình đầu chuẩn (mũi ra trước 0,9 bán kính, mắt 0,8, tai 0 và ±1 bán kính), xoay đầu suy từ độ lệch của mũi.
 * (3) CAMERA TRỰC GIAO [orbit]: quay quanh tâm hông (nhóm nhiều người: tâm chung, để giữ bố cục nhóm), cùng quy ước với thư viện poseorbit (Apache-2.0): +yaw đưa camera sang PHẢI người xem,
 *     +pitch nâng camera lên; giới hạn yaw ±90°, pitch ±45° (poseorbit đo thấy quá giới hạn này độ sâu từ một ảnh không còn đáng tin). Quy ước z của dự án: z NHỎ = GẦN camera.
 *
 * Đơn vị: x, y là phần của khung (0..1) như PoseKeypoint; z tính theo bề NGANG khung (như MediaPipe/poseorbit). Bên trong đổi sang đơn vị đẳng hướng (x·aspect, y, z·aspect), aspect = rộng/cao.
 * Chỉ số OpenPose BODY_18: 0 mũi, 1 cổ, 2/5 vai P/T, 3/6 khuỷu, 4/7 cổ tay, 8/11 hông P/T, 9/12 gối, 10/13 cổ chân, 14/15 mắt P/T, 16/17 tai P/T. "Phải" = bên phải của CHÍNH nhân vật
 * (nằm bên TRÁI ảnh khi nhân vật quay mặt về phía người xem).
 */
object Pose3D {
    const val MAX_YAW = 90f
    const val MAX_PITCH = 45f

    // cờ lật chiều sâu (bit): đảo hướng ra-trước/ra-sau của cả một chi hoặc chiều xoay của thân
    const val FLIP_R_ARM = 1
    const val FLIP_L_ARM = 2
    const val FLIP_R_LEG = 4
    const val FLIP_L_LEG = 8
    const val FLIP_TORSO = 16

    /** Dải z nhỏ hơn mức này coi như không có thông tin độ sâu. BẰNG `ContactDetector.Thresholds.Z_MEANINGFUL` (test_pose3d.py kiểm hai hằng số này khớp nhau). */
    const val Z_MEANINGFUL = 0.02f

    // CHỐNG NHIỄU (đo bằng `Pose3DTest --noise/--sweep`, mục 279.5): dz = √((sL)² − l²) có đạo hàm VÔ HẠN khi đoạn xương gần song song mặt ảnh (l → sL) nên nhiễu nhỏ của bộ phát hiện khớp
    // biến người đứng thẳng thành người "cúi/ngả" giả; và s lấy từ đoạn dài NHẤT bị đẩy lên theo nhiễu. Hai tham số dưới đây là kết quả dò, KHÔNG phải số có căn cứ lý thuyết:
    // biên 0,03·s cộng vào độ dài trên ảnh, và s = trung bình 5 tỷ lệ lớn nhất. Là thuộc tính công khai CHỈ để test/dò đổi giá trị — đừng đổi trong app.
    @JvmField var noiseMargin = 0.03f
    @JvmField var scaleTopK = 5

    private val MIRROR_PAIRS = listOf(2 to 5, 3 to 6, 4 to 7, 8 to 11, 9 to 12, 10 to 13, 14 to 15, 16 to 17)

    /** Có z thật (người dùng chỉnh tay hoặc nguồn có độ sâu) chưa: biên độ z của các khớp đang hiện ≥ [Z_MEANINGFUL] (0,02 bề ngang khung, cùng ngưỡng với ContactDetector). */
    fun hasDepth(p: List<StoryManager.PoseKeypoint>): Boolean {
        val zs = p.filter { it.visible }.map { it.z }
        return zs.isNotEmpty() && (zs.max() - zs.min()) >= Z_MEANINGFUL
    }

    /** Tâm hông nếu hai hông đều hiện; không thì trung bình các khớp đang hiện; không có khớp nào thì null. */
    fun pivot(p: List<StoryManager.PoseKeypoint>): Pair<Float, Float>? {
        if (p.size >= 12 && p[8].visible && p[11].visible) return (p[8].x + p[11].x) / 2f to (p[8].y + p[11].y) / 2f
        val v = p.filter { it.visible }
        if (v.isEmpty()) return null
        return v.map { it.x }.average().toFloat() to v.map { it.y }.average().toFloat()
    }

    // ───────────────────────── (1) biến đổi cả người 2D ─────────────────────────
    // Mỗi phép có bản NHÓM (nhiều người cùng quanh MỘT tâm chung = trung bình tâm hông, để giữ bố cục giữa các người) và bản MỘT người (gọi bản nhóm với một chỉ số).
    // Nếu không có gì đổi, trả đúng danh sách cũ (cùng đối tượng) để giao diện biết "không làm được".

    /** Tâm chung của các người ở [indices] (trung bình tâm hông); null nếu không có khớp nào hiện. */
    fun groupPivot(people: List<MutableList<StoryManager.PoseKeypoint>>, indices: List<Int>): Pair<Float, Float>? {
        val pv = indices.filter { it in people.indices }.mapNotNull { pivot(people[it]) }
        if (pv.isEmpty()) return null
        return pv.map { it.first }.average().toFloat() to pv.map { it.second }.average().toFloat()
    }

    private fun selectedVisible(people: List<MutableList<StoryManager.PoseKeypoint>>, indices: List<Int>) =
        indices.filter { it in people.indices }.flatMap { people[it].filter { k -> k.visible } }

    private fun mapSelected(
        people: List<MutableList<StoryManager.PoseKeypoint>>, indices: List<Int>, f: (MutableList<StoryManager.PoseKeypoint>) -> MutableList<StoryManager.PoseKeypoint>
    ) = people.mapIndexed { i, p -> if (i in indices) f(p) else p }

    /** Dời các người đã chọn. Không cho khung xương đi XA THÊM ra ngoài khung [0,1] (đang nằm trong thì giữ trong; đã lòi ra thì chỉ được dời vào). */
    fun translateGroup(people: List<MutableList<StoryManager.PoseKeypoint>>, indices: List<Int>, dx: Float, dy: Float): List<MutableList<StoryManager.PoseKeypoint>> {
        val v = selectedVisible(people, indices)
        if (v.isEmpty()) return people
        val minX = v.minOf { it.x }; val maxX = v.maxOf { it.x }; val minY = v.minOf { it.y }; val maxY = v.maxOf { it.y }
        val ddx = dx.coerceIn(min(0f, -minX), max(0f, 1f - maxX))
        val ddy = dy.coerceIn(min(0f, -minY), max(0f, 1f - maxY))
        return mapSelected(people, indices) { p -> p.map { if (it.visible) it.copy(x = it.x + ddx, y = it.y + ddy) else it }.toMutableList() }
    }
    fun translate(p: MutableList<StoryManager.PoseKeypoint>, dx: Float, dy: Float): MutableList<StoryManager.PoseKeypoint> =
        translateGroup(listOf(p), listOf(0), dx, dy)[0]

    /** Dời tâm chung về (cx, cy) (mặc định giữa khung), cùng ràng buộc như [translateGroup]. */
    fun centerGroup(people: List<MutableList<StoryManager.PoseKeypoint>>, indices: List<Int>, cx: Float = 0.5f, cy: Float = 0.5f): List<MutableList<StoryManager.PoseKeypoint>> {
        val pv = groupPivot(people, indices) ?: return people
        return translateGroup(people, indices, cx - pv.first, cy - pv.second)
    }
    fun centerTo(p: MutableList<StoryManager.PoseKeypoint>, cx: Float = 0.5f, cy: Float = 0.5f): MutableList<StoryManager.PoseKeypoint> =
        centerGroup(listOf(p), listOf(0), cx, cy)[0]

    /** Phóng/thu quanh tâm chung. Phóng to bị giới hạn để không đẩy thêm khớp ra ngoài khung; thu nhỏ luôn được. */
    fun scaleGroup(people: List<MutableList<StoryManager.PoseKeypoint>>, indices: List<Int>, factor: Float): List<MutableList<StoryManager.PoseKeypoint>> {
        if (factor <= 0f || factor == 1f) return people
        val pv = groupPivot(people, indices) ?: return people
        var f = factor
        if (f > 1f) {
            var lim = Float.MAX_VALUE
            for (k in selectedVisible(people, indices)) {
                val ex = k.x - pv.first; val ey = k.y - pv.second
                if (ex > 1e-6f) lim = min(lim, (1f - pv.first) / ex) else if (ex < -1e-6f) lim = min(lim, pv.first / -ex)
                if (ey > 1e-6f) lim = min(lim, (1f - pv.second) / ey) else if (ey < -1e-6f) lim = min(lim, pv.second / -ey)
            }
            f = min(f, max(lim, 1f))
            if (f <= 1f) return people
        }
        return mapSelected(people, indices) { p -> p.map { if (it.visible) it.copy(x = pv.first + (it.x - pv.first) * f, y = pv.second + (it.y - pv.second) * f) else it }.toMutableList() }
    }
    fun scaleAbout(p: MutableList<StoryManager.PoseKeypoint>, factor: Float): MutableList<StoryManager.PoseKeypoint> = scaleGroup(listOf(p), listOf(0), factor)[0]

    /**
     * Xoay PHẲNG (nghiêng trong mặt phẳng ảnh) quanh tâm chung; dương = theo chiều kim đồng hồ trên màn hình. Tính theo đơn vị đẳng hướng (aspect = rộng/cao).
     * KHÔNG tự đưa vào khung (giữ phép xoay chính xác, đảo được) — gọi [fitInside] sau nếu cần.
     */
    fun rollGroup(people: List<MutableList<StoryManager.PoseKeypoint>>, indices: List<Int>, degrees: Float, aspect: Float = 1f): List<MutableList<StoryManager.PoseKeypoint>> {
        if (degrees == 0f) return people
        val pv = groupPivot(people, indices) ?: return people
        val t = Math.toRadians(degrees.toDouble()); val c = cos(t).toFloat(); val s = sin(t).toFloat()
        return mapSelected(people, indices) { p ->
            p.map {
                if (!it.visible) it else {
                    val dx = (it.x - pv.first) * aspect; val dy = it.y - pv.second
                    it.copy(x = pv.first + (dx * c - dy * s) / aspect, y = pv.second + (dx * s + dy * c))
                }
            }.toMutableList()
        }
    }
    fun roll(p: MutableList<StoryManager.PoseKeypoint>, degrees: Float, aspect: Float = 1f): MutableList<StoryManager.PoseKeypoint> = rollGroup(listOf(p), listOf(0), degrees, aspect)[0]

    /** Lật trái–phải quanh trục dọc qua tâm chung, HOÁN ĐỔI nhãn trái–phải của từng người. Lật hai lần về đúng hình cũ. z giữ nguyên. */
    fun mirrorGroup(people: List<MutableList<StoryManager.PoseKeypoint>>, indices: List<Int>): List<MutableList<StoryManager.PoseKeypoint>> {
        val pv = groupPivot(people, indices) ?: return people
        return mapSelected(people, indices) { p ->
            if (p.size < 18) p else {
                val m = p.map { it.copy(x = 2f * pv.first - it.x) }.toMutableList()
                val out = m.toMutableList()
                for ((a, b) in MIRROR_PAIRS) { out[a] = m[b]; out[b] = m[a] }
                out
            }
        }
    }
    fun mirror(p: MutableList<StoryManager.PoseKeypoint>): MutableList<StoryManager.PoseKeypoint> = mirrorGroup(listOf(p), listOf(0))[0]

    /**
     * Nếu có khớp nằm ngoài khung [0,1]: thu nhỏ CHUNG (nếu bao quanh to hơn khung) rồi dời CHUNG vào trong, giữ bố cục giữa các người. Nằm trong sẵn thì trả đúng danh sách cũ.
     * Dùng sau xoay phẳng / xoay 3D vì các phép đó có thể đẩy khớp ra ngoài.
     */
    fun fitInside(people: List<MutableList<StoryManager.PoseKeypoint>>, margin: Float = 0.01f): List<MutableList<StoryManager.PoseKeypoint>> {
        val v = people.flatMap { it.filter { k -> k.visible } }
        if (v.isEmpty()) return people
        val minX = v.minOf { it.x }; val maxX = v.maxOf { it.x }; val minY = v.minOf { it.y }; val maxY = v.maxOf { it.y }
        if (minX >= 0f && maxX <= 1f && minY >= 0f && maxY <= 1f) return people
        val w = maxX - minX; val h = maxY - minY
        val avail = 1f - 2f * margin
        val k = min(1f, min(if (w > 1e-6f) avail / w else 1f, if (h > 1e-6f) avail / h else 1f))
        val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f
        val nMinX = cx + (minX - cx) * k; val nMaxX = cx + (maxX - cx) * k
        val nMinY = cy + (minY - cy) * k; val nMaxY = cy + (maxY - cy) * k
        var sx = 0f; var sy = 0f
        if (nMinX < margin) sx = margin - nMinX else if (nMaxX > 1f - margin) sx = (1f - margin) - nMaxX
        if (nMinY < margin) sy = margin - nMinY else if (nMaxY > 1f - margin) sy = (1f - margin) - nMaxY
        return people.map { person ->
            person.map { if (it.visible) it.copy(x = cx + (it.x - cx) * k + sx, y = cy + (it.y - cy) * k + sy) else it }.toMutableList()
        }
    }

    // ───────────────────────── (2) dựng độ sâu từ khung xương 2D ─────────────────────────

    /**
     * Gán z cho các khớp đang hiện từ độ dài đã co (foreshortening). Xem ghi chú đầu tệp về dấu ± và các ước lượng. Gốc độ sâu: tâm hông z = 0 (hoặc cổ nếu thiếu hông).
     * [limbDepth]: false (mặc định) = chỉ đầu + xoay thân; true = đoán thêm độ sâu tay/chân/thân nghiêng (thử nghiệm). [flips]: các cờ FLIP_* (chỉ tác dụng với phần đã đoán). [ageYears]: tuổi để lấy tỷ lệ đoạn từ AgeBodyTable (mặc định người lớn; sai khác với trẻ em chỉ vài %).
     * Trả danh sách MỚI; không đổi x, y. Không đủ khớp để đo thì trả bản sao giữ nguyên z.
     */
    fun reconstructDepth(
        person: List<StoryManager.PoseKeypoint>, aspect: Float = 1f, ageYears: Int = AgeBodyTable.ADULT_AGE, flips: Int = 0, limbDepth: Boolean = false
    ): MutableList<StoryManager.PoseKeypoint> {
        val out = person.toMutableList()
        if (person.size < 18) return out
        val fr = AgeBodyTable.heightFractions(ageYears)
        fun vis(i: Int) = person[i].visible
        fun len(a: Int, b: Int) = hypot((person[b].x - person[a].x) * aspect, person[b].y - person[a].y)

        val hipsOk = vis(8) && vis(11); val neckOk = vis(1)
        if (!hipsOk && !neckOk) return out
        val hx = if (hipsOk) (person[8].x + person[11].x) / 2f else person[1].x
        val hy = if (hipsOk) (person[8].y + person[11].y) / 2f else person[1].y
        val trunkLen = if (hipsOk && neckOk) hypot((person[1].x - hx) * aspect, person[1].y - hy) else 0f

        // đoạn chi: (cha, con, độ dài thật theo chiều cao, giới hạn bit lật, dấu mặc định: −1 = ra trước camera)
        class Bone(val a: Int, val b: Int, val l: Float, val flipBit: Int, val sign: Int)
        val bones = listOf(
            Bone(2, 3, fr.upperArm, FLIP_R_ARM, -1), Bone(3, 4, fr.forearm, FLIP_R_ARM, -1),
            Bone(5, 6, fr.upperArm, FLIP_L_ARM, -1), Bone(6, 7, fr.forearm, FLIP_L_ARM, -1),
            Bone(8, 9, fr.thigh, FLIP_R_LEG, -1), Bone(9, 10, fr.shank, FLIP_R_LEG, +1),
            Bone(11, 12, fr.thigh, FLIP_L_LEG, -1), Bone(12, 13, fr.shank, FLIP_L_LEG, +1)
        )
        // tỷ lệ s = đoạn ít bị co nhất (Taylor), bỏ các đoạn dài bất thường (> 2× trung vị: nhiễu phát hiện khớp)
        val ratios = ArrayList<Float>()
        if (trunkLen > 1e-6f) ratios.add(trunkLen / fr.trunk)
        for (b in bones) if (vis(b.a) && vis(b.b)) ratios.add(len(b.a, b.b) / b.l)
        if (ratios.isEmpty()) return out
        val sorted = ratios.sorted()
        val median = if (sorted.size % 2 == 1) sorted[sorted.size / 2] else (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2f
        val kept = ratios.filter { it <= 2f * median }.sortedDescending()
        val s = if (kept.isEmpty()) median else kept.take(scaleTopK.coerceAtLeast(1)).average().toFloat()
        if (s <= 1e-6f) return out

        // độ lệch sâu của một đoạn; biên `noiseMargin·s` cộng vào độ dài trên ảnh để nhiễu nhỏ không biến đoạn gần song song mặt ảnh thành đoạn "co" (dz có đạo hàm vô hạn khi l → s·L)
        // limbDepth = false (MẶC ĐỊNH, chế độ an toàn): KHÔNG đoán độ sâu cho tay/chân/thân nghiêng (dz = 0) — chỉ còn xoay thân từ độ hẹp của vai và mô hình đầu (hai tín hiệu lớn, ít nhạy nhiễu).
        // Đo với nhiễu hiệu chỉnh theo COCO (279.9): chế độ này tốt hơn hoặc bằng coi người phẳng ở MỌI ca thử, kể cả khi dấu ra-trước/ra-sau đoán sai; đoán cả chi chỉ lợi khi dấu đúng và tệ hơn phẳng khi đứng thẳng hoặc dấu sai.
        fun dz(l2d: Float, lTrue: Float): Float { if (!limbDepth) return 0f; val e = s * lTrue; val l = min(e, l2d + noiseMargin * s); return sqrt(max(0f, e * e - l * l)) }
        val z = FloatArray(18)

        // thân: cổ so với tâm hông (nghiêng ra trước camera mặc định)
        val torsoFlip = (flips and FLIP_TORSO) != 0
        if (hipsOk && neckOk) z[1] = (if (torsoFlip) +1 else -1) * dz(trunkLen, fr.trunk)

        // xoay thân quanh trục dọc suy từ độ hẹp của vai (ước lượng của mình, xem ghi chú đầu tệp)
        var faceSign = 1  // +1: mặt quay về bên TRÁI ảnh (vai trái nhân vật ra trước), −1: ngược lại
        if (vis(0) && vis(2) && vis(5)) faceSign = if (person[0].x <= (person[2].x + person[5].x) / 2f) 1 else -1
        if (torsoFlip) faceSign = -faceSign
        var theta = 0.0
        val eSh = s * fr.shoulder
        if (vis(2) && vis(5) && eSh > 1e-6f) {
            val q = (len(2, 5) / eSh).coerceIn(0f, 1f)
            val full = acos(q.toDouble())
            val t = ((0.7f - q) / 0.4f).coerceIn(0f, 1f)
            theta = full * t
        }
        val sinT = sin(theta).toFloat(); val cosT = cos(theta).toFloat()
        if (vis(2)) z[2] = z[1] + faceSign * (eSh / 2f) * sinT        // vai phải: ra SAU khi mặt quay trái
        if (vis(5)) z[5] = z[1] - faceSign * (eSh / 2f) * sinT        // vai trái: ra TRƯỚC khi mặt quay trái
        if (hipsOk) {
            val wHip = len(8, 11)
            val halfHip = if (cosT > 0.35f) wHip / (2f * cosT) else 0.8f * eSh / 2f
            z[8] = faceSign * halfHip * sinT
            z[11] = -faceSign * halfHip * sinT
        } else {
            if (vis(8)) z[8] = 0f
            if (vis(11)) z[11] = 0f
        }
        // chi: dọc theo chuỗi cha → con
        for (b in bones) if (vis(b.a) && vis(b.b)) {
            val sg = if ((flips and b.flipBit) != 0) -b.sign else b.sign
            z[b.b] = z[b.a] + sg * dz(len(b.a, b.b), b.l)
        }
        // đầu: mô hình đầu chuẩn xoay theo độ lệch của mũi (ước lượng của mình)
        if (vis(0) && neckOk) {
            val r = s * fr.head / 2f
            val f = 0.9f * r
            val centerX = if (vis(16) && vis(17)) (person[16].x + person[17].x) / 2f else person[1].x
            val dx = (person[0].x - centerX) * aspect
            val sinPsi = (-dx / f).coerceIn(-1f, 1f)
            val psi = asin(sinPsi.toDouble()); val sP = sin(psi).toFloat(); val cP = cos(psi).toFloat()
            // điểm đầu: (bên trái +, ra trước) theo bán kính r: z' = −(bên·sin + trước·cos)
            fun headZ(lateral: Float, forward: Float) = z[1] - (lateral * r * sP + forward * r * cP)
            z[0] = headZ(0f, 0.9f)
            if (vis(15)) z[15] = headZ(+0.4f, 0.8f)
            if (vis(14)) z[14] = headZ(-0.4f, 0.8f)
            if (vis(17)) z[17] = headZ(+1f, 0f)
            if (vis(16)) z[16] = headZ(-1f, 0f)
        }
        for (i in 0 until 18) if (vis(i)) out[i] = person[i].copy(z = z[i] / aspect)
        return out
    }

    /** Bỏ độ sâu: z = 0 cho mọi khớp (x, y giữ nguyên). Dùng khi chốt góc xoay mà không muốn đưa z ĐOÁN vào các chỗ dùng z (lọc điểm chạm, ảnh độ sâu). */
    fun flattenDepth(p: MutableList<StoryManager.PoseKeypoint>): MutableList<StoryManager.PoseKeypoint> =
        if (p.all { it.z == 0f }) p else p.map { it.copy(z = 0f) }.toMutableList()

    // ───────────────────────── (3) camera trực giao quay quanh tâm hông ─────────────────────────

    /**
     * Quay camera (yaw, pitch độ) quanh tâm hông chung của các người ở [indices]; người khác giữ nguyên. Chưa có z thì tự [reconstructDepth] (theo [flips] của từng người).
     * yaw = pitch = 0 trả đúng dữ liệu cũ (không trôi số). Kết quả được [fitInside] để không lòi ra ngoài khung. z mới cũng được ghi lại.
     */
    fun orbit(
        people: List<MutableList<StoryManager.PoseKeypoint>>, indices: List<Int>, yawDeg: Float, pitchDeg: Float,
        aspect: Float = 1f, flips: Map<Int, Int> = emptyMap(), ageYears: Int = AgeBodyTable.ADULT_AGE, limbDepth: Boolean = false
    ): List<MutableList<StoryManager.PoseKeypoint>> {
        val yaw = yawDeg.coerceIn(-MAX_YAW, MAX_YAW); val pitch = pitchDeg.coerceIn(-MAX_PITCH, MAX_PITCH)
        if (yaw == 0f && pitch == 0f) return people.map { it.toMutableList() }
        val idx = indices.filter { it in people.indices && people[it].any { k -> k.visible } }
        if (idx.isEmpty()) return people.map { it.toMutableList() }
        val prepared = people.mapIndexed { i, p ->
            if (i in idx) (if (hasDepth(p)) p.toMutableList() else reconstructDepth(p, aspect, ageYears, flips[i] ?: 0, limbDepth)) else p.toMutableList()
        }
        // tâm chung = trung bình tâm hông (đơn vị đẳng hướng)
        val hips = idx.mapNotNull { i -> pivot(prepared[i])?.let { pv ->
            val p = prepared[i]
            val zc = if (p.size >= 12 && p[8].visible && p[11].visible) (p[8].z + p[11].z) / 2f else p.filter { it.visible }.map { it.z }.average().toFloat()
            Triple(pv.first * aspect, pv.second, zc * aspect)
        } }
        val cX = hips.map { it.first }.average().toFloat(); val cY = hips.map { it.second }.average().toFloat(); val cZ = hips.map { it.third }.average().toFloat()
        val psi = Math.toRadians(yaw.toDouble()); val phi = Math.toRadians(pitch.toDouble())
        val cps = cos(psi).toFloat(); val sps = sin(psi).toFloat(); val cph = cos(phi).toFloat(); val sph = sin(phi).toFloat()
        // cơ sở camera: r = phải màn hình, d = xuống màn hình, f = hướng nhìn (ra xa camera)
        val rX = cps; val rY = 0f; val rZ = sps
        val dX = sph * sps; val dY = cph; val dZ = -sph * cps
        val fX = -sps * cph; val fY = sph; val fZ = cps * cph
        val rotated = prepared.mapIndexed { i, p ->
            if (i !in idx) p else p.map {
                if (!it.visible) it else {
                    val px = it.x * aspect - cX; val py = it.y - cY; val pz = it.z * aspect - cZ
                    val nx = rX * px + rY * py + rZ * pz
                    val ny = dX * px + dY * py + dZ * pz
                    val nz = fX * px + fY * py + fZ * pz
                    it.copy(x = (cX + nx) / aspect, y = cY + ny, z = (cZ + nz) / aspect)
                }
            }.toMutableList()
        }
        return fitInside(rotated)
    }

    /** Khoảng cách 3D (đơn vị đẳng hướng) giữa hai khớp — dùng cho kiểm tra: độ dài xương phải giữ nguyên khi xoay camera. */
    fun dist3(p: List<StoryManager.PoseKeypoint>, a: Int, b: Int, aspect: Float = 1f): Float {
        val dx = (p[b].x - p[a].x) * aspect; val dy = p[b].y - p[a].y; val dz = (p[b].z - p[a].z) * aspect
        return sqrt(dx * dx + dy * dy + dz * dz)
    }
}
