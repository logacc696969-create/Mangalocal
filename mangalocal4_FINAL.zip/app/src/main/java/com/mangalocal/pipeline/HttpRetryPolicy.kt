package com.mangalocal.pipeline

import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * mục 266 TECHNICAL_STATUS.md — chính sách THỬ LẠI cho API ngoài (LLM/VLM/ảnh miễn phí). Bậc miễn phí luôn có giới hạn tần suất (ví dụ một nguồn ghi
 * Gemini 2.5 Flash 10 yêu cầu/phút) nên HTTP 429 là chuyện thường chứ không phải lỗi hiếm; trước đây ExternalLlmClient ném lỗi ngay ở lần đầu và nhiều nhánh
 * gọi LLM có `catch` rơi về giá trị dự phòng -> chất lượng giảm ÂM THẦM. Thuần Kotlin để kiểm thử bằng kotlinc (tools/test_http_retry.py).
 *
 * Nguyên tắc: (1) chỉ thử lại lỗi TẠM THỜI (408/425/429/5xx và lỗi mạng); 401/403/404/400 không bao giờ thử lại (thử lại chỉ đốt hạn mức);
 * (2) 429 mà thân phản hồi cho thấy hết hạn mức THEO NGÀY -> bỏ ngay, chờ vô ích; (3) Retry-After được tôn trọng nhưng chờ quá lâu (> 120 giây) thì bỏ để
 * không treo cả lượt sinh; (4) lùi cấp số nhân có kẹp trần.
 */
object HttpRetryPolicy {
    const val DEFAULT_MAX_ATTEMPTS = 4
    const val BASE_DELAY_MS = 2_000L
    const val MAX_BACKOFF_MS = 30_000L
    /** Máy chủ yêu cầu chờ lâu hơn mức này -> không chờ, báo lỗi rõ. */
    const val MAX_ACCEPTED_WAIT_MS = 120_000L
    /** Mã giả cho lỗi mạng (không có phản hồi HTTP). */
    const val NETWORK_ERROR = -1

    /** mục 271 — cụm từ có trong MỌI thông báo bỏ cuộc vì hết hạn mức NGÀY; MangaPipeline.log đếm các dòng log chứa nó để hiện MỘT biểu ngữ (PipelineState.dailyQuotaHits). */
    const val DAILY_QUOTA_MARKER = "hết hạn mức MIỄN PHÍ trong ngày"

    sealed class Decision {
        class Retry(val delayMs: Long, val reason: String) : Decision()
        class GiveUp(val reason: String) : Decision()
    }

    fun isRetryable(code: Int): Boolean =
        code == NETWORK_ERROR || code == 408 || code == 425 || code == 429 || code == 500 || code == 502 || code == 503 || code == 504

    private val DAILY_MARKERS = listOf("perday", "per day", "per-day", "per_day", "daily free allocation", "daily limit", "daily quota", "free-models-per-day")

    /** Thân phản hồi cho thấy hết hạn mức THEO NGÀY (Cloudflare 3036 "daily free allocation", Gemini quotaId ...PerDay..., OpenRouter free-models-per-day). */
    fun isDailyQuotaExhausted(body: String): Boolean {
        val low = body.lowercase()
        if (DAILY_MARKERS.any { low.contains(it) }) return true
        return Regex("\"code\"\\s*:\\s*3036\\b").containsMatchIn(body)
    }

    /**
     * Giá trị Retry-After -> mili-giây: số giây (nguyên hoặc thập phân, làm tròn LÊN) hoặc ngày HTTP (RFC 1123). Âm/không hiểu -> null.
     * [nowMs] là giờ hiện tại (được tiêm vào để test).
     */
    fun parseRetryAfterMs(header: String?, nowMs: Long): Long? {
        val h = header?.trim().orEmpty()
        if (h.isEmpty()) return null
        if (Regex("^\\d+(\\.\\d+)?$").matches(h)) {
            val sec = h.toDoubleOrNull() ?: return null
            return Math.ceil(sec * 1000.0).toLong()
        }
        return try {
            val f = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
            f.timeZone = TimeZone.getTimeZone("GMT")
            f.isLenient = false
            val t = f.parse(h)?.time ?: return null
            (t - nowMs).coerceAtLeast(0L)
        } catch (e: Exception) {
            null
        }
    }

    /** Lùi cấp số nhân: attempt 1 -> BASE, 2 -> 2*BASE, ... kẹp MAX_BACKOFF_MS; [jitter01] in [0,1] cộng tối đa 25%. */
    fun backoffMs(attempt: Int, jitter01: Double = 0.0): Long {
        val a = attempt.coerceIn(1, 30)
        var d = BASE_DELAY_MS
        for (i in 1 until a) { d *= 2; if (d >= MAX_BACKOFF_MS) { d = MAX_BACKOFF_MS; break } }
        d = d.coerceAtMost(MAX_BACKOFF_MS)
        val j = if (jitter01.isNaN()) 0.0 else jitter01.coerceIn(0.0, 1.0)
        return d + (d * 0.25 * j).toLong()
    }

    /**
     * Sau một lần THẤT BẠI (mã HTTP hoặc NETWORK_ERROR): thử lại hay bỏ. [attempt] = số lần đã thử (>= 1).
     * Không dùng cho phản hồi thành công.
     */
    fun decide(code: Int, retryAfterHeader: String?, body: String, attempt: Int, maxAttempts: Int, nowMs: Long, jitter01: Double = 0.0): Decision {
        if (!isRetryable(code)) return Decision.GiveUp("HTTP $code không phải lỗi tạm thời — không thử lại")
        if (code == 429 && isDailyQuotaExhausted(body)) {
            return Decision.GiveUp("Đã $DAILY_QUOTA_MARKER — thử lại vào ngày mai (hoặc chọn nhà cung cấp/nguồn khác)")
        }
        if (attempt >= maxAttempts) return Decision.GiveUp("đã thử $attempt lần vẫn lỗi")
        val ra = parseRetryAfterMs(retryAfterHeader, nowMs)
        if (ra != null && ra > MAX_ACCEPTED_WAIT_MS) {
            return Decision.GiveUp("máy chủ yêu cầu chờ ${ra / 1000} giây — quá lâu, bỏ qua")
        }
        val delay = ra ?: backoffMs(attempt, jitter01)
        val why = if (code == NETWORK_ERROR) "lỗi mạng" else "HTTP $code"
        return Decision.Retry(delay, "$why, thử lại lần ${attempt + 1}/$maxAttempts sau ${(delay + 999) / 1000} giây")
    }

    /** Thông báo lỗi cuối cùng cho người dùng (tiếng Việt). Không bao giờ chứa khoá API (chỉ trích thân phản hồi, cắt ngắn, gộp khoảng trắng). */
    fun failureMessage(code: Int, body: String): String {
        val snippet = body.replace(Regex("\\s+"), " ").trim().take(200)
        val head = when (code) {
            NETWORK_ERROR -> "Lỗi mạng (không kết nối được hoặc quá thời gian)"
            400 -> "Yêu cầu bị từ chối (400) — kiểm tra tên model/tham số"
            401, 403 -> "Khoá/token API sai, hết hạn hoặc không có quyền ($code)"
            404 -> "Không tìm thấy (404) — kiểm tra Base URL/tên model/Account ID"
            413 -> "Nội dung gửi lên quá lớn (413)"
            429 -> "Bị giới hạn tần suất/hạn mức (429)"
            in 500..599 -> "Máy chủ API lỗi ($code)"
            else -> "HTTP $code"
        }
        return if (snippet.isEmpty()) head else "$head: $snippet"
    }
}
