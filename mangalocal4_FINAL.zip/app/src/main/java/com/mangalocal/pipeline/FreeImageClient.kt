package com.mangalocal.pipeline

import com.mangalocal.model.FreeImageConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/** Ảnh nhận về: byte gốc (PNG/JPEG/WebP theo magic bytes) + đuôi file. */
class FreeImageResult(val bytes: ByteArray, val ext: String)

/** Cấu hình lưu trong GenerationSettings -> thông tin đăng nhập cho lõi thuần. */
fun FreeImageConfig.toCreds(): FreeImageCreds = FreeImageCreds(cfAccountId, cfApiToken, cfModel, pollinationsKey)

/**
 * mục 266 TECHNICAL_STATUS.md — gọi API ảnh MIỄN PHÍ (chữ -> ảnh) cho ảnh nền/địa điểm và ảnh phác nhân vật. Phần dựng yêu cầu/giải mã nằm ở [FreeImageApi]
 * (đã kiểm thử bằng kotlinc); lớp này chỉ là lớp mạng mỏng + thử lại theo [HttpRetryPolicy].
 *
 * BẢO MẬT/RIÊNG TƯ: prompt (mô tả bối cảnh/nhân vật) gửi tới bên thứ ba qua TLS chuẩn, không có lớp mã hoá riêng của app (khác Remote GPU tự host). Khoá API chỉ nằm
 * trong bộ nhớ (hoặc tệp riêng nếu bật "Nhớ khoá API", mục 267), đi trong header `Authorization: Bearer` cho CẢ HAI nhà cung cấp (mục 268: Pollinations trước đây để khoá trong URL).
 * CHƯA gọi thử với dịch vụ thật (sandbox không ra Internet): sai tên tham số sẽ báo 400 và thông báo hiện cho người dùng.
 */
class FreeImageClient(private val provider: FreeImageProvider, private val creds: FreeImageCreds) {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(180, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    private fun toRequest(spec: HttpSpec): Request {
        val b = Request.Builder().url(spec.url)
        for ((k, v) in spec.headers) b.addHeader(k, v)
        if (spec.method == "POST") b.post((spec.jsonBody ?: "").toRequestBody("application/json".toMediaType())) else b.get()
        return b.build()
    }

    /** Ném RuntimeException (tiếng Việt, hiện được cho người dùng) khi thiếu thông tin, bị giới hạn, hết hạn mức, hoặc phản hồi không phải ảnh. */
    suspend fun generate(prompt: String, negative: String, width: Int, height: Int, seed: Long, onWait: (String) -> Unit = {}): FreeImageResult =
        withContext(Dispatchers.IO) {
            val problems = FreeImageApi.problems(provider, creds)
            if (problems.isNotEmpty()) throw RuntimeException(problems.joinToString("; ") + " (Cài đặt > API ảnh miễn phí).")
            val spec = try {
                FreeImageApi.buildRequest(provider, prompt, negative, width, height, seed, creds)
            } catch (e: IllegalArgumentException) {
                throw RuntimeException("${provider.label}: ${e.message}")
            }
            val res = HttpRetryExec.execute(client, { toRequest(spec) }, onWait = onWait)
            if (res.code !in 200..299) {
                throw RuntimeException("${provider.label}: " + HttpRetryPolicy.failureMessage(res.code, String(res.body, Charsets.UTF_8)))
            }
            val d = FreeImageApi.decode(res.contentType, res.body)
            val bytes = d.bytes ?: throw RuntimeException("${provider.label}: ${d.error ?: "phản hồi không phải ảnh"}")
            FreeImageResult(bytes, d.ext)
        }
}
