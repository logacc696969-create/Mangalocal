package com.mangalocal.pipeline

import java.io.File
import java.io.InputStream

/**
 * mục 281 TECHNICAL_STATUS.md — chép model ĐÓNG TRONG APK (assets) ra thư mục model của app ở LẦN ĐẦU, để người dùng khỏi chép tay (cùng kiểu "chép nếu chưa có" của
 * StoryManager.ensureManifestInitialized). Thuần Kotlin/Java (không Android; assets được truyền vào dưới dạng hàm mở luồng) để chạy thử độc lập — xem tools/kotlin_tests/BundledModelsTest.kt.
 *
 * QUY TẮC: nếu thư mục ĐÃ có BẤT KỲ tệp nào trong [names] thì KHÔNG làm gì (tôn trọng model người dùng tự đặt, không bao giờ ghi đè); nếu chưa có tệp nào thì chép lần lượt từng tệp
 * qua tệp tạm `.part` rồi đổi tên (không bao giờ để lại tệp model cụt); tệp nào mở/chép lỗi thì bỏ qua tệp đó và dọn tệp tạm; mọi lỗi (không tạo được thư mục, hết chỗ, không ghi được) → trả 0,
 * KHÔNG ném lỗi. Gọi trên luồng nền (chép ~9 MB). Trả về số tệp đã chép.
 */
object BundledModels {
    fun copyIfNoneExist(dir: File, names: List<String>, open: (String) -> InputStream?): Int {
        if (names.isEmpty() || names.any { File(dir, it).exists() }) return 0
        try { if (!dir.isDirectory && !dir.mkdirs()) return 0 } catch (e: Exception) { return 0 }
        var copied = 0
        for (n in names) {
            val dst = File(dir, n); val tmp = File(dir, "$n.part")
            try {
                val input = open(n) ?: continue
                input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                if (tmp.length() > 0L && tmp.renameTo(dst)) copied++ else tmp.delete()
            } catch (e: Exception) {
                try { tmp.delete() } catch (_: Exception) {}
            }
        }
        return copied
    }
}
