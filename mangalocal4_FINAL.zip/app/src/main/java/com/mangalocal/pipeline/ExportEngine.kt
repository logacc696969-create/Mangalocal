package com.mangalocal.pipeline

import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.mangalocal.model.*
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ExportEngine {

    // mục 141 TECHNICAL_STATUS.md — SỬA BUG THẬT (không chỉ tiện lợi):
    // TRƯỚC ĐÂY file xuất luôn đặt tên CỨNG "chapter.pdf"/"chapter.cbz" —
    // không chỉ phiền (user phải tự đổi tên mỗi lần), mà còn RỦI RO MẤT
    // DỮ LIỆU THẬT: nếu xuất NHIỀU CHƯƠNG vào CÙNG 1 thư mục đích (qua
    // Storage Access Framework, `MainViewModel.exportChapter(destUri=...)`)
    // — chương sau sẽ GHI ĐÈ ÂM THẦM lên chương trước vì `destTree.findFile(srcFile.name)`
    // tìm theo tên, cả 2 đều tên "chapter.pdf" như nhau. Đặt tên theo
    // truyện + chương giải quyết CẢ 2 vấn đề cùng lúc.
    //
    // Lọc ký tự KHÔNG hợp lệ cho tên file (Android/hầu hết filesystem):
    // `/ \ : * ? " < > |` + ký tự điều khiển — thay bằng "_". Gộp nhiều
    // dấu cách/gạch dưới liên tiếp thành 1. Cắt độ dài an toàn (100 ký tự
    // — thừa đủ cho mọi tên truyện thật, tránh lỗi ENAMETOOLONG trên 1 số
    // filesystem cũ giới hạn 255 BYTE, không phải 255 KÝ TỰ, với tiếng
    // Việt có dấu mỗi ký tự chiếm nhiều byte hơn). Fallback "chapter" nếu
    // kết quả rỗng (vd tên truyện toàn emoji/ký tự đặc biệt bị lọc hết).
    private fun sanitizeFilename(raw: String): String {
        val cleaned = raw.trim()
            .replace(Regex("[/\\\\:*?\"<>|\\x00-\\x1F]"), "_")
            .replace(Regex("\\s+"), " ")
            .replace(Regex("_+"), "_")
            .trim('_', ' ', '.')
            .take(100)
        return cleaned.ifBlank { "chapter" }
    }

    fun exportPdf(panels: List<Panel>, outDir: File, title: String, fileBaseName: String = title): String {
        val doc = PdfDocument()
        val pw = 595; val ph = 842

        panels.chunked(2).forEachIndexed { pageIdx, chunk ->
            val info = PdfDocument.PageInfo.Builder(pw, ph, pageIdx + 1).create()
            val page = doc.startPage(info)
            val c = page.canvas
            c.drawColor(Color.WHITE)

            if (pageIdx == 0) {
                c.drawText(title, 20f, 28f, Paint().apply {
                    color = Color.BLACK; textSize = 16f
                    typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true
                })
            }

            val topPad = if (pageIdx == 0) 42f else 12f
            val halfH = (ph - topPad - 20f) / 2f

            chunk.forEachIndexed { i, panel ->
                val imgPath = panel.upscaledPath ?: panel.imagePath ?: return@forEachIndexed
                val bmp = BitmapFactory.decodeFile(imgPath) ?: return@forEachIndexed
                val top = topPad + if (i == 0) 0f else halfH + 8f
                val dst = RectF(12f, top, pw - 12f, top + halfH - 4f)

                c.drawRect(dst, Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f })
                c.drawBitmap(bmp, null, dst, null)
                bmp.recycle()

                // Vẽ bubble theo vị trí normalized đã lưu trong panel
                panel.bubbles.forEach { bubble -> drawBubbleAtPosition(c, bubble, dst) }

                c.drawText("#${panel.index + 1}", dst.left + 4f, dst.bottom - 4f,
                    Paint().apply { color = Color.DKGRAY; textSize = 8f; isAntiAlias = true })
            }
            doc.finishPage(page)
        }

        val out = File(outDir, "${sanitizeFilename(fileBaseName)}.pdf")
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
        return out.absolutePath
    }

    // mục 79/80 TECHNICAL_STATUS.md (TODO #11, nay đã code) — 2 việc sửa
    // cùng lúc trong hàm này vì cùng điểm chạm:
    //
    // 1. BUG PHÁT HIỆN KHI RÀ LẠI (không có trong tài liệu trước đó — phát
    //    hiện MỚI của lượt này): CBZ export TRƯỚC ĐÂY copy thẳng byte PNG
    //    thô (`file.inputStream().use { it.copyTo(zip) }`), KHÔNG hề vẽ
    //    bubble — khác `exportPdf()` ở trên có gọi `drawBubbleAtPosition()`
    //    đúng. `renderPanelWithBubbles()` (hàm ngay dưới) được viết sẵn
    //    nhưng CHƯA TỪNG được gọi ở đâu trong toàn bộ codebase — dead code.
    //    Sửa: dùng lại đúng hàm có sẵn này thay vì copy thô.
    //
    // 2. Nén ảnh: THAY VÌ đổi định dạng lưu trữ PIPELINE (panel.imagePath/
    //    upscaledPath vẫn giữ NGUYÊN PNG — các file này còn có thể bị đọc-
    //    sửa-ghi lại bởi ManualMaskFixer trong PostProcessingScreen TRƯỚC
    //    khi export, nén sớm sẽ làm mất chất lượng qua nhiều lần sửa tay
    //    lossy — đúng lo ngại mục 72 đã nêu), CHỈ nén ở ĐIỂM XUẤT CUỐI CÙNG
    //    (CBZ — file deliverable, KHÔNG còn ai đọc lại làm input pipeline
    //    nữa). An toàn tuyệt đối với toàn bộ pipeline phía trước, giải
    //    quyết đúng vấn đề gốc "tích luỹ dung lượng PNG khổng lồ" mà mục 70
    //    lo ngại — vì dung lượng thật sự tích luỹ theo thời gian là các file
    //    EXPORT (CBZ) người dùng giữ lại đọc, không phải file trung gian
    //    (đã bị `hardResetEngine`/giữa-chương xoá dọn một phần theo mục 77).
    //
    // JPEG quality 92 (không phải WebP) — chọn JPEG vì tương thích universal
    // với MỌI comic reader (WebP vẫn có reader cũ không hỗ trợ đọc trong
    // CBZ, đặc biệt trên các app đọc truyện Android cũ) — đúng nguyên tắc
    // "không đổi 1 vấn đề (dung lượng) lấy 1 vấn đề khác (không mở được)".
    // ĐÍNH CHÍNH (mục 141): dòng comment cũ ở đây từng nói "CHƯA CÓ UI để
    // user tự chọn... chất lượng khác — TODO còn lại" — SAI, đã lỗi thời.
    // `settings.cbzJpegQuality` (Models.kt) CÓ Slider thật trong
    // SettingsScreen.kt (nhóm "Hệ thống & vận hành"), nối xuyên suốt qua
    // MainViewModel → MangaPipeline.exportChapter() → tham số
    // `jpegQuality` ngay dưới đây — mạch đầy đủ, đã xác nhận lại ở mục
    // 134.3. CHỈ "chọn ĐỊNH DẠNG khác JPEG" (vd WebP) là KHÔNG làm, và đó
    // là quyết định CÓ CHỦ ĐÍCH (lý do ở đoạn trên), không phải thiếu sót.
    fun exportCbz(panels: List<Panel>, outDir: File, jpegQuality: Int = 92, fileBaseName: String = "chapter"): String {
        val out = File(outDir, "${sanitizeFilename(fileBaseName)}.cbz")
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            panels.forEach { panel ->
                val path = panel.upscaledPath ?: panel.imagePath ?: return@forEach
                val file = File(path)
                if (!file.exists()) return@forEach
                val composited = renderPanelWithBubbles(path, panel.bubbles)
                zip.putNextEntry(ZipEntry("panel_%03d.jpg".format(panel.index + 1)))
                if (composited != null) {
                    composited.compress(Bitmap.CompressFormat.JPEG, jpegQuality, zip)
                    composited.recycle()
                } else {
                    // renderPanelWithBubbles thất bại (file lỗi/không đọc được) —
                    // fallback về copy thô PNG cũ, an toàn hơn bỏ trắng panel.
                    file.inputStream().use { it.copyTo(zip) }
                }
                zip.closeEntry()
            }
        }
        return out.absolutePath
    }

    /**
     * Render ảnh panel kèm bubble thành 1 bitmap hoàn chỉnh (dùng cho preview trong app)
     */
    fun renderPanelWithBubbles(imagePath: String, bubbles: List<Bubble>): Bitmap? {
        val original = BitmapFactory.decodeFile(imagePath) ?: return null
        val result = original.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val rect = RectF(0f, 0f, result.width.toFloat(), result.height.toFloat())
        bubbles.forEach { drawBubbleAtPosition(canvas, it, rect) }
        return result
    }

    private fun drawBubbleAtPosition(canvas: Canvas, bubble: Bubble, panelRect: RectF) {
        val bx = panelRect.left + bubble.xNorm * panelRect.width()
        val by = panelRect.top + bubble.yNorm * panelRect.height()
        val bw = bubble.widthNorm * panelRect.width()
        val bh = 0.10f * panelRect.height()

        val rect = RectF(bx, by, bx + bw, by + bh)
        val cornerRadius = bh * 0.25f

        val bgColor = when (bubble.type) {
            BubbleType.THOUGHT -> Color.argb(240, 245, 245, 255)
            BubbleType.SHOUT -> Color.argb(240, 255, 245, 230)
            BubbleType.NARRATION -> Color.argb(220, 255, 255, 220)
            else -> Color.WHITE
        }

        canvas.drawRoundRect(rect, cornerRadius, cornerRadius,
            Paint().apply { color = bgColor; style = Paint.Style.FILL; isAntiAlias = true })
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius,
            Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = bh * 0.04f; isAntiAlias = true })

        val nameSize = bh * 0.18f
        val textSize = bh * 0.22f

        canvas.drawText(bubble.characterName, rect.left + bw*0.04f, rect.top + bh*0.28f,
            Paint().apply { color = Color.DKGRAY; this.textSize = nameSize; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true })

        val maxChars = (bw / (textSize * 0.55f)).toInt().coerceAtLeast(10)
        val text = if (bubble.text.length > maxChars) bubble.text.take(maxChars - 1) + "…" else bubble.text
        canvas.drawText(text, rect.left + bw*0.04f, rect.top + bh*0.62f,
            Paint().apply { color = Color.BLACK; this.textSize = textSize; isAntiAlias = true })
    }
}
