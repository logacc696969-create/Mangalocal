package com.mangalocal.pipeline

import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.mangalocal.model.*
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ExportEngine {

    // mục 141 TECHNICAL_STATUS.md — SỬA BUG THẬT (không chỉ tiện lợi):
    // TRƯỚC ĐÂY file xuất luôn đặt tên CỨNG "chapter.pdf"/"chapter.cbz" —
    // không chỉ phiền (user phải tự đổi tên mỗi lần), mà còn RỦI RO MẤT
    // DỮ LIỆU THẬT: nếu xuất NHIỀU CHƯƠNG vào CÙNG 1 thư mục đích (qua
    // Storage Access Framework, `MainViewModel.exportChapter(destUri=...)`)
    // — chương sau sẽ GHI ĐÈ ÂM THẦM lên chương trước vì `destTree.findFile(srcFile.name)`
    // tìm theo tên, cả 2 đều tên "chapter.pdf" như nhau. Đặt tên theo
    // truyện + chương giải quyết CẢ 2 vấn đề cùng lúc.
    //
    // Lọc ký tự KHÔNG hợp lệ cho tên file (Android/hầu hết filesystem):
    // `/ \ : * ? " < > |` + ký tự điều khiển — thay bằng "_". Gộp nhiều
    // dấu cách/gạch dưới liên tiếp thành 1. Cắt độ dài an toàn (100 ký tự
    // — thừa đủ cho mọi tên truyện thật, tránh lỗi ENAMETOOLONG trên 1 số
    // filesystem cũ giới hạn 255 BYTE, không phải 255 KÝ TỰ, với tiếng
    // Việt có dấu mỗi ký tự chiếm nhiều byte hơn). Fallback "chapter" nếu
    // kết quả rỗng (vd tên truyện toàn emoji/ký tự đặc biệt bị lọc hết).
    private fun sanitizeFilename(raw: String): String {
        val cleaned = raw.trim()
            .replace(Regex("[/\\\\:*?\"<>|\\x00-\\x1F]"), "_")
            .replace(Regex("\\s+"), " ")
            .replace(Regex("_+"), "_")
            .trim('_', ' ', '.')
            .take(100)
        return cleaned.ifBlank { "chapter" }
    }

    fun exportPdf(panels: List<Panel>, outDir: File, title: String, fileBaseName: String = title): String {
        val doc = PdfDocument()
        val pw = 595; val ph = 842

        panels.chunked(2).forEachIndexed { pageIdx, chunk ->
            val info = PdfDocument.PageInfo.Builder(pw, ph, pageIdx + 1).create()
            val page = doc.startPage(info)
            val c = page.canvas
            c.drawColor(Color.WHITE)

            if (pageIdx == 0) {
                c.drawText(title, 20f, 28f, Paint().apply {
                    color = Color.BLACK; textSize = 16f
                    typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true
                })
            }

            val topPad = if (pageIdx == 0) 42f else 12f
            val halfH = (ph - topPad - 20f) / 2f

            chunk.forEachIndexed { i, panel ->
                val imgPath = panel.upscaledPath ?: panel.imagePath ?: return@forEachIndexed
                val bmp = BitmapFactory.decodeFile(imgPath) ?: return@forEachIndexed
                val top = topPad + if (i == 0) 0f else halfH + 8f
                val dst = RectF(12f, top, pw - 12f, top + halfH - 4f)

                c.drawRect(dst, Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f })
                c.drawBitmap(bmp, null, dst, null)
                bmp.recycle()

                // Vẽ bubble theo vị trí normalized đã lưu trong panel
                panel.bubbles.forEach { bubble -> drawBubbleAtPosition(c, bubble, dst) }

                c.drawText("#${panel.index + 1}", dst.left + 4f, dst.bottom - 4f,
                    Paint().apply { color = Color.DKGRAY; textSize = 8f; isAntiAlias = true })
            }
            doc.finishPage(page)
        }

        val out = File(outDir, "${sanitizeFilename(fileBaseName)}.pdf")
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
        return out.absolutePath
    }

    // mục 79/80 TECHNICAL_STATUS.md (TODO #11, nay đã code) — 2 việc sửa
    // cùng lúc trong hàm này vì cùng điểm chạm:
    //
    // 1. BUG PHÁT HIỆN KHI RÀ LẠI (không có trong tài liệu trước đó — phát
    //    hiện MỚI của lượt này): CBZ export TRƯỚC ĐÂY copy thẳng byte PNG
    //    thô (`file.inputStream().use { it.copyTo(zip) }`), KHÔNG hề vẽ
    //    bubble — khác `exportPdf()` ở trên có gọi `drawBubbleAtPosition()`
    //    đúng. `renderPanelWithBubbles()` (hàm ngay dưới) được viết sẵn
    //    nhưng CHƯA TỪNG được gọi ở đâu trong toàn bộ codebase — dead code.
    //    Sửa: dùng lại đúng hàm có sẵn này thay vì copy thô.
    //
    // 2. Nén ảnh: THAY VÌ đổi định dạng lưu trữ PIPELINE (panel.imagePath/
    //    upscaledPath vẫn giữ NGUYÊN PNG — các file này còn có thể bị đọc-
    //    sửa-ghi lại bởi ManualMaskFixer trong PostProcessingScreen TRƯỚC
    //    khi export, nén sớm sẽ làm mất chất lượng qua nhiều lần sửa tay
    //    lossy — đúng lo ngại mục 72 đã nêu), CHỈ nén ở ĐIỂM XUẤT CUỐI CÙNG
    //    (CBZ — file deliverable, KHÔNG còn ai đọc lại làm input pipeline
    //    nữa). An toàn tuyệt đối với toàn bộ pipeline phía trước, giải
    //    quyết đúng vấn đề gốc "tích luỹ dung lượng PNG khổng lồ" mà mục 70
    //    lo ngại — vì dung lượng thật sự tích luỹ theo thời gian là các file
    //    EXPORT (CBZ) người dùng giữ lại đọc, không phải file trung gian
    //    (đã bị `hardResetEngine`/giữa-chương xoá dọn một phần theo mục 77).
    //
    // JPEG quality 92 (không phải WebP) — chọn JPEG vì tương thích universal
    // với MỌI comic reader (WebP vẫn có reader cũ không hỗ trợ đọc trong
    // CBZ, đặc biệt trên các app đọc truyện Android cũ) — đúng nguyên tắc
    // "không đổi 1 vấn đề (dung lượng) lấy 1 vấn đề khác (không mở được)".
    // ĐÍNH CHÍNH (mục 141): dòng comment cũ ở đây từng nói "CHƯA CÓ UI để
    // user tự chọn... chất lượng khác — TODO còn lại" — SAI, đã lỗi thời.
    // `settings.cbzJpegQuality` (Models.kt) CÓ Slider thật trong
    // SettingsScreen.kt (nhóm "Hệ thống & vận hành"), nối xuyên suốt qua
    // MainViewModel → MangaPipeline.exportChapter() → tham số
    // `jpegQuality` ngay dưới đây — mạch đầy đủ, đã xác nhận lại ở mục
    // 134.3. CHỈ "chọn ĐỊNH DẠNG khác JPEG" (vd WebP) là KHÔNG làm, và đó
    // là quyết định CÓ CHỦ ĐÍCH (lý do ở đoạn trên), không phải thiếu sót.
    fun exportCbz(
        panels: List<Panel>, outDir: File, jpegQuality: Int = 92, fileBaseName: String = "chapter",
        // mục 249 — ComicInfo.xml ở gốc kho nén (Manga=YesAndRightToLeft khi rtl); mặc định giữ hành vi cũ về ảnh/thứ tự trang
        rtl: Boolean = false, series: String = "", chapterNumber: Int? = null, title: String = ""
    ): String {
        val out = File(outDir, "${sanitizeFilename(fileBaseName)}.cbz")
        val pageCount = panels.count { p -> (p.upscaledPath ?: p.imagePath)?.let { File(it).exists() } == true }
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            zip.putNextEntry(ZipEntry("ComicInfo.xml"))
            zip.write(ComicInfoXml.build(title, series, chapterNumber, pageCount, null, rtl).toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            panels.forEach { panel ->
                val path = panel.upscaledPath ?: panel.imagePath ?: return@forEach
                val file = File(path)
                if (!file.exists()) return@forEach
                val composited = renderPanelWithBubbles(path, panel.bubbles)
                zip.putNextEntry(ZipEntry("panel_%03d.jpg".format(panel.index + 1)))
                if (composited != null) {
                    composited.compress(Bitmap.CompressFormat.JPEG, jpegQuality, zip)
                    composited.recycle()
                } else {
                    // renderPanelWithBubbles thất bại (file lỗi/không đọc được) —
                    // fallback về copy thô PNG cũ, an toàn hơn bỏ trắng panel.
                    file.inputStream().use { it.copyTo(zip) }
                }
                zip.closeEntry()
            }
        }
        return out.absolutePath
    }

    /**
     * Render ảnh panel kèm bubble thành 1 bitmap hoàn chỉnh (dùng cho preview trong app)
     */
    fun renderPanelWithBubbles(imagePath: String, bubbles: List<Bubble>): Bitmap? {
        val original = BitmapFactory.decodeFile(imagePath) ?: return null
        val result = original.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val rect = RectF(0f, 0f, result.width.toFloat(), result.height.toFloat())
        bubbles.forEach { drawBubbleAtPosition(canvas, it, rect) }
        return result
    }

    // mục 228 TECHNICAL_STATUS.md — VẼ LẠI bubble: (1) tự xuống dòng theo bề
    // rộng và co giãn chiều cao theo số dòng (trước đây chiều cao cố định
    // 10% panel và CẮT chữ bằng "…" sau ~vài chục ký tự -> lời thoại dài mất
    // chữ trong file xuất), (2) vẽ ĐUÔI trỏ về miệng người nói nếu bubble có
    // tailXNorm/tailYNorm (Bubble cũ không có -> không đuôi, hành vi như cũ),
    // (3) khác kiểu theo BubbleType (THOUGHT bo tròn + chấm nhỏ thay đuôi,
    // NARRATION khung vuông, SHOUT viền dày).
    // GIỚI HẠN THẬT: chưa hỗ trợ viền răng cưa cho SHOUT / chữ dọc kiểu
    // Nhật; CHƯA build-test — chỉ logic hình học đuôi đã mô phỏng bằng
    // Python (tools/test_bubble_placement.py).
    private class TailGeom(
        val pax: Float, val pay: Float, val pbx: Float, val pby: Float,
        val tipX: Float, val tipY: Float, val nx: Float, val ny: Float
    )

    private fun computeTail(rect: RectF, tx: Float, ty: Float, halfBase: Float, shrink: Float): TailGeom? {
        val cornerMargin = halfBase * 1.6f
        val edge: Int = when {
            ty > rect.bottom -> 0   // đuôi ở cạnh dưới
            ty < rect.top -> 1      // cạnh trên
            tx < rect.left -> 2     // cạnh trái
            tx > rect.right -> 3    // cạnh phải
            else -> return null     // mục tiêu nằm TRONG bubble: không vẽ đuôi
        }
        val baseX: Float; val baseY: Float; val nx: Float; val ny: Float
        when (edge) {
            0 -> { baseX = tx.coerceIn(rect.left + cornerMargin, rect.right - cornerMargin); baseY = rect.bottom; nx = 0f; ny = 1f }
            1 -> { baseX = tx.coerceIn(rect.left + cornerMargin, rect.right - cornerMargin); baseY = rect.top; nx = 0f; ny = -1f }
            2 -> { baseX = rect.left; baseY = ty.coerceIn(rect.top + cornerMargin, rect.bottom - cornerMargin); nx = -1f; ny = 0f }
            else -> { baseX = rect.right; baseY = ty.coerceIn(rect.top + cornerMargin, rect.bottom - cornerMargin); nx = 1f; ny = 0f }
        }
        val dx = tx - baseX; val dy = ty - baseY
        val dist = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (dist < 1e-3f) return null
        // Dừng ngắn hơn mục tiêu một đoạn để đuôi không chạm vào mặt.
        val tipDist = (dist - shrink).coerceAtLeast(halfBase * 1.2f)
        val tipX = baseX + dx / dist * tipDist
        val tipY = baseY + dy / dist * tipDist
        // Hai góc đáy: dọc theo cạnh (vuông góc pháp tuyến).
        val tanX = -ny; val tanY = nx
        return TailGeom(baseX + tanX * halfBase, baseY + tanY * halfBase,
            baseX - tanX * halfBase, baseY - tanY * halfBase, tipX, tipY, nx, ny)
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float, maxLines: Int): List<String> {
        val lines = mutableListOf<String>()
        var cur = StringBuilder()
        fun flush() { if (cur.isNotEmpty()) { lines += cur.toString().trimEnd(); cur = StringBuilder() } }
        text.split(' ').filter { it.isNotEmpty() }.forEach { word0 ->
            var word = word0
            // Từ dài hơn cả dòng: cắt theo ký tự.
            while (paint.measureText(word) > maxWidth && word.length > 1) {
                var n = word.length
                while (n > 1 && paint.measureText(word.substring(0, n)) > maxWidth) n--
                flush(); lines += word.substring(0, n); word = word.substring(n)
            }
            val candidate = if (cur.isEmpty()) word else cur.toString() + " " + word
            if (paint.measureText(candidate) <= maxWidth) { cur = StringBuilder(candidate) }
            else { flush(); cur = StringBuilder(word) }
        }
        flush()
        if (lines.isEmpty()) lines += ""
        if (lines.size > maxLines) {
            val kept = lines.take(maxLines).toMutableList()
            kept[maxLines - 1] = kept[maxLines - 1].trimEnd().take((kept[maxLines - 1].length - 1).coerceAtLeast(1)) + "…"
            return kept
        }
        return lines
    }

    private fun drawBubbleAtPosition(canvas: Canvas, bubble: Bubble, panelRect: RectF) {
        val ph = panelRect.height(); val pw = panelRect.width()
        val bx = panelRect.left + bubble.xNorm * pw
        val by0 = panelRect.top + bubble.yNorm * ph
        val bw = (bubble.widthNorm * pw).coerceAtLeast(pw * 0.15f)

        val textSize = (ph * 0.026f).coerceAtLeast(7f)
        val nameSize = textSize * 0.78f
        val pad = textSize * 0.6f
        val lineH = textSize * 1.25f

        val textPaint = Paint().apply { color = Color.BLACK; this.textSize = textSize; isAntiAlias = true }
        val namePaint = Paint().apply { color = Color.DKGRAY; this.textSize = nameSize; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true }
        val lines = wrapText(bubble.text, textPaint, bw - 2 * pad, 8)

        val hasName = bubble.characterName.isNotBlank() && bubble.type != BubbleType.NARRATION
        val bh = pad * 2 + (if (hasName) nameSize * 1.3f else 0f) + lines.size * lineH
        // Giữ bubble trong panel (dịch lên nếu tràn đáy).
        val bTop = by0.coerceAtMost(panelRect.bottom - bh - 2f).coerceAtLeast(panelRect.top + 2f)
        val rect = RectF(bx, bTop, bx + bw, bTop + bh)

        val bgColor = when (bubble.type) {
            BubbleType.THOUGHT -> Color.argb(240, 245, 245, 255)
            BubbleType.SHOUT -> Color.argb(240, 255, 245, 230)
            BubbleType.NARRATION -> Color.argb(230, 255, 255, 220)
            else -> Color.WHITE
        }
        val strokeW = (if (bubble.type == BubbleType.SHOUT) textSize * 0.16f else textSize * 0.08f).coerceAtLeast(1f)
        val fillPaint = Paint().apply { color = bgColor; style = Paint.Style.FILL; isAntiAlias = true }
        val strokePaint = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = strokeW; isAntiAlias = true }
        val radius = when (bubble.type) {
            BubbleType.THOUGHT -> minOf(bw, bh) * 0.5f
            BubbleType.NARRATION -> 0f
            else -> minOf(bw, bh) * 0.25f
        }

        canvas.drawRoundRect(rect, radius, radius, fillPaint)
        canvas.drawRoundRect(rect, radius, radius, strokePaint)

        // Đuôi trỏ về miệng người nói (chỉ khi bubble có toạ độ đuôi).
        val txN = bubble.tailXNorm; val tyN = bubble.tailYNorm
        if (txN != null && tyN != null && bubble.type != BubbleType.NARRATION) {
            val tx = panelRect.left + txN * pw; val ty = panelRect.top + tyN * ph
            if (bubble.type == BubbleType.THOUGHT) {
                // Bubble suy nghĩ: chuỗi chấm nhỏ dần thay vì đuôi nhọn.
                val cx = rect.centerX(); val cy = rect.centerY()
                val dx = tx - cx; val dy = ty - cy
                val len = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                if (len > 1e-3f) {
                    val startT = 0.5f * minOf(bw, bh) / len + 0.15f
                    for (k in 0 until 3) {
                        val t = (startT + k * 0.12f).coerceAtMost(0.85f)
                        val r = textSize * (0.45f - 0.12f * k)
                        canvas.drawCircle(cx + dx * t, cy + dy * t, r.coerceAtLeast(1.5f), fillPaint)
                        canvas.drawCircle(cx + dx * t, cy + dy * t, r.coerceAtLeast(1.5f), strokePaint)
                    }
                }
            } else {
                val halfBase = textSize * 0.55f
                val tail = computeTail(rect, tx, ty, halfBase, shrink = textSize * 1.2f)
                if (tail != null) {
                    val inset = strokeW * 1.6f
                    val cover = Path().apply {
                        moveTo(tail.pax, tail.pay); lineTo(tail.tipX, tail.tipY); lineTo(tail.pbx, tail.pby)
                        lineTo(tail.pbx - tail.nx * inset, tail.pby - tail.ny * inset)
                        lineTo(tail.pax - tail.nx * inset, tail.pay - tail.ny * inset)
                        close()
                    }
                    canvas.drawPath(cover, fillPaint)
                    canvas.drawLine(tail.pax, tail.pay, tail.tipX, tail.tipY, strokePaint)
                    canvas.drawLine(tail.pbx, tail.pby, tail.tipX, tail.tipY, strokePaint)
                }
            }
        }

        var y = rect.top + pad
        if (hasName) {
            y += nameSize
            canvas.drawText(bubble.characterName, rect.left + pad, y, namePaint)
            y += nameSize * 0.3f
        }
        lines.forEach { line ->
            y += lineH
            canvas.drawText(line, rect.left + pad, y - (lineH - textSize) * 0.5f, textPaint)
        }
    }
}
