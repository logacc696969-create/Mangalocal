package com.mangalocal.pipeline

object NativeBridge {
    init { System.loadLibrary("mangalocal_native") }

    // Bắt crash tầng native (xem native_crash_handler.cpp) — gọi 1 lần từ
    // MangaLocalApplication lúc app khởi động, truyền sẵn đường dẫn file
    // ghi log để signal handler dùng (signal handler không tự lấy được
    // Context/filesDir vì chỉ được gọi hàm async-signal-safe).
    external fun setCrashLogPath(path: String)

    // mục 161 TECHNICAL_STATUS.md — gọi NGAY TRƯỚC mỗi lời gọi native sinh
    // ảnh rủi ro cao (ImagePipeline.kt), để nếu app crash tầng native, file
    // log (native_crash_handler.cpp) ghi lại đúng panel/hàm nào đang chạy
    // lúc đó, thay vì chỉ có signal/địa chỉ lỗi không đủ để debug thực tế.
    // context="" (mặc định) hợp lệ — coi như "không rõ", không lỗi gì.
    external fun setCrashContext(context: String = "")

    // ── LLM ──────────────────────────────────────────────────────────────
    external fun llamaInit(modelPath: String, nThreads: Int, nCtx: Int, nGpuLayers: Int): Long
    external fun llamaGenerate(ctx: Long, prompt: String, maxTokens: Int, temperature: Float): String
    external fun llamaFree(ctx: Long)

    // ── Stable Diffusion (MNN) ──────────────────────────────────────────
    // CHỮ KÝ GIỮ NGUYÊN như bản sd.cpp cũ để không phải sửa ImagePipeline.kt/
    // MainViewModel.kt ở bước này, nhưng PHẦN NATIVE HIỆN LÀ STUB — mọi
    // hàm sd* trả về thất bại (0 / false) cho tới khi jni/mnn_diffusion_
    // pipeline.cpp được viết xong (xem MangaLocal_Technical_Handoff.md
    // mục 6). Không gọi các hàm này trong luồng chính cho tới lúc đó.
    // ĐỔI CHỮ KÝ (xem ghi chú trong ImagePipeline.kt/model_manifest.json):
    // modelDir = thư mục chứa clip/unet/vae*/tokenizer của 1 model,
    // modelId = phải khớp "id" trong assets/model_manifest.json.
    // modelId quyết định TOÀN BỘ kiến trúc dùng bên dưới (đọc field
    // "pipeline" trong model_manifest.json — "sd15_cpu" hoặc "sdxl_cpu" từ
    // mục 59 TECHNICAL_STATUS.md) — hàm này HOÀN TOÀN KHÔNG ĐỔI để hỗ trợ
    // SDXL, native tự chọn PipelineSd15Cpu/PipelineSdxlCpu bên trong sdInit().
    // useNpu (mục 60 TECHNICAL_STATUS.md): BẬT -> mọi session UNet/VAE (KHÔNG
    // áp dụng cho CLIP, luôn CPU — xem PipelineSd15Cpu.hpp) tự thử NPU (QNN)
    // TRƯỚC, rớt xuống useOpenCL rồi CPU nếu NPU không khả dụng — ĐỘC LẬP với
    // useOpenCL (không phải "bật GPU sẽ tự thử NPU"), mặc định false. CHỈ có
    // tác dụng thật khi build với MANGALOCAL_ENABLE_QNN=ON (mặc định OFF,
    // xem CMakeLists.txt) VÀ máy có QNN SDK runtime libs — build mặc định
    // (QNN OFF) thì bật useNpu vẫn AN TOÀN (tự rớt xuống OpenCL/CPU ngay,
    // không crash), chỉ là không có tác dụng tăng tốc thật.
    // mục 63 TECHNICAL_STATUS.md — socModel: chuỗi SoC đã tự dò (vd
    // "SM8650") từ RuntimeOptimizer.detectQnnSoc()?.socModel, dùng để chọn
    // ĐÚNG file trong mảng "npu_offline" của model_manifest.json (mục 62).
    // Truyền "" nếu không dò được/không áp dụng — an toàn, native tự bỏ
    // qua npu_offline khi đó (rớt về UNet CPU/OpenCL thường).
    external fun sdInit(modelDir: String, modelId: String, useOpenCL: Boolean, embeddingsDir: String,
                        useNpu: Boolean = false, socModel: String = ""): Long
    external fun sdTxt2Img(ctx: Long, prompt: String, negPrompt: String, width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long, outputPath: String, callback: SDProgressCallback): Boolean
    // ── img2img / inpaint / Ultrafix (upscale-vẽ-lại) THẬT (mục 16
    // TECHNICAL_STATUS.md) — dùng chung ctx đã sdInit()/sdInitAugmented(),
    // KHÔNG cần init riêng. maskImagePath = "" nghĩa là img2img thường
    // (không mask, vẽ lại toàn ảnh ở denoiseStrength cho trước); có mask
    // nghĩa là inpaint thật (chỉ vẽ lại vùng trắng trong mask). ultrafix=true
    // dùng cho upscale-vẽ-lại (Ultimate SD Upscale-style): width/height lúc
    // này là kích thước ĐÍCH đã upscale (lớn hơn 512), ultrafixTile = kích
    // thước tile gốc model (mặc định 512, khớp SD1.5).
    external fun sdImg2Img(ctx: Long, prompt: String, negPrompt: String, inputImagePath: String,
                           maskImagePath: String, denoiseStrength: Float, width: Int, height: Int,
                           steps: Int, cfgScale: Float, seed: Long, ultrafix: Boolean, ultrafixTile: Int,
                           outputPath: String, callback: SDProgressCallback): Boolean
    // ── Nhất quán nhân vật + tư thế (IP-Adapter + ControlNet-Pose) ──────
    // Dùng UNet ĐÃ RE-EXPORT riêng (xem tools/export_ipa_controlnet_unet.py)
    // — KHÁC unet.mnn thường dùng trong sdInit(), không dùng lẫn được.
    // clip/vaeDecoder/vaeEncoder vẫn dùng chung với model gốc (không đổi).
    // embeddingsDir: thư mục .safetensors Textual Inversion (mục 12
    // TECHNICAL_STATUS.md — phương pháp thứ 3, độc lập LoRA/IP-Adapter,
    // hoạt động ở tầng text-encoder nên không đụng UNet/ip_image_embeds).
    external fun sdInitAugmented(modelDir: String, clipPath: String, unetAugmentedPath: String,
                                  vaeDecoderPath: String, vaeEncoderPath: String,
                                  ipEncoderPath: String, tokenizerPath: String, embeddingsDir: String,
                                  useOpenCL: Boolean = false, useNpu: Boolean = false): Long
    // skeletonData: toạ độ khung xương ĐÃ RETARGET theo tỷ lệ từng nhân vật
    // (mục 32/33 TECHNICAL_STATUS.md — tính ở PoseRetargeter.kt), mảng
    // phẳng mỗi người 18 khớp * 4 giá trị (x,y,z,visible 0/1) = 72 float/
    // người. Mảng rỗng -> native tự dùng fallback đứng đơn giản. KHÔNG còn
    // truyền tên template/đường dẫn thư viện — native không tự đọc/chọn
    // pose nữa (đổi kiến trúc, giải quyết luôn lỗ hổng "skeleton không biết
    // ai là ai" — mục 12).
    // mục 81 TECHNICAL_STATUS.md — 3 tham số MỚI cân bằng Pose/Depth
    // ControlNet, dùng default = giá trị khuyến nghị (pose=1.0 chiếm ưu
    // thế, depth=0.6 hỗ trợ nhẹ, chỉ bật depth ở early-to-mid step
    // ~timestep>=300/999 — xem docstring export_ipa_controlnet_depth_unet.py
    // mục 81 cho giải thích đầy đủ). Model CŨ (chưa export lại) bỏ qua an
    // toàn (native tự phát hiện không có input tương ứng).
    // 2 tham số cuối — Smooth Timestep Decay cho IP-Adapter (mở rộng mục 81
    // sang IP-Adapter, xem forward() trong export_ipa_controlnet_unet.py /
    // export_ipa_controlnet_depth_unet.py cho công thức + GIỚI HẠN THẬT:
    // đây là XẤP XỈ scale-input, chưa xác nhận A/B ảnh thật). Default
    // ipDecayFloor=1.0f = KHÔNG suy giảm gì (tương thích ngược tuyệt đối).
    // ipStaticScale — mục 9: đóng gap "consistencyStrength chết", tầng
    // nhân riêng độc lập với decay, default 1.0f = cường độ gốc.
    external fun sdTxt2ImgWithReferenceAndPose(ctx: Long, prompt: String, negPrompt: String,
                                                referenceImagePath: String, skeletonData: FloatArray,
                                                width: Int, height: Int, steps: Int, cfgScale: Float,
                                                seed: Long, outputPath: String,
                                                poseConditioningScale: Float = 1.0f,
                                                depthConditioningScale: Float = 0.6f,
                                                depthActiveMinTimestep: Float = 300.0f,
                                                ipDecayFloor: Float = 1.0f,
                                                ipDecayStartTimestep: Float = 999.0f,
                                                ipStaticScale: Float = 1.0f,
                                                // mục 134 TECHNICAL_STATUS.md — trước đây hàm này KHÔNG có
                                                // callback per-step (khác sdImg2ImgWithReferenceAndPose bên
                                                // dưới) — ImagePipeline.generatePanel() phải báo tiến trình
                                                // GIẢ ("0 rồi nhảy thẳng lên steps") cho nhánh augmented.
                                                // Đã nối THẬT ở ip_adapter.cpp (xem comment ở đó) — tham số
                                                // thêm CUỐI để không phá thứ tự các default value cũ.
                                                callback: SDProgressCallback? = null): Boolean

    // mục 115/117 TECHNICAL_STATUS.md — Multi-Pass Inpainting Cascade: ghép
    // img2img+mask (sdImg2Img) VỚI IP-Adapter+ControlNet-Pose
    // (sdTxt2ImgWithReferenceAndPose) — trước hàm này, 2 khả năng tồn tại
    // RIÊNG BIỆT, không ghép được cho use-case "inpaint lại đúng 1 người
    // trong cảnh đông người, giữ đúng danh tính người đó". Dùng ctx đã
    // sdInitAugmented() (giống sdTxt2ImgWithReferenceAndPose — KHÔNG dùng
    // ctx thường sdInit()/sdImg2Img() vì cần handle->ipEncoder).
    external fun sdImg2ImgWithReferenceAndPose(ctx: Long, prompt: String, negPrompt: String,
                                                inputImagePath: String, maskImagePath: String,
                                                referenceImagePath: String, skeletonData: FloatArray,
                                                denoiseStrength: Float,
                                                width: Int, height: Int, steps: Int, cfgScale: Float,
                                                seed: Long, outputPath: String,
                                                poseConditioningScale: Float = 1.0f,
                                                depthConditioningScale: Float = 0.6f,
                                                depthActiveMinTimestep: Float = 300.0f,
                                                ipDecayFloor: Float = 1.0f,
                                                ipDecayStartTimestep: Float = 999.0f,
                                                ipStaticScale: Float = 1.0f,
                                                callback: SDProgressCallback? = null): Boolean

    // ── Multi-IP-Adapter CÓ MASK VÙNG, 2 nhân vật (mục "Multi-IP-Adapter /
    // Regional Prompting local" cuối TECHNICAL_STATUS.md — trước đây "CHỦ
    // ĐỘNG CHƯA làm", giờ đã triển khai theo API "IP-Adapter masking" CHÍNH
    // THỨC của diffusers, xem tools/export_ipa_controlnet_mask_unet.py).
    // Dùng CHUNG ctx đã sdInitAugmented() NHƯNG unetAugmentedPath lúc đó
    // PHẢI trỏ tới unet_ipa_mask_controlnet.mnn (bản 2 nhân vật) — KHÔNG
    // dùng lẫn với unet_ipa_controlnet.mnn (1 nhân vật/depth), 2 file có
    // input "ip_image_embeds" khác shape nhau. referenceImagePath1/2: thứ
    // tự PHẢI khớp đúng thứ tự người trong skeletonData (person[0] <->
    // referenceImagePath1, person[1] <-> referenceImagePath2 — cùng
    // invariant thứ tự đã xác lập ở mục 32/33).
    external fun sdTxt2ImgWithTwoReferencesAndPose(ctx: Long, prompt: String, negPrompt: String,
                                                    referenceImagePath1: String, referenceImagePath2: String,
                                                    skeletonData: FloatArray,
                                                    width: Int, height: Int, steps: Int, cfgScale: Float,
                                                    seed: Long, outputPath: String): Boolean
    // ── TỔNG QUÁT HOÁ mục trên: N NHÂN VẬT thay vì cố định 2 (mục 52
    // TECHNICAL_STATUS.md — "nếu ảnh có >2 nhân vật thì sao"). N THẬT SỰ
    // dùng được bị giới hạn bởi model .mnn đã export (cố định lúc
    // tools/export_ipa_controlnet_mask_unet.py --num_characters N — mỗi N
    // cần 1 file .mnn riêng, KHÔNG có 1 file dùng chung mọi N). Dùng ctx đã
    // sdInitAugmented() với unetAugmentedPath trỏ tới đúng file
    // unet_ipa_mask_controlnet_{N}char.mnn khớp referenceImagePaths.size.
    // referenceImagePaths: thứ tự PHẢI khớp đúng thứ tự người trong
    // skeletonData (cùng invariant mục 32/33). sdTxt2ImgWithTwoReferences
    // AndPose() ở trên VẪN GIỮ NGUYÊN (trường hợp riêng N=2), không bị thay
    // thế — dùng hàm nào cũng được cho N=2.
    external fun sdTxt2ImgWithCharactersAndPose(ctx: Long, prompt: String, negPrompt: String,
                                                 referenceImagePaths: Array<String>,
                                                 skeletonData: FloatArray,
                                                 width: Int, height: Int, steps: Int, cfgScale: Float,
                                                 seed: Long, outputPath: String,
                                                 // mục 100 — Smooth Timestep Decay + consistencyStrength,
                                                 // mở rộng mục 97/99 sang đường mask N-nhân-vật. Default
                                                 // = KHÔNG đổi gì (tương thích ngược tuyệt đối).
                                                 ipDecayFloor: Float = 1.0f,
                                                 ipDecayStartTimestep: Float = 999.0f,
                                                 ipStaticScale: Float = 1.0f,
                                                 // mục 147 — Per-Instance Decay: 3 mảng TUỲ CHỌN (null hợp
                                                 // lệ, mặc định null = dùng scalar 3 tham số trên cho MỌI
                                                 // nhân vật — tương thích ngược tuyệt đối). Truyền đủ thì
                                                 // MỖI nhân vật suy giảm ĐỘC LẬP — xem
                                                 // ImagePipeline.generatePanelMultiChar() cho cách tính.
                                                 ipDecayFloors: FloatArray? = null,
                                                 ipDecayStartTimesteps: FloatArray? = null,
                                                 ipStaticScales: FloatArray? = null,
                                                 // mục 217 (đợt 2) TECHNICAL_STATUS.md — "Location Anchor" slot
                                                 // thứ N+1. null/rỗng = KHÔNG dùng (tương thích ngược tuyệt đối).
                                                 // Thứ tự tham số PHẢI khớp CHÍNH XÁC với 2 tham số cuối trước
                                                 // callback trong chữ ký JNI thật ở ip_adapter.cpp — xem "GIỚI
                                                 // HẠN THẬT" ở đó cho lý do KHÔNG tự suy ra được N model đã
                                                 // export có slot này hay chưa: StoryManager.hasMultiCharMaskUnetWithLocation()
                                                 // PHẢI được gọi TRƯỚC ở MangaPipeline.kt để quyết định model nào
                                                 // nạp, hàm native này không tự kiểm tra lại.
                                                 locationAnchorPath: String? = null,
                                                 locationScale: Float = 0.5f,
                                                 // mục 134 — nối progress callback per-step, cùng lý do/mẫu
                                                 // hình như sdTxt2ImgWithReferenceAndPose ở trên.
                                                 callback: SDProgressCallback? = null): Boolean
    external fun sdFreeAugmented(ctx: Long)

    // mục 222-225 TECHNICAL_STATUS.md — GLIGEN (Grounded Language-to-Image
    // Generation, CVPR 2023): ép tỷ lệ vật thể NỀN (cây, nhà, tường...)
    // bằng bounding-box hình học thay vì hy vọng SD1.5 tự "hiểu" từ chữ
    // (xem tools/export_gligen_unet.py, app/src/main/jni/gligen_wrapper.cpp
    // cho toàn bộ nguồn/GIỚI HẠN THẬT). KHÔNG có ipEncoderPath (khác
    // sdInitAugmented) — GLIGEN không dùng ảnh tham chiếu, chỉ dùng NHÃN
    // CHỮ + hộp toạ độ, encode qua CHÍNH clip.mnn (đường dẫn clipPath).
    // mục 226 — ipEncoderPath: RỖNG = biến thể unet_gligen.mnn thường (không
    // nhân vật); có đường dẫn ip_image_encoder.mnn = biến thể "_char" (GLIGEN
    // + IP-Adapter cho 1 nhân vật chính). Thứ tự (sau vaeEncoderPath, trước
    // tokenizerPath) khớp CHÍNH XÁC chữ ký JNI thật ở gligen_wrapper.cpp và
    // mirror sdInitAugmented.
    external fun sdInitGligen(modelDir: String, clipPath: String, unetGligenPath: String,
                               vaeDecoderPath: String, vaeEncoderPath: String,
                               ipEncoderPath: String,
                               tokenizerPath: String, embeddingsDir: String,
                               useOpenCL: Boolean = false, useNpu: Boolean = false): Long

    // labels/boxesFlat: 2 mảng CÙNG thứ tự, ĐÚNG cách MangaPipeline.kt sẽ
    // dựng từ Scene.objectBoxes (mục 222/223 Models.kt) — boxesFlat là mảng
    // PHẲNG 4*N phần tử liên tiếp [xmin,ymin,xmax,ymax] từng vật thể (mirror
    // cách dự án truyền tensor phẳng ở nơi khác, vd characterMasks trong
    // sdTxt2ImgWithCharactersAndPoseSdxl) — KHÔNG dùng List<FloatArray> lồng
    // nhau (JNI xử lý mảng phẳng đơn giản/an toàn hơn mảng lồng).
    // mục 226 — referenceImagePath: ảnh anchor 1 nhân vật chính (null = không
    // có / model không phải "_char"). Vị trí (sau boxesFlat) khớp JNI thật.
    external fun sdTxt2ImgGligen(ctx: Long, prompt: String, negPrompt: String,
                                  labels: Array<String>, boxesFlat: FloatArray,
                                  referenceImagePath: String?,
                                  width: Int, height: Int, steps: Int, cfgScale: Float,
                                  seed: Long, outputPath: String,
                                  callback: SDProgressCallback? = null): Boolean

    external fun sdFreeGligen(ctx: Long)

    // ── SDXL augmented (mục 177 TECHNICAL_STATUS.md — SDXL Phase 2b) —
    // bản SDXL tương đương sdInitAugmented/sdTxt2ImgWithReferenceAndPose ở
    // trên, nhưng CHỈ phần cơ bản (1 nhân vật, IP-Adapter + ControlNet-
    // Pose, KHÔNG depth/decay/mask N-nhân-vật — xem "PHẠM VI" đầu
    // ip_adapter_sdxl.cpp). clipL/clipG THAY vì 1 clipPath (SDXL có 2 text
    // encoder, giống sdInitSdxl trong mnn_diffusion_pipeline.cpp).
    external fun sdInitAugmentedSdxl(modelDir: String, clipLPath: String, clipGPath: String,
                                      unetAugmentedPath: String, vaeDecoderPath: String,
                                      vaeEncoderPath: String, ipEncoderPath: String,
                                      tokenizerPath: String, embeddingsDir: String,
                                      useOpenCL: Boolean = false, useNpu: Boolean = false): Long
    // controlHintRgb: PHẢI render sẵn qua renderSkeletonCanvas() (mục 69,
    // khai báo bên dưới) rồi truyền vào ĐÂY — KHÁC
    // sdTxt2ImgWithReferenceAndPose (SD1.5) nhận skeletonData thô rồi tự vẽ
    // — xem comment đầu ip_adapter_sdxl.cpp cho lý do (không cross-include
    // pose_templates, cùng quy ước sdTxt2ImgTripleCombo/sdTxt2ImgRegionalMask).
    // depthHintRgb: TUỲ CHỌN, MỚI (mục 181 TECHNICAL_STATUS.md, Phase 2f) —
    // render qua renderDepthHintCanvas() (mục 69), truyền ByteArray(0) nếu
    // panel không cần depth.
    external fun sdTxt2ImgWithReferenceAndPoseSdxl(ctx: Long, prompt: String, negPrompt: String,
                                                    referenceImagePath: String, controlHintRgb: ByteArray,
                                                    depthHintRgb: ByteArray,
                                                    controlSize: Int, width: Int, height: Int, steps: Int,
                                                    cfgScale: Float, seed: Long, outputPath: String,
                                                    callback: SDProgressCallback? = null): Boolean
    // mục 178 TECHNICAL_STATUS.md (SDXL Phase 2c) — Mask N-nhân-vật, bản
    // SDXL tương đương sdTxt2ImgWithCharactersAndPose ở trên. characterMasks
    // là mảng PHẲNG N khối controlSize*controlSize byte, ĐÚNG thứ tự
    // referenceImagePaths (cùng invariant mục 32/33/52b/178). KHÔNG có 6
    // tham số decay (khác bản SD1.5 — xem "PHẠM VI" đầu
    // tools/export_ipa_controlnet_mask_unet_sdxl.py).
    external fun sdTxt2ImgWithCharactersAndPoseSdxl(ctx: Long, prompt: String, negPrompt: String,
                                                     referenceImagePaths: Array<String>,
                                                     characterMasks: ByteArray, controlHintRgb: ByteArray,
                                                     controlSize: Int, width: Int, height: Int, steps: Int,
                                                     cfgScale: Float, seed: Long, outputPath: String,
                                                     // mục 218 TECHNICAL_STATUS.md — "Location Anchor" slot
                                                     // thứ N+1, mirror ĐÚNG bản SD1.5. null/rỗng = KHÔNG
                                                     // dùng. Thứ tự PHẢI khớp CHÍNH XÁC với tham số tương
                                                     // ứng (trước callback) trong chữ ký JNI thật ở
                                                     // ip_adapter_sdxl.cpp.
                                                     locationAnchorPath: String? = null,
                                                     callback: SDProgressCallback? = null): Boolean
    external fun sdFreeAugmentedSdxl(ctx: Long)

    // mục 207 TECHNICAL_STATUS.md — PLAIN SDXL (KHÔNG IP-Adapter), dùng
    // riêng cho auto-fix vùng nhỏ (tryAutoFixInteractions() qua
    // img2imgFixSdxl() trong ImagePipeline.kt) — mirror ĐÚNG cặp
    // sdInit()/sdImg2Img()/sdFree() của SD1.5 (mnn_diffusion_pipeline.cpp),
    // KHÔNG phải sdInitAugmentedSdxl ở trên (không cần IP-Adapter/pose cho
    // việc "vẽ lại đúng 1 vùng nhỏ theo prompt"). Dùng CHUNG file model
    // `unet_sdxl.mnn`/`clip_l.mnn`/`clip_g.mnn`/`vae_decoder.mnn`/
    // `vae_encoder.mnn`/`tokenizer.json` với sdInitAugmentedSdxl — cùng thư
    // mục model SDXL (xem prepare_models.yml, ĐÃ export + copy sẵn, không
    // cần model riêng).
    external fun sdInitSdxl(modelDir: String, clipLPath: String, clipGPath: String,
                             unetPath: String, vaeDecoderPath: String, vaeEncoderPath: String,
                             tokenizerPath: String, embeddingsDir: String,
                             useOpenCL: Boolean = false, useNpu: Boolean = false): Long
    // KHÔNG có tham số ultrafix/ultrafixTile — khác sdImg2Img (SD1.5) —
    // PipelineSdxlCpu CHƯA hỗ trợ Ultrafix/tiling (xem GIỚI HẠN THẬT ở
    // comment C++ tương ứng, ip_adapter_sdxl.cpp mục 207).
    external fun sdImg2ImgSdxl(ctx: Long, prompt: String, negPrompt: String, inputImagePath: String,
                                maskImagePath: String, denoiseStrength: Float, width: Int, height: Int,
                                steps: Int, cfgScale: Float, seed: Long,
                                outputPath: String, callback: SDProgressCallback): Boolean
    external fun sdFreeSdxl(ctx: Long)

    // ── Regional Prompting SDXL (mục 179 TECHNICAL_STATUS.md — SDXL Phase
    // 2d) — bản SDXL tương đương sdInitRegional/sdTxt2ImgRegional ở dưới.
    // clipL/clipG THAY vì 1 clipPath (SDXL 2 text encoder, giống
    // sdInitAugmentedSdxl ở trên).
    external fun sdInitRegionalSdxl(modelDir: String, clipLPath: String, clipGPath: String,
                                     unetRegionalPath: String, vaeDecoderPath: String,
                                     vaeEncoderPath: String, tokenizerPath: String,
                                     embeddingsDir: String, numRegions: Int,
                                     useOpenCL: Boolean = false, useNpu: Boolean = false): Long
    external fun sdTxt2ImgRegionalSdxl(ctx: Long, regionPrompts: Array<String>, negPrompt: String,
                                        controlHintRgb: ByteArray, controlSize: Int, width: Int,
                                        height: Int, steps: Int, cfgScale: Float, seed: Long,
                                        outputPath: String, callback: SDProgressCallback? = null): Boolean
    external fun sdFreeRegionalSdxl(ctx: Long)

    // ── Regional-Mask / Attention Couple SDXL (mục 180 TECHNICAL_STATUS.md
    // — SDXL Phase 2e) — bản SDXL tương đương sdInitRegionalMask/
    // sdTxt2ImgRegionalMask ở dưới.
    external fun sdInitRegionalMaskSdxl(modelDir: String, clipLPath: String, clipGPath: String,
                                         unetRegionalMaskPath: String, vaeDecoderPath: String,
                                         vaeEncoderPath: String, tokenizerPath: String,
                                         embeddingsDir: String, numRegions: Int,
                                         useOpenCL: Boolean = false, useNpu: Boolean = false): Long
    external fun sdTxt2ImgRegionalMaskSdxl(ctx: Long, regionPrompts: Array<String>, backgroundPrompt: String,
                                            negPrompt: String, regionMasks: ByteArray, controlHintRgb: ByteArray,
                                            controlSize: Int, width: Int, height: Int, steps: Int,
                                            cfgScale: Float, seed: Long, outputPath: String,
                                            callback: SDProgressCallback? = null): Boolean
    external fun sdFreeRegionalMaskSdxl(ctx: Long)

    // ── Regional Prompting THẬT (mục 56 TECHNICAL_STATUS.md — prompt CHỮ
    // riêng cho từng vùng, KHÁC sdInitAugmented ở trên là gán ẢNH nhân vật
    // riêng cho từng vùng, mục 52). Model unet_regional_*.mnn CÓ INPUT
    // KHÁC HẲN unet_augmented (xem regional_prompting.cpp) — dùng ctx RIÊNG
    // (không dùng chung sdInitAugmented). tokenizerPath/embeddingsDir giống
    // hệt quy ước sdInitAugmented ở trên.
    external fun sdInitRegional(modelDir: String, clipPath: String, unetRegionalPath: String,
                                 vaeDecoderPath: String, vaeEncoderPath: String,
                                 tokenizerPath: String, embeddingsDir: String, numRegions: Int,
                                 useOpenCL: Boolean = false, useNpu: Boolean = false): Long

    // regionPrompts: N chuỗi, THỨ TỰ trái->phải (vùng 0 = cột trái nhất) —
    // PHẢI khớp đúng numRegions đã dùng lúc sdInitRegional VÀ đúng
    // --num_regions lúc export model (tools/export_ipa_controlnet_regional_unet.py).
    // controlHintRgb: canvas RGB pose thô 0-255 (kotlin tự dựng — dự án
    // CHƯA có hàm dựng skeleton canvas dùng chung giữa Kotlin và cả 2 file
    // native (ip_adapter.cpp/regional_prompting.cpp), xem mục 56 phần "CHƯA
    // làm"), độ dài PHẢI = controlSize*controlSize*3.
    external fun sdTxt2ImgRegional(ctx: Long, regionPrompts: Array<String>, negPrompt: String,
                                    controlHintRgb: ByteArray, controlSize: Int,
                                    width: Int, height: Int, steps: Int, cfgScale: Float,
                                    seed: Long, outputPath: String,
                                    // mục 134 — nối progress callback per-step, cùng lý do/mẫu hình
                                    // như 2 hàm augmented ở trên (trước đây CHỈ báo tiến trình GIẢ).
                                    callback: SDProgressCallback? = null): Boolean
    external fun sdFreeRegional(ctx: Long)

    // mục 172 TECHNICAL_STATUS.md — đối tác Kotlin của
    // regional_mask_prompting.cpp (Regional Prompting MASK hình dạng tuỳ ý,
    // khác bản CỘT ở trên). numRegions ĐÚNG --num_regions lúc export
    // tools/export_ipa_controlnet_regional_mask_unet.py.
    external fun sdInitRegionalMask(modelDir: String, clipPath: String, unetRegionalMaskPath: String,
                                     vaeDecoderPath: String, vaeEncoderPath: String,
                                     tokenizerPath: String, embeddingsDir: String, numRegions: Int,
                                     useOpenCL: Boolean = false, useNpu: Boolean = false): Long

    // regionPrompts: N chuỗi ĐÚNG THỨ TỰ với regionMasks (khối i của mask
    // khớp prompt i — KHÔNG còn ý nghĩa "trái->phải" như bản cột, vì mask
    // giờ hình dạng tuỳ ý). backgroundPrompt: 1 chuỗi cho vùng KHÔNG mask
    // nào phủ (mục 172, KHÁC bản cột — bản cột không cần vì cột phủ kín
    // 100% ảnh). regionMasks: N khối liên tiếp, MỖI khối controlSize*
    // controlSize byte (1 kênh, 0-255) — dựng bằng
    // MangaPipeline.buildCharacterBodyMaskFile() (ĐÃ CÓ SAM, mục 168) rồi
    // đọc kênh alpha, KHÔNG dựng lại phía C++ (xem comment đầu file .cpp).
    // Độ dài PHẢI = regionPrompts.size * controlSize * controlSize.
    external fun sdTxt2ImgRegionalMask(ctx: Long, regionPrompts: Array<String>, backgroundPrompt: String,
                                        negPrompt: String, regionMasks: ByteArray,
                                        controlHintRgb: ByteArray, controlSize: Int,
                                        width: Int, height: Int, steps: Int, cfgScale: Float,
                                        seed: Long, outputPath: String,
                                        callback: SDProgressCallback? = null): Boolean
    external fun sdFreeRegionalMask(ctx: Long)
    external fun sdFree(ctx: Long)

    // mục 151 TECHNICAL_STATUS.md — Triple-Conditioning combo (Regional
    // Prompting + IP-Adapter mask + Depth ControlNet CÙNG LÚC 1 UNet, xem
    // tools/export_ipa_controlnet_triple_combo_unet.py mục 143 + nối dây
    // app_side triple_combo.cpp mục 151). Model `unet_triple_combo_
    // {N}region.mnn` RIÊNG — không dùng chung ctx với sdInitAugmented/
    // sdInitRegional. `ipEncoderPath` = ip_image_encoder.mnn (CÙNG file
    // dùng cho sdInitAugmented, không phải model riêng).
    external fun sdInitTripleCombo(modelDir: String, clipPath: String, unetTriplePath: String,
                                    vaeDecoderPath: String, vaeEncoderPath: String,
                                    ipEncoderPath: String, tokenizerPath: String, embeddingsDir: String,
                                    numRegions: Int,
                                    useOpenCL: Boolean = false, useNpu: Boolean = false): Long

    // regionPrompts/referenceImagePaths: PHẢI CÙNG ĐỘ DÀI, CÙNG THỨ TỰ (1
    // cột = 1 nhân vật = 1 phần tử ở CẢ 2 mảng — xem GIỚI HẠN THẬT trong
    // docstring export script: ranh giới cột cứng dùng CHUNG cho cả danh
    // tính ảnh lẫn prompt chữ). poseHintRgb/depthHintRgb: canvas RGB dựng
    // qua renderSkeletonCanvas()/renderDepthHintCanvas(), ĐỘ DÀI PHẢI =
    // controlSize*controlSize*3.
    external fun sdTxt2ImgTripleCombo(ctx: Long, regionPrompts: Array<String>, negPrompt: String,
                                       referenceImagePaths: Array<String>,
                                       poseHintRgb: ByteArray, depthHintRgb: ByteArray, controlSize: Int,
                                       width: Int, height: Int, steps: Int, cfgScale: Float,
                                       seed: Long, outputPath: String,
                                       poseScale: Float = 1.0f, depthScale: Float = 0.6f,
                                       ipDecayFloor: Float = 1.0f, ipDecayStartTimestep: Float = 999.0f,
                                       // mục 219 TECHNICAL_STATUS.md — "Location Anchor" đợt 3.
                                       // null/rỗng = KHÔNG dùng slot bối cảnh (tương thích ngược
                                       // tuyệt đối — chỉ có tác dụng nếu model .mnn đang nạp có
                                       // hậu tố "_loc", xem StoryManager.hasTripleComboUnetWithLocation()).
                                       // Thứ tự PHẢI khớp CHÍNH XÁC chữ ký JNI thật ở triple_combo.cpp.
                                       locationAnchorPath: String? = null, locationScale: Float = 0.5f,
                                       callback: SDProgressCallback? = null): Boolean
    external fun sdFreeTripleCombo(ctx: Long)

    // mục 142 TECHNICAL_STATUS.md — cờ ngắt cuốn chiếu vòng lặp denoise
    // native (sd_engine/Pipeline.hpp, biến toàn cục g_generation_interrupted
    // — dùng chung mọi Pipeline vì app chỉ chạy 1 generate() tại 1 thời
    // điểm, xem generationMutex ở MainViewModel.kt). Gọi
    // signalInterruptNative() TRƯỚC/CÙNG lúc cancelAndJoin() (xem
    // MangaPipeline.cancelSafely(), mục 84 + 142) để native tự dừng ở step
    // kế tiếp thay vì phải chạy hết toàn bộ số step còn lại. KHÔNG thay
    // thế withTimeoutOrNull() ở mục 84 — chỉ giảm khả năng chạm timeout.
    external fun signalInterruptNative()
    // mục 248 — bật/tắt Differential Diffusion cho img2img có mask (cờ toàn cục native; mặc định tắt)
    external fun setDifferentialDiffusion(enabled: Boolean)

    // mục 262 — thêm nhiễu cho ảnh gốc ở mức timesteps[i+1] (đúng mức của latent sau bước) khi trộn mask; bước cuối dùng ảnh sạch. Mặc định tắt (xem MaskBlend.hpp).
    external fun setMaskBlendMatched(enabled: Boolean)

    // mục 261 — OccCFG (PersonaCraft Eq.4, CFG biến thiên theo không gian). map = w*h float [0,1] (thường latent = width/8 x height/8).
    // boost = k_occ / cfg. Cờ toàn cục native: người gọi PHẢI clearOccCfg() trong finally.
    external fun setOccCfg(map: FloatArray, w: Int, h: Int, boost: Float)
    external fun clearOccCfg()

    // mục 261 — LoRA Switch/Composite (Multi-LoRA Composition, arXiv 2402.16843). extraUnetPaths = đường dẫn unet.mnn của các biến thể PHỤ
    // (UNet chính = model đang nạp). activeCount: 1 = Switch, k = Composite. tau: bước đổi LoRA (bài: 5). Cờ toàn cục: PHẢI clearLoraCompose().
    external fun setLoraCompose(activeCount: Int, tau: Int, extraUnetPaths: Array<String>, weights: FloatArray)
    external fun clearLoraCompose()
    // mục 261.11 — Regional Composite: k mask vùng liên tiếp (k*w*h, [0,1]) theo THỨ TỰ biến thể (UNet chính = mask 0). Gọi SAU setLoraCompose.
    external fun setLoraComposeMasks(masks: FloatArray, k: Int, w: Int, h: Int)
    // mục 261.14 — CLIP riêng của từng UNet phụ (đường dẫn clip.mnn, "" = dùng CLIP chính). Gọi SAU setLoraCompose; số phần tử = số UNet phụ.
    external fun setLoraComposeClips(clips: Array<String>)

    external fun clearInterruptNative()

    // mục 69 TECHNICAL_STATUS.md — đóng gap "Kotlin cần tự dựng skeleton
    // canvas cho Regional Prompting" bằng cách gọi LẠI hàm renderSkeletons()
    // native đã dùng thật cho ip_adapter.cpp (KHÔNG viết lại thuật toán vẽ
    // ở Kotlin — tránh 2 nơi vẽ khác định dạng nhau). skeletonData: cùng
    // định dạng MangaPipeline.resolveSkeletonData() trả về. size PHẢI khớp
    // controlSize truyền vào sdTxt2ImgRegional() (512, theo quy ước
    // renderSkeletons() dùng cho pipeline IP-Adapter). Trả mảng RỖNG nếu
    // skeletonData không hợp lệ — gọi nơi KHÔNG throw, tự kiểm tra size==0.
    external fun renderSkeletonCanvas(skeletonData: FloatArray, size: Int): ByteArray

    // mục 151 TECHNICAL_STATUS.md — song sinh với renderSkeletonCanvas() ở
    // trên, dùng cho depth_hint của pipeline Triple-Conditioning combo
    // (xem ip_adapter.cpp — hàm này nằm ở đó, không phải triple_combo.cpp,
    // vì namespace pose_templates chỉ có ở file đó).
    external fun renderDepthHintCanvas(skeletonData: FloatArray, size: Int): ByteArray

    // Convert on-device: dir chứa "checkpoint.safetensors" + tuỳ chọn
    // "lora1.safetensors"... + BẮT BUỘC đã có sẵn unet.mnn/vae_decoder.mnn/
    // vae_encoder.mnn "khung" từ trước (xem sd_model_converter.cpp).
    // KHÔNG cần sdInit trước — đây là tool độc lập, chạy 1 lần trước khi
    // model đó dùng được trong sdInit.
    // orthogonalLora (mục 55 TECHNICAL_STATUS.md): Gram-Schmidt trực giao
    // hoá delta LoRA khi loraFiles.size() >= 2 — giảm 1 dạng nhiễu (nhiều
    // LoRA cộng dồn cùng hướng), KHÔNG đảm bảo hết identity bleeding (xem
    // comment applyLoRA() trong SafeTensor2MNN.hpp cho giới hạn thật, dựa
    // trên nghiên cứu 2025 còn tranh cãi). Mặc định false = giữ NGUYÊN
    // hành vi cộng dồn trực tiếp cũ.
    external fun sdConvertModel(dir: String, safetensorFile: String, clipSkip2: Boolean,
                                 loraFiles: Array<String>, loraWeights: FloatArray,
                                 orthogonalLora: Boolean = false,
                                 // mục 259: mergeMode 0 = cộng như cũ (hoặc trực giao theo cờ trên), 2 = TIES (cần >= 2 LoRA).
                                 // tiesDensity = tỉ lệ phần tử giữ lại mỗi delta (0.05..1); dareDrop = xác suất bỏ ngẫu nhiên (0..0.95).
                                 mergeMode: Int = 0, tiesDensity: Float = 0.5f, dareDrop: Float = 0f): Boolean

    // ── ESRGAN ───────────────────────────────────────────────────────────
    external fun esrganInit(scale: Int, modelDir: String): Long
    external fun esrganUpscale(ctx: Long, inputPath: String, outputPath: String, sharpen: Boolean): Boolean
    external fun esrganFree(ctx: Long)

    // ── YOLOv8n (object/face detection cho auto bubble) ──────────────────
    external fun yoloInit(modelDir: String): Long
    external fun yoloDetect(ctx: Long, imagePath: String): FloatArray // [x1,y1,x2,y2,conf, ...] normalized
    external fun yoloFree(ctx: Long)

    // ── YOLOv8-pose (mục 19 TECHNICAL_STATUS.md — thay MediaPipe Pose) ──
    // Trả về mảng float phẳng, mỗi người 56 giá trị liên tiếp:
    // [x1,y1,x2,y2,conf, kp0_x,kp0_y,kp0_vis, ..., kp16_x,kp16_y,kp16_vis]
    // (17 keypoint COCO chuẩn Ultralytics, x/y normalized 0..1, vis 0..1).
    // Map sang OpenPose-18 làm ở Kotlin (PoseExtractor.kt), không ở native.
    external fun yoloPoseInit(modelDir: String): Long
    external fun yoloPoseDetect(ctx: Long, imagePath: String, confThresh: Float, iouThresh: Float): FloatArray
    external fun yoloPoseFree(ctx: Long)

    // ── MiDaS-small (mục 232 TECHNICAL_STATUS.md) — độ sâu ĐƠN ẢNH ──────────
    // midasEstimate trả 256*256 float 0..1 (1 = GẦN camera nhất trong CHÍNH ảnh
    // đó), hàng trước cột sau; mảng RỖNG nếu lỗi. Model: midas_small_depth.mnn
    // trong thư mục truyền vào midasInit (StoryManager.yoloDir).
    external fun midasInit(modelDir: String): Long
    external fun midasEstimate(ctx: Long, imagePath: String): FloatArray
    external fun midasFree(ctx: Long)

    // ── ArcFace MobileFaceNet (mục 246) — embedding khuôn mặt ĐÃ CĂN CHỈNH 112x112 ────────────────────────────
    // arcfaceEmbed nhận đường dẫn ảnh 112x112 RGB đã căn chỉnh, trả 512 float đã L2-normalize; mảng RỖNG nếu lỗi.
    external fun arcfaceInit(modelDir: String): Long
    external fun arcfaceEmbed(ctx: Long, alignedImagePath: String): FloatArray
    external fun arcfaceFree(ctx: Long)

    // ── MobileSAM click-to-mask (mục 21 TECHNICAL_STATUS.md — "Inpaint
    // Anything" cho UI mask thủ công ở phase cuối) ──
    // Trả về đường dẫn PNG mask đã ghi (trắng=inpaint, đen=giữ nguyên —
    // cùng quy ước buildMaskFile() trong MangaPipeline.kt), feed thẳng vào
    // sdImg2Img() — CÙNG 1 inpainting với auto-fix mặt/tay, không tách riêng.
    external fun mobileSamInit(modelDir: String): Long
    external fun mobileSamClickToMask(ctx: Long, imagePath: String, clickX: Float, clickY: Float, outMaskPath: String): String
    external fun mobileSamFree(ctx: Long)

    // mục 280 TECHNICAL_STATUS.md — BlazePose GHUM 3D (blazepose_wrapper.cpp). Init: thư mục chứa blazepose_full.mnn hoặc blazepose_lite.mnn (0 nếu thiếu/lỗi).
    // Run: 256*256*3 float RGB 0..1 (HWC, ảnh đã cắt ROI bởi BlazePoseLift.sampleCrop) → 313 float [cờ có người, 39*5 điểm ảnh, 39*3 điểm world mét]; MẢNG RỖNG nếu lỗi.
    external fun blazePoseInit(modelDir: String): Long
    external fun blazePoseRun(ctx: Long, rgb256: FloatArray): FloatArray
    external fun blazePoseFree(ctx: Long)

    interface SDProgressCallback {
        fun onProgress(step: Int, totalSteps: Int)
    }
}
