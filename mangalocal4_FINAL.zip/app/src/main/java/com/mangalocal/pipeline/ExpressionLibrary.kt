package com.mangalocal.pipeline

import com.google.gson.Gson
import com.mangalocal.model.ImageStyle
import com.mangalocal.model.PromptStyle
import java.io.File
import java.util.UUID

/**
 * mục 240 TECHNICAL_STATUS.md — HỆ THỐNG BIỂU CẢM / DIỄN XUẤT TẬP TRUNG (cùng vai trò với thư viện tư thế
 * khung xương: một nơi quản lý, dùng chung cho LLM, từng panel, từng nhân vật).
 *
 * Trước mục này biểu cảm chỉ là 12 nhãn cố định (LLMParser.EXPRESSION_TAGS) đi qua prompt chính. Cộng đồng làm
 * khác (xem mục 238/240): (1) biểu cảm được CẤU TẠO từ thành phần nhỏ — lông mày, mắt, miệng, chi tiết phụ
 * (đổ mồ hôi, nước mắt, mặt xám...), hướng nhìn, nghiêng đầu — giống Action Unit của FACS và giống cách người
 * dùng ghép tag danbooru; (2) mỗi nhân vật có "bảng biểu cảm" (expression sheet) dùng làm ẢNH THAM CHIẾU thay
 * cho ảnh trung tính (xem Character.expressionAnchors); (3) quản lý diễn biến cảm xúc xuyên panel.
 *
 * File này gồm: từ vựng thành phần, bộ biểu cảm dựng sẵn mở rộng (đặc biệt cho cảnh vật lộn: đau, gắng sức,
 * gầm thét, hoảng sợ, kiệt sức, chiến thắng...), hàm ghép prompt theo PromptStyle + cường độ, và
 * `ExpressionRegistry` (biểu cảm tự tạo của người dùng, lưu JSON).
 *
 * TỪ VỰNG: lấy từ nhóm tag mặt/biểu cảm của danbooru (cùng hệ tag mà checkpoint anime SD1.5/SDXL được huấn
 * luyện): furrowed brow, half-closed eyes, wince, clenched teeth, shaded face, crying with eyes open, looking
 * away... Tag dạng ngôn ngữ tự nhiên (`nl`) do tôi tự diễn đạt cho checkpoint ảnh thực (PromptStyle
 * NATURAL_LANGUAGE) — KHÔNG phải trích nguồn nào.
 *
 * GIỚI HẠN THẬT: chưa đo trên checkpoint nào cụ thể; một số tag ít phổ biến có thể yếu ở checkpoint không huấn
 * luyện theo danbooru (khi đó biểu cảm thể hiện nhạt — cần thử và chỉnh cường độ/tag).
 */
object ExpressionVocab {
    /**
     * @param verified true = tag có trong trang wiki CHÍNH THỨC của Danbooru (tag_group:face_tags, tag_group:eyes_tags,
     *   tag_group:posture) hoặc hướng dẫn gắn tag của booru, đã đối chiếu ở mục 241. false = tag phổ biến nhưng
     *   KHÔNG tìm thấy trong nguồn đã tra (danh sách ở UNVERIFIED_TAGS, test sẽ báo nếu lệch).
     */
    data class Part(
        val key: String, val label: String, val tag: String, val nl: String, val verified: Boolean = true,
        // mục 242: cách diễn đạt cho checkpoint ẢNH THỰC (giải phẫu/cơ mặt, KHÔNG dùng tag riêng của anime như sweatdrop,
        // anger vein, kubrick stare, v-shaped eyebrows, shaded face). Mặc định = nl.
        val real: String = nl
    )

    val BROWS = listOf(
        Part("furrowed", "Cau mày", "furrowed brow", "furrowed brows", real = "furrowed brows"),
        Part("raised", "Nhướng cao", "raised eyebrows", "raised eyebrows", real = "raised eyebrows"),
        Part("one_raised", "Nhướng một bên", "raised eyebrow", "one raised eyebrow", real = "one eyebrow raised"),
        Part("v_shape", "Mày chữ V (giận)", "v-shaped eyebrows", "sharply angled, angry brows", real = "brows pulled sharply down and together"),
        Part("inner_up", "Mày xếch trong (buồn)", "raised inner eyebrows", "brows tilted up at the inner corners", real = "inner corners of the eyebrows lifted"),
        Part("worried", "Lo âu", "worried", "brows drawn together in worry", real = "worried eyebrows drawn together")
    )
    val EYES = listOf(
        Part("wide", "Mở to", "wide-eyed", "wide open eyes", real = "wide open eyes"),
        Part("narrowed", "Nheo lại", "narrowed eyes", "narrowed eyes", real = "narrowed eyes"),
        Part("squint", "Nheo (căng)", "squinting", "squinting eyes", real = "eyes squeezed into a tense squint"),
        Part("half_closed", "Lim dim", "half-closed eyes", "half-closed eyes", real = "heavy-lidded, half-closed eyes"),
        Part("closed", "Nhắm", "closed eyes", "closed eyes", real = "eyes shut tight"),
        Part("glare", "Lườm", "glaring", "a hard glare", real = "an intense glaring stare"),
        Part("kubrick", "Nhìn xoáy (đe doạ)", "kubrick stare", "a menacing stare from under lowered brows", real = "an intense stare looking up from under lowered brows with the head tilted down"),
        Part("teary", "Rưng rưng", "tears", "tearful, glistening eyes", real = "watery, teary eyes"),
        Part("crying_open", "Khóc mở mắt", "crying with eyes open", "crying with eyes open", real = "tears streaming down the cheeks with the eyes open"),
        Part("pleading", "Van nài", "pleading eyes", "pleading eyes", real = "wide, pleading eyes"),
        Part("empty", "Vô hồn", "empty eyes", "empty, lifeless eyes", real = "vacant, unfocused eyes"),
        Part("wink", "Nháy mắt", "one eye closed", "one eye closed in a wink", real = "one eye winking")
    )
    val MOUTH = listOf(
        Part("smile", "Cười nhẹ", "smile", "a smile", real = "a gentle smile"),
        Part("grin", "Cười toe", "grin", "a wide grin", real = "a wide grin showing teeth"),
        Part("smirk", "Nhếch mép", "smirk", "a smirk", real = "a one-sided smirk"),
        Part("laugh", "Cười lớn", "laughing, open mouth", "laughing with an open mouth", real = "laughing with an open mouth"),
        Part("open", "Há miệng", "open mouth", "an open mouth", real = "the mouth slightly open"),
        Part("round", "Miệng tròn (sững)", "round mouth", "a small round open mouth", real = "the mouth open in a small round O"),
        Part("shout", "Hét", "shouting, open mouth", "shouting with the mouth wide open", verified = false, real = "the mouth wide open, shouting"),
        Part("clenched", "Nghiến răng", "clenched teeth", "clenched teeth", real = "clenched teeth and a tense jaw"),
        Part("grimace", "Nhăn nhó", "grimace", "a grimace", real = "a grimace with the lips pulled back"),
        Part("frown", "Mếu/nhăn", "frown", "a frown", real = "a downturned mouth"),
        Part("pout", "Bĩu môi", "pout", "a pout", real = "pouting lips"),
        Part("parted", "Hé môi", "parted lips", "parted lips", real = "slightly parted lips"),
        Part("closed", "Mím môi", "closed mouth", "a closed mouth", real = "lips pressed together")
    )
    val EXTRAS = listOf(
        Part("blush", "Đỏ mặt", "blush", "flushed cheeks", real = "flushed cheeks"),
        Part("sweatdrop", "Giọt mồ hôi", "sweatdrop", "a bead of sweat", real = "a bead of sweat on the temple"),
        Part("sweat", "Đổ mồ hôi", "sweat", "sweat on the face", real = "sweat glistening on the face"),
        Part("wince", "Nhăn mặt đau", "wince", "wincing", real = "a wincing, scrunched face"),
        Part("pain", "Đau đớn", "pain", "a look of pain", real = "a face contorted in pain"),
        Part("struggling", "Vật lộn/gắng", "struggling", "struggling hard", real = "a face straining with effort"),
        Part("panicking", "Hoảng loạn", "panicking", "panicking", real = "a panicked look"),
        Part("panting", "Thở dốc", "heavy breathing", "breathing heavily, out of breath", real = "panting, out of breath"),  // id giữ "panting" (preset đã lưu); tag chuẩn Danbooru là "heavy breathing" (panting là alias — mục 247)
        Part("trembling", "Run rẩy", "trembling", "trembling", real = "trembling lips"),
        Part("shaded", "Mặt tối sầm", "shaded face", "a shadowed face", real = "the face partly in shadow"),
        Part("pale", "Tái mặt", "pale skin", "a pale face", real = "a pale, drained complexion"),
        Part("embarrassed", "Ngượng", "embarrassed", "an embarrassed look", real = "an embarrassed look"),
        Part("vein", "Gân nổi giận", "anger vein", "a bulging anger vein", real = "a visible vein bulging at the temple")
    )
    val GAZE = listOf(
        Part("viewer", "Nhìn thẳng", "looking at viewer", "looking straight at the viewer", real = "looking straight into the camera"),
        // Danbooru: "looking away" là tag MƠ HỒ; né ánh mắt có chủ ý dùng "averting eyes".
        Part("away", "Né ánh mắt", "averting eyes", "deliberately averting the eyes", real = "the eyes deliberately averted"),
        Part("down", "Nhìn xuống", "looking down", "looking down", real = "looking down"),
        Part("up", "Nhìn lên", "looking up", "looking up", real = "looking up"),
        Part("side", "Liếc sang bên", "looking to the side", "glancing to the side", real = "eyes glancing to the side")
    )
    val HEAD = listOf(
        Part("tilt", "Nghiêng đầu", "head tilt", "head tilted", real = "the head tilted"),
        Part("down", "Cúi đầu", "head down", "head lowered", real = "the head lowered")
    )

    fun find(list: List<Part>, key: String?): Part? = if (key == null) null else list.firstOrNull { it.key == key }

    /** Mọi tag chưa xác minh (để UI/test hiển thị trung thực). */
    fun unverifiedTags(): List<String> =
        (BROWS + EYES + MOUTH + EXTRAS + GAZE + HEAD).filter { !it.verified }.map { it.tag }
}

data class ExpressionPreset(
    val id: String,                 // built-in: khoá thường (vd "pain"); tự tạo: "x:<8 ký tự>"
    val name: String,               // tên hiển thị (tiếng Việt)
    val lead: String,               // cụm tiếng Anh mô tả chung, vd "pained expression" (dùng cho ngôn ngữ tự nhiên)
    val brows: String? = null,
    val eyes: String? = null,
    val mouth: String? = null,
    val extras: List<String>? = null, // nullable: Gson để null khi thiếu field trong JSON
    val gaze: String? = null,
    val head: String? = null,
    val intensity: Int = 2,         // 1 nhẹ, 2 vừa, 3 mạnh
    val builtIn: Boolean = false,
    // mục 241: tag danbooru dẫn đầu cho PromptStyle.TAG_BASED (checkpoint anime hiểu "pain" tốt hơn "pained expression").
    val tagLead: String? = null
)

object ExpressionLibrary {

    private fun p(
        id: String, name: String, lead: String, brows: String? = null, eyes: String? = null,
        mouth: String? = null, extras: List<String> = emptyList(), gaze: String? = null,
        head: String? = null, intensity: Int = 2, tagLead: String? = null
    ) = ExpressionPreset(id, name, lead, brows, eyes, mouth, extras, gaze, head, intensity, builtIn = true, tagLead = tagLead)

    /**
     * Biểu cảm dựng sẵn MỞ RỘNG (ngoài 12 nhãn gốc của LLMParser). `tagLead` là tag danbooru ĐÃ XÁC MINH trong trang
     * tag_group:face_tags (pain, struggling, panicking, despair, skeptical, exhausted, expressionless, scowl...)
     * để checkpoint anime hiểu trực tiếp; `lead` là cụm mô tả cho PromptStyle ngôn ngữ tự nhiên.
     */
    val EXTENDED_BUILTINS: List<ExpressionPreset> = listOf(
        p("pain", "Đau đớn", "pained expression", brows = "furrowed", eyes = "closed", mouth = "clenched", extras = listOf("wince", "sweat"), intensity = 3, tagLead = "pain"),
        p("exertion", "Gắng sức", "strained expression", brows = "furrowed", eyes = "squint", mouth = "clenched", extras = listOf("struggling", "sweat", "panting"), intensity = 3, tagLead = "struggling"),
        p("shouting", "Gầm thét", "shouting expression", brows = "v_shape", eyes = "narrowed", mouth = "shout", extras = listOf("vein"), intensity = 3, tagLead = "angry"),
        p("terrified", "Hoảng sợ", "terrified expression", brows = "inner_up", eyes = "wide", mouth = "open", extras = listOf("panicking", "pale", "sweatdrop", "trembling"), intensity = 3, tagLead = "scared"),
        p("exhausted", "Kiệt sức", "exhausted expression", eyes = "half_closed", mouth = "parted", extras = listOf("panting", "sweat"), gaze = "down", head = "down", tagLead = "exhausted"),
        p("triumphant", "Chiến thắng", "triumphant expression", brows = "raised", eyes = "narrowed", mouth = "grin", gaze = "viewer", intensity = 3, tagLead = "excited"),
        p("menacing", "Đe doạ", "menacing expression", brows = "v_shape", eyes = "kubrick", mouth = "smirk", extras = listOf("shaded"), head = "down", intensity = 3, tagLead = "scowl"),
        p("shocked", "Sững sờ", "shocked expression", brows = "raised", eyes = "wide", mouth = "round", extras = listOf("sweatdrop"), tagLead = "surprised"),
        p("anguished", "Đau khổ", "anguished expression", brows = "inner_up", eyes = "crying_open", mouth = "frown", intensity = 3, tagLead = "despair"),
        p("pleading", "Van xin", "pleading expression", brows = "inner_up", eyes = "pleading", mouth = "parted", gaze = "viewer", tagLead = "worried"),
        p("suspicious", "Nghi ngờ", "suspicious expression", brows = "one_raised", eyes = "narrowed", mouth = "closed", gaze = "side", tagLead = "skeptical"),
        p("laughing", "Cười lớn", "laughing expression", eyes = "half_closed", mouth = "laugh", extras = listOf("blush"), tagLead = "happy"),
        p("serene", "Thanh thản", "serene expression", eyes = "closed", mouth = "smile", intensity = 1, tagLead = "happy"),
        p("dazed", "Choáng váng", "dazed expression", eyes = "empty", mouth = "parted", extras = listOf("sweatdrop"), gaze = "away", tagLead = "expressionless"),
        p("winking", "Nháy mắt", "playful expression", eyes = "wink", mouth = "smile", head = "tilt", tagLead = "happy")
    )

    /**
     * Cấu tạo XẤP XỈ của 12 nhãn gốc theo thành phần — CHỈ để "Nhân bản" trong màn hình Biểu cảm (12 nhãn gốc dùng
     * chuỗi viết tay trong LLMParser và không đổi hành vi). Xấp xỉ, không đảm bảo giống từng tag của nhãn gốc.
     */
    val BASE_CLONES: Map<String, ExpressionPreset> = mapOf(
        "neutral" to p("neutral", "Bình thường", "neutral expression", mouth = "closed", intensity = 1),
        "smile" to p("smile", "Mỉm cười", "smiling", mouth = "smile", tagLead = "happy"),
        "sad" to p("sad", "Buồn", "sad expression", brows = "inner_up", eyes = "teary", mouth = "frown", gaze = "down", tagLead = "sad"),
        "angry" to p("angry", "Giận dữ", "angry expression", brows = "v_shape", eyes = "glare", mouth = "clenched", extras = listOf("vein"), tagLead = "angry"),
        "surprised" to p("surprised", "Ngạc nhiên", "surprised expression", brows = "raised", eyes = "wide", mouth = "round", tagLead = "surprised"),
        "scared" to p("scared", "Sợ hãi", "scared expression", brows = "inner_up", eyes = "wide", mouth = "open", extras = listOf("sweatdrop", "pale"), tagLead = "scared"),
        "disgust" to p("disgust", "Ghê tởm", "disgusted expression", brows = "furrowed", eyes = "narrowed", mouth = "grimace", tagLead = "disgust"),
        "contempt" to p("contempt", "Khinh bỉ", "contemptuous expression", brows = "one_raised", eyes = "half_closed", mouth = "smirk", head = "tilt", tagLead = "disdain"),
        "crying" to p("crying", "Khóc", "crying", brows = "inner_up", eyes = "crying_open", mouth = "frown", tagLead = "sad"),
        "smirk" to p("smirk", "Nhếch mép", "smug expression", eyes = "half_closed", mouth = "smirk"),
        "determined" to p("determined", "Quyết tâm", "determined expression", brows = "furrowed", eyes = "narrowed", mouth = "closed", tagLead = "determined"),
        "blush" to p("blush", "Đỏ mặt/ngượng", "embarrassed expression", mouth = "parted", extras = listOf("blush", "embarrassed"), gaze = "away", tagLead = "embarrassed")
    )

    private fun article(word: String) =
        if (word.isNotEmpty() && word[0].lowercaseChar() in "aeiou") "an" else "a"

    private fun naturalJoin(items: List<String>): String = when (items.size) {
        0 -> ""
        1 -> items[0]
        2 -> items[0] + " and " + items[1]
        else -> items.dropLast(1).joinToString(", ") + " and " + items.last()
    }

    /** Mức dùng để chặn các lỗi hay gặp ở checkpoint ảnh thực khi vẽ miệng/mắt (răng méo, da sáp). Thực hành chung, chưa kiểm chứng riêng. */
    const val REALISTIC_FACE_NEGATIVE =
        "deformed teeth, bad teeth, extra teeth, deformed mouth, asymmetrical eyes, cross-eyed, waxy plastic skin"

    /**
     * Ghép prompt từ thành phần + cường độ. [realistic] = true dùng cách diễn đạt GIẢI PHẪU cho checkpoint ảnh thực (mục 242):
     * cộng đồng ảnh thực viết "<cảm xúc> facial expression, <đặc điểm cơ mặt>" (vd "disgusted expression, wrinkled nose and furrowed
     * brows"; "fearful expression, wide eyes and tense muscles" — openart.ai; DiffusionFER dùng "angry emotion with open mouth,
     * frown eyebrow") chứ không dùng tag riêng của anime. Thành phần lạ/không có bị bỏ qua (không throw).
     */
    fun compose(p: ExpressionPreset, style: PromptStyle, realistic: Boolean = false): String {
        val core = listOfNotNull(
            ExpressionVocab.find(ExpressionVocab.BROWS, p.brows),
            ExpressionVocab.find(ExpressionVocab.EYES, p.eyes),
            ExpressionVocab.find(ExpressionVocab.MOUTH, p.mouth)
        )
        val rest = p.extras.orEmpty().mapNotNull { ExpressionVocab.find(ExpressionVocab.EXTRAS, it) } +
            listOfNotNull(ExpressionVocab.find(ExpressionVocab.GAZE, p.gaze), ExpressionVocab.find(ExpressionVocab.HEAD, p.head))
        val level = p.intensity.coerceIn(1, 3)
        val lead = p.lead.trim()
        return if (style == PromptStyle.TAG_BASED) {
            // Ảnh thực: dẫn đầu bằng cụm mô tả đầy đủ; anime: tag danbooru đã xác minh (tagLead).
            val leadText = if (realistic) lead else (p.tagLead?.takeIf { it.isNotBlank() } ?: lead).trim()
            val leadPart = when (level) { 1 -> leadText; 2 -> "($leadText:1.2)"; else -> "($leadText:1.35)" }
            fun txt(x: ExpressionVocab.Part) = if (realistic) x.real else x.tag
            val detail = (core.map { if (level == 3) "(${txt(it)}:1.15)" else txt(it) } + rest.map { txt(it) })
            (listOf(leadPart) + detail).filter { it.isNotBlank() }.joinToString(", ")
        } else {
            val head = when (level) {
                1 -> "a subtle $lead"
                2 -> "${article(lead)} $lead"
                else -> "a strongly pronounced $lead"
            }
            val parts = (core + rest).map { if (realistic) it.real else it.nl }
            if (parts.isEmpty()) head else head + ", with " + naturalJoin(parts)
        }
    }

    /** Cho LLMParser: key -> (tagBased, naturalLanguage) của các biểu cảm mở rộng. */
    fun extendedBuiltIns(): Map<String, Pair<String, String>> =
        EXTENDED_BUILTINS.associate { it.id to (compose(it, PromptStyle.TAG_BASED) to compose(it, PromptStyle.NATURAL_LANGUAGE)) }

    // Nhãn hiển thị cho 12 khoá gốc của LLMParser.
    private val BASE_LABELS = mapOf(
        "neutral" to "Bình thường", "smile" to "Mỉm cười", "sad" to "Buồn", "angry" to "Giận dữ",
        "surprised" to "Ngạc nhiên", "scared" to "Sợ hãi", "disgust" to "Ghê tởm", "contempt" to "Khinh bỉ",
        "crying" to "Khóc", "smirk" to "Nhếch mép", "determined" to "Quyết tâm", "blush" to "Đỏ mặt/ngượng"
    )
    fun baseLabel(key: String): String? = BASE_LABELS[key]
}

/**
 * Biểu cảm TỰ TẠO của người dùng (lưu JSON cạnh pose_library.json) + tra cứu chung cho UI. Singleton vì LLMParser
 * (companion, không có instance) cần tra được; được nạp một lần ở MainViewModel.
 */
object ExpressionRegistry {
    /**
     * mục 242 — true khi phong cách ảnh đang chọn là "Siêu thực" (ImageStyle.REALISTIC). MainViewModel cập nhật mỗi khi đổi cài đặt.
     * Là cờ toàn cục vì LLMParser.resolveExpressionTag() nằm trong companion object (không có instance/settings).
     */
    @Volatile var realisticDomain: Boolean = false

    /**
     * mục 243 — chọn bộ từ vựng. Tra cứu cho thấy việc checkpoint có hiểu tag booru KHÔNG tách đôi "ảnh thực / anime":
     * nhiều checkpoint ảnh thực do cộng đồng tinh chỉnh được gắn nhãn bằng bộ phân loại theo định dạng booru (README TTResume),
     * và model huấn luyện bằng tag vẫn chạy được với câu tự nhiên "ở mức nào đó" (Tech Tactician) — nên AUTO chỉ là phỏng đoán theo
     * phong cách ảnh; người dùng ghi đè được bằng [mode] = "ANATOMICAL" (mô tả giải phẫu) hoặc "BOORU" (tag danbooru).
     */
    fun domainFor(style: ImageStyle, mode: String): Boolean = when (mode) {
        "ANATOMICAL" -> true
        "BOORU" -> false
        else -> style == ImageStyle.REALISTIC
    }
    @Volatile private var custom: List<ExpressionPreset> = emptyList()
    private val gson = Gson()

    fun load(file: File) {
        custom = try {
            if (!file.exists()) emptyList()
            else gson.fromJson(file.readText(), Array<ExpressionPreset>::class.java)
                ?.filter { it.id.startsWith("x:") && it.name.isNotBlank() }?.toList().orEmpty()
        } catch (e: Exception) { emptyList() }
    }

    fun save(file: File) {
        try { file.writeText(gson.toJson(custom)) } catch (e: Exception) { /* không làm hỏng luồng chính */ }
    }

    fun customPresets(): List<ExpressionPreset> = custom

    fun newCustomId(): String = "x:" + UUID.randomUUID().toString().replace("-", "").take(8)

    fun upsert(p: ExpressionPreset) {
        val fixed = p.copy(builtIn = false, intensity = p.intensity.coerceIn(1, 3))
        custom = if (custom.any { it.id == fixed.id }) custom.map { if (it.id == fixed.id) fixed else it } else custom + fixed
    }

    fun delete(id: String) { custom = custom.filterNot { it.id == id } }

    /** LLMParser.resolveExpressionTag() gọi khi khoá không phải built-in. */
    fun resolveCustom(key: String, style: PromptStyle): String? =
        custom.firstOrNull { it.id == key }?.let { ExpressionLibrary.compose(it, style, realisticDomain) }

    /** Preset (mở rộng hoặc tự tạo) theo khoá; 12 nhãn gốc không có preset thành phần -> null. */
    fun presetOf(key: String): ExpressionPreset? =
        custom.firstOrNull { it.id == key } ?: ExpressionLibrary.EXTENDED_BUILTINS.firstOrNull { it.id == key }

    /** Toàn bộ khoá chọn được: built-in (12 gốc + mở rộng) rồi tự tạo. */
    fun selectableKeys(): List<String> = LLMParser.VALID_EXPRESSIONS.toList() + custom.map { it.id }

    fun labelOf(key: String): String =
        ExpressionLibrary.baseLabel(key) ?: presetOf(key)?.name ?: key

    /** Cường độ dùng để chỉnh denoise của lượt vẽ lại mặt: 12 nhãn gốc coi như vừa (2). */
    fun intensityOf(key: String): Int = presetOf(key)?.intensity ?: 2

    /** Lỗi tham chiếu thành phần của 1 preset (dùng cho UI/kiểm tra); rỗng = hợp lệ. */
    fun validate(p: ExpressionPreset): List<String> {
        val errs = ArrayList<String>()
        if (p.lead.isBlank()) errs += "thiếu cụm mô tả chính"
        if (p.brows != null && ExpressionVocab.find(ExpressionVocab.BROWS, p.brows) == null) errs += "lông mày: ${p.brows}"
        if (p.eyes != null && ExpressionVocab.find(ExpressionVocab.EYES, p.eyes) == null) errs += "mắt: ${p.eyes}"
        if (p.mouth != null && ExpressionVocab.find(ExpressionVocab.MOUTH, p.mouth) == null) errs += "miệng: ${p.mouth}"
        p.extras.orEmpty().forEach { if (ExpressionVocab.find(ExpressionVocab.EXTRAS, it) == null) errs += "phụ: $it" }
        if (p.gaze != null && ExpressionVocab.find(ExpressionVocab.GAZE, p.gaze) == null) errs += "hướng nhìn: ${p.gaze}"
        if (p.head != null && ExpressionVocab.find(ExpressionVocab.HEAD, p.head) == null) errs += "đầu: ${p.head}"
        return errs
    }
}
