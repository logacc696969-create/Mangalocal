package com.mangalocal.pipeline

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min

/**
 * mục 237 TECHNICAL_STATUS.md — "Only masked" (cắt-vẽ-dán) và DÁN LẠI PIXEL GỐC cho các lượt vẽ lại
 * vùng chạm trong tryAutoFixInteractions().
 *
 * HAI VẤN ĐỀ CHẤT LƯỢNG THẬT tìm thấy khi đọc code (trước mục này):
 * 1. Mỗi vùng chạm (vd 120x120px) được img2img/inpaint ở độ phân giải của CẢ PANEL (512²), tức vùng đó chỉ
 *    chiếm ~6% diện tích model nhìn thấy -> bàn tay/khuỷu/gối ra mềm, thiếu chi tiết, dễ méo. Cộng đồng gọi
 *    đúng cách khắc phục này là "inpaint only masked" (A1111) / `padding_mask_crop` (diffusers): cắt vùng mask
 *    + lề, phóng lên độ phân giải gốc của model, vẽ, thu nhỏ rồi dán lại. Nguồn: tài liệu diffusers
 *    StableDiffusionInpaintPipeline (tham số padding_mask_crop) và bài PromptZone "Stable Diffusion Inpainting:
 *    Masks, Denoise, and Seams" ("Whole picture generates at the image's resolution, so a small mask gets a
 *    small share of the model's attention and comes back soft").
 * 2. Mỗi lượt inpaint đưa CẢ ẢNH qua một vòng encode-decode VAE nên pixel NGOÀI mask cũng đổi nhẹ; với tối đa
 *    nhiều vùng tuần tự, sai lệch cộng dồn (cùng nguồn PromptZone: "everything makes a VAE round-trip, so even
 *    untouched pixels come back slightly different... after several successive inpaint passes"). Cách chuẩn
 *    là dán kết quả lên ảnh gốc theo mask trong không gian pixel.
 *
 * File này gồm: (a) hình học `planCrop` THUẦN (kiểm bằng mô phỏng Python tools/test_inpaint_crop.py),
 * (b) `blendInto` trộn theo mask trên bitmap.
 *
 * GIỚI HẠN THẬT:
 * - Vùng crop luôn VUÔNG; model nhận ảnh vuông `nativeSide`. Panel không vuông vẫn dùng được (crop vẫn vuông).
 * - Phóng crop lên rồi thu nhỏ dùng nội suy song tuyến tính của Android (không phải Lanczos).
 * - Vẽ ở độ phân giải cao hơn KHÔNG tự đảm bảo giải phẫu đúng: nó cho model đủ điểm ảnh để vẽ chi tiết,
 *   còn việc vùng chạm đúng hay sai vẫn do prompt/ControlNet/ngưỡng dò quyết định.
 * - Crop chỉ thấy một phần cảnh nên model mất ngữ cảnh toàn cục (ánh sáng, người ở xa); lề rộng hơn bù một phần.
 * - CHƯA build-test, chưa có ảnh thật nào so sánh trước/sau.
 */
object InpaintCompose {

    /**
     * Trả vùng crop VUÔNG (toạ độ trong không gian ảnh [imgW]x[imgH]) chứa trọn [rect], hoặc null nếu không
     * đáng crop (hệ số phóng < [minGain]) hoặc không thể chứa trọn vùng.
     *
     * @param target    cạnh vuông model vẽ (nativeSide)
     * @param padFactor cạnh crop = max(rộng, cao của rect) * padFactor (lề ~ 30% mỗi phía khi 1.6)
     * @param minSide   cạnh crop tối thiểu (tránh crop quá nhỏ mất ngữ cảnh)
     * @param minGain   chỉ crop khi target/side >= minGain
     */
    fun planCrop(
        rect: Rect, imgW: Int, imgH: Int, target: Int,
        padFactor: Float = 1.6f, minSide: Int = 192, minGain: Float = 1.35f
    ): Rect? {
        if (imgW <= 0 || imgH <= 0 || target <= 0 || rect.width() <= 0 || rect.height() <= 0) return null
        val maxSide = min(imgW, imgH)
        var side = (max(rect.width(), rect.height()) * padFactor).toInt()
        side = max(side, minSide)
        side = min(side, maxSide)
        if (target.toFloat() / side < minGain) return null
        val cx = (rect.left + rect.right) / 2
        val cy = (rect.top + rect.bottom) / 2
        val left = (cx - side / 2).coerceIn(0, imgW - side)
        val top = (cy - side / 2).coerceIn(0, imgH - side)
        if (rect.left < left || rect.right > left + side || rect.top < top || rect.bottom > top + side) return null
        return Rect(left, top, left + side, top + side)
    }

    /**
     * Trộn [patch] vào [base] (PHẢI mutable, ARGB_8888) tại ([left],[top]) theo [mask]: pixel = base*(1-m) +
     * patch*m, m = kênh đỏ của mask / 255 (mask trắng = vẽ lại, đúng quy ước các mask trong dự án, 3 kênh bằng nhau).
     * [patch] và [mask] PHẢI cùng kích thước; phần vượt ra ngoài [base] bị bỏ qua.
     */
    fun blendInto(base: Bitmap, patch: Bitmap, mask: Bitmap, left: Int, top: Int) {
        val w = min(patch.width, mask.width)
        val h = min(patch.height, mask.height)
        val bw = min(w, base.width - left)
        val bh = min(h, base.height - top)
        if (bw <= 0 || bh <= 0 || left < 0 || top < 0) return
        val pp = IntArray(bw * bh); val mp = IntArray(bw * bh); val bp = IntArray(bw * bh)
        patch.getPixels(pp, 0, bw, 0, 0, bw, bh)
        mask.getPixels(mp, 0, bw, 0, 0, bw, bh)
        base.getPixels(bp, 0, bw, left, top, bw, bh)
        for (i in 0 until bw * bh) {
            val m = ((mp[i] shr 16) and 0xFF)
            if (m == 0) continue
            val b = bp[i]; val p = pp[i]
            val inv = 255 - m
            val r = (((b shr 16) and 0xFF) * inv + ((p shr 16) and 0xFF) * m) / 255
            val g = (((b shr 8) and 0xFF) * inv + ((p shr 8) and 0xFF) * m) / 255
            val bl = ((b and 0xFF) * inv + (p and 0xFF) * m) / 255
            bp[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
        }
        base.setPixels(bp, 0, bw, left, top, bw, bh)
    }

    /**
     * Trả BẢN SAO của [patch] với màu khớp ảnh gốc [base] trong vùng mask (mask R >= 128): chuẩn hoá trung bình và độ
     * lệch chuẩn từng kênh RGB của patch về của base (hệ số độ lệch kẹp 0.8..1.25 để không bóp/giãn tương phản quá
     * mức), rồi trộn theo [strength] (0 = giữ patch, 1 = khớp hoàn toàn). Ít hơn 64 điểm trong mask -> trả patch gốc.
     * Cùng ý với tuỳ chọn "color correction" của img2img (A1111); đây là Reinhard trên RGB, KHÔNG phải trên LAB.
     * GIỚI HẠN THẬT: khớp theo trung bình làm mất màu CHỦ Ý (đỏ mặt, tái mặt) — caller hạ [strength] khi biểu cảm có màu chủ ý.
     */
    fun matchColors(base: Bitmap, patch: Bitmap, mask: Bitmap, left: Int, top: Int, strength: Float): Bitmap {
        val w = min(patch.width, mask.width); val h = min(patch.height, mask.height)
        val bw = min(w, base.width - left); val bh = min(h, base.height - top)
        if (bw <= 0 || bh <= 0 || left < 0 || top < 0 || strength <= 0f) return patch
        val pp = IntArray(bw * bh); val mp = IntArray(bw * bh); val bp = IntArray(bw * bh)
        patch.getPixels(pp, 0, bw, 0, 0, bw, bh)
        mask.getPixels(mp, 0, bw, 0, 0, bw, bh)
        base.getPixels(bp, 0, bw, left, top, bw, bh)
        val n = IntArray(1); val sumB = DoubleArray(3); val sumP = DoubleArray(3); val sqB = DoubleArray(3); val sqP = DoubleArray(3)
        for (i in 0 until bw * bh) {
            if (((mp[i] shr 16) and 0xFF) < 128) continue
            n[0]++
            for (c in 0 until 3) {
                val sh = 16 - 8 * c
                val b = ((bp[i] shr sh) and 0xFF).toDouble(); val p = ((pp[i] shr sh) and 0xFF).toDouble()
                sumB[c] += b; sumP[c] += p; sqB[c] += b * b; sqP[c] += p * p
            }
        }
        if (n[0] < 64) return patch
        val cnt = n[0].toDouble()
        val muB = DoubleArray(3) { sumB[it] / cnt }; val muP = DoubleArray(3) { sumP[it] / cnt }
        val sdB = DoubleArray(3) { kotlin.math.sqrt(max(0.0, sqB[it] / cnt - muB[it] * muB[it])) }
        val sdP = DoubleArray(3) { kotlin.math.sqrt(max(0.0, sqP[it] / cnt - muP[it] * muP[it])) }
        val scale = DoubleArray(3) { if (sdP[it] < 1e-3) 1.0 else (sdB[it] / sdP[it]).coerceIn(0.8, 1.25) }
        val out = IntArray(bw * bh)
        val st = strength.coerceIn(0f, 1f).toDouble()
        for (i in 0 until bw * bh) {
            var px = 0xFF shl 24
            for (c in 0 until 3) {
                val sh = 16 - 8 * c
                val p = ((pp[i] shr sh) and 0xFF).toDouble()
                val q = ((p - muP[c]) * scale[c] + muB[c]).coerceIn(0.0, 255.0)
                px = px or ((p * (1.0 - st) + q * st).toInt().coerceIn(0, 255) shl sh)
            }
            out[i] = px
        }
        val result = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        result.setPixels(out, 0, bw, 0, 0, bw, bh)
        return result
    }

    /** Chuyển khung xương (x,y,z,visible) từ không gian ảnh [w]x[h] sang không gian crop vuông [side] tại ([left],[top]). */
    fun remapSkeleton(sk: FloatArray, w: Int, h: Int, left: Int, top: Int, side: Int): FloatArray {
        if (sk.isEmpty() || side <= 0) return sk
        val out = sk.copyOf()
        var i = 0
        while (i + 3 < out.size) {
            out[i] = (sk[i] * w - left) / side
            out[i + 1] = (sk[i + 1] * h - top) / side
            i += 4
        }
        return out
    }
}
