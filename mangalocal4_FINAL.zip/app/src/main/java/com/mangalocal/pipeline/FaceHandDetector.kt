package com.mangalocal.pipeline

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Dò vùng mặt + tay để auto-inpaint (ADetailer-style, mục 16/17
 * TECHNICAL_STATUS.md).
 *
 * ĐÃ ĐỔI (mục 19/20 TECHNICAL_STATUS.md — "dùng YOLO xuyên suốt, giảm công
 * code kỹ thuật autodetect khác"): TRƯỚC dùng MediaPipe Face Detector +
 * Hand Landmarker (2 model riêng). GIỜ tái dùng NGAY khung xương
 * YOLOv8-pose (PoseExtractor, mục 19) đã detect sẵn — vùng mặt suy ra từ
 * mũi/mắt/tai, vùng tay suy ra từ khớp cổ tay + khuỷu tay (đo độ dài cẳng
 * tay để ước lượng kích thước bàn tay). KHÔNG CẦN THÊM MODEL YOLO NÀO
 * KHÁC — dùng lại đúng 1 lần detect YOLOv8-pose đã chạy, giảm hẳn 1 lượt
 * inference riêng cho face/hand so với trước (vừa nhanh hơn, vừa đỡ code).
 *
 * ĐÁNH ĐỔI CẦN BIẾT (thành thật, không giấu): model face/hand CHUYÊN BIỆT
 * (MediaPipe BlazeFace, hoặc YOLO-face/YOLO-hand cộng đồng train riêng) cho
 * box CHÍNH XÁC hơn — họ được train ĐỂ tìm đúng ranh giới mặt/tay thật. Suy
 * từ keypoint pose chỉ là ƯỚC LƯỢNG hình học (box vuông quanh 1 điểm, kích
 * thước theo tỷ lệ cơ thể) — có thể lệch tâm hoặc sai kích thước với tư thế
 * lạ (tay giơ cao, nghiêng mạnh...). Đánh đổi được chấp nhận vì: (1) mask
 * inpaint vốn đã có padding rộng, lệch nhẹ vẫn che được vùng lỗi; (2) tái
 * dùng detect đã chạy sẵn cho pose, không tốn thêm resource/model riêng —
 * đúng tiêu chí "hiệu suất cao, dùng nhiều nơi, không code lại" đã thống
 * nhất từ mục 17. CHƯA build-test để biết độ lệch thực tế bao nhiêu.
 */
class FaceHandDetector(private val poseExtractor: PoseExtractor) {

    fun isReady() = poseExtractor.isReady()

    // Padding thêm quanh box ước lượng — rộng hơn hẳn bản MediaPipe cũ
    // (25%) vì đây là suy luận hình học thô, cần biên độ rộng hơn để không
    // cắt hụt vùng lỗi thật.
    private val facePaddingRatio = 0.6f
    private val handPaddingRatio = 0.5f

    fun detectRegions(bitmap: Bitmap): List<Rect> {
        if (!isReady()) return emptyList()
        val w = bitmap.width; val h = bitmap.height
        val people = poseExtractor.extractFromImage(bitmap) ?: return emptyList()
        val regions = mutableListOf<Rect>()

        people.forEach { person ->
            // Vùng mặt: bounding box quanh mũi(0)/mắt(14,15)/tai(16,17) —
            // bán kính tham chiếu = khoảng cách vai (2-5), tỷ lệ kinh
            // nghiệm ~0.5x bề rộng vai cho 1 khuôn mặt người thường.
            val faceIdx = listOf(0, 14, 15, 16, 17)
            val faceVisible = faceIdx.mapNotNull { person.getOrNull(it) }.filter { it.visible }
            val rightSh = person.getOrNull(2); val leftSh = person.getOrNull(5)
            if (faceVisible.isNotEmpty() && rightSh?.visible == true && leftSh?.visible == true) {
                val cx = faceVisible.map { it.x }.average().toFloat()
                val cy = faceVisible.map { it.y }.average().toFloat()
                val shoulderWidth = sqrt((rightSh.x-leftSh.x)*(rightSh.x-leftSh.x) + (rightSh.y-leftSh.y)*(rightSh.y-leftSh.y))
                val faceRadius = shoulderWidth * 0.55f * (1 + facePaddingRatio)
                regions += normalizedBoxToRect(cx - faceRadius, cy - faceRadius, cx + faceRadius, cy + faceRadius, w, h)
            }

            // Vùng tay: quanh cổ tay (4=right_wrist, 7=left_wrist), kích
            // thước = độ dài cẳng tay (khuỷu(3/6)->cổ tay(4/7)) * hệ số —
            // bàn tay thường ~0.5-0.6x độ dài cẳng tay.
            listOf(Pair(3, 4), Pair(6, 7)).forEach { (elbowIdx, wristIdx) ->
                val elbow = person.getOrNull(elbowIdx); val wrist = person.getOrNull(wristIdx)
                if (elbow?.visible == true && wrist?.visible == true) {
                    val forearmLen = sqrt((elbow.x-wrist.x)*(elbow.x-wrist.x) + (elbow.y-wrist.y)*(elbow.y-wrist.y))
                    val handRadius = forearmLen * 0.55f * (1 + handPaddingRatio)
                    regions += normalizedBoxToRect(
                        wrist.x - handRadius, wrist.y - handRadius,
                        wrist.x + handRadius, wrist.y + handRadius, w, h
                    )
                }
            }
        }
        return regions
    }

    private fun normalizedBoxToRect(nx1: Float, ny1: Float, nx2: Float, ny2: Float, w: Int, h: Int): Rect {
        return Rect(
            (nx1 * w).toInt().coerceIn(0, w), (ny1 * h).toInt().coerceIn(0, h),
            (nx2 * w).toInt().coerceIn(0, w), (ny2 * h).toInt().coerceIn(0, h)
        )
    }

    // mục 79/80 TECHNICAL_STATUS.md — Hand-Over-Body Fixer (2D check), đề
    // xuất từ `bổ_sung_sd1_5.txt`: phát hiện cổ tay của người NÀY nằm ĐÈ
    // LÊN vùng thân người KHÁC (khác với `tryAutoFixInteractions()` mục 74
    // chỉ xét GIAO của bounding-box Hip-Knee — bỏ sót trường hợp 1 tay vươn
    // tới ngực/vai người kia mà hông KHÔNG chồng lấn, ví dụ động tác vỗ vai,
    // đặt tay lên ngực trong tư thế ôm nghiêng).
    //
    // NHẬN THAM SỐ [skeletonData]/[numExpectedPersons] — CÙNG FORMAT ĐÚNG
    // với `QualityGateChecker.evaluate()` (FloatArray phẳng, 18 khớp × 4
    // giá trị/người, normalized 0..1) — KHÔNG nhận Bitmap, KHÔNG tự gọi
    // `poseExtractor.extractFromImage()` lần nữa. Lý do: skeleton data đã
    // được tính 1 LẦN DUY NHẤT cho panel này (trong `runGeneration()`) và
    // truyền xuyên suốt mọi bước hậu kỳ (Quality Gate mục 74, Interaction
    // Fix mục 74) — thêm 1 hàm re-infer ở đây sẽ VI PHẠM nguyên tắc "không
    // chạy inference lần 2" mà chính dự án đã đặt ra và tuân thủ nghiêm
    // ngặt từ mục 20 trở đi. Bản đầu tiên của hàm này (đã sửa) từng nhận
    // Bitmap và tự gọi lại poseExtractor — đó là lỗi thiết kế, đã sửa ngay
    // trong cùng lượt trước khi đưa vào code chính.
    //
    // Trả về list Rect quanh ĐIỂM CỔ TAY đang đè lên thân người khác (đã
    // padding), để MangaPipeline hợp nhất (union) với mask giao thoa Hip-
    // Knee đã có, mở rộng vùng inpaint đúng nơi thật sự cần — KHÔNG thay
    // thế `tryAutoFixInteractions()`, chỉ BỔ SUNG thêm case nó bỏ sót.
    //
    // GIỚI HẠN THẬT: kế thừa nguyên hạn chế suy luận hình học thô của toàn
    // bộ FaceHandDetector (xem docstring đầu file) — không phân biệt được
    // occlusion thật với ảo giác keypoint.
    // mục 94 TECHNICAL_STATUS.md — đổi trả về từ List<Rect> sang
    // List<HandOverBodyContact> (thêm handPersonIdx/bodyPersonIdx) để nơi
    // gọi biết ĐÚNG nhân vật nào bị chạm (cần cho việc mô tả đúng trang
    // phục của NGƯỜI BỊ CHẠM khi build prompt rách vải — mục 94), không
    // chỉ biết "có 1 vùng chạm ở đâu đó" như trước.
    data class HandOverBodyContact(val rect: Rect, val handPersonIdx: Int, val bodyPersonIdx: Int)

    fun detectHandOverBodyOverlaps(skeletonData: FloatArray, numExpectedPersons: Int, imageW: Int, imageH: Int): List<HandOverBodyContact> {
        if (numExpectedPersons < 2 || skeletonData.isEmpty()) return emptyList()
        val floatsPerPerson = 18 * 4
        val numPersons = minOf(numExpectedPersons, skeletonData.size / floatsPerPerson)
        if (numPersons < 2) return emptyList()

        data class Joint(val x: Float, val y: Float, val conf: Float) { val visible get() = conf > 0.3f }
        fun jointAt(personIdx: Int, jointIdx: Int): Joint {
            val base = personIdx * floatsPerPerson + jointIdx * 4
            return Joint(skeletonData[base], skeletonData[base + 1], skeletonData[base + 2])
        }

        data class TorsoBox(val personIdx: Int, val l: Float, val t: Float, val r: Float, val b: Float)
        val torsos = (0 until numPersons).mapNotNull { idx ->
            val rSh = jointAt(idx, 2); val lSh = jointAt(idx, 5)
            val rHip = jointAt(idx, 8); val lHip = jointAt(idx, 11)
            if (!rSh.visible || !lSh.visible || !rHip.visible || !lHip.visible) return@mapNotNull null
            val xs = listOf(rSh.x, lSh.x, rHip.x, lHip.x); val ys = listOf(rSh.y, lSh.y, rHip.y, lHip.y)
            val pad = 0.15f
            val bw = (xs.max() - xs.min()) * pad; val bh = (ys.max() - ys.min()) * pad
            TorsoBox(idx, xs.min() - bw, ys.min() - bh, xs.max() + bw, ys.max() + bh)
        }
        if (torsos.size < 2) return emptyList()

        val overlaps = mutableListOf<HandOverBodyContact>()
        for (personIdx in 0 until numPersons) {
            listOf(4, 7).forEach { wristIdx -> // right_wrist=4, left_wrist=7
                val wrist = jointAt(personIdx, wristIdx)
                if (!wrist.visible) return@forEach
                torsos.filter { it.personIdx != personIdx }.forEach { torso ->
                    if (wrist.x in torso.l..torso.r && wrist.y in torso.t..torso.b) {
                        val radius = 0.06f
                        overlaps += HandOverBodyContact(
                            normalizedBoxToRect(wrist.x - radius, wrist.y - radius, wrist.x + radius, wrist.y + radius, imageW, imageH),
                            handPersonIdx = personIdx, bodyPersonIdx = torso.personIdx
                        )
                    }
                }
            }
        }
        return overlaps
    }

    fun close() { /* dùng chung poseExtractor, KHÔNG tự close() ở đây — MangaPipeline sở hữu vòng đời poseExtractor */ }
}
