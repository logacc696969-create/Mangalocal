package com.mangalocal.pipeline

/**
 * mục 260 TECHNICAL_STATUS.md — KIỂM TRA TÍNH LIÊN TỤC giữa các panel (mở rộng phần "CANVAS" của PDF bổ sung — mục 248/256 ghi MỘT PHẦN).
 *
 * CANVAS (PDF) lập kế hoạch liên tục TƯỜNG MINH cho cảnh nhiều khung: nhân vật liên tục, mỏ neo bối cảnh bền, vật dụng liên tục; báo cải thiện
 * liên tục bối cảnh/nhân vật/vật dụng so với baseline. Dự án đã có phần NEO (Location anchor mục 216-219, anchorVersions mục 161) nhưng chưa có bước
 * nào phát hiện chỗ KHAI BÁO của kịch bản bị đứt quãng. File này là bước kiểm đó — dạng hàm thuần, theo đúng mẫu ScaleConsistencyChecker (mục 235).
 *
 * Ba loại cảnh báo, đều chỉ dựa trên dữ liệu kịch bản (Scene.locationName / characters / objectBoxes), KHÔNG đọc ảnh:
 *   1. LOCATION_DRIFT — panel không khai bối cảnh nhưng nằm giữa hai panel cùng một bối cảnh: dễ bị trôi nền (không có mỏ neo bối cảnh nào áp dụng).
 *   2. CHARACTER_GAP  — nhân vật có ở panel trước và sau (cùng bối cảnh) nhưng vắng đúng ở panel giữa có người: thường là LLM bỏ sót khi tách cảnh.
 *   3. PROP_GAP       — vật thể khai ở panel a và b (cùng bối cảnh) nhưng panel nằm giữa khai các vật khác mà thiếu vật này: vật biến mất rồi hiện lại.
 *
 * GIỚI HẠN THẬT:
 *   - Chỉ CẢNH BÁO (ghi log). KHÔNG tự sửa kịch bản, KHÔNG đổi ảnh: hồi tưởng/cắt cảnh/góc máy chỉ thấy một nhân vật là hợp lệ về nghệ thuật.
 *   - Chỉ kiểm cái ĐÃ KHAI; vật thể/nhân vật chưa từng được khai thì không bao giờ bị cảnh báo. objectBoxes là hộp LLM/người dùng khai.
 *   - Chỉ so các panel có chỉ số LIÊN TIẾP nhau (sinh lại vài panel lẻ thì khoảng trống không bị tính là đứt quãng).
 *   - Chưa hiệu chỉnh mức nhiễu trên truyện thật. CHƯA build-test.
 */
object ContinuityChecker {

    enum class Kind { LOCATION_DRIFT, CHARACTER_GAP, PROP_GAP }

    data class Entry(val panelIndex: Int, val location: String, val characters: Set<String>, val objects: Set<String>)

    data class Warning(val kind: Kind, val panelIndex: Int, val subject: String) {
        val message: String
            get() = when (kind) {
                Kind.LOCATION_DRIFT -> "chưa khai bối cảnh nhưng nằm giữa các panel cùng bối cảnh \"$subject\" — nền dễ bị trôi, nên gán Địa điểm cho panel này"
                Kind.CHARACTER_GAP -> "nhân vật \"$subject\" có ở panel trước và sau (cùng bối cảnh) nhưng vắng ở panel này — kiểm tra có phải bị bỏ sót"
                Kind.PROP_GAP -> "vật thể \"$subject\" có ở panel trước và sau (cùng bối cảnh) nhưng thiếu ở panel này — kiểm tra có phải bị bỏ sót"
            }
    }

    private fun norm(s: String) = s.trim().lowercase()

    /** `entries` theo thứ tự đọc; được tự tách thành các đoạn có chỉ số panel liên tiếp rồi kiểm từng đoạn. */
    fun check(entries: List<Entry>): List<Warning> {
        val sorted = entries.sortedBy { it.panelIndex }.map {
            Entry(it.panelIndex, norm(it.location), it.characters.map { c -> norm(c) }.filter { s -> s.isNotEmpty() }.toSet(),
                it.objects.map { o -> norm(o) }.filter { s -> s.isNotEmpty() }.toSet())
        }
        val out = LinkedHashSet<Warning>()
        var start = 0
        while (start < sorted.size) {
            var end = start + 1
            while (end < sorted.size && sorted[end].panelIndex == sorted[end - 1].panelIndex + 1) end++
            checkRun(sorted.subList(start, end), out)
            start = end
        }
        return out.sortedWith(compareBy<Warning>({ it.panelIndex }, { it.kind.ordinal }, { it.subject }))
    }

    private fun checkRun(run: List<Entry>, out: MutableSet<Warning>) {
        val n = run.size
        // 1. LOCATION_DRIFT: bối cảnh gần nhất ở TRƯỚC và ở SAU đều có và giống nhau.
        for (i in 0 until n) {
            if (run[i].location.isNotEmpty()) continue
            var p = i - 1
            while (p >= 0 && run[p].location.isEmpty()) p--
            var q = i + 1
            while (q < n && run[q].location.isEmpty()) q++
            if (p >= 0 && q < n && run[p].location == run[q].location) out.add(Warning(Kind.LOCATION_DRIFT, run[i].panelIndex, run[p].location))
        }
        // 2. CHARACTER_GAP: ba panel liền nhau cùng bối cảnh (không rỗng); panel giữa CÓ người (không phải cảnh nền trống).
        for (i in 1 until n - 1) {
            val loc = run[i].location
            if (loc.isEmpty() || run[i - 1].location != loc || run[i + 1].location != loc) continue
            if (run[i].characters.isEmpty()) continue
            for (c in run[i - 1].characters.intersect(run[i + 1].characters)) {
                if (c !in run[i].characters) out.add(Warning(Kind.CHARACTER_GAP, run[i].panelIndex, c))
            }
        }
        // 3. PROP_GAP: vật có ở a và b (b - a >= 2), mọi panel a..b cùng bối cảnh; panel giữa khai vật khác mà thiếu vật này.
        for (a in 0 until n) {
            val loc = run[a].location
            if (loc.isEmpty()) continue
            for (label in run[a].objects) {
                var b = a + 1
                while (b < n && run[b].location == loc) {
                    if (label in run[b].objects) {
                        for (k in a + 1 until b) {
                            if (label !in run[k].objects && run[k].objects.isNotEmpty()) out.add(Warning(Kind.PROP_GAP, run[k].panelIndex, label))
                        }
                        break
                    }
                    b++
                }
            }
        }
    }
}
