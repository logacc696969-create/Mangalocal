package com.mangalocal.pipeline

/**
 * mục 266 TECHNICAL_STATUS.md — LÕI THUẦN (không mạng, không Android) cho việc tạo ảnh KHÔNG CÓ NHÂN VẬT / ảnh phác nhân vật bằng API ảnh MIỄN PHÍ:
 * dựng yêu cầu HTTP, giải mã phản hồi, dựng prompt. Phần gọi mạng ở FreeImageClient.kt. Kiểm thử bằng kotlinc (tools/test_free_image_api.py).
 *
 * VÌ SAO CHỈ CHO ẢNH NỀN/ĐỊA ĐIỂM VÀ ẢNH PHÁC NHÂN VẬT: API ảnh miễn phí chỉ là chữ -> ảnh. Sinh panel của app cần ControlNet-pose + IP-Adapter + LoRA từng
 * nhân vật + mask vùng; các model miễn phí đã tra (SDXL, FLUX schnell, SDXL-Lightning...) không có các điều khiển đó, nên KHÔNG dùng cho panel.
 *
 * NHÀ CUNG CẤP (đã tra tài liệu công khai tháng 10/2026; CHƯA gọi thử thật — sandbox không ra Internet, xem GIỚI HẠN):
 *  - Cloudflare Workers AI: POST https://api.cloudflare.com/client/v4/accounts/{account_id}/ai/run/{model}, Authorization: Bearer {token}, thân JSON.
 *    10.000 Neurons miễn phí mỗi ngày; Cloudflare nêu không dùng nội dung của bạn để huấn luyện model. FLUX schnell trả JSON {result:{image:<base64>}} (JPEG);
 *    SDXL/SDXL-Lightning trả thẳng PNG (hoặc JSON). Tên tham số theo tài liệu từng model — SAI tham số sẽ báo 400.
 *  - Pollinations: GET image.pollinations.ai/prompt/{prompt}?width&height&seed&model — không cần khoá, bậc ẩn danh giới hạn 1 yêu cầu/15 giây và CÓ THỂ có watermark;
 *    có khoá (enter.pollinations.ai) thì dùng gen.pollinations.ai/image/{prompt} với `Authorization: Bearer`.
 *    ĐÃ TRA CỨU (mục 268): README chính thức khuyên host hợp nhất và gọi host cũ là "legacy"; tài liệu cũ (APIDOCS.md) ghi anonymous 15 s và seed 5 s; một bài hướng dẫn thử
 *    ngày 2026-05-02 ghi host cũ vẫn chạy ẩn danh và host mới cần khoá; gói PyPI chính thức ghi "mọi yêu cầu sinh ảnh cần khoá". Các nguồn còn lệch nhau về chuyện bậc ẩn danh của
 *    host mới -> mã giữ ẩn danh ở host cũ, có khoá ở host mới. CHƯA gọi thật (sandbox không ra được các tên miền đó) -> vẫn coi là THỬ NGHIỆM.
 *    mục 272 (tra lại 2026-10-31): README nhánh master của pollinations/pollinations mô tả HAI đường — "Classic API" image.pollinations.ai/prompt/... (không đăng ký/khoá, một model ảnh,
 *    "một yêu cầu mỗi IP cùng lúc", ẢNH CÓ LOGO NHỎ, miễn phí "best effort") và "khoá riêng trên enter" (mọi model, không giới hạn theo IP, không logo) qua gen.pollinations.ai/image/{prompt}
 *    với `Authorization: Bearer` hoặc `?key=`; gói PyPI SDK ghi mọi yêu cầu sinh ảnh ở gen.* cần khoá (sk_ máy chủ; pk_ phía client: 1 pollen/IP/giờ). Khớp thiết kế hiện tại (ẩn danh ->
 *    host cũ, có khoá -> host mới + Bearer). `nologo=true` ở host cũ có thể bị bỏ qua (logo vẫn có); `model=flux` ở host cũ có thể bị bỏ qua (chỉ một model). Vẫn CHƯA gọi thật.
 *    Cloudflare (tra cùng ngày): FLUX schnell nhận `prompt` (tối đa 2048 ký tự; mã kẹp 1800), `steps` (mặc định 4, tối đa 8; mã dùng 4), `seed` tuỳ chọn; trả {image:base64}
 *    (REST bọc trong `result`) — khớp mã. Mã lỗi: 3036 hết hạn mức ngày, 3007 timeout (408), 3006 quá lớn (413).
 *  Không đưa vào: Gemini (model ảnh KHÔNG miễn phí), Hugging Face (credit miễn phí 0,10 USD/tháng — chỉ vài ảnh).
 *
 * GIỚI HẠN THẬT: mọi hạn mức/điều khoản đổi nhanh; chưa kiểm chứng tên tham số trên endpoint thật; ảnh gửi qua bên thứ ba (khác tinh thần "offline" của app) — UI phải nói rõ.
 */
enum class FreeImageProvider(val id: String, val label: String) {
    CLOUDFLARE("cloudflare", "Cloudflare Workers AI (miễn phí 10.000 Neurons/ngày)"),
    POLLINATIONS("pollinations", "Pollinations (không cần khoá, thử nghiệm)")
}

/** Thông tin đăng nhập (chỉ ở bộ nhớ, KHÔNG lưu đĩa). Chuỗi rỗng = chưa nhập. */
class FreeImageCreds(
    val cfAccountId: String = "",
    val cfApiToken: String = "",
    val cfModel: String = FreeImageApi.CF_DEFAULT_MODEL,
    val pollinationsKey: String = ""
)

class HttpSpec(val method: String, val url: String, val headers: List<Pair<String, String>>, val jsonBody: String?)

class DecodedImage(val bytes: ByteArray?, val ext: String, val error: String?)

/**
 * Nguồn tạo ảnh KHÔNG CÓ ĐIỀU KHIỂN (ảnh nền địa điểm, ảnh phác nhân vật) — người dùng chọn NGAY TẠI CHỖ TẠO (hộp thoại ở màn Bối cảnh / Nhân vật).
 * CONFIGURED = đúng cấu hình đang bật (SD trên máy hoặc Remote GPU) như trước mục 266, nên chọn mặc định không đổi hành vi cũ.
 */
enum class ImageSource(val label: String) {
    CONFIGURED("Theo cấu hình hiện tại (trên máy này hoặc Remote GPU)"),
    CLOUDFLARE("API miễn phí: Cloudflare Workers AI"),
    POLLINATIONS("API miễn phí: Pollinations (thử nghiệm)");

    fun freeProvider(): FreeImageProvider? = when (this) {
        CONFIGURED -> null
        CLOUDFLARE -> FreeImageProvider.CLOUDFLARE
        POLLINATIONS -> FreeImageProvider.POLLINATIONS
    }
}

object FreeImageApi {
    const val CF_DEFAULT_MODEL = "@cf/black-forest-labs/flux-1-schnell"
    val CF_KNOWN_MODELS = listOf(
        CF_DEFAULT_MODEL,
        "@cf/bytedance/stable-diffusion-xl-lightning",
        "@cf/stabilityai/stable-diffusion-xl-base-1.0"
    )
    const val MAX_PROMPT_CHARS = 1800
    const val POLLINATIONS_MAX_PROMPT_CHARS = 600

    private val ACCOUNT_RE = Regex("^[A-Za-z0-9]{8,64}$")
    private val MODEL_RE = Regex("^@(cf|hf)/[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$")

    /** Lý do KHÔNG dùng được (rỗng = dùng được). Hiển thị cho người dùng trước khi gọi. */
    fun problems(provider: FreeImageProvider, c: FreeImageCreds): List<String> {
        val out = ArrayList<String>()
        if (provider == FreeImageProvider.CLOUDFLARE) {
            if (c.cfAccountId.isBlank()) out.add("Chưa nhập Account ID Cloudflare")
            else if (!ACCOUNT_RE.matches(c.cfAccountId.trim())) out.add("Account ID Cloudflare không hợp lệ (chỉ chữ và số, 8–64 ký tự)")
            if (c.cfApiToken.isBlank()) out.add("Chưa nhập API Token Cloudflare")
            if (!MODEL_RE.matches(c.cfModel.trim())) out.add("Tên model Cloudflare không hợp lệ (dạng @cf/hãng/tên-model)")
        }
        return out
    }

    fun isConfigured(provider: FreeImageProvider, c: FreeImageCreds): Boolean = problems(provider, c).isEmpty()

    /** Cắt prompt tới [max] ký tự, ưu tiên cắt ở ranh giới từ/dấu phẩy gần cuối để không đứt giữa chữ. */
    fun clampPrompt(p: String, max: Int): String {
        val t = p.replace(Regex("\\s+"), " ").trim()
        if (t.length <= max) return t
        val cut = t.substring(0, max)
        val boundary = maxOf(cut.lastIndexOf(' '), cut.lastIndexOf(','))
        return (if (boundary > max * 2 / 3) cut.substring(0, boundary) else cut).trimEnd(',', ' ')
    }

    private fun clampSize(v: Int): Int = (v.coerceIn(256, 2048) / 8) * 8

    /** Mã hoá phần trăm kiểu URL cho đoạn đường dẫn/tham số (UTF-8, giữ A-Za-z0-9-_.~). */
    fun urlEncode(s: String): String {
        val sb = StringBuilder()
        for (b in s.toByteArray(Charsets.UTF_8)) {
            val c = b.toInt() and 0xFF
            val ch = c.toChar()
            if ((ch in 'A'..'Z') || (ch in 'a'..'z') || (ch in '0'..'9') || ch == '-' || ch == '_' || ch == '.' || ch == '~') sb.append(ch)
            else { sb.append('%'); sb.append("0123456789ABCDEF"[c shr 4]); sb.append("0123456789ABCDEF"[c and 15]) }
        }
        return sb.toString()
    }

    /**
     * Dựng yêu cầu. Ném IllegalArgumentException nếu thông tin chưa đủ (gọi [problems] trước để báo thân thiện).
     * Tham số theo từng họ model Cloudflare: FLUX schnell chỉ nhận prompt + steps (không kích thước/âm bản); SDXL/Lightning nhận thêm
     * negative_prompt/width/height/num_steps/guidance/seed; model lạ chỉ gửi prompt.
     */
    fun buildRequest(provider: FreeImageProvider, prompt: String, negative: String, width: Int, height: Int, seed: Long, c: FreeImageCreds): HttpSpec {
        val w = clampSize(width); val h = clampSize(height)
        when (provider) {
            FreeImageProvider.CLOUDFLARE -> {
                val pr = problems(provider, c)
                require(pr.isEmpty()) { pr.joinToString("; ") }
                val model = c.cfModel.trim()
                val url = "https://api.cloudflare.com/client/v4/accounts/${c.cfAccountId.trim()}/ai/run/$model"
                val p = clampPrompt(prompt, MAX_PROMPT_CHARS)
                val neg = clampPrompt(negative, MAX_PROMPT_CHARS)
                val body = when {
                    model.contains("flux-1-schnell") -> "{\"prompt\":" + MiniJson.quote(p) + ",\"steps\":4}"
                    model.contains("lightning") ->
                        "{\"prompt\":" + MiniJson.quote(p) + (if (neg.isNotEmpty()) ",\"negative_prompt\":" + MiniJson.quote(neg) else "") +
                            ",\"width\":$w,\"height\":$h,\"num_steps\":4,\"guidance\":2,\"seed\":${seedInt(seed)}}"
                    model.contains("stable-diffusion-xl") ->
                        "{\"prompt\":" + MiniJson.quote(p) + (if (neg.isNotEmpty()) ",\"negative_prompt\":" + MiniJson.quote(neg) else "") +
                            ",\"width\":$w,\"height\":$h,\"num_steps\":20,\"guidance\":7.5,\"seed\":${seedInt(seed)}}"
                    else -> "{\"prompt\":" + MiniJson.quote(p) + "}"
                }
                return HttpSpec("POST", url,
                    listOf("Authorization" to "Bearer ${c.cfApiToken.trim()}", "Content-Type" to "application/json", "Accept" to "application/json, image/png, image/jpeg"),
                    body)
            }
            FreeImageProvider.POLLINATIONS -> {
                val p = clampPrompt(prompt, POLLINATIONS_MAX_PROMPT_CHARS)
                require(p.isNotEmpty()) { "Prompt rỗng" }
                val key = c.pollinationsKey.trim()
                val q = "model=flux&width=$w&height=$h&seed=${seedInt(seed)}&nologo=true"
                val accept = "image/jpeg, image/png, image/*"
                // mục 268: KHÔNG đưa khoá vào URL (URL đi qua proxy/nhật ký/thông báo lỗi). Tài liệu chính thức của gen.pollinations.ai cho phép cả `?key=` lẫn
                // `Authorization: Bearer` -> dùng Bearer. Không khoá -> host cũ ẩn danh; có khoá -> host hợp nhất.
                return if (key.isEmpty()) HttpSpec("GET", "https://image.pollinations.ai/prompt/${urlEncode(p)}?$q", listOf("Accept" to accept), null)
                       else HttpSpec("GET", "https://gen.pollinations.ai/image/${urlEncode(p)}?$q", listOf("Authorization" to "Bearer $key", "Accept" to accept), null)
            }
        }
    }

    /** Seed hợp lệ cho tham số số nguyên 32-bit không âm của API (giữ tính tất định theo seed gốc). */
    fun seedInt(seed: Long): Int = (seed and 0x7FFFFFFFL).toInt()

    /**
     * Khoảng nghỉ TỐI THIỂU giữa hai lần gọi liên tiếp (mili-giây) để không bị giới hạn tần suất: Pollinations bậc ẩn danh (không khoá) bị giới hạn
     * ~1 yêu cầu/15 giây theo một nguồn đã tra — gọi 4 lần liền sẽ dính 429; Cloudflare tính theo hạn mức ngày nên không cần nghỉ.
     */
    fun minIntervalMs(provider: FreeImageProvider, c: FreeImageCreds): Long =
        if (provider == FreeImageProvider.POLLINATIONS && c.pollinationsKey.isBlank()) 15_000L else 0L

    private const val B64_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    /** base64 chuẩn có đệm '=', không xuống dòng (dùng khi gửi ảnh cho LLM nhìn ảnh; không phụ thuộc android.util.Base64 để kiểm thử được). */
    fun base64Encode(b: ByteArray): String {
        val sb = StringBuilder(((b.size + 2) / 3) * 4)
        var i = 0
        while (i + 2 < b.size) {
            val n = ((b[i].toInt() and 0xFF) shl 16) or ((b[i + 1].toInt() and 0xFF) shl 8) or (b[i + 2].toInt() and 0xFF)
            sb.append(B64_ALPHABET[(n shr 18) and 63]).append(B64_ALPHABET[(n shr 12) and 63]).append(B64_ALPHABET[(n shr 6) and 63]).append(B64_ALPHABET[n and 63])
            i += 3
        }
        val rem = b.size - i
        if (rem == 1) {
            val n = (b[i].toInt() and 0xFF) shl 16
            sb.append(B64_ALPHABET[(n shr 18) and 63]).append(B64_ALPHABET[(n shr 12) and 63]).append("==")
        } else if (rem == 2) {
            val n = ((b[i].toInt() and 0xFF) shl 16) or ((b[i + 1].toInt() and 0xFF) shl 8)
            sb.append(B64_ALPHABET[(n shr 18) and 63]).append(B64_ALPHABET[(n shr 12) and 63]).append(B64_ALPHABET[(n shr 6) and 63]).append('=')
        }
        return sb.toString()
    }

    // ---------------- giải mã phản hồi ----------------

    /** Đuôi file theo MAGIC BYTES (không tin Content-Type): "png" / "jpg" / "webp"; null nếu không phải ảnh nhận ra. */
    fun imageExt(b: ByteArray): String? {
        if (b.size >= 8 && b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte() && b[2] == 'N'.code.toByte() && b[3] == 'G'.code.toByte()) return "png"
        if (b.size >= 3 && b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte() && b[2] == 0xFF.toByte()) return "jpg"
        if (b.size >= 12 && b[0] == 'R'.code.toByte() && b[1] == 'I'.code.toByte() && b[2] == 'F'.code.toByte() && b[3] == 'F'.code.toByte() &&
            b[8] == 'W'.code.toByte() && b[9] == 'E'.code.toByte() && b[10] == 'B'.code.toByte() && b[11] == 'P'.code.toByte()) return "webp"
        return null
    }

    /** Giải mã base64 (chuẩn hoặc URL-safe, bỏ khoảng trắng/xuống dòng/tiền tố data:...;base64,). Ném IllegalArgumentException nếu ký tự lạ. */
    fun base64Decode(input: String): ByteArray {
        var s = input
        val comma = s.indexOf("base64,")
        if (s.startsWith("data:") && comma >= 0) s = s.substring(comma + 7)
        val vals = IntArray(256) { -1 }
        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        for (i in alphabet.indices) vals[alphabet[i].code] = i
        vals['-'.code] = 62; vals['_'.code] = 63
        val out = java.io.ByteArrayOutputStream((s.length * 3) / 4 + 3)
        var acc = 0; var bits = 0
        for (ch in s) {
            if (ch == '=' || ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t') continue
            val v = if (ch.code < 256) vals[ch.code] else -1
            require(v >= 0) { "base64 có ký tự không hợp lệ" }
            acc = (acc shl 6) or v; bits += 6
            if (bits >= 8) { bits -= 8; out.write((acc shr bits) and 0xFF) }
        }
        return out.toByteArray()
    }

    /**
     * Giải mã phản hồi thành công HOẶC lỗi nằm trong thân 200. Thứ tự: (1) magic bytes là ảnh -> dùng thẳng; (2) thân là JSON -> tìm ảnh base64 ở
     * result.image / image / result.image_b64 / data[0].b64_json, hoặc đọc errors[0] / error.message; (3) còn lại -> lỗi kèm vài ký tự đầu để chẩn đoán.
     */
    fun decode(contentType: String?, body: ByteArray): DecodedImage {
        val ext = imageExt(body)
        if (ext != null) return DecodedImage(body, ext, null)
        val head = String(body, 0, minOf(body.size, 4096), Charsets.UTF_8).trimStart()
        if (head.startsWith("{") || head.startsWith("[")) {
            try {
                val root = MiniJson.parse(String(body, Charsets.UTF_8))
                val b64 = listOf(
                    MiniJson.path(root, "result", "image"), MiniJson.path(root, "image"),
                    MiniJson.path(root, "result", "image_b64"), MiniJson.path(root, "data", 0, "b64_json")
                ).firstOrNull { it is String && it.isNotBlank() } as? String
                if (b64 != null) {
                    val raw = base64Decode(b64)
                    val e2 = imageExt(raw) ?: return DecodedImage(null, "", "Chuỗi base64 giải mã ra không phải ảnh (PNG/JPEG/WebP)")
                    return DecodedImage(raw, e2, null)
                }
                val errs = MiniJson.arr(MiniJson.path(root, "errors"))
                val first = errs?.firstOrNull()
                if (first != null) {
                    val code = MiniJson.path(first, "code")
                    val msg = (MiniJson.path(first, "message") as? String) ?: first.toString()
                    return DecodedImage(null, "", "API báo lỗi" + (if (code != null) " [$code]" else "") + ": " + msg.take(200))
                }
                val em = MiniJson.path(root, "error", "message") as? String
                if (em != null) return DecodedImage(null, "", "API báo lỗi: " + em.take(200))
                return DecodedImage(null, "", "Phản hồi JSON không chứa ảnh")
            } catch (e: IllegalArgumentException) {
                return DecodedImage(null, "", "Phản hồi JSON không đọc được: ${e.message}")
            }
        }
        val snippet = head.replace(Regex("\\s+"), " ").take(120)
        return DecodedImage(null, "", "Phản hồi không phải ảnh (Content-Type=${contentType ?: "?"}, ${body.size} byte" + (if (snippet.isNotEmpty()) ", đầu: $snippet" else "") + ")")
    }

    // ---------------- dựng prompt (ngôn ngữ tự nhiên cho FLUX/SDXL — không phải thẻ tag của SD1.5) ----------------

    const val NO_PEOPLE_NEGATIVE = "people, person, human, man, woman, child, character, face, crowd, silhouette, figure, text, watermark, logo"

    /** Âm bản cho ảnh phác MỘT nhân vật (ảnh tham chiếu danh tính): tránh nhiều người, chữ, watermark. */
    const val CHARACTER_NEGATIVE = "multiple people, crowd, group, text, watermark, logo, deformed, extra limbs, blurry"

    /** Prompt ảnh nền/địa điểm KHÔNG có người. [framing] là ghi chú khung hình người dùng viết (có thể rỗng). */
    fun locationPrompt(name: String, framing: String?, stylePrompt: String, worldRules: String): String {
        val parts = ArrayList<String>()
        parts.add("Establishing shot of the location: ${name.trim()}")
        if (!framing.isNullOrBlank()) parts.add("camera and composition: ${framing.trim()}")
        parts.add("empty scene with absolutely no people, no characters, no figures, no text")
        if (stylePrompt.isNotBlank()) parts.add(stylePrompt.trim())
        if (worldRules.isNotBlank()) parts.add("setting: ${worldRules.trim().take(300)}")
        parts.add("detailed background art, consistent lighting, wide shot")
        return parts.joinToString(". ")
    }

    /** Prompt ảnh phác nhân vật (làm ảnh tham chiếu danh tính): một người, nền trơn, nhìn rõ mặt và trang phục. */
    fun characterSketchPrompt(anchorPrompt: String, stylePrompt: String, changeDescription: String? = null): String {
        val parts = ArrayList<String>()
        parts.add("Character reference image of a single character: ${anchorPrompt.trim()}")
        if (!changeDescription.isNullOrBlank()) parts.add("with this change: ${changeDescription.trim()}")
        parts.add("one person only, upper body, facing the viewer, plain simple background, clear face and clothing")
        if (stylePrompt.isNotBlank()) parts.add(stylePrompt.trim())
        return parts.joinToString(". ")
    }
}
