package com.mangalocal.pipeline

import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * mục 227 TECHNICAL_STATUS.md — Dò điểm TIẾP XÚC TỔNG QUÁT giữa các nhân
 * vật từ khung xương, mở rộng `FaceHandDetector.detectHandOverBodyOverlaps()`
 * (mục 79/80/94, CHỈ dò cổ tay nằm trong hộp thân) sang các loại tiếp xúc
 * còn lại của cảnh ôm/vật/đánh nhau: khuỷu tay, đầu gối, bàn chân, đầu, và
 * tay chạm CỔ/ĐẦU người kia (khoá cổ, túm tóc, bóp cổ).
 *
 * Nguồn gốc: tài liệu mục 15/113/168 tự thừa nhận `tryAutoFixInteractions()`
 * chỉ sửa được vùng HÔNG/GỐI (bbox giao nhau) và TAY-ĐÈ-THÂN; mọi điểm
 * chạm khác (đá vào người, đầu gối tì bụng, khuỷu tay ghì cổ...) KHÔNG
 * được phát hiện nên không được sửa. PDF bổ sung (DeepSeek) và tra cứu
 * cộng đồng (PersonaCraft ICCV 2025: khung xương 2D thiếu tín hiệu chiều
 * sâu để xử lý chi chồng lấn) cùng chỉ về một hướng: sửa CỤC BỘ tại từng
 * điểm chạm bằng prompt mô tả đúng loại tiếp xúc, thay vì hy vọng một lượt
 * sinh chung tự giải được. Hàm này CHỈ tìm vị trí + phân loại; việc vẽ lại
 * do `tryAutoFixInteractions()` (img2img/inpaint có sẵn) đảm nhiệm.
 *
 * Hàm THUẦN (không đọc file, không native, không đọc pixel). Bố cục đầu vào
 * là bố cục THẬT của `MangaPipeline.resolveSkeletonData()` / struct Keypoint
 * native: `18 khớp × 4 float (x, y, z, visible 0/1)` mỗi người, toạ độ x/y
 * chuẩn hoá 0..1, z NHỎ hơn = GẦN camera hơn (đơn vị z không được định nghĩa
 * — xem mục 231; z=0 với đa số template vì PoseKeypoint.z mặc định 0),
 * chỉ số khớp OpenPose-18 (0 mũi, 1 cổ, 2/5 vai, 3/6 khuỷu, 4/7 cổ tay,
 * 8/11 hông, 9/12 gối, 10/13 mắt cá, 14/15 mắt, 16/17 tai).
 *
 * GIỚI HẠN THẬT:
 * - Đây là hình học 2D trên khung xương: "khớp A nằm trong/gần hộp thân B"
 *   KHÔNG chứng minh hai cơ thể thật sự chạm nhau (có thể A đứng TRƯỚC B,
 *   không chạm — thiếu chiều sâu). Kết quả sai là dư một lượt inpaint nhẹ,
 *   không làm hỏng ảnh (denoise vừa phải, mask cục bộ).
 * - Ngưỡng (0.55/0.7/0.5 × kích thước thân) là hằng số kinh nghiệm, CHƯA
 *   hiệu chỉnh trên ảnh thật — nên phần lớn tham số để ở `Thresholds`.
 * - CHƯA build-test trên thiết bị. Logic hình học đã được mô phỏng lại
 *   bằng Python độc lập (tools/test_contact_detector.py).
 */
object ContactDetector {

    const val FLOATS_PER_PERSON = 18 * 4

    /** Các `kind` mà detector này sinh ra (khác "hip_overlap"/"hand_over_body" có sẵn). */
    val LIMB_KINDS: Set<String> = setOf(
        "hand_at_head_neck", "head_contact", "knee_on_body", "foot_on_body", "elbow_on_body"
    )

    fun isLimbKind(kind: String) = kind in LIMB_KINDS

    /**
     * @param rect        vùng cần vẽ lại (pixel)
     * @param kind        một trong LIMB_KINDS
     * @param actorIdx    người CÓ bộ phận chạm (tay/gối/chân/đầu)
     * @param targetIdx   người BỊ chạm
     * @param priority    càng nhỏ càng ưu tiên (mặt/cổ trước, vì lỗi ở mặt lộ nhất)
     */
    data class LimbContact(
        val rect: Rect, val kind: String, val actorIdx: Int, val targetIdx: Int, val priority: Int
    )

    object Thresholds {
        const val VISIBLE_FLAG = 0.5f      // cờ visible trong mảng là 0f/1f
        const val Z_TOL_FRACTION = 0.5f    // chỉ áp khi cảnh CÓ chênh lệch z thật
        const val Z_MEANINGFUL = 0.02f     // dải z nhỏ hơn mức này coi như không có thông tin sâu
        const val TORSO_PAD = 0.15f
        const val HAND_NEAR_NECK = 0.55f   // × kích thước thân người bị chạm
        const val HAND_NEAR_HEAD = 0.70f
        const val HEAD_NEAR_HEAD = 0.60f
        const val LEG_NEAR_HIP = 0.50f
        const val MIN_HALF = 0.05f         // nửa cạnh vùng tối thiểu (tỉ lệ cạnh ngắn ảnh)
        const val HALF_PER_BODY = 0.40f
        const val DEDUP_IOU = 0.35f
    }

    private class Pt(val x: Float, val y: Float, val z: Float, val vis: Float) {
        val visible get() = vis > Thresholds.VISIBLE_FLAG
    }

    private class Body(
        val idx: Int, val joints: Array<Pt>,
        val torsoL: Float, val torsoT: Float, val torsoR: Float, val torsoB: Float,
        val size: Float, val headX: Float, val headY: Float, val hasHead: Boolean,
        val zTorso: Float, val zHead: Float
    ) {
        fun inTorso(p: Pt) = p.x in torsoL..torsoR && p.y in torsoT..torsoB
    }

    private fun buildBody(data: FloatArray, idx: Int): Body? {
        val base = idx * FLOATS_PER_PERSON
        if (base + FLOATS_PER_PERSON > data.size) return null
        val joints = Array(18) { j ->
            val o = base + j * 4
            Pt(data[o], data[o + 1], data[o + 2], data[o + 3])
        }
        val rSh = joints[2]; val lSh = joints[5]; val rHip = joints[8]; val lHip = joints[11]
        if (!rSh.visible || !lSh.visible || !rHip.visible || !lHip.visible) return null
        val xs = listOf(rSh.x, lSh.x, rHip.x, lHip.x)
        val ys = listOf(rSh.y, lSh.y, rHip.y, lHip.y)
        val bw = (xs.max() - xs.min()) * Thresholds.TORSO_PAD
        val bh = (ys.max() - ys.min()) * Thresholds.TORSO_PAD
        // Kích thước thân = trung bình (bề rộng vai, chiều cao thân) — ổn định
        // hơn dùng riêng 1 số khi người nghiêng/cúi.
        val shoulderW = sqrt((rSh.x - lSh.x) * (rSh.x - lSh.x) + (rSh.y - lSh.y) * (rSh.y - lSh.y))
        val torsoH = abs((rHip.y + lHip.y) / 2f - (rSh.y + lSh.y) / 2f)
        val size = max(0.05f, (shoulderW + torsoH) / 2f)
        val headPts = listOf(0, 14, 15, 16, 17).map { joints[it] }.filter { it.visible }
        val hasHead = headPts.isNotEmpty()
        val hx = if (hasHead) headPts.map { it.x }.average().toFloat() else joints[1].x
        val hy = if (hasHead) headPts.map { it.y }.average().toFloat() else joints[1].y
        val zTorso = (rSh.z + lSh.z + rHip.z + lHip.z) / 4f
        val zHead = if (hasHead) headPts.map { it.z }.average().toFloat() else joints[1].z
        return Body(idx, joints, xs.min() - bw, ys.min() - bh, xs.max() + bw, ys.max() + bh, size, hx, hy,
            hasHead || joints[1].visible, zTorso, zHead)
    }

    private fun dist(ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = ax - bx; val dy = ay - by
        return sqrt(dx * dx + dy * dy)
    }

    private fun iou(a: Rect, b: Rect): Float {
        val l = max(a.left, b.left); val t = max(a.top, b.top)
        val r = min(a.right, b.right); val bo = min(a.bottom, b.bottom)
        if (r <= l || bo <= t) return 0f
        val inter = (r - l).toFloat() * (bo - t).toFloat()
        val union = a.width().toFloat() * a.height() + b.width().toFloat() * b.height() - inter
        return if (union <= 0f) 0f else inter / union
    }

    private fun regionAround(
        cx: Float, cy: Float, extraX: Float?, extraY: Float?, half: Float, w: Int, h: Int
    ): Rect {
        val minSide = min(w, h).toFloat()
        val halfPx = half * minSide
        var l = cx * w - halfPx; var r = cx * w + halfPx
        var t = cy * h - halfPx; var b = cy * h + halfPx
        if (extraX != null && extraY != null) {
            l = min(l, extraX * w - halfPx * 0.6f); r = max(r, extraX * w + halfPx * 0.6f)
            t = min(t, extraY * h - halfPx * 0.6f); b = max(b, extraY * h + halfPx * 0.6f)
        }
        return Rect(
            l.toInt().coerceIn(0, w), t.toInt().coerceIn(0, h),
            r.toInt().coerceIn(0, w), b.toInt().coerceIn(0, h)
        )
    }

    /**
     * @param existingRects vùng ĐÃ có (hip_overlap/hand_over_body) — không thêm vùng trùng
     * @param maxRegions    chặn trên số vùng thêm (mỗi vùng = 1 lượt img2img, tốn thời gian)
     */
    fun detect(
        skeletonData: FloatArray, numExpectedPersons: Int, imageW: Int, imageH: Int,
        existingRects: List<Rect> = emptyList(), maxRegions: Int = 4
    ): List<LimbContact> {
        if (numExpectedPersons < 2 || skeletonData.isEmpty() || imageW <= 0 || imageH <= 0) return emptyList()
        val n = min(numExpectedPersons, skeletonData.size / FLOATS_PER_PERSON)
        if (n < 2) return emptyList()
        val bodies = (0 until n).mapNotNull { buildBody(skeletonData, it) }
        if (bodies.size < 2) return emptyList()

        // Lọc theo ĐỘ SÂU z (chỉ khi cảnh thật sự CÓ chênh lệch z): bộ phận của A chỉ
        // tính là CHẠM B nếu z của nó gần z của phần thân/đầu B. Đa số template có
        // z=0 (PoseKeypoint.z mặc định 0) => zRange=0 => bộ lọc này KHÔNG hoạt động và
        // hàm quay về hình học 2D thuần như đã mô tả ở GIỚI HẠN THẬT.
        var zMin = Float.MAX_VALUE; var zMax = -Float.MAX_VALUE
        for (b in bodies) for (j in b.joints) if (j.visible) { zMin = min(zMin, j.z); zMax = max(zMax, j.z) }
        val zRange = if (zMax >= zMin) zMax - zMin else 0f
        val useZ = zRange > Thresholds.Z_MEANINGFUL
        fun zOk(jointZ: Float, targetZ: Float) =
            !useZ || abs(jointZ - targetZ) <= Thresholds.Z_TOL_FRACTION * zRange

        val raw = mutableListOf<Triple<LimbContact, Float, Int>>() // (contact, khoảng cách chuẩn hoá, thứ tự)
        var order = 0
        for (a in bodies) for (b in bodies) {
            if (a.idx == b.idx) continue
            val half = max(Thresholds.MIN_HALF, Thresholds.HALF_PER_BODY * a.size)

            // 1. Tay chạm cổ/đầu người kia (khoá cổ, túm tóc, bóp cổ) — ưu tiên 0.
            for (wristIdx in intArrayOf(4, 7)) {
                val wr = a.joints[wristIdx]
                if (!wr.visible || !b.hasHead) continue
                val neck = b.joints[1]
                val dNeck = if (neck.visible) dist(wr.x, wr.y, neck.x, neck.y) / b.size else Float.MAX_VALUE
                val dHead = dist(wr.x, wr.y, b.headX, b.headY) / b.size
                val d = min(dNeck, dHead)
                if ((dNeck < Thresholds.HAND_NEAR_NECK || dHead < Thresholds.HAND_NEAR_HEAD) && zOk(wr.z, b.zHead)) {
                    raw += Triple(LimbContact(
                        regionAround(wr.x, wr.y, b.headX, b.headY, half, imageW, imageH),
                        "hand_at_head_neck", a.idx, b.idx, 0), d, order++)
                }
            }
            // 2. Đầu chạm đầu/thân người kia (húc đầu, hôn, tì trán).
            val nose = a.joints[0]
            if (nose.visible && b.hasHead) {
                val dHead = dist(nose.x, nose.y, b.headX, b.headY) / b.size
                if ((dHead < Thresholds.HEAD_NEAR_HEAD || b.inTorso(nose)) && zOk(nose.z, b.zHead)) {
                    raw += Triple(LimbContact(
                        regionAround(nose.x, nose.y, b.headX, b.headY, half, imageW, imageH),
                        "head_contact", a.idx, b.idx, 0), dHead, order++)
                }
            }
            // 3. Đầu gối / bàn chân chạm thân hoặc hông người kia (đá, tì gối, kẹp chân) — ưu tiên 1.
            val bHipMidX = (b.joints[8].x + b.joints[11].x) / 2f
            val bHipMidY = (b.joints[8].y + b.joints[11].y) / 2f
            for (kneeIdx in intArrayOf(9, 12)) {
                val k = a.joints[kneeIdx]
                if (!k.visible) continue
                val dHip = dist(k.x, k.y, bHipMidX, bHipMidY) / b.size
                if ((b.inTorso(k) || dHip < Thresholds.LEG_NEAR_HIP) && zOk(k.z, b.zTorso)) {
                    raw += Triple(LimbContact(
                        regionAround(k.x, k.y, null, null, half, imageW, imageH),
                        "knee_on_body", a.idx, b.idx, 1), dHip, order++)
                }
            }
            for (ankleIdx in intArrayOf(10, 13)) {
                val f = a.joints[ankleIdx]
                if (!f.visible) continue
                if (b.inTorso(f) && zOk(f.z, b.zTorso)) {
                    raw += Triple(LimbContact(
                        regionAround(f.x, f.y, null, null, half, imageW, imageH),
                        "foot_on_body", a.idx, b.idx, 1), 0f, order++)
                }
            }
            // 4. Khuỷu tay đè lên thân người kia (ghì, chống khuỷu) — ưu tiên 2.
            for (elbowIdx in intArrayOf(3, 6)) {
                val e = a.joints[elbowIdx]
                if (!e.visible) continue
                if (b.inTorso(e) && zOk(e.z, b.zTorso)) {
                    raw += Triple(LimbContact(
                        regionAround(e.x, e.y, null, null, half, imageW, imageH),
                        "elbow_on_body", a.idx, b.idx, 2), 0f, order++)
                }
            }
        }

        val sorted = raw.filter { it.first.rect.width() > 0 && it.first.rect.height() > 0 }
            .sortedWith(compareBy({ it.first.priority }, { it.second }, { it.third }))
        val kept = mutableListOf<LimbContact>()
        for ((c, _, _) in sorted) {
            if (kept.size >= maxRegions) break
            if (existingRects.any { iou(it, c.rect) > Thresholds.DEDUP_IOU }) continue
            if (kept.any { iou(it.rect, c.rect) > Thresholds.DEDUP_IOU }) continue
            kept += c
        }
        return kept
    }

    /**
     * Prompt CỤC BỘ theo loại tiếp xúc — chỉ mô tả ĐIỂM CHẠM (không mô tả lại
     * từng người riêng lẻ), kèm cụm "ranh giới hai cơ thể rõ ràng" mà mục
     * 15 đã dùng. Trả (positive, negative) đã ghép `basePrompt`/`baseNegative`.
     * Chuỗi tiếng Anh dạng tag — cùng quy ước với hip_overlap/hand_over_body
     * có sẵn trong tryAutoFixInteractions().
     */
    fun promptFor(kind: String, basePrompt: String, baseNegative: String): Pair<String, String> {
        val pos = when (kind) {
            "hand_at_head_neck" ->
                "hand gripping neck, fingers wrapped around, five fingers, correct hand anatomy, " +
                    "clear boundary between hand and neck, distinct skin separation"
            "head_contact" ->
                "two faces close together, two distinct faces, each face complete, " +
                    "clear facial features, separate heads, correct head anatomy"
            "knee_on_body" ->
                "knee pressed against body, leg clearly separate from torso, " +
                    "cloth folds at contact point, correct leg anatomy, distinct silhouettes"
            "foot_on_body" ->
                "foot pressed against body, five toes, correct foot anatomy, " +
                    "foot clearly separate from torso, distinct silhouettes"
            "elbow_on_body" ->
                "elbow pressing against body, arm clearly separate from torso, " +
                    "correct arm anatomy, cloth folds at contact point, distinct silhouettes"
            else -> "clear boundary between bodies, distinct silhouettes"
        }
        val neg = "fused bodies, merged limbs, conjoined bodies, extra limbs, missing limbs, " +
            "extra fingers, deformed anatomy, mutated hands"
        return Pair("$pos, $basePrompt", "$neg, $baseNegative")
    }
}
