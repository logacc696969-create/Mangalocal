package com.mangalocal.pipeline

import kotlinx.coroutines.CancellationException

/** Kết quả một lần gọi thử: [ok] + thông báo tiếng Việt hiện nguyên văn cho người dùng. */
class FreeImageTestReport(val ok: Boolean, val message: String)

/**
 * mục 273 TECHNICAL_STATUS.md — TỰ KIỂM API ảnh miễn phí NGAY TRÊN MÁY NGƯỜI DÙNG (thay cho "gọi API thật" mà sandbox không làm được: không có mạng, không có khoá).
 * Gửi MỘT yêu cầu nhỏ (256x256) qua đúng đường mà tạo ảnh nền/ảnh phác dùng ([FreeImageClient.generate]) nên kiểm cả tham số (Cloudflare steps/prompt, Pollinations host/Bearer),
 * giải mã phản hồi và thử lại theo [HttpRetryPolicy]. KHÔNG ném: mọi lỗi trở thành thông báo (đã tiếng Việt từ FreeImageClient/HttpRetryPolicy), trừ huỷ coroutine.
 */
object FreeImageSelfTest {
    const val TEST_PROMPT = "a single red apple on a white table, soft daylight, simple product photo"
    const val TEST_SIZE = 256
    const val TEST_SEED = 12345L

    /** Thông báo khi gọi thành công (thuần, không phụ thuộc mạng). */
    fun describeSuccess(provider: FreeImageProvider, ext: String, byteCount: Int, elapsedMs: Long): String =
        "✓ ${provider.label}: nhận ảnh .$ext ${(byteCount + 512) / 1024} KB sau ${elapsedMs / 1000}.${(elapsedMs % 1000) / 100} giây — API và thông tin đăng nhập dùng được."

    /** Thông báo khi lỗi; [error] đã là câu tiếng Việt của tầng dưới (hoặc null). */
    fun describeFailure(provider: FreeImageProvider, error: String?): String =
        "✗ " + (if (error.isNullOrBlank()) "${provider.label}: lỗi không rõ" else error)

    suspend fun run(provider: FreeImageProvider, creds: FreeImageCreds, onWait: (String) -> Unit = {}): FreeImageTestReport {
        val t0 = System.currentTimeMillis()
        return try {
            val r = FreeImageClient(provider, creds).generate(TEST_PROMPT, "", TEST_SIZE, TEST_SIZE, TEST_SEED, onWait)
            FreeImageTestReport(true, describeSuccess(provider, r.ext, r.bytes.size, System.currentTimeMillis() - t0))
        } catch (ce: CancellationException) {
            throw ce
        } catch (ex: Exception) {
            FreeImageTestReport(false, describeFailure(provider, ex.message))
        }
    }
}
