package com.mangalocal.pipeline

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Inpaint Anything" thủ công (mục 21 TECHNICAL_STATUS.md) — dùng cho PHASE
 * CUỐI, sau khi ảnh đã ở độ phân giải cuối (upscale + Ultrafix + auto-fix
 * mặt/tay xong) mà VẪN còn lỗi (dính người, giải phẫu sai) mà các bước tự
 * động không bắt được/không sửa đúng.
 *
 * Luồng: user chạm 1 điểm trên vùng lỗi -> MobileSAM (mục 21) tự phân đoạn
 * ra mask chính xác theo đúng khối đó -> mask này feed THẲNG vào
 * `ImagePipeline.img2imgFix()` ĐÃ CÓ (mục 16) — CÙNG 1 inpainting với
 * auto-fix mặt/tay (mục 17), không viết pipeline vẽ lại riêng, đúng yêu
 * cầu "cái inpainting của mask tay cũng cùng 1 inpainting luôn".
 */
class ManualMaskFixer(private val storyManager: StoryManager, private val imagePipeline: ImagePipeline) {

    // mục 133 TECHNICAL_STATUS.md — SỬA BUG THẬT phát hiện khi triển khai
    // Industrial Batch Upscale Mode: TRƯỚC ĐÂY `ctx` là `val`, chỉ init 1
    // LẦN DUY NHẤT lúc construct object. `close()` gọi `mobileSamFree(ctx)`
    // giải phóng THẬT bộ nhớ native nhưng KHÔNG THỂ reset `ctx` về 0 (val
    // không gán lại được) — nếu `close()` từng được gọi giữa phiên (đúng
    // điều mục 133 cần làm, để giải phóng MobileSAM sau giai đoạn build
    // mask, trước giai đoạn SD inpaint) rồi `maskFixer` (cached bởi `by
    // lazy` trong `MangaPipeline`, KHÔNG tạo instance mới) bị dùng LẠI sau
    // đó (chương tiếp theo trong CÙNG session app, hoặc user bấm "Sinh lại
    // panel" có auto-fix mặt/tay sau khi đã 1 lần bấm Huỷ generation —
    // `cancelSafely()` cũng gọi `close()` từ trước mục 133 rồi) — `ctx` cũ
    // vẫn khác 0 dù bộ nhớ native đã mất, `isReady()` trả về SAI (true) →
    // mọi lời gọi `clickToMask()` sau đó dùng con trỏ ĐÃ GIẢI PHÓNG → nguy
    // cơ crash use-after-free THẬT. Bug này CÓ SẴN TỪ TRƯỚC mục 133 (đã
    // tồn tại từ khi `cancelSafely()`/`freeAllPipelineResources()` được
    // viết), chỉ lộ rõ và trở thành RỦI RO THẬT hơn khi mục 133 chủ động
    // gọi `close()` giữa chừng pipeline (không chỉ lúc app/story kết thúc
    // hẳn như trước).
    // Sửa: `ctx` giờ `var`, `close()` reset về 0, và mọi hàm public tự gọi
    // `ensureInit()` để LƯỜI TÁI KHỞI TẠO khi cần dùng lại — đúng mẫu hình
    // "resident, tự nạp lại khi cần, tự free khi được yêu cầu" mà
    // `ImagePipeline.loadEsrgan()`/`loadSD()` đã dùng cho các model khác
    // trong dự án, thay vì "init 1 lần duy nhất, không bao giờ hồi phục
    // được" như trước.
    private var ctx: Long = 0L

    private fun ensureInit() {
        if (ctx != 0L) return
        ctx = try {
            NativeBridge.mobileSamInit(storyManager.yoloDir.absolutePath) // dùng chung thư mục model YOLO/detect
        } catch (e: Exception) { 0L }
    }

    fun isReady(): Boolean { ensureInit(); return ctx != 0L }

    /**
     * clickX/clickY: toạ độ PIXEL theo đúng ảnh gốc tại `imagePath` (không
     * phải toạ độ normalized 0..1 — khác quy ước Rect trong FaceHandDetector,
     * vì đây là input trực tiếp của decoder MobileSAM, giữ nguyên contract
     * gốc của model để không phải quy đổi thêm 1 lớp có thể gây lệch).
     */
    suspend fun clickToMask(imagePath: String, clickX: Float, clickY: Float, outDir: File, panelIndex: Int): String? =
        withContext(Dispatchers.IO) {
            ensureInit()
            if (ctx == 0L) return@withContext null
            val maskFile = File(outDir, "panel_%03d_manualmask.png".format(panelIndex))
            val result = NativeBridge.mobileSamClickToMask(ctx, imagePath, clickX, clickY, maskFile.absolutePath)
            result.takeIf { it.isNotBlank() }
        }

    /**
     * Vẽ lại đúng vùng mask vừa phân đoạn — gọi CHUNG `img2imgFix()`, cùng
     * hàm auto-fix mặt/tay (mục 17) đang dùng. denoiseStrength cho user tự
     * chỉnh (mặc định theo cùng "thông số vàng" 0.35-0.45 đã thống nhất).
     */
    suspend fun inpaintMaskedRegion(
        panelIndex: Int, prompt: String, negativePrompt: String, stylePrompt: String,
        imagePath: String, maskPath: String, denoiseStrength: Float,
        width: Int, height: Int, seed: Long, outDir: File
    ): String = imagePipeline.img2imgFix(
        panelIndex = panelIndex, prompt = prompt, negativePrompt = negativePrompt, stylePrompt = stylePrompt,
        inputPath = imagePath, maskPath = maskPath, denoiseStrength = denoiseStrength,
        width = width, height = height, steps = 20, cfgScale = 7f, seed = seed,
        ultrafix = false, ultrafixTile = 512, outDir = outDir
    ) { _, _ -> }

    fun close() { if (ctx != 0L) { NativeBridge.mobileSamFree(ctx); ctx = 0L } }
}
