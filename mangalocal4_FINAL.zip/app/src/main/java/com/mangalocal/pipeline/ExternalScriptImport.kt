package com.mangalocal.pipeline

import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import com.mangalocal.model.BubbleType
import com.mangalocal.model.DialogueLine
import com.mangalocal.model.Scene

/**
 * mục 120 TECHNICAL_STATUS.md — import kịch bản ĐÃ CÓ SẴN từ LLM ngoài app
 * (vd ChatGPT/Claude dùng trên web, hoặc bất kỳ công cụ nào khác), bỏ qua
 * bước `LLMParser.parseStory()` (LLM on-device tự chia truyện chữ thô
 * thành scene) — dùng khi user đã có kịch bản chia scene sẵn, không muốn
 * (hoặc không cần) LLM nhỏ trên máy làm lại việc đó.
 *
 * GIỚI HẠN THẬT quan trọng (đọc trước khi dùng): CHỈ bypass được bước
 * "truyện chữ -> scene có cấu trúc". Bước SAU đó — `LLMParser.buildPrompt()`
 * (scene có cấu trúc -> tag prompt SD1.5 thật theo đúng PromptStyle của
 * checkpoint đang dùng + chọn pose template THẬT trong pose_library.json
 * của user) — VẪN CẦN LLM on-device chạy, vì đây là bước MÁY MÓC/KỸ THUẬT
 * phụ thuộc trực tiếp vào những gì có SẴN TRÊN MÁY NÀY (checkpoint nào,
 * thư viện pose nào) — 1 LLM ngoài app không thể biết trước những thứ đó.
 * KHÔNG PHẢI "thoái thác không giải quyết" — đây là ranh giới kỹ thuật
 * thật giữa 2 việc khác bản chất (sáng tác kịch bản vs. dịch sang ngôn ngữ
 * kỹ thuật của pipeline sinh ảnh cụ thể).
 */
object ExternalScriptImport {
    private val gson = Gson()

    /** 1 scene trong format JSON import — cố ý ĐƠN GIẢN HƠN Scene nội bộ
     * (thiếu actionCategory/expression — 2 field mà chỉ LLMParser.parseStory()
     * nội bộ mới tự phân loại đúng theo enum đóng đã định nghĩa, xem
     * Scene.kt mục 85/93). Thiếu 2 field đó -> rơi về heuristic regex cũ
     * (SeedRegistry.resolveActionCategory()), KHÔNG hỏng gì thêm so với
     * hành vi TRƯỚC KHI 2 field đó tồn tại — chỉ mất phần cải thiện độ
     * chính xác, không phải lỗi cứng. */
    data class ExternalScene(
        val characters: List<String> = emptyList(),
        val description: String = "",
        val mood: String = "",
        val cameraAngle: String = "",
        val action: String = "",
        val setting: String = "",
        val dialogue: List<ExternalDialogueLine> = emptyList(),
        // mục 121 TECHNICAL_STATUS.md — cùng field depth_scale đã thêm cho
        // LLM nội bộ (Scene.depthScale), cho LLM NGOÀI cũng điền được nếu
        // muốn chỉ định tỷ lệ gần/xa tường minh. Tuỳ chọn — để trống {} là
        // bình thường, không bắt buộc.
        val depth_scale: Map<String, Float> = emptyMap()
    )

    data class ExternalDialogueLine(
        val character: String = "",
        val text: String = "",
        // Chuỗi tự do, không bắt ép đúng enum BubbleType ngay ở JSON — parse
        // khoan dung hơn (user/LLM ngoài viết "speech"/"SPEECH"/"nói" đều
        // được, xem parseBubbleType()), tránh cả file import hỏng chỉ vì 1
        // dòng thoại gõ sai hoa/thường.
        val type: String = "speech"
    )

    data class ScriptJson(val scenes: List<ExternalScene> = emptyList())

    private fun parseBubbleType(raw: String): BubbleType = when (raw.trim().lowercase()) {
        "thought", "nghĩ", "suy nghĩ" -> BubbleType.THOUGHT
        "narration", "tường thuật", "dẫn truyện" -> BubbleType.NARRATION
        "shout", "hét", "quát" -> BubbleType.SHOUT
        else -> BubbleType.SPEECH // mặc định an toàn — không rõ/gõ lạ -> lời thoại thường
    }

    /**
     * Parse chuỗi JSON thô (user dán từ LLM ngoài) thành [ScriptJson].
     * Ném [IllegalArgumentException] với thông báo tiếng Việt RÕ RÀNG nếu
     * JSON sai cú pháp hoặc thiếu field "scenes" — KHÔNG để lỗi Gson mù mờ
     * lọt tới UI (người dùng không phải lập trình viên, cần biết ĐÚNG chỗ
     * sai để tự sửa JSON dán vào, không phải đọc stack trace).
     */
    fun parseFromRawJson(rawJson: String): ScriptJson {
        val trimmed = rawJson.trim()
        if (trimmed.isEmpty()) throw IllegalArgumentException("Chưa dán nội dung kịch bản nào")
        val script = try {
            gson.fromJson(trimmed, ScriptJson::class.java)
        } catch (e: JsonSyntaxException) {
            throw IllegalArgumentException(
                "JSON sai cú pháp — kiểm tra lại dấu ngoặc/dấu phẩy. Lỗi gốc: ${e.message?.take(120)}"
            )
        }
        if (script == null || script.scenes.isEmpty()) {
            throw IllegalArgumentException(
                "Không tìm thấy field \"scenes\" (mảng) trong JSON, hoặc mảng rỗng. " +
                "Xem đúng định dạng mẫu ở màn hình import."
            )
        }
        return script
    }

    /** Chuyển [ScriptJson] đã parse thành [Scene] nội bộ — index tự gán
     * theo thứ tự trong mảng "scenes" (0-based, đúng quy ước Scene.index
     * dùng xuyên suốt pipeline). */
    fun toScenes(json: ScriptJson): List<Scene> = json.scenes.mapIndexed { i, ext ->
        Scene(
            index = i,
            description = ext.description,
            characters = ext.characters,
            mood = ext.mood,
            cameraAngle = ext.cameraAngle,
            action = ext.action,
            setting = ext.setting,
            dialogue = ext.dialogue.map { d ->
                DialogueLine(characterName = d.character, text = d.text, type = parseBubbleType(d.type))
            },
            actionCategory = null, // xem GIỚI HẠN THẬT ở docstring đầu file
            expression = null,
            depthScale = ext.depth_scale.filterValues { it > 0f && it.isFinite() } // lọc an toàn, cùng quy tắc parser LLM nội bộ
        )
    }

    /** Chuỗi JSON mẫu hiển thị cho user copy làm khung sườn khi tự viết
     * prompt cho LLM ngoài (vd dán prompt này + truyện của họ vào ChatGPT,
     * xin trả về đúng format này) — KHÔNG hardcode trong UI, để 1 chỗ duy
     * nhất dễ cập nhật nếu format đổi. */
    const val EXAMPLE_JSON = """{
  "scenes": [
    {
      "characters": ["An", "Bình"],
      "description": "An và Bình đứng đối diện nhau trong công viên, ánh nắng chiều buông xuống",
      "mood": "căng thẳng, xúc động",
      "cameraAngle": "medium shot",
      "action": "hai người nhìn nhau, không nói gì",
      "setting": "công viên buổi chiều",
      "dialogue": [
        { "character": "An", "text": "Cậu định làm gì tiếp theo?", "type": "speech" }
      ],
      "depth_scale": {}
    }
  ]
}"""
}
