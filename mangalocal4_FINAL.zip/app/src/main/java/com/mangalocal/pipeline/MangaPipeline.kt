package com.mangalocal.pipeline

import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import com.mangalocal.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MangaPipeline(
    private val storyManager: StoryManager,
    private val thermalMonitor: ThermalMonitor,
    private val runtimeOptimizer: RuntimeOptimizer
) {
    private val _state = MutableStateFlow(PipelineState())
    val state: StateFlow<PipelineState> = _state.asStateFlow()

    private val imagePipeline = ImagePipeline(storyManager)
    private val exportEngine  = ExportEngine()
    private val publishExporter = PublishExporter(exportEngine)   // mục 233
    private val videoExporter   = VideoExporter(exportEngine)     // mục 234
    /** File phụ (webtoon zip / metadata / mp4) của lần exportChapter() gần nhất — đọc ngay sau khi gọi. */
    @Volatile var lastExtraExports: List<Pair<String, String>> = emptyList() // (đường dẫn, mime)
    private val bubbleEngine  = BubbleEngine(storyManager)
    // Dùng CHUNG 1 PoseExtractor (YOLOv8-pose, mục 19) cho cả trích xuất
    // pose_library.json LẪN auto-fix mặt/tay — đúng yêu cầu "dùng YOLO
    // xuyên suốt, không code lại autodetect riêng cho từng việc" (mục 20).
    // mục 159 TECHNICAL_STATUS.md — BUG THẬT ĐÃ SỬA: `poseExtractor` là `by
    // lazy` (delegate), KHÔNG PHẢI `lateinit var` — `this::poseExtractor.isInitialized`
    // chỉ hợp lệ trên tham chiếu tới property `lateinit`, gây lỗi build thật
    // "This declaration can only be called on a reference to a lateinit
    // property" (build #97). Giữ riêng instance `Lazy<T>` (`poseExtractorLazy`)
    // để gọi ĐÚNG `Lazy<T>.isInitialized()` (hàm trên chính đối tượng Lazy,
    // không phải trên property delegate) — `poseExtractor` vẫn dùng như cũ
    // qua `by poseExtractorLazy`, không đổi hành vi lazy-init ở mọi nơi khác.
    private val poseExtractorLazy = lazy { PoseExtractor(storyManager.appContext, storyManager) }
    private val poseExtractor by poseExtractorLazy
    private val faceHandDetector by lazy { FaceHandDetector(poseExtractor) }
    // mục 232 TECHNICAL_STATUS.md — độ sâu đơn ảnh (MiDaS) cho bộ lọc điểm chạm; cùng
    // khuôn Lazy + isInitialized() như poseExtractor để dọn dẹp không vô tình khởi tạo.
    private val depthEstimatorLazy = lazy { DepthEstimator(storyManager) }
    private val depthEstimator by depthEstimatorLazy
    // mục 246 — cổng danh tính (ArcFace). Lazy + isInitialized() như các model tuỳ chọn khác.
    private val identityGuardLazy = lazy { FaceIdentityGuard(storyManager) }
    private val identityGuard by identityGuardLazy
    private var llmParser: LLMParser? = null
    private var backendRouter: BackendRouter? = null
    private var job: Job? = null
    // mục 83 TECHNICAL_STATUS.md — Job THẬT đang chạy (khác `job` phía trên,
    // vốn KHÔNG BAO GIỜ được gán ở đâu cả — dead code phát hiện khi rà lại
    // theo yêu cầu user, xem `cancelSafely()` để hiểu vì sao đây là bug thật
    // chứ không phải chưa dùng tới). `@Volatile` vì đọc/ghi từ nhiều thread
    // (coroutine chạy trên Dispatchers.IO, `cancelSafely()` gọi từ luồng
    // khác qua viewModelScope).
    @Volatile private var currentJob: Job? = null

    // mục 74 TECHNICAL_STATUS.md — Quality Gate tự động (đếm chi/đo tỷ lệ
    // xương từ skeleton YOLOv8-pose đã có sẵn, KHÔNG chạy inference thêm).
    private val qualityGate = QualityGateChecker()
    // mục 75 — Seed Registry (lưu seed "hoàn hảo" theo story, lazy vì cần
    // biết storyDir cụ thể — chỉ có khi có story đang xử lý).
    private var seedRegistry: SeedRegistry? = null
    private fun getOrCreateSeedRegistry(storyId: String): SeedRegistry {
        val cached = seedRegistry
        if (cached != null) return cached
        val reg = SeedRegistry(storyManager.storyDir(storyId))
        seedRegistry = reg
        return reg
    }
    // mục 76 — Bubble Protection Mask (che ô thoại khỏi bị vẽ đè lúc auto-fix)
    private val bubbleProtection = BubbleProtectionMask()

    // Cache hardware profile — chỉ detect 1 lần, dùng lại cho mọi chương
    private val hwProfile by lazy { runtimeOptimizer.detectHardware() }
    private val optimalConfig by lazy { runtimeOptimizer.computeOptimalConfig(hwProfile) }

    // mục 138 TECHNICAL_STATUS.md — helper duy nhất quyết định số thread
    // LLM thật sự dùng: mặc định (`nThreadsAutoDetect=true`) trả về
    // `optimalConfig.nThreads` (hành vi CŨ, không đổi gì) — user tắt cờ
    // này để ép dùng `settings.nThreads` (Slider trong Settings, TRƯỚC ĐÂY
    // là UI vỏ rỗng vì không có hàm này). Gom về 1 hàm DUY NHẤT thay vì
    // sửa lẻ tẻ 10 call site — nếu sau này đổi logic override, chỉ sửa 1 chỗ.
    private fun effectiveNThreads(settings: GenerationSettings): Int =
        if (settings.nThreadsAutoDetect) optimalConfig.nThreads else settings.nThreads.coerceIn(1, 16)

    // ── Setting 2 tầng: hợp nhất GenerationSettings (chung) +
    // PanelOverrideSettings (riêng ảnh này) — field nào override có giá
    // trị (không null) thì ƯU TIÊN override, còn lại lấy từ tầng chung.
    // KHÔNG có field LoRA/model ở đây (lý do đã chốt: không bật/tắt LoRA
    // per-ảnh được) — model chỉ đổi được gián tiếp qua characterOverride.
    private data class Effective(
        val prompt: String, val negativePrompt: String, val poseTemplate: String, val poseAngle: String,
        val width: Int, val height: Int, val steps: Int, val cfgScale: Float, val seed: Long, val characterName: String?,
        // mục 176 TECHNICAL_STATUS.md — vá lỗ hổng doc/code lệch nhau THẬT:
        // comment ở khai báo `ImageModelTier` (Models.kt, mục 171) khẳng
        // định "đặt modelTierOverride = SDXL sẽ bị MangaPipeline LOG CẢNH
        // BÁO rồi tự rơi về SD1.5" — nhưng lúc đó, KHÔNG có dòng code nào
        // trong MangaPipeline/ImagePipeline/native từng đọc
        // `defaultModelTier`/`modelTierOverride` để làm việc đó (đã tự grep
        // xác nhận, không phải suy đoán). Thêm field này + log cảnh báo ở
        // `resolveEffective()` bên dưới để lời hứa trong comment trở thành
        // ĐÚNG THẬT tại thời điểm đó.
        // mục 184 TECHNICAL_STATUS.md — CẬP NHẬT: field này NAY ĐÃ được
        // `dispatchSdxlPanel()` (gọi từ `generatePanels()`/`regeneratePanel()`,
        // ngay SAU khi `resolveEffective()` trả về) đọc để CHỌN PIPELINE
        // thật — không còn "CHƯA được nơi nào đọc" như mục 176 mô tả. Log
        // cảnh báo bên dưới cũng đã sửa lại cho khớp (không còn khẳng định
        // cứng "dùng SD1.5", vì giờ có thể thật sự dùng SDXL nếu đủ điều
        // kiện — xem `resolveEffective()`).
        val modelTier: ImageModelTier
    )

    // Chèn trigger word Textual Inversion của các nhân vật KHÔNG được chọn
    // neo chính (eff.characterName) vào đầu prompt — cho họ 1 lớp nhất quán
    // yếu hơn thay vì hoàn toàn không có gì. An toàn khi gọi dù panel chỉ có
    // 1 nhân vật hoặc không ai có TI (trả về prompt gốc, không đổi).
    private fun injectEmbeddingTriggers(
        prompt: String, panel: Panel, allChars: List<Character>, primaryCharacterName: String?
    ): String {
        val triggers = panel.scene.characters
            .filter { it != primaryCharacterName }
            .mapNotNull { name -> allChars.find { c -> c.name == name }?.embeddingTrigger }
            .distinct()
        return if (triggers.isEmpty()) prompt else triggers.joinToString(", ") + ", " + prompt
    }

    // mục 123 TECHNICAL_STATUS.md — "anchor prompting" cho nhánh CHỈ 1
    // nhân vật/panel (single-char/remote/regenerate) — KHÔNG dùng chung
    // với injectEmbeddingTriggers() vì hàm đó CŨNG được gọi ở nhánh
    // multiChar-mask (1 prompt CHUNG cho N người), nơi thêm tag "N đầu"
    // của RIÊNG 1 người vào prompt chung có rủi ro SD gắn nhầm tỷ lệ đó
    // cho CẢ những người khác trong cùng mask (attribute-binding không
    // đáng tin khi nhiều chủ thể chia sẻ 1 đoạn text — hạn chế đã biết
    // của SD1.5, không phải giả định). Nhánh 1-người/panel KHÔNG có rủi ro
    // này (chỉ 1 danh tính được điều kiện hoá bằng IP-Adapter trong ảnh).
    // mục 161 TECHNICAL_STATUS.md (đợt 2 — trả lời "nhân vật lớn lên/đổi
    // trang phục thì sao"): áp override CharacterAnchorVersion (nếu có,
    // đúng chương) LÊN TRÊN đối tượng Character TRƯỚC KHI đưa vào bất kỳ
    // logic đọc `boneProportions`/`anchorPrompt` nào phía dưới (headsTall
    // tag, prompt injection, PoseRetargeter...) — 1 ĐIỂM DUY NHẤT, thay vì
    // sửa từng nơi đọc `ch.boneProportions`/`ch.anchorPrompt` riêng lẻ (4+
    // chỗ, dễ sót/lệch nhau — đúng bài học mục 93). KHÔNG đổi
    // `anchorImagePath`/`tornAnchorImagePath` ở đây (ảnh đã tự chọn đúng
    // qua `StoryManager.getCharacterAnchor(chapterNumber=...)` riêng biệt
    // — hàm này chỉ lo phần "chữ" + "tỷ lệ xương" của Character object).
    // KHÔNG ghi đè `anchorPrompt` nếu label rỗng — tránh dư dấu phẩy vô ích
    // khi user chỉ tạo version để đổi tỷ lệ cơ thể mà không ghi mô tả.
    private fun applyActiveAnchorVersion(chars: List<Character>, chapterNumber: Int?): List<Character> {
        if (chapterNumber == null) return chars
        return chars.map { c ->
            val v = c.activeAnchorVersion(chapterNumber) ?: return@map c
            c.copy(
                anchorPrompt = if (v.label.isNotBlank()) "${c.anchorPrompt}, ${v.label}" else c.anchorPrompt,
                boneProportions = v.boneProportionsOverride ?: c.boneProportions
            )
        }
    }

    private fun injectHeadsTallTag(prompt: String, characterName: String?, allChars: List<Character>): String {
        val ch = characterName?.let { name -> allChars.find { it.name == name } } ?: return prompt
        val tag = ch.boneProportions.headsTallPromptTag()
        return if (tag.isEmpty()) prompt else "$tag, $prompt"
    }

    // Ultrafix — Hires-fix kiểu Ultimate SD Upscale (mục 16/20
    // TECHNICAL_STATUS.md): vẽ lại NHẸ toàn ảnh SAU khi ESRGAN đã phóng to,
    // ở đúng "thông số vàng" denoise 0.35-0.45 theo khuyến nghị cộng đồng —
    // đủ để AI vẽ đè ranh giới nhòe/dính thành nét sắc, không đổi bố cục/tư
    // thế gốc (denoise thấp = giữ nguyên phần lớn nội dung latent gốc).
    // CHƯA BUILD-TEST — bọc try/catch riêng, lỗi ở đây rơi về ảnh ESRGAN
    // thuần (không có gì tệ hơn trước khi có Ultrafix).
    private suspend fun tryUltrafixRedraw(
        upscaledPath: String, panel: Panel, settings: GenerationSettings, outDir: File
    ): String {
        return try {
            val bitmap = BitmapFactory.decodeFile(upscaledPath) ?: return upscaledPath
            val w = bitmap.width; val h = bitmap.height
            bitmap.recycle()
            log("  → Ultrafix: vẽ lại bề mặt ${w}x${h} (denoise ${settings.ultrafixDenoiseStrength})...")
            imagePipeline.img2imgFix(
                panelIndex = panel.index, prompt = panel.prompt, negativePrompt = panel.negativePrompt,
                stylePrompt = settings.imageStyle.stylePrompt, inputPath = upscaledPath, maskPath = null,
                denoiseStrength = settings.ultrafixDenoiseStrength, width = w, height = h,
                steps = 20, cfgScale = 7f, seed = panel.index.toLong() + 2000L,
                ultrafix = true, ultrafixTile = 512, outDir = outDir
            ) { _, _ -> }
        } catch (ex: Exception) {
            log("  ⚠ Ultrafix lỗi (${ex.message}) — giữ ảnh ESRGAN thuần")
            upscaledPath
        }
    }

    // Auto-fix mặt/tay (mục 16/17/20 TECHNICAL_STATUS.md, ADetailer-style).
    // CẬP NHẬT (mục 53 TECHNICAL_STATUS.md — trả lời phân tích gap user dán
    // vào, mục "Inpaint Anything tích hợp auto" trước đó ghi "CHƯA làm, để
    // sau" ở mục 20 #4): mask giờ ƯU TIÊN dùng MobileSAM (mục 21, trước đây
    // CHỈ dùng cho UI thủ công qua ManualMaskFixer) để phân đoạn CHÍNH XÁC
    // theo khối thật thay vì hình chữ nhật cứng suy từ pose keypoint — vừa
    // đóng gap "Inpaint Anything auto", vừa sửa luôn nhược điểm "mask cứng
    // viền, chưa feather" đã ghi ở mục 17 rủi ro #3. MobileSAM không sẵn
    // sàng (thiếu model/lỗi bất kỳ vùng nào) -> TỰ RƠI VỀ rectangle CÓ
    // FEATHER biên mềm (cải tiến so với rectangle cứng cũ) cho riêng vùng
    // đó — KHÔNG BAO GIỜ làm hỏng cả panel vì thiếu SAM.
    // mục 159 TECHNICAL_STATUS.md — cùng bug/cùng cách sửa như `poseExtractor`
    // ở trên: `maskFixer` là `by lazy`, không phải `lateinit var`.
    private val maskFixerLazy = lazy { ManualMaskFixer(storyManager, imagePipeline) }
    private val maskFixer by maskFixerLazy

    // mục 133 TECHNICAL_STATUS.md — Industrial Batch Mode toàn pipeline
    // (theo đúng yêu cầu user: "toàn bộ ảnh đi qua từng model", không phải
    // "1 ảnh đi qua hết toàn bộ model"). Tách hàm gốc `tryAutoFixFacesHands`
    // (dưới đây, GIỮ NGUYÊN 100% cho nhánh cũ) thành 2 nửa dùng được RIÊNG:
    //   `buildAutoFixMaskOrNull()` — CHỈ detect vùng + build file mask
    //   (dùng faceHandDetector + MobileSAM qua maskFixer, KHÔNG đụng SD).
    //   `applyAutoFixInpaint()` — CHỈ gọi SD img2imgFix với mask ĐÃ CÓ SẴN
    //   (KHÔNG đụng MobileSAM/detector).
    // Nhờ vậy có thể chạy "MobileSAM cho TẤT CẢ panel trước" rồi "SD cho
    // TẤT CẢ panel sau", đúng nghĩa industrial batch cho ĐÚNG cặp model
    // từng bị coi là "không tách được sạch" (mục 132/cuộc trò chuyện
    // trước) — hoá ra tách được, vì mask vốn đã là 1 FILE trung gian trên
    // đĩa (`panel_%03d_mask.png`), không có ràng buộc kỹ thuật nào bắt
    // buộc SD phải dùng NGAY sau MobileSAM trong CÙNG 1 lượt lặp; ràng
    // buộc "dùng ngay" chỉ tồn tại trong CÁCH VIẾT VÒNG LẶP cũ (per-panel),
    // không phải ràng buộc kiến trúc thật.
    private suspend fun buildAutoFixMaskOrNull(rawPath: String, panelIndex: Int, outDir: File): File? {
        if (!faceHandDetector.isReady()) {
            log("  ⚠ Auto-fix mặt/tay: thiếu model MediaPipe trong assets (blaze_face_short_range.tflite / hand_landmarker.task) — bỏ qua")
            return null
        }
        return try {
            val bitmap = BitmapFactory.decodeFile(rawPath) ?: return null
            val regions = faceHandDetector.detectRegions(bitmap)
            if (regions.isEmpty()) { bitmap.recycle(); return null }

            val maskFile = File(outDir, "panel_%03d_mask.png".format(panelIndex))
            buildMaskFileRefined(rawPath, regions, bitmap.width, bitmap.height, maskFile, panelIndex, outDir)
            bitmap.recycle()
            log("  → Auto-fix: phát hiện ${regions.size} vùng mặt/tay (mask ${if (maskFixer.isReady()) "MobileSAM" else "rectangle+feather (SAM chưa sẵn sàng)"})")
            maskFile
        } catch (ex: Exception) {
            log("  ⚠ Auto-fix mặt/tay: build mask lỗi (${ex.message}) — bỏ qua panel này")
            null
        }
    }

    private suspend fun applyAutoFixInpaint(
        rawPath: String, maskFile: File, width: Int, height: Int, prompt: String, negativePrompt: String,
        stylePrompt: String, seed: Long, denoiseStrength: Float, panelIndex: Int, outDir: File
    ): String = try {
        imagePipeline.img2imgFix(
            panelIndex = panelIndex, prompt = prompt, negativePrompt = negativePrompt,
            stylePrompt = stylePrompt, inputPath = rawPath, maskPath = maskFile.absolutePath,
            denoiseStrength = denoiseStrength, width = width, height = height,
            steps = 20, cfgScale = 7f, seed = seed, ultrafix = false, ultrafixTile = 512,
            outDir = outDir
        ) { _, _ -> }
    } catch (ex: Exception) {
        log("  ⚠ Auto-fix mặt/tay lỗi (${ex.message}) — giữ ảnh gốc")
        rawPath
    }

    // Hàm GỐC — GIỮ NGUYÊN nguyên văn (nay chỉ là build mask + inpaint gọi
    // NỐI TIẾP nhau, tương đương 100% hành vi cũ), dùng cho nhánh
    // `upscaleApprovedPanelsInterleaved()` (mặc định) và bất kỳ chỗ nào
    // khác từng gọi hàm này trước mục 133.
    private suspend fun tryAutoFixFacesHands(
        rawPath: String, width: Int, height: Int, prompt: String, negativePrompt: String,
        stylePrompt: String, seed: Long, denoiseStrength: Float, panelIndex: Int, outDir: File
    ): String {
        val maskFile = buildAutoFixMaskOrNull(rawPath, panelIndex, outDir) ?: return rawPath
        return applyAutoFixInpaint(rawPath, maskFile, width, height, prompt, negativePrompt, stylePrompt, seed, denoiseStrength, panelIndex, outDir)
    }

    // Auto-fix vùng giao thoa hông/tay (Interaction Zone Fixer) — mục 74
    // TECHNICAL_STATUS.md, đề xuất từ bổ_sung_sd1_5.txt ("Điều bổ sung 2").
    // SỬA LẠI ở mục 92 (theo đúng cách cộng đồng SD dùng ADetailer — xem
    // TECHNICAL_STATUS.md mục 92): trước đây UNION hết mọi vùng lỗi (hông +
    // mọi điểm tay) thành 1 MASK DUY NHẤT, chạy img2imgFix() ĐÚNG 1 LẦN với
    // 1 prompt CHUNG cho cả vùng — nghĩa là vùng "hông chồng lấn" (cần sửa
    // giải phẫu da thịt) và vùng "tay đè lên người khác" (cần sửa đúng số
    // ngón/vị trí bàn tay) dùng CHUNG 1 prompt không đặc hiệu cho từng loại
    // lỗi — ADetailer (công cụ phổ biến nhất cộng đồng cho đúng bài toán
    // này) xử lý TỪNG vùng RIÊNG, mỗi vùng 1 prompt riêng phù hợp loại lỗi
    // đó, chạy TUẦN TỰ (vùng sau sửa trên ảnh ĐÃ sửa vùng trước, không phải
    // trên ảnh gốc) — bản sửa này làm đúng theo pattern đó.
    //
    // Xác định vùng giao thoa GIỮA 2+ nhân vật dựa trên bounding-box Hip
    // (khớp 8/11) + Knee (khớp 9/12) của TỪNG người trong [skeletonData]
    // (FloatArray phẳng, ĐÚNG format resolveSkeletonData() trả về — mục 33).
    //
    // Chỉ gọi khi numExpectedPersons >= 2. An toàn tuyệt đối nếu không có
    // giao thoa: trả về rawPath không đổi (return sớm ở nhiều điểm kiểm tra).
    //
    // GIỚI HẠN THẬT: vùng giao thoa là GIAO của bounding-box 2D (không phải
    // giao thoa 3D thật) — nếu 2 người đứng CẠNH nhau (không chồng bounding
    // box) thì đúng là không có gì cần sửa, hàm sẽ bỏ qua (không phải bug).
    // Xử lý TUẦN TỰ (không song song) — mỗi vùng thêm 1 lần chạy img2imgFix
    // đầy đủ (chậm hơn union 1 lần rõ rệt nếu có nhiều điểm tay), đánh đổi
    // lấy chất lượng sửa đúng loại lỗi hơn — CHƯA đo thời gian thật tăng
    // thêm bao nhiêu (không có thiết bị thật để test).
    // mục 94 TECHNICAL_STATUS.md — thêm characterOrder/allChars/settings/
    // worldRules để build được mô tả trang phục ĐÚNG nhân vật bị chạm khi
    // settings.autoTearClothingAtContactPoints bật (mặc định tắt, không
    // đổi hành vi cũ nếu user chưa bật). characterOrder PHẢI đúng thứ tự
    // ĐÃ DÙNG để dựng [skeletonData] (regionOrderRg cho nhánh Regional, hay
    // sceneChars cho nhánh khác) — sai thứ tự ở đây sẽ tra NHẦM nhân vật.
    // CHƯA BUILD-TEST.
    private suspend fun tryAutoFixInteractions(
        rawPath: String, width: Int, height: Int,
        prompt: String, negativePrompt: String, stylePrompt: String,
        seed: Long, denoiseStrength: Float, panelIndex: Int, outDir: File,
        skeletonData: FloatArray, numExpectedPersons: Int,
        characterOrder: List<String> = emptyList(), allChars: List<Character> = emptyList(),
        settings: GenerationSettings? = null, worldRules: String = "",
        // mục 207 TECHNICAL_STATUS.md — "SDXL chưa có Cascade/auto-fix
        // riêng" (user chỉ ra — đúng, lượt trước đánh giá SAI). Thêm cờ
        // TUỲ CHỌN (mặc định false, KHÔNG đổi hành vi 10 call site cũ đang
        // gọi hàm này cho SD1.5) — true CHỈ ở 2 call site MỚI (nhánh SDXL
        // trực tiếp của generatePanels()/regeneratePanel()). Caller PHẢI tự
        // gọi imagePipeline.loadSDSdxl() TRƯỚC khi truyền true (hàm này
        // không tự load, giống img2imgFix()/sdCtx không tự load ở đây).
        useSdxlFix: Boolean = false
    ): String {
        if (numExpectedPersons < 2 || skeletonData.isEmpty()) return rawPath
        return try {
            val floatsPerPerson = 18 * 4
            // mục 111 TECHNICAL_STATUS.md — giữ lại personIdx cùng Rect (trước
            // đây chỉ có Rect, mất chỉ số người) để SilhouetteFilter biết vẽ
            // trục xương của ĐÚNG những người đang chồng lấn, không phải đoán.
            val bboxList = mutableListOf<Pair<Int, Rect>>()
            for (pi in 0 until minOf(numExpectedPersons, skeletonData.size / floatsPerPerson)) {
                val base = pi * floatsPerPerson
                // Hip: joints 8 (right), 11 (left); Knee: joints 9, 12 (chuẩn OpenPose-18)
                val hipRx = skeletonData[base + 8 * 4];  val hipRy = skeletonData[base + 8 * 4 + 1]
                val hipLx = skeletonData[base + 11 * 4]; val hipLy = skeletonData[base + 11 * 4 + 1]
                val kneeRx = skeletonData[base + 9 * 4]; val kneeRy = skeletonData[base + 9 * 4 + 1]
                val kneeLx = skeletonData[base + 12 * 4]; val kneeLy = skeletonData[base + 12 * 4 + 1]
                val xs = listOf(hipRx, hipLx, kneeRx, kneeLx).filter { it > 0f }
                val ys = listOf(hipRy, hipLy, kneeRy, kneeLy).filter { it > 0f }
                if (xs.isEmpty() || ys.isEmpty()) continue
                // Toạ độ đã normalize 0..1 bởi PoseRetargeter — nhân lên pixel
                val l = (xs.min() * width).toInt().coerceAtLeast(0)
                val r = (xs.max() * width).toInt().coerceAtMost(width)
                val t = (ys.min() * height).toInt().coerceAtLeast(0)
                val b = (ys.max() * height).toInt().coerceAtMost(height)
                if (r > l && b > t) bboxList.add(pi to Rect(l, t, r, b))
            }
            if (bboxList.size < 2) return rawPath

            // Giao (intersection) của TẤT CẢ bounding-box người trong panel
            var intersect = bboxList[0].second
            for (i in 1 until bboxList.size) {
                val b = bboxList[i].second
                intersect = Rect(
                    maxOf(intersect.left, b.left), maxOf(intersect.top, b.top),
                    minOf(intersect.right, b.right), minOf(intersect.bottom, b.bottom)
                )
                if (intersect.isEmpty) intersect = Rect() // không chồng lấn thật — bỏ vùng hông, vẫn xét tiếp vùng tay
            }
            // Người thật sự đóng góp vào vùng chồng lấn — dùng để vẽ vách
            // ngăn SilhouetteFilter đúng người, không phải toàn bộ bboxList.
            val overlappingPersonIdxs = bboxList.filter { !intersect.isEmpty && Rect.intersects(it.second, intersect) }.map { it.first }

            // mục 79/80 — vùng cổ tay đè lên thân người khác (case Hip-Knee
            // KHÔNG chồng lấn nhưng 1 tay vươn tới ngực/vai người kia — vd vỗ
            // vai, đặt tay lên ngực khi ôm nghiêng). Dùng CHUNG skeletonData
            // đã có, KHÔNG inference thêm. mục 94 — giờ trả về CẢ personIdx
            // của tay VÀ của thân bị chạm (HandOverBodyContact), không chỉ Rect.
            val handOverlaps = faceHandDetector.detectHandOverBodyOverlaps(skeletonData, numExpectedPersons, width, height)
            if (handOverlaps.isNotEmpty()) log("  → Hand-Over-Body: phát hiện ${handOverlaps.size} điểm tay đè lên thân người khác")

            // mục 92 TECHNICAL_STATUS.md — xử lý TỪNG vùng RIÊNG, tuần tự,
            // mỗi vùng 1 prompt đặc hiệu đúng loại lỗi (thay vì union 1 mask
            // + 1 prompt chung như trước). Danh sách (rect, loại) — vùng hông
            // xử lý TRƯỚC (nếu có, ảnh hưởng bố cục lớn hơn), rồi tới từng
            // điểm tay (thường là chi tiết nhỏ cục bộ hơn).
            // mục 94 — thêm field `bodyCharacterName` (tên nhân vật SỞ HỮU
            // thân bị chạm — không phải người có tay chạm) để build prompt
            // rách vải ĐÚNG trang phục của người đó, null nếu không tra
            // được (characterOrder rỗng/lệch — an toàn, chỉ bỏ qua phần
            // rách vải, KHÔNG chặn phần sửa giải phẫu tay vẫn chạy bình
            // thường như trước mục 94).
            data class FixRegion(val rect: Rect, val kind: String, val bodyCharacterName: String? = null, val silhouettePersonIdxs: List<Int> = emptyList(), val involvedNames: List<String> = emptyList())
            val regions = mutableListOf<FixRegion>()
            if (!intersect.isEmpty) {
                val pw = (intersect.width() * 0.2f).toInt()
                val ph = (intersect.height() * 0.2f).toInt()
                regions.add(FixRegion(Rect(
                    (intersect.left - pw).coerceAtLeast(0), (intersect.top - ph).coerceAtLeast(0),
                    (intersect.right + pw).coerceAtMost(width), (intersect.bottom + ph).coerceAtMost(height)
                ), "hip_overlap", silhouettePersonIdxs = overlappingPersonIdxs))
            }
            handOverlaps.forEach { contact ->
                regions.add(FixRegion(contact.rect, "hand_over_body", characterOrder.getOrNull(contact.bodyPersonIdx)))
            }
            // mục 227 TECHNICAL_STATUS.md — điểm chạm TỔNG QUÁT ngoài hông/tay
            // (khuỷu tay, đầu gối, bàn chân, đầu, tay chạm cổ/đầu). Dùng
            // ĐÚNG khung xương `skeletonData` đã có, không inference thêm.
            // `existingRects` để KHÔNG thêm vùng trùng với hip_overlap /
            // hand_over_body ở trên; `maxRegions` chặn số lượt img2img thêm.
            // Mặc định `settings == null` (call site cũ không truyền) -> bỏ
            // qua, không đổi hành vi những call site đó.
            if (settings?.autoFixLimbContacts == true) {
                // mục 232 — nếu có model MiDaS: thay z của khung xương bằng độ sâu THẬT đọc từ
                // ẢNH ĐÃ SINH, để ContactDetector loại điểm chạm "giả" (chi nằm trong hộp
                // thân người kia trên ảnh 2D nhưng ở TRƯỚC/SAU xa). Chỉ dùng cho dò điểm chạm
                // mở rộng — không đổi khung xương nào khác.
                val skForContacts = if (settings?.useDepthForContacts == true) {
                    try {
                        val est = depthEstimator
                        val depth = if (est.isReady()) est.estimate(rawPath) else null
                        if (depth != null) est.applyDepth(depth, skeletonData) else skeletonData
                    } catch (ex: Throwable) {
                        log("  ⚠ Độ sâu MiDaS lỗi (${ex.message}) — dò điểm chạm bằng hình học 2D")
                        skeletonData
                    }
                } else skeletonData
                val limbContacts = ContactDetector.detect(
                    skForContacts, numExpectedPersons, width, height,
                    existingRects = regions.map { it.rect },
                    maxRegions = (settings?.maxContactFixRegions ?: 4).coerceIn(0, 8)
                )
                limbContacts.forEach { c ->
                    regions.add(FixRegion(c.rect, c.kind, characterOrder.getOrNull(c.targetIdx),
                        involvedNames = listOfNotNull(characterOrder.getOrNull(c.actorIdx), characterOrder.getOrNull(c.targetIdx))))
                }
                if (limbContacts.isNotEmpty()) {
                    log("  → Điểm chạm mở rộng: ${limbContacts.size} vùng (" +
                        limbContacts.joinToString { it.kind } + ")")
                }
            }
            if (regions.isEmpty()) return rawPath

            // mục 94 — LLMParser riêng cho việc dịch mô tả rách vải, khởi
            // tạo LƯỜI (chỉ khi thật sự cần: bật setting + có ít nhất 1
            // region hand_over_body tra được tên nhân vật) — tránh phí nạp
            // model LLM khi tính năng đang tắt (mặc định) hoặc không dùng
            // được (characterOrder rỗng).
            val tearEnabled = settings?.autoTearClothingAtContactPoints == true
            var tearParser: LLMParser? = null
            if (tearEnabled && regions.any { it.kind == "hand_over_body" && it.bodyCharacterName != null }) {
                try {
                    // mục 114 TECHNICAL_STATUS.md — nGpuLayers=0 hardcode ép
                    // CPU dù máy có GPU/NPU khả dụng (comment dòng 941-943 xác
                    // nhận đây LÀ bug, không phải cố ý — 6/7 lần khởi tạo
                    // LLMParser trong file này từng lệch khỏi đúng ý định).
                    tearParser = LLMParser(settings!!.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
                    tearParser.init()
                } catch (e: Exception) {
                    log("  ⚠ Không khởi tạo được LLM cho mô tả rách vải (${e.message}) — bỏ qua phần này, vẫn tiếp tục sửa giải phẫu")
                    tearParser = null
                }
            }

            var currentPath = rawPath
            // mục 130 TECHNICAL_STATUS.md — user hỏi "LLM dùng trong lúc
            // sinh ảnh có tuần tự hay chen nhau" dẫn tới phát hiện RÒ BỘ
            // NHỚ NATIVE THẬT: tearParser được init() ở trên nhưng KHÔNG
            // hề có free() nào trong toàn bộ hàm — mỗi lần tính năng
            // autoTearClothingAtContactPoints kích hoạt sẽ nạp 1 model LLM
            // MỚI vào RAM native và KHÔNG BAO GIỜ giải phóng cho tới khi
            // app bị kill, tích luỹ qua từng panel trong 1 chương dài. Bọc
            // try/finally NGAY TẠI ĐÂY (không phải try/catch NGOÀI ở dưới
            // — catch đó chỉ log rồi return, KHÔNG chạy được cleanup cho
            // biến cục bộ tearParser) để free() chạy ở MỌI đường thoát:
            // vòng lặp xong bình thường LẪN có exception giữa chừng.
            try {
                for ((idx, region) in regions.withIndex()) {
                    log("  → Auto-fix giao thoa [${idx + 1}/${regions.size}, ${region.kind}]: vùng ${region.rect.width()}×${region.rect.height()}px")

                    val maskFile = File(outDir, "panel_%03d_interaction_mask_%d.png".format(panelIndex, idx))
                    buildInteractionMaskFile(region.rect, width, height, maskFile,
                        skeletonData = skeletonData, silhouettePersonIdxs = region.silhouettePersonIdxs)

                    // Prompt ĐẶC HIỆU theo loại lỗi — khác nhau THẬT SỰ giữa 2
                    // loại, không dùng chung 1 prompt tổng quát như bản trước.
                    var (regionPrompt, regionNeg) = when (region.kind) {
                        "hip_overlap" -> Pair(
                            "seamless skin contact, tight embrace, perfect anatomy, " +
                                "clear body silhouette separation, distinct limbs, $prompt",
                            "extra limbs, fused bodies, merged skin, deformed anatomy, " +
                                "conjoined bodies, $negativePrompt"
                        )
                        // mục 227 — điểm chạm mở rộng (khuỷu/gối/chân/đầu/tay-cổ):
                        // prompt CỤC BỘ theo đúng loại tiếp xúc, xem ContactDetector.promptFor().
                        in ContactDetector.LIMB_KINDS ->
                            ContactDetector.promptFor(region.kind, prompt, negativePrompt)
                        else -> Pair( // "hand_over_body"
                            "natural hand placement, five fingers, correct finger count, " +
                                "hand resting naturally, clear hand silhouette, detailed hand anatomy, $prompt",
                            "extra fingers, missing fingers, merged hand, hand fused into body, " +
                                "deformed hand, mutated hand, $negativePrompt"
                        )
                    }

                    // mục 94 — GHÉP THÊM mô tả rách/xộc xệch trang phục vào ĐÚNG
                    // prompt hand_over_body ở trên (KHÔNG tạo lần img2imgFix
                    // riêng cho cùng 1 vùng pixel — mục 92 đã ghi rõ xử lý tuần
                    // tự trên CÙNG vùng nhiều lần có rủi ro dồn lỗi, ghép chung
                    // 1 lần an toàn hơn). Dùng đúng anchorPrompt (trang phục
                    // thật) của NHÂN VẬT SỞ HỮU thân bị chạm, dịch qua LLM theo
                    // đúng PromptStyle checkpoint đang active (mục 93) — không
                    // hardcode tiếng Anh cố định vì trang phục khác nhau từng
                    // truyện/nhân vật (đã bàn kỹ lý do ở lượt hỏi trước mục 94).
                    if (region.kind == "hand_over_body" && tearEnabled && tearParser != null && region.bodyCharacterName != null) {
                        val bodyChar = allChars.find { it.name == region.bodyCharacterName }
                        if (bodyChar != null) {
                            try {
                                val tearDesc = "trang phục của nhân vật (${bodyChar.anchorPrompt}) bị nắm/kéo tại điểm " +
                                    "tiếp xúc với tay đối phương trong lúc vật lộn — vải nhăn nhúm, xộc xệch, có thể " +
                                    "hơi rách ở đúng điểm bị nắm, KHÔNG mô tả gì khác ngoài trạng thái vải tại điểm này"
                                val tearResult = tearParser.translateStagePrompt(
                                    tearDesc, PromptStage.INPAINT, worldRules, stylePrompt,
                                    promptStyle = settings?.let { resolvePromptStyle(it) } ?: PromptStyle.TAG_BASED
                                )
                                regionPrompt = "$regionPrompt, ${tearResult.positive}"
                                regionNeg = "$regionNeg, ${tearResult.negative}"
                            } catch (e: Exception) {
                                log("  ⚠ Dịch mô tả rách vải lỗi (${e.message}) — bỏ qua phần này cho vùng này")
                            }
                        }
                    }

                    // mục 237 TECHNICAL_STATUS.md — "ONLY MASKED": vùng nhỏ được cắt + lề, phóng lên độ
                    // phân giải gốc của model, vẽ, thu nhỏ rồi dán lại theo mask. Lỗi ở bất kỳ bước nào
                    // -> log rồi rơi về cách vẽ cả khung ngay bên dưới (hành vi cũ) cho đúng vùng này.
                    val nativeSide = (minOf(width, height, if (useSdxlFix) 1024 else 768) / 8) * 8
                    val cropRect = if (settings?.autoFixCropInpaint == true)
                        InpaintCompose.planCrop(region.rect, width, height, nativeSide) else null
                    if (cropRect != null) {
                        // mục 238 TECHNICAL_STATUS.md — PROMPT CHỈ VỀ VÙNG ĐƯỢC VẼ (khuyến nghị cộng đồng: prompt
                        // inpaint chỉ nên mô tả phần trong mask). Crop chỉ thấy 1 phần cảnh nên prompt cả cảnh nhắc
                        // người/vật không có trong crop. Với điểm chạm chi/đầu: chỉ mô tả loại chạm + hai nhân vật
                        // liên quan (anchorPrompt giữ màu tóc/trang phục); phong cách vẫn đi qua `stylePrompt`.
                        var cropPrompt = regionPrompt
                        var cropNeg = regionNeg
                        if (settings?.autoFixRegionOnlyPrompt == true && region.kind in ContactDetector.LIMB_KINDS &&
                            region.involvedNames.isNotEmpty()) {
                            val involved = region.involvedNames.distinct().mapNotNull { n -> allChars.find { it.name == n } }
                            if (involved.isNotEmpty()) {
                                val localPair = ContactDetector.promptFor(
                                    region.kind,
                                    involved.joinToString(", ") { it.anchorPrompt },
                                    involved.joinToString(", ") { it.negativePrompt } + ", " + negativePrompt
                                )
                                cropPrompt = localPair.first; cropNeg = localPair.second
                            }
                        }
                        val cropped = try {
                            inpaintRegionCropped(
                                currentPath, region.rect, cropRect, width, height, nativeSide,
                                skeletonData, region.silhouettePersonIdxs, cropPrompt, cropNeg,
                                stylePrompt, denoiseStrength, seed, panelIndex, idx, outDir, useSdxlFix,
                                colorMatch = if (settings?.inpaintColorMatch == true) 0.5f else 0f
                            )
                        } catch (ex: Exception) {
                            log("  ⚠ Vẽ vùng ${idx + 1} kiểu cắt-phóng-dán lỗi (${ex.message}) — dùng cách vẽ cả khung")
                            null
                        }
                        if (cropped != null) {
                            log("  → Vùng ${idx + 1} vẽ ở ${nativeSide}² từ crop ${cropRect.width()}px (phóng %.1fx)".format(nativeSide.toFloat() / cropRect.width()))
                            currentPath = cropped
                            continue
                        }
                    }

                    val fullFrameResult = if (useSdxlFix) {
                        // mục 207 TECHNICAL_STATUS.md — nhánh SDXL, caller
                        // (call site mới ở generatePanels()/regeneratePanel())
                        // đã gọi imagePipeline.loadSDSdxl() TRƯỚC khi tới đây.
                        imagePipeline.img2imgFixSdxl(
                            panelIndex = panelIndex, prompt = regionPrompt, negativePrompt = regionNeg,
                            stylePrompt = stylePrompt, inputPath = currentPath, maskPath = maskFile.absolutePath,
                            denoiseStrength = denoiseStrength, width = width, height = height,
                            steps = 25, cfgScale = 7.5f, seed = seed,
                            outDir = outDir
                        ) { _, _ -> }
                    } else {
                        imagePipeline.img2imgFix(
                            panelIndex = panelIndex, prompt = regionPrompt, negativePrompt = regionNeg,
                            stylePrompt = stylePrompt, inputPath = currentPath, maskPath = maskFile.absolutePath,
                            denoiseStrength = denoiseStrength, width = width, height = height,
                            steps = 25, cfgScale = 7.5f, seed = seed, ultrafix = false, ultrafixTile = 512,
                            outDir = outDir
                        ) { _, _ -> }
                    }
                    // mục 237 — dán pixel gốc ngoài mask: tránh sai lệch cộng dồn do mỗi lượt đi qua VAE.
                    currentPath = if (settings?.autoFixPasteBack == true)
                        pasteBackFullFrame(currentPath, fullFrameResult, maskFile.absolutePath,
                            File(outDir, "panel_%03d_pasteback.png".format(panelIndex)))
                    else fullFrameResult
                }
            } finally {
                tearParser?.free()
            }
            currentPath
        } catch (ex: Exception) {
            log("  ⚠ Auto-fix giao thoa lỗi (${ex.message}) — giữ ảnh gốc")
            rawPath
        }
    }


    // mục 240 TECHNICAL_STATUS.md — biểu cảm HIỆU LỰC của 1 nhân vật trong 1 panel: ghi đè của người dùng > biểu cảm
    // riêng từng nhân vật do LLM > biểu cảm chung của cảnh. "neutral"/không có -> null (không cần ảnh tham chiếu riêng).
    private fun expressionKeyFor(panel: Panel, charName: String): String? {
        val manual = panel.overrideSettings?.characterExpressionOverrides?.get(charName)
        if (manual != null) return manual.takeIf { it != "neutral" } // người dùng chỉnh tay luôn thắng mọi tín hiệu tự động
        var key = panel.scene.characterExpressions[charName] ?: panel.scene.expression
        // mục 241 — TÍN HIỆU TỪ THOẠI: người đang HÉT (bubble kiểu SHOUT) mà biểu cảm là trung tính/giận/quyết tâm/đe doạ thì
        // mặt phải đang há miệng hét. Quy tắc thuần quyết định, không phụ thuộc LLM nhỏ chọn đúng hay không.
        val shouts = panel.scene.dialogue.any { it.type == BubbleType.SHOUT && it.characterName.equals(charName, ignoreCase = true) }
        if (shouts && (key == null || key == "neutral" || key == "angry" || key == "determined" || key == "menacing")) key = "shouting"
        return key?.takeIf { it != "neutral" }
    }

    /** Bản đồ biểu cảm HIỆU LỰC từng nhân vật của panel (dùng cho cascade/prompt chính) — cùng quy tắc với expressionKeyFor. */
    private fun effectiveExpressionMap(panel: Panel): Map<String, String> =
        panel.scene.characters.mapNotNull { n -> expressionKeyFor(panel, n)?.let { n to it } }.toMap()

    // mục 240 TECHNICAL_STATUS.md — TẠO 1 ẢNH TRONG BẢNG BIỂU CẢM của nhân vật: lấy chính ảnh anchor, dò mặt bằng
    // YOLOv8-pose (cùng PoseExtractor), vẽ lại CHỈ vùng đặc trưng mặt với biểu cảm [key] qua đường "only masked"
    // (inpaintRegionCropped, mục 237), giữ nguyên tóc/nền/trang phục. Khuôn mẫu: generateTornReferenceImage().
    // Trả đường dẫn ảnh tạm (caller sao vào thư mục truyện) hoặc null — KHÔNG throw.
    //
    // GIỚI HẠN THẬT: cần anchorImagePath có mặt nhìn rõ (mũi + ít nhất 1 mắt) để YOLOv8-pose dò; ảnh không có người/
    // quay lưng -> null. Không dùng IP-Adapter nên có thể lệch nhẹ khuôn mặt so với anchor — người dùng nên xem ảnh
    // trong màn hình Biểu cảm rồi xoá nếu không đạt. CHƯA build-test.
    suspend fun generateExpressionAnchorImage(
        character: Character, story: Story, key: String, settings: GenerationSettings, outDir: File,
        realisticOverride: Boolean? = null // mục 243: ép bộ từ vựng (A/B); null = theo cài đặt hiện tại
    ): String? = withContext(Dispatchers.IO) {
        val srcPath = character.anchorImagePath?.takeIf { File(it).exists() } ?: return@withContext null
        try {
            val exprTag = LLMParser.resolveExpressionTag(
                key, resolvePromptStyle(settings), realisticOverride ?: ExpressionRegistry.realisticDomain
            ) ?: return@withContext null
            if (!poseExtractor.isReady()) { log("  ⚠ Bảng biểu cảm: YOLOv8-pose chưa sẵn sàng — không dò được mặt"); return@withContext null }
            // mục 245 — luồng theo yêu cầu: img2imgFix KHÔNG tự nạp model (loadSD idempotent nên gọi lại vô hại).
            imagePipeline.loadSD(storyManager.modelsDir.absolutePath,
                resolveModelIdForCharacter(story, character.name, settings.sdModelId), settings.useOpenCL,
                storyManager.embeddingsDir(story.id).absolutePath, settings.useNpu, runtimeOptimizer.detectQnnSoc()?.socModel ?: "")
            val bmp = BitmapFactory.decodeFile(srcPath) ?: return@withContext null
            val w = bmp.width; val h = bmp.height
            val people = poseExtractor.extractFromImage(bmp)
            bmp.recycle()
            if (people.isNullOrEmpty()) { log("  ⚠ Bảng biểu cảm: không thấy người trong ảnh anchor của ${character.name}"); return@withContext null }
            // Dựng mảng khung xương (x,y,z,visible) cho TỪNG người rồi lấy mặt lớn nhất.
            val fpp = 18 * 4
            val sk = FloatArray(people.size * fpp)
            people.forEachIndexed { pi, person ->
                for (j in 0 until 18) {
                    val kp = person.getOrNull(j)
                    val o = pi * fpp + j * 4
                    if (kp != null) { sk[o] = kp.x; sk[o + 1] = kp.y; sk[o + 2] = 0f; sk[o + 3] = if (kp.visible) 1f else 0f }
                }
            }
            val face = ExpressionFace.faceBoxes(sk, people.size, w, h).maxByOrNull { it.headWidthPx }
                ?: run { log("  ⚠ Bảng biểu cảm: không dò được mặt rõ trong ảnh anchor của ${character.name}"); return@withContext null }
            val nativeSide = (minOf(w, h, 768) / 8) * 8
            val cropRect = InpaintCompose.planCrop(face.rect, w, h, nativeSide, minGain = 1.0f) ?: return@withContext null
            val intensity = ExpressionRegistry.intensityOf(key)
            val denoise = (0.45f + 0.05f * (intensity - 2)).coerceIn(0.35f, 0.6f)
            val anchorPrompt = "$exprTag, detailed face, " + listOfNotNull(character.embeddingTrigger, character.anchorPrompt).filter { it.isNotBlank() }.joinToString(", ")
            val anchorNeg = "deformed face, asymmetrical eyes, extra eyes, bad mouth, " +
                (if (settings.imageStyle == ImageStyle.REALISTIC) ExpressionLibrary.REALISTIC_FACE_NEGATIVE + ", " else "") + character.negativePrompt
            // Mỗi lần vẽ ghi ra cùng tên file -> sao lưu kết quả lần 1 trước khi thử lần 2 (cổng danh tính, mục 246).
            suspend fun attempt(d: Float, idScale: Float): String = inpaintRegionCropped(
                srcPath, face.rect, cropRect, w, h, nativeSide, sk, emptyList(), anchorPrompt, anchorNeg,
                settings.imageStyle.stylePrompt, d, character.seed, 9700, 0, outDir, false, oval = true,
                colorMatch = if (settings.inpaintColorMatch) 0.5f else 0f,
                // ảnh anchor chính là đầu vào nên dùng nó làm tham chiếu danh tính (giữ mặt khi đổi biểu cảm)
                identityRefPath = if (settings.expressionFaceIdentity) srcPath else null,
                identityPersonIdx = face.personIdx, identityScale = idScale
            )
            var result = attempt(denoise, settings.expressionIdentityScale)
            val eyes = eyePair(sk, face.personIdx)
            val minSim = settings.expressionIdentityMinSim
            if (minSim > 0f && eyes != null && identityGuard.isReady()) {
                val sim = identityGuard.similarity(srcPath, result, eyes[0], eyes[1], eyes[2], eyes[3], outDir)
                log("  ◦ Độ giống danh tính ${character.name} · \"$key\" (ArcFace, anchor/biểu cảm): " + (sim?.let { "%.2f".format(it) } ?: "không đo được") + " · ngưỡng %.2f".format(minSim))
                if (sim != null && sim < minSim) {
                    val first = File(outDir, "panel_9700_firstattempt.png")
                    File(result).copyTo(first, overwrite = true)
                    val retry = attempt(denoise * 0.75f, (settings.expressionIdentityScale + 0.2f).coerceAtMost(1.2f))
                    val sim2 = identityGuard.similarity(srcPath, retry, eyes[0], eyes[1], eyes[2], eyes[3], outDir)
                    log("  ◦ Thử lại với denoise thấp hơn: " + (sim2?.let { "%.2f".format(it) } ?: "không đo được"))
                    if (sim2 == null || sim2 < minSim) {
                        log("  ⚠ Ảnh biểu cảm \"$key\" của ${character.name} lệch danh tính sau cả 2 lần vẽ — KHÔNG lưu vào bảng", LogLevel.WARN)
                        return@withContext null
                    }
                    result = retry
                }
            }
            result

        } catch (ex: Exception) {
            log("  ⚠ generateExpressionAnchorImage lỗi (${ex.message})")
            null
        }
    }

    // ───────────────────────── mục 244 TECHNICAL_STATUS.md — ẢNH LÀM KHUNG HÌNH CHO MODEL VIDEO ─────────────────────────

    /** Kết quả phân tích 1 panel làm khung hình đầu cho video. */
    data class PanelVideoInfo(
        val panel: Panel, val imagePath: String, val imgW: Int, val imgH: Int, val personCount: Int,
        val faces: List<ExpressionFace.FaceBox>, val crop: VideoPrep.Crop, val issues: List<VideoPrep.Issue>
    )

    private fun imageSize(path: String): Pair<Int, Int> {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        return o.outWidth to o.outHeight
    }

    // Ảnh làm khung đầu: bản đã upscale nếu có (nét hơn), nếu không thì ảnh gốc. ĐỀU là ảnh SẠCH — bóng thoại chỉ được vẽ lúc xuất PDF/CBZ.
    private fun videoBasePath(panel: Panel): String? =
        (panel.upscaledPath?.takeIf { File(it).exists() } ?: panel.imagePath?.takeIf { File(it).exists() })

    private fun analyzePanelForVideo(panel: Panel, story: Story, chapterNumber: Int?, target: VideoTarget): PanelVideoInfo? {
        val path = videoBasePath(panel) ?: return null
        val (w, h) = imageSize(path)
        if (w <= 0 || h <= 0) return null
        val allChars = applyActiveAnchorVersion(story.characters, chapterNumber)
        val order = stableCharacterOrder(panel.scene.characters, allChars)
        val ov = panel.overrideSettings
        val faces = try {
            val sk = resolveSkeletonData(ov?.poseTemplate ?: panel.suggestedPoseTemplate ?: guessPoseTemplate(panel),
                ov?.poseAngle ?: panel.suggestedPoseAngle, panel.scene, story, order, chapterNumber = chapterNumber)
            if (sk.isEmpty()) emptyList() else ExpressionFace.faceBoxes(sk, order.size, w, h)
        } catch (ex: Exception) { emptyList() }
        // Vùng cần giữ trong khung đích: hộp "đặc trưng mặt" nới ra phủ cả đầu + chừa khoảng trống phía trên.
        val keep = faces.map { f ->
            val pad = (0.6f * f.headWidthPx).toInt()
            Rect((f.rect.left - pad).coerceAtLeast(0), (f.rect.top - pad).coerceAtLeast(0),
                (f.rect.right + pad).coerceAtMost(w), (f.rect.bottom + pad).coerceAtMost(h))
        }
        val crop = VideoPrep.cropForAspect(w, h, target.w, target.h, keep)
        val wantsEnd = ov?.videoEndExpressions?.isNotEmpty() == true
        val hasEnd = ov?.videoEndFramePath?.let { File(it).exists() } == true
        val issues = VideoPrep.readiness(
            w, h, panel.scene.characters.size, faces.map { VideoPrep.FaceInfo(it.headWidthPx, it.threeQuarter) },
            panel.qualityGatePassed, crop.containsAll, wantsEnd, hasEnd
        )
        return PanelVideoInfo(panel, path, w, h, panel.scene.characters.size, faces, crop, issues)
    }

    /** Kiểm tra độ sẵn sàng của từng panel làm khung hình đầu cho model video. */
    suspend fun videoReadiness(chapter: Chapter, story: Story, target: VideoTarget): List<PanelVideoInfo> =
        withContext(Dispatchers.IO) { chapter.panels.mapNotNull { analyzePanelForVideo(it, story, chapter.chapterNumber, target) } }

    // Tạo KHUNG KẾT (biểu cảm kết) cho First-Last-Frame: vẽ lại CHỈ mặt trên chính ảnh khung đầu, cùng seed ⇒ bố cục/góc máy/ánh sáng
    // giống hệt (đúng khuyến nghị "chỉ MỘT biến đổi lớn giữa hai khung"). Trả đường dẫn ảnh khung kết hoặc null.
    suspend fun generateVideoEndFrame(
        panel: Panel, story: Story, chapterNumber: Int?, settings: GenerationSettings, outDir: File
    ): String? = withContext(Dispatchers.IO) {
        val forced = panel.overrideSettings?.videoEndExpressions
        if (forced.isNullOrEmpty()) return@withContext null
        val base = videoBasePath(panel) ?: return@withContext null
        try {
            val allChars = applyActiveAnchorVersion(story.characters, chapterNumber)
            val eff = resolveEffective(panel, settings)
            val work = 8000 + panel.index // chỉ số tạm riêng: tránh ghi đè panel_NNN_cropfix.png của ảnh chính
            val result = tryExpressionFacePass(base, panel, story, settings, eff, allChars, chapterNumber, outDir, forced = forced, workIndex = work)
            if (result == base) { log("  ℹ Khung kết: không vẽ lại được mặt nào (thiếu khung xương/mặt nhỏ/quay lưng) — panel ${panel.index + 1}"); null }
            else {
                val dest = File(outDir, "panel_%03d_videoend.png".format(panel.index))
                File(result).copyTo(dest, overwrite = true)
                dest.absolutePath
            }
        } catch (ex: Exception) {
            log("  ⚠ Tạo khung kết lỗi (${ex.message})", LogLevel.WARN)
            null
        }
    }

    // Xuất GÓI ẢNH CHO MODEL VIDEO: mỗi panel một thư mục {start.png, end.png?, prompt.txt, dialogue.txt?, info.json}, kèm pack.json + README.
    suspend fun exportVideoPack(
        chapter: Chapter, story: Story, outDir: File, fileBaseName: String, target: VideoTarget,
        speech: Boolean = false,   // mục 248: kèm âm thanh TTS từng câu thoại
        remote: RemoteEndpointConfig? = null   // mục 249: khác null -> clip.mp4 từng panel qua server từ xa (SVD)
    ): String = withContext(Dispatchers.IO) {
        val infos = chapter.panels.mapNotNull { analyzePanelForVideo(it, story, chapter.chapterNumber, target) }
        if (infos.isEmpty()) throw IllegalStateException("Không có panel nào có ảnh để làm gói video")
        val safe = fileBaseName.replace(Regex("[/\\\\:*?\"<>|]"), "_").take(100).ifBlank { "chapter" }
        val out = File(outDir, "${safe}_i2v_pack.zip")
        val gson = com.google.gson.GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create()
        val summary = ArrayList<Map<String, Any?>>()

        // mục 248 — lồng tiếng: tổng hợp TRƯỚC khi mở zip (TTS chạy trên luồng chính; cần ngữ cảnh ứng dụng). Lỗi/thiếu giọng
        // -> không có clip, gói vẫn xuất bình thường. File tạm dọn sau khi đóng zip.
        val ttsDir = File(outDir, "${safe}_tts_tmp")
        val clipsByPanel: Map<Int, List<DialogueAudio.Clip>> = if (!speech) emptyMap() else try {
            DialogueAudio.synthesize(storyManager.appContext, DialogueAudio.plan(infos.map { it.panel }), ttsDir,
                log = { msg -> log(msg) }).groupBy { it.item.panelIndex }
        } catch (ex: Exception) {
            log("  ⚠ Lồng tiếng lỗi (${ex.message}) — gói xuất không kèm âm thanh", LogLevel.WARN)
            emptyMap()
        }

        // mục 249 — clip chuyển động trên server từ xa; lỗi một panel không làm hỏng gói (ghi cảnh báo, bỏ clip của panel đó)
        val remoteClient = if (remote != null && remote.enabled) RemoteGenerationClient(remote) else null
        var remoteStopped = false   // server không hỗ trợ video -> dừng thử các panel còn lại

        fun pngBytes(path: String, info: PanelVideoInfo): ByteArray? {
            val src = BitmapFactory.decodeFile(path) ?: return null
            val sized = if (src.width != info.imgW || src.height != info.imgH) Bitmap.createScaledBitmap(src, info.imgW, info.imgH, true) else src
            if (sized !== src) src.recycle()
            val r = info.crop.rect
            val cropped = Bitmap.createBitmap(sized, r.left, r.top, r.width(), r.height())
            if (cropped !== sized) sized.recycle()
            val finalBmp = if (target.w > 0 && (cropped.width != target.w || cropped.height != target.h))
                Bitmap.createScaledBitmap(cropped, target.w, target.h, true).also { if (it !== cropped) cropped.recycle() } else cropped
            val bos = java.io.ByteArrayOutputStream()
            finalBmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
            finalBmp.recycle()
            return bos.toByteArray()
        }

        java.util.zip.ZipOutputStream(FileOutputStream(out)).use { zip ->
            fun put(name: String, bytes: ByteArray) { zip.putNextEntry(java.util.zip.ZipEntry(name)); zip.write(bytes); zip.closeEntry() }
            infos.forEach { info ->
                val p = info.panel
                val dir = "panel_%02d/".format(p.index + 1)
                val ov = p.overrideSettings
                val startKeys = p.scene.characters.mapNotNull { n -> expressionKeyFor(p, n)?.let { n to it } }.toMap()
                val endKeys = ov?.videoEndExpressions.orEmpty()
                val endPath = ov?.videoEndFramePath?.takeIf { File(it).exists() }
                val startPng = pngBytes(info.imagePath, info)
                if (startPng == null) { summary += mapOf("panel" to p.index + 1, "error" to "không đọc được ảnh"); return@forEach }
                put(dir + "start.png", startPng)
                val endPng = endPath?.let { pngBytes(it, info) }
                if (endPng != null) put(dir + "end.png", endPng)
                val speakers = p.scene.dialogue.map { it.characterName }.toSet()
                val (pos, neg) = VideoPrep.buildPrompt(
                    p.scene.characters, startKeys, endKeys, speakers, hasEndFrame = endPng != null,
                    faceFocus = info.faces.isNotEmpty() && info.personCount <= 2
                )
                put(dir + "prompt.txt", ("POSITIVE:\n$pos\n\nNEGATIVE:\n$neg\n").toByteArray(Charsets.UTF_8))
                if (p.scene.dialogue.isNotEmpty())
                    put(dir + "dialogue.txt", p.scene.dialogue.joinToString("\n") { "${it.characterName}: ${it.text}" }.toByteArray(Charsets.UTF_8))
                val meta = linkedMapOf<String, Any?>(
                    "panel" to p.index + 1, "characters" to p.scene.characters, "startExpressions" to startKeys,
                    "endExpressions" to endKeys.takeIf { endPng != null }, "sourceSize" to listOf(info.imgW, info.imgH),
                    "target" to target.name, "crop" to listOf(info.crop.rect.left, info.crop.rect.top, info.crop.rect.right, info.crop.rect.bottom),
                    "cropKeepsFaces" to info.crop.containsAll,
                    "issues" to info.issues.map { it.code }
                )
                if (remoteClient != null && !remoteStopped) {
                    try {
                        val clip = remoteClient.generateVideo(startPng)
                        put(dir + "clip.mp4", clip)
                        meta["remoteClip"] = mapOf("file" to "clip.mp4", "model" to "svd", "frames" to RemoteVideo.DEFAULT_FRAMES,
                            "fps" to RemoteVideo.DEFAULT_FPS, "bytes" to clip.size)
                        log("  Clip chuyển động panel ${p.index + 1}: ${clip.size / 1024} KB")
                    } catch (ex: RemoteGenerationClient.RemoteVideoException) {
                        remoteStopped = true
                        log("  ⚠ Clip chuyển động dừng: ${ex.message}", LogLevel.WARN)
                    } catch (ex: Exception) {
                        log("  ⚠ Clip chuyển động panel ${p.index + 1} lỗi (${ex.message}) — gói vẫn có ảnh", LogLevel.WARN)
                    }
                }
                clipsByPanel[p.index].orEmpty().forEach { clip ->
                    put(dir + clip.item.fileName, clip.file.readBytes())
                }
                if (clipsByPanel[p.index].orEmpty().isNotEmpty()) {
                    meta["dialogueAudio"] = clipsByPanel[p.index].orEmpty().map {
                        mapOf("file" to it.item.fileName, "character" to it.item.character, "text" to it.item.text, "seconds" to it.seconds)
                    }
                }
                put(dir + "info.json", gson.toJson(meta).toByteArray(Charsets.UTF_8))
                summary += meta
            }
            put("pack.json", gson.toJson(linkedMapOf("tool" to "MangaLocal", "chapter" to chapter.title, "target" to target.name, "panels" to summary)).toByteArray(Charsets.UTF_8))
            put("README.txt", (
                "Gói ảnh cho model video (image-to-video) — MangaLocal mục 244.\n\n" +
                "- start.png: khung hình ĐẦU, ảnh sạch (không bóng thoại/chữ), đã cắt/đổi cỡ theo khung đích '${target.label}' và giữ trọn mặt khi có thể.\n" +
                "- end.png (nếu có): khung KẾT cho chế độ First-Last-Frame; chỉ khác start.png ở BIỂU CẢM mặt, cùng bố cục/ánh sáng.\n" +
                "- prompt.txt: prompt CHUYỂN ĐỘNG (không mô tả lại ngoại hình) và negative prompt theo hướng dẫn Wan 2.2.\n" +
                "- dialogue.txt: lời thoại để dùng với model có âm thanh (talking portrait).\n" +
                "- pPPP_lLL.wav (chỉ khi bật 'Lồng tiếng' và máy có giọng Tiếng Việt): giọng đọc TTS của máy cho từng câu thoại, khác nhau giữa nhân vật chỉ ở cao độ; KHÔNG ghép vào video, KHÔNG đồng bộ khẩu hình. Độ dài từng câu ở info.json (dialogueAudio).\n" +
                "- clip.mp4 (chỉ khi bật 'Tạo clip chuyển động trên server'): clip ngắn do Stable Video Diffusion trên server từ xa sinh từ start.png; chuyển động do model tự nghĩ, không theo prompt.txt.\n" +
                "- info.json: biểu cảm đầu/cuối, vùng cắt, các cảnh báo sẵn sàng.\n\n" +
                "Chưa kiểm chứng với model video nào cụ thể: prompt và ngưỡng cảnh báo là theo khuyến nghị chung của cộng đồng, cần thử và chỉnh.\n"
            ).toByteArray(Charsets.UTF_8))
        }
        ttsDir.deleteRecursively()
        out.absolutePath
    }

    // mục 243 — chuỗi prompt biểu cảm theo bộ từ vựng chỉ định (để UI hiển thị cạnh ảnh so sánh).
    fun previewExpressionPrompt(key: String, settings: GenerationSettings, realistic: Boolean): String =
        LLMParser.resolveExpressionTag(key, resolvePromptStyle(settings), realistic).orEmpty()

    // mục 243 TECHNICAL_STATUS.md — nạp LLM, chạy lượt LẬP KẾ HOẠCH CẢM XÚC cho cả chương, giải phóng LLM. Trả đề xuất
    // (chỉ số panel -> tên nhân vật -> khoá biểu cảm); rỗng nếu lỗi. KHÔNG ghi gì vào chương — caller (ViewModel) quyết định áp dụng.
    suspend fun planEmotionArc(chapter: Chapter, settings: GenerationSettings): Map<Int, Map<String, String>> =
        withContext(Dispatchers.IO) {
            val parser = LLMParser(settings.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
            try {
                parser.init()
                val arc = chapter.panels.filter { it.scene.characters.isNotEmpty() }.map { p ->
                    EmotionArcPanel(
                        index = p.index, description = p.scene.description, characters = p.scene.characters,
                        dialogue = p.scene.dialogue.map { it.characterName to it.text },
                        current = p.scene.characters.mapNotNull { n -> expressionKeyFor(p, n)?.let { n to it } }.toMap()
                    )
                }
                if (arc.isEmpty()) emptyMap() else parser.planEmotionArc(arc)
            } catch (ex: Exception) {
                log("  ⚠ Lập kế hoạch cảm xúc lỗi (${ex.message})", LogLevel.WARN)
                emptyMap()
            } finally {
                parser.free()
            }
        }

    // mục 246 — hai điểm mắt chuẩn hoá của người [personIdx]: (mắt bên TRÁI ảnh, mắt bên PHẢI ảnh).
    // Null nếu thiếu 1 trong 2 mắt (mặt 3/4) -> không căn chỉnh được -> cổng danh tính bỏ qua mặt đó.
    private fun eyePair(sk: FloatArray, personIdx: Int): FloatArray? {
        val b = personIdx * 18 * 4
        if (b + 18 * 4 > sk.size) return null
        if (sk[b + 14 * 4 + 3] <= 0.5f || sk[b + 15 * 4 + 3] <= 0.5f) return null
        val rx = sk[b + 14 * 4]; val ry = sk[b + 14 * 4 + 1]; val lx = sk[b + 15 * 4]; val ly = sk[b + 15 * 4 + 1]
        // Mắt bên TRÁI ảnh là mắt có x nhỏ hơn (đúng cả khi người quay hoặc nhãn trái/phải bị đảo).
        return if (rx <= lx) floatArrayOf(rx, ry, lx, ly) else floatArrayOf(lx, ly, rx, ry)
    }

    // mục 248 TECHNICAL_STATUS.md — KIỂM TRA ẢNH SAU SINH (xem OutputVerifier.kt): chạy lại YOLOv8-pose trên ẢNH RA, so với
    // khung xương đã đưa vào ControlNet. Chỉ CẢNH BÁO (thêm lý do vào badge Quality Gate của panel), không thử lại, không
    // chặn. Tắt mặc định (settings.verifyOutputPose). Trả null = không kiểm được (tắt / chưa có model / không có khung xương).
    private fun verifyOutputPose(
        imagePath: String, panel: Panel, story: Story, settings: GenerationSettings, eff: Effective, chapterNumber: Int?
    ): OutputVerifier.Result? {
        if (!settings.verifyOutputPose) return null
        return try {
            if (!poseExtractor.isReady()) { log("  ⚠ Kiểm tra sau sinh: YOLOv8-pose chưa sẵn sàng — bỏ qua"); return null }
            val sk = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapterNumber)
            val targets = OutputVerifier.targetsFromSkeleton(sk)
            if (targets.isEmpty()) return null
            val bmp = BitmapFactory.decodeFile(imagePath) ?: return null
            val people = try { poseExtractor.extractFromImage(bmp) } finally { bmp.recycle() }
            val result = OutputVerifier.verify(targets, OutputVerifier.detectedFromKeypoints(people ?: emptyList()))
            log("  Kiểm tra sau sinh panel ${panel.index + 1}: ${result.detected}/${result.expected} người — " +
                if (result.passed) "ổn" else result.reasons.joinToString("; "))
            result
        } catch (e: Exception) {
            log("  ⚠ Kiểm tra sau sinh lỗi (bỏ qua): ${e.message}")
            null
        }
    }

    // mục 238 TECHNICAL_STATUS.md — LƯỢT VẼ LẠI BIỂU CẢM TỪNG KHUÔN MẶT (kiểu ADetailer). Chạy CUỐI, sau mọi
    // lượt sửa vùng chạm/SDXL hậu kỳ, để biểu cảm không bị lượt khác ghi đè. Với mỗi nhân vật có biểu cảm KHÁC
    // "neutral" (per-character > override của người dùng > biểu cảm chung của cảnh), vẽ lại riêng vùng đặc trưng
    // mặt (mày–mắt–mũi–miệng–cằm, KHÔNG gồm tóc/tai) bằng prompt biểu cảm, dùng chính seed của panel, denoise
    // vừa (mặc định 0.42), qua đường "only masked" (inpaintRegionCropped) nên mặt nhỏ được vẽ ở độ phân giải đầy đủ.
    // Nguồn và giới hạn: xem ExpressionFace.kt và TECHNICAL_STATUS.md mục 238.
    //
    // GIỚI HẠN THẬT:
    // - Vị trí mặt lấy từ khung xương ĐẦU VÀO (như bubble mục 228), không dò lại từ ảnh sinh ra; ControlNet không bám
    //   sát thì mask có thể lệch mặt thật. CHƯA có bước kiểm chứng bằng dò mặt trên ảnh.
    // - Lượt img2img KHÔNG có IP-Adapter nên danh tính mặt chỉ được giữ nhờ denoise thấp + mask hẹp + anchorPrompt
    //   của nhân vật; denoise cao hơn ~0.5 dễ lệch khuôn mặt khỏi anchor.
    // - Mặt không thấy mũi/mắt (quay lưng) bị bỏ qua; mặt quá nhỏ (đầu < ~28px ở cỡ 512) bị bỏ qua.
    // - Mỗi mặt = 1 lượt img2img; tối đa settings.maxExpressionFaces mặt/panel.
    // - CHƯA build-test, chưa có ảnh thật so trước/sau.
    private suspend fun tryExpressionFacePass(
        rawPath: String, panel: Panel, story: Story, settings: GenerationSettings, eff: Effective,
        allChars: List<Character>, chapterNumber: Int?, outDir: File,
        forced: Map<String, String>? = null, // mục 244: ép biểu cảm theo TÊN nhân vật (khung kết video); bỏ qua cờ expressionFacePass
        workIndex: Int = panel.index         // mục 244: chỉ số đặt tên file tạm — khung kết dùng chỉ số riêng để không ghi đè ảnh chính
    ): String {
        if (forced == null && !settings.expressionFacePass) return rawPath
        val sceneChars = stableCharacterOrder(panel.scene.characters, allChars)
        if (sceneChars.isEmpty()) return rawPath
        val promptStyle = resolvePromptStyle(settings)
        // Biểu cảm từng người (override > LLM từng người > chung cảnh > tín hiệu thoại); null = bỏ qua.
        val wanted: List<Pair<Int, String>> = sceneChars.mapIndexedNotNull { i, name ->
            val key = if (forced != null) forced[name] else expressionKeyFor(panel, name)
            if (key == null || LLMParser.resolveExpressionTag(key, promptStyle) == null) null else i to key
        }
        if (wanted.isEmpty()) return rawPath
        val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(rawPath, opts)
        val w = opts.outWidth; val h = opts.outHeight
        if (w <= 0 || h <= 0) return rawPath
        return try {
            val sk = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapterNumber)
            if (sk.isEmpty()) { log("  ℹ Biểu cảm: panel ${panel.index + 1} không có khung xương — bỏ qua lượt vẽ mặt"); return rawPath }
            val faces = ExpressionFace.faceBoxes(sk, sceneChars.size, w, h).associateBy { it.personIdx }
            val useSdxl = eff.modelTier == ImageModelTier.SDXL
            val nativeSide = (minOf(w, h, if (useSdxl) 1024 else 768) / 8) * 8
            // mục 245 — luồng theo yêu cầu (khung kết video...) chạy khi model có thể chưa nạp; img2imgFix KHÔNG tự nạp.
            // loadSD/loadSDSdxl đều idempotent (bỏ qua nếu cùng model + cùng embeddings) nên gọi ở luồng sinh ảnh cũng vô hại.
            val embDir = storyManager.embeddingsDir(story.id).absolutePath
            if (useSdxl) {
                val sdxlId = settings.sdxlModelId?.takeIf { it.isNotBlank() }
                if (sdxlId != null && !imagePipeline.isSdxlBaseLoaded())
                    imagePipeline.loadSDSdxl(storyManager.modelsDir.absolutePath + "/" + sdxlId, embDir, settings.useOpenCL, settings.useNpu)
            } else if (!imagePipeline.isSdLoaded()) {
                val mid = resolveModelIdForScene(story, panel.scene.characters, settings.sdModelId)
                imagePipeline.loadSD(storyManager.modelsDir.absolutePath, mid, settings.useOpenCL, embDir, settings.useNpu,
                    runtimeOptimizer.detectQnnSoc()?.socModel ?: "")
            }
            var current = rawPath
            var done = 0
            for ((personIdx, key) in wanted) {
                if (done >= settings.maxExpressionFaces.coerceIn(1, 6)) break
                val face = faces[personIdx] ?: continue
                val ch = allChars.firstOrNull { it.name == sceneChars[personIdx] }
                val exprTag = LLMParser.resolveExpressionTag(key, promptStyle) ?: continue
                // Prompt CHỈ về vùng được vẽ (khuyến nghị cộng đồng): biểu cảm + mặt + đặc điểm nhân vật này.
                // embeddingTrigger (Textual Inversion của nhân vật) giữ danh tính vì lượt này KHÔNG có IP-Adapter — cùng
                // vai trò "LoRA/embedding trong prompt ADetailer" mà cộng đồng dùng để giữ mặt khi vẽ lại riêng khuôn mặt.
                val facePrompt = "$exprTag, detailed face, " +
                    listOfNotNull(ch?.embeddingTrigger, ch?.anchorPrompt).filter { it.isNotBlank() }.joinToString(", ")
                val faceNeg = "deformed face, asymmetrical eyes, extra eyes, cross-eyed, bad mouth, " +
                    (if (settings.imageStyle == ImageStyle.REALISTIC) ExpressionLibrary.REALISTIC_FACE_NEGATIVE + ", " else "") +
                    (ch?.negativePrompt ?: "") + ", " + eff.negativePrompt
                val cropRect = InpaintCompose.planCrop(face.rect, w, h, nativeSide, minGain = 1.0f)
                if (cropRect == null) { log("  ℹ Biểu cảm: không dựng được crop cho ${sceneChars[personIdx]} — bỏ qua"); continue }
                // mục 246 — CỔNG DANH TÍNH. Sao lưu ảnh trước khi vẽ (inpaintRegionCropped ghi đè cùng tên file kết quả), vẽ, đo cosine ArcFace
                // giữa mặt trước/sau; dưới ngưỡng -> thử lại 1 lần (denoise ×0.75, bám danh tính +0.2); vẫn dưới -> GIỮ mặt cũ. Thiếu model hoặc
                // mặt 3/4 (thiếu 1 mắt) -> bỏ qua cổng, hành vi như mục 245.
                val baseDenoise = (settings.expressionFaceDenoise + 0.05f * (ExpressionRegistry.intensityOf(key) - 2)).coerceIn(0.25f, 0.65f)
                val idRef = if (settings.expressionFaceIdentity)
                    storyManager.getCharacterAnchor(story.id, sceneChars[personIdx], preferTorn = false,
                        chapterNumber = chapterNumber, expressionKey = key) else null
                val colorMatch = if (!settings.inpaintColorMatch) 0f
                    else if (key == "blush" || ExpressionRegistry.presetOf(key)?.extras.orEmpty().any { it == "blush" || it == "pale" || it == "embarrassed" }) 0.25f
                    else 0.6f
                val backup = File(outDir, "panel_%03d_facebak_%d.png".format(workIndex, personIdx))
                File(current).copyTo(backup, overwrite = true)
                suspend fun attempt(denoise: Float, idScale: Float): String = inpaintRegionCropped(
                    backup.absolutePath, face.rect, cropRect, w, h, nativeSide,
                    sk, emptyList(), facePrompt, faceNeg, settings.imageStyle.stylePrompt, denoise,
                    eff.seed, workIndex, 100 + personIdx, outDir, useSdxl, oval = true, colorMatch = colorMatch,
                    identityRefPath = idRef, identityPersonIdx = personIdx, identityScale = idScale
                )
                current = try {
                    var result = attempt(baseDenoise, settings.expressionIdentityScale)
                    val eyes = eyePair(sk, personIdx)
                    val minSim = settings.expressionIdentityMinSim
                    if (minSim > 0f && eyes != null && identityGuard.isReady()) {
                        val sim = identityGuard.similarity(backup.absolutePath, result, eyes[0], eyes[1], eyes[2], eyes[3], outDir)
                        log("  ◦ Độ giống danh tính ${sceneChars[personIdx]} (ArcFace, trước/sau): " + (sim?.let { "%.2f".format(it) } ?: "không đo được") + " · ngưỡng %.2f".format(minSim))
                        if (sim != null && sim < minSim) {
                            val retry = attempt(baseDenoise * 0.75f, (settings.expressionIdentityScale + 0.2f).coerceAtMost(1.2f))
                            val sim2 = identityGuard.similarity(backup.absolutePath, retry, eyes[0], eyes[1], eyes[2], eyes[3], outDir)
                            log("  ◦ Thử lại với denoise thấp hơn: " + (sim2?.let { "%.2f".format(it) } ?: "không đo được"))
                            if (sim2 != null && sim2 >= minSim) result = retry
                            else { log("  ⚠ Mặt ${sceneChars[personIdx]} lệch danh tính sau cả 2 lần vẽ — GIỮ mặt cũ (biểu cảm \"$key\" không được áp dụng)", LogLevel.WARN); result = backup.absolutePath }
                        }
                    }
                    result
                } catch (ex: Exception) {
                    log("  ⚠ Vẽ biểu cảm \"$key\" cho ${sceneChars[personIdx]} lỗi (${ex.message}) — giữ mặt cũ")
                    current
                }
                done++
                log("  → Biểu cảm \"$key\": đã vẽ lại mặt ${sceneChars[personIdx]}" + if (face.threeQuarter) " (mặt 3/4 — kém chắc chắn hơn)" else "")
            }
            current
        } catch (ex: Exception) {
            log("  ⚠ Lượt vẽ biểu cảm lỗi (${ex.message}) — giữ ảnh hiện tại", LogLevel.WARN)
            rawPath
        }
    }

    // mục 229 TECHNICAL_STATUS.md — HYBRID HẬU KỲ: SD1.5 dựng bố cục + danh
    // tính, SDXL vẽ lại CÁC VÙNG TIẾP XÚC ở bước cuối (đúng quy trình cộng
    // đồng "inpaint bằng model nhẹ rồi tinh chỉnh bằng SDXL" mà PDF bổ sung
    // mô tả). TÁI DÙNG NGUYÊN tryAutoFixInteractions(useSdxlFix=true) (mục
    // 207) — không viết thuật toán vẽ lại mới; khác các call site SDXL cũ ở
    // chỗ ảnh ĐẦU VÀO là ảnh SD1.5 (thường 512²) và toạ độ vùng được dựng
    // theo kích thước SDXL (toạ độ khung xương chuẩn hoá nên đổi kích thước
    // an toàn).
    //
    // GIỚI HẠN THẬT:
    // - CHỈ ảnh VUÔNG (unet_sdxl.mnn export cố định 1 kích thước vuông — mục
    //   191/192; native resizeToCHWFloat sẽ KÉO GIÃN nếu khác tỷ lệ). Panel
    //   không vuông -> bỏ qua có log, giữ ảnh SD1.5.
    // - Khi CÓ vùng cần sửa, toàn ảnh đi qua VAE SDXL một lần (encode ảnh
    //   SD1.5 đã phóng lên -> decode) nên phần NGOÀI mask mềm hơn bản gốc do
    //   phóng từ 512 lên; bước ESRGAN sau đó bù lại. Kích thước panel ra
    //   khác panel SD1.5 thường (giống panel SDXL trực tiếp sẵn có).
    // - Nạp SDXL khi SD1.5 vẫn đang nằm trong RAM (cùng cách nhánh "SD1.5
    //   fail -> SDXL" mục 185 đã làm); máy 16GB theo ngưỡng TokForge (mục
    //   171) nhưng CHƯA đo thật.
    // - CHƯA build-test.
    private suspend fun trySdxlFinishPass(
        rawPath: String, panel: Panel, story: Story, settings: GenerationSettings, eff: Effective,
        allChars: List<Character>, chapterNumber: Int?, outDir: File
    ): String {
        if (!settings.sdxlFinishPass || !settings.autoFixInteractions) return rawPath
        if (eff.modelTier == ImageModelTier.SDXL) return rawPath // panel đã là SDXL
        val sceneChars = stableCharacterOrder(panel.scene.characters, allChars)
        if (sceneChars.size < 2) return rawPath
        val sdxlModelId = settings.sdxlModelId?.takeIf { it.isNotBlank() } ?: return rawPath
        if (!storyManager.hasSdxlBaseUnet(sdxlModelId)) {
            log("  ⚠ SDXL hậu kỳ: model \"$sdxlModelId\" thiếu unet_sdxl.mnn — bỏ qua, giữ ảnh SD1.5")
            return rawPath
        }
        if (eff.width != eff.height) {
            log("  ⚠ SDXL hậu kỳ: panel ${panel.index + 1} không vuông (${eff.width}×${eff.height}) — " +
                "SDXL export cố định ảnh vuông, bỏ qua để tránh kéo giãn")
            return rawPath
        }
        return try {
            val sdxlSize = storyManager.readSdxlExportedResolution(sdxlModelId) ?: 1024
            val sdxlModelDir = storyManager.modelsDir.absolutePath + "/" + sdxlModelId
            val embeddingsDir = storyManager.embeddingsDir(story.id).absolutePath
            imagePipeline.loadSDSdxl(sdxlModelDir, embeddingsDir, settings.useOpenCL, settings.useNpu)
            val effPromptFinish = injectHeadsTallTag(
                injectEmbeddingTriggers(eff.prompt, panel, allChars, eff.characterName), eff.characterName, allChars)
            val skFinish = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapterNumber)
            val out = tryAutoFixInteractions(
                rawPath, sdxlSize, sdxlSize, effPromptFinish, eff.negativePrompt,
                settings.imageStyle.stylePrompt, eff.seed, settings.sdxlFinishDenoise,
                panel.index, outDir, skFinish, sceneChars.size,
                characterOrder = sceneChars, allChars = allChars,
                settings = settings, worldRules = story.worldRules, useSdxlFix = true
            )
            if (out != rawPath) log("  → SDXL hậu kỳ: đã vẽ lại vùng tiếp xúc panel ${panel.index + 1} ở ${sdxlSize}×${sdxlSize}")
            out
        } catch (ex: Exception) {
            log("  ⚠ SDXL hậu kỳ lỗi (${ex.message}) — giữ ảnh SD1.5")
            rawPath
        }
    }

    // mục 237 TECHNICAL_STATUS.md — vẽ 1 vùng chạm kiểu "only masked". Trả đường dẫn ảnh đã dán patch.
    // Ném exception nếu bất kỳ bước nào hỏng (caller bắt và rơi về vẽ cả khung). Xem InpaintCompose.kt
    // cho nguồn tra cứu và GIỚI HẠN THẬT. Toạ độ regionRect/cropRect nằm trong không gian ảnh width x height;
    // nếu ảnh đầu vào có kích thước khác (vd ảnh SD1.5 512² khi SDXL hậu kỳ dùng 1024²) thì phóng ảnh nền lên
    // width x height trước (cùng kích thước ảnh ra như cách vẽ cả khung cũ).
    private suspend fun inpaintRegionCropped(
        currentPath: String, regionRect: Rect, cropRect: Rect, width: Int, height: Int, nativeSide: Int,
        skeletonData: FloatArray, silhouettePersonIdxs: List<Int>,
        prompt: String, negativePrompt: String, stylePrompt: String, denoise: Float, seed: Long,
        panelIndex: Int, regionIdx: Int, outDir: File, useSdxlFix: Boolean, oval: Boolean = false,
        colorMatch: Float = 0f, // mục 241: 0 = tắt; (0,1] = mức khớp màu patch theo ảnh gốc trong vùng mask
        identityRefPath: String? = null, // mục 245: ảnh tham chiếu danh tính (IP-Adapter); null = img2img thường
        identityPersonIdx: Int = -1,     // chỉ số người trong skeletonData dùng làm pose cho lượt giữ danh tính
        identityScale: Float = 0.6f
    ): String {
        val srcBmp = BitmapFactory.decodeFile(currentPath)
            ?: throw IllegalStateException("không đọc được ảnh nền $currentPath")
        val scaledBase = if (srcBmp.width != width || srcBmp.height != height) {
            val sb = Bitmap.createScaledBitmap(srcBmp, width, height, true)
            if (sb !== srcBmp) srcBmp.recycle()
            sb
        } else srcBmp
        val base = scaledBase.copy(Bitmap.Config.ARGB_8888, true)
            ?: throw IllegalStateException("không tạo được bản sao ghi được của ảnh nền")
        if (scaledBase !== base) scaledBase.recycle()

        val side = cropRect.width()
        val cropRaw = Bitmap.createBitmap(base, cropRect.left, cropRect.top, side, side)
        val cropIn = Bitmap.createScaledBitmap(cropRaw, nativeSide, nativeSide, true)
        if (cropRaw !== base && cropRaw !== cropIn) cropRaw.recycle()
        val cropFile = File(outDir, "panel_%03d_cropin_%d.png".format(panelIndex, regionIdx))
        FileOutputStream(cropFile).use { cropIn.compress(Bitmap.CompressFormat.PNG, 100, it) }
        cropIn.recycle()

        val f = nativeSide.toFloat() / side
        val rIn = Rect(
            ((regionRect.left - cropRect.left) * f).toInt().coerceIn(0, nativeSide),
            ((regionRect.top - cropRect.top) * f).toInt().coerceIn(0, nativeSide),
            ((regionRect.right - cropRect.left) * f).toInt().coerceIn(0, nativeSide),
            ((regionRect.bottom - cropRect.top) * f).toInt().coerceIn(0, nativeSide)
        )
        val skCrop = InpaintCompose.remapSkeleton(skeletonData, width, height, cropRect.left, cropRect.top, side)
        val maskFile = File(outDir, "panel_%03d_cropmask_%d.png".format(panelIndex, regionIdx))
        buildInteractionMaskFile(rIn, nativeSide, nativeSide, maskFile,
            skeletonData = skCrop, silhouettePersonIdxs = silhouettePersonIdxs, oval = oval)

        // mục 245 — đường giữ danh tính bằng IP-Adapter (chỉ SD1.5 có model augmented). Lỗi -> rơi về img2img thường ngay bên dưới.
        val idPath: String? = if (!useSdxlFix && identityRefPath != null && identityPersonIdx >= 0 &&
            File(identityRefPath).exists() && imagePipeline.isAugmentedLoaded()) {
            try {
                val fpp = 18 * 4
                val from = identityPersonIdx * fpp
                val personSk = if (from + fpp <= skeletonData.size)
                    InpaintCompose.remapSkeleton(skeletonData.copyOfRange(from, from + fpp), width, height, cropRect.left, cropRect.top, side)
                else FloatArray(0)
                imagePipeline.inpaintWithIdentity(
                    prompt + ", " + stylePrompt, negativePrompt, cropFile.absolutePath, maskFile.absolutePath, identityRefPath,
                    personSk, denoise, nativeSide, nativeSide, 25, 7.5f, seed,
                    File(outDir, "panel_%03d_idfix_%d.png".format(panelIndex, regionIdx)), identityScale
                ) { _, _ -> }
            } catch (ex: Exception) {
                log("  ⚠ Inpaint giữ danh tính lỗi (${ex.message}) — dùng img2img thường cho vùng này")
                null
            }
        } else null
        val resPath = if (idPath != null) idPath else if (useSdxlFix) {
            imagePipeline.img2imgFixSdxl(
                panelIndex = panelIndex, prompt = prompt, negativePrompt = negativePrompt,
                stylePrompt = stylePrompt, inputPath = cropFile.absolutePath, maskPath = maskFile.absolutePath,
                denoiseStrength = denoise, width = nativeSide, height = nativeSide,
                steps = 25, cfgScale = 7.5f, seed = seed, outDir = outDir
            ) { _, _ -> }
        } else {
            imagePipeline.img2imgFix(
                panelIndex = panelIndex, prompt = prompt, negativePrompt = negativePrompt,
                stylePrompt = stylePrompt, inputPath = cropFile.absolutePath, maskPath = maskFile.absolutePath,
                denoiseStrength = denoise, width = nativeSide, height = nativeSide,
                steps = 25, cfgScale = 7.5f, seed = seed, ultrafix = false, ultrafixTile = 512,
                outDir = outDir
            ) { _, _ -> }
        }

        val res = BitmapFactory.decodeFile(resPath)
            ?: throw IllegalStateException("không đọc được kết quả inpaint $resPath")
        val maskBmp = BitmapFactory.decodeFile(maskFile.absolutePath)
            ?: throw IllegalStateException("không đọc lại được mask crop")
        val resS = Bitmap.createScaledBitmap(res, side, side, true)
        val maskS = Bitmap.createScaledBitmap(maskBmp, side, side, true)
        // mục 241 — khớp trung bình/độ lệch màu của patch theo ảnh gốc trong vùng mask (tương tự tuỳ chọn "color
        // correction" của img2img A1111, vì img2img/VAE làm trôi màu da/tóc) TRƯỚC khi dán.
        val patchForBlend = if (colorMatch > 0f) InpaintCompose.matchColors(base, resS, maskS, cropRect.left, cropRect.top, colorMatch) else resS
        InpaintCompose.blendInto(base, patchForBlend, maskS, cropRect.left, cropRect.top)
        if (patchForBlend !== resS) patchForBlend.recycle()

        val outFile = File(outDir, "panel_%03d_cropfix.png".format(panelIndex))
        FileOutputStream(outFile).use { base.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (resS !== res) res.recycle()
        if (maskS !== maskBmp) maskBmp.recycle()
        resS.recycle(); maskS.recycle(); base.recycle()
        cropFile.delete(); maskFile.delete()
        return outFile.absolutePath
    }

    // mục 237 — dán pixel gốc ngoài mask cho lượt vẽ cả khung (cách cũ). Lỗi bất kỳ -> trả luôn kết quả inpaint thô
    // (hành vi cũ), không làm hỏng ảnh.
    private fun pasteBackFullFrame(basePath: String, resultPath: String, maskPath: String, outFile: File): String {
        return try {
            val res = BitmapFactory.decodeFile(resultPath) ?: return resultPath
            val baseSrc = BitmapFactory.decodeFile(basePath) ?: return resultPath
            val baseScaled = if (baseSrc.width != res.width || baseSrc.height != res.height) {
                val sb = Bitmap.createScaledBitmap(baseSrc, res.width, res.height, true)
                if (sb !== baseSrc) baseSrc.recycle()
                sb
            } else baseSrc
            val base = baseScaled.copy(Bitmap.Config.ARGB_8888, true) ?: return resultPath
            if (baseScaled !== base) baseScaled.recycle()
            val maskSrc = BitmapFactory.decodeFile(maskPath) ?: return resultPath
            val mask = if (maskSrc.width != res.width || maskSrc.height != res.height) {
                val ms = Bitmap.createScaledBitmap(maskSrc, res.width, res.height, true)
                if (ms !== maskSrc) maskSrc.recycle()
                ms
            } else maskSrc
            InpaintCompose.blendInto(base, res, mask, 0, 0)
            FileOutputStream(outFile).use { base.compress(Bitmap.CompressFormat.PNG, 100, it) }
            res.recycle(); mask.recycle(); base.recycle()
            outFile.absolutePath
        } catch (ex: Exception) {
            log("  ⚠ Dán lại pixel gốc lỗi (${ex.message}) — dùng kết quả inpaint thô")
            resultPath
        }
    }

    // mục 92 TECHNICAL_STATUS.md — bỏ tham số extraRegions (union nhiều vùng
    // vào 1 mask) vì giờ mỗi vùng lỗi được xử lý RIÊNG, tuần tự (xem
    // tryAutoFixInteractions() ở trên) — hàm này giờ chỉ vẽ ĐÚNG 1 vùng.
    private fun buildInteractionMaskFile(
        region: Rect, fullW: Int, fullH: Int, outFile: File,
        skeletonData: FloatArray = FloatArray(0), silhouettePersonIdxs: List<Int> = emptyList(),
        oval: Boolean = false // mục 238: mask khuôn mặt hình bầu dục (mặc định false = hình chữ nhật như cũ)
    ) {
        val mask = Bitmap.createBitmap(fullW, fullH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(mask)
        canvas.drawColor(Color.BLACK) // ngoài vùng: giữ nguyên (không inpaint)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE // trong vùng: cho phép inpaint
            style = Paint.Style.FILL
            maskFilter = BlurMaskFilter(15f * (fullW / 512f).coerceIn(0.75f, 3f), BlurMaskFilter.Blur.NORMAL) // feather biên mềm, tỉ lệ theo cạnh ảnh (mục 229: 15px cố định quá hẹp ở SDXL 1024)
        }
        if (oval) canvas.drawOval(android.graphics.RectF(region), paint)
        else canvas.drawRect(region.left.toFloat(), region.top.toFloat(),
                        region.right.toFloat(), region.bottom.toFloat(), paint)
        // mục 111 TECHNICAL_STATUS.md — SilhouetteFilter: khắc (subtract) 1
        // dải đen mảnh dọc trục thân của MỖI người giao thoa, VẼ SAU khi đã
        // fill trắng, TRƯỚC khi ghi file — buộc vùng da thịt sinh mới của 2
        // người dừng đúng ranh giới trục xương thay vì tự do hoà lẫn. Không
        // tác dụng phụ khi silhouettePersonIdxs rỗng hoặc skeletonData rỗng
        // (strokeAxis tự bỏ qua nếu thiếu khớp hợp lệ).
        if (silhouettePersonIdxs.size >= 2 && skeletonData.isNotEmpty()) {
            for (idx in silhouettePersonIdxs) {
                SilhouetteFilter.strokeAxis(canvas, skeletonData, idx, fullW, fullH)
            }
        }
        FileOutputStream(outFile).use { fos -> mask.compress(Bitmap.CompressFormat.PNG, 100, fos) }
        mask.recycle()
    }

    // mục 115/117 TECHNICAL_STATUS.md — mask CƠ THỂ 1 người cụ thể (khác
    // buildInteractionMaskFile ở trên — hàm đó khoanh vùng GIAO THOA giữa
    // 2+ người, hàm này khoanh TOÀN THÂN 1 người riêng lẻ cho Multi-Pass
    // Cascade). Dùng TẤT CẢ 18 khớp hợp lệ của người đó (không chỉ hông/
    // gối) — cascade cần sửa được cả mặt/tay, không riêng phần thân dưới.
    // mục 172 TECHNICAL_STATUS.md — dựng `region_masks` cho
    // ImagePipeline.generatePanelRegionalMask() (Regional Prompting MASK
    // hình dạng tuỳ ý). Gọi buildCharacterBodyMaskFile(imagePath=null, ...)
    // — null CHỦ Ý (xem giải thích ngay tại khai báo hàm đó): CHƯA có ảnh
    // nào tồn tại lúc này (đây là input cho LƯỢT SINH ĐẦU TIÊN, không phải
    // inpaint như Cascade), nên bỏ qua SAM, dùng thẳng rectangle+feather.
    // Trả về ByteArray PHẲNG, N khối `width*height` byte liên tiếp, ĐÚNG
    // thứ tự `sceneChars` (khớp `regionPrompts` được build cùng thứ tự ở
    // `buildRegionPrompts()` đã có) — người KHÔNG đủ khớp xương hợp lệ
    // (buildCharacterBodyMaskFile trả false) nhận khối TOÀN 0 (không claim
    // pixel nào, rơi hết về background — an toàn, không throw, chỉ mất
    // vùng ưu tiên riêng của đúng người đó).
    private suspend fun buildRegionMasksForPanel(
        sceneChars: List<String>, skeletonData: FloatArray, width: Int, height: Int,
        panelIndex: Int, outDir: File
    ): ByteArray {
        val result = ByteArray(sceneChars.size * width * height)
        for (i in sceneChars.indices) {
            val maskFile = File(outDir, "panel_%03d_regionalmask_%d.png".format(panelIndex, i))
            val built = buildCharacterBodyMaskFile(null, skeletonData, i, width, height, maskFile, panelIndex, outDir)
            val offset = i * width * height
            if (!built) {
                log("  ⚠ Regional-Mask: bỏ qua nhân vật '${sceneChars[i]}' (không đủ khớp xương hợp lệ) — vùng của họ rơi về background")
                continue // khối đã = 0 sẵn (ByteArray Kotlin khởi tạo 0)
            }
            val bmp = BitmapFactory.decodeFile(maskFile.absolutePath)
            if (bmp == null) { log("  ⚠ Regional-Mask: đọc lại file mask vừa tạo thất bại cho '${sceneChars[i]}'"); continue }
            // Đọc kênh ĐỎ (R) làm giá trị xám — buildCharacterBodyMaskFile()
            // vẽ TRẮNG (R=G=B=255) trên nền ĐEN (R=G=B=0), 3 kênh y hệt nhau
            // nên đọc kênh nào cũng ra cùng giá trị, chọn R theo quy ước.
            val pixels = IntArray(width * height)
            bmp.getPixels(pixels, 0, width, 0, 0, width, height)
            for (p in pixels.indices) result[offset + p] = ((pixels[p] shr 16) and 0xFF).toByte()
            bmp.recycle()
            maskFile.delete() // file trung gian, không cần giữ lại (khác cascade — cascade cần xem lại để debug từng lượt)
        }
        return result
    }

    // mục 184 TECHNICAL_STATUS.md — SDXL Phase 3: chọn VÀ gọi đúng pipeline
    // SDXL (augmented 1-người / mask N-người / regional cột / regional-mask)
    // theo thứ tự ưu tiên MIRROR y hệt SD1.5 (mask > regional-mask >
    // regional > đơn — xem 4 điều kiện useRegionalMask/useRegional/
    // multiCharAnchors ở generatePanels()/regeneratePanel()). Dùng CHUNG 1
    // hàm cho cả 2 nơi gọi (khác cách SD1.5 làm — SD1.5 lặp lại logic ở cả
    // 2 hàm, TỰ CHỌN dùng chung ở đây để giảm rủi ro copy-paste lệch nhau,
    // đúng bài học mục 147 đã rút ra cho chính SD1.5).
    //
    // Trả về đường dẫn ảnh RAW, hoặc NULL nếu KHÔNG đủ điều kiện dùng SDXL
    // cho panel này (thiếu sdxlModelId, thiếu file .mnn tương ứng, hoặc
    // thiếu ảnh anchor) — caller PHẢI tự rơi về nhánh SD1.5 sẵn có khi hàm
    // này trả null, KHÔNG được coi null là lỗi (cùng nguyên tắc "log cảnh
    // báo + fallback, không throw" đã áp dụng cho modelTierOverride ở
    // resolveEffective()).
    //
    // GIỚI HẠN THẬT (đọc trước khi bật `defaultModelTier=SDXL`):
    // - CHƯA build-test bất kỳ phần nào của Phase 2 (mục 177-181) lẫn phần
    //   nối dây này (Phase 3, mục 184) — không có GPU/NDK/thiết bị thật
    //   trong sandbox lúc viết.
    // - KHÔNG có Quality Gate retry / FleshDeformationEngine /
    //   autoFixInteractions / Multi-Pass Cascade cho nhánh SDXL — mỗi panel
    //   chỉ sinh ĐÚNG 1 lần, không đánh giá lại, không tự sửa tương tác
    //   tay/hông giao nhau. PHẠM VI CỐ Ý HẸP cho lần nối dây đầu tiên,
    //   không phải thiếu sót quên làm — mở rộng thêm là việc riêng, sau
    //   khi phần cơ bản chạy được thật.
    // - KHÔNG có switch bật/tắt Depth ControlNet riêng như SD1.5 (mục 81/
    //   146) — `generatePanelAugmentedSdxl()` tự render + gửi depth hint
    //   LUÔN (model .mnn tự bỏ qua an toàn nếu không có input đó, xem
    //   ImagePipeline.kt).
    // - Độ phân giải LUÔN VUÔNG, user tự chọn 768 hoặc 1024 ở Cài đặt (mục
    //   189 — trước đó cố định 1024, xem lý do KHÔNG cho chọn 512 ở comment
    //   field `sdxlResolution`, Models.kt) — KHÔNG đọc `eff.width`/
    //   `eff.height` (giá trị đó tối ưu cho SD1.5 512, ép dùng cho SDXL
    //   augmented CHƯA xác nhận an toàn) — mọi biến thể tỷ lệ khung ảnh
    //   (mục 161 đợt 5-7) KHÔNG áp dụng cho nhánh này, kể cả ở 768.
    // - KHÔNG đọc `panel.overrideSettings?.characterOverride` (neo tay 1
    //   người cụ thể) — dùng thẳng `sceneChars`/anchor mặc định, giống hệt
    //   cách SD1.5 làm cho 3 nhánh multiCharAnchors/regionalMask/regional
    //   (những nhánh đó CŨNG bỏ qua characterOverride qua điều kiện
    //   `noCharacterOverride` ở caller — nhất quán, không phải thiếu sót
    //   riêng của SDXL).
    // - KHÔNG check `pairModelIdForSceneOrNull()` (LoRA ghép cặp SD1.5) —
    //   khái niệm đó gắn với checkpoint SD1.5 merge sẵn, KHÔNG có tương
    //   đương cho SDXL trong Phase 2.
    private suspend fun dispatchSdxlPanel(
        panel: Panel, story: Story, settings: GenerationSettings, eff: Effective,
        sceneChars: List<String>, allChars: List<Character>, chapterNumber: Int?,
        outDir: File, onProgress: (Int, Int) -> Unit
    ): String? {
        val sdxlModelId = settings.sdxlModelId?.takeIf { it.isNotBlank() } ?: return null
        val sdxlModelDir = storyManager.modelsDir.absolutePath + "/" + sdxlModelId
        val embeddingsDir = storyManager.embeddingsDir(story.id).absolutePath
        // mục 192 TECHNICAL_STATUS.md — giải quyết giới hạn thật mục 191:
        // ƯU TIÊN đọc `sdxl_resolution.txt` (marker ghi bởi prepare_models.yml
        // lúc export thật, mục 192) thay vì chỉ tin `settings.sdxlResolution`
        // (lựa chọn user tự nhớ, mục 189 — vẫn có thể sai nếu model export
        // TRƯỚC mục 192, hoặc user tự copy tay thiếu file marker). Model
        // .mnn export CỐ ĐỊNH 1 độ phân giải (mục 52b, không dynamic_axes)
        // nên KHÔNG cho phép Kotlin tự "chọn" — chỉ có ĐÚNG 1 giá trị THẬT
        // đúng, marker biết chắc.
        //
        // mục 193 TECHNICAL_STATUS.md — GIẢI QUYẾT THÊM cho trường hợp
        // THIẾU marker (user hỏi thẳng "sao không tìm hướng khác" sau khi
        // mục 192 tự nhận đây là giới hạn không giải quyết được — đúng là
        // còn hướng khác): TRƯỚC `sdxl_image_size` (mục 191), KHÔNG script/
        // workflow nào trong dự án từng truyền `--image_size` khác 1024 cho
        // `export_*_sdxl.py` (grep xác nhận: input đó chỉ mới thêm ở mục
        // 191, và mục 192 ghi marker CÙNG lúc) — nghĩa là BẤT KỲ model SDXL
        // nào KHÔNG có marker CHẮC CHẮN được export ở 1024 (không có khả
        // năng nào khác từng tồn tại). Vì vậy khi thiếu marker, KHÔNG còn
        // "mù quáng tin Cài đặt" (rủi ro user lỡ chọn 768 cho model legacy
        // 1024, gây đúng lỗi lệch shape muốn tránh) — mặc định THẲNG về
        // 1024, bất kể Cài đặt nói gì. Điều này giải quyết ĐÚNG trường hợp
        // phổ biến nhất (model cũ, chưa từng đổi độ phân giải). Trường hợp
        // hiếm còn lại KHÔNG giải quyết được (đã nêu rõ, không phóng đại):
        // user tự chạy tay `export_*_sdxl.py --image_size 768` (bỏ qua hẳn
        // `prepare_models.yml`) rồi tự xoá/không tạo file marker — lúc đó
        // giả định "thiếu marker = 1024" SẼ SAI. Không có cách nào phân
        // biệt được trường hợp hiếm này với trường hợp phổ biến nếu không
        // đọc chính file `.mnn` (cân nhắc lại vẫn giữ nguyên quyết định mục
        // 192: không đáng đánh đổi rủi ro JNI mới cho 1 trường hợp hiếm).
        val exportedRes = storyManager.readSdxlExportedResolution(sdxlModelId)
        val sdxlSize = when {
            exportedRes != null && exportedRes == settings.sdxlResolution -> exportedRes
            exportedRes != null -> {
                log("  ⚠ SDXL: Cài đặt chọn ${settings.sdxlResolution}×${settings.sdxlResolution} " +
                    "nhưng model \"$sdxlModelId\" THẬT SỰ export ở $exportedRes×$exportedRes " +
                    "(đọc từ sdxl_resolution.txt) — DÙNG THEO MODEL THẬT, không theo Cài đặt, " +
                    "để tránh lệch shape/crash. Sửa lại lựa chọn ở Cài đặt cho khớp nếu muốn hết cảnh báo này.")
                exportedRes
            }
            settings.sdxlResolution == 768 -> {
                log("  ⚠ SDXL: Cài đặt chọn 768×768 nhưng model \"$sdxlModelId\" KHÔNG có file " +
                    "sdxl_resolution.txt — mọi model export TRƯỚC mục 191/192 CHẮC CHẮN là 1024 " +
                    "(không có cách nào khác từng tồn tại để export 768 trước đó) — DÙNG 1024, " +
                    "BỎ QUA lựa chọn 768 ở Cài đặt, để tránh đúng lỗi lệch shape mà lựa chọn 768 " +
                    "sai sẽ gây ra. Nếu bạn CHẮC CHẮN đã tự export tay ở 768 (ngoài prepare_models.yml) " +
                    "và biết mình đang làm gì, tự tạo file \"sdxl_resolution.txt\" chứa \"768\" trong " +
                    "thư mục model để ghi đè giả định này.")
                1024
            }
            else -> 1024
        }
        log("  → SDXL: dùng model \"$sdxlModelId\" ở $sdxlSize×$sdxlSize" +
            (if (exportedRes != null) " (xác nhận khớp file marker thật)."
             else " (không có marker — suy ra 1024 vì đó là giá trị DUY NHẤT có thể có trước mục 191)."))
        val skeletonData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapterNumber)
        val preferTorn = SeedRegistry.resolveActionCategory(panel.scene) == "combat"

        return when {
            sceneChars.size >= 2 && storyManager.hasMultiCharMaskSdxlUnet(sdxlModelId, sceneChars.size) -> {
                val anchors = sceneChars.map { storyManager.getCharacterAnchor(story.id, it, preferTorn = preferTorn, chapterNumber = chapterNumber, expressionKey = expressionKeyFor(panel, it)) }
                if (!anchors.all { it != null }) return null
                // mục 218 TECHNICAL_STATUS.md — mirror ĐÚNG nhánh Mc SD1.5
                // (mục 217 đợt 2): CẦN ĐỦ CẢ 2 điều kiện — bối cảnh đã có
                // ảnh neo VÀ model "_loc" đúng sceneChars.size đã export.
                // Thiếu 1 trong 2 -> rơi về model N-slot như cũ, KHÔNG đổi
                // hành vi.
                val locationAnchorForMcSdxl = panel.scene.locationName?.let { storyManager.getLocationAnchor(story.id, it) }
                val useMcSdxlLocationSlot = locationAnchorForMcSdxl != null &&
                    storyManager.hasMultiCharMaskSdxlUnetWithLocation(sdxlModelId, sceneChars.size)
                imagePipeline.loadSDAugmentedMultiCharSdxl(sdxlModelDir, embeddingsDir, sceneChars.size, settings.useOpenCL, settings.useNpu,
                    withLocationSlot = useMcSdxlLocationSlot)
                val masks = buildRegionMasksForPanel(sceneChars, skeletonData, sdxlSize, sdxlSize, panel.index, outDir)
                imagePipeline.generatePanelMultiCharSdxl(
                    panelIndex = panel.index, prompt = eff.prompt, negativePrompt = eff.negativePrompt,
                    stylePrompt = settings.imageStyle.stylePrompt, width = sdxlSize, height = sdxlSize,
                    steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                    referenceImagePaths = anchors.filterNotNull(), skeletonData = skeletonData,
                    characterMasks = masks, outDir = outDir, onProgress = onProgress,
                    locationAnchorPath = if (useMcSdxlLocationSlot) locationAnchorForMcSdxl else null
                )
            }
            sceneChars.size >= 2 && storyManager.hasRegionalMaskSdxlUnet(sdxlModelId, sceneChars.size) -> {
                imagePipeline.loadSDRegionalMaskSdxl(sdxlModelDir, embeddingsDir, sceneChars.size, settings.useOpenCL, settings.useNpu)
                val regionPrompts = buildRegionPrompts(sceneChars, panel.overrideSettings?.regionalPromptOverrides ?: emptyMap(), allChars, eff, settings.imageStyle.stylePrompt)
                val masks = buildRegionMasksForPanel(sceneChars, skeletonData, sdxlSize, sdxlSize, panel.index, outDir)
                imagePipeline.generatePanelRegionalMaskSdxl(
                    panelIndex = panel.index, regionPrompts = regionPrompts, backgroundPrompt = settings.imageStyle.stylePrompt,
                    negativePrompt = eff.negativePrompt, regionMasks = masks, skeletonData = skeletonData,
                    width = sdxlSize, height = sdxlSize, steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                    outDir = outDir, onProgress = onProgress
                )
            }
            sceneChars.size >= 2 && storyManager.hasRegionalSdxlUnet(sdxlModelId, sceneChars.size) -> {
                imagePipeline.loadSDRegionalSdxl(sdxlModelDir, embeddingsDir, sceneChars.size, settings.useOpenCL, settings.useNpu)
                val regionPrompts = buildRegionPrompts(sceneChars, panel.overrideSettings?.regionalPromptOverrides ?: emptyMap(), allChars, eff, settings.imageStyle.stylePrompt)
                imagePipeline.generatePanelRegionalSdxl(
                    panelIndex = panel.index, regionPrompts = regionPrompts, negativePrompt = eff.negativePrompt,
                    skeletonData = skeletonData, width = sdxlSize, height = sdxlSize, steps = eff.steps,
                    cfgScale = eff.cfgScale, seed = eff.seed, outDir = outDir, onProgress = onProgress
                )
            }
            storyManager.hasAugmentedSdxlUnet(sdxlModelId) -> {
                // mục 217 TECHNICAL_STATUS.md — mirror ĐÚNG nhánh 0-nhân-
                // vật đã thêm cho bản SD1.5 base (xem generatePanels(),
                // GIỚI HẠN THẬT đầy đủ ở đó). Khác bản SD1.5: KHÔNG có
                // ipStaticScale riêng để hạ thấp cho bối cảnh, vì
                // generatePanelAugmentedSdxl() (mục "SDXL Phase 2b") CHƯA
                // hề expose tham số này (cường độ IP-Adapter cố định trong
                // native cho toàn bộ pipeline SDXL 1-nhân-vật) — dùng
                // NGUYÊN mặc định, không phải bỏ sót.
                val characterReferenceImage = eff.characterName?.let { storyManager.getCharacterAnchor(story.id, it, preferTorn = preferTorn, chapterNumber = chapterNumber, expressionKey = expressionKeyFor(panel, it)) }
                val locationReferenceImage = if (characterReferenceImage == null && panel.scene.characters.isEmpty())
                    panel.scene.locationName?.let { storyManager.getLocationAnchor(story.id, it) }
                else null
                val referenceImage = characterReferenceImage ?: locationReferenceImage ?: return null
                imagePipeline.loadSDAugmentedSdxl(sdxlModelDir, embeddingsDir, settings.useOpenCL, settings.useNpu)
                imagePipeline.generatePanelAugmentedSdxl(
                    panelIndex = panel.index, prompt = eff.prompt, negativePrompt = eff.negativePrompt,
                    stylePrompt = settings.imageStyle.stylePrompt, width = sdxlSize, height = sdxlSize,
                    steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                    referenceImagePath = referenceImage, skeletonData = skeletonData,
                    outDir = outDir, onProgress = onProgress
                )
            }
            else -> null
        }
    }

    // mục 168 TECHNICAL_STATUS.md — nối MobileSAM (đã có sẵn từ mục 21,
    // dùng ở buildMaskFileRefined() bên trên) vào ĐÚNG chỗ user chỉ ra:
    // trước đây hàm này CHỈ vẽ 1 hình chữ nhật quanh bbox khớp xương —
    // với cảnh nhiều người CHẠM/CHỒNG LẤN vật lý (ôm/vật/hỗn chiến), bbox
    // của 2 người sát nhau ĐÈ LÊN NHAU rất nhiều, làm hỏng đúng mục đích
    // "cô lập 1 người/lượt" mà cascade cần (xem giải thích đầy đủ ở mục
    // 168 phần "Multi-Pass Cascade — mask chồng lấn"). Giờ THỬ SAM trước
    // (phân đoạn theo BIÊN THẬT của người trong ảnh, không phải hình học
    // thô), CHỈ fallback về rectangle-feather cũ khi SAM chưa sẵn sàng/
    // lỗi/trả mask rỗng — KHÔNG đổi hành vi cho trường hợp đó (an toàn).
    //
    // Điểm click cho SAM: ưu tiên khớp NECK (index 1, OpenPose-18 — xem
    // yolo_pose_wrapper.cpp) thay vì tâm hình học bbox — bbox 1 người dáng
    // dang tay/chân thường có TÂM RƠI VÀO KHOẢNG TRỐNG giữa 2 chân/tay
    // (không thuộc cơ thể), trong khi neck gần như luôn nằm TRÊN thân
    // người thật. Fallback tâm bbox nếu neck không hợp lệ (che khuất).
    //
    // suspend (trước đây fun thường) vì clickToMask() là suspend — đổi
    // TẤT CẢ call site gọi hàm này thành suspend theo (chỉ 1 call site,
    // trong runMultiPassCascade(), vốn đã suspend sẵn — không lan rộng).
    //
    // GIỚI HẠN THẬT (đọc trước khi tin đã hết rủi ro chồng lấn mask):
    // (1) điểm click NECK vẫn có thể bị người khác che HOÀN TOÀN trong
    // cảnh vật lộn dày đặc (vd bị ôm ghì từ phía sau) — SAM khi đó nhiều
    // khả năng phân đoạn nhầm sang người đang che, KHÔNG có cách nào phát
    // hiện việc này tự động trong code (cần review ảnh thật bằng mắt);
    // (2) CHƯA build-test — chỉ xác nhận cú pháp hợp lệ, tái dùng nguyên
    // API clickToMask() đã chạy được ở buildMaskFileRefined(); (3) SAM
    // vẫn có thể trả mask rỗng/lỗi bình thường (đã có từ mục 21) — case
    // đó rơi về fallback rectangle-feather CŨ, không phải lỗi mới.
    // mục 172 TECHNICAL_STATUS.md — TỰ SỬA 1 chỗ overclaim của CHÍNH mục
    // 172 (lượt trước): tài liệu lúc đó nói sẽ tái dùng NGUYÊN hàm này
    // (đã có SAM) để dựng `region_masks` cho pipeline Regional-Mask mới —
    // nhưng SAM (`maskFixer.clickToMask`) cần 1 ẢNH THẬT ĐàCÓ để click
    // segment. Regional-Mask cần mask này làm INPUT cho LƯỢT SINH ẢNH ĐẦU
    // TIÊN (chưa có ảnh nào tồn tại) — khác hẳn Cascade (mục 168, luôn có
    // ảnh từ lượt trước để SAM). Phát hiện lúc THỰC SỰ nối dây (không phải
    // lúc viết tài liệu suy đoán) — đúng bài học mục 170 "code sai lộ ra
    // khi nối, không phải khi tưởng tượng". Sửa: `imagePath` giờ
    // NULLABLE — null = CHỦ Ý bỏ qua SAM (không có ảnh để click), dùng
    // thẳng rectangle+feather, KHÔNG dựa vào exception ngầm (imagePath
    // rỗng/sai gây `clickToMask` throw) như cách làm tắt có thể gây hiểu
    // nhầm đây là lỗi thay vì hành vi CHỦ Ý.
    // mục 201 TECHNICAL_STATUS.md — bao lồi (convex hull) của các khớp
    // xương hợp lệ, thay cho hình chữ nhật thô (mục 169/renderCharacterMask,
    // buildCharacterBodyMaskFile fallback) khi KHÔNG có ảnh thật để dùng
    // SAM (trước khi sinh ảnh — SAM cần ảnh đã tồn tại, xem giải thích đầy
    // đủ ở comment buildCharacterBodyMaskFile ngay dưới). Thuật toán chuẩn
    // Andrew's monotone chain (O(n log n)) — không suy đoán, đây là thuật
    // toán bao lồi 2D phổ biến nhất, đối chiếu đúng cấu trúc chuẩn: sort
    // theo (x,y) → dựng nửa dưới + nửa trên bằng cross-product loại điểm
    // lõm → nối lại. Input/output đều toạ độ CHUẨN HOÁ [0,1] (khớp đúng
    // đơn vị `xs`/`ys` đã có sẵn trong buildCharacterBodyMaskFile).
    //
    // GIỚI HẠN THẬT: bao lồi vẫn KHÔNG PHẢI segmentation thật — 1 người
    // dang tay/chân tạo khoảng TRỐNG giữa các chi (vd giữa 2 chân khi
    // đứng dạng) vẫn bị tô ĐẦY bên trong bao lồi (đặc điểm cố hữu của
    // convex hull — không lõm được), khác hẳn SAM tách đúng viền THẬT kể
    // cả phần lõm. Vẫn là gần đúng hình học, chỉ CHÍNH XÁC HƠN chữ nhật
    // (bám theo hướng thật của dáng người thay vì luôn thẳng trục ngang/
    // dọc — quan trọng nhất cho tư thế nghiêng/chéo, nơi chữ nhật lãng phí
    // nhiều diện tích nhất và dễ chồng lấn người bên cạnh nhất).
    private fun convexHull(points: List<Pair<Float, Float>>): List<Pair<Float, Float>> {
        if (points.size < 3) return points
        val sorted = points.distinct().sortedWith(compareBy({ it.first }, { it.second }))
        if (sorted.size < 3) return sorted
        fun cross(o: Pair<Float, Float>, a: Pair<Float, Float>, b: Pair<Float, Float>): Float =
            (a.first - o.first) * (b.second - o.second) - (a.second - o.second) * (b.first - o.first)
        val lower = mutableListOf<Pair<Float, Float>>()
        for (p in sorted) {
            while (lower.size >= 2 && cross(lower[lower.size - 2], lower[lower.size - 1], p) <= 0f) lower.removeAt(lower.size - 1)
            lower.add(p)
        }
        val upper = mutableListOf<Pair<Float, Float>>()
        for (p in sorted.asReversed()) {
            while (upper.size >= 2 && cross(upper[upper.size - 2], upper[upper.size - 1], p) <= 0f) upper.removeAt(upper.size - 1)
            upper.add(p)
        }
        lower.removeAt(lower.size - 1)
        upper.removeAt(upper.size - 1)
        return lower + upper
    }

    private suspend fun buildCharacterBodyMaskFile(
        imagePath: String?, skeletonData: FloatArray, personIdx: Int, fullW: Int, fullH: Int,
        outFile: File, panelIndex: Int, outDir: File
    ): Boolean {
        val floatsPerPerson = 18 * 4
        val base = personIdx * floatsPerPerson
        if (base + floatsPerPerson > skeletonData.size) return false
        val xs = mutableListOf<Float>(); val ys = mutableListOf<Float>()
        for (j in 0 until 18) {
            val x = skeletonData[base + j * 4]; val y = skeletonData[base + j * 4 + 1]
            if (x > 0f && y > 0f) { xs.add(x); ys.add(y) }
        }
        if (xs.size < 3) return false // quá ít khớp hợp lệ — không đủ tin cậy để khoanh vùng

        // Padding tỷ lệ theo kích thước bbox (không phải hằng số px cố định
        // — người chiếm ít diện tích khung hình cần padding NHỎ hơn tuyệt
        // đối so với người chiếm nhiều, giữ đúng tỷ lệ tương đối).
        val bboxW = (xs.max() - xs.min()) * fullW; val bboxH = (ys.max() - ys.min()) * fullH
        val padX = (bboxW * 0.15f).coerceAtLeast(20f); val padY = (bboxH * 0.15f).coerceAtLeast(20f)
        val l = (xs.min() * fullW - padX).coerceAtLeast(0f)
        val t = (ys.min() * fullH - padY).coerceAtLeast(0f)
        val r = (xs.max() * fullW + padX).coerceAtMost(fullW.toFloat())
        val b = (ys.max() * fullH + padY).coerceAtMost(fullH.toFloat())
        if (r <= l || b <= t) return false

        // Thử SAM trước — CHỈ nếu có ảnh thật (imagePath != null). Click
        // point ưu tiên neck (index 1) thật của CHÍNH người này, fallback
        // tâm bbox nếu neck che khuất/không hợp lệ.
        var samMask: Bitmap? = null
        if (imagePath != null && maskFixer.isReady()) {
            val neckX = skeletonData[base + 1 * 4]; val neckY = skeletonData[base + 1 * 4 + 1]
            val clickX = if (neckX > 0f && neckY > 0f) neckX * fullW else (l + r) / 2f
            val clickY = if (neckX > 0f && neckY > 0f) neckY * fullH else (t + b) / 2f
            val samPath = try {
                maskFixer.clickToMask(imagePath, clickX, clickY, outDir, panelIndex)
            } catch (ex: Exception) { null }
            if (samPath != null) {
                val raw = BitmapFactory.decodeFile(samPath)
                if (raw != null) {
                    samMask = if (raw.width != fullW || raw.height != fullH)
                        Bitmap.createScaledBitmap(raw, fullW, fullH, true).also { if (it !== raw) raw.recycle() }
                    else raw
                }
            }
        }

        val mask = Bitmap.createBitmap(fullW, fullH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(mask)
        canvas.drawColor(Color.BLACK)
        if (samMask != null) {
            canvas.drawBitmap(samMask, 0f, 0f, null)
            samMask.recycle()
        } else {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE; style = Paint.Style.FILL
                maskFilter = BlurMaskFilter(20f, BlurMaskFilter.Blur.NORMAL) // feather rộng hơn buildInteractionMaskFile (vùng lớn hơn, cần chuyển mượt hơn)
            }
            // mục 201 TECHNICAL_STATUS.md — bao lồi thay hình chữ nhật khi
            // KHÔNG có SAM (không có ảnh thật để click, trước lúc sinh ảnh
            // — xem giải thích ở comment convexHull() phía trên). Nới rộng
            // 15% ra ngoài từ TÂM bao lồi (cùng tinh thần margin 10-15% đã
            // dùng cho hình chữ nhật cũ, không phải số tự bịa) — tránh cắt
            // cụt sát đúng rìa khớp ngoài cùng.
            val hullPts = convexHull(xs.zip(ys))
            if (hullPts.size >= 3) {
                val cx = hullPts.sumOf { it.first.toDouble() }.toFloat() / hullPts.size
                val cy = hullPts.sumOf { it.second.toDouble() }.toFloat() / hullPts.size
                val path = android.graphics.Path()
                hullPts.forEachIndexed { idx, (hx, hy) ->
                    val ex = (cx + (hx - cx) * 1.15f).coerceIn(0f, 1f) * fullW
                    val ey = (cy + (hy - cy) * 1.15f).coerceIn(0f, 1f) * fullH
                    if (idx == 0) path.moveTo(ex, ey) else path.lineTo(ex, ey)
                }
                path.close()
                canvas.drawPath(path, paint)
            } else {
                // Suy biến (hiếm — vd toàn bộ khớp gần như thẳng hàng) —
                // rơi về hình chữ nhật CŨ, an toàn, không phải lỗi.
                canvas.drawRect(l, t, r, b, paint)
            }
        }
        FileOutputStream(outFile).use { fos -> mask.compress(Bitmap.CompressFormat.PNG, 100, fos) }
        mask.recycle()
        return true
    }

    // mục 115/117 TECHNICAL_STATUS.md — Multi-Pass Inpainting Cascade:
    // TUẦN TỰ từng nhân vật trong scene, inpaint lại đúng vùng cơ thể
    // người đó bằng img2img+IP-Adapter (sdImg2ImgWithReferenceAndPose,
    // mục 115), dùng CHÍNH anchor image của người đó ở cường độ cao
    // (ipStaticScale cao hơn mặc định) — "khoá" danh tính từng người sau
    // khi lượt nền (multiChar mask, N người CÙNG LÚC) đã dựng bố cục
    // chung nhưng có thể hoà lẫn đặc điểm khi N lớn.
    //
    // GIỚI HẠN THẬT: TUẦN TỰ (không song song) — mỗi lượt SỬA TRÊN kết
    // quả lượt trước (đúng ý nghĩa "cascade"), nên tốn thêm ĐÚNG N lượt
    // sinh ảnh nữa (N = sceneChars.size), chậm hơn hẳn — mục 126 đã đổi
    // enableMultiPassCascade mặc định thành BẬT (vì đây là fix đúng-sai,
    // không phải sở thích) — field giờ dùng để user TẮT thủ công (opt-out)
    // trên máy yếu ưu tiên tốc độ. Nếu 1 người bị lỗi (mask build
    // thất bại — quá ít khớp hợp lệ, occlusion nặng), BỎ QUA người đó
    // (giữ nguyên ảnh hiện có), KHÔNG dừng cả cascade — 1 người lỗi không
    // nên làm hỏng những người đã sửa đúng trước đó trong cùng ảnh.
    // mục 125 TECHNICAL_STATUS.md — user chỉ ra ĐÚNG: mục 124 tra cứu ra
    // giải pháp thật (masked cross-attention) rồi bỏ cuộc vì độ phức tạp
    // — nhưng bỏ qua giải pháp ĐÃ CÓ SẴN trong chính dự án. Multi-Pass
    // Cascade (mục 117) vốn đã tách N người thành N LƯỢT SINH ẢNH RIÊNG
    // BIỆT (không phải 1 lượt chung dùng attention-mask) — đây CHÍNH LÀ
    // cách né hoàn toàn vấn đề "attribute binding" (mục 123/124) MÀ KHÔNG
    // CẦN đụng attention nội bộ: mỗi lượt cascade chỉ có ĐÚNG 1 người
    // trong prompt text, nên không có "nhiều chủ thể chia sẻ 1 đoạn text"
    // để mà nhầm lẫn — vấn đề KHÔNG TỒN TẠI trong kiến trúc cascade, khác
    // hẳn nhánh multiChar-mask 1-lượt (nơi vấn đề THẬT SỰ tồn tại).
    //
    // BUG THẬT phát hiện khi soát lại: bản mục 117 dùng chung `effPrompt`
    // (prompt CHUNG cho cả scene, mô tả TẤT CẢ nhân vật) cho MỌI lượt
    // cascade — hoàn toàn PHÍ tiềm năng "cô lập từng người" mà cascade
    // vốn có, biến cascade thành "vẽ lại cùng 1 prompt chung N lần" thay
    // vì "N lượt, mỗi lượt ĐÚNG 1 người". Đã sửa: build prompt RIÊNG cho
    // từng nhân vật (anchorPrompt + headsTallPromptTag CỦA RIÊNG người đó,
    // an toàn tiêm vì lượt cascade ĐÓ chỉ có 1 người trong text — đúng
    // điều kiện injectHeadsTallTag() yêu cầu, mục 123), cùng khuôn mẫu
    // buildRegionPrompts() đã dùng cho Regional Prompting.
    private suspend fun runMultiPassCascade(
        basePath: String, sceneChars: List<String>, multiCharAnchors: List<String>,
        skeletonData: FloatArray, scenePrompt: String, negPrompt: String, allChars: List<Character>,
        stylePrompt: String, width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        denoiseStrength: Float, panelIndex: Int, outDir: File,
        // mục 168 TECHNICAL_STATUS.md — "Per-Character Expression". null =
        // hành vi CŨ 100% (mọi call site cũ không truyền 2 tham số này vẫn
        // biên dịch/chạy y hệt trước, nhờ default). Chỉ 1 call site (nhánh
        // multiChar trong generatePanels()) truyền giá trị thật — xem đó.
        characterExpressions: Map<String, String> = emptyMap(),
        promptStyle: PromptStyle = PromptStyle.TAG_BASED,
        // mục 170 TECHNICAL_STATUS.md — trả lời "cascade có giải quyết được
        // đúng ai-trước-ai-sau khi 6 người quần/vật lộn không": TRƯỚC ĐÂY
        // vòng lặp cascade luôn xử lý theo ĐÚNG thứ tự `sceneChars` (thứ
        // tự ổn định để mapping slot, KHÔNG mang ý nghĩa "ai gần máy quay
        // hơn") — 2 mask chồng lấn thì người xử lý SAU luôn "thắng" vùng
        // chồng lấn dù người đó có nên đứng SAU (xa hơn) người kia hay
        // không, hoàn toàn NGẪU NHIÊN theo thứ tự tên. Map này (rỗng =
        // hành vi CŨ 100%, mọi factor coi như 1f, sort ổn định giữ nguyên
        // thứ tự cũ) cho phép xử lý người XA trước, người GẦN sau — người
        // gần máy quay hơn thắng đúng vùng chồng lấn, khớp quy ước đã
        // dùng cho `scalePersonAroundHip()`/`depthScale` (mục 121: factor
        // >1 = gần/to hơn, <1 = xa/nhỏ hơn).
        depthOrder: Map<String, Float> = emptyMap()
    ): String {
        var currentPath = basePath
        // Sort ỔN ĐỊNH (Kotlin sortedBy giữ nguyên thứ tự tương đối khi
        // key bằng nhau) — depthOrder rỗng/thiếu tên -> mọi factor = 1f ->
        // kết quả sort giống hệt thứ tự gốc `sceneChars.indices`, KHÔNG
        // đổi hành vi cho panel không có depth_scale (đa số trường hợp).
        val processingOrder = sceneChars.indices.sortedBy { idx -> depthOrder[sceneChars[idx]] ?: 1f }
        for (i in processingOrder) {
            val maskFile = File(outDir, "panel_%03d_cascade_mask_%d.png".format(panelIndex, i))
            val built = buildCharacterBodyMaskFile(currentPath, skeletonData, i, width, height, maskFile, panelIndex, outDir)
            if (!built) {
                log("  ⚠ Cascade: bỏ qua nhân vật '${sceneChars[i]}' (không đủ khớp xương hợp lệ để khoanh vùng)")
                continue
            }
            // Prompt CÔ LẬP cho ĐÚNG người này — KHÔNG dùng lại prompt
            // chung của scene (điểm khác biệt cốt lõi so với bản cũ, xem
            // giải thích ở docstring hàm). anchorPrompt + headsTallPromptTag
            // đặt TRƯỚC prompt scene chung để mô hình ưu tiên đúng danh
            // tính/tỷ lệ người này khi denoise lại vùng mask của họ.
            val ch = allChars.find { it.name == sceneChars[i] }
            val headsTag = ch?.boneProportions?.headsTallPromptTag()?.takeIf { it.isNotEmpty() }
            // mục 168 TECHNICAL_STATUS.md — Per-Character Expression: nếu
            // scene.characterExpressions có override RIÊNG cho người này,
            // tra LLMParser.resolveExpressionTag() và ĐẶT TRƯỚC prompt
            // (cùng vị trí ưu tiên với headsTag ở trên) — front-loading là
            // nguyên tắc trọng số đã dùng xuyên suốt dự án cho checkpoint
            // đang active (xem LLMParser.promptTemplate()). KHÔNG xoá tag
            // biểu cảm NỀN đã có sẵn trong `scenePrompt` (là tag của
            // `scene.expression` dùng chung, do LLM viết vào lúc tạo
            // `scenePrompt` gốc) — chỉ ĐÈ TRỌNG SỐ bằng cách đặt tag riêng
            // lên trước, không phải xoá sạch chuỗi cũ. GIỚI HẠN THẬT: đây
            // là giải pháp thực dụng (front-load), không phải cô lập tuyệt
            // đối như masked cross-attention thật (mục 124 đã tra cứu,
            // quyết định không viết lại UNet/attention) — vẫn có khả năng
            // tag nền cũ "kéo ngược" phần nào nếu 2 tag mâu thuẫn mạnh, dù
            // ĐÃ giảm đáng kể nhờ mỗi lượt cascade chỉ có 1 người trong
            // vùng mask thật sự bị vẽ lại.
            val exprOverride = characterExpressions[sceneChars[i]]
            val exprTag = exprOverride?.let { LLMParser.resolveExpressionTag(it, promptStyle) }
            val isolatedPrompt = (ch?.anchorPrompt?.let { "$it, " } ?: "") +
                (headsTag?.let { "$it, " } ?: "") +
                (exprTag?.let { "$it, " } ?: "") + scenePrompt + ", " + stylePrompt
            try {
                currentPath = imagePipeline.inpaintCharacterInCascade(
                    panelIndex = panelIndex, characterOrderInCascade = i,
                    prompt = isolatedPrompt, negativePrompt = negPrompt,
                    basePanelPath = currentPath, maskPath = maskFile.absolutePath,
                    referenceImagePath = multiCharAnchors[i], skeletonData = skeletonData,
                    denoiseStrength = denoiseStrength, width = width, height = height,
                    steps = steps, cfgScale = cfgScale, seed = seed, outDir = outDir,
                    onProgress = { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } }
                )
                log("  ✓ Cascade: đã khoá danh tính+tỷ lệ '${sceneChars[i]}' (lượt ${i + 1}/${sceneChars.size}, prompt cô lập riêng người này)")
            } catch (ex: Exception) {
                log("  ⚠ Cascade: lỗi khi xử lý '${sceneChars[i]}' (${ex.message}), giữ nguyên kết quả trước đó")
            }
        }
        return currentPath
    }

    /**
     * Giải phóng toàn bộ native engine (SD/ESRGAN/MobileSAM) giữa các chương
     * trong batch công nghiệp — mục 77 TECHNICAL_STATUS.md (RAM Purge Loop).
     *
     * Gọi từ MainViewModel.runIndustrialBatch() sau khi lưu xong 1 chương,
     * TRƯỚC khi delay và nạp chương tiếp theo. LLM đã được free() ngay sau
     * parseStory() trong prepareChapter() từ trước — không cần free lại LLM
     * ở đây.
     *
     * CHƯA BUILD-TEST — CHƯA xác nhận sdFree() an toàn gọi giữa chừng batch
     * (chỉ biết an toàn khi app dừng hoàn toàn). Bọc try/catch: lỗi purge
     * KHÔNG làm chết batch, chỉ log cảnh báo và tiếp tục.
     */
    suspend fun purgeEnginesBetweenChapters() {
        try {
            // ImagePipeline.freeAll() (đã có sẵn từ trước) giải phóng MỌI
            // handle native (sd/sdAugmented/sdRegional/esrgan/yolo) — dùng
            // lại nguyên hàm này, KHÔNG viết hàm free riêng mới.
            imagePipeline.freeAll()
            if (maskFixerLazy.isInitialized()) maskFixer.close()
            log("  🧹 RAM Purge: đã giải phóng SD/SAM engine giữa chương")
        } catch (ex: Exception) {
            log("  ⚠ RAM Purge lỗi (${ex.message}) — tiếp tục batch dù không purge")
        }
    }

    // Hợp nhất mask TỪNG VÙNG thành 1 file mask duy nhất cho cả panel (giữ
    // NGUYÊN hành vi "1 lần img2imgFix cho cả panel", KHÔNG đổi thành N lần
    // gọi/N vùng — tránh tốn thêm N lần sinh ảnh chỉ để có mask chính xác
    // hơn, đúng tinh thần "hiệu suất cao" đã thống nhất từ mục 17).
    //
    // TỪNG vùng: thử MobileSAM (click vào TÂM bounding box pose suy ra —
    // dùng bounding box làm "gợi ý điểm click" chứ không dùng trực tiếp làm
    // mask, khác hẳn cách dùng ở ManualMaskFixer nơi user tự chạm) trước,
    // fallback rectangle-có-feather nếu SAM không sẵn sàng/lỗi/mask rỗng.
    // Hợp nhất kiểu OR (LIGHTEN) — vùng nào đã trắng từ region trước vẫn
    // giữ trắng khi region sau chồng lấn.
    //
    // RỦI RO CHƯA KIỂM CHỨNG (thêm vào rủi ro đã có ở mục 17/21, CHƯA build-
    // test): (1) click vào TÂM bounding box suy từ pose keypoint có thể
    // không rơi đúng vào giữa mặt/tay thật (vd tay giơ chéo, bounding box
    // lệch tâm so với khối vật lý) — MobileSAM có thể phân đoạn nhầm vật
    // thể khác gần đó; (2) kích thước mask MobileSAM trả về CÓ THỂ khác
    // đúng bằng (w,h) ảnh gốc (tài liệu không xác nhận rõ, xem mục 21) —
    // đã tự động scale về đúng (w,h) trước khi hợp nhất để phòng hờ,
    // nhưng CHƯA xác nhận scale này có cần thiết/đúng thật hay không.
    private suspend fun buildMaskFileRefined(
        imagePath: String, regions: List<android.graphics.Rect>, w: Int, h: Int,
        outFile: File, panelIndex: Int, outDir: File
    ) {
        val combined = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = Canvas(combined)
        canvas.drawColor(Color.BLACK)

        for (r in regions) {
            var refined: android.graphics.Bitmap? = null
            if (maskFixer.isReady()) {
                val samMaskPath = try {
                    maskFixer.clickToMask(imagePath, r.centerX().toFloat(), r.centerY().toFloat(), outDir, panelIndex)
                } catch (ex: Exception) { null }
                if (samMaskPath != null) refined = BitmapFactory.decodeFile(samMaskPath)
            }
            if (refined != null) {
                val scaled = if (refined.width != w || refined.height != h)
                    android.graphics.Bitmap.createScaledBitmap(refined, w, h, true) else refined
                val unionPaint = Paint().apply {
                    xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.LIGHTEN)
                }
                canvas.drawBitmap(scaled, 0f, 0f, unionPaint)
                if (scaled !== refined) scaled.recycle()
                refined.recycle()
            } else {
                // Fallback rectangle CÓ FEATHER (BlurMaskFilter làm mềm
                // biên) — cải tiến so với rectangle cứng bản cũ (mục 17 rủi
                // ro #3), bán kính blur tỉ lệ theo kích thước vùng (vùng nhỏ
                // như mắt/miệng không bị blur quá tay nuốt mất vùng cần sửa).
                val featherPaint = Paint().apply {
                    color = Color.WHITE; isAntiAlias = true
                    maskFilter = android.graphics.BlurMaskFilter(
                        (minOf(r.width(), r.height()) * 0.15f).coerceAtLeast(8f),
                        android.graphics.BlurMaskFilter.Blur.NORMAL
                    )
                }
                canvas.drawRect(r.left.toFloat(), r.top.toFloat(), r.right.toFloat(), r.bottom.toFloat(), featherPaint)
            }
        }
        FileOutputStream(outFile).use { out -> combined.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out) }
        combined.recycle()
    }

    // Tính toạ độ khung xương ĐÃ RETARGET cho 1 panel (mục 32/33
    // TECHNICAL_STATUS.md) — thay thế hoàn toàn việc gửi tên template cho
    // native tự đọc/chọn. Đọc thư viện, chọn variant khớp góc mong muốn,
    // gán TƯỜNG MINH scene.characters[i] <-> variant.people[i] (giải quyết
    // luôn lỗ hổng "skeleton không biết ai là ai" — mục 12), retarget theo
    // BoneProportions riêng từng nhân vật, cuối cùng flatten thành FloatArray
    // đúng contract native mong đợi (mỗi người 18*4 float: x,y,z,visible).
    // characterOrder: mặc định = scene.characters (thứ tự gốc, hành vi cũ
    // 100%) — nhánh Regional Prompting (mục 88 TECHNICAL_STATUS.md) truyền
    // regionOrder (thứ tự CỘT sau khi user kéo-thả) thay vì mặc định, để
    // khung xương render ĐÚNG cột khớp với prompt của cột đó. KHÔNG sửa
    // default cho mọi call site khác — chỉ nhánh Regional Prompting cần
    // quan tâm thứ tự vì đây là kiến trúc DUY NHẤT ghép N người vào N vùng
    // không gian cố định trong 1 ảnh; các nhánh khác (multiChar/augmented)
    // không có khái niệm "cột" nên thứ tự characterProportions không ảnh
    // hưởng gì tới việc RENDER (chỉ ảnh hưởng edge case hiếm: 2 nhân vật
    // trùng hệt boneProportions, không đáng kể).
    // mục 118 TECHNICAL_STATUS.md — helper DÙNG CHUNG, tránh viết lặp công
    // thức sort ở nhiều nơi (resolveSkeletonData + 2 chỗ khai báo sceneChars)
    // dễ lệch nhau theo thời gian. Sort theo vị trí CỐ ĐỊNH trong allChars
    // (danh sách nhân vật CHÍNH của truyện, không đổi theo scene) — IDEMPOTENT
    // theo TẬP nhân vật (không phụ thuộc thứ tự đầu vào): cùng 1 tập nhân
    // vật luôn ra ĐÚNG 1 thứ tự, bất kể gọi hàm này với input đã sort hay
    // chưa — nên gọi ở NHIỀU nơi độc lập (sceneChars lẫn resolveSkeletonData)
    // vẫn tự động cho kết quả khớp nhau, không cần truyền tay xuyên suốt.
    private fun stableCharacterOrder(names: List<String>, allChars: List<Character>): List<String> =
        names.sortedBy { name -> allChars.indexOfFirst { it.name == name }.let { if (it < 0) Int.MAX_VALUE else it } }

    private fun resolveSkeletonData(
        poseTemplate: String, poseAngle: String, scene: Scene, story: Story,
        characterOrder: List<String> = scene.characters,
        // mục 161 TECHNICAL_STATUS.md (đợt 2) — null = hành vi cũ 100%
        // (đúng cho 4 call site KHÔNG nối — runConditioningComparisonTest,
        // đó là test conditioning, không phải sinh panel thật theo chương,
        // cùng lý do đã áp dụng cho getCharacterAnchor()/regeneratePanel()
        // trước đó). Có giá trị -> boneProportions dùng để retarget khung
        // xương PHẢN ÁNH ĐÚNG "nhân vật lớn lên" (mục CharacterAnchorVersion
        // .boneProportionsOverride) thay vì luôn dùng tỷ lệ CỐ ĐỊNH cả
        // truyện — nếu không có bước này, ảnh anchor mới (VD người lớn)
        // nhưng khung xương ControlNet vẫn co theo tỷ lệ TRẺ EM cũ, gây
        // đúng loại lỗi "hoà lẫn thịt/tỷ lệ sai" mà PDF audit ngoài cảnh
        // báo (mục 146, phần "Giải phẫu & Tương tác Phức tạp").
        chapterNumber: Int? = null
    ): FloatArray {
        // mục 251 — khung xương BỐ CỤC lấy từ InteractDiffusion (đúng số người) thay khung xương mẫu; bỏ qua retarget tỉ lệ nhân vật/neo mặt đất.
        scene.layoutSkeleton?.takeIf { InteractionLayout.isValidLayout(it, characterOrder.size) }?.let { return it.toFloatArray() }
        if (poseTemplate.isBlank()) return FloatArray(0)
        // mục 161 TECHNICAL_STATUS.md (đợt 12) — ĐỔI sang
        // loadPoseTemplateVariants(poseTemplate) (đọc ĐÚNG 1 template) thay
        // vì loadPoseLibrary() (đọc TOÀN BỘ thư viện MỌI template, tích luỹ
        // suốt lịch sử dùng app) rồi mới lọc — hàm NÀY chạy MỖI PANEL sinh
        // ra (hot-path thật sự, không phải lý thuyết), nên đây là chỗ lợi
        // ích rõ nhất trong toàn bộ đợt tách file lần này.
        val variants = storyManager.loadPoseTemplateVariants(poseTemplate)
        if (variants.isEmpty()) return FloatArray(0)
        val chosen = variants.find { it.angle == poseAngle } ?: variants.first()

        val allChars = applyActiveAnchorVersion(storyManager.loadStory(story.id)?.characters ?: story.characters, chapterNumber)
        // mục 118 TECHNICAL_STATUS.md — user phát hiện đúng: nhân vật "lúc
        // cao bằng vai người kia, khung khác lại cao hơn/thấp hơn" dù
        // boneProportions KHÔNG hề đổi. Nguyên nhân THẬT: characterOrder
        // (tham số mặc định = scene.characters) trước đây dùng TRỰC TIẾP
        // thứ tự LLM viết tên nhân vật trong văn bản scene — thứ tự này
        // ĐỔI tuỳ câu văn ("A và B" khung này, "B và A" khung khác), map
        // THẲNG vào variant.people[i]. savePoseVariant() KHÔNG có bước
        // chuẩn hoá tỷ lệ giữa các slot khi lưu — nếu template gốc không
        // đối xứng tuyệt đối giữa people[0]/people[1] (gần như chắc chắn
        // không, vì mỗi template trace từ 1 ảnh/video riêng), nhân vật đổi
        // slot ngẫu nhiên giữa các khung -> tỷ lệ tương đối "nhảy" theo,
        // dù KHÔNG có gì trong dữ liệu nhân vật thay đổi.
        //
        // ĐÃ SỬA: stableCharacterOrder() thay vì dùng thẳng characterOrder
        // truyền vào. sceneChars (nơi build multiCharAnchors — ảnh danh
        // tính) CŨNG được sort CÙNG công thức ở nơi khai báo (dòng ~1342/
        // ~1747) — nhờ tính idempotent theo tập nhân vật, KHÔNG cần đồng
        // bộ tay giữa 2 nơi, tự động khớp nhau dù gọi độc lập.
        //
        // GIỚI HẠN THẬT CÒN LẠI (chưa giải quyết, không giả vờ đã xong):
        // (1) Nếu BẢN THÂN template gốc vẽ people[0]/people[1] KHÔNG đúng
        //     tỷ lệ chiều cao tương đối thật (lỗi lúc trace/lưu, không có
        //     công cụ kiểm tra trực quan khi lưu pose) — cố định slot chỉ
        //     làm sai số đó ỔN ĐỊNH (không còn nhảy lung tung), KHÔNG sửa
        //     được sai số gốc nếu có. Cần thêm công cụ xem trước tỷ lệ khi
        //     lưu template (PoseEditorScreen) — CHƯA làm, việc riêng.
        // (2) Phối cảnh gần/xa: trường PoseKeypoint.z (độ sâu) HIỆN CHỈ
        //     dùng để dựng depth-hint cho ControlNet (MangaPipeline dòng
        //     ~615), KHÔNG được dùng để tự động scale kích thước theo
        //     khoảng cách camera (gần to hơn/xa nhỏ hơn). Toàn bộ tỷ lệ
        //     gần-xa phụ thuộc HOÀN TOÀN vào cách template gốc được vẽ tay
        //     — hệ thống KHÔNG tự bù trừ phối cảnh. Xây dựng logic scale-
        //     theo-z cần biết đơn vị z chuẩn hoá thế nào (hiện KHÔNG có
        //     định nghĩa rõ ràng — z có thể là ước lượng thô của người
        //     trace, không phải đơn vị mét/khoảng cách thật) — làm ẩu sẽ
        //     RA SAI THÊM một cách khác, không làm ở đây, cần thiết kế
        //     riêng (định nghĩa lại ý nghĩa z trong pose_library.json).
        val stableOrder = stableCharacterOrder(characterOrder, allChars)
        val characterProportions = stableOrder.map { name ->
            allChars.find { it.name == name }?.boneProportions ?: BoneProportions()
        }
        val retargeted = PoseRetargeter.retargetVariant(chosen, characterProportions)

        // mục 122 TECHNICAL_STATUS.md — user chỉ ra ĐÚNG: truyện chữ/kịch
        // bản HẦU NHƯ KHÔNG BAO GIỜ nói tường minh "A đứng gần ống kính" —
        // yêu cầu LLM tự phán đoán field depth_scale RIÊNG (mục 121) gần
        // như không bao giờ có căn cứ để kích hoạt, dù đã hướng dẫn kỹ.
        // ĐÃ SỬA: suy luận TỰ ĐỘNG từ field cameraAngle — field này LLM
        // LUÔN điền cho MỌI panel (không phải phán đoán mới, đã có sẵn từ
        // đầu pipeline), và cameraAngle="close-up"/"extreme-close-up" khi
        // có 2+ nhân vật GẦN NHƯ LUÔN ngụ ý 1 người là chủ thể chính (gần
        // ống kính hơn), người còn lại là hậu cảnh — đúng quy ước điện ảnh/
        // manga chuẩn (không cần LLM tự nghĩ thêm gì mới, chỉ áp dụng suy
        // luận có sẵn). depthScale tường minh (nếu LLM/user có điền) LUÔN
        // được ưu tiên hơn — suy luận tự động CHỈ là fallback khi rỗng.
        val effectiveDepthScale = if (scene.depthScale.isNotEmpty()) scene.depthScale
                                   else inferDepthScaleFromCameraAngle(scene)

        // mục 121 TECHNICAL_STATUS.md — "Depth Scale": áp dụng SAU khi
        // retarget tỷ lệ xương xong (bước ĐẠO DIỄN/BỐ CỤC, tách biệt hoàn
        // toàn khỏi tỷ lệ xương CỦA nhân vật — xem docstring Scene.depthScale).
        // stableOrder[i] khớp ĐÚNG retargeted[i] (cùng thứ tự — retargetVariant
        // xử lý theo variant.people, giữ nguyên chỉ số i tương ứng characterProportions
        // vốn được build TỪ stableOrder cùng chỉ số i).
        val depthScaled = retargeted.mapIndexed { i, person ->
            val charName = stableOrder.getOrNull(i)
            val factor = charName?.let { effectiveDepthScale[it] } ?: 1f
            if (factor == 1f) person else scalePersonAroundHip(person, factor)
        }

        val flat = FloatArray(depthScaled.size * 18 * 4)
        var idx = 0
        depthScaled.forEach { person ->
            person.forEach { kp ->
                flat[idx++] = kp.x; flat[idx++] = kp.y; flat[idx++] = kp.z; flat[idx++] = if (kp.visible) 1f else 0f
            }
        }
        return flat
    }

    // mục 121 TECHNICAL_STATUS.md — co giãn TOÀN BỘ khung xương 1 người
    // quanh CHÍNH TÂM HÔNG của người đó theo [factor] (>1 = to hơn/gần máy
    // quay, <1 = nhỏ hơn/xa máy quay). Tách RIÊNG khỏi PoseRetargeter (file
    // đó chỉ lo tỷ lệ xương CỦA nhân vật — ý nghĩa vật lý khác hẳn: "người
    // này cao/thấp" so với "người này đứng gần/xa máy quay trong CẢNH NÀY").
    private fun scalePersonAroundHip(person: List<StoryManager.PoseKeypoint>, factor: Float): List<StoryManager.PoseKeypoint> {
        val rHip = person.getOrNull(8); val lHip = person.getOrNull(11)
        val validHips = listOfNotNull(rHip?.takeIf { it.visible }, lHip?.takeIf { it.visible })
        if (validHips.isEmpty()) return person // không đủ dữ liệu hông hợp lệ — không đoán mù tâm scale, giữ nguyên
        val cx = validHips.map { it.x }.average().toFloat()
        val cy = validHips.map { it.y }.average().toFloat()
        return person.map { kp ->
            if (!kp.visible) kp else kp.copy(x = cx + (kp.x - cx) * factor, y = cy + (kp.y - cy) * factor)
        }
    }

    // mục 122 TECHNICAL_STATUS.md — fallback tự động khi LLM không điền
    // depth_scale tường minh (trường hợp PHỔ BIẾN NHẤT — văn bản gốc hầu
    // như không bao giờ nói tường minh "gần/xa ống kính"). Dùng chính
    // cameraAngle (LLM LUÔN điền field này cho mọi panel, không phải phán
    // đoán mới) làm tín hiệu: cận cảnh + 2+ người -> có 1 người là CHỦ THỂ
    // CHÍNH (gần ống kính hơn), người còn lại làm nền — đúng quy ước điện
    // ảnh/manga chuẩn.
    //
    // "Chủ thể chính" = scene.characters.first() — dùng THỨ TỰ GỐC LLM
    // viết trong JSON scene (chưa qua stableCharacterOrder() của mục 118 —
    // hàm đó sắp lại theo allChars, làm MẤT tín hiệu "ai được nhắc/tập
    // trung trước" mà LLM vốn cố ý đặt lên đầu). Đây là 2 mục đích KHÁC
    // NHAU của cùng 1 danh sách tên: stableOrder dùng để mapping slot
    // template ỔN ĐỊNH, còn thứ tự GỐC ở đây dùng làm tín hiệu TƯỜNG THUẬT
    // (narrative focus) — không mâu thuẫn, chỉ là dùng đúng bản KHÁC nhau
    // của cùng danh sách cho đúng mục đích.
    //
    // GIỚI HẠN THẬT: đây là suy luận YẾU (không chắc chắn như depth_scale
    // tường minh) — hệ số nhẹ hơn hẳn ví dụ LLM tường minh trong schema
    // (1.15/0.85 thay vì 1.4/0.6) để tránh phóng đại quá đà nếu suy luận
    // sai (vd cận cảnh vì lý do khác, không phải phân biệt gần/xa 2
    // người — vd cận cảnh biểu cảm của người ĐANG NÓI, không liên quan
    // khoảng cách camera thật).
    private fun inferDepthScaleFromCameraAngle(scene: Scene): Map<String, Float> {
        val isCloseShot = scene.cameraAngle.lowercase().let { it == "close-up" || it == "extreme-close-up" }
        if (!isCloseShot || scene.characters.size < 2) return emptyMap()
        val focus = scene.characters.first()
        val result = mutableMapOf(focus to 1.15f)
        scene.characters.drop(1).forEach { result[it] = 0.85f }
        return result
    }

    private fun resolveEffective(panel: Panel, settings: GenerationSettings, inheritedSeed: Long? = null): Effective {
        val ov = panel.overrideSettings
        val autoChar = panel.scene.characters.firstOrNull()
        return Effective(
            prompt = ov?.promptOverride ?: panel.prompt,
            negativePrompt = ov?.negativePrompt ?: (panel.negativePrompt + ", " + settings.imageStyle.negPrompt),
            // Thứ tự ưu tiên: override tay > gợi ý LLM (đã validate khớp tên
            // thật trong pose_library.json, xem LLMParser.extractPrompts) >
            // heuristic dò tên theo substring trong CHÍNH thư viện thật của
            // user (KHÔNG còn đoán mù "two_hugging"/"single_standing" như
            // trước — 2 tên đó có thể không hề tồn tại nếu user tự trích
            // pose bằng ảnh/video riêng, template.
            poseTemplate = ov?.poseTemplate ?: panel.suggestedPoseTemplate ?: guessPoseTemplate(panel),
            poseAngle = ov?.poseAngle ?: panel.suggestedPoseAngle,
            width = ov?.width ?: settings.width,
            height = ov?.height ?: settings.height,
            steps = ov?.steps ?: settings.steps,
            cfgScale = ov?.cfgScale ?: settings.cfgScale,
            // mục 71 TECHNICAL_STATUS.md — SỬA BUG THẬT: TRƯỚC ĐÂY seed mặc
            // định = autoChar.hashCode(), nghĩa là MỌI panel của CÙNG 1
            // nhân vật (bất kể bối cảnh/tư thế khác nhau thế nào) luôn nhận
            // ĐÚNG 1 seed — noise nền giống hệt nhau, đúng triệu chứng
            // "panel giống nhau kỳ quái sau vài trăm chương" mà 1 bản review
            // (doc mục 70) cảnh báo. Giờ mặc định NGẪU NHIÊN thật mỗi panel
            // (kotlin.random.Random, KHÔNG deterministic) — trừ khi
            // seedInheritanceEnabled=true VÀ panel này cùng scene.setting
            // (bối cảnh) với panel liền trước → kế thừa đúng seed đó
            // (inheritedSeed, do generatePanels()/vòng lặp panels.forEach
            // tự theo dõi và truyền vào — xem đó để biết cách track).
            seed = ov?.seed ?: inheritedSeed
                ?: kotlin.random.Random.nextLong().let { if (it < 0) -(it + 1) else it },
            characterName = ov?.characterOverride ?: autoChar,
            // mục 171/176 TECHNICAL_STATUS.md — xem comment đầy đủ ở field
            // `modelTier` trong `Effective` phía trên. Chỉ LOG, KHÔNG đổi
            // pipeline nào — SD1.5 luôn được dùng bất kể giá trị này, vì
            // dispatch sinh ảnh (nhánh multiChar/regional/regionalMask/
            // tripleCombo/1-người ngay bên dưới lời gọi resolveEffective())
            // không đọc trường này ở bất kỳ đâu khác.
            modelTier = (ov?.modelTierOverride ?: settings.defaultModelTier).also { tier ->
                // mục 184 TECHNICAL_STATUS.md — SỬA lại log này: TRƯỚC đây
                // (mục 176) khẳng định CỨNG "dùng SD1.5" vì lúc đó CHƯA có
                // dòng code nào đọc field này để dispatch — giờ
                // `dispatchSdxlPanel()` (gọi ngay sau resolveEffective() ở
                // generatePanels()/regeneratePanel()) THẬT SỰ thử SDXL nếu
                // tier=SDXL, nên không còn đúng để khẳng định trước kết quả
                // sẽ luôn là SD1.5 — chỉ LOG THÔNG BÁO trung lập ở đây,
                // log CHI TIẾT thành/bại thật nằm ở dispatchSdxlPanel()/nơi
                // gọi nó (xem log("SD panel...") sau đó).
                if (tier == ImageModelTier.SDXL) {
                    log("  → Panel ${panel.index + 1} yêu cầu SDXL — sẽ thử dùng nếu " +
                        "GenerationSettings.sdxlModelId đã khai VÀ có model .mnn SDXL phù hợp " +
                        "(mục 177-181/184 TECHNICAL_STATUS.md), tự rơi về SD1.5 nếu không đủ điều kiện.")
                }
            }
        )
    }

    // Fallback cuối cùng khi LLM không gợi ý được gì (thư viện rỗng hoặc LLM
    // trả "none") — dò theo substring trong tên THẬT có trong thư viện, thay
    // vì hardcode 1 tên có thể không tồn tại. Rỗng -> "" ; đã xác nhận trong
    // ip_adapter.cpp (pose_templates::pickVariant + templates.find) rằng tên
    // không khớp/rỗng KHÔNG bị bỏ qua — nó rơi vào pose_templates::fallbackStanding()
    // cứng (đứng thẳng 1 người). Nghĩa là kể cả không đoán được gì, ảnh vẫn có
    // ControlNet-Pose tác động (dáng đứng mặc định), không phải "tắt hẳn".
    // Tự động chọn tư thế khớp mô tả kịch bản (mục 6.4/34 TECHNICAL_STATUS.md)
    // — ƯU TIÊN so khớp actionTags (user tự gắn nhãn lúc lưu vào thư viện,
    // vd "hug"/"fight_lock") với từ khoá trong action/description của scene.
    // Đây là fallback CUỐI CÙNG (sau gợi ý LLM đã validate ở buildPrompt())
    // — chỉ chạy khi LLM không gợi ý được gì. KHÔNG tự suy ra tag từ toạ độ
    // khớp (không đáng tin) — tag phải do user gắn tay, đây chỉ so khớp
    // CHUỖI, không phải AI hiểu nghĩa.
    private fun guessPoseTemplate(panel: Panel): String {
        val names = storyManager.listPoseTemplateNames()
        if (names.isEmpty()) return ""
        val wantMulti = panel.scene.characters.size >= 2
        val sceneText = "${panel.scene.action} ${panel.scene.description}".lowercase()

        // Bước 1: so khớp actionTags thật (đáng tin hơn hẳn match tên template)
        val tagsByTemplate = storyManager.listPoseTemplateTags()
        val tagMatch = names
            .mapNotNull { name -> tagsByTemplate[name]?.let { tags -> name to tags.count { tag -> sceneText.contains(tag.lowercase()) } } }
            .filter { it.second > 0 }
            .maxByOrNull { it.second }
        if (tagMatch != null) return tagMatch.first

        // Bước 2: fallback CŨ — so khớp thô trên TÊN template (chỉ hoạt động
        // nếu user đặt tên template có nghĩa, vd "two_hugging") — giữ lại
        // cho thư viện CHƯA gắn tag nào (tương thích ngược).
        val keywords = if (wantMulti) listOf("hug", "together", "two", "group", "multi")
                       else listOf("single", "solo", "alone", "one")
        return names.firstOrNull { name -> keywords.any { name.contains(it, ignoreCase = true) } }
            ?: names.first()
    }

    // Model đã convert riêng cho nhân vật (nếu có) có id = characterId
    // (xem StoryManager.registerConvertedModel — id truyền vào lúc convert
    // chính là characterId). Không có bản convert riêng -> dùng model gốc
    // (settings.sdModelId) — mọi nhân vật CHƯA convert riêng dùng chung 1
    // model, đúng giới hạn đã ghi trong TECHNICAL_STATUS.md.
    private fun resolveModelIdForCharacter(story: Story, characterName: String?, defaultModelId: String): String {
        if (characterName == null) return defaultModelId
        val char = storyManager.loadStory(story.id)?.characters?.find { it.name == characterName } ?: return defaultModelId
        return if (storyManager.hasConvertedModel(char.id)) char.id else defaultModelId
    }

    // mục 93 TECHNICAL_STATUS.md — "So Sánh Thử": người dùng không thể biết
    // chắc checkpoint cần TAG_BASED hay NATURAL_LANGUAGE chỉ bằng cách đọc
    // file — hàm này sinh 2 ảnh THỬ NHANH (độ phân giải/step thấp để nhanh),
    // CÙNG 1 SEED (chỉ khác prompt) để so sánh công bằng — người dùng tự
    // nhìn ảnh nào mạch lạc hơn để quyết, KHÔNG có cách nào app tự "biết"
    // chắc chắn thay người dùng (đã xác nhận qua tra cứu — không có tín
    // hiệu tĩnh nào đọc được từ file checkpoint để suy ra chắc chắn).
    // panelIndex 9001/9002 CỐ Ý cách xa dải index thật của panel truyện
    // (tránh trùng tên file với panel thật đang xử lý song song).
    suspend fun runPromptStyleComparisonTest(
        naturalDescription: String, worldRules: String, stylePrompt: String, settings: GenerationSettings, outDir: File
    ): PromptStyleTestResult = withContext(Dispatchers.IO) {
        // mục 114 TECHNICAL_STATUS.md — dùng optimalConfig thay vì hardcode 0,
        // xem giải thích đầy đủ ở lần sửa đầu tiên trong file này (dòng ~289).
        val stageParser = LLMParser(settings.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
        stageParser.init()
        // mục 130 TECHNICAL_STATUS.md — RÒ BỘ NHỚ NATIVE THẬT phát hiện khi
        // user hỏi về trình tự nạp LLM lúc sinh ảnh: stageParser trước đây
        // KHÔNG BAO GIỜ được free() — mỗi lần chạy "So Sánh Thử" nạp thêm 1
        // model LLM vào RAM native, không bao giờ giải phóng. Bọc try/finally.
        try {
            val tagResult = stageParser.translateStagePrompt(naturalDescription, PromptStage.TXT2IMG, worldRules, stylePrompt, promptStyle = PromptStyle.TAG_BASED)
            val nlResult = stageParser.translateStagePrompt(naturalDescription, PromptStage.TXT2IMG, worldRules, stylePrompt, promptStyle = PromptStyle.NATURAL_LANGUAGE)
            val testSeed = 12345L // cố định — 2 ảnh chỉ khác PROMPT, không khác nhiễu khởi tạo, so sánh công bằng
            val tagImg = imagePipeline.generatePanel(
                panelIndex = 9001, prompt = tagResult.positive, negativePrompt = tagResult.negative, stylePrompt = "",
                width = 384, height = 384, steps = 15, cfgScale = 7f, seed = testSeed, referenceImagePath = null,
                skeletonData = FloatArray(0), useStoryDiffusion = false, outDir = outDir,
                onProgress = { _, _ -> }
            )
            val nlImg = imagePipeline.generatePanel(
                panelIndex = 9002, prompt = nlResult.positive, negativePrompt = nlResult.negative, stylePrompt = "",
                width = 384, height = 384, steps = 15, cfgScale = 7f, seed = testSeed, referenceImagePath = null,
                skeletonData = FloatArray(0), useStoryDiffusion = false, outDir = outDir,
                onProgress = { _, _ -> }
            )
            PromptStyleTestResult(tagImg, nlImg, tagResult.positive, nlResult.positive)
        } finally {
            stageParser.free()
        }
    }

    // mục 95 TECHNICAL_STATUS.md — tự động tạo ảnh tham chiếu "áo rách" cho
    // 1 nhân vật bằng img2img từ chính anchorImagePath hiện có (bootstrap
    // dữ liệu identity, không cần đi tìm/tự vẽ ảnh ngoài — đã bàn ở lượt
    // hỏi trước mục 92). maskPath=null = redraw TOÀN ẢNH (giữ pattern đã
    // dùng ở tryUltrafixRedraw, KHÔNG phải tính năng mới), denoise vừa phải
    // (0.5, thấp hơn hẳn auto-fix giao thoa 0.55-0.75) để GIỮ khuôn
    // mặt/tư thế/bối cảnh, chỉ đổi trạng thái trang phục.
    //
    // Trả về null nếu: nhân vật chưa có anchorImagePath (không có gì để
    // img2img từ đó), hoặc lỗi bất kỳ trong lúc chạy — KHÔNG throw, nơi
    // gọi (UI) tự hiển thị lỗi qua try/catch riêng.
    // CHƯA BUILD-TEST.
    suspend fun generateTornReferenceImage(
        character: Character, worldRules: String, settings: GenerationSettings, outDir: File
    ): String? = withContext(Dispatchers.IO) {
        val srcPath = character.anchorImagePath?.takeIf { File(it).exists() } ?: return@withContext null
        var tearParser: LLMParser? = null
        try {
            tearParser = LLMParser(settings.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
            tearParser.init()
            // PromptStage.INPAINT — đúng ngữ nghĩa "chỉ mô tả chi tiết đang
            // đổi, không mô tả lại toàn cảnh" (mục 93/94), phù hợp việc CHỈ
            // đổi trạng thái trang phục trên ảnh có sẵn.
            val desc = "trang phục của nhân vật (${character.anchorPrompt}) trong tình trạng vừa trải qua " +
                "vật lộn/chiến đấu — vải nhăn nhúm, xộc xệch, rách nhẹ ở vài chỗ hợp lý. KHÔNG đổi khuôn " +
                "mặt, tư thế, hay bối cảnh phía sau — CHỈ đổi trạng thái trang phục."
            val r = tearParser.translateStagePrompt(
                desc, PromptStage.INPAINT, worldRules, settings.imageStyle.stylePrompt,
                promptStyle = resolvePromptStyle(settings)
            )
            imagePipeline.img2imgFix(
                panelIndex = 9500, prompt = r.positive, negativePrompt = r.negative, stylePrompt = "",
                inputPath = srcPath, maskPath = null, denoiseStrength = 0.5f,
                width = 512, height = 512, steps = 25, cfgScale = 7.5f, seed = character.seed,
                ultrafix = false, ultrafixTile = 512, outDir = outDir
            ) { _, _ -> }
        } catch (ex: Exception) {
            log("  ⚠ generateTornReferenceImage lỗi (${ex.message})")
            null
        } finally {
            // mục 130 TECHNICAL_STATUS.md — rò bộ nhớ native, cùng loại phát
            // hiện khi user hỏi về trình tự nạp LLM lúc sinh ảnh (xem giải
            // thích đầy đủ ở tryAutoFixInteractions() phía trên).
            tearParser?.free()
        }
    }

    // mục 102 TECHNICAL_STATUS.md — implement thật cho stub rỗng
    // `MainViewModel.regenerateAnchor()` (mục 14 roadmap: "AI tự phác thảo
    // khuôn mặt nhân vật dựa trên mô tả LLM"). BẢN ĐƠN GIẢN HOÁ so với ý
    // tưởng gốc mục 14 (gốc: sinh 3-4 bản cho user chọn — ĐÂY chỉ sinh 1
    // bản, xem GIỚI HẠN THẬT dưới cho lý do). Dịch anchorPrompt (mô tả tự
    // nhiên, đã có sẵn từ lúc tạo nhân vật) qua LLM đúng PromptStyle
    // checkpoint (mục 93) rồi txt2img THƯỜNG (không dùng IP-Adapter —
    // KHÔNG CÓ ảnh tham chiếu nào để dùng, đây chính là bước TẠO RA ảnh
    // tham chiếu đầu tiên/thay thế). useStoryDiffusion=false,
    // referenceImagePath=null tường minh — không đọc nhầm anchorImagePath
    // CŨ của nhân vật làm reference (mục đích của hàm là THAY THẾ nó).
    //
    // Trả về null nếu lỗi bất kỳ — KHÔNG throw, nơi gọi (UI) tự xử lý.
    // CHƯA BUILD-TEST.
    suspend fun regenerateAnchorImage(
        character: Character, worldRules: String, settings: GenerationSettings, outDir: File
    ): String? = withContext(Dispatchers.IO) {
        var parser: LLMParser? = null
        try {
            parser = LLMParser(settings.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
            parser.init()
            val r = parser.translateStagePrompt(
                character.anchorPrompt, PromptStage.TXT2IMG, worldRules, settings.imageStyle.stylePrompt,
                promptStyle = resolvePromptStyle(settings)
            )
            imagePipeline.generatePanel(
                panelIndex = 9600, prompt = r.positive, negativePrompt = r.negative, stylePrompt = "",
                width = 512, height = 512, steps = 25, cfgScale = 7.5f, seed = character.seed,
                referenceImagePath = null, skeletonData = FloatArray(0), useStoryDiffusion = false,
                outDir = outDir, onProgress = { _, _ -> }
            )
        } catch (ex: Exception) {
            log("  ⚠ regenerateAnchorImage lỗi (${ex.message})")
            null
        } finally {
            // mục 130 TECHNICAL_STATUS.md — rò bộ nhớ native, cùng loại phát
            // hiện khi user hỏi về trình tự nạp LLM lúc sinh ảnh.
            parser?.free()
        }
    }

    // mục 111 TECHNICAL_STATUS.md — "Máy tự động phác thảo, người dùng duyệt
    // chốt": sinh NHIỀU biến thể (mặc định 4) thay vì 1 ảnh duy nhất, để
    // CharacterApprovalSheet (CharactersScreen.kt) hiển thị dạng lưới cho
    // user chọn thay vì tự động gán thẳng. Dùng chung translate LLM MỘT
    // LẦN (prompt không đổi giữa các biến thể), chỉ đổi seed mỗi lần gọi
    // generatePanel — tránh tốn thời gian dịch LLM lặp lại 4 lần không cần
    // thiết. Trả về danh sách rỗng nếu lỗi (KHÔNG throw — nơi gọi tự quyết
    // hiển thị lỗi phù hợp).
    suspend fun regenerateAnchorCandidates(
        character: Character, worldRules: String, settings: GenerationSettings, outDir: File,
        count: Int = 4
    ): List<String> = withContext(Dispatchers.IO) {
        try {
            val parser = LLMParser(settings.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
            parser.init()
            val r = parser.translateStagePrompt(
                character.anchorPrompt, PromptStage.TXT2IMG, worldRules, settings.imageStyle.stylePrompt,
                promptStyle = resolvePromptStyle(settings)
            )
            parser.free()
            val results = mutableListOf<String>()
            for (i in 0 until count) {
                // Seed lệch nhau nhưng deterministic (character.seed cố định
                // làm gốc) — bấm lại "tạo bằng AI" sẽ ra CÙNG 4 biến thể này
                // (đúng hành vi seed cố định của dự án, không phải bug).
                val variantSeed = character.seed + i * 977L
                val path = imagePipeline.generatePanel(
                    panelIndex = 9600 + i, prompt = r.positive, negativePrompt = r.negative, stylePrompt = "",
                    width = 512, height = 512, steps = 25, cfgScale = 7.5f, seed = variantSeed,
                    referenceImagePath = null, skeletonData = FloatArray(0), useStoryDiffusion = false,
                    outDir = outDir, onProgress = { _, _ -> }
                )
                if (path != null) results.add(path)
            }
            results
        } catch (ex: Exception) {
            log("  ⚠ regenerateAnchorCandidates lỗi (${ex.message})")
            emptyList()
        }
    }

    // mục 161 TECHNICAL_STATUS.md — "Dynamic Identity Bootstrap" (đề xuất
    // #8, mục 146/161). Y HỆT khuôn mẫu `regenerateAnchorCandidates()` ở
    // trên (dùng lại, không viết lại logic dịch LLM/sinh ảnh từ đầu — bài
    // học mục 93 "1 nơi lặp logic rồi lệch nhau") — CHỈ khác:
    // `changeDescription` được NỐI THÊM vào `anchorPrompt` gốc (mô tả cái
    // gì đã thay đổi vĩnh viễn — "có sẹo dài trên má trái", "trưởng thành
    // hơn, cao hơn"...), để LLM dịch prompt PHẢN ÁNH đúng thay đổi thay vì
    // vẫn ra đúng y ảnh gốc. Trả về rỗng nếu lỗi, không throw — giống hệt
    // quy ước của hàm gốc.
    suspend fun generateAnchorVersionCandidates(
        character: Character, changeDescription: String, worldRules: String,
        settings: GenerationSettings, outDir: File, count: Int = 4
    ): List<String> = withContext(Dispatchers.IO) {
        try {
            val parser = LLMParser(settings.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
            parser.init()
            val combinedPrompt = if (changeDescription.isBlank()) character.anchorPrompt
                else "${character.anchorPrompt}, $changeDescription"
            val r = parser.translateStagePrompt(
                combinedPrompt, PromptStage.TXT2IMG, worldRules, settings.imageStyle.stylePrompt,
                promptStyle = resolvePromptStyle(settings)
            )
            parser.free()
            val results = mutableListOf<String>()
            for (i in 0 until count) {
                // seed lệch cố định (character.seed + offset khác dải với
                // regenerateAnchorCandidates ở trên — tránh trùng seed nếu
                // user tạo cả 2 loại cho cùng nhân vật cùng lúc).
                val variantSeed = character.seed + 5_000_000L + i * 977L
                val path = imagePipeline.generatePanel(
                    panelIndex = 9700 + i, prompt = r.positive, negativePrompt = r.negative, stylePrompt = "",
                    width = 512, height = 512, steps = 25, cfgScale = 7.5f, seed = variantSeed,
                    referenceImagePath = null, skeletonData = FloatArray(0), useStoryDiffusion = false,
                    outDir = outDir, onProgress = { _, _ -> }
                )
                if (path != null) results.add(path)
            }
            results
        } catch (ex: Exception) {
            log("  ⚠ generateAnchorVersionCandidates lỗi (${ex.message})")
            emptyList()
        }
    }

    // mục 93 TECHNICAL_STATUS.md — 1 nguồn sự thật duy nhất cho việc tra
    // promptStyle của checkpoint đang active, dùng chung cho mọi call site
    // buildPrompt()/translateStagePrompt() — tránh lặp lại logic tra cứu 3
    // nơi rồi lệch nhau (bài học từ mục 66/87/88).
    private fun resolvePromptStyle(settings: GenerationSettings): PromptStyle =
        settings.promptStyleOverrides[settings.sdModelId] ?: PromptStyle.TAG_BASED

    // mục 107 TECHNICAL_STATUS.md — bảng tra Pose/Depth/Decay THEO
    // action_category (mục 86), thay vì 1 bộ số cố định cho CẢ TRUYỆN (xem
    // GenerationSettings.autoConditioningPresets cho giải thích đầy đủ +
    // GIỚI HẠN THẬT).
    //
    // NGUYÊN TẮC CHỌN SỐ (ước lượng hợp lý theo Ý NGHĨA từng tham số đã
    // ghi ở mục 81/97/99, CHƯA kiểm chứng bằng so sánh ảnh thật — dùng "So
    // sánh thử" mục 107 để tự xác nhận):
    //   - combat: 2 người tương tác VẬT LÝ MẠNH, tư thế phải rõ ràng nhất
    //     có thể (poseScale CAO 1.2) + cần phân tách "ai trước ai sau" rõ
    //     (depthScale CAO 0.8, mục 81 vốn sinh ra để giải quyết đúng cảnh
    //     này — "ai đấm ai" mục 81 TECHNICAL_STATUS.md) + biểu cảm CĂNG
    //     THẲNG cần "thắng" identity-lock ở cuối step (ipDecayFloor THẤP
    //     0.5, bắt đầu suy giảm sớm 700).
    //   - embrace: tư thế vẫn cần rõ (poseScale 1.0, không cần cao như
    //     combat vì ít chuyển động dữ dội) + 2 thân thể ÁP SÁT nhau, ít
    //     cần tách lớp sâu (depthScale THẤP 0.4) + identity QUAN TRỌNG hơn
    //     biểu cảm ở cảnh ôm (nhận diện đúng 2 nhân vật là ai quan trọng
    //     hơn biểu cảm chi tiết) nên ipDecayFloor CAO 0.8 (suy giảm ít).
    //   - kiss: khung hình thường CẬN (mục 104: close-up/extreme-close-up)
    //     nên ít cần pose toàn thân (poseScale 0.9) + gần như không cần
    //     depth (0 hoặc gần 0 người khác trong khung, depthScale THẤP
    //     0.4) + biểu cảm mắt/môi rất quan trọng, decay bắt đầu SỚM 600
    //     nhưng floor vừa phải 0.6 (không mất hẳn identity).
    //   - run: chuyển động MẠNH cần pose rất rõ (poseScale CAO 1.2), depth
    //     ít quan trọng (thường 1 người, giữ mặc định 0.5) + decay vừa
    //     phải (floor 0.7).
    //   - neutral: GIỮ NGUYÊN default hiện có (1.0/0.6/300/1.0/999/1.0) —
    //     không đổi hành vi cho cảnh không có gì đặc biệt.
    private val ACTION_CONDITIONING_PRESETS: Map<String, ConditioningPreset> = mapOf(
        "combat" to ConditioningPreset(
            poseConditioningScale = 1.2f, depthConditioningScale = 0.8f, depthActiveMinTimestep = 350f,
            ipDecayFloor = 0.5f, ipDecayStartTimestep = 700f, ipStaticScale = 1.0f),
        "embrace" to ConditioningPreset(
            poseConditioningScale = 1.0f, depthConditioningScale = 0.4f, depthActiveMinTimestep = 300f,
            ipDecayFloor = 0.8f, ipDecayStartTimestep = 900f, ipStaticScale = 1.0f),
        "kiss" to ConditioningPreset(
            poseConditioningScale = 0.9f, depthConditioningScale = 0.4f, depthActiveMinTimestep = 250f,
            ipDecayFloor = 0.6f, ipDecayStartTimestep = 600f, ipStaticScale = 1.0f),
        "run" to ConditioningPreset(
            poseConditioningScale = 1.2f, depthConditioningScale = 0.5f, depthActiveMinTimestep = 300f,
            ipDecayFloor = 0.7f, ipDecayStartTimestep = 700f, ipStaticScale = 1.0f),
        "neutral" to ConditioningPreset(
            poseConditioningScale = 1.0f, depthConditioningScale = 0.6f, depthActiveMinTimestep = 300f,
            ipDecayFloor = 1.0f, ipDecayStartTimestep = 999f, ipStaticScale = 1.0f)
    )

    // mục 107 — 1 NGUỒN SỰ THẬT DUY NHẤT cho việc quyết định 6 tham số
    // Pose/Depth/Decay của 1 panel (đúng bài học mục 93 — không lặp logic
    // tra cứu ở nhiều nơi rồi lệch nhau). THỨ TỰ ƯU TIÊN (cao->thấp):
    //   1. override.conditioningOverride (tay, từ "So sánh thử" hoặc
    //      chỉnh trực tiếp — CHƯA có UI chỉnh trực tiếp, chỉ có qua so
    //      sánh thử ở bước này)
    //   2. Nếu settings.autoConditioningPresets bật VÀ scene.actionCategory
    //      khớp 1 key trong ACTION_CONDITIONING_PRESETS -> dùng preset đó
    //   3. Cài đặt chung toàn cục (settings.pose*/depth*/ip*) — HÀNH VI CŨ,
    //      dùng khi tắt cờ HOẶC actionCategory null/lạ (model cũ/parse lỗi)
    fun resolveConditioning(
        scene: Scene, settings: GenerationSettings, override: PanelOverrideSettings?
    ): ConditioningPreset {
        override?.conditioningOverride?.let { return it }
        if (settings.autoConditioningPresets) {
            val preset = scene.actionCategory?.let { ACTION_CONDITIONING_PRESETS[it] }
            if (preset != null) return preset
        }
        return ConditioningPreset(
            poseConditioningScale = settings.poseConditioningScale,
            depthConditioningScale = settings.depthConditioningScale,
            depthActiveMinTimestep = settings.depthActiveMinTimestep,
            ipDecayFloor = settings.ipDecayFloor,
            ipDecayStartTimestep = settings.ipDecayStartTimestep,
            ipStaticScale = settings.consistencyStrength
        )
    }

    // ── Regional Prompting — canvas kéo-thả (mục 88 TECHNICAL_STATUS.md) ──
    // Nguồn sự thật DUY NHẤT cho việc build `regionPrompts` (List<String>
    // truyền cho ImagePipeline.generatePanelRegional) — dùng chung cho CẢ 2
    // call site (nhánh Quality Gate và nhánh không Quality Gate của
    // generatePanels()), tránh lặp lại đúng loại logic 2 nơi rồi lệch nhau
    // theo thời gian (bài học từ chính dự án này, xem mục 66/87).
    //
    // sceneChars: panel.scene.characters GỐC (chưa áp override thứ tự) —
    // dùng để validate override khớp đúng bộ nhân vật, và làm nguồn fallback
    // khi override không hợp lệ.
    private fun resolveRegionalOrder(sceneChars: List<String>, overrideOrder: List<String>?): List<String> {
        if (overrideOrder == null) return sceneChars
        // Validate: PHẢI là hoán vị đúng bộ sceneChars — không thiếu, không
        // thừa, không tên lạ (kịch bản có thể đã được sửa lại SAU khi user
        // set override qua canvas, khiến override cũ không còn khớp).
        val validPermutation = overrideOrder.size == sceneChars.size &&
            overrideOrder.toSet() == sceneChars.toSet()
        if (!validPermutation) {
            log("  ⚠ Regional Prompting: bỏ qua regionalColumnOrder đã lưu vì không còn khớp " +
                "đúng bộ nhân vật của scene hiện tại (kịch bản có thể đã đổi) — dùng lại thứ tự mặc định.")
            return sceneChars
        }
        return overrideOrder
    }

    // mục 224 TECHNICAL_STATUS.md — user chỉ ra ĐÚNG: cần kết hợp tự động
    // (LLM đề xuất `Scene.objectBoxes`, mục 222/223) + thủ công (user tự
    // sửa khi LLM đề xuất sai) — mirror ĐÚNG `resolveRegionalOrder()` ngay
    // trên (null = dùng tự động, có giá trị = override THẮNG hoàn toàn,
    // không gộp). Khác `resolveRegionalOrder()` ở phần validate: đây là 1
    // DANH SÁCH ĐỘC LẬP (không phải hoán vị bắt buộc đủ bộ) nên lỗi ở 1
    // box không cần huỷ CẢ danh sách — chỉ lọc bỏ đúng box hỏng, giữ lại
    // phần còn hợp lệ (cùng triết lý "dung thứ, lọc từng phần tử" đã dùng
    // khi parse `object_boxes` từ JSON LLM ở LLMParser.kt).
    private fun resolveObjectBoxes(scene: Scene, override: List<ObjectBox>?): List<ObjectBox> {
        val source = override ?: scene.objectBoxes
        val valid = source.filter {
            it.label.isNotBlank() &&
            listOf(it.xmin, it.ymin, it.xmax, it.ymax).all { v -> v.isFinite() && v in 0f..1f } &&
            it.xmax > it.xmin && it.ymax > it.ymin
        }
        if (valid.size != source.size) {
            log("  ⚠ objectBoxes: bỏ qua ${source.size - valid.size}/${source.size} box không hợp lệ " +
                "(toạ độ ngoài [0,1] hoặc xmax<=xmin/ymax<=ymin)" +
                (if (override != null) " trong override thủ công" else " do LLM đề xuất") + ".")
        }
        return valid
    }

    // eff/allChars/style: xem 2 call site — cả 2 build prompt tự động y hệt
    // nhau (anchorPrompt + prompt cảnh + style), chỉ khác override tay có
    // hay không, nên gộp về đúng 1 hàm để không lệch công thức.
    private fun buildRegionPrompts(
        order: List<String>, promptOverrides: Map<String, String>,
        allChars: List<Character>, eff: Effective, stylePrompt: String
    ): List<String> = order.map { name ->
        promptOverrides[name]?.takeIf { it.isNotBlank() } ?: run {
            val ch = allChars.find { it.name == name }
            // mục 123 TECHNICAL_STATUS.md — "anchor prompting" (kỹ thuật
            // cộng đồng AI-comic đã tra cứu): nhúng tỷ lệ "N đầu" của
            // NHÂN VẬT NÀY vào ĐÚNG đoạn prompt của cột người đó — Regional
            // Prompting có ánh xạ 1:1 rõ ràng cột↔người (khác nhánh
            // multiChar-mask dùng 1 prompt CHUNG, KHÔNG áp dụng ở đó vì
            // rủi ro SD gắn nhầm thuộc tính cho sai người khi nhiều chủ
            // thể chia sẻ 1 đoạn text — xem chỗ gọi injectEmbeddingTriggers
            // cho giải thích đầy đủ). Trả "" nếu ~7.5 đầu (chuẩn, không
            // cần nhấn thêm) — không làm dài prompt vô ích.
            val headsTag = ch?.boneProportions?.headsTallPromptTag()?.takeIf { it.isNotEmpty() }
            (ch?.anchorPrompt?.let { "$it, " } ?: "") +
                (headsTag?.let { "$it, " } ?: "") +
                eff.prompt + ", " + stylePrompt
        }
    }


    // Nếu TẤT CẢ nhân vật trong scene đều đã có LoRA riêng (Character.loraPath
    // != null) VÀ đã convert model ghép cho đúng nhóm này -> dùng model ghép
    // (neo được ngoại hình cho CẢ nhóm, không chỉ 1 người). Ngược lại rơi về
    // logic cũ (chỉ neo 1 người qua resolveModelIdForCharacter/IP-Adapter).
    // KHÔNG tự động convert ở đây — convert cần chạy trước (tốn thời gian
    // thật), việc sinh ảnh chỉ nên DÙNG model đã có sẵn, không đứng chờ.
    private fun resolveModelIdForScene(story: Story, characterNames: List<String>, defaultModelId: String): String {
        if (characterNames.size < 2) {
            return resolveModelIdForCharacter(story, characterNames.firstOrNull(), defaultModelId)
        }
        pairModelIdForSceneOrNull(story, characterNames)?.let { return it }
        // Không có model ghép sẵn -> fallback cũ, chỉ neo 1 người (người đầu
        // danh sách, hoặc người user chọn qua characterOverride ở resolveEffective).
        return resolveModelIdForCharacter(story, characterNames.firstOrNull(), defaultModelId)
    }

    // mục 67 TECHNICAL_STATUS.md — tách riêng phần kiểm tra "có model ghép
    // sẵn cho ĐÚNG bộ nhân vật này không" ra khỏi resolveModelIdForScene(),
    // để generatePanels()/regeneratePanel() TÁI DÙNG được (quyết định có nên
    // thử nhánh IP-Adapter-mask N-nhân-vật mới hay không) — tránh viết lại
    // logic 2 lần ở 2 chỗ rồi lệch pha nhau về sau (đúng nguyên tắc "tài
    // liệu và code không được lệch pha" — ở đây là "code và code" cũng phải
    // 1 nguồn sự thật duy nhất).
    private fun pairModelIdForSceneOrNull(story: Story, characterNames: List<String>): String? {
        val allChars = storyManager.loadStory(story.id)?.characters ?: story.characters
        val chars = characterNames.mapNotNull { name -> allChars.find { it.name == name } }
        val allHaveLora = chars.size == characterNames.size && chars.all { it.loraPath != null }
        return if (allHaveLora && storyManager.hasConvertedPairModel(chars.map { it.id }))
            storyManager.pairModelId(chars.map { it.id }) else null
    }

    // ── Giai đoạn 1: Sinh panel (dừng lại ở REVIEW) ───────────────────────
    // SỬA (yêu cầu duyệt lại routing trước khi sinh ảnh — tránh lỡ tay gửi
    // panel không muốn lên remote): TÁCH generatePanels() cũ thành 2 giai
    // đoạn RÕ RỆT:
    //   1. prepareChapter() — phân tích kịch bản (LLM parseStory, GỌI ĐÚNG
    //      1 LẦN — quan trọng vì gọi lại sẽ cho kết quả HƠI khác do
    //      temperature>0, làm lệch giữa cái user duyệt và cái thật sự sinh
    //      ra nếu gọi lại) + build prompt từng panel + TÍNH SẴN quyết định
    //      routing AUTO cho MỌI panel, "đóng băng" luôn vào
    //      panel.overrideSettings.backendOverride — CHƯA sinh ảnh gì cả.
    //   2. runGeneration() — sinh ảnh thật, tôn trọng ĐÚNG lựa chọn đã
    //      đóng băng ở bước 1 (hoặc user đã sửa tay qua màn hình duyệt
    //      routing — xem RoutingReviewScreen.kt) cho từng panel.
    // Do quyết định AUTO đã "đóng băng" ngay sau prepareChapter() (không
    // còn để router tự quyết LẠI lúc runGeneration()), UI duyệt routing có
    // thể cho user đổi tay panel nào đó TRƯỚC khi bấm sinh ảnh — đúng yêu
    // cầu "duyệt lần cuối", và đảm bảo cái user thấy lúc duyệt CHÍNH XÁC là
    // cái sẽ chạy thật (không có chuyện AUTO đổi ý giữa lúc duyệt và lúc
    // sinh ảnh thật).
    // mục 154 TECHNICAL_STATUS.md — "đảo pipeline nhân vật", BƯỚC 1 (phân
    // tích sơ bộ RẺ, TRƯỚC khi viết kịch bản chi tiết). Tự quản lý vòng đời
    // LLMParser RIÊNG (không dùng chung `llmParser` field của
    // prepareChapter() — hàm đó giữ instance qua NHIỀU bước sau này
    // (generatePanels() cần buildPrompt() dùng lại), còn hàm này chạy XONG
    // LÀ FREE NGAY, gọi độc lập được bất kỳ lúc nào, không ảnh hưởng phiên
    // sinh ảnh đang/sắp chạy).
    suspend fun analyzeCharacters(text: String, existingNames: List<String>, settings: GenerationSettings): List<CharacterSummary> {
        val parser = LLMParser(settings.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
        return try {
            parser.init()
            parser.extractCharacterSummary(text, existingNames)
        } finally {
            parser.free()
        }
    }

    suspend fun prepareChapter(
        story: Story,
        storyText: String,
        settings: GenerationSettings,
        chapterId: String,
        chapterNumber: Int,
        // mục 154 TECHNICAL_STATUS.md — "đảo pipeline nhân vật": tên nhân
        // vật user vừa XÁC NHẬN Ở BƯỚC PHÂN TÍCH SƠ BỘ là "sẽ cần giữ mặt
        // nhất quán" (CharacterSummaryReviewScreen) — CHỈ dùng làm hint
        // TẠM THỜI cho scenePrompt() né ghép chung panel ngay từ lượt viết
        // ĐẦU TIÊN, KHÔNG lưu vào Character (giữ đúng nguyên tắc
        // StoryManager.currentConsistencyMethod(): method LUÔN suy ra từ dữ
        // liệu thật — anchorImagePath/loraPath/embeddingTrigger — không có
        // field "ý định" riêng để tránh 2 nguồn sự thật lệch nhau). Rỗng
        // (mặc định) = hành vi Y HỆT trước mục 154 — caller không đi qua
        // bước phân tích sơ bộ mới thì không đổi gì.
        extraIdentityHintNames: List<String> = emptyList()
    ): Chapter = coroutineScope {
        try {
            // LLM parse — dùng config tự động tối ưu theo phần cứng thực tế,
            // không hardcode. Nếu người dùng đổi máy, config này tự thay đổi
            // theo vì hwProfile detect lại chipset/GPU/RAM mỗi lần cài app mới.
            emit(PipelineStage.LLM_PARSING, "Khởi động LLM...")
            log("⚙️ Phần cứng: ${hwProfile.chipset} · Adreno~${hwProfile.adrenoGen} · ${hwProfile.bigCores} big core")
            log("⚙️ LLM dùng ${effectiveNThreads(settings)} thread" +
                if (optimalConfig.useGpuForLlm) " + GPU offload (${optimalConfig.nGpuLayers} layer, ${optimalConfig.gpuBackend.name})"
                else " (CPU-only, không có GPU backend khả dụng)")
            val parser = LLMParser(settings.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
            llmParser = parser
            parser.init()
            log("✓ LLM sẵn sàng")
            log("Đang phân tích truyện, chia ${settings.panelCount} scene...")
            // Nhân vật user ĐÃ tự thêm từ trước (qua CharactersScreen) và đã
            // gán anchorImagePath -> cho LLM biết trước để né ghép cặp khi
            // viết kịch bản (soft hint, xem scenePrompt()). Lần đầu sinh
            // truyện (chưa ai được thêm) thì list này rỗng, không có gì để
            // né - đây là giới hạn thật, không giả vờ né được cái chưa biết.
            // mục 154 — GIỜ CÓ THÊM extraIdentityHintNames (từ bước phân
            // tích sơ bộ mới, nếu caller đi qua bước đó) — đóng đúng gap đã
            // ghi ở nhiều mục cũ.
            val knownIpaNames = (story.characters.filter { it.anchorImagePath != null }.map { it.name } +
                extraIdentityHintNames).distinct()
            // mục 216 TECHNICAL_STATUS.md — Location Anchor: đưa tên bối
            // cảnh đã biết vào prompt LLM (xem knownLocationsBlock trong
            // scenePrompt()) để LLM tự tái dùng đúng tên khi cảnh mới quay
            // lại 1 bối cảnh cũ — rỗng nếu truyện chưa từng sinh cảnh nào
            // (đúng giới hạn thật, không giả vờ biết trước cái chưa từng có).
            // mục 220 — CHỈ lọc những bối cảnh THẬT SỰ có ghi chú khung
            // hình (referenceFraming không rỗng) — phần lớn Location sẽ
            // KHÔNG có (user không bắt buộc điền), giữ prompt gọn.
            val locationFramingHints = story.locations.associate { it.name to (it.referenceFraming ?: "") }.filterValues { it.isNotBlank() }
            val scenes = parser.parseStory(storyText, settings.panelCount, knownIpaNames, settings.llmStoryGuidance,
                knownLocationNames = story.locations.map { it.name },
                locationFramingHints = locationFramingHints)
            log("✓ Chia được ${scenes.size} scene")
            buildChapterFromScenes(story, scenes, storyText, settings, chapterId, chapterNumber, parser)
        } catch (e: Exception) {
            _state.update { it.copy(stage = PipelineStage.ERROR, error = e.message) }
            llmParser?.free(); llmParser = null
            throw e
        }
    }

    // mục 120 TECHNICAL_STATUS.md — user hỏi: "có đường chen ngang không đi
    // qua bước LLM sinh kịch bản từ truyện chữ không, khi đã có sẵn kịch
    // bản từ LLM bên ngoài (vd ChatGPT/Claude dùng ngoài app)". CÓ THỂ bypass
    // ĐÚNG 1 bước — parseStory() (truyện chữ thô -> Scene có cấu trúc) —
    // NHƯNG buildPrompt() (Scene có cấu trúc -> tag prompt SD1.5 thật, chọn
    // pose template, ConceptDictionary) VẪN CẦN LLM on-device, vì đó là bước
    // MÁY MÓC/KỸ THUẬT khác hẳn (dịch sang đúng PromptStyle của checkpoint
    // đang active, tra cứu pose_library.json thật của user — 1 LLM ngoài
    // app KHÔNG THỂ biết trước thư viện pose/checkpoint cụ thể của máy này).
    // Đây là 2 bước TÁCH BIỆT rõ ràng trong kiến trúc sẵn có (KHÔNG phải vá
    // chắp — parseStory()/buildPrompt() đã là 2 hàm riêng từ đầu), chỉ cần
    // hàm entry MỚI bỏ qua bước 1, giữ nguyên bước 2.
    //
    // externalScript: JSON do user dán vào (từ LLM ngoài app), format xem
    // [ExternalScriptImport]. GIỚI HẠN THẬT: actionCategory/expression (LLM
    // nội bộ tự phân loại lúc parseStory(), mục 85/93) sẽ LUÔN null nếu LLM
    // ngoài không điền field đó trong JSON — rơi về heuristic regex cũ
    // (SeedRegistry.resolveActionCategory()), KHÔNG hỏng thêm gì so với
    // hành vi trước khi có 2 field đó, chỉ mất phần cải thiện độ chính xác.
    suspend fun prepareChapterFromExternalScript(
        story: Story,
        externalScript: ExternalScriptImport.ScriptJson,
        settings: GenerationSettings,
        chapterId: String,
        chapterNumber: Int
    ): Chapter = coroutineScope {
        try {
            val scenes = ExternalScriptImport.toScenes(externalScript)
            if (scenes.isEmpty()) throw IllegalArgumentException("Kịch bản import rỗng — không có scene nào để dựng chương")
            log("✓ Import ${scenes.size} scene từ kịch bản ngoài (bỏ qua bước LLM chia truyện)")

            emit(PipelineStage.LLM_PARSING, "Khởi động LLM (chỉ để dịch prompt, không chia truyện)...")
            val parser = LLMParser(settings.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
            llmParser = parser
            parser.init()
            log("✓ LLM sẵn sàng")
            // storyText gốc không tồn tại (không có truyện chữ thô) — ghép
            // description các scene lại làm bản ghi tham khảo cho Chapter,
            // KHÔNG dùng lại để parse (chỉ hiển thị/lưu trữ).
            val pseudoStoryText = scenes.joinToString("\n\n") { it.description }
            buildChapterFromScenes(story, scenes, pseudoStoryText, settings, chapterId, chapterNumber, parser)
        } catch (e: Exception) {
            _state.update { it.copy(stage = PipelineStage.ERROR, error = e.message) }
            llmParser?.free(); llmParser = null
            throw e
        }
    }

    // Phần DÙNG CHUNG giữa prepareChapter() (LLM tự chia truyện) và
    // prepareChapterFromExternalScript() (đã có Scene sẵn) — mọi thứ SAU
    // khi có `scenes: List<Scene>`, TRƯỚC đây là phần cuối prepareChapter().
    private suspend fun buildChapterFromScenes(
        story: Story, scenes: List<Scene>, storyText: String, settings: GenerationSettings,
        chapterId: String, chapterNumber: Int, parser: LLMParser
    ): Chapter {
            // Auto character detection
            val freq = parser.extractCharacterFrequency(scenes)
            val newChars = freq.keys.filter { name ->
                story.characters.none { it.name.equals(name, ignoreCase = true) }
            }
            if (newChars.isNotEmpty()) {
                log("✓ Phát hiện ${newChars.size} nhân vật mới: ${newChars.joinToString(", ")}")
                newChars.forEach { name ->
                    val role = storyManager.autoClassifyCharacter(name, freq[name] ?: 0, scenes.size)
                    val char = Character(
                        id = UUID.randomUUID().toString(), name = name,
                        anchorPrompt = "$name character",
                        seed = (10000L..99999L).random(), role = role
                    )
                    storyManager.saveCharacter(story.id, char)
                    log("  → $name: ${role.name.lowercase()}")
                }
            }

            // Build prompts
            emit(PipelineStage.PROMPT_BUILDING, "Sinh prompt từng panel...")
            val allChars = applyActiveAnchorVersion(storyManager.loadStory(story.id)?.characters ?: story.characters, chapterNumber)
            val charMap = allChars.associate { it.name to it.anchorPrompt }
            val poseTemplates = storyManager.listPoseTemplateNames()

            // Xung đột IP-Adapter THẬT (đếm bằng Kotlin, không dựa vào LLM
            // có nghe lời né hay không — xem StoryManager.detectIpAdapterConflicts).
            val storyForConflictCheck = story.copy(characters = allChars)
            val conflicts = storyManager.detectIpAdapterConflicts(storyForConflictCheck, scenes.map { it.characters })
            if (conflicts.isNotEmpty()) {
                log("⚠ ${conflicts.size} panel có ≥2 nhân vật IP-Adapter cùng khung — chỉ 1 người/panel được neo ảnh thật:")
                conflicts.forEach { (idx, names) -> log("  → panel ${idx + 1}: ${names.joinToString(", ")}") }
            }

            // mục 78 TECHNICAL_STATUS.md — Concept Dictionary: tra cứu 1 lần
            // cho toàn chương (dict không đổi giữa các panel cùng chương),
            // inject vào MỌI lời gọi buildPrompt() bên dưới. Rỗng nếu tính
            // năng tắt hoặc dict chưa có entry nào — không tác dụng phụ.
            // Giữ lại INSTANCE (không chỉ text) — mục 101 cần gọi
            // recordFromLlmOutput() lên CÙNG instance này sau mỗi panel.
            val conceptDict = if (story.conceptDictionaryEnabled)
                ConceptDictionary(storyManager.storyDir(story.id)) else null
            // mục 146 TECHNICAL_STATUS.md — nối text mọi scene trong chương
            // (description/action/setting/thoại) làm proxy cho "văn bản
            // chương" để buildInjectionText() lọc TOP-N theo độ liên quan.
            // KHÔNG dùng văn bản THÔ gốc user dán vào (không còn giữ tới
            // đây, `scenes` đã là kết quả PARSE) — proxy này vẫn hợp lý vì
            // scene description/action do LLM viết ra TỪ văn bản gốc, nên
            // khái niệm nào thật sự xuất hiện trong chương gần như chắc
            // chắn cũng xuất hiện lại ở đây.
            val chapterTextForConceptFilter = scenes.joinToString(" ") { s ->
                listOf(s.description, s.action, s.setting, s.dialogue.joinToString(" ") { it.text })
                    .joinToString(" ")
            }
            val conceptDictText = conceptDict?.buildInjectionText(chapterTextForConceptFilter) ?: ""

            var panels = scenes.mapIndexed { i, scene ->
                log("  Prompt panel ${i+1}: ${scene.description.take(45)}...")
                val result = parser.buildPrompt(scene, charMap, settings.imageStyle.stylePrompt, poseTemplates, story.worldRules, storyManager.listPoseTemplateTags(), story.promptGuideNotes, conceptDictText, resolvePromptStyle(settings),
                    ipAdapterDecayActive = settings.ipDecayFloor < 1.0f)
                if (conceptDict != null && result.newConcepts.isNotEmpty()) {
                    if (conceptDict.recordFromLlmOutput(result.newConcepts)) {
                        log("  📖 Ghi nhận khái niệm mới: ${result.newConcepts.joinToString { it.first }}")
                    }
                }
                Panel(
                    index = i, scene = scene, prompt = result.positive, negativePrompt = result.negative,
                    suggestedPoseTemplate = result.poseTemplate, suggestedPoseAngle = result.poseAngle,
                    ipAdapterConflictNames = conflicts[i] ?: emptyList()
                )
            }
            parser.free(); llmParser = null
            log("✓ ${panels.size} prompt sẵn sàng")

            val router = BackendRouterFactory.create(settings)
            if (settings.routingMode == RoutingMode.AUTO)
                log("🔀 Routing tự động: LLM quyết định local/remote từng panel — sẽ hiện ở màn hình duyệt trước khi sinh ảnh")
            else if (settings.remoteEndpoint.enabled)
                log("🔀 Routing thủ công: mặc định ${settings.defaultBackend.name}, panel nào override tay dùng theo override")
            panels = panels.map { panel ->
                val decision = if (panel.hasManualBackendOverride())
                    RoutingDecision(panel.overrideSettings!!.backendOverride!!, "Người dùng chọn tay cho panel này")
                else
                    router.decide(panel, story, settings)
                log("  → Backend panel ${panel.index + 1}: ${decision.backend.name} (${decision.reason})")
                panel.copy(
                    overrideSettings = PanelOverrideSettings(backendOverride = decision.backend),
                    routingReason = decision.reason
                )
            }
            router.free()

            emit(PipelineStage.REVIEW, "✓ Đã phân tích xong — duyệt routing trước khi sinh ảnh")
            return Chapter(
                id = chapterId, storyId = story.id, title = "Chương $chapterNumber",
                chapterNumber = chapterNumber, storyText = storyText, style = settings.imageStyle,
                panels = panels, status = ChapterStatus.DRAFT
            )
    }

    // Sinh ảnh thật cho 1 Chapter ĐÃ CÓ panels + routing (từ prepareChapter(),
    // sau khi user duyệt/sửa tay ở RoutingReviewScreen) — KHÔNG gọi LLM
    // parseStory() lại (đã làm 1 lần rồi, xem lý do trong comment trên).
    suspend fun runGeneration(
        story: Story,
        chapter: Chapter,
        settings: GenerationSettings
    ): Chapter = coroutineScope {
        val outDir = storyManager.outputDir(story.id, chapter.id)
        val startMs = System.currentTimeMillis()
        _state.update { PipelineState(startTimeMs = startMs) }
        thermalMonitor.start(settings.thermalThreshold, settings.thermalResumeOffset)

        // mục 83 TECHNICAL_STATUS.md — theo dõi Job THẬT của coroutine đang
        // chạy hàm này, để `cancelSafely()` có thể ĐỢI nó dừng hẳn (native
        // call bên trong KHÔNG cooperative-cancellable — Kotlin cancel()
        // không ngắt được 1 lời gọi JNI blocking giữa chừng) trước khi giải
        // phóng con trỏ native — tránh use-after-free. Xem docstring đầy đủ
        // ở `cancelSafely()`.
        // mục 142 TECHNICAL_STATUS.md — reset cờ ngắt native SẠCH mỗi
        // lần bắt đầu 1 lượt generate MỚI (Pipeline::generate() cũng tự
        // reset ở đầu hàm — đây là lớp phòng thủ thứ 2, phòng lượt trước
        // bị ngắt mà vì lý do gì đó cờ chưa kịp reset).
        try { NativeBridge.clearInterruptNative() } catch (_: Throwable) {}
        // mục 248 — Differential Diffusion cho img2img CÓ MASK (vùng chạm/mặt/tay); cờ toàn cục native, đặt lại mỗi lượt
        try { NativeBridge.setDifferentialDiffusion(settings.differentialInpaint) } catch (_: Throwable) {}
        currentJob = coroutineContext[Job]

        try {
            val panels = prepareInteractionLayouts(chapter.panels, story, chapter.chapterNumber, settings)   // mục 251 (tắt mặc định)
            val allChars = applyActiveAnchorVersion(storyManager.loadStory(story.id)?.characters ?: story.characters, chapter.chapterNumber)

            // Load SD model
            emit(PipelineStage.SD_GENERATING, totalPanels = panels.size)
            log("Chuẩn bị sinh ảnh (${optimalConfig.sdNThreads} thread" +
                if (settings.useOpenCL) " + OpenCL)" else ", CPU-only)")

            // Generate panels với thermal check
            val completedPanels = mutableListOf<Panel>()
            // mục 138 TECHNICAL_STATUS.md — MỞ RỘNG "kế thừa seed" (mục 71)
            // từ chỉ-so-panel-liền-trước sang CỬA SỔ TRƯỢT N panel gần nhất
            // (N = settings.slidingWindowSize — field này tồn tại sẵn từ
            // trước nhưng CHƯA từng được đọc ở đâu, xem mục 137). Thuật
            // toán: giữ danh sách (setting, seed) của TỐI ĐA N panel gần
            // nhất có scene.setting không rỗng; khi cần seed kế thừa, tìm
            // NGƯỢC từ panel GẦN NHẤT trở về trước, lấy seed của panel ĐẦU
            // TIÊN khớp scene.setting — "seed gần nhất dùng cho bối cảnh
            // này thắng", tự nhiên hơn hẳn so với chỉ so panel liền trước
            // (vd: A, A, B, A — panel B chen giữa 2 cảnh A không còn làm
            // "quên" mất seed đã dùng cho A ở bản CŨ chỉ-so-1-panel).
            data class SettingSeedEntry(val setting: String, val seed: Long)
            val settingHistory = ArrayDeque<SettingSeedEntry>()
            val windowSize = settings.slidingWindowSize.coerceAtLeast(1)

            panels.forEach { panel ->
                // Thermal gate
                waitForThermalSafe(settings)

                _state.update { it.copy(currentPanel = panel.index + 1) }

                // mục 74 TECHNICAL_STATUS.md — kết quả Quality Gate cho panel
                // này (chỉ được set khi settings.enableQualityGate=true — CẢ
                // 5 nhánh sinh ảnh SD1.5 bên dưới đều set, không chỉ riêng
                // nhánh 1-nhân-vật như comment cũ ở đây từng ghi SAI — sửa
                // lại mục 185, cùng loại lỗi đã tự phát hiện ở mục 83 cho 1
                // comment KHÁC gần đó, comment NÀY thì bị sót). Mặc định
                // true/rỗng = "không đánh giá". mục 185: nhánh SDXL-làm-chính
                // (`sdxlPath`) CŨNG không set — luôn giữ mặc định `true`, xem
                // GIỚI HẠN THẬT ở docstring `dispatchSdxlPanel()`.
                var panelQualityGatePassed = true
                var panelQualityGateReasons: List<String> = emptyList()

                val inheritedSeed = if (settings.seedInheritanceEnabled && panel.scene.setting.isNotBlank())
                    settingHistory.lastOrNull { it.setting == panel.scene.setting }?.seed else null
                val eff = resolveEffective(panel, settings, inheritedSeed)
                if (panel.scene.setting.isNotBlank()) {
                    settingHistory.addLast(SettingSeedEntry(panel.scene.setting, eff.seed))
                    while (settingHistory.size > windowSize) settingHistory.removeFirst()
                }

                // ── Local/Remote routing ────────────────────────────────
                // Quyết định đã "đóng băng" từ prepareChapter() (đã qua màn
                // hình duyệt user xem/sửa) — KHÔNG tự quyết lại ở đây nữa,
                // luôn tôn trọng đúng backendOverride hiện có trên panel.
                // Fallback router.decide() chỉ để phòng hờ (không nên xảy
                // ra bình thường, panel nào cũng đã có override từ bước 1).
                var routing = if (panel.hasManualBackendOverride())
                    RoutingDecision(panel.overrideSettings!!.backendOverride!!, panel.routingReason.ifBlank { "Người dùng chọn tay cho panel này" })
                else {
                    val fallbackRouter = BackendRouterFactory.create(settings)
                    val d = fallbackRouter.decide(panel, story, settings)
                    fallbackRouter.free()
                    d
                }

                log("  → Backend panel ${panel.index + 1}: ${routing.backend.name} (${routing.reason})")

                var rawPath: String
                if (routing.backend == GenerationBackend.REMOTE) {
                    val outFile = File(outDir, "panel_%03d_raw.png".format(panel.index))
                    val effPromptRemote = injectHeadsTallTag(injectEmbeddingTriggers(eff.prompt, panel, allChars, eff.characterName), eff.characterName, allChars)
                    val referenceImageRemote = eff.characterName?.let { storyManager.getCharacterAnchor(story.id, it, preferTorn = SeedRegistry.resolveActionCategory(panel.scene) == "combat", chapterNumber = chapter.chapterNumber, expressionKey = expressionKeyFor(panel, it)) }
                    val skeletonDataRemote = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapter.chapterNumber)
                        .takeIf { it.isNotEmpty() }
                    // LoRA riêng của nhân vật (nếu có gán) — KHÁC modelId local
                    // (đó là model .mnn đã convert/merge sẵn, không dùng được ở
                    // remote vì remote chạy diffusers thật). Server tìm đúng
                    // file .safetensors này trong --loras-dir (đã đồng bộ tay
                    // từ trước, xem README.md) — KHÔNG upload file LoRA qua
                    // đây (quá lớn để gửi lại mỗi request).
                    val loraIdRemote = eff.characterName
                        ?.let { name -> storyManager.loadStory(story.id)?.characters?.find { it.name == name } }
                        ?.loraPath?.let { java.io.File(it).nameWithoutExtension }
                    try {
                        RemoteGenerationClient(settings.remoteEndpoint).generatePanel(
                            prompt = effPromptRemote + ", " + settings.imageStyle.stylePrompt,
                            negativePrompt = eff.negativePrompt,
                            width = eff.width, height = eff.height, steps = eff.steps,
                            cfgScale = eff.cfgScale, seed = eff.seed, outFile = outFile,
                            referenceImagePath = referenceImageRemote,
                            skeletonData = skeletonDataRemote,
                            loraId = loraIdRemote
                        )
                    } catch (ex: Exception) {
                        // KHÔNG tự fallback local ở đây — user đã chọn remote (tay
                        // hoặc qua policy AUTO), im lặng đổi sang local sẽ khiến họ
                        // tưởng dữ liệu không rời máy trong khi trước đó panel khác
                        // đã gửi đi rồi. Báo lỗi rõ, dừng lại để user tự quyết định
                        // (bấm regenerate panel này với backend khác nếu muốn).
                        throw RuntimeException("Remote generate thất bại tại panel ${panel.index + 1}: ${ex.message}\n" +
                            "Kiểm tra remote endpoint còn chạy không (Cài đặt > Remote GPU > Kiểm tra kết nối), " +
                            "hoặc đổi backend panel này về Local rồi generate lại.", ex)
                    }
                    rawPath = outFile.absolutePath
                } else {
                // ĐÃ NỐI: model giờ chọn theo nhân vật NẾU đã convert riêng
                // (xem StoryManager.registerConvertedModel) — không còn
                // "tạm dùng chung 1 model cho mọi nhân vật" như trước.
                // loadSD() tự bỏ qua nếu model đang load đúng rồi (rẻ khi
                // các panel liên tiếp cùng nhân vật).
                val modelId = if (panel.overrideSettings?.characterOverride != null)
                    resolveModelIdForCharacter(story, eff.characterName, settings.sdModelId)
                else
                    resolveModelIdForScene(story, panel.scene.characters, settings.sdModelId)
                val embeddingsDir = storyManager.embeddingsDir(story.id).absolutePath
                imagePipeline.loadSD(storyManager.modelsDir.absolutePath, modelId, settings.useOpenCL, embeddingsDir, settings.useNpu, runtimeOptimizer.detectQnnSoc()?.socModel ?: "")

                // mục 67 TECHNICAL_STATUS.md — ĐÃ NỐI DÂY sdTxt2ImgWithCharactersAndPose
                // (mục 52b): trước mục này, native/JNI đã xong hoàn chỉnh
                // nhưng KHÔNG có nơi nào trong Kotlin gọi tới (xác nhận qua
                // grep, không phải tự suy đoán) — panel có 2+ nhân vật mà
                // KHÔNG có model ghép LoRA sẵn (pairModelIdForSceneOrNull()
                // == null) trước đây LUÔN rơi về chỉ neo ĐÚNG 1 người
                // (eff.characterName), người còn lại không có anchor gì cả
                // ngoài trigger word TI yếu. Giờ: nếu KHÔNG có override tay
                // 1 người cụ thể, scene có 2-4 nhân vật, KHÔNG có model ghép
                // LoRA sẵn cho đúng bộ này, TẤT CẢ nhân vật đều đã có ảnh
                // anchor, VÀ đúng file unet_ipa_mask_controlnet_{N}char.mnn
                // tồn tại cho modelId hiện tại -> dùng nhánh mask N-nhân-vật
                // thay vì chỉ neo 1 người. N>=4 mục 52b cảnh báo CHƯA xác
                // nhận chạy thật kỹ — vẫn cho phép (đúng API, chỉ là rủi ro
                // chất lượng chưa đo, không phải lỗi cứng) nhưng log rõ.
                //
                // mục 169 TECHNICAL_STATUS.md — TRƯỚC ĐÂY điều kiện này là
                // `sceneChars.size in 2..4`, MÂU THUẪN với đúng câu comment
                // ngay trên ("N>=4 vẫn cho phép") — vì chặn cứng ở 4 nên
                // dòng log cảnh báo N>=4 KHÔNG BAO GIỜ thật sự bắn cho N>4
                // (chỉ bắn được đúng N=4). Đổi thành `>= 2`, để hàm
                // `storyManager.hasMultiCharMaskUnet(modelId, N)` (đã N-
                // tổng-quát từ mục 52b, không hardcode giới hạn) là ĐIỀU
                // KIỆN THẬT DUY NHẤT quyết định dùng được hay không — đúng
                // với "cảnh 6+ người" user hỏi. Cần export model N=6 thật
                // qua `prepare_models.yml` (`export_mask_variant=true` +
                // `mask_num_characters=6`, mục 169) thì nhánh này mới có gì
                // để chạy — chỉ đổi điều kiện Kotlin KHÔNG tự tạo ra model.
                //
                // mục 118 TECHNICAL_STATUS.md — sort ỔN ĐỊNH theo allChars
                // (không dùng thẳng thứ tự LLM viết trong scene) — QUAN
                // TRỌNG: multiCharAnchors bên dưới build TỪ sceneChars này,
                // phải khớp ĐÚNG thứ tự với skeleton (resolveSkeletonData()
                // tự sort idempotent theo CÙNG công thức — 2 nơi độc lập
                // vẫn tự khớp nhau vì cùng 1 tập nhân vật luôn ra cùng 1 thứ
                // tự, xem giải thích đầy đủ ở resolveSkeletonData()).
                val sceneChars = stableCharacterOrder(panel.scene.characters, allChars)
                val noCharacterOverride = panel.overrideSettings?.characterOverride == null
                val noPairModel = pairModelIdForSceneOrNull(story, sceneChars) == null
                val multiCharAnchors: List<String>? = if (settings.useStoryDiffusion && noCharacterOverride &&
                        sceneChars.size >= 2 && noPairModel) {
                    val anchors = sceneChars.map { storyManager.getCharacterAnchor(story.id, it, preferTorn = SeedRegistry.resolveActionCategory(panel.scene) == "combat", chapterNumber = chapter.chapterNumber, expressionKey = expressionKeyFor(panel, it)) }
                    if (anchors.all { it != null } && storyManager.hasMultiCharMaskUnet(modelId, sceneChars.size))
                        anchors.filterNotNull() else null
                } else null
                // mục 217 (đợt 2) TECHNICAL_STATUS.md — "Location Anchor"
                // slot thứ N+1, ÁP DỤNG THẬT cho panel CÓ nhân vật (khác
                // đợt 1 — CHỈ panel 0-nhân-vật). Cần CẢ 2 điều kiện: (a)
                // bối cảnh của scene đã có ảnh neo (mục 216/217 đợt 1), (b)
                // model .mnn hậu tố "_loc" ĐÃ được export cho ĐÚNG
                // sceneChars.size (việc export riêng — xem "VIỆC CÒN LẠI"
                // mục 217 đợt 2, KHÔNG tự có chỉ vì đổi code này). Thiếu 1
                // trong 2 -> rơi về multiCharAnchors N-slot như cũ, hành vi
                // KHÔNG đổi.
                val locationAnchorForMc = panel.scene.locationName?.let { storyManager.getLocationAnchor(story.id, it) }
                val useMcLocationSlot = multiCharAnchors != null && locationAnchorForMc != null &&
                    storyManager.hasMultiCharMaskUnetWithLocation(modelId, sceneChars.size)
                // mục 69 TECHNICAL_STATUS.md — TẦNG DỰ PHÒNG THỨ 3, sau
                // pair-LoRA (mục cũ) và IP-Adapter mask (mục 67): nếu
                // KHÔNG có model mask N-nhân-vật (thiếu file/thiếu anchor)
                // NHƯNG CÓ file unet_regional_controlnet_{N}col.mnn ->
                // dùng Regional Prompting (mục 56, "chia cột dọc"). QUY
                // ƯỚC ĐƠN GIẢN HOÁ (nói rõ, không giấu): mỗi nhân vật = 1
                // cột theo ĐÚNG thứ tự scene.characters, ĐỀU NHAU (chưa có
                // canvas cho user tự kéo thả chia vùng khác nhau — đó vẫn
                // là việc CHƯA làm, xem TECHNICAL_STATUS.md). Prompt mỗi
                // vùng = character.anchorPrompt (mô tả GỐC nhân vật đó,
                // Character model đã có sẵn) + prompt cảnh chung, để vùng
                // vừa có đặc trưng riêng người vừa có bối cảnh chung.
                // mục 172 TECHNICAL_STATUS.md — Regional Prompting bản MASK
                // hình dạng tuỳ ý (kiểu "Attention Couple" cộng đồng, mục
                // 171) — ƯU TIÊN HƠN `useRegional` (bản cột, khai báo NGAY
                // DƯỚI) khi CẢ 2 model cùng tồn tại, vì mask thật xử lý đúng
                // cảnh "quần nhau/vật lộn" (chồng lấn vật lý) mà cột cứng
                // không làm được. Khai báo TRƯỚC `useRegional` (Kotlin cần
                // khai báo trước khi dùng trong 1 hàm — khác thứ tự ưu tiên
                // RUNTIME, cái đó nằm ở chuỗi if/else bên dưới, xem đó). Cùng
                // điều kiện đủ như useRegional, CHỈ thêm yêu cầu file
                // `unet_regional_mask_controlnet_{N}char.mnn` — KHÔNG có thì
                // tự rơi về useRegional/multiCharAnchors/fallback như TRƯỚC
                // mục 172, không đổi hành vi hiện tại của bất kỳ story nào
                // chưa export model này.
                val useRegionalMask = multiCharAnchors == null && settings.useStoryDiffusion && noCharacterOverride &&
                    sceneChars.size >= 2 && noPairModel && storyManager.hasRegionalMaskUnet(modelId, sceneChars.size)

                val useRegional = multiCharAnchors == null && settings.useStoryDiffusion && noCharacterOverride &&
                    sceneChars.size >= 2 && noPairModel && storyManager.hasRegionalUnet(modelId, sceneChars.size) &&
                    !useRegionalMask // mục 172 — nhường ưu tiên cho bản mask nếu CẢ 2 model cùng tồn tại

                // mục 152 TECHNICAL_STATUS.md — TẦNG ƯU TIÊN CAO NHẤT, MỚI:
                // Triple-Conditioning combo (Regional Prompting + IP-Adapter
                // mask + Depth ControlNet CÙNG LÚC — mục 143/151). Đặt TRƯỚC
                // `multiCharAnchors`/`useRegional` (không đổi 2 biến đó —
                // tính RIÊNG, ĐỘC LẬP, để không đụng logic đã có, chỉ đổi THỨ
                // TỰ ưu tiên qua if/else bên dưới — rủi ro thấp nhất có thể
                // cho 1 thay đổi thêm nhánh mới). Điều kiện: CÙNG điều kiện
                // đủ anchor như multiCharAnchors (giữ mặt được) NHƯNG cần
                // THÊM file `unet_triple_combo_{N}region.mnn` — nếu file đó
                // KHÔNG có, nhánh này tự bỏ qua (null), rơi xuống
                // multiCharAnchors/useRegional như TRƯỚC mục 152, không đổi
                // hành vi hiện tại của bất kỳ story nào chưa export model
                // triple combo.
                //
                // GIỚI HẠN THẬT: dùng regionOrderTc (tôn trọng
                // regionalColumnOrder override) làm thứ tự DUY NHẤT cho CẢ
                // prompt chữ lẫn ảnh neo — bắt buộc phải khớp nhau (xem
                // GIỚI HẠN THẬT trong docstring export script: ranh giới cột
                // cứng dùng chung cho danh tính ảnh và prompt). KHÔNG áp
                // dụng Multi-Pass Inpainting Cascade (runMultiPassCascade
                // gắn chặt với format multiCharAnchors/pipeline mask, không
                // tương thích thẳng — để dành, chưa làm) — vẫn có Quality
                // Gate retry + FleshDeformationEngine + auto-fix interaction
                // (đồng bộ với 2 nhánh kia).
                val regionOrderTc = resolveRegionalOrder(sceneChars, panel.overrideSettings?.regionalColumnOrder)
                val tripleComboAnchors: List<String>? = if (settings.useStoryDiffusion && noCharacterOverride &&
                        sceneChars.size >= 2 && noPairModel && storyManager.hasTripleComboUnet(modelId, sceneChars.size)) {
                    val anchors = regionOrderTc.map { storyManager.getCharacterAnchor(story.id, it, preferTorn = SeedRegistry.resolveActionCategory(panel.scene) == "combat", chapterNumber = chapter.chapterNumber, expressionKey = expressionKeyFor(panel, it)) }
                    if (anchors.all { it != null }) anchors.filterNotNull() else null
                } else null
                // mục 219 TECHNICAL_STATUS.md — "Location Anchor" đợt 3,
                // mirror ĐÚNG nhánh Mc (mục 217 đợt 2) — CẦN ĐỦ CẢ 2: bối
                // cảnh đã có ảnh neo VÀ model "_loc" đúng sceneChars.size
                // đã export. Thiếu 1 trong 2 -> model N-vùng như cũ, KHÔNG
                // đổi hành vi. LƯU Ý cơ chế native ÁP DỤNG KHÁC hẳn Mc
                // (cộng thêm 1 lượt IP-Adapter toàn ảnh, không phải 1 slot
                // mask N+1 — xem GIỚI HẠN THẬT trong export script, công
                // thức MỚI chưa verify thực nghiệm).
                val locationAnchorForTc = panel.scene.locationName?.let { storyManager.getLocationAnchor(story.id, it) }
                val useTcLocationSlot = tripleComboAnchors != null && locationAnchorForTc != null &&
                    storyManager.hasTripleComboUnetWithLocation(modelId, sceneChars.size)

                // mục 184 TECHNICAL_STATUS.md — SDXL Phase 3, ƯU TIÊN CAO
                // NHẤT (kể cả trước Triple-Combo SD1.5): nếu user đã bật
                // modelTier=SDXL cho panel này VÀ có đủ model .mnn SDXL phù
                // hợp, dùng luôn SDXL — KHÔNG chờ Triple-Combo/mask/regional
                // SD1.5 trước, vì user đã CHỌN RÕ muốn SDXL cho panel này
                // (khác các nhánh SD1.5 bên dưới, vốn tự động chọn theo
                // model có sẵn chứ không phải theo lựa chọn tường minh của
                // user). Trả null (KHÔNG throw) nếu thiếu điều kiện — rơi
                // xuống ĐÚNG chuỗi SD1.5 sẵn có bên dưới, không đổi hành vi
                // của bất kỳ story nào chưa cấu hình sdxlModelId. Xem GIỚI
                // HẠN THẬT đầy đủ ở docstring dispatchSdxlPanel().
                val sdxlPath = if (eff.modelTier == ImageModelTier.SDXL)
                    dispatchSdxlPanel(panel, story, settings, eff, sceneChars, allChars, chapter.chapterNumber, outDir) { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } }
                else null

                if (sdxlPath != null) {
                    rawPath = sdxlPath
                    // mục 205 TECHNICAL_STATUS.md — đóng gap thật "SDXL chưa có
                    // Quality Gate riêng" (user chỉ thẳng, đúng — trước bản vá
                    // này panelQualityGatePassed giữ nguyên `true` mặc định cho
                    // MỌI panel dùng SDXL trực tiếp, badge cảnh báo ở
                    // GalleryReviewScreen — mục 185 — không bao giờ hiện dù
                    // khung xương xấu thế nào). `qualityGate.evaluate()` (mục
                    // 74/187) là hàm THUẦN chỉ đọc `skeletonData` — không đọc
                    // model/pixel — nên áp dụng nguyên vẹn cho SDXL, KHÔNG cần
                    // "Quality Gate riêng" nào khác (khác Multi-Pass Cascade —
                    // mục 168 — hay hỗ trợ tỷ lệ khung ảnh khác vuông, cả 2 việc
                    // đó cần code sinh ảnh/export model mới, không áp dụng được
                    // kiểu tái dùng này). KHÔNG có phương án thay thế nào khác
                    // để tự thử nếu fail (panel này ĐÃ LÀ SDXL, không phải SD1.5
                    // để rơi xuống nhánh mục 185 bên dưới) — chỉ để badge hiện
                    // đúng, không tự nhận "đạt" khi thực ra chưa đánh giá.
                    if (settings.enableQualityGate) {
                        val skDataSdxl = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapter.chapterNumber)
                        val precheckSdxl = qualityGate.evaluate(skDataSdxl, sceneChars.size.coerceAtLeast(1))
                        panelQualityGatePassed = precheckSdxl.passed
                        panelQualityGateReasons = precheckSdxl.reasons
                        if (!precheckSdxl.passed) {
                            log("  ⚠ Quality Gate [SDXL trực tiếp]: khung xương KHÔNG đạt " +
                                "(${precheckSdxl.reasons.joinToString().ifBlank { "không rõ lý do" }}) — đây ĐÃ LÀ " +
                                "SDXL, không còn phương án thay thế khác để tự thử — badge cảnh báo vẫn hiện, " +
                                "cần tự xem ảnh để quyết định.")
                        }
                    }
                    // mục 207 TECHNICAL_STATUS.md — đóng gap thật "SDXL
                    // chưa có auto-fix giao thoa riêng" — dùng
                    // img2imgFixSdxl() mới (mirror ĐÚNG hàm img2imgFix()
                    // SD1.5, khác Multi-Pass Cascade/runMultiPassCascade —
                    // CÁI ĐÓ vẫn CHƯA làm cho SDXL, xem comment dòng ~2280,
                    // 2 tính năng khác nhau dù cùng bị gọi chung là
                    // "Cascade" trong câu hỏi ban đầu). `hasSdxlBaseUnet()`
                    // kiểm tra phòng thủ file `unet_sdxl.mnn` — thực tế
                    // luôn có sẵn cùng thư mục augmented (mục 59/207) nhưng
                    // không giả định, đọc file thật trước khi dùng.
                    if (sdxlPath != null && settings.autoFixInteractions && sceneChars.size >= 2 &&
                        storyManager.hasSdxlBaseUnet(settings.sdxlModelId!!)) {
                        try {
                            val sdxlModelDirFix = storyManager.modelsDir.absolutePath + "/" + settings.sdxlModelId
                            val embeddingsDirFix = storyManager.embeddingsDir(story.id).absolutePath
                            imagePipeline.loadSDSdxl(sdxlModelDirFix, embeddingsDirFix, settings.useOpenCL, settings.useNpu)
                            val effPromptSdxl = injectHeadsTallTag(injectEmbeddingTriggers(eff.prompt, panel, allChars, eff.characterName), eff.characterName, allChars)
                            val skDataFixSdxl = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapter.chapterNumber)
                            rawPath = tryAutoFixInteractions(
                                rawPath, eff.width, eff.height, effPromptSdxl, eff.negativePrompt,
                                settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                                panel.index, outDir, skDataFixSdxl, sceneChars.size,
                                characterOrder = panel.scene.characters, allChars = allChars,
                                settings = settings, worldRules = story.worldRules, useSdxlFix = true
                            )
                        } catch (ex: Exception) {
                            log("  ⚠ Auto-fix giao thoa SDXL lỗi (${ex.message}) — giữ ảnh gốc")
                        }
                    }
                } else if (tripleComboAnchors != null) {
                    imagePipeline.loadSDTripleCombo(
                        storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir,
                        sceneChars.size, settings.useOpenCL, settings.useNpu,
                        withLocationSlot = useTcLocationSlot)
                    var regionPromptsTc = buildRegionPrompts(
                        regionOrderTc, panel.overrideSettings?.regionalPromptOverrides ?: emptyMap(),
                        allChars, eff, settings.imageStyle.stylePrompt
                    )
                    run {
                        val skPreviewTc = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderTc, chapterNumber = chapter.chapterNumber)
                        val deformTc = FleshDeformationEngine.analyze(skPreviewTc, sceneChars.size)
                        if (deformTc.tags.isNotEmpty()) {
                            regionPromptsTc = regionPromptsTc.map { it + deformTc.tags }
                            log("  → FleshDeformationEngine: tiêm tag biến dạng vào ${regionPromptsTc.size} cột [triple combo]")
                        }
                    }
                    log("SD panel ${panel.index + 1}/${panels.size} [Triple-Conditioning combo, ${sceneChars.size} nhân vật]" +
                        (if (useTcLocationSlot) " [+ bối cảnh neo ✓]" else ""))

                    val condTc = resolveConditioning(panel.scene, settings, panel.overrideSettings)
                    var rawPathTc: String
                    if (settings.enableQualityGate) {
                        val seedRegTc = if (settings.useSeedRegistry) getOrCreateSeedRegistry(story.id) else null
                        val actionCatTc = SeedRegistry.resolveActionCategory(panel.scene)
                        val numPersonsTc = sceneChars.size
                        val candidateSeedTc = seedRegTc?.suggestSeed(numPersonsTc, actionCatTc) ?: eff.seed

                        // mục 187 TECHNICAL_STATUS.md — THIẾT KẾ LẠI theo đúng góp ý
                        // user: khung xương phải được ĐÁNH GIÁ (duyệt) TRƯỚC khi bắt
                        // đầu "đắp thịt" sinh ảnh, không phải sinh ảnh RỒI mới đánh giá
                        // như code cũ (mục 74, đã vá tạm ở mục 186). Vì `skDataTc`
                        // không đổi theo seed/attempt (mục 185/186 xác nhận, kể cả bên
                        // trong PoseRetargeter — không có Random nào), đánh giá 1 LẦN
                        // DUY NHẤT ở đây, TRƯỚC lệnh sinh ảnh — không còn vòng lặp
                        // "sinh rồi mới biết có đạt không" (mục 186 chỉ giảm từ 3 xuống
                        // 1 lần sinh lãng phí; bản này còn 0 lần lãng phí — biết kết quả
                        // trước khi tốn bất kỳ lần sinh ảnh SD1.5 nào).
                        val skDataTc = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderTc, chapterNumber = chapter.chapterNumber)
                        val precheckTc = qualityGate.evaluate(skDataTc, numPersonsTc)
                        if (precheckTc.passed) {
                            seedRegTc?.recordPerfectSeed(numPersonsTc, actionCatTc, candidateSeedTc)
                        } else {
                            log("  ⚠ Quality Gate [triple combo]: khung xương KHÔNG đạt TRƯỚC khi sinh " +
                                "(${precheckTc.reasons.joinToString().ifBlank { "không rõ lý do" }}) — vẫn sinh 1 lần " +
                                "với SD1.5 (retry thêm vô ích, xem mục 185/187), quy trình thay thế SDXL sẽ áp dụng " +
                                "ngay sau nếu có cấu hình.")
                        }
                        rawPathTc = imagePipeline.generatePanelTripleCombo(
                            panelIndex = panel.index, regionPrompts = regionPromptsTc, negativePrompt = eff.negativePrompt,
                            referenceImagePaths = tripleComboAnchors, skeletonData = skDataTc,
                            width = eff.width, height = eff.height,
                            steps = eff.steps, cfgScale = eff.cfgScale, seed = candidateSeedTc, outDir = outDir,
                            onProgress = { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } },
                            poseScale = condTc.poseConditioningScale, depthScale = condTc.depthConditioningScale,
                            ipDecayFloor = condTc.ipDecayFloor, ipDecayStartTimestep = condTc.ipDecayStartTimestep,
                            // mục 219 — mirror ĐÚNG nhánh Mc.
                            locationAnchorPath = if (useTcLocationSlot) locationAnchorForTc else null,
                            locationScale = settings.locationAnchorStrength
                        )
                        panelQualityGatePassed = precheckTc.passed
                        panelQualityGateReasons = precheckTc.reasons

                        if (settings.autoFixInteractions && sceneChars.size >= 2) {
                            val skFinalTc = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderTc, chapterNumber = chapter.chapterNumber)
                            rawPathTc = tryAutoFixInteractions(
                                rawPathTc, eff.width, eff.height, regionPromptsTc.joinToString(", "), eff.negativePrompt,
                                settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                                panel.index, outDir, skFinalTc, sceneChars.size,
                                characterOrder = regionOrderTc, allChars = allChars, settings = settings, worldRules = story.worldRules
                            )
                        }
                    } else {
                        rawPathTc = imagePipeline.generatePanelTripleCombo(
                            panelIndex = panel.index, regionPrompts = regionPromptsTc, negativePrompt = eff.negativePrompt,
                            referenceImagePaths = tripleComboAnchors,
                            skeletonData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderTc, chapterNumber = chapter.chapterNumber),
                            width = eff.width, height = eff.height,
                            steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed, outDir = outDir,
                            onProgress = { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } },
                            poseScale = condTc.poseConditioningScale, depthScale = condTc.depthConditioningScale,
                            ipDecayFloor = condTc.ipDecayFloor, ipDecayStartTimestep = condTc.ipDecayStartTimestep,
                            // mục 219 — mirror ĐÚNG nhánh Mc.
                            locationAnchorPath = if (useTcLocationSlot) locationAnchorForTc else null,
                            locationScale = settings.locationAnchorStrength
                        )
                    }
                    rawPath = rawPathTc
                } else if (multiCharAnchors != null) {
                    val embeddingsDirMc = embeddingsDir
                    imagePipeline.loadSDAugmentedMultiChar(
                        storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDirMc,
                        sceneChars.size, settings.useOpenCL, settings.useNpu,
                        withLocationSlot = useMcLocationSlot)
                    var effPromptMc = injectEmbeddingTriggers(eff.prompt, panel, allChars, eff.characterName)
                    // mục 111 TECHNICAL_STATUS.md — FleshDeformationEngine: tiêm tag
                    // biến dạng vải/da thịt dựa trên khoảng cách hình học hông/cổ
                    // tay giữa các nhân vật TRƯỚC khi sinh ảnh (bổ trợ cho
                    // detectHandOverBodyOverlaps ở dưới, vốn chạy SAU khi có ảnh để
                    // khoanh vùng inpaint — hai cơ chế không trùng lặp).
                    run {
                        val skPreview = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapter.chapterNumber)
                        val deform = FleshDeformationEngine.analyze(skPreview, sceneChars.size)
                        if (deform.tags.isNotEmpty()) {
                            effPromptMc += deform.tags
                            log("  → FleshDeformationEngine: phát hiện ${if (deform.hasHandContact) "va chạm tay+" else ""}tương tác gần, tiêm tag biến dạng")
                        }
                    }
                    log("SD panel ${panel.index + 1}/${panels.size} [IP-Adapter mask, ${sceneChars.size} nhân vật]" +
                        (if (sceneChars.size >= 4) " [N>=4 — mục 52b: CHƯA xác nhận chạy thật kỹ]" else "") +
                        (if (useMcLocationSlot) " [+ bối cảnh neo ✓]" else ""))

                    // mục 83 TECHNICAL_STATUS.md — PHÁT HIỆN KHI ĐỐI CHIẾU
                    // `thêm_sd1_5.txt` (claim ĐÚNG, đã xác nhận): trước đây
                    // Quality Gate (mục 74) CHỈ wiring cho nhánh 1-nhân-vật,
                    // trong khi CHÍNH nhánh multichar (2+ người dính chạm)
                    // mới là nơi cần đếm-chi/đo-tỷ-lệ-xương NHẤT. Sửa: bọc
                    // retry loop y hệt pattern nhánh đơn người, dùng
                    // `sceneChars.size` làm numPersons.
                    var rawPathMc: String
                    // mục 107 TECHNICAL_STATUS.md — resolveConditioning() thay
                    // vì đọc trực tiếp settings.pose*/depth*/ip* — tự tra preset
                    // theo action_category nếu bật autoConditioningPresets,
                    // rơi về cài đặt chung nếu tắt/không nhận diện được (HÀNH
                    // VI CŨ, không đổi gì nếu cờ mặc định false).
                    val cond = resolveConditioning(panel.scene, settings, panel.overrideSettings)
                    if (settings.enableQualityGate) {
                        val seedRegMc = if (settings.useSeedRegistry) getOrCreateSeedRegistry(story.id) else null
                        val actionCatMc = SeedRegistry.resolveActionCategory(panel.scene)
                        val numPersonsMc = sceneChars.size
                        val candidateSeedMc = seedRegMc?.suggestSeed(numPersonsMc, actionCatMc) ?: eff.seed

                        // mục 187 TECHNICAL_STATUS.md — THIẾT KẾ LẠI, cùng lý do đã
                        // giải thích đầy đủ ở nhánh triple-combo phía trên (không lặp
                        // lại toàn bộ comment): đánh giá khung xương 1 LẦN, TRƯỚC khi
                        // sinh ảnh, thay vì vòng lặp retry-rồi-mới-biết cũ.
                        val skDataMc = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapter.chapterNumber)
                        val precheckMc = qualityGate.evaluate(skDataMc, numPersonsMc)
                        if (precheckMc.passed) {
                            seedRegMc?.recordPerfectSeed(numPersonsMc, actionCatMc, candidateSeedMc)
                        } else {
                            log("  ⚠ Quality Gate [multichar]: khung xương KHÔNG đạt TRƯỚC khi sinh " +
                                "(${precheckMc.reasons.joinToString().ifBlank { "không rõ lý do" }}) — vẫn sinh 1 lần " +
                                "với SD1.5, quy trình thay thế SDXL sẽ áp dụng ngay sau nếu có cấu hình.")
                        }
                        rawPathMc = imagePipeline.generatePanelMultiChar(
                            panelIndex = panel.index, prompt = effPromptMc, negativePrompt = eff.negativePrompt,
                            stylePrompt = settings.imageStyle.stylePrompt, width = eff.width, height = eff.height,
                            steps = eff.steps, cfgScale = eff.cfgScale, seed = candidateSeedMc,
                            referenceImagePaths = multiCharAnchors, skeletonData = skDataMc, outDir = outDir,
                            // mục 147 TECHNICAL_STATUS.md — BUG THẬT ĐÃ SỬA (tiền tồn tại,
                            // không liên quan việc đang làm ở mục này — tự phát hiện khi soát
                            // lại `generatePanelMultiChar()`): TRƯỚC ĐÂY truyền
                            // poseConditioningScale/depthConditioningScale/depthActiveMinTimestep
                            // — hàm KHÔNG HỀ có 3 tham số này (copy nhầm từ call site
                            // generatePanel() 1-nhân-vật, nơi 3 tham số này CÓ nghĩa) — lẽ ra
                            // KHÔNG compile được. Bỏ hẳn 3 dòng đó: model mask N-nhân-vật
                            // (export_ipa_controlnet_mask_unet.py) KHÔNG có Depth ControlNet
                            // (chỉ Pose) VÀ residual Pose cộng thẳng 1:1, không có input scale
                            // nào để truyền — không phải thiếu sót cần thêm vào, là khác biệt
                            // kiến trúc thật giữa 2 pipeline.
                            ipDecayFloor = cond.ipDecayFloor, ipDecayStartTimestep = cond.ipDecayStartTimestep,
                            ipStaticScale = cond.ipStaticScale,
                            // mục 217 (đợt 2) — chỉ khác null khi useMcLocationSlot đúng
                            // (model "_loc" đã export CHO ĐÚNG sceneChars.size VÀ bối cảnh
                            // đã có ảnh neo) — null thì hành vi y hệt trước khi có mục này.
                            locationAnchorPath = if (useMcLocationSlot) locationAnchorForMc else null,
                            locationScale = settings.locationAnchorStrength,
                            onProgress = { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } }
                        )
                        panelQualityGatePassed = precheckMc.passed
                        panelQualityGateReasons = precheckMc.reasons

                        if (settings.autoFixInteractions && sceneChars.size >= 2) {
                            val skFinalMc = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapter.chapterNumber)
                            rawPathMc = tryAutoFixInteractions(
                                rawPathMc, eff.width, eff.height, effPromptMc, eff.negativePrompt,
                                settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                                panel.index, outDir, skFinalMc, sceneChars.size,
                                characterOrder = sceneChars, allChars = allChars, settings = settings, worldRules = story.worldRules
                            )
                        }
                    } else {
                        rawPathMc = imagePipeline.generatePanelMultiChar(
                            panelIndex = panel.index,
                            prompt = effPromptMc, negativePrompt = eff.negativePrompt,
                            stylePrompt = settings.imageStyle.stylePrompt,
                            width = eff.width, height = eff.height,
                            steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                            referenceImagePaths = multiCharAnchors,
                            skeletonData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapter.chapterNumber),
                            outDir = outDir,
                            // mục 147 — xem comment đầy đủ ở call site trên (nhánh Quality
                            // Gate): bỏ poseConditioningScale/depthConditioningScale/
                            // depthActiveMinTimestep — bug thật tiền tồn tại, model mask
                            // N-nhân-vật không có input này.
                            ipDecayFloor = cond.ipDecayFloor, ipDecayStartTimestep = cond.ipDecayStartTimestep,
                            ipStaticScale = cond.ipStaticScale,
                            // mục 217 (đợt 2) — mirror ĐÚNG nhánh Quality Gate ở trên.
                            locationAnchorPath = if (useMcLocationSlot) locationAnchorForMc else null,
                            locationScale = settings.locationAnchorStrength,
                            onProgress = { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } }
                        )
                    }
                    // mục 115/117 TECHNICAL_STATUS.md — Multi-Pass Cascade,
                    // sau CẢ 2 nhánh trên (Quality Gate bật/tắt đều cần) và
                    // sau autoFixInteractions (cascade sửa THÊM trên kết quả
                    // đã fix giao thoa, không thay thế bước đó).
                    if (settings.enableMultiPassCascade && sceneChars.size >= 2) {
                        val skCascade = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapter.chapterNumber)
                        rawPathMc = runMultiPassCascade(
                            rawPathMc, sceneChars, multiCharAnchors, skCascade,
                            eff.prompt, eff.negativePrompt, allChars, settings.imageStyle.stylePrompt,
                            eff.width, eff.height, eff.steps, eff.cfgScale,
                            eff.seed, settings.cascadeDenoiseStrength, panel.index, outDir,
                            // mục 168 TECHNICAL_STATUS.md — Per-Character Expression:
                            // rỗng ở panel.scene.characterExpressions (mặc định,
                            // đa số panel) -> hành vi CŨ 100% (không truyền gì khác
                            // trước đây, exprTag luôn null trong runMultiPassCascade).
                            // mục 197: merge thêm override tay của user (nếu có) —
                            // override THẮNG cho tên trùng (Map `+` bên phải đè bên
                            // trái), người KHÔNG override vẫn giữ nguyên giá trị LLM.
                            characterExpressions = effectiveExpressionMap(panel),
                            promptStyle = resolvePromptStyle(settings),
                            // mục 170 TECHNICAL_STATUS.md — CÙNG công thức
                            // effectiveDepthScale trong resolveSkeletonData()
                            // (tường minh ưu tiên, suy luận cameraAngle làm
                            // fallback) — không gọi lại resolveSkeletonData()
                            // vì hàm đó trả FloatArray đã áp dụng, không trả
                            // map theo tên; tính lại map riêng ở đây RẺ (chỉ
                            // đọc field có sẵn/1 phép suy luận nhẹ, không I/O).
                            depthOrder = panel.scene.depthScale.ifEmpty { inferDepthScaleFromCameraAngle(panel.scene) }
                        )
                    }
                    rawPath = rawPathMc
                } else if (useRegionalMask) {
                    // mục 172 TECHNICAL_STATUS.md — CÙNG khung với nhánh
                    // `useRegional` ngay dưới (Quality Gate retry, FleshDeformationEngine,
                    // autoFixInteractions) — CHỈ khác: dùng
                    // generatePanelRegionalMask() (mask thật) thay vì
                    // generatePanelRegional() (cột cứng), và cần dựng thêm
                    // `region_masks` + `backgroundPrompt` TRƯỚC khi gọi.
                    // KHÔNG dùng `resolveRegionalOrder()`/`regionalColumnOrder`
                    // override (khái niệm "thứ tự CỘT" không còn ý nghĩa với
                    // mask hình dạng tuỳ ý — override đó dành RIÊNG cho bản
                    // cột, cố tình không áp dụng ở đây) — dùng thẳng
                    // `sceneChars` (thứ tự ổn định sẵn có, mục 118).
                    imagePipeline.loadSDRegionalMask(
                        storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir,
                        sceneChars.size, settings.useOpenCL, settings.useNpu)
                    var regionPromptsRm = buildRegionPrompts(
                        sceneChars, panel.overrideSettings?.regionalPromptOverrides ?: emptyMap(),
                        allChars, eff, settings.imageStyle.stylePrompt
                    )
                    // Background prompt: KHÔNG gắn anchorPrompt của bất kỳ ai
                    // (đúng ý nghĩa "vùng không nhân vật nào claim") — dùng
                    // scene prompt chung + style, y hệt phần "prompt scene
                    // chung" đã dùng trong isolatedPrompt của Cascade (mục 168).
                    val backgroundPromptRm = "${eff.prompt}, ${settings.imageStyle.stylePrompt}"
                    run {
                        val skPreviewRm = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapter.chapterNumber)
                        val deformRm = FleshDeformationEngine.analyze(skPreviewRm, sceneChars.size)
                        if (deformRm.tags.isNotEmpty()) {
                            regionPromptsRm = regionPromptsRm.map { it + deformRm.tags }
                            log("  → FleshDeformationEngine: tiêm tag biến dạng vào ${regionPromptsRm.size} vùng")
                        }
                    }
                    log("SD panel ${panel.index + 1}/${panels.size} [Regional-Mask, ${sceneChars.size} vùng]")

                    var rawPathRm: String
                    if (settings.enableQualityGate) {
                        val seedRegRm = if (settings.useSeedRegistry) getOrCreateSeedRegistry(story.id) else null
                        val actionCatRm = SeedRegistry.resolveActionCategory(panel.scene)
                        val numPersonsRm = sceneChars.size
                        val candidateSeedRm = seedRegRm?.suggestSeed(numPersonsRm, actionCatRm) ?: eff.seed

                        // mục 187 TECHNICAL_STATUS.md — THIẾT KẾ LẠI, cùng lý do đã
                        // giải thích đầy đủ ở nhánh triple-combo phía trên (không lặp
                        // lại toàn bộ comment): đánh giá khung xương 1 LẦN, TRƯỚC khi
                        // sinh ảnh, thay vì vòng lặp retry-rồi-mới-biết cũ.
                        val skDataRm = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapter.chapterNumber)
                        val precheckRm = qualityGate.evaluate(skDataRm, numPersonsRm)
                        if (precheckRm.passed) {
                            seedRegRm?.recordPerfectSeed(numPersonsRm, actionCatRm, candidateSeedRm)
                        } else {
                            log("  ⚠ Quality Gate [regional-mask]: khung xương KHÔNG đạt TRƯỚC khi sinh " +
                                "(${precheckRm.reasons.joinToString().ifBlank { "không rõ lý do" }}) — vẫn sinh 1 lần " +
                                "với SD1.5, quy trình thay thế SDXL sẽ áp dụng ngay sau nếu có cấu hình.")
                        }
                        val regionMasksRm = buildRegionMasksForPanel(sceneChars, skDataRm, eff.width, eff.height, panel.index, outDir)
                        rawPathRm = imagePipeline.generatePanelRegionalMask(
                            panelIndex = panel.index, regionPrompts = regionPromptsRm, backgroundPrompt = backgroundPromptRm,
                            negativePrompt = eff.negativePrompt, regionMasks = regionMasksRm, skeletonData = skDataRm,
                            width = eff.width, height = eff.height, steps = eff.steps, cfgScale = eff.cfgScale, seed = candidateSeedRm, outDir = outDir
                        ) { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } }
                        panelQualityGatePassed = precheckRm.passed
                        panelQualityGateReasons = precheckRm.reasons

                        if (settings.autoFixInteractions && sceneChars.size >= 2) {
                            val skFinalRm = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapter.chapterNumber)
                            rawPathRm = tryAutoFixInteractions(
                                rawPathRm, eff.width, eff.height, regionPromptsRm.joinToString(", "), eff.negativePrompt,
                                settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                                panel.index, outDir, skFinalRm, sceneChars.size,
                                characterOrder = sceneChars, allChars = allChars, settings = settings, worldRules = story.worldRules
                            )
                        }
                    } else {
                        val skDataRm = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapter.chapterNumber)
                        val regionMasksRm = buildRegionMasksForPanel(sceneChars, skDataRm, eff.width, eff.height, panel.index, outDir)
                        rawPathRm = imagePipeline.generatePanelRegionalMask(
                            panelIndex = panel.index, regionPrompts = regionPromptsRm, backgroundPrompt = backgroundPromptRm,
                            negativePrompt = eff.negativePrompt, regionMasks = regionMasksRm, skeletonData = skDataRm,
                            width = eff.width, height = eff.height, steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed, outDir = outDir
                        ) { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } }
                    }
                    rawPath = rawPathRm
                } else if (useRegional) {
                    imagePipeline.loadSDRegional(
                        storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir,
                        sceneChars.size, settings.useOpenCL, settings.useNpu)
                    val regionOrderRg = resolveRegionalOrder(sceneChars, panel.overrideSettings?.regionalColumnOrder)
                    var regionPrompts = buildRegionPrompts(
                        regionOrderRg, panel.overrideSettings?.regionalPromptOverrides ?: emptyMap(),
                        allChars, eff, settings.imageStyle.stylePrompt
                    )
                    // mục 111 TECHNICAL_STATUS.md — FleshDeformationEngine, xem
                    // giải thích đầy đủ ở nhánh multichar phía trên. Ở Regional
                    // Prompting, tag áp cho MỌI cột (tương tác là giữa các cột,
                    // không thuộc riêng cột nào).
                    run {
                        val skPreviewRg = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderRg, chapterNumber = chapter.chapterNumber)
                        val deformRg = FleshDeformationEngine.analyze(skPreviewRg, sceneChars.size)
                        if (deformRg.tags.isNotEmpty()) {
                            regionPrompts = regionPrompts.map { it + deformRg.tags }
                            log("  → FleshDeformationEngine: tiêm tag biến dạng vào ${regionPrompts.size} cột")
                        }
                    }
                    log("SD panel ${panel.index + 1}/${panels.size} [Regional Prompting, ${sceneChars.size} cột]")

                    // mục 83 TECHNICAL_STATUS.md — vá nốt gap Quality Gate
                    // còn lại (nhánh multichar đã vá cùng lượt trước, nhánh
                    // này bỏ sót do có chữ ký hàm khác — `generatePanelRegional()`
                    // nhận `regionPrompts: List<String>` thay vì 1 prompt +
                    // reference anchors, không có tham số `stylePrompt`/
                    // `referenceImagePaths` như 2 nhánh kia).
                    var rawPathRg: String
                    if (settings.enableQualityGate) {
                        val seedRegRg = if (settings.useSeedRegistry) getOrCreateSeedRegistry(story.id) else null
                        val actionCatRg = SeedRegistry.resolveActionCategory(panel.scene)
                        val numPersonsRg = sceneChars.size
                        val candidateSeedRg = seedRegRg?.suggestSeed(numPersonsRg, actionCatRg) ?: eff.seed

                        // mục 187 TECHNICAL_STATUS.md — THIẾT KẾ LẠI, cùng lý do đã
                        // giải thích đầy đủ ở nhánh triple-combo phía trên (không lặp
                        // lại toàn bộ comment): đánh giá khung xương 1 LẦN, TRƯỚC khi
                        // sinh ảnh, thay vì vòng lặp retry-rồi-mới-biết cũ.
                        val skDataRg = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderRg, chapterNumber = chapter.chapterNumber)
                        val precheckRg = qualityGate.evaluate(skDataRg, numPersonsRg)
                        if (precheckRg.passed) {
                            seedRegRg?.recordPerfectSeed(numPersonsRg, actionCatRg, candidateSeedRg)
                        } else {
                            log("  ⚠ Quality Gate [regional]: khung xương KHÔNG đạt TRƯỚC khi sinh " +
                                "(${precheckRg.reasons.joinToString().ifBlank { "không rõ lý do" }}) — vẫn sinh 1 lần " +
                                "với SD1.5, quy trình thay thế SDXL sẽ áp dụng ngay sau nếu có cấu hình.")
                        }
                        rawPathRg = imagePipeline.generatePanelRegional(
                            panelIndex = panel.index, regionPrompts = regionPrompts, negativePrompt = eff.negativePrompt,
                            skeletonData = skDataRg, width = eff.width, height = eff.height,
                            steps = eff.steps, cfgScale = eff.cfgScale, seed = candidateSeedRg, outDir = outDir
                        ) { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } }
                        panelQualityGatePassed = precheckRg.passed
                        panelQualityGateReasons = precheckRg.reasons

                        if (settings.autoFixInteractions && sceneChars.size >= 2) {
                            val skFinalRg = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderRg, chapterNumber = chapter.chapterNumber)
                            rawPathRg = tryAutoFixInteractions(
                                rawPathRg, eff.width, eff.height, regionPrompts.joinToString(", "), eff.negativePrompt,
                                settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                                panel.index, outDir, skFinalRg, sceneChars.size,
                                characterOrder = regionOrderRg, allChars = allChars, settings = settings, worldRules = story.worldRules
                            )
                        }
                    } else {
                        rawPathRg = imagePipeline.generatePanelRegional(
                            panelIndex = panel.index,
                            regionPrompts = regionPrompts, negativePrompt = eff.negativePrompt,
                            skeletonData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderRg, chapterNumber = chapter.chapterNumber),
                            width = eff.width, height = eff.height,
                            steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                            outDir = outDir
                        ) { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } }
                    }
                    rawPath = rawPathRg
                // mục 222-226 TECHNICAL_STATUS.md — GLIGEN. Mục 225 từng
                // giới hạn CHỈ panel 0-nhân-vật (coi "mất nhất quán khuôn
                // mặt" là đánh đổi không đáng) — mục 226 tự sửa: tra cứu
                // thật xác nhận CÓ THỂ ghép GLIGEN + IP-Adapter TRÊN CÙNG 1
                // UNet (ComfyUI tách GLIGEN "conditioning" khỏi IPAdapter
                // "model patch" — ghép được cùng lúc; paper InteractDiffusion
                // "pluggable" trên nền GLIGEN; `IPAdapterMixin.load_ip_adapter()`
                // là mixin chung không ràng buộc `attention_type`). Đã export
                // (`export_gligen_unet.py --with_character_slot`) + nối native
                // (`gligen_wrapper.cpp` mục 226) 1 biến thể "_char" — GIỜ cho
                // phép ĐÚNG 1 nhân vật chính (không phải N — cơ chế này mirror
                // `export_ipa_controlnet_unet.py`, bản 1-nhân-vật, KHÔNG phải
                // bản mask N-nhân-vật) cùng lúc với object_boxes.
                // Panel ≥2 nhân vật + object_boxes: VẪN rơi về hành vi cũ
                // (object_boxes bị bỏ qua, dùng nhánh Mc/base bình thường) —
                // cơ chế "_char" chỉ có 1 slot ip_image_embeds, không phải
                // mask N-nhân-vật như mục 217 đợt 2 — CHƯA mở rộng, xem GIỚI
                // HẠN THẬT mục 226.
                // Ưu tiên: object_boxes hợp lệ + model GLIGEN phù hợp sẵn
                // sàng (biến thể "_char" nếu có đúng 1 nhân vật, biến thể
                // thường nếu 0 nhân vật) THẮNG ảnh neo bối cảnh (mục 217) —
                // 2 UNet khác nhau không dùng chung 1 lượt được, GLIGEN giải
                // đúng vấn đề đang được hỏi trực tiếp (tỷ lệ vật thể).
                } else if (run {
                        if (!settings.useStoryDiffusion) return@run false
                        if (resolveObjectBoxes(panel.scene, panel.overrideSettings?.objectBoxOverride).isEmpty()) return@run false
                        if (panel.scene.characters.size > 1) return@run false
                        val charName = panel.scene.characters.firstOrNull()
                        if (charName == null) return@run storyManager.hasGligenUnet(modelId)
                        // Có nhân vật nhưng CHƯA có anchor (lần đầu xuất
                        // hiện) -> KHÔNG rẽ vào GLIGEN (không có gì để giữ
                        // nhất quán) — điều kiện else-if trả false, tự rơi
                        // xuống else bên dưới (base/Mc bình thường) — KHÔNG
                        // cần khối lệnh rẽ nhánh phụ nào bên trong thân if.
                        storyManager.getCharacterAnchor(story.id, charName, chapterNumber = chapter.chapterNumber, expressionKey = expressionKeyFor(panel, charName)) != null &&
                            storyManager.hasGligenUnetWithCharacter(modelId)
                    }) {
                    val resolvedBoxes = resolveObjectBoxes(panel.scene, panel.overrideSettings?.objectBoxOverride)
                    val gligenCharName = panel.scene.characters.firstOrNull()
                    val gligenCharAnchor = gligenCharName?.let { storyManager.getCharacterAnchor(story.id, it, chapterNumber = chapter.chapterNumber, expressionKey = expressionKeyFor(panel, it)) }
                    log("SD panel ${panel.index + 1}/${panels.size} [GLIGEN, ${resolvedBoxes.size} vật thể nền" +
                        (if (gligenCharAnchor != null) ", + nhân vật $gligenCharName" else "") + "]")
                    imagePipeline.loadSDGligen(storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir,
                        settings.useOpenCL, settings.useNpu, withCharacterSlot = gligenCharAnchor != null)
                    val rawPathGligen = imagePipeline.generatePanelGligen(
                        panelIndex = panel.index,
                        prompt = eff.prompt, negativePrompt = eff.negativePrompt,
                        stylePrompt = settings.imageStyle.stylePrompt,
                        objectBoxes = resolvedBoxes,
                        width = eff.width, height = eff.height,
                        steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                        outDir = outDir,
                        onProgress = { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } },
                        referenceImagePath = gligenCharAnchor
                    )
                    rawPath = rawPathGligen
                } else {

                // Lấy ẢNH anchor thật của nhân vật (không còn "embedding
                // giả" — IP-Adapter tự encode lại từ ảnh mỗi lần dùng).
                val characterReferenceImage = eff.characterName?.let { storyManager.getCharacterAnchor(story.id, it, preferTorn = SeedRegistry.resolveActionCategory(panel.scene) == "combat", chapterNumber = chapter.chapterNumber, expressionKey = expressionKeyFor(panel, it)) }

                // mục 217 TECHNICAL_STATUS.md — "Location Anchor", PHẦN TẠO
                // TÁC DỤNG THẬT đầu tiên (tiếp mục 216, mới chỉ có nền
                // móng dữ liệu). Nhánh NÀY (else của multiCharAnchors/
                // tripleCombo/regionalMask/regional) là nơi DUY NHẤT dùng
                // pipeline augmented "1 slot ip_image_embeds" (loadSDAugmented
                // + sdTxt2ImgWithReferenceAndPose) — khi panel KHÔNG có
                // nhân vật nào (eff.characterName null, do panel.scene.characters
                // rỗng — cảnh toàn cảnh/thiết lập bối cảnh), slot đó đang
                // RẢNH HOÀN TOÀN (characterReferenceImage null, ảnh trước đây
                // luôn sinh với 0 điều kiện ảnh gì). Dùng đúng slot rảnh đó
                // cho ảnh neo bối cảnh nếu locationName đã có anchor.
                //
                // GIỚI HẠN THẬT — ĐỌC KỸ trước khi tưởng đây đã "xong toàn
                // bộ mục 216": panel CÓ nhân vật KHÔNG dùng được cách này.
                // Đã đọc kỹ ip_adapter.cpp::onBeforeUnetRun() (input
                // "ip_image_embeds") để xác nhận: số "slot" identity là
                // HẰNG SỐ CỐ ĐỊNH của chính file .mnn đã export (N nhân vật,
                // native tự suy từ elementSize() thật) — nếu Kotlin truyền
                // NHIỀU ảnh hơn N (vd thêm 1 ảnh bối cảnh vào cuối
                // referenceImagePaths của nhánh multiCharAnchors/
                // tripleComboAnchors phía trên), native chỉ log cảnh báo rồi
                // CẮT BỎ ÂM THẦM đúng phần dư — ảnh cuối bị bỏ, KHÔNG có tác
                // dụng gì cả. Comment cũ ở `Story.locations` (Models.kt,
                // viết lúc mới tạo Location mục 216) ghi "tái dùng nguyên cơ
                // chế... không cần code native mới" — SAI, đã tự phát hiện
                // và sửa lại comment đó cùng lượt này (đúng bài học mục 215
                // ngay phía trên: đối chiếu code thật trước khi khẳng định).
                // Muốn ảnh neo bối cảnh ảnh hưởng NỀN của panel CÓ nhân vật
                // cần re-export UNet mask với 1 slot ip_image_embeds THỨ N+1
                // riêng (mask = phần ảnh KHÔNG nhân vật nào phủ) — việc CHƯA
                // làm, xem "VIỆC CÒN LẠI" cuối mục 217.
                val locationReferenceImage = if (characterReferenceImage == null && panel.scene.characters.isEmpty())
                    panel.scene.locationName?.let { storyManager.getLocationAnchor(story.id, it) }
                else null
                val usingLocationAnchor = locationReferenceImage != null
                val referenceImage = characterReferenceImage ?: locationReferenceImage

                // Textual Inversion cho nhân vật PHỤ trong panel (mục 12
                // TECHNICAL_STATUS.md) — người không được chọn làm
                // eff.characterName (chỉ 1 người/panel được neo LoRA/IP-
                // Adapter) vẫn có thể được neo Ở MỨC YẾU HƠN qua trigger
                // word TI, nếu họ có embeddingTrigger. Không thay thế được
                // IP-Adapter/LoRA, chỉ là lớp phòng hộ thêm — vẫn tốt hơn
                // hoàn toàn không có gì.
                val effPrompt = injectHeadsTallTag(injectEmbeddingTriggers(eff.prompt, panel, allChars, eff.characterName), eff.characterName, allChars)

                log("SD panel ${panel.index + 1}/${panels.size}" +
                    (if (characterReferenceImage != null) " [anchor ✓]" else "") +
                    (if (usingLocationAnchor) " [bối cảnh neo ✓]" else "") +
                    (if (modelId != settings.sdModelId) " [model riêng: $modelId]" else ""))

                if (settings.useStoryDiffusion && referenceImage != null) {
                    imagePipeline.loadSDAugmented(storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir, settings.useOpenCL, settings.useNpu)
                }

                // mục 74/75 TECHNICAL_STATUS.md — Quality Gate + Seed Registry.
                // mục 187 (THIẾT KẾ LẠI — thay cho mục 83 mô tả retry loop CŨ,
                // nay không còn nữa): CẢ 5 nhánh sinh ảnh (1-nhân-vật ở đây,
                // multi-char, regional, regional-mask, triple-combo) đều đánh
                // giá khung xương 1 LẦN DUY NHẤT TRƯỚC khi sinh (không còn vòng
                // lặp `for (attempt in 0 until QualityGateChecker.MAX_RETRY)` —
                // đã xoá hẳn ở cả 5 chỗ, xem mục 187 lý do: khung xương không
                // đổi theo seed nên lặp lại vô ích). Khi TẮT (mặc định), hành
                // vi y hệt 1 lần gọi generatePanel() như cũ (không đổi).
                var rawPath2: String
                // mục 107 TECHNICAL_STATUS.md — resolveConditioning(), xem
                // chú thích đầy đủ ở nhánh multichar phía trên.
                val cond2 = resolveConditioning(panel.scene, settings, panel.overrideSettings)
                // mục 217 TECHNICAL_STATUS.md — cond2.ipStaticScale (mặc
                // định = settings.consistencyStrength, 0.8) được HIỆU CHỈNH
                // cho NHÂN VẬT — dùng nguyên cho ảnh neo bối cảnh sẽ ép NỀN
                // quá cứng (dễ khoá luôn bố cục thay vì chỉ ảnh hưởng màu
                // sắc/không khí như mong muốn — xem ghi chú "Cần quyết định
                // trọng số riêng" ở mục 216). settings.locationAnchorStrength
                // (mặc định 0.5, TÁCH RIÊNG khỏi consistencyStrength) là giá
                // trị khởi điểm hợp lý CHƯA có số liệu A/B thật — user tự
                // tinh chỉnh qua Cài đặt (xem SettingsScreen.kt). CHỈ áp
                // dụng khi usingLocationAnchor thật sự đúng (panel 0-nhân-
                // vật + có anchor bối cảnh) — mọi trường hợp khác giữ NGUYÊN
                // cond2.ipStaticScale như cũ, không đổi hành vi.
                val effectiveIpStaticScale = if (usingLocationAnchor) settings.locationAnchorStrength else cond2.ipStaticScale
                if (settings.enableQualityGate) {
                    val seedReg = if (settings.useSeedRegistry) getOrCreateSeedRegistry(story.id) else null
                    val actionCat = SeedRegistry.resolveActionCategory(panel.scene)
                    val numPersons = panel.scene.characters.size.coerceAtLeast(1)
                    val candidateSeed = seedReg?.suggestSeed(numPersons, actionCat) ?: eff.seed

                    // mục 187 TECHNICAL_STATUS.md — THIẾT KẾ LẠI theo đúng góp ý
                    // user: khung xương phải được ĐÁNH GIÁ (duyệt) TRƯỚC khi bắt
                    // đầu "đắp thịt" sinh ảnh, không phải sinh ảnh RỒI mới đánh giá
                    // như code cũ (mục 74, vá tạm ở mục 186). Vì `skData` không đổi
                    // theo seed/attempt (mục 185/186 xác nhận, kể cả bên trong
                    // PoseRetargeter — không Random nào), đánh giá 1 LẦN DUY NHẤT ở
                    // đây, TRƯỚC lệnh sinh ảnh — không còn vòng lặp "sinh rồi mới
                    // biết có đạt không". `firstPassPerfect` (biến cũ) đã bỏ — khai
                    // báo nhưng CHƯA từng được đọc ở đâu khác (đã grep xác nhận),
                    // chỉ là dead code, không mất chức năng thật nào khi bỏ.
                    val skData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapter.chapterNumber)
                    val precheck = qualityGate.evaluate(skData, numPersons)
                    if (precheck.passed) {
                        seedReg?.recordPerfectSeed(numPersons, actionCat, candidateSeed)
                    } else {
                        log("  ⚠ Quality Gate: khung xương KHÔNG đạt TRƯỚC khi sinh " +
                            "(${precheck.reasons.joinToString().ifBlank { "không rõ lý do" }}) — vẫn sinh 1 lần " +
                            "với SD1.5, quy trình thay thế SDXL sẽ áp dụng ngay sau nếu có cấu hình.")
                    }

                    rawPath2 = imagePipeline.generatePanel(
                        panelIndex = panel.index,
                        prompt = effPrompt, negativePrompt = eff.negativePrompt,
                        stylePrompt = settings.imageStyle.stylePrompt,
                        width = eff.width, height = eff.height,
                        steps = eff.steps, cfgScale = eff.cfgScale, seed = candidateSeed,
                        referenceImagePath = referenceImage,
                        skeletonData = skData,
                        useStoryDiffusion = settings.useStoryDiffusion, outDir = outDir,
                        onProgress = { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } },
                        poseConditioningScale = cond2.poseConditioningScale,
                        depthConditioningScale = cond2.depthConditioningScale,
                        depthActiveMinTimestep = cond2.depthActiveMinTimestep,
                        ipDecayFloor = cond2.ipDecayFloor,
                        ipDecayStartTimestep = cond2.ipDecayStartTimestep,
                        ipStaticScale = effectiveIpStaticScale
                    )
                    panelQualityGatePassed = precheck.passed
                    panelQualityGateReasons = precheck.reasons

                    // mục 74 — auto-fix vùng giao thoa hông/tay nếu bật + ≥2 người
                    if (settings.autoFixInteractions && numPersons >= 2) {
                        val skDataFinal = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapter.chapterNumber)
                        rawPath2 = tryAutoFixInteractions(
                            rawPath2, eff.width, eff.height, effPrompt, eff.negativePrompt,
                            settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                            panel.index, outDir, skDataFinal, numPersons,
                            characterOrder = panel.scene.characters, allChars = allChars, settings = settings, worldRules = story.worldRules
                        )
                    }
                } else {
                    rawPath2 = imagePipeline.generatePanel(
                        panelIndex = panel.index,
                        prompt = effPrompt, negativePrompt = eff.negativePrompt,
                        stylePrompt = settings.imageStyle.stylePrompt,
                        width = eff.width, height = eff.height,
                        steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                        referenceImagePath = referenceImage,
                        skeletonData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapter.chapterNumber),
                        useStoryDiffusion = settings.useStoryDiffusion, outDir = outDir,
                        onProgress = { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } },
                        poseConditioningScale = cond2.poseConditioningScale,
                        depthConditioningScale = cond2.depthConditioningScale,
                        depthActiveMinTimestep = cond2.depthActiveMinTimestep,
                        ipDecayFloor = cond2.ipDecayFloor,
                        ipDecayStartTimestep = cond2.ipDecayStartTimestep,
                        ipStaticScale = effectiveIpStaticScale
                    )
                }
                rawPath = rawPath2
                } // end single-character-anchor branch (else of multiCharAnchors != null)
                } // end local-generation branch

                // mục 185 TECHNICAL_STATUS.md — "quy trình thay thế" THẬT khi
                // SD1.5 không đạt yêu cầu chất lượng đầu ra (Quality Gate, mục
                // 74, THIẾT KẾ LẠI ở mục 187) — trả lời trực tiếp câu hỏi user
                // đặt ra. Đây KHÁC nhánh "SDXL làm chính" ở trên (`sdxlPath`,
                // user tự chọn rõ modelTier=SDXL) — ở ĐÂY, SD1.5 vẫn được ưu
                // tiên/đã sinh (mục 187: ĐÚNG 1 lần, đánh giá khung xương
                // TRƯỚC khi sinh — không còn "chạy đủ MAX_RETRY lần" như bản
                // mục 185 gốc mô tả, xem mục 187), chỉ khi NÓ THẬT SỰ không
                // đạt mới thử SDXL bổ sung.
                //
                // GIỚI HẠN THẬT quan trọng — ĐỌC KỸ trước khi tưởng đây là "tự
                // sửa lỗi": `QualityGateChecker.evaluate()` (mục 74) chỉ đọc
                // `skeletonData` — khung xương ĐẦU VÀO feed cho ControlNet-Pose
                // — theo đúng docstring lớp đó ("KHÔNG chạy inference lần 2").
                // `resolveSkeletonData()` là hàm THUẦN (không phụ thuộc seed/
                // attempt/model), nên khung xương giống hệt nhau dù SD1.5 hay
                // SDXL sinh ảnh — nghĩa là gọi lại `qualityGate.evaluate()` để
                // "xác nhận SDXL khá hơn" sẽ LUÔN cho ra ĐÚNG NGUYÊN defectScore
                // (vô nghĩa, không dùng làm căn cứ được). Vì vậy bước này KHÔNG
                // đánh giá lại ảnh SDXL bằng Quality Gate — chỉ ĐÁNH CƯỢC có
                // chủ đích rằng 1 kiến trúc/độ phân giải khác (SDXL, 768² hoặc
                // 1024² tuỳ Cài đặt — mục 189, không còn cố định 1024² như bản
                // mục 185 gốc) có thể xử lý khung xương biên (borderline) này
                // khá hơn TRONG THỰC TẾ, dù không có cách nào xác minh lại bằng
                // chính cơ chế hiện có. `panelQualityGatePassed` CỐ Ý giữ
                // nguyên `false` sau bước này (KHÔNG tự nhận đã "qua" — panel
                // vẫn cần mắt người duyệt lại ở GalleryReviewScreen), chỉ thêm
                // 1 dòng lý do để biết panel đã thử phương án thay thế. Nếu
                // `dispatchSdxlPanel()` trả null (thiếu sdxlModelId/model
                // .mnn/ảnh anchor phù hợp), GIỮ NGUYÊN ảnh SD1.5 gốc (dù chưa
                // đạt) — không throw, không chặn tiến trình sinh cả chương vì
                // 1 panel.
                //
                // Lưu ý phụ: nếu panel này TRÙNG với panel lưu anchor lần đầu
                // của nhân vật (đoạn code ngay dưới), anchor sẽ lưu ẢNH SDXL
                // (nếu đã thay) — cùng hành vi đã chấp nhận cho nhánh
                // `sdxlPath` phía trên, không phải rủi ro MỚI riêng của bước
                // này.
                var sdxlReplacedByFallback = false
                if (!panelQualityGatePassed && eff.modelTier != ImageModelTier.SDXL) {
                    // mục 212 TECHNICAL_STATUS.md — Build APK #117 THẬT (log
                    // user gửi) — lỗi biên dịch THẬT ĐẦU TIÊN của cả dự án kể
                    // từ Build #97 (build.yml đã qua được bước SDK/CMake/NDK
                    // nhờ mục 210, lần đầu tiên chạm tới compileDebugKotlin).
                    // `sceneChars` (khai báo ở dòng ~2220) nằm TRONG nhánh
                    // `else` của "Local/Remote routing" (dòng ~2176, đóng lại
                    // ở dòng ~2855 — xem 2 comment "end ... branch" ngay trên)
                    // — khối "SD1.5 fail → thử SDXL" này (mục 185, KHÔNG phải
                    // code của tôi viết trong đợt 203-211) nằm SAU khi nhánh
                    // đó đã đóng, nên `sceneChars` hết phạm vi — lỗi CÓ SẴN từ
                    // lúc mục 185 viết, chỉ chưa ai phát hiện vì code CHƯA
                    // TỪNG compile được tới đây trước Build #117. Tính lại
                    // TẠI CHỖ — mirror ĐÚNG biểu thức gốc dòng 2220, hàm thuần
                    // không có tác dụng phụ, an toàn tính lại 1 lần nữa.
                    val sceneChars = stableCharacterOrder(panel.scene.characters, allChars)
                    val sdxlFallbackPath = dispatchSdxlPanel(
                        panel, story, settings, eff, sceneChars, allChars, chapter.chapterNumber, outDir
                    ) { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } }
                    if (sdxlFallbackPath != null) {
                        log("  → Panel ${panel.index + 1}: SD1.5 không đạt Quality Gate " +
                            "(${panelQualityGateReasons.joinToString().ifBlank { "không rõ lý do" }}) — " +
                            "đã thử SDXL thay thế (mục 185, CHƯA xác minh lại được bằng Quality Gate, " +
                            "xem GIỚI HẠN THẬT ở comment ngay trên).")
                        rawPath = sdxlFallbackPath
                        sdxlReplacedByFallback = true
                        panelQualityGateReasons = panelQualityGateReasons +
                            "Đã thay bằng SDXL do SD1.5 không đạt Quality Gate (chưa xác minh lại được)"
                    }
                }

                // mục 229 — SDXL hậu kỳ cho vùng tiếp xúc (nếu bật). Bỏ qua khi
                // panel vừa được thay hẳn bằng SDXL ở khối ngay trên (đã là SDXL).
                if (!sdxlReplacedByFallback) {
                    rawPath = trySdxlFinishPass(rawPath, panel, story, settings, eff, allChars, chapter.chapterNumber, outDir)
                }
                // mục 238 — vẽ lại biểu cảm từng khuôn mặt (nếu bật), CUỐI CÙNG để không bị lượt sửa khác ghi đè.
                rawPath = tryExpressionFacePass(rawPath, panel, story, settings, eff, allChars, chapter.chapterNumber, outDir)

                // Auto-fix mặt/tay ĐÃ CHUYỂN sang upscaleApprovedPanels()
                // (mục 20 TECHNICAL_STATUS.md — chạy SAU upscale, ở độ phân
                // giải cuối, đúng thứ tự Hires-fix trước/ADetailer sau theo
                // chuẩn cộng đồng). KHÔNG còn chạy ở đây (512px, trước upscale).

                // Lưu ảnh gốc làm anchor nếu là lần đầu nhân vật MAIN/SUPPORTING xuất hiện
                eff.characterName?.let { name ->
                    val char = storyManager.loadStory(story.id)?.characters?.find { it.name == name }
                    if (char != null && char.role != CharacterRole.ONETIME && char.anchorImagePath == null) {
                        storyManager.saveCharacterAnchor(story.id, char.id, rawPath)
                        log("  → Lưu anchor cho $name")
                    }
                }

                // mục 217 TECHNICAL_STATUS.md — "Location Anchor", BOOTSTRAP
                // ảnh neo bối cảnh. Mirror ĐÚNG khối lưu anchor nhân vật
                // ngay trên: panel ĐẦU TIÊN thành công của 1 locationName
                // (bất kể panel đó có nhân vật hay không — bootstrap không
                // phụ thuộc nhánh 0-nhân-vật ở trên, CHỈ việc "dùng lại" mới
                // giới hạn vậy) tự trở thành ảnh neo, các panel SAU cùng tên
                // locationName tra ra ảnh này qua getLocationAnchor(). KHÔNG
                // bootstrap trong regeneratePanel() — mirror đúng lựa chọn
                // đã có từ trước với nhân vật (saveCharacterAnchor() cũng
                // CHỈ gọi ở generatePanels(), không gọi lại ở
                // regeneratePanel() — "vẽ lại" 1 panel đã có anchor không
                // nên tự ý ghi đè anchor cũ).
                panel.scene.locationName?.let { locName ->
                    val loc = storyManager.findOrCreateLocation(story.id, locName)
                    if (loc != null && loc.anchorImagePath == null) {
                        storyManager.saveLocationAnchor(story.id, loc.id, rawPath)
                        log("  → Lưu anchor bối cảnh cho \"$locName\"")
                    }
                }

                val elapsed = (System.currentTimeMillis() - startMs) / 1000
                log("✓ Panel ${panel.index + 1} xong (${elapsed}s tổng)")

                val outVerify = verifyOutputPose(rawPath, panel, story, settings, eff, chapter.chapterNumber)
                completedPanels.add(panel.copy(
                    imagePath = rawPath, status = PanelStatus.DONE,
                    generationTimeMs = System.currentTimeMillis() - startMs,
                    resolvedBackend = routing.backend, routingReason = routing.reason,
                    qualityGatePassed = panelQualityGatePassed && (outVerify?.passed ?: true),
                    qualityGateReasons = panelQualityGateReasons + (outVerify?.reasons ?: emptyList())
                ))
                emit(PipelineStage.SD_GENERATING)
            }

            imagePipeline.freeAll()
            thermalMonitor.stop()

            // Dừng ở REVIEW - người dùng duyệt panel trước khi upscale
            emit(PipelineStage.REVIEW, "✓ Sinh xong! Hãy duyệt từng panel trước khi upscale")
            _state.update { it.copy(stage = PipelineStage.REVIEW) }

            // mục 235 TECHNICAL_STATUS.md — cảnh báo lệch tỉ lệ vật thể giữa các panel (chỉ ghi log).
            if (settings.checkObjectScale) {
                try { logObjectScaleWarnings(completedPanels, story, chapter.chapterNumber) }
                catch (ex: Exception) { log("  ⚠ Kiểm tra tỉ lệ vật thể lỗi (${ex.message}) — bỏ qua", LogLevel.WARN) }
            }
            chapter.copy(panels = completedPanels, status = ChapterStatus.REVIEW)
        } catch (e: Exception) {
            _state.update { it.copy(stage = PipelineStage.ERROR, error = e.message) }
            imagePipeline.freeAll(); thermalMonitor.stop()
            throw e
        } finally {
            // mục 83 — LUÔN xoá tham chiếu Job dù thành công/lỗi/bị huỷ (Kotlin
            // đảm bảo `finally` chạy cả khi CancellationException ném ra giữa
            // coroutine, đây chính là cơ chế structured concurrency chuẩn).
            currentJob = null
        }
    }

    // ── Regenerate 1 panel (từ Gallery Review) ─────────────────────────────
    // ĐÃ NỐI: panel.overrideSettings (setting riêng ảnh này, đặt từ
    // GalleryReviewScreen) giờ được áp dụng qua resolveEffective() — trước
    // đây hàm này bỏ qua hoàn toàn override, luôn dùng tầng chung.
    /**
     * mục 144 TECHNICAL_STATUS.md — "import ảnh ngoài thay 1 panel" (khả thi
     * kỹ thuật, đã đánh giá ở mục 140 archive, "cần quyết định sản phẩm
     * trước khi làm" — quyết định ở đây: LÀM, theo đúng 3 rủi ro đã liệt kê
     * ở mục 140 archive, giải quyết từng cái một cách tường minh thay vì
     * đoán):
     *
     * (a) Tỷ lệ ảnh import có thể không khớp settings.width/height — CROP
     *     CENTER về đúng tỷ lệ khung (không stretch méo hình, không thêm
     *     viền đen) rồi resize về đúng kích thước, giống hệt cách
     *     `img2imgFix`/upscale pipeline vốn giả định input đã đúng khung.
     * (b) `resolvedBackend`/`routingReason`/Quality Gate cho ảnh import —
     *     đặt `resolvedBackend = null` (không phải LOCAL/REMOTE nào cả,
     *     UI đọc null → hiện "Ảnh nhập tay" thay vì badge Local/Remote,
     *     xem GalleryReviewScreen), `routingReason = "Ảnh nhập tay (import
     *     ngoài)"`, `qualityGatePassed = true` (bỏ qua Quality Gate — ảnh
     *     người tự chọn, không cần AI tự chấm giải phẫu của chính người
     *     vẽ).
     * (c) ESRGAN/Ultrafix/auto-fix bước SAU không cần đổi gì — vốn nhận
     *     `imagePath` bất kỳ, không phân biệt nguồn gốc ảnh.
     *
     * GIỚI HẠN THẬT: không validate định dạng ảnh (để `BitmapFactory` tự
     * quăng exception nếu file hỏng/không phải ảnh — bắt ở `MainViewModel`,
     * báo lỗi rõ ràng thay vì crash im lặng). CHƯA build-test.
     */
    suspend fun importPanelImage(
        panel: Panel,
        sourceUri: android.net.Uri,
        context: android.content.Context,
        settings: GenerationSettings,
        outDir: File
    ): Panel = withContext(Dispatchers.IO) {
        val srcBytes = context.contentResolver.openInputStream(sourceUri)?.use { it.readBytes() }
            ?: throw RuntimeException("Không đọc được file ảnh đã chọn")
        val srcBitmap = BitmapFactory.decodeByteArray(srcBytes, 0, srcBytes.size)
            ?: throw RuntimeException("File đã chọn không phải ảnh hợp lệ (hoặc định dạng không hỗ trợ)")

        val targetW = settings.width
        val targetH = settings.height
        val targetRatio = targetW.toFloat() / targetH.toFloat()
        val srcRatio = srcBitmap.width.toFloat() / srcBitmap.height.toFloat()
        // Crop-center về đúng tỷ lệ khung TRƯỚC khi resize — tránh méo hình.
        val cropped = if (kotlin.math.abs(srcRatio - targetRatio) < 0.001f) {
            srcBitmap
        } else if (srcRatio > targetRatio) {
            // Ảnh gốc RỘNG hơn tỷ lệ đích -> cắt bớt 2 bên.
            val cropW = (srcBitmap.height * targetRatio).toInt().coerceAtMost(srcBitmap.width)
            val x = (srcBitmap.width - cropW) / 2
            Bitmap.createBitmap(srcBitmap, x, 0, cropW, srcBitmap.height)
        } else {
            // Ảnh gốc CAO hơn tỷ lệ đích -> cắt bớt trên/dưới.
            val cropH = (srcBitmap.width / targetRatio).toInt().coerceAtMost(srcBitmap.height)
            val y = (srcBitmap.height - cropH) / 2
            Bitmap.createBitmap(srcBitmap, 0, y, srcBitmap.width, cropH)
        }
        val resized = Bitmap.createScaledBitmap(cropped, targetW, targetH, true)

        val outFile = File(outDir, "panel_%03d_raw.png".format(panel.index))
        java.io.FileOutputStream(outFile).use { resized.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (cropped !== srcBitmap) cropped.recycle()
        if (resized !== cropped) resized.recycle()
        srcBitmap.recycle()

        panel.copy(
            imagePath = outFile.absolutePath,
            upscaledPath = null,        // ảnh import chưa qua upscale — user vẫn có thể bấm upscale bình thường ở bước sau
            status = PanelStatus.DONE,
            resolvedBackend = null,     // null = "ảnh nhập tay", không phải LOCAL/REMOTE nào — xem UI GalleryReviewScreen
            routingReason = "Ảnh nhập tay (import ngoài)",
            qualityGatePassed = true,
            qualityGateReasons = emptyList(),
            autoFixApplied = false,
            generationTimeMs = 0
        )
    }

    suspend fun regeneratePanel(
        panel: Panel,
        story: Story,
        settings: GenerationSettings,
        outDir: File,
        // mục 161 TECHNICAL_STATUS.md — null = hành vi cũ 100% (không có
        // caller nào BẮT BUỘC phải sửa). Có giá trị -> getCharacterAnchor()
        // chọn đúng CharacterAnchorVersion theo chương khi regenerate.
        chapterNumber: Int? = null
    ): Panel = withContext(Dispatchers.IO) {
        // mục 83 TECHNICAL_STATUS.md — TODO tự ghi nhận đã vá: track Job
        // thật để `cancelSafely()` đợi được hàm này dừng hẳn trước khi free
        // native pointer, cùng lý do/cơ chế đã áp dụng cho `runGeneration()`
        // — xem docstring đầy đủ ở `cancelSafely()`.
        // mục 142 TECHNICAL_STATUS.md — reset cờ ngắt native SẠCH mỗi
        // lần bắt đầu 1 lượt generate MỚI (Pipeline::generate() cũng tự
        // reset ở đầu hàm — đây là lớp phòng thủ thứ 2, phòng lượt trước
        // bị ngắt mà vì lý do gì đó cờ chưa kịp reset).
        try { NativeBridge.clearInterruptNative() } catch (_: Throwable) {}
        // mục 248 — Differential Diffusion cho img2img CÓ MASK (vùng chạm/mặt/tay); cờ toàn cục native, đặt lại mỗi lượt
        try { NativeBridge.setDifferentialDiffusion(settings.differentialInpaint) } catch (_: Throwable) {}
        currentJob = coroutineContext[Job]
        try {
        val eff = resolveEffective(panel, settings)
        val modelId = if (panel.overrideSettings?.characterOverride != null)
            resolveModelIdForCharacter(story, eff.characterName, settings.sdModelId)
        else
            resolveModelIdForScene(story, panel.scene.characters, settings.sdModelId)
        val embeddingsDir = storyManager.embeddingsDir(story.id).absolutePath
        imagePipeline.loadSD(storyManager.modelsDir.absolutePath, modelId, settings.useOpenCL, embeddingsDir, settings.useNpu, runtimeOptimizer.detectQnnSoc()?.socModel ?: "")

        val characterReferenceImage = eff.characterName?.let { storyManager.getCharacterAnchor(story.id, it, preferTorn = SeedRegistry.resolveActionCategory(panel.scene) == "combat", chapterNumber = chapterNumber, expressionKey = expressionKeyFor(panel, it)) }
        // mục 217 TECHNICAL_STATUS.md — mirror ĐÚNG nhánh 0-nhân-vật đã
        // thêm ở generatePanels() (nguyên tắc mục 67/69 ngay trên: "vẽ lại
        // từng tấm" không được lệch hành vi so với sinh hàng loạt). Xem
        // giải thích đầy đủ (GIỚI HẠN THẬT vì sao CHỈ áp dụng panel 0-nhân-
        // vật) ở generatePanels(), không lặp lại ở đây.
        val locationReferenceImage = if (characterReferenceImage == null && panel.scene.characters.isEmpty())
            panel.scene.locationName?.let { storyManager.getLocationAnchor(story.id, it) }
        else null
        val usingLocationAnchor = locationReferenceImage != null
        val referenceImage = characterReferenceImage ?: locationReferenceImage
        val allChars = applyActiveAnchorVersion(storyManager.loadStory(story.id)?.characters ?: story.characters, chapterNumber)
        val effPrompt = injectHeadsTallTag(injectEmbeddingTriggers(eff.prompt, panel, allChars, eff.characterName), eff.characterName, allChars)

        // mục 67 TECHNICAL_STATUS.md — cùng nhánh IP-Adapter mask N-nhân-vật
        // đã nối vào generatePanels() ở trên, áp dụng luôn cho "vẽ lại từng
        // tấm" (nếu không, regenerate 1 panel N-nhân-vật sẽ quay lại hành vi
        // cũ chỉ neo 1 người, KHÁC hành vi lúc sinh hàng loạt — tự lệch pha
        // trong chính app, không phải chỉ lệch tài liệu/code).
        // mục 118 — sort ổn định, xem giải thích đầy đủ ở nhánh runGeneration().
        val sceneChars = stableCharacterOrder(panel.scene.characters, allChars)
        val noCharacterOverride = panel.overrideSettings?.characterOverride == null
        val noPairModel = pairModelIdForSceneOrNull(story, sceneChars) == null
        val multiCharAnchors: List<String>? = if (settings.useStoryDiffusion && noCharacterOverride &&
                sceneChars.size >= 2 && noPairModel) {
            val anchors = sceneChars.map { storyManager.getCharacterAnchor(story.id, it, preferTorn = SeedRegistry.resolveActionCategory(panel.scene) == "combat", chapterNumber = chapterNumber, expressionKey = expressionKeyFor(panel, it)) }
            if (anchors.all { it != null } && storyManager.hasMultiCharMaskUnet(modelId, sceneChars.size))
                anchors.filterNotNull() else null
        } else null
        // mục 217 (đợt 2) TECHNICAL_STATUS.md — mirror ĐÚNG generatePanels()
        // ở trên (nguyên tắc mục 67/69: không lệch hành vi giữa sinh hàng
        // loạt và "vẽ lại từng tấm").
        val locationAnchorForMc = panel.scene.locationName?.let { storyManager.getLocationAnchor(story.id, it) }
        val useMcLocationSlot = multiCharAnchors != null && locationAnchorForMc != null &&
            storyManager.hasMultiCharMaskUnetWithLocation(modelId, sceneChars.size)
        // mục 69 TECHNICAL_STATUS.md — tầng dự phòng thứ 3, đồng bộ với
        // generatePanels() ở trên (lý do đồng bộ: xem comment mục 67 ngay
        // trên — regenerate 1 panel không được lệch hành vi so với sinh
        // hàng loạt).
        // mục 172 TECHNICAL_STATUS.md — đồng bộ với generatePanels() ở
        // trên (đúng nguyên tắc mục 67/69). Xem giải thích đầy đủ ở đó,
        // không lặp lại.
        val useRegionalMask = multiCharAnchors == null && settings.useStoryDiffusion && noCharacterOverride &&
            sceneChars.size >= 2 && noPairModel && storyManager.hasRegionalMaskUnet(modelId, sceneChars.size)

        val useRegional = multiCharAnchors == null && settings.useStoryDiffusion && noCharacterOverride &&
            sceneChars.size >= 2 && noPairModel && storyManager.hasRegionalUnet(modelId, sceneChars.size) &&
            !useRegionalMask

        // mục 107 TECHNICAL_STATUS.md — resolveConditioning(), đồng bộ với
        // generatePanels() (đúng nguyên tắc mục 67/69: regenerate 1 panel
        // không được lệch hành vi so với sinh hàng loạt).
        val condRg = resolveConditioning(panel.scene, settings, panel.overrideSettings)

        // mục 152 TECHNICAL_STATUS.md — Triple-Conditioning combo, đồng bộ
        // với generatePanels() ở trên (đúng nguyên tắc mục 67/69: regenerate
        // 1 panel không được lệch hành vi so với sinh hàng loạt). Xem giải
        // thích đầy đủ ở đó, không lặp lại.
        val regionOrderTc2 = resolveRegionalOrder(sceneChars, panel.overrideSettings?.regionalColumnOrder)
        val tripleComboAnchors: List<String>? = if (settings.useStoryDiffusion && noCharacterOverride &&
                sceneChars.size >= 2 && noPairModel && storyManager.hasTripleComboUnet(modelId, sceneChars.size)) {
            val anchors = regionOrderTc2.map { storyManager.getCharacterAnchor(story.id, it, preferTorn = SeedRegistry.resolveActionCategory(panel.scene) == "combat", chapterNumber = chapterNumber, expressionKey = expressionKeyFor(panel, it)) }
            if (anchors.all { it != null }) anchors.filterNotNull() else null
        } else null
        // mục 219 TECHNICAL_STATUS.md — mirror ĐÚNG generatePanels() ở
        // trên (nguyên tắc mục 67/69: không lệch hành vi sinh hàng loạt
        // vs "vẽ lại từng tấm").
        val locationAnchorForTc = panel.scene.locationName?.let { storyManager.getLocationAnchor(story.id, it) }
        val useTcLocationSlot = tripleComboAnchors != null && locationAnchorForTc != null &&
            storyManager.hasTripleComboUnetWithLocation(modelId, sceneChars.size)

        // mục 184 TECHNICAL_STATUS.md — SDXL Phase 3, đồng bộ với
        // generatePanels() ở trên (đúng nguyên tắc mục 67/69: regenerate 1
        // panel không được lệch hành vi so với sinh hàng loạt). Xem giải
        // thích đầy đủ ở đó + docstring dispatchSdxlPanel(), không lặp lại.
        val sdxlPathRg = if (eff.modelTier == ImageModelTier.SDXL)
            dispatchSdxlPanel(panel, story, settings, eff, sceneChars, allChars, chapterNumber, outDir) { _, _ -> }
        else null

        val rawPath = if (sdxlPathRg != null) {
            // mục 253 TECHNICAL_STATUS.md — khai báo kiểu String TƯỜNG MINH. `sdxlPathRg` là String?
            // (dispatchSdxlPanel trả String?); không ghi kiểu thì pathSdxlFix suy ra String? và sau
            // khối try/catch bên dưới smart-cast bị mất => `rawPath` thành String? => lỗi build #127
            // (MangaPipeline.kt:4456 "inferred type is String? but String was expected").
            // Ở đây sdxlPathRg đã được smart-cast String bởi `if (sdxlPathRg != null)` (val cục bộ, ổn định).
            var pathSdxlFix: String = sdxlPathRg
            // mục 207 TECHNICAL_STATUS.md — mirror ĐÚNG khối vừa thêm ở
            // generatePanels() (cùng lượt) — đóng gap "SDXL chưa có auto-fix
            // giao thoa riêng" bằng img2imgFixSdxl() mới. KHÁC Multi-Pass
            // Cascade/runMultiPassCascade (CÁI ĐÓ vẫn chưa làm cho SDXL).
            if (settings.autoFixInteractions && sceneChars.size >= 2 &&
                storyManager.hasSdxlBaseUnet(settings.sdxlModelId!!)) {
                try {
                    val sdxlModelDirFix = storyManager.modelsDir.absolutePath + "/" + settings.sdxlModelId
                    val embeddingsDirFix = storyManager.embeddingsDir(story.id).absolutePath
                    imagePipeline.loadSDSdxl(sdxlModelDirFix, embeddingsDirFix, settings.useOpenCL, settings.useNpu)
                    val effPromptSdxl = injectHeadsTallTag(injectEmbeddingTriggers(eff.prompt, panel, allChars, eff.characterName), eff.characterName, allChars)
                    val skDataFixSdxl = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapterNumber)
                    pathSdxlFix = tryAutoFixInteractions(
                        pathSdxlFix, eff.width, eff.height, effPromptSdxl, eff.negativePrompt,
                        settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                        panel.index, outDir, skDataFixSdxl, sceneChars.size,
                        characterOrder = panel.scene.characters, allChars = allChars,
                        settings = settings, worldRules = story.worldRules, useSdxlFix = true
                    )
                } catch (ex: Exception) {
                    log("  ⚠ Auto-fix giao thoa SDXL lỗi (${ex.message}) — giữ ảnh gốc")
                }
            }
            pathSdxlFix
        } else if (tripleComboAnchors != null) {
            imagePipeline.loadSDTripleCombo(
                storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir,
                sceneChars.size, settings.useOpenCL, settings.useNpu,
                withLocationSlot = useTcLocationSlot)
            val regionPromptsTc2 = buildRegionPrompts(
                regionOrderTc2, panel.overrideSettings?.regionalPromptOverrides ?: emptyMap(),
                allChars, eff, settings.imageStyle.stylePrompt
            )
            val baseTc2 = imagePipeline.generatePanelTripleCombo(
                panelIndex = panel.index, regionPrompts = regionPromptsTc2, negativePrompt = eff.negativePrompt,
                referenceImagePaths = tripleComboAnchors,
                skeletonData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderTc2, chapterNumber = chapterNumber),
                width = eff.width, height = eff.height,
                steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed, outDir = outDir,
                onProgress = { _, _ -> },
                poseScale = condRg.poseConditioningScale, depthScale = condRg.depthConditioningScale,
                ipDecayFloor = condRg.ipDecayFloor, ipDecayStartTimestep = condRg.ipDecayStartTimestep,
                // mục 219 — mirror ĐÚNG generatePanels().
                locationAnchorPath = if (useTcLocationSlot) locationAnchorForTc else null,
                locationScale = settings.locationAnchorStrength
            )
            // mục 199 TECHNICAL_STATUS.md — CÙNG LOẠI BUG đã vá ở mục 198
            // (Multi-Pass Cascade), lần này cho `tryAutoFixInteractions()`:
            // regeneratePanel() CHƯA TỪNG gọi hàm này ở BẤT KỲ nhánh nào
            // (tripleCombo/multiChar/regionalMask/regional) — nghĩa là bật
            // `autoFixInteractions` ở Cài đặt hoàn toàn KHÔNG có tác dụng
            // khi dùng qua "Vẽ lại", chỉ có tác dụng khi sinh hàng loạt qua
            // `generatePanels()`. Vá cho cả 4 nhánh (không chỉ tripleCombo ở
            // đây) — mirror ĐÚNG điều kiện + tham số từng call site tương
            // ứng trong generatePanels(), chỉ khác `chapterNumber`.
            if (settings.autoFixInteractions && sceneChars.size >= 2) {
                val skFinalTc2 = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderTc2, chapterNumber = chapterNumber)
                tryAutoFixInteractions(
                    baseTc2, eff.width, eff.height, regionPromptsTc2.joinToString(", "), eff.negativePrompt,
                    settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                    panel.index, outDir, skFinalTc2, sceneChars.size,
                    characterOrder = regionOrderTc2, allChars = allChars, settings = settings, worldRules = story.worldRules
                )
            } else baseTc2
        } else if (multiCharAnchors != null) {
            imagePipeline.loadSDAugmentedMultiChar(
                storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir,
                sceneChars.size, settings.useOpenCL, settings.useNpu,
                withLocationSlot = useMcLocationSlot)
            var baseMc2 = imagePipeline.generatePanelMultiChar(
                panelIndex = panel.index,
                prompt = effPrompt, negativePrompt = eff.negativePrompt,
                stylePrompt = settings.imageStyle.stylePrompt,
                width = eff.width, height = eff.height,
                steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                referenceImagePaths = multiCharAnchors,
                skeletonData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapterNumber),
                outDir = outDir,
                ipDecayFloor = condRg.ipDecayFloor, ipDecayStartTimestep = condRg.ipDecayStartTimestep,
                ipStaticScale = condRg.ipStaticScale,
                // mục 217 (đợt 2) — mirror ĐÚNG generatePanels().
                locationAnchorPath = if (useMcLocationSlot) locationAnchorForMc else null,
                locationScale = settings.locationAnchorStrength,
                onProgress = { _, _ -> }
            )
            // mục 199 TECHNICAL_STATUS.md — cùng loại bug đã vá ở tripleCombo
            // trên/mục 198 (Cascade) — thêm tryAutoFixInteractions() TRƯỚC
            // Multi-Pass Cascade, ĐÚNG thứ tự generatePanels() dùng (autoFix
            // chạy trước, cascade nhận ảnh ĐÃ autoFix làm nền — xem dòng
            // tương ứng trong generatePanels(), không đảo thứ tự).
            if (settings.autoFixInteractions && sceneChars.size >= 2) {
                val skFixMc2 = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapterNumber)
                baseMc2 = tryAutoFixInteractions(
                    baseMc2, eff.width, eff.height, effPrompt, eff.negativePrompt,
                    settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                    panel.index, outDir, skFixMc2, sceneChars.size,
                    characterOrder = sceneChars, allChars = allChars, settings = settings, worldRules = story.worldRules
                )
            }
            // mục 197 TECHNICAL_STATUS.md — BUG THẬT tự phát hiện NGAY SAU
            // khi vừa xây xong UI sửa tay biểu cảm riêng (cùng mục 197):
            // regeneratePanel() CHƯA TỪNG gọi runMultiPassCascade() ở nhánh
            // này — nghĩa là `characterExpressions` (LLM, mục 168) VÀ
            // `characterExpressionOverrides` (user, mục 197 — CHỈ dùng
            // được qua "Vẽ lại", tức HÀM NÀY) hoàn toàn KHÔNG có tác dụng
            // trước bản vá này, dù lưu đúng, dù UI hiện đúng. Khác hẳn
            // việc CỐ Ý bỏ Quality Gate retry ở regeneratePanel() (mục 172
            // — giữ đơn giản, không đổi ảnh CUỐI vì retry vốn không đổi
            // được gì, xem mục 185/187): thiếu cascade ở ĐÂY làm ảnh CUỐI
            // thật sự khác (không có bước cô lập-từng-người-đắp-biểu-cảm-
            // riêng nào chạy cả) — không phải tối ưu hiệu năng, là tính
            // năng vừa xây bị vô hiệu hoàn toàn. Mirror ĐÚNG điều kiện +
            // tham số của call site generatePanels() (chỉ khác `chapterNumber`
            // — tham số riêng của hàm này thay vì `chapter.chapterNumber`).
            if (settings.enableMultiPassCascade && sceneChars.size >= 2) {
                val skCascadeRg = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapterNumber)
                runMultiPassCascade(
                    baseMc2, sceneChars, multiCharAnchors, skCascadeRg,
                    eff.prompt, eff.negativePrompt, allChars, settings.imageStyle.stylePrompt,
                    eff.width, eff.height, eff.steps, eff.cfgScale,
                    eff.seed, settings.cascadeDenoiseStrength, panel.index, outDir,
                    characterExpressions = effectiveExpressionMap(panel),
                    promptStyle = resolvePromptStyle(settings),
                    depthOrder = panel.scene.depthScale.ifEmpty { inferDepthScaleFromCameraAngle(panel.scene) }
                )
            } else baseMc2
        } else if (useRegionalMask) {
            // mục 172 TECHNICAL_STATUS.md — đồng bộ với generatePanels() ở
            // trên (nhánh không-Quality-Gate, đúng độ phức tạp của
            // regeneratePanel() — hàm này vốn không có Quality Gate retry
            // loop cho bất kỳ nhánh nào khác, xem useRegional ngay dưới,
            // nên KHÔNG thêm riêng cho nhánh mới này).
            imagePipeline.loadSDRegionalMask(
                storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir,
                sceneChars.size, settings.useOpenCL, settings.useNpu)
            val regionPromptsRm2 = buildRegionPrompts(
                sceneChars, panel.overrideSettings?.regionalPromptOverrides ?: emptyMap(),
                allChars, eff, settings.imageStyle.stylePrompt
            )
            val backgroundPromptRm2 = "${eff.prompt}, ${settings.imageStyle.stylePrompt}"
            val skDataRm2 = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapterNumber)
            val regionMasksRm2 = buildRegionMasksForPanel(sceneChars, skDataRm2, eff.width, eff.height, panel.index, outDir)
            val baseRm2 = imagePipeline.generatePanelRegionalMask(
                panelIndex = panel.index, regionPrompts = regionPromptsRm2, backgroundPrompt = backgroundPromptRm2,
                negativePrompt = eff.negativePrompt, regionMasks = regionMasksRm2, skeletonData = skDataRm2,
                width = eff.width, height = eff.height, steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                outDir = outDir
            ) { _, _ -> }
            // mục 199 TECHNICAL_STATUS.md — cùng loại bug đã vá ở tripleCombo/
            // multiChar trên — xem giải thích đầy đủ ở đó, không lặp lại.
            if (settings.autoFixInteractions && sceneChars.size >= 2) {
                val skFinalRm2 = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, sceneChars, chapterNumber = chapterNumber)
                tryAutoFixInteractions(
                    baseRm2, eff.width, eff.height, regionPromptsRm2.joinToString(", "), eff.negativePrompt,
                    settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                    panel.index, outDir, skFinalRm2, sceneChars.size,
                    characterOrder = sceneChars, allChars = allChars, settings = settings, worldRules = story.worldRules
                )
            } else baseRm2
        } else if (useRegional) {
            imagePipeline.loadSDRegional(
                storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir,
                sceneChars.size, settings.useOpenCL, settings.useNpu)
            val regionOrderRg2 = resolveRegionalOrder(sceneChars, panel.overrideSettings?.regionalColumnOrder)
            val regionPrompts = buildRegionPrompts(
                regionOrderRg2, panel.overrideSettings?.regionalPromptOverrides ?: emptyMap(),
                allChars, eff, settings.imageStyle.stylePrompt
            )
            val baseRg2 = imagePipeline.generatePanelRegional(
                panelIndex = panel.index,
                regionPrompts = regionPrompts, negativePrompt = eff.negativePrompt,
                skeletonData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderRg2, chapterNumber = chapterNumber),
                width = eff.width, height = eff.height,
                steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                outDir = outDir
            ) { _, _ -> }
            // mục 199 TECHNICAL_STATUS.md — cùng loại bug đã vá ở 3 nhánh
            // trên — xem giải thích đầy đủ ở tripleCombo, không lặp lại.
            if (settings.autoFixInteractions && sceneChars.size >= 2) {
                val skFinalRg2 = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, regionOrderRg2, chapterNumber = chapterNumber)
                tryAutoFixInteractions(
                    baseRg2, eff.width, eff.height, regionPrompts.joinToString(", "), eff.negativePrompt,
                    settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                    panel.index, outDir, skFinalRg2, sceneChars.size,
                    characterOrder = regionOrderRg2, allChars = allChars, settings = settings, worldRules = story.worldRules
                )
            } else baseRg2
        // mục 226 TECHNICAL_STATUS.md — mirror ĐÚNG nhánh GLIGEN đã cập
        // nhật ở generatePanels() (nguyên tắc mục 67/69: không lệch hành
        // vi giữa sinh hàng loạt và "vẽ lại từng tấm"). Xem giải thích đầy
        // đủ (ghép IP-Adapter 1-nhân-vật, ưu tiên so với ảnh neo bối cảnh)
        // ở đó, không lặp lại ở đây.
        } else if (run {
                if (!settings.useStoryDiffusion) return@run false
                if (resolveObjectBoxes(panel.scene, panel.overrideSettings?.objectBoxOverride).isEmpty()) return@run false
                if (panel.scene.characters.size > 1) return@run false
                val charName = panel.scene.characters.firstOrNull()
                if (charName == null) return@run storyManager.hasGligenUnet(modelId)
                storyManager.getCharacterAnchor(story.id, charName, chapterNumber = chapterNumber, expressionKey = expressionKeyFor(panel, charName)) != null &&
                    storyManager.hasGligenUnetWithCharacter(modelId)
            }) {
            val resolvedBoxes2 = resolveObjectBoxes(panel.scene, panel.overrideSettings?.objectBoxOverride)
            val gligenCharName2 = panel.scene.characters.firstOrNull()
            val gligenCharAnchor2 = gligenCharName2?.let { storyManager.getCharacterAnchor(story.id, it, chapterNumber = chapterNumber, expressionKey = expressionKeyFor(panel, it)) }
            imagePipeline.loadSDGligen(storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir,
                settings.useOpenCL, settings.useNpu, withCharacterSlot = gligenCharAnchor2 != null)
            imagePipeline.generatePanelGligen(
                panelIndex = panel.index,
                prompt = eff.prompt, negativePrompt = eff.negativePrompt,
                stylePrompt = settings.imageStyle.stylePrompt,
                objectBoxes = resolvedBoxes2,
                width = eff.width, height = eff.height,
                steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
                outDir = outDir,
                onProgress = { _, _ -> },
                referenceImagePath = gligenCharAnchor2
            )
        } else {
        if (settings.useStoryDiffusion && referenceImage != null) {
            imagePipeline.loadSDAugmented(storyManager.modelsDir.absolutePath + "/" + modelId, embeddingsDir, settings.useOpenCL, settings.useNpu)
        }

        val baseSingle2 = imagePipeline.generatePanel(
            panelIndex = panel.index,
            prompt = effPrompt, negativePrompt = eff.negativePrompt,
            stylePrompt = settings.imageStyle.stylePrompt,
            width = eff.width, height = eff.height,
            steps = eff.steps, cfgScale = eff.cfgScale, seed = eff.seed,
            referenceImagePath = referenceImage,
            skeletonData = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapterNumber),
            useStoryDiffusion = settings.useStoryDiffusion, outDir = outDir,
            onProgress = { _, _ -> },
            poseConditioningScale = condRg.poseConditioningScale,
            depthConditioningScale = condRg.depthConditioningScale,
            depthActiveMinTimestep = condRg.depthActiveMinTimestep,
            ipDecayFloor = condRg.ipDecayFloor,
            ipDecayStartTimestep = condRg.ipDecayStartTimestep,
            // mục 217 TECHNICAL_STATUS.md — mirror ĐÚNG generatePanels():
            // dùng settings.locationAnchorStrength (0.5 mặc định) thay vì
            // condRg.ipStaticScale (hiệu chỉnh cho NHÂN VẬT, 0.8) khi ảnh
            // tham chiếu là ảnh neo BỐI CẢNH, không phải nhân vật.
            ipStaticScale = if (usingLocationAnchor) settings.locationAnchorStrength else condRg.ipStaticScale
        )
        // mục 199 TECHNICAL_STATUS.md — cùng loại bug đã vá ở 3 nhánh trên —
        // xem giải thích đầy đủ ở tripleCombo, không lặp lại. `numPersons`
        // dùng `panel.scene.characters.size` (khớp đúng cách generatePanels()
        // tính cho nhánh này — KHÁC `sceneChars`/`regionOrder` các nhánh
        // kia, dùng list GỐC chưa qua stableCharacterOrder()).
        if (settings.autoFixInteractions && panel.scene.characters.size >= 2) {
            val skFinalSingle2 = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapterNumber)
            tryAutoFixInteractions(
                baseSingle2, eff.width, eff.height, effPrompt, eff.negativePrompt,
                settings.imageStyle.stylePrompt, eff.seed, settings.autoFixInteractionStrength,
                panel.index, outDir, skFinalSingle2, panel.scene.characters.size,
                characterOrder = panel.scene.characters, allChars = allChars, settings = settings, worldRules = story.worldRules
            )
        } else baseSingle2
        } // end single-character-anchor branch

        // mục 200 TECHNICAL_STATUS.md — user hỏi đúng trọng tâm: bỏ VÒNG
        // LẶP retry tự động ở regeneratePanel() (mục 185/187 — vô ích vì
        // khung xương không đổi theo seed) KHÔNG có nghĩa là bỏ luôn việc
        // BÁO CÁO trạng thái Quality Gate cho panel — 2 việc khác nhau.
        // TRƯỚC bản vá này, `qualityGatePassed`/`qualityGateReasons` của
        // panel giữ NGUYÊN giá trị CŨ (từ lần sinh trước) sau khi "Vẽ lại"
        // — sai nếu user vừa đổi `poseTemplateOverride`/`poseAngleOverride`
        // lúc regenerate (khung xương MỚI có thể đạt/không đạt khác hẳn
        // khung xương CŨ, nhưng badge ở GalleryReviewScreen — mục 185 —
        // vẫn hiện cảnh báo/trạng thái của khung xương CŨ, đã lỗi thời).
        // Tính lại 1 LẦN (không lặp, đúng tinh thần mục 187) bằng khung
        // xương THẬT của lần regenerate này, cập nhật lại badge cho đúng.
        // mục 205 TECHNICAL_STATUS.md — BỎ điều kiện loại trừ SDXL đã có ở
        // đây (`&& eff.modelTier != ImageModelTier.SDXL`, viết lúc mục 200
        // vì lúc đó `dispatchSdxlPanel()` CHƯA hề đánh giá Quality Gate ở
        // bất kỳ đâu — mục 184). Nay mục 205 đã đóng đúng gap đó ở
        // `generatePanels()`, và khối tính bên dưới ĐÃ SẴN tier-agnostic
        // (`resolveSkeletonData()`/`qualityGate.evaluate()` không đọc
        // model nào) — loại trừ SDXL ở đây giờ chỉ còn là lệch pha thừa,
        // không phải giới hạn kỹ thuật thật.
        val (finalPassed, finalReasons) = if (settings.enableQualityGate) {
            val skBadge = resolveSkeletonData(eff.poseTemplate, eff.poseAngle, panel.scene, story, chapterNumber = chapterNumber)
            val reportBadge = qualityGate.evaluate(skBadge, panel.scene.characters.size.coerceAtLeast(1))
            reportBadge.passed to reportBadge.reasons
        } else panel.qualityGatePassed to panel.qualityGateReasons
        // mục 229 — mirror generatePanels(): SDXL hậu kỳ cho vùng tiếp xúc.
        val rawPathSdxl = trySdxlFinishPass(rawPath, panel, story, settings, eff, allChars, chapterNumber, outDir)
        val rawPathFinished = tryExpressionFacePass(rawPathSdxl, panel, story, settings, eff, allChars, chapterNumber, outDir)
        val outVerifyRegen = verifyOutputPose(rawPathFinished, panel, story, settings, eff, chapterNumber)
        panel.copy(imagePath = rawPathFinished, status = PanelStatus.DONE, upscaledPath = null,
            qualityGatePassed = finalPassed && (outVerifyRegen?.passed ?: true),
            qualityGateReasons = finalReasons + (outVerifyRegen?.reasons ?: emptyList()))
        } finally {
            currentJob = null
        }
    }

    // ── Giai đoạn 2: Upscale (sau khi user đã duyệt hết panel) ─────────────
    suspend fun upscaleApprovedPanels(
        chapter: Chapter,
        settings: GenerationSettings,
        outDir: File
    ): Chapter = coroutineScope {
        // mục 83 TECHNICAL_STATUS.md — cùng lý do/cơ chế đã áp dụng cho
        // `runGeneration()`/`regeneratePanel()` — xem docstring đầy đủ ở
        // `cancelSafely()`. Hàm này cũng gọi native (`esrganUpscale`,
        // `sdImg2Img` qua auto-fix/Ultrafix) nên có CÙNG rủi ro use-after-
        // free nếu bị huỷ giữa chừng.
        // mục 142 TECHNICAL_STATUS.md — reset cờ ngắt native SẠCH mỗi
        // lần bắt đầu 1 lượt generate MỚI (Pipeline::generate() cũng tự
        // reset ở đầu hàm — đây là lớp phòng thủ thứ 2, phòng lượt trước
        // bị ngắt mà vì lý do gì đó cờ chưa kịp reset).
        try { NativeBridge.clearInterruptNative() } catch (_: Throwable) {}
        // mục 248 — Differential Diffusion cho img2img CÓ MASK (vùng chạm/mặt/tay); cờ toàn cục native, đặt lại mỗi lượt
        try { NativeBridge.setDifferentialDiffusion(settings.differentialInpaint) } catch (_: Throwable) {}
        currentJob = coroutineContext[Job]
        try {
        emit(PipelineStage.UPSCALING, "Upscale ${chapter.panels.size} panel đã duyệt...")
        thermalMonitor.start(settings.thermalThreshold, settings.thermalResumeOffset)

        if (settings.upscaleOption != UpscaleOption.NONE) {
            imagePipeline.loadEsrgan(settings.upscaleOption.factor)
        }

        val worldRules = storyManager.loadStory(chapter.storyId)?.worldRules ?: ""
        val promptGuideNotes = storyManager.loadStory(chapter.storyId)?.promptGuideNotes ?: ""

        // mục 133 TECHNICAL_STATUS.md — Industrial Batch Upscale Mode. Xem
        // ghi chú đầy đủ ở `GenerationSettings.industrialBatchUpscaleMode`.
        // Nhánh cũ (industrialBatchUpscaleMode=false, MẶC ĐỊNH) GIỮ NGUYÊN
        // 100% hành vi trước đây (xen kẽ ESRGAN→Ultrafix→auto-fix TỪNG
        // panel, 1 vòng lặp duy nhất) — không đổi gì cho người dùng chưa
        // bật cờ mới.
        val updated = if (settings.industrialBatchUpscaleMode) {
            upscaleApprovedPanelsIndustrialBatch(chapter, settings, outDir, worldRules, promptGuideNotes)
        } else {
            upscaleApprovedPanelsInterleaved(chapter, settings, outDir, worldRules, promptGuideNotes)
        }

        imagePipeline.freeEsrganOnly()
        thermalMonitor.stop()
        chapter.copy(panels = updated, status = ChapterStatus.DONE)
        } finally {
            currentJob = null
        }
    }

    // Hành vi CŨ — xen kẽ ESRGAN→Ultrafix→auto-fix mặt/tay TỪNG panel 1,
    // trong 1 vòng lặp duy nhất (đúng nguyên văn code trước mục 133, chỉ
    // tách ra thành hàm riêng để dùng chung với nhánh mới). Thứ tự CHẤT
    // LƯỢNG bên trong mỗi panel giữ nguyên theo mục 20 (ESRGAN trước, vẽ
    // lại chi tiết sau, ở độ phân giải CUỐI).
    private suspend fun upscaleApprovedPanelsInterleaved(
        chapter: Chapter, settings: GenerationSettings, outDir: File,
        worldRules: String, promptGuideNotes: String
    ): List<Panel> {
        // LLM dịch prompt riêng theo giai đoạn (mục 24 TECHNICAL_STATUS.md)
        // — CHỈ init nếu thật sự cần (1 trong 2 tính năng dùng img2img đang
        // bật), tránh tốn thời gian/RAM tải LLM khi không cần. Instance
        // RIÊNG cho hàm này (không dùng chung `llmParser` ở generatePanels()
        // — cái đó đã free() xong trước khi tới bước này).
        val needsStageLLM = settings.useUltrafixRedraw || settings.autoFixFacesHands
        var stageParser: LLMParser? = null
        if (needsStageLLM && settings.llmModelPath.isNotBlank()) {
            try {
                stageParser = LLMParser(settings.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
                stageParser.init()
            } catch (ex: Exception) {
                log("⚠ Không khởi động được LLM dịch prompt theo giai đoạn (${ex.message}) — dùng lại prompt gốc")
                stageParser = null
            }
        }

        val updated = chapter.panels.map { panel ->
            waitForThermalSafe(settings)
            val path = panel.imagePath ?: return@map panel
            val hdEsrgan = imagePipeline.upscale(path, panel.index, outDir, settings.upscaleOption)
            val (hd, fixApplied) = applyUltrafixAndAutoFix(panel, hdEsrgan, stageParser, settings, worldRules, outDir)
            log("✓ Panel ${panel.index + 1} upscale xong" + (if (fixApplied) " [đã auto-fix — nên kiểm tra kỹ ở Gallery cuối]" else ""))
            panel.copy(upscaledPath = hd, autoFixApplied = fixApplied)
        }
        stageParser?.free()
        return updated
    }

    // MỚI (mục 133, mở rộng theo đúng yêu cầu user: "toàn bộ ảnh đi qua
    // từng model, không phải 1 ảnh đi qua hết toàn bộ model") — 4 GIAI
    // ĐOẠN tách biệt thật sự, MỖI giai đoạn xử lý TẤT CẢ panel bằng ĐÚNG 1
    // loại model trước khi chuyển giai đoạn kế tiếp:
    //   Giai đoạn 1: ESRGAN cho TẤT CẢ panel → giải phóng ESRGAN.
    //   Giai đoạn 2: Ultrafix (SD, không cần mask) cho TẤT CẢ panel.
    //   Giai đoạn 3: Dò vùng mặt/tay + build mask (faceHandDetector +
    //   MobileSAM qua `maskFixer`, KHÔNG đụng SD) cho TẤT CẢ panel → giải
    //   phóng MobileSAM.
    //   Giai đoạn 4: SD inpaint dùng mask đã build ở giai đoạn 3, cho TẤT
    //   CẢ panel.
    // Trước mục này, cặp MobileSAM+SD ở bước auto-fix mặt/tay từng bị coi
    // là "không tách được sạch" (mục 132/hội thoại trước) vì lý luận
    // "MobileSAM tạo mask rồi SD dùng NGAY mask đó" — hoá ra đó là ràng
    // buộc của CÁCH VIẾT VÒNG LẶP (per-panel) cũ, không phải ràng buộc kỹ
    // thuật thật: mask vốn ĐÃ LÀ 1 file PNG trên đĩa
    // (`panel_%03d_mask.png`) — không có gì ngăn việc build HẾT mask cho
    // mọi panel trước, rồi mới lượt SD đọc lại các file đó sau. Xem
    // `buildAutoFixMaskOrNull()`/`applyAutoFixInpaint()` (tách từ
    // `tryAutoFixFacesHands()` gốc) cho phần triển khai.
    // Thứ tự CHẤT LƯỢNG cho TỪNG panel (ESRGAN → Ultrafix → auto-fix mặt/
    // tay, mục 20) được GIỮ NGUYÊN — chỉ đổi trình tự VÒNG LẶP NGOÀI (theo
    // giai đoạn/model thay vì theo panel), ảnh ra giống hệt nhánh cũ khi
    // không có panel nào lỗi giữa chừng.
    private suspend fun upscaleApprovedPanelsIndustrialBatch(
        chapter: Chapter, settings: GenerationSettings, outDir: File,
        worldRules: String, promptGuideNotes: String
    ): List<Panel> {
        data class StageResult(val panel: Panel, val hd: String?, val fixApplied: Boolean = false)

        // ── Giai đoạn 1/4: ESRGAN cho tất cả panel ─────────────────────
        _state.update { it.copy(phaseLabel = "Giai đoạn 1/4 · Phóng to (ESRGAN)", currentPanel = 0) }
        log("── Industrial Batch: giai đoạn 1/4 — ESRGAN cho ${chapter.panels.size} panel ──")
        var results: List<StageResult> = chapter.panels.mapIndexed { i, panel ->
            waitForThermalSafe(settings)
            _state.update { it.copy(currentPanel = i + 1) }
            val path = panel.imagePath
            if (path == null) {
                log("  ⚠ Panel ${panel.index + 1}: thiếu imagePath, bỏ qua toàn bộ 4 giai đoạn")
                StageResult(panel, null)
            } else {
                val hd = try {
                    imagePipeline.upscale(path, panel.index, outDir, settings.upscaleOption)
                } catch (ex: Exception) {
                    log("  ⚠ Panel ${panel.index + 1}: ESRGAN lỗi (${ex.message}) — bỏ qua các giai đoạn sau cho panel này")
                    null
                }
                StageResult(panel, hd)
            }
        }
        // Giải phóng ESRGAN NGAY sau khi TẤT CẢ panel đã qua xong bước
        // phóng to — lợi ích RAM của giai đoạn này (xem ghi chú ở
        // GenerationSettings.industrialBatchUpscaleMode).
        imagePipeline.freeEsrganOnly()

        // LLM dịch prompt riêng theo giai đoạn (mục 24) — dùng chung cho cả
        // giai đoạn 2 và 4, init 1 LẦN ở đây (không cần resident ở giai
        // đoạn 1/3 vì 2 giai đoạn đó không dịch prompt).
        val needsStageLLM = settings.useUltrafixRedraw || settings.autoFixFacesHands
        var stageParser: LLMParser? = null
        if (needsStageLLM && settings.llmModelPath.isNotBlank()) {
            try {
                stageParser = LLMParser(settings.llmModelPath, effectiveNThreads(settings), optimalConfig.nGpuLayers, settings.externalLlm)
                stageParser.init()
            } catch (ex: Exception) {
                log("⚠ Không khởi động được LLM dịch prompt theo giai đoạn (${ex.message}) — dùng lại prompt gốc")
                stageParser = null
            }
        }

        // ── Giai đoạn 2/4: Ultrafix (SD, không cần mask) cho tất cả panel ─
        if (settings.upscaleOption != UpscaleOption.NONE && settings.useUltrafixRedraw) {
            _state.update { it.copy(phaseLabel = "Giai đoạn 2/4 · Vẽ lại bề mặt (Ultrafix, SD)", currentPanel = 0) }
            log("── Industrial Batch: giai đoạn 2/4 — Ultrafix (SD) ──")
            results = results.mapIndexed { i, r ->
                waitForThermalSafe(settings)
                _state.update { it.copy(currentPanel = i + 1) }
                val hdIn = r.hd ?: return@mapIndexed r
                val naturalDesc = r.panel.overrideSettings?.naturalDescriptionOverride ?: r.panel.scene.description
                val (ufPrompt, ufNeg) = stageParser?.let {
                    try {
                        val res = it.translateStagePrompt(naturalDesc, PromptStage.UPSCALE_REDRAW, worldRules, settings.imageStyle.stylePrompt, promptStyle = resolvePromptStyle(settings))
                        res.positive to res.negative
                    } catch (ex: Exception) { r.panel.prompt to r.panel.negativePrompt }
                } ?: (r.panel.prompt to r.panel.negativePrompt)

                val ufPromptFinal = if (settings.enableHistogramGuard) {
                    try {
                        val hist = HistogramGuard.analyze(hdIn)
                        val tag = HistogramGuard.suggestCompensationTag(hist)
                        if (tag.isNotBlank()) {
                            log("  → Histogram Guard panel ${r.panel.index + 1}: ảnh ${if (hist!!.isDark) "tối" else "sáng"} (mean=${"%.0f".format(hist.meanLuminance)}), thêm tag bù trừ")
                            "$ufPrompt, $tag"
                        } else ufPrompt
                    } catch (ex: Exception) { ufPrompt }
                } else ufPrompt

                val hdOut = tryUltrafixRedraw(hdIn, r.panel.copy(prompt = ufPromptFinal, negativePrompt = ufNeg), settings, outDir)
                r.copy(hd = hdOut, fixApplied = r.fixApplied || hdOut != hdIn)
            }
        } else {
            log("── Industrial Batch: bỏ qua giai đoạn 2/4 — Ultrafix đang tắt ──")
        }

        // ── Giai đoạn 3/4: Dò vùng + build mask (faceHandDetector + MobileSAM), KHÔNG đụng SD ─
        data class MaskResult(val maskFile: File?)
        var maskResults: List<MaskResult> = List(results.size) { MaskResult(null) }
        if (settings.autoFixFacesHands) {
            _state.update { it.copy(phaseLabel = "Giai đoạn 3/4 · Dò vùng mặt/tay (MobileSAM)", currentPanel = 0) }
            log("── Industrial Batch: giai đoạn 3/4 — build mask (MobileSAM) ──")
            maskResults = results.mapIndexed { i, r ->
                waitForThermalSafe(settings)
                _state.update { it.copy(currentPanel = i + 1) }
                val hdIn = r.hd ?: return@mapIndexed MaskResult(null)
                MaskResult(buildAutoFixMaskOrNull(hdIn, r.panel.index, outDir))
            }
            // Giải phóng MobileSAM NGAY sau khi build mask xong cho TẤT CẢ
            // panel — lợi ích RAM của giai đoạn này. An toàn tái sử dụng
            // sau (chương kế tiếp, hoặc lần chạy khác trong CÙNG session)
            // nhờ đã sửa bug ManualMaskFixer.close() (mục 133 — xem
            // ManualMaskFixer.kt) tự tái khởi tạo khi cần lại thay vì kẹt
            // ở trạng thái "đã free, không hồi phục được" như trước.
            if (maskFixerLazy.isInitialized()) maskFixer.close()
        } else {
            log("── Industrial Batch: bỏ qua giai đoạn 3/4 — auto-fix mặt/tay đang tắt ──")
        }

        // ── Giai đoạn 4/4: SD inpaint dùng mask đã build ở giai đoạn 3 ──
        _state.update { it.copy(phaseLabel = "Giai đoạn 4/4 · Vẽ lại mặt/tay (SD inpaint)", currentPanel = 0) }
        if (settings.autoFixFacesHands) log("── Industrial Batch: giai đoạn 4/4 — SD inpaint ──")
        val updated = results.mapIndexed { i, r ->
            waitForThermalSafe(settings)
            _state.update { it.copy(currentPanel = i + 1) }
            var hdFinal = r.hd
            var fixApplied = r.fixApplied
            val maskFile = maskResults.getOrNull(i)?.maskFile
            if (settings.autoFixFacesHands && hdFinal != null && maskFile != null) {
                val fixedWidth = settings.width * settings.upscaleOption.factor
                val fixedHeight = settings.height * settings.upscaleOption.factor
                val naturalDesc = r.panel.overrideSettings?.naturalDescriptionOverride ?: r.panel.scene.description
                val (afPrompt, afNeg) = stageParser?.let {
                    try {
                        val res = it.translateStagePrompt(naturalDesc, PromptStage.INPAINT, worldRules, settings.imageStyle.stylePrompt, promptStyle = resolvePromptStyle(settings))
                        res.positive to res.negative
                    } catch (ex: Exception) { r.panel.prompt to r.panel.negativePrompt }
                } ?: (r.panel.prompt to r.panel.negativePrompt)
                val before = hdFinal
                hdFinal = applyAutoFixInpaint(
                    hdFinal, maskFile, fixedWidth, fixedHeight, afPrompt, afNeg,
                    settings.imageStyle.stylePrompt, r.panel.index.toLong() + 1000L,
                    settings.autoFixDenoiseStrength, r.panel.index, outDir
                )
                if (hdFinal != before) fixApplied = true
            }
            log("✓ Panel ${r.panel.index + 1} upscale xong" + (if (fixApplied) " [đã auto-fix — nên kiểm tra kỹ ở Gallery cuối]" else ""))
            if (hdFinal != null) r.panel.copy(upscaledPath = hdFinal, autoFixApplied = fixApplied) else r.panel
        }
        stageParser?.free()
        _state.update { it.copy(phaseLabel = null) }
        return updated
    }

    // Ultrafix (mục 16) + auto-fix mặt/tay (mục 17), rút ra dùng chung cho
    // cả 2 nhánh trên (mục 133) — nguyên văn logic cũ, KHÔNG đổi hành vi.
    private suspend fun applyUltrafixAndAutoFix(
        panel: Panel, hdIn: String, stageParser: LLMParser?,
        settings: GenerationSettings, worldRules: String, outDir: File
    ): Pair<String, Boolean> {
        var hd = hdIn
        var fixApplied = false

        // Mô tả tự nhiên nguồn cho dịch — ưu tiên override riêng panel
        // (PanelOverrideSettings.naturalDescriptionOverride), fallback về
        // mô tả scene tự động (Scene.description đã có từ parseStory()).
        val naturalDesc = panel.overrideSettings?.naturalDescriptionOverride ?: panel.scene.description

        if (settings.upscaleOption != UpscaleOption.NONE && settings.useUltrafixRedraw) {
            val beforeUltrafix = hd
            val (ufPrompt, ufNeg) = stageParser?.let {
                try {
                    val r = it.translateStagePrompt(naturalDesc, PromptStage.UPSCALE_REDRAW, worldRules, settings.imageStyle.stylePrompt, promptStyle = resolvePromptStyle(settings))
                    r.positive to r.negative
                } catch (ex: Exception) { panel.prompt to panel.negativePrompt }
            } ?: (panel.prompt to panel.negativePrompt)

            // mục 79/80 TECHNICAL_STATUS.md — Auto-Histogram Guard: đo độ
            // sáng ảnh RAW trước Ultrafix (thuần pixel-level, KHÔNG cần
            // model mới), chèn tag bù trừ NHẸ nếu quá tối/quá sáng. Bọc
            // try/catch riêng — lỗi đo histogram KHÔNG được làm gãy luồng
            // Ultrafix chính.
            val ufPromptFinal = if (settings.enableHistogramGuard) {
                try {
                    val hist = HistogramGuard.analyze(beforeUltrafix)
                    val tag = HistogramGuard.suggestCompensationTag(hist)
                    if (tag.isNotBlank()) {
                        log("  → Histogram Guard: ảnh ${if (hist!!.isDark) "tối" else "sáng"} (mean=${"%.0f".format(hist.meanLuminance)}), thêm tag bù trừ")
                        "$ufPrompt, $tag"
                    } else ufPrompt
                } catch (ex: Exception) { ufPrompt }
            } else ufPrompt

            hd = tryUltrafixRedraw(hd, panel.copy(prompt = ufPromptFinal, negativePrompt = ufNeg), settings, outDir)
            if (hd != beforeUltrafix) fixApplied = true
        }

        if (settings.autoFixFacesHands) {
            val fixedWidth = settings.width * settings.upscaleOption.factor
            val fixedHeight = settings.height * settings.upscaleOption.factor
            val beforeAutoFix = hd
            val (afPrompt, afNeg) = stageParser?.let {
                try {
                    val r = it.translateStagePrompt(naturalDesc, PromptStage.INPAINT, worldRules, settings.imageStyle.stylePrompt, promptStyle = resolvePromptStyle(settings))
                    r.positive to r.negative
                } catch (ex: Exception) { panel.prompt to panel.negativePrompt }
            } ?: (panel.prompt to panel.negativePrompt)
            hd = tryAutoFixFacesHands(
                hd, fixedWidth, fixedHeight, afPrompt, afNeg,
                settings.imageStyle.stylePrompt, panel.index.toLong() + 1000L,
                settings.autoFixDenoiseStrength, panel.index, outDir
            )
            if (hd != beforeAutoFix) fixApplied = true
        }

        return hd to fixApplied
    }

    // mục 235 TECHNICAL_STATUS.md — nhóm panel theo bối cảnh (Scene.locationName; thiếu thì
    // gom cả chương vào 1 nhóm), lấy kích thước thân người từ khung xương của chính panel
    // (khoảng cách trung điểm vai -> trung điểm hông, trung bình các người), rồi nhờ
    // ScaleConsistencyChecker so tỉ số chiều cao-hộp-vật-thể / thân-người giữa các panel.
    // Chỉ panel có Scene.objectBoxes (mục 223) mới tham gia. Chỉ GHI LOG, không đổi ảnh.
    private fun logObjectScaleWarnings(panels: List<Panel>, story: Story, chapterNumber: Int?) {
        val withBoxes = panels.filter { it.scene.objectBoxes.isNotEmpty() }
        if (withBoxes.size < 2) return
        val allChars = applyActiveAnchorVersion(story.characters, chapterNumber)
        val fpp = 18 * 4
        val entries = withBoxes.mapNotNull { panel ->
            val ov = panel.overrideSettings
            val template = ov?.poseTemplate ?: panel.suggestedPoseTemplate ?: guessPoseTemplate(panel)
            val angle = ov?.poseAngle ?: panel.suggestedPoseAngle
            val order = stableCharacterOrder(panel.scene.characters, allChars)
            val sk = resolveSkeletonData(template, angle, panel.scene, story, order, chapterNumber = chapterNumber)
            if (sk.isEmpty()) return@mapNotNull null
            val torsos = ArrayList<Float>()
            for (i in 0 until minOf(order.size, sk.size / fpp)) {
                val b = i * fpp
                // bố cục (x, y, z, visible): vai 2/5, hông 8/11
                fun vis(j: Int) = sk[b + j * 4 + 3] > 0.5f
                if (vis(2) && vis(5) && vis(8) && vis(11)) {
                    val shY = (sk[b + 2 * 4 + 1] + sk[b + 5 * 4 + 1]) / 2f
                    val hipY = (sk[b + 8 * 4 + 1] + sk[b + 11 * 4 + 1]) / 2f
                    torsos.add(kotlin.math.abs(hipY - shY))
                }
            }
            if (torsos.isEmpty()) return@mapNotNull null
            ScaleConsistencyChecker.Entry(
                panelIndex = panel.index,
                group = panel.scene.locationName?.trim()?.lowercase().orEmpty(),
                torso = torsos.average().toFloat(),
                boxes = panel.scene.objectBoxes.map { ScaleConsistencyChecker.Box(it.label, kotlin.math.abs(it.ymax - it.ymin)) }
            )
        }
        val warnings = ScaleConsistencyChecker.check(entries)
        warnings.forEach { w ->
            log("  ⚠ Panel ${w.panelIndex + 1}: \"${w.label}\" lệch ${(w.deviation * 100).toInt()}% so với tỉ lệ vật/người " +
                "của các panel cùng cảnh — kiểm tra kích thước vật thể", LogLevel.WARN)
        }
        if (warnings.isEmpty() && entries.size >= 2) log("  ✓ Tỉ lệ vật thể nhất quán giữa ${entries.size} panel có khai hộp vật thể", LogLevel.OK)
    }

    // mục 251 TECHNICAL_STATUS.md — BỐ CỤC TƯƠNG TÁC: với panel đúng 2 nhân vật embrace/kiss/combat, nhờ server InteractDiffusion sinh ảnh bố cục
    // (ôm/hôn/đánh), trích khung xương bằng YOLOv8-pose, lưu vào scene.layoutSkeleton để resolveSkeletonData dùng THAY khung xương mẫu. Ảnh cuối vẫn do
    // pipeline của dự án render (checkpoint/LoRA/IP-Adapter/độ phân giải của dự án) — xem InteractionLayout.kt. Mọi lỗi -> giữ khung xương mẫu.
    private suspend fun prepareInteractionLayouts(panels: List<Panel>, story: Story, chapterNumber: Int?, settings: GenerationSettings): List<Panel> {
        val cfg = settings.remoteEndpoint
        if (!settings.remoteInteractLayout || !cfg.enabled) return panels
        val client = RemoteGenerationClient(cfg)
        var stopped = false
        return panels.map { panel ->
            val sc = panel.scene
            val phrase = InteractionLayout.actionPhrase(sc.actionCategory)
            if (stopped || phrase == null || sc.characters.size != 2 || !sc.layoutSkeleton.isNullOrEmpty()) return@map panel
            try {
                val ov = panel.overrideSettings
                val template = ov?.poseTemplate ?: panel.suggestedPoseTemplate ?: guessPoseTemplate(panel)
                val angle = ov?.poseAngle ?: panel.suggestedPoseAngle
                val order = stableCharacterOrder(sc.characters, story.characters)
                val tmpl = OutputVerifier.targetsFromSkeleton(resolveSkeletonData(template, angle, sc, story, order, chapterNumber = chapterNumber))
                if (tmpl.size != 2) return@map panel
                val b0 = InteractionLayout.personBox(tmpl[0]); val b1 = InteractionLayout.personBox(tmpl[1])
                if (b0 == null || b1 == null) return@map panel
                val inter = org.json.JSONObject().apply {
                    put("subject_phrase", "person"); put("object_phrase", "person"); put("action_phrase", phrase)
                    put("subject_box", org.json.JSONArray(b0.map { it.toDouble() })); put("object_box", org.json.JSONArray(b1.map { it.toDouble() }))
                }
                val png = client.runImageTask("interact", null, mapOf(
                    "prompt" to InteractionLayout.prompt(sc.actionCategory), "interaction" to inter,
                    "width" to settings.width, "height" to settings.height, "seed" to sc.index.toLong()))
                val bmp = BitmapFactory.decodeByteArray(png, 0, png.size) ?: return@map panel
                val people = try { poseExtractor.extractFromImage(bmp) } finally { bmp.recycle() }
                val ordered = InteractionLayout.orderedDetected(tmpl, OutputVerifier.detectedFromKeypoints(people ?: emptyList()))
                if (ordered == null) {
                    log("  Bố cục tương tác panel ${panel.index + 1}: không dò đủ 2 người (đủ khớp) trong ảnh bố cục — dùng khung xương mẫu")
                    return@map panel
                }
                log("  Bố cục tương tác panel ${panel.index + 1}: dùng khung xương từ InteractDiffusion (\"$phrase\")")
                panel.copy(scene = sc.copy(layoutSkeleton = InteractionLayout.flatten(ordered).toList()))
            } catch (ex: RemoteGenerationClient.RemoteTaskException) {
                stopped = true
                log("  ⚠ Bố cục tương tác dừng: ${ex.message}", LogLevel.WARN)
                panel
            } catch (ex: Exception) {
                log("  ⚠ Bố cục tương tác panel ${panel.index + 1} lỗi (${ex.message}) — dùng khung xương mẫu", LogLevel.WARN)
                panel
            }
        }
    }

    // mục 250 TECHNICAL_STATUS.md — vị trí ĐẦU từng nhân vật (hộp chuẩn hoá) + ảnh neo, để server ghép mặt/khung. Cùng cách xếp thứ tự người ↔ nhân vật
    // như speakerHeadsForPanel/sinh ảnh (stableCharacterOrder). Rỗng khi panel không có khung xương hoặc nhân vật không có ảnh neo còn tồn tại.
    private fun remoteTargetsForPanel(panel: Panel, story: Story, chapterNumber: Int?): List<RemotePostProcess.Target> {
        if (panel.scene.characters.isEmpty()) return emptyList()
        return try {
            val ov = panel.overrideSettings
            val template = ov?.poseTemplate ?: panel.suggestedPoseTemplate ?: guessPoseTemplate(panel)
            val angle = ov?.poseAngle ?: panel.suggestedPoseAngle
            val order = stableCharacterOrder(panel.scene.characters, story.characters)
            val sk = resolveSkeletonData(template, angle, panel.scene, story, order, chapterNumber = chapterNumber)
            if (sk.isEmpty()) return emptyList()
            val people = OutputVerifier.targetsFromSkeleton(sk)
            val out = ArrayList<RemotePostProcess.Target>()
            order.forEachIndexed { i, name ->
                if (i >= people.size) return@forEachIndexed
                val ref = story.characters.firstOrNull { it.name == name }?.anchorImagePath
                val box = RemotePostProcess.headBox(people[i].joints)
                if (ref != null && File(ref).isFile && box != null) out.add(RemotePostProcess.Target(name, box, ref, RemotePostProcess.shoulderNorm(people[i].joints)))
            }
            out
        } catch (ex: Exception) {
            log("  ⚠ Không lấy được vị trí đầu panel ${panel.index + 1} cho hậu kỳ server (${ex.message})", LogLevel.WARN)
            emptyList()
        }
    }

    // mục 250 — HẬU KỲ TRÊN SERVER cho từng panel đã có ảnh cuối: Kontext (chỉ panel có ĐÚNG 1 nhân vật có ảnh neo) → sửa tay → hoán đổi mặt.
    // Kết quả ghi ra file MỚI (panel_NNN_srv.png) và gán vào upscaledPath; ảnh gốc imagePath giữ nguyên. Lỗi một panel -> panel đó giữ nguyên ảnh
    // (mọi bước của panel đó bị huỷ, không để nửa chừng); server không hỗ trợ tác vụ -> dừng các panel còn lại.
    suspend fun remotePostProcess(chapter: Chapter, story: Story, settings: GenerationSettings, outDir: File): Chapter = withContext(Dispatchers.IO) {
        val cfg = settings.remoteEndpoint
        val doKontext = settings.remoteKontext; val doHand = settings.remoteHandFix; val doSwap = settings.remoteFaceSwap
        if (!cfg.enabled || !(doKontext || doHand || doSwap)) return@withContext chapter
        val client = RemoteGenerationClient(cfg)
        outDir.mkdirs()
        var stopped = false
        var changedCount = 0
        fun b64(path: String) = android.util.Base64.encodeToString(File(path).readBytes(), android.util.Base64.NO_WRAP)
        val newPanels = chapter.panels.map { panel ->
            val src = panel.upscaledPath ?: panel.imagePath
            if (stopped || src == null || !File(src).exists()) return@map panel
            val targets = if (doSwap || doKontext) remoteTargetsForPanel(panel, story, chapter.chapterNumber) else emptyList()
            try {
                var cur = File(src).readBytes()
                var changed = false
                val notes = ArrayList<String>()      // mục 251: ghi chú từ báo cáo của server (hoàn nguyên/khôi phục/bỏ qua/cảnh báo tỉ lệ)
                var needsReview = false
                if (doKontext) {
                    if (targets.size == 1) {
                        cur = client.runImageTask(RemotePostProcess.TASK_KONTEXT, cur,
                            mapOf("prompt" to RemotePostProcess.KONTEXT_PROMPT, "ref_b64" to b64(targets[0].refPath)))
                        changed = true
                    } else log("  Kontext bỏ qua panel ${panel.index + 1}: cần đúng 1 nhân vật có ảnh neo và khung xương (hiện ${targets.size})")
                }
                if (doHand) {
                    cur = client.runImageTask(RemotePostProcess.TASK_HANDFIX, cur)
                    changed = true
                }
                if (doSwap) {
                    if (targets.isNotEmpty()) {
                        val arr = org.json.JSONArray()
                        targets.forEach { t ->
                            arr.put(org.json.JSONObject().apply {
                                put("id", t.name)
                                put("box", org.json.JSONArray(t.box.map { it.toDouble() }))
                                put("ref_b64", b64(t.refPath))
                                t.shoulderNorm?.let { put("shoulder_norm", it.toDouble()) }
                            })
                        }
                        cur = client.runImageTask(RemotePostProcess.TASK_FACESWAP, cur, mapOf("targets" to arr))
                        changed = true
                        RemotePostProcess.pngText(cur, "mangalocal_report")?.let { RemotePostProcess.faceSwapSummary(it) }?.let { sm ->
                            notes.addAll(sm.notes)
                            if (sm.hasRevert) needsReview = true
                            sm.notes.forEach { n -> log("    $n") }
                        }
                    } else log("  Hoán đổi mặt bỏ qua panel ${panel.index + 1}: không có nhân vật nào vừa có ảnh neo vừa có khung xương")
                }
                if (!changed) return@map panel
                val out = File(outDir, RemotePostProcess.panelFileName(panel.index))
                out.writeBytes(cur)
                changedCount++
                log("  Hậu kỳ server panel ${panel.index + 1}: xong")
                panel.copy(upscaledPath = out.absolutePath,
                    qualityGatePassed = panel.qualityGatePassed && !needsReview,
                    qualityGateReasons = panel.qualityGateReasons + notes)
            } catch (ex: RemoteGenerationClient.RemoteTaskException) {
                stopped = true
                log("  ⚠ Hậu kỳ server dừng: ${ex.message}", LogLevel.WARN)
                panel
            } catch (ex: Exception) {
                log("  ⚠ Hậu kỳ server panel ${panel.index + 1} lỗi (${ex.message}) — giữ ảnh cũ", LogLevel.WARN)
                panel
            }
        }
        log("Hậu kỳ trên server: $changedCount/${chapter.panels.size} panel đã xử lý")
        chapter.copy(panels = newPanels)
    }

    // mục 228 TECHNICAL_STATUS.md — vị trí ĐẦU (chuẩn hoá 0..1) của từng nhân
    // vật trong panel, lấy từ khung xương ĐẦU VÀO đã feed ControlNet (cùng
    // thứ tự stableCharacterOrder như lúc sinh ảnh, nên slot i <-> nhân vật
    // i). Rỗng khi panel không có template pose (nhánh GLIGEN/không pose)
    // hoặc khớp đầu/cổ không đủ tin cậy — caller rơi về cách đặt cũ.
    // GIỚI HẠN THẬT: là vị trí THEO KHUNG XƯƠNG, không dò lại từ ảnh sinh ra;
    // nếu ảnh không bám khung xương thì đuôi bubble có thể lệch (user vẫn
    // kéo/sửa tay được như trước). CHƯA build-test.
    private fun speakerHeadsForPanel(
        panel: Panel, story: Story, allChars: List<Character>, chapterNumber: Int?
    ): Map<String, Pair<Float, Float>> {
        if (panel.scene.dialogue.isEmpty() || panel.scene.characters.isEmpty()) return emptyMap()
        return try {
            val ov = panel.overrideSettings
            val template = ov?.poseTemplate ?: panel.suggestedPoseTemplate ?: guessPoseTemplate(panel)
            val angle = ov?.poseAngle ?: panel.suggestedPoseAngle
            val order = stableCharacterOrder(panel.scene.characters, allChars)
            val sk = resolveSkeletonData(template, angle, panel.scene, story, order, chapterNumber = chapterNumber)
            if (sk.isEmpty()) return emptyMap()
            val fpp = 18 * 4
            val out = LinkedHashMap<String, Pair<Float, Float>>()
            order.forEachIndexed { i, name ->
                val base = i * fpp
                if (base + fpp > sk.size) return@forEachIndexed
                var sx = 0f; var sy = 0f; var n = 0
                for (j in intArrayOf(0, 14, 15, 16, 17)) {
                    val o = base + j * 4
                    if (sk[o + 3] > 0.5f) { sx += sk[o]; sy += sk[o + 1]; n++ } // bố cục (x,y,z,visible) — mục 231
                }
                if (n > 0) {
                    out[name] = Pair((sx / n).coerceIn(0f, 1f), (sy / n).coerceIn(0f, 1f))
                } else {
                    val o = base + 1 * 4 // chỉ còn cổ: đầu ước lượng nằm trên cổ một đoạn
                    if (sk[o + 3] > 0.5f) out[name] = Pair(sk[o].coerceIn(0f, 1f), (sk[o + 1] - 0.05f).coerceIn(0f, 1f))
                }
            }
            out
        } catch (ex: Exception) {
            log("  ⚠ Không lấy được vị trí đầu nhân vật panel ${panel.index + 1} (${ex.message}) — đặt bubble theo cách cũ")
            emptyMap()
        }
    }

    // ── Giai đoạn 3 (tùy chọn): Auto bubble bằng YOLOv8 ────────────────────
    suspend fun autoPlaceBubbles(chapter: Chapter): Chapter = withContext(Dispatchers.IO) {
        emit(PipelineStage.BUBBLE_AUTO, "Tải YOLOv8n để detect vị trí nhân vật...")
        val loaded = bubbleEngine.loadYolo()
        if (!loaded) {
            log("⚠ Không có YOLOv8n, dùng vị trí mặc định")
        }

        // mục 228 TECHNICAL_STATUS.md — đặt bubble THEO NGƯỜI NÓI: dùng vị trí
        // đầu từng nhân vật lấy từ chính khung xương panel (xem
        // speakerHeadsForPanel). Không có khung xương (panel không dùng pose)
        // -> rơi về đúng 2 nhánh cũ (YOLO né hộp / vị trí lưới mặc định).
        val storyForBubbles = storyManager.loadStory(chapter.storyId)
        val charsForBubbles = storyForBubbles?.let { applyActiveAnchorVersion(it.characters, chapter.chapterNumber) } ?: emptyList()
        val updated = chapter.panels.map { panel ->
            val imgPath = panel.upscaledPath ?: panel.imagePath ?: return@map panel
            val heads = if (storyForBubbles != null)
                speakerHeadsForPanel(panel, storyForBubbles, charsForBubbles, chapter.chapterNumber) else emptyMap()
            val bubbles = if (heads.isNotEmpty() && panel.scene.dialogue.isNotEmpty()) {
                bubbleEngine.placeWithSpeakers(panel.scene.dialogue, heads)
            } else if (loaded) {
                bubbleEngine.autoPplaceBubbles(imgPath, panel.scene.dialogue)
            } else {
                bubbleEngine.defaultBubbles(panel.scene.dialogue)
            }
            log("✓ Panel ${panel.index + 1}: ${bubbles.size} bubble")
            panel.copy(bubbles = bubbles)
        }
        bubbleEngine.freeYolo()
        chapter.copy(panels = updated)
    }

    // ── Giai đoạn 4: Export ─────────────────────────────────────────────────
    // SỬA (yêu cầu chọn định dạng xuất): trước đây LUÔN xuất cả PDF lẫn CBZ,
    // không cho chọn. Giờ nhận thêm 2 cờ, mặc định cả 2 = true (giữ đúng
    // hành vi cũ nếu không truyền gì) — UI (PostProcessingScreen) cho user
    // tự bỏ chọn loại không cần.
    // jpegQuality: mặc định giữ 92 (hành vi cũ) nếu nơi gọi không truyền
    // gì — MainViewModel truyền settings.cbzJpegQuality thật để UI Settings
    // (mục "đã code nhưng thiếu UI") có tác dụng thật.
    // mục 141 TECHNICAL_STATUS.md — thêm `storyTitle` để đặt tên file xuất
    // theo "Tên truyện - Tên chương" thay vì tên cứng "chapter" (xem
    // sanitizeFilename() ở ExportEngine.kt). Default rỗng + fallback về
    // chapter.title khi rỗng — không bắt buộc sửa MỌI call site cũ.
    suspend fun exportChapter(
        chapter: Chapter, outDir: File, exportPdf: Boolean = true, exportCbz: Boolean = true,
        jpegQuality: Int = 92, storyTitle: String = "", extras: ExportExtras = ExportExtras()
    ): Chapter = withContext(Dispatchers.IO) {
        emit(PipelineStage.LAYOUT_EXPORT, "Đang xuất...")
        val fileBaseName = if (storyTitle.isBlank()) chapter.title else "$storyTitle - ${chapter.title}"
        // mục 233 — template/profile mặc định (STACK_2 + A4) đi đúng đường cũ; khác mặc định mới dùng PublishExporter.
        val pdfPath = if (exportPdf) {
            if (extras.usesCustomPdf)
                publishExporter.exportPdf(chapter.panels, outDir, chapter.title, fileBaseName, extras.pageTemplate, extras.pageProfile, extras.rightToLeft)
            else exportEngine.exportPdf(chapter.panels, outDir, chapter.title, fileBaseName)
        } else null
        val cbzPath = if (exportCbz) exportEngine.exportCbz(chapter.panels, outDir, jpegQuality, fileBaseName,
            rtl = extras.rightToLeft, series = storyTitle, chapterNumber = chapter.chapterNumber, title = chapter.title) else null

        // mục 233/234 — file phụ; lỗi từng loại chỉ ghi log, không làm hỏng PDF/CBZ đã xuất xong.
        val extraFiles = mutableListOf<Pair<String, String>>()
        if (extras.webtoonZip) try {
            extraFiles += publishExporter.exportWebtoonZip(chapter.panels, outDir, fileBaseName) to "application/zip"
            log("  → Đã xuất dải dọc Webtoon (800px, mỗi ảnh ≤1280px)")
        } catch (ex: Exception) { log("  ⚠ Xuất Webtoon lỗi: ${ex.message}", LogLevel.WARN) }
        if (extras.metadataJson) try {
            extraFiles += publishExporter.exportMetadata(chapter, outDir, fileBaseName, extras) to "application/json"
        } catch (ex: Exception) { log("  ⚠ Xuất metadata lỗi: ${ex.message}", LogLevel.WARN) }
        if (extras.videoPack && extras.story != null) try {
            extraFiles += exportVideoPack(chapter, extras.story, outDir, fileBaseName,
                runCatching { VideoTarget.valueOf(extras.videoTarget) }.getOrDefault(VideoTarget.KEEP),
                speech = extras.videoSpeech, remote = extras.videoRemote) to "application/zip"
            log("  → Đã xuất gói ảnh cho model video")
        } catch (ex: Exception) { log("  ⚠ Xuất gói video lỗi: ${ex.message}", LogLevel.WARN) }
        if (extras.kenBurnsVideo) try {
            log("  → Đang dựng video Ken Burns (chậm, dùng encoder phần cứng)...")
            extraFiles += videoExporter.exportKenBurns(chapter.panels, outDir, fileBaseName,
                secondsPerPanel = extras.videoSecondsPerPanel) to "video/mp4"
            log("  → Đã xuất video Ken Burns")
        } catch (ex: Exception) { log("  ⚠ Xuất video lỗi: ${ex.message}", LogLevel.WARN) }
        lastExtraExports = extraFiles
        log("✅ Hoàn thành!")
        _state.update { it.copy(stage = PipelineStage.DONE) }
        chapter.copy(pdfPath = pdfPath ?: chapter.pdfPath, cbzPath = cbzPath ?: chapter.cbzPath)
    }

    // ── Thermal gate ─────────────────────────────────────────────────────
    private suspend fun waitForThermalSafe(settings: GenerationSettings) {
        while (thermalMonitor.state.value.isOverheating) {
            _state.update { it.copy(
                isPaused = true, pauseReason = PauseReason.THERMAL,
                currentTempC = thermalMonitor.state.value.currentTempC
            )}
            log("🔥 Máy đang nóng ${thermalMonitor.state.value.currentTempC}°C — tạm dừng", LogLevel.WARN)
            delay(2000)
            if (!settings.autoResume) {
                // Chờ người dùng resume thủ công - check lại mỗi 2s
                continue
            }
        }
        if (_state.value.isPaused) {
            log("✓ Máy đã nguội, tiếp tục...", LogLevel.OK)
            _state.update { it.copy(isPaused = false, pauseReason = null) }
        }
    }

    // mục 83 TECHNICAL_STATUS.md — PHÁT HIỆN KHI RÀ LẠI THEO YÊU CẦU USER
    // (đối chiếu với `thêm_sd1_5.txt`, claim "cancel() gây dangling
    // pointer" — xác nhận ĐÚNG, và còn NGHIÊM TRỌNG HƠN mô tả gốc):
    //
    // Trường `job` phía trên KHÔNG BAO GIỜ được gán — `runGeneration()`/
    // `regeneratePanel()`/`upscaleApprovedPanels()` đều được gọi trực tiếp
    // từ `viewModelScope.launch { pipeline.runGeneration(...) }` bên
    // MainViewModel, Job THẬT của coroutine đó sống trong `viewModelScope`,
    // KHÔNG BAO GIỜ được gán vào `pipeline.job`. Nghĩa là `job?.cancel()`
    // dưới đây LUÔN LÀ NO-OP — hàm `cancel()` cũ này chưa từng thực sự huỷ
    // được coroutine đang chạy, chỉ giải phóng con trỏ native NGAY LẬP TỨC
    // trong khi coroutine (nếu đang chạy dở) vẫn tiếp tục gọi
    // `NativeBridge.sdImg2Img()`/`sdTxt2Img*()` — các hàm JNI BLOCKING,
    // KHÔNG cooperative-cancellable giữa chừng — dùng ĐÚNG con trỏ vừa bị
    // free. Đây là use-after-free THẬT, không phải suy đoán lý thuyết.
    //
    // GIỮ NGUYÊN hàm `cancel()` cũ (không xoá) — dùng làm fallback CUỐI
    // CÙNG cho `onCleared()` (ViewModel lifecycle, non-suspend, tại thời
    // điểm này `viewModelScope` gần như đã bị Android tự huỷ, không còn
    // đường an toàn nào để "đợi coroutine dừng hẳn" nữa — ưu tiên giải
    // phóng native handle ngay, chấp nhận rủi ro nhỏ hơn là leak vĩnh viễn
    // khi Activity/ViewModel bị destroy).
    //
    // HÀM MỚI `cancelSafely()` bên dưới là con đường ĐÚNG cho nút "Huỷ"
    // người dùng bấm khi app vẫn đang chạy bình thường — THẬT SỰ đợi
    // coroutine dừng hẳn (`cancelAndJoin()`) trước khi đụng vào bất kỳ con
    // trỏ native nào.
    fun cancel() {
        job?.cancel()
        llmParser?.free()
        imagePipeline.freeAll()
        bubbleEngine.freeYolo()
        thermalMonitor.stop()
        // maskFixer là `by lazy` — chỉ gọi close() (giải phóng MobileSAM
        // native) nếu ĐÃ từng khởi tạo thật (tránh tự khởi tạo chỉ để đóng
        // ngay, panel chưa từng chạy auto-fix thì không cần đụng tới).
        if (maskFixerLazy.isInitialized()) maskFixer.close()
        _state.value = PipelineState()
    }

    /**
     * mục 83 TECHNICAL_STATUS.md — Huỷ AN TOÀN, dùng cho nút "Huỷ" người
     * dùng bấm khi app đang chạy bình thường (KHÔNG dùng cho `onCleared()`
     * — xem giải thích ở docstring `cancel()` phía trên).
     *
     * `currentJob?.cancelAndJoin()` THẬT SỰ đợi coroutine đang chạy dừng
     * hẳn — bao gồm cả trường hợp nó đang blocking giữa chừng 1 lời gọi
     * JNI native (`sdImg2Img`/`sdTxt2Img*`): coroutine sẽ tiếp tục chạy
     * đến khi native call đó TRẢ VỀ QUYỀN ĐIỀU KHIỂN cho Kotlin, sau đó
     * mới thấy cờ huỷ và ném `CancellationException` tại điểm suspend tiếp
     * theo — `cancelAndJoin()` đợi đúng tới lúc đó, KHÔNG trả về sớm hơn.
     * Chỉ SAU KHI `cancelAndJoin()` trả về, ta mới chắc chắn không còn
     * thread nào đang dùng `sdCtx`/`esrganCtx`/MobileSAM handle nữa, lúc
     * đó gọi `freeAll()` mới thật sự an toàn.
     *
     * GIỚI HẠN THẬT: nếu native call ĐANG TREO (hang thật, không bao giờ
     * trả về — ví dụ deadlock nội bộ C++), `cancelAndJoin()` sẽ ĐỢI VÔ HẠN,
     * hàm này sẽ không bao giờ return. Đây là đánh đổi có chủ đích: thà
     * treo UI (người dùng thấy nút Huỷ không phản hồi, biết có vấn đề) còn
     * hơn silent crash app do use-after-free — nhưng CHƯA có timeout/circuit-
     * breaker cho trường hợp hang thật, TODO còn lại nếu phát hiện xảy ra
     * trong thực tế. CHƯA BUILD-TEST.
     */
    /**
     * mục 83/84 TECHNICAL_STATUS.md — Huỷ AN TOÀN kèm timeout thật (mục 84
     * đóng nốt TODO mục 83 để lại: "chưa có timeout/circuit-breaker cho
     * trường hợp native call bị hang thật").
     *
     * KHÔNG THỂ giải quyết triệt để việc "ép dừng" 1 lời gọi JNI blocking
     * đang treo thật (deadlock C++ nội bộ) — Kotlin cancel() là cooperative,
     * không có cách nào preempt 1 thread native đang chạy từ phía Kotlin mà
     * không có nguy cơ corrupt state (Android không cho app tự kill riêng
     * 1 native thread của chính nó một cách an toàn). Đây là giới hạn THẬT
     * của mọi hệ thống có blocking FFI call, không phải thiếu sót có thể
     * code cho hết.
     *
     * NHƯNG có thể giới hạn THỜI GIAN CHỜ + báo cho người dùng biết, thay
     * vì để UI treo vô thời hạn không 1 dấu hiệu nào (trải nghiệm tệ hơn
     * hẳn so với 1 thông báo rõ ràng "có thể đang bị treo, khởi động lại
     * app nếu kéo dài"):
     *  - Trong [timeoutMs] (mặc định 30 giây — đủ rộng cho 1 bước UNet
     *    forward chậm nhất trên phần cứng yếu, không quá dài để người dùng
     *    phải đợi vô ích khi thật sự bị treo): đợi `cancelAndJoin()` như
     *    bình thường qua `withTimeoutOrNull()`.
     *  - Nếu coroutine dừng THẬT trong khoảng đó -> an toàn free native
     *    pointer như cũ, trả về [CancelResult.Success].
     *  - Nếu HẾT timeout mà coroutine vẫn chưa dừng -> đây là dấu hiệu
     *    native call thật sự bị treo. **CỐ TÌNH KHÔNG gọi `freeAll()`** —
     *    thà chấp nhận leak/treo còn hơn free trong khi có thể vẫn còn
     *    thread khác đang dùng đúng con trỏ đó (use-after-free thật sự xảy
     *    ra nếu free lúc này). Trả về [CancelResult.TimedOut] để
     *    `MainViewModel` hiển thị cảnh báo rõ ràng cho người dùng.
     *
     * CHƯA BUILD-TEST.
     */
    sealed class CancelResult { object Success : CancelResult(); object TimedOut : CancelResult() }
    // mục 93 TECHNICAL_STATUS.md — kết quả "So Sánh Thử" PromptStyle.
    data class PromptStyleTestResult(
        val tagBasedImagePath: String, val naturalLanguageImagePath: String,
        val tagPrompt: String, val naturalLanguagePrompt: String
    )

    // mục 107 TECHNICAL_STATUS.md — "So sánh thử" cho Pose/Depth/Decay,
    // MỞ RỘNG cơ chế mục 93 (PromptStyleTestResult) sang panel THẬT thay vì
    // mô tả tự do — BẮT BUỘC vì poseConditioningScale/depthConditioningScale/
    // ipDecayFloor CHỈ có tác dụng trên đường sinh CÓ IP-Adapter/ControlNet
    // (cần ảnh nhân vật tham chiếu + skeleton thật), không dùng chung được
    // đường txt2img thường như mục 93 (xem runPromptStyleComparisonTest()).
    //
    // GIỚI HẠN THẬT — PHẠM VI: chỉ hỗ trợ đường sinh 1-NHÂN-VẬT (IP-Adapter
    // đơn, `imagePipeline.generatePanel` với referenceImagePath). CHƯA hỗ
    // trợ panel dùng đường multi-char mask/regional (cần logic resolve
    // phức tạp hơn nhiều, xem `regeneratePanel()` — không nhân bản ở đây
    // để tránh 2 nơi lặp logic rồi lệch nhau, bài học mục 93). Nếu panel
    // KHÔNG có `referenceImage` (nhân vật đầu tiên có anchorImagePath),
    // trả về null — UI tự hiển thị thông báo phù hợp, không throw.
    data class ConditioningTestResult(
        val autoImagePath: String, val globalImagePath: String,
        val autoPreset: ConditioningPreset, val globalPreset: ConditioningPreset,
        val actionCategoryUsed: String?
    )

    suspend fun runConditioningComparisonTest(
        panel: Panel, story: Story, settings: GenerationSettings, outDir: File
    ): ConditioningTestResult? = withContext(Dispatchers.IO) {
        val referenceImage = panel.scene.characters.firstNotNullOfOrNull { name ->
            storyManager.getCharacterAnchor(story.id, name, preferTorn = false)
        } ?: return@withContext null

        val actionCat = panel.scene.actionCategory?.takeIf { it in setOf("embrace", "combat", "kiss", "run", "neutral") }
        val autoPreset = actionCat?.let { ACTION_CONDITIONING_PRESETS[it] } ?: ACTION_CONDITIONING_PRESETS.getValue("neutral")
        val globalPreset = ConditioningPreset(
            poseConditioningScale = settings.poseConditioningScale, depthConditioningScale = settings.depthConditioningScale,
            depthActiveMinTimestep = settings.depthActiveMinTimestep, ipDecayFloor = settings.ipDecayFloor,
            ipDecayStartTimestep = settings.ipDecayStartTimestep, ipStaticScale = settings.consistencyStrength
        )

        val eff107 = resolveEffective(panel, settings)
        val skeletonData = resolveSkeletonData(eff107.poseTemplate, eff107.poseAngle, panel.scene, story)
        // CÙNG 1 seed cho cả 2 ảnh — chỉ khác 6 tham số conditioning, so
        // sánh công bằng (đúng nguyên tắc mục 93: "chỉ khác PROMPT/tham số
        // đang test, không khác nhiễu khởi tạo").
        val testSeed = panel.overrideSettings?.seed ?: 424242L

        val autoImg = imagePipeline.generatePanel(
            panelIndex = 9500 + panel.index, prompt = eff107.prompt, negativePrompt = eff107.negativePrompt,
            stylePrompt = settings.imageStyle.stylePrompt, width = 384, height = 384, steps = 20, cfgScale = 7f,
            seed = testSeed, referenceImagePath = referenceImage, skeletonData = skeletonData,
            useStoryDiffusion = true, outDir = outDir, onProgress = { _, _ -> },
            poseConditioningScale = autoPreset.poseConditioningScale, depthConditioningScale = autoPreset.depthConditioningScale,
            depthActiveMinTimestep = autoPreset.depthActiveMinTimestep, ipDecayFloor = autoPreset.ipDecayFloor,
            ipDecayStartTimestep = autoPreset.ipDecayStartTimestep, ipStaticScale = autoPreset.ipStaticScale
        )
        val globalImg = imagePipeline.generatePanel(
            panelIndex = 9600 + panel.index, prompt = eff107.prompt, negativePrompt = eff107.negativePrompt,
            stylePrompt = settings.imageStyle.stylePrompt, width = 384, height = 384, steps = 20, cfgScale = 7f,
            seed = testSeed, referenceImagePath = referenceImage, skeletonData = skeletonData,
            useStoryDiffusion = true, outDir = outDir, onProgress = { _, _ -> },
            poseConditioningScale = globalPreset.poseConditioningScale, depthConditioningScale = globalPreset.depthConditioningScale,
            depthActiveMinTimestep = globalPreset.depthActiveMinTimestep, ipDecayFloor = globalPreset.ipDecayFloor,
            ipDecayStartTimestep = globalPreset.ipDecayStartTimestep, ipStaticScale = globalPreset.ipStaticScale
        )

        ConditioningTestResult(autoImg, globalImg, autoPreset, globalPreset, actionCat)
    }

    suspend fun cancelSafely(timeoutMs: Long = 30_000L): CancelResult {
        val runningJob = currentJob
        if (runningJob == null || !runningJob.isActive) {
            // Không có coroutine nào đang thực sự chạy (hoặc đã tự kết
            // thúc) — an toàn free ngay, không cần đợi gì cả.
            freeAllPipelineResources()
            return CancelResult.Success
        }

        // mục 142 TECHNICAL_STATUS.md — BỔ TRỢ cho cơ chế mục 84 bên dưới
        // (KHÔNG thay thế): bật cờ ngắt native TRƯỚC khi cancelAndJoin().
        // Vòng lặp denoise thật (sd_engine/Pipeline.hpp) giờ tự kiểm tra
        // cờ này GIỮA 2 step — nếu native đang chạy đúng lúc gọi hàm này,
        // nó sẽ tự dừng ở step kế tiếp (throw GenerationInterrupted, bắt
        // bởi try/catch có sẵn ở tầng JNI, trả JNI_FALSE) thay vì phải
        // chạy hết toàn bộ số step CÒN LẠI rồi coroutine mới cancel được
        // — giảm mạnh khả năng chạm ngưỡng timeoutMs bên dưới. Đây KHÔNG
        // phải "ép dừng tức thời" (đọc GIỚI HẠN THẬT tại khai báo
        // g_generation_interrupted trong Pipeline.hpp — không ngắt được
        // giữa chừng 1 lệnh runSession() đang chạy, chỉ ngắt được giữa 2
        // step) — withTimeoutOrNull()/"không free tới khi native thật sự
        // trả về" của mục 84 VẪN LÀ lưới an toàn cuối cùng, giữ nguyên y
        // hệt bên dưới, không đổi gì.
        try { NativeBridge.signalInterruptNative() } catch (_: Throwable) {}

        val completed = withTimeoutOrNull(timeoutMs) {
            runningJob.cancelAndJoin()
            true
        }

        return if (completed == true) {
            freeAllPipelineResources()
            CancelResult.Success
        } else {
            log("⚠ Huỷ sinh ảnh: quá ${timeoutMs / 1000} giây mà tiến trình chưa dừng hẳn — " +
                "có thể đang bị treo ở tầng native (MNN/SD). KHÔNG giải phóng bộ nhớ lúc này để " +
                "tránh crash do vẫn còn thread khác dùng con trỏ — nếu tình trạng kéo dài, khuyến " +
                "nghị khởi động lại app.", LogLevel.ERROR)
            CancelResult.TimedOut
        }
    }

    private fun freeAllPipelineResources() {
        llmParser?.free()
        imagePipeline.freeAll()
        bubbleEngine.freeYolo()
        thermalMonitor.stop()
        if (maskFixerLazy.isInitialized()) maskFixer.close()
        // mục 131 TECHNICAL_STATUS.md — user hỏi "ngoài LLM ra, các model
        // khác thì sao" dẫn tới phát hiện: poseExtractor (kích hoạt
        // YOLOv8-pose load NGAY lúc constructor chạy, không lazy nội bộ)
        // BỊ THIẾU khỏi hàm dọn dẹp trung tâm này — trong khi faceHandDetector
        // (dùng thật trong tryAutoFixInteractions(), chạy thường xuyên cho
        // cảnh 2+ người) PHỤ THUỘC poseExtractor, nên model YOLO gần như
        // CHẮC CHẮN được nạp trong phiên sinh truyện bình thường nhưng
        // KHÔNG BAO GIỜ giải phóng khi pipeline dọn dẹp. Dùng ĐÚNG khuôn
        // mẫu isInitialized() đã có sẵn cho maskFixer (không kích hoạt lazy
        // chỉ để đóng nếu chưa từng dùng tới — nếu chưa init thì đúng
        // nghĩa chưa có gì để giải phóng, gọi .close() lúc đó sẽ VÔ TÌNH
        // tạo mới rồi đóng ngay, lãng phí vô nghĩa chứ không sai, nhưng vẫn
        // nên tránh).
        if (poseExtractorLazy.isInitialized()) poseExtractor.close()
        if (depthEstimatorLazy.isInitialized()) depthEstimator.close()
        if (identityGuardLazy.isInitialized()) identityGuard.close()
        _state.value = PipelineState()
    }

    private fun emit(stage: PipelineStage, msg: String? = null, totalPanels: Int? = null) {
        _state.update { prev -> prev.copy(
            stage = stage, totalPanels = totalPanels ?: prev.totalPanels,
            log = if (msg != null) prev.log + LogEntry(time(), msg) else prev.log
        )}
    }

    private fun log(msg: String, level: LogLevel = LogLevel.INFO) {
        val lvl = when {
            msg.startsWith("✓") || msg.startsWith("✅") -> LogLevel.OK
            msg.startsWith("⚠") || msg.startsWith("🔥") -> LogLevel.WARN
            msg.startsWith("❌") -> LogLevel.ERROR
            else -> level
        }
        _state.update { it.copy(log = it.log + LogEntry(time(), msg, lvl)) }
    }

    private fun time() = SimpleDateFormat("mm:ss", Locale.getDefault()).format(Date())
}
