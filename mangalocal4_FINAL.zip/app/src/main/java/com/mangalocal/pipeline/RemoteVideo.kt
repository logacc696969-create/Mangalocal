package com.mangalocal.pipeline

/**
 * mục 249 TECHNICAL_STATUS.md — hằng số + hàm THUẦN cho "ảnh → clip (Stable Video Diffusion) qua server từ xa".
 * Giá trị mặc định/giới hạn bám tham số của pipeline diffusers (SVD-XT: tối đa 25 khung; fps điều kiện mặc định 7;
 * motion_bucket_id mặc định 127; noise_aug_strength mặc định 0.02) — server kẹp lại một lần nữa (tools/remote_server/app.py).
 * GIỚI HẠN THẬT: chưa chạy với server/GPU thật; xem `RemoteGenerationClient.generateVideo`.
 */
object RemoteVideo {
    const val MIN_FRAMES = 6
    const val MAX_FRAMES = 25
    const val DEFAULT_FRAMES = 14
    const val MIN_FPS = 3
    const val MAX_FPS = 30
    const val DEFAULT_FPS = 7
    const val MIN_MOTION = 1
    const val MAX_MOTION = 255
    const val DEFAULT_MOTION = 127
    const val DEFAULT_NOISE_AUG = 0.02f
    /** Một clip có thể mất nhiều phút (tải model + khử nhiễu 25 khung) -> thời hạn đọc riêng, dài hơn ảnh. */
    const val VIDEO_READ_TIMEOUT_S = 900L

    fun clampFrames(n: Int) = n.coerceIn(MIN_FRAMES, MAX_FRAMES)
    fun clampFps(n: Int) = n.coerceIn(MIN_FPS, MAX_FPS)
    fun clampMotion(n: Int) = n.coerceIn(MIN_MOTION, MAX_MOTION)

    /** mp4/ISO-BMFF: 4 byte đầu là kích thước hộp, 4 byte kế là "ftyp". Dùng để từ chối PNG của server cũ chưa hỗ trợ video. */
    fun isMp4(b: ByteArray): Boolean =
        b.size >= 12 && b[4] == 'f'.code.toByte() && b[5] == 't'.code.toByte() && b[6] == 'y'.code.toByte() && b[7] == 'p'.code.toByte()
}
