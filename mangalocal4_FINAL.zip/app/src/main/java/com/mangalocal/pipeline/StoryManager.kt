package com.mangalocal.pipeline

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.mangalocal.model.*
import java.io.File

class StoryManager(context: Context) {

    // Lưu applicationContext (KHÔNG leak, chuẩn Android) để MangaPipeline có
    // thể tự dựng FaceHandDetector (MediaPipe) mà không cần truyền Context
    // qua thêm 1 tầng constructor nữa — tái dùng đúng như user yêu cầu
    // ("có thể dùng nhiều nơi, không cần code lại").
    val appContext: Context = context.applicationContext

    // SỬA (chẩn đoán crash lúc mở app lần đầu): trước đây các dòng mkdirs()
    // dưới đây không có try/catch — nếu ghi vào GỐC bộ nhớ ngoài bị Android
    // chặn (scoped storage, thiếu quyền MANAGE_EXTERNAL_STORAGE), mkdirs()
    // tự nó không ném lỗi (chỉ trả về false), NHƯNG các thao tác đọc/ghi
    // file bên trong các thư mục này ngay sau đó (ensureManifestInitialized
    // gọi từ MainViewModel.init) sẽ ném IOException không ai bắt -> crash
    // ngay lúc StoryManager khởi tạo, tức ngay lúc tạo ViewModel, trước khi
    // kịp vẽ giao diện. Bọc try/catch + thử ghi thật (probe file) để phát
    // hiện chắc chắn, initError có giá trị rõ ràng thay vì crash cứng —
    // MainViewModel đọc initError và hiện dialog thân thiện thay vì để app
    // văng.
    var initError: String? = null
        private set

    private val rootDir: File
    private val storiesDir: File
    val modelsDir: File
    val lorasDir: File
    val esrganDir: File
    val yoloDir: File
    val embeddingSourcesDir: File

    init {
        // SỬA (vẫn lỗi dù đã cấp quyền "Bộ nhớ" thường — quyền ĐẶC BIỆT
        // "Quản lý tất cả tệp" nằm ở chỗ khác tuỳ hãng máy, rất dễ cấp
        // nhầm/không thấy mục đó): bỏ hẳn việc ghi vào GỐC bộ nhớ ngoài
        // (Environment.getExternalStorageDirectory()), đổi sang thư mục
        // riêng của app trong bộ nhớ ngoài (getExternalFilesDir) — không
        // cần xin BẤT KỲ quyền nào trên mọi phiên bản Android, luôn ghi
        // được ngay. Đường dẫn cụ thể: /storage/emulated/0/Android/data/
        // com.mangalocal/files/MangaLocal — vẫn xem được qua ứng dụng quản
        // lý tệp có hỗ trợ (ví dụ trình quản lý tệp gốc của máy, hoặc nối
        // USB vào máy tính), chỉ là không phải mọi app quản lý tệp bên thứ
        // 3 đều vào được thư mục Android/data trên Android 11+.
        val extBase = context.getExternalFilesDir(null) ?: context.filesDir
        val root = File(extBase, "MangaLocal")
        val stories = File(root, "stories")
        val models = File(root, "models")
        val loras = File(root, "loras")
        val esrgan = File(root, "esrgan")
        val yolo = File(root, "yolo")
        // File .safetensors Textual Inversion GỐC (train sẵn trên PC hoặc tải
        // từ cộng đồng) user copy tay vào đây qua file manager — giống hệt quy
        // ước lorasDir. StoryManager.setCharacterEmbedding() copy TỪ đây (hoặc
        // từ URI người dùng chọn) vào embeddingsDir() riêng của từng truyện.
        val embeddingSources = File(root, "embeddings_source")
        try {
            root.mkdirs(); stories.mkdirs(); models.mkdirs()
            loras.mkdirs(); esrgan.mkdirs(); yolo.mkdirs(); embeddingSources.mkdirs()
            // mkdirs() có thể "thành công" giả (trả true nhưng thư mục
            // không thật sự dùng được do FUSE scoped storage ở vài thiết
            // bị) — xác nhận bằng cách thử ghi 1 file test nhỏ.
            val probe = File(root, ".write_test")
            probe.writeText("ok")
            probe.delete()
        } catch (e: Exception) {
            initError = "Không ghi được vào bộ nhớ (${root.absolutePath}). " +
                "Thử khởi động lại app; nếu vẫn lỗi, kiểm tra còn dung lượng trống trên máy không. " +
                "(Lỗi gốc: ${e.javaClass.simpleName}: ${e.message})"
        }
        rootDir = root
        storiesDir = stories
        modelsDir = models
        lorasDir = loras
        esrganDir = esrgan
        yoloDir = yolo
        embeddingSourcesDir = embeddingSources
    }

    // ── Manifest model động (đọc bởi native qua sdInit) ─────────────────
    // KHÁC assets/model_manifest.json (chỉ đọc, đóng gói sẵn trong APK) —
    // đây là BẢN GHI ĐƯỢC, nằm ngoài APK, cập nhật mỗi khi convert xong 1
    // nhân vật mới. sdInit (native) đọc file NÀY, không đọc file trong
    // assets nữa — xem lại đường dẫn "../model_manifest.json" trong
    // mnn_diffusion_pipeline.cpp phải trỏ đúng rootDir này.
    private val manifestFile = File(rootDir, "model_manifest.json")
    private val manifestGson = Gson()

    // pose_library.json — sinh ra bởi tools/extract_pose_library.py (chạy
    // trên máy tính, MediaPipe Pose từ ảnh thật), đóng gói sẵn trong
    // assets/, copy ra đây để ip_adapter.cpp đọc được (native không đọc
    // trực tiếp assets/ của APK).
    val poseLibraryFile = File(rootDir, "pose_library.json")
    fun ensurePoseLibraryInitialized(context: Context) {
        if (poseLibraryFile.exists()) return
        try {
            context.assets.open("pose_library.json").use { input ->
                poseLibraryFile.outputStream().use { output -> input.copyTo(output) }
            }
        } catch (e: Exception) {
            // Chưa có pose_library.json trong assets (chưa chạy
            // extract_pose_library.py) -> để trống, ip_adapter.cpp tự
            // fallback về tư thế đơn giản khi không đọc được file.
        }
    }

    // ── Data model khớp CHÍNH XÁC schema JSON của extract_pose_library.py
    // và loadLibrary() trong ip_adapter.cpp — đổi 1 bên PHẢI đổi cả 2 bên.
    // confidence: điểm tự tin THẬT từ YOLOv8-pose (0..1) cho khớp này —
    // trước đây MediaPipe không tách riêng field này (chỉ có visible bool).
    // Mặc định 1f cho dữ liệu cũ đã lưu trước khi có field này (Gson tự
    // điền default khi thiếu field trong JSON cũ, không cần migrate tay).
    data class PoseKeypoint(val x: Float = 0f, val y: Float = 0f, val z: Float = 0f,
                             val visible: Boolean = false, val confidence: Float = 1f)
    // needsReview/reviewReasons: kết quả 3 kiểm tra tự động (mục 19
    // TECHNICAL_STATUS.md) — điểm tự tin thấp / thiếu khớp / giải phẫu dị
    // thường. Mặc định false/rỗng cho variant tạo thủ công (không qua auto-
    // detect thì không có gì để cảnh báo).
    // sourceProportions: tỷ lệ xương của người THẬT trong video/ảnh trích
    // xuất ra variant này (mục 32 TECHNICAL_STATUS.md) — mặc định = chuẩn
    // người lớn (1.0 mọi mặt), user có thể tự sửa khi lưu vào thư viện nếu
    // biết rõ nguồn khác (vd "quay 2 diễn viên trẻ em"). Cần biết baseline
    // này để tính TỶ LỆ retarget đúng khi áp cho nhân vật có boneProportions
    // khác — không có field này thì không biết retarget theo tỷ lệ nào.
    data class PoseVariant(val angle: String = "unknown", val people: MutableList<MutableList<PoseKeypoint>> = mutableListOf(),
                            val needsReview: Boolean = false, val reviewReasons: List<String> = emptyList(),
                            val sourceProportions: BoneProportions = BoneProportions(),
                            // Nhãn loại tương tác (mục 33 — tự chọn tư thế khớp kịch bản), user tự
                            // gõ khi lưu (vd "hug", "fight_lock", "standing_talk") — KHÔNG tự suy ra
                            // từ toạ độ khớp (không đáng tin), phải để user gắn nhãn thủ công 1 lần.
                            val actionTags: List<String> = emptyList())

    fun loadPoseLibrary(): MutableMap<String, MutableList<PoseVariant>> = try {
        val type = object : com.google.gson.reflect.TypeToken<MutableMap<String, MutableList<PoseVariant>>>() {}.type
        manifestGson.fromJson(poseLibraryFile.readText(), type) ?: mutableMapOf()
    } catch (e: Exception) { mutableMapOf() }

    fun savePoseLibrary(library: Map<String, List<PoseVariant>>) {
        poseLibraryFile.writeText(manifestGson.toJson(library))
    }

    /** Thêm/cập nhật 1 biến thể tư thế — gọi từ PoseEditorScreen sau khi
     * người dùng chỉnh/vẽ xong. variantIndex null = thêm mới, có giá trị =
     * ghi đè biến thể đã có (dùng khi sửa lại tư thế lỗi). */
    fun savePoseVariant(templateName: String, variant: PoseVariant, variantIndex: Int? = null) {
        val lib = loadPoseLibrary()
        val list = lib.getOrPut(templateName) { mutableListOf() }
        if (variantIndex != null && variantIndex in list.indices) list[variantIndex] = variant
        else list.add(variant)
        savePoseLibrary(lib)
    }

    fun listPoseTemplateNames(): List<String> = loadPoseLibrary().keys.sorted()

    // Gộp actionTags của TẤT CẢ biến thể trong 1 template (mục 6.4/34
    // TECHNICAL_STATUS.md — tự động chọn tư thế khớp mô tả kịch bản) — 1
    // template có thể có nhiều variant (góc khác nhau), mỗi variant có thể
    // được gắn tag khác nhau lúc lưu, gộp lại để so khớp rộng hơn.
    fun listPoseTemplateTags(): Map<String, List<String>> =
        loadPoseLibrary().mapValues { (_, variants) -> variants.flatMap { it.actionTags }.distinct() }

    /**
     * Import khung xương từ NGUỒN KHÁC (mục 34 TECHNICAL_STATUS.md — user
     * hỏi có nhập được thư viện tư thế từ nơi khác không). CHỈ hỗ trợ định
     * dạng OpenPose BODY_18 CHUẨN (18 điểm, thứ tự CMU OpenPose gốc — TRÙNG
     * KHỚP thứ tự OpenPose-18 đã dùng xuyên suốt app, không cần map lại) —
     * đây là định dạng phổ biến nhất từ công cụ khác (ComfyUI OpenPose
     * Editor, A1111 openpose extension export, DWPose...). KHÔNG hỗ trợ
     * BODY_25 (25 điểm, thứ tự khác hẳn — dễ nhầm, từ chối rõ ràng thay vì
     * đoán map sai).
     *
     * Input JSON mong đợi (chuẩn OpenPose output):
     *   {"people": [{"pose_keypoints_2d": [x0,y0,c0, x1,y1,c1, ..., x17,y17,c17]}]}
     * (x,y là PIXEL theo canvasWidth/canvasHeight gốc — OpenPose JSON gốc
     * KHÔNG tự kèm kích thước canvas, user phải tự cung cấp đúng kích thước
     * ảnh gốc để normalize về 0..1 đúng tỷ lệ, xem canvasWidth/canvasHeight bên dưới).
     *
     * @return số người import được, 0 nếu lỗi format/không phải BODY_18.
     */
    fun importOpenPoseJson(
        jsonText: String, canvasWidth: Int, canvasHeight: Int,
        templateName: String, angle: String = "unknown"
    ): Int {
        return try {
            val root = com.google.gson.JsonParser.parseString(jsonText).asJsonObject
            val peopleArr = root.getAsJsonArray("people") ?: return 0
            val people = mutableListOf<MutableList<PoseKeypoint>>()
            for (personEl in peopleArr) {
                val kp2d = personEl.asJsonObject.getAsJsonArray("pose_keypoints_2d") ?: continue
                if (kp2d.size() != 18 * 3) {
                    // KHÔNG đoán map BODY_25 hay định dạng khác — từ chối rõ
                    // ràng, an toàn hơn suy diễn sai (mục 34 nguyên tắc "không
                    // đề xuất giải pháp chưa kiểm chứng").
                    return 0
                }
                val keypoints = MutableList(18) { i ->
                    val x = kp2d[i * 3].asFloat / canvasWidth
                    val y = kp2d[i * 3 + 1].asFloat / canvasHeight
                    val conf = kp2d[i * 3 + 2].asFloat
                    PoseKeypoint(x, y, 0f, visible = conf > 0.1f, confidence = conf)
                }
                people.add(keypoints)
            }
            if (people.isEmpty()) return 0
            savePoseVariant(templateName, PoseVariant(
                angle = angle, people = people,
                needsReview = true, // LUÔN đánh dấu cần kiểm tra — nguồn ngoài
                                     // chưa qua 3 cơ chế validate của chính app
                                     // (mục 19), user nên tự xem lại trước khi tin dùng.
                reviewReasons = listOf("Import từ nguồn ngoài — chưa qua kiểm tra tự động của app, nên tự xem lại trong PoseEditorScreen trước khi dùng")
            ))
            people.size
        } catch (ex: Exception) {
            0
        }
    }

    data class ManifestModelFiles(
        val tokenizer: String = "tokenizer.json",
        val clip: String = "clip.mnn",
        val unet: String = "unet.mnn",
        val vae_decoder: String = "vae_decoder.mnn",
        val vae_encoder: String? = "vae_encoder.mnn",
        val pos_emb: String = "pos_emb.bin",
        val token_emb: String = "token_emb.bin",
    )
    data class ManifestModelEntry(
        val id: String,
        val display_name: String,
        val pipeline: String = "sd15_cpu",
        val dir: String,
        val files: ManifestModelFiles = ManifestModelFiles(),
        val use_v_pred: Boolean = false,
        // mục 64 TECHNICAL_STATUS.md — model này BẮT BUỘC NPU thật (không
        // fallback GPU/CPU âm thầm), xem chú thích đầy đủ trong
        // assets/model_manifest.json._npu_required_mau. SettingsScreen.kt
        // dùng field này để khoá công tắc NPU (không cho tắt) khi model
        // đang chọn yêu cầu NPU bắt buộc.
        val npu_required: Boolean = false,
        // mục 96 TECHNICAL_STATUS.md — ĐÃ CÓ trong model_manifest.json từ
        // mục 59 nhưng KHÔNG CÓ code Kotlin nào đọc (grep xác nhận trước
        // khi sửa) — SDXL cần ~1024, SD1.5 512, UI chip cố định cũ (mục 25)
        // không biết phân biệt. null = model cũ chưa khai báo, UI tự rơi
        // về chip cố định như trước (không đổi hành vi cho model đã có).
        val default_width: Int? = null,
        val default_height: Int? = null,
    )
    data class ManifestRoot(val models: MutableList<ManifestModelEntry> = mutableListOf())

    /** Copy assets/model_manifest.json (mẫu ban đầu) ra rootDir nếu chưa có, để có bản ghi được. */
    fun ensureManifestInitialized(context: Context) {
        if (initError != null) return  // đã biết không ghi được, khỏi thử nữa (xem init{} ở trên)
        if (manifestFile.exists()) return
        try {
            context.assets.open("model_manifest.json").use { input ->
                manifestFile.outputStream().use { output -> input.copyTo(output) }
            }
        } catch (e: Exception) {
            // Không có mẫu trong assets (không nên xảy ra) -> tạo manifest rỗng.
            // Bọc thêm try/catch ở đây: nếu nguyên nhân thật là quyền ghi bị
            // chặn (chứ không phải thiếu file mẫu), lần ghi thứ 2 này cũng
            // sẽ lỗi y hệt — trước đây không bọc nên ném tiếp ra ngoài,
            // không ai bắt, crash cả app.
            try {
                manifestFile.writeText(manifestGson.toJson(ManifestRoot()))
            } catch (e2: Exception) {
                // Đành chịu, để rỗng — các hàm đọc (loadManifest) đã tự
                // fallback về ManifestRoot() rỗng khi đọc lỗi.
            }
        }
    }

    private fun loadManifest(): ManifestRoot = try {
        manifestGson.fromJson(manifestFile.readText(), ManifestRoot::class.java) ?: ManifestRoot()
    } catch (e: Exception) { ManifestRoot() }

    private fun saveManifest(m: ManifestRoot) {
        manifestFile.writeText(manifestGson.toJson(m))
    }

    /** Thêm/ghi đè 1 entry model vào manifest động — gọi sau khi sdConvertModel() thành công. */
    fun registerConvertedModel(id: String, displayName: String, modelDirName: String, useVPred: Boolean = false, hasVaeEncoder: Boolean = true) {
        val m = loadManifest()
        m.models.removeAll { it.id == id }
        m.models.add(ManifestModelEntry(
            id = id, display_name = displayName, dir = modelDirName,
            files = ManifestModelFiles(vae_encoder = if (hasVaeEncoder) "vae_encoder.mnn" else null),
            use_v_pred = useVPred
        ))
        saveManifest(m)
    }

    fun hasConvertedModel(id: String): Boolean = loadManifest().models.any { it.id == id }
    fun listConvertedModels(): List<ManifestModelEntry> = loadManifest().models

    // ── Model ghép cặp (nhiều nhân vật CÙNG dùng LoRA trong 1 checkpoint) ──
    // KHÔNG cần sửa gì native — sdConvertModel()/convertAndRegisterModel()
    // vốn đã nhận List<String> loraFiles + List<Float> loraWeights (thiết
    // kế ban đầu có lẽ để merge "LoRA nhân vật + LoRA chất lượng chung",
    // nhưng không có gì ngăn merge N LoRA NHÂN VẬT khác nhau vào cùng 1
    // checkpoint). id ghép = tên nhân vật đã sort + nối "+", ổn định bất kể
    // thứ tự truyền vào.
    //
    // GIỚI HẠN CẦN BIẾT (không phải bug, là đặc tính kỹ thuật thật của LoRA
    // merge, cộng đồng SD ghi nhận rộng rãi): merge nhiều LoRA nhân vật vào
    // 1 checkpoint có thể gây "rò rỉ đặc điểm" giữa 2 người (màu tóc/kiểu
    // mặt lẫn nhau), nhất là nếu 2 LoRA train ở cường độ cao hoặc concept
    // gần nhau. Dùng token kích hoạt (trigger word) riêng biệt cho mỗi
    // nhân vật trong anchorPrompt giúp giảm nhưng KHÔNG đảm bảo tách bạch
    // hoàn toàn như sinh 2 lượt riêng — CHƯA có cách nào kiểm chứng chất
    // lượng thật ngoài build-test trên máy thật.
    fun pairModelId(characterIds: Collection<String>): String =
        characterIds.distinct().sorted().joinToString("+")

    fun hasConvertedPairModel(characterIds: Collection<String>): Boolean =
        characterIds.size >= 2 && hasConvertedModel(pairModelId(characterIds))

    /**
     * Merge LoRA của NHIỀU nhân vật (>=2) vào 1 checkpoint dùng chung cho
     * cảnh có cả nhóm xuất hiện — mỗi nhân vật PHẢI đã có `loraPath` (file
     * .safetensors LoRA riêng, train trước trên PC), nếu thiếu 1 người ->
     * trả false ngay, không merge một phần.
     */
    /**
     * Merge LoRA của NHIỀU nhân vật (>=2) vào 1 checkpoint dùng chung cho
     * cảnh có cả nhóm xuất hiện — mỗi nhân vật PHẢI đã có `loraPath` (file
     * .safetensors LoRA riêng, train trước trên PC), nếu thiếu 1 người ->
     * trả false ngay, không merge một phần.
     *
     * SỬA LỖI (tự phát hiện lúc đọc kỹ sd_model_converter.cpp): hàm native
     * `sdConvertModel` cần checkpointFile/loraFiles là TÊN FILE nằm NGAY
     * TRONG modelDir (tự nối dir+"/"+tên) — bản đầu viết hàm này TRUYỀN
     * THẲNG path tuyệt đối của loraPath, SẼ LUÔN FAIL. Giờ tự copy checkpoint
     * + từng file LoRA + 3 file "khung" (unet.mnn/vae_decoder.mnn/
     * vae_encoder.mnn, lấy từ baseModelId đã convert sẵn) vào modelDir
     * trước, dùng TÊN TƯƠNG ĐỐI khi gọi convert — giống hệt cách đã sửa cho
     * convert 1 nhân vật (MainViewModel.convertCharacterLora).
     *
     * Chạy trên luồng nền (IO) — người gọi PHẢI tự wrap Dispatchers.IO,
     * hàm này không tự làm (StoryManager không có coroutine scope riêng).
     */
    fun convertAndRegisterPairModel(
        baseModelId: String, checkpointFile: String, characters: List<Character>,
        loraWeights: List<Float>? = null, clipSkip2: Boolean = false,
        // mục 55 TECHNICAL_STATUS.md — mặc định TRUE riêng cho hàm này
        // (khác convertAndRegisterModel() bên dưới mặc định false): đây
        // ĐÚNG LÀ tình huống "nhiều LoRA (nhiều nhân vật) merge vào 1
        // checkpoint" mà Gram-Schmidt trực giao hoá nhắm tới — user vẫn
        // tắt được nếu muốn giữ hành vi cũ (vd đang debug, muốn so sánh).
        orthogonalStacking: Boolean = true
    ): Boolean {
        if (characters.size < 2) return false
        // mục 71 TECHNICAL_STATUS.md — SỬA BUG THẬT (item #8 còn treo mục
        // 70): review cảnh báo Gram-Schmidt phụ thuộc thứ tự nhân vật —
        // đúng, nhưng đối chiếu code xác nhận CÒN NẶNG HƠN cảnh báo: hàm
        // này TRƯỚC ĐÂY dùng NGUYÊN thứ tự `characters` do caller truyền
        // vào để merge LoRA thật (native), TRONG KHI `pairModelId()` ở
        // trên lại SORT trước khi ghép chuỗi ID. Hệ quả: gọi hàm này 2 lần
        // với ĐÚNG 2 người đó nhưng thứ tự khác nhau (vd UI cho chọn theo
        // thứ tự bấm) sẽ merge RA 2 KẾT QUẢ KHÁC NHAU nhưng GHI ĐÈ lên
        // đúng 1 model id — panel đã sinh trước đó từ lần merge đầu sẽ
        // ngầm định "thuộc về" 1 checkpoint đã bị thay weight khác, không
        // ai biết. SỬA TẬN GỐC bằng cách SORT `characters` NGAY ĐẦU HÀM
        // theo đúng tiêu chí `pairModelId()` dùng (id, không phải tên) —
        // đảm bảo thứ tự merge LUÔN xác định (deterministic) theo ĐÚNG bộ
        // nhân vật, bất kể caller truyền vào theo thứ tự nào.
        // mục 71 — ghép cặp (character, weight) THEO ĐÚNG THỨ TỰ GỐC caller
        // truyền vào TRƯỚC khi sort — nếu sort riêng `characters` mà không
        // ghép cặp trước, `loraWeights` truyền tay (khớp vị trí THEO THỨ TỰ
        // GỐC) sẽ bị lệch khỏi đúng người của nó sau khi characters đổi thứ
        // tự. `characters.map { it.loraWeight }` (giá trị mặc định) không bị
        // ảnh hưởng (thuộc tính CỦA từng Character, không phải vị trí) —
        // nhưng vẫn ghép cặp chung 1 cách cho cả 2 trường hợp cho nhất quán.
        val originalWeights = loraWeights ?: characters.map { it.loraWeight }
        val sortedPairs = characters.zip(originalWeights).sortedBy { it.first.id }
        val characters = sortedPairs.map { it.first }
        val weights = sortedPairs.map { it.second }
        val id = pairModelId(characters.map { it.id })
        val sourceLoraPaths = characters.map { it.loraPath ?: return false }
        val displayName = characters.joinToString(" + ") { it.name }

        val dir = File(modelsDir, id).also { it.mkdirs() }
        val baseDir = File(modelsDir, baseModelId)
        val templates = listOf("unet.mnn", "vae_decoder.mnn", "vae_encoder.mnn")
        val missingTemplate = templates.firstOrNull { !File(baseDir, it).exists() }
        if (missingTemplate != null) return false // model gốc chưa convert xong, không có khung để copy
        templates.forEach { File(baseDir, it).copyTo(File(dir, it), overwrite = true) }

        val checkpointName = File(checkpointFile).name
        File(checkpointFile).copyTo(File(dir, checkpointName), overwrite = true)
        // Tên file LoRA của 2 nhân vật khác nhau CÓ THỂ trùng nhau (2 người
        // dùng file cùng tên từ nguồn khác nhau) -> đổi tên theo characterId
        // để không đè lên nhau khi copy vào cùng 1 thư mục.
        val loraNames = characters.mapIndexed { i, c ->
            val destName = "lora_${c.id}.safetensors"
            File(sourceLoraPaths[i]).copyTo(File(dir, destName), overwrite = true)
            destName
        }

        return convertAndRegisterModel(
            modelDirName = id, checkpointFile = checkpointName, characterId = id,
            displayName = displayName, loraFiles = loraNames, loraWeights = weights,
            clipSkip2 = clipSkip2, orthogonalStacking = orthogonalStacking
        )
    }

    /**
     * Convert 1 checkpoint (+ tuỳ chọn LoRA) thành model dùng được, rồi tự
     * đăng ký vào manifest. Chạy trên luồng nền (IO), có thể mất vài phút.
     *
     * ĐIỀU KIỆN: modelDir đã phải có sẵn unet.mnn/vae_decoder.mnn/
     * vae_encoder.mnn "khung" (xem sd_model_converter.cpp) + file
     * checkpointFile (.safetensors) + các file loraFiles (.safetensors)
     * nằm CÙNG thư mục modelDir.
     */
    fun convertAndRegisterModel(
        modelDirName: String, checkpointFile: String, characterId: String,
        displayName: String, loraFiles: List<String> = emptyList(),
        loraWeights: List<Float> = emptyList(), clipSkip2: Boolean = false,
        orthogonalStacking: Boolean = false  // mục 55 — mặc định false (chỉ đổi ở nơi gọi có ý nghĩa: convertAndRegisterPairModel)
    ): Boolean {
        val dir = File(modelsDir, modelDirName)
        // mục 69 TECHNICAL_STATUS.md — gộp TỰ ĐỘNG mọi Addon LoRA đang
        // enabled vào MỌI lần convert (character lẫn pair) — ĐIỂM DUY NHẤT
        // mọi call site đi qua, tránh phải sửa từng nơi gọi rồi lệch nhau.
        // Copy addon file vào ĐÚNG dir đang convert (tên đổi tiền tố
        // "addon_" để không đụng tên với lora_<characterId> ở trên).
        val addons = listAddonLoras().filter { it.enabled }
        val addonLoraNames = addons.map { a ->
            val src = File(addonsDir, a.fileName)
            val destName = "addon_${a.id}.safetensors"
            if (src.exists()) src.copyTo(File(dir, destName), overwrite = true)
            destName
        }
        val allLoraFiles = loraFiles + addonLoraNames
        val allLoraWeights = loraWeights + addons.map { it.weight }
        val ok = NativeBridge.sdConvertModel(
            dir.absolutePath, checkpointFile, clipSkip2,
            allLoraFiles.toTypedArray(), allLoraWeights.toFloatArray(), orthogonalStacking
        )
        if (ok) registerConvertedModel(id = characterId, displayName = displayName, modelDirName = modelDirName)
        return ok
    }

    // ── LoRA Addon (mục 69 TECHNICAL_STATUS.md — chất lượng chung, áp dụng
    // TOÀN CỤC, xem chú thích đầy đủ ở Models.kt.AddonLora) ────────────────
    val addonsDir: File by lazy { File(lorasDir, "addons").apply { mkdirs() } }
    private val addonLorasFile: File by lazy { File(lorasDir, "addon_loras.json") }

    fun listAddonLoras(): List<AddonLora> = try {
        if (!addonLorasFile.exists()) emptyList()
        else gson.fromJson(addonLorasFile.readText(),
            object : TypeToken<List<AddonLora>>() {}.type) ?: emptyList()
    } catch (e: Exception) { emptyList() }

    private fun saveAddonLoras(list: List<AddonLora>) {
        addonLorasFile.writeText(gson.toJson(list))
    }

    /** Copy file LoRA (đã chọn qua SAF picker) vào addonsDir, tạo entry mới. */
    fun addAddonLora(context: Context, uri: Uri, displayName: String, weight: Float = 0.7f): AddonLora? {
        val name = queryDisplayName(context, uri) ?: return null
        val id = "addon_${System.currentTimeMillis()}"
        val destName = "${id}_$name"
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                File(addonsDir, destName).outputStream().use { output -> input.copyTo(output) }
            }
        } catch (e: Exception) { return null }
        val entry = AddonLora(id = id, displayName = displayName.ifBlank { name }, fileName = destName, weight = weight)
        saveAddonLoras(listAddonLoras() + entry)
        return entry
    }

    fun removeAddonLora(id: String) {
        val entry = listAddonLoras().find { it.id == id } ?: return
        File(addonsDir, entry.fileName).delete()
        saveAddonLoras(listAddonLoras().filter { it.id != id })
    }

    fun setAddonLoraEnabled(id: String, enabled: Boolean) {
        saveAddonLoras(listAddonLoras().map { if (it.id == id) it.copy(enabled = enabled) else it })
    }

    fun setAddonLoraWeight(id: String, weight: Float) {
        saveAddonLoras(listAddonLoras().map { if (it.id == id) it.copy(weight = weight) else it })
    }

    private val gson = Gson()

    // ── Story CRUD ────────────────────────────────────────────────────────

    fun saveStory(story: Story) {
        val dir = storyDir(story.id).also { it.mkdirs() }
        File(dir, "story.json").writeText(gson.toJson(story))
        // mục 72 TECHNICAL_STATUS.md — item #3 (1 phần) của roadmap mục 70:
        // chặn Android MediaScanner quét ảnh sinh ra hàng loạt (gây lag khi
        // sinh nhiều panel liên tục — MediaScanner tự tạo thumbnail cho MỌI
        // ảnh mới phát hiện). File .nomedia RỖNG là đủ, Android tự nhận diện
        // theo TÊN file, không cần nội dung gì. Đặt ở gốc thư mục truyện —
        // áp dụng cho MỌI thư mục con (chapter/output/...) theo quy tắc
        // MediaScanner (chặn đệ quy xuống hết thư mục con). Idempotent — an
        // toàn gọi lại nhiều lần (writeText ghi đè rỗng lên rỗng, vô hại).
        val nomedia = File(dir, ".nomedia")
        if (!nomedia.exists()) try { nomedia.writeText("") } catch (e: Exception) { /* không chặn luồng chính nếu lỗi ghi file phụ này */ }
    }

    fun loadStory(storyId: String): Story? = try {
        val f = File(storyDir(storyId), "story.json")
        if (f.exists()) gson.fromJson(f.readText(), Story::class.java) else null
    } catch (e: Exception) { null }

    fun loadAllStories(): List<Story> = storiesDir.listFiles()
        ?.filter { it.isDirectory }
        ?.mapNotNull { loadStory(it.name) }
        ?.sortedByDescending { it.updatedAt }
        ?: emptyList()

    fun deleteStory(storyId: String) {
        storyDir(storyId).deleteRecursively()
    }

    // ── Character management ──────────────────────────────────────────────

    fun saveCharacter(storyId: String, character: Character) {
        val story = loadStory(storyId) ?: return
        val updated = story.copy(
            characters = story.characters.filter { it.id != character.id } + character,
            updatedAt = System.currentTimeMillis()
        )
        saveStory(updated)
    }

    fun deleteCharacter(storyId: String, characterId: String) {
        val story = loadStory(storyId) ?: return
        val char = story.characters.find { it.id == characterId }

        // Xóa anchor file (ảnh gốc) nếu có — không còn embedding riêng để xoá.
        char?.anchorImagePath?.let { File(it).delete() }

        saveStory(story.copy(
            characters = story.characters.filter { it.id != characterId },
            updatedAt = System.currentTimeMillis()
        ))
    }

    // Lưu ảnh gốc của nhân vật (dùng làm reference cho IP-Adapter thật —
    // KHÔNG còn "embedding giả" như bản cũ, chỉ cần lưu đúng đường dẫn
    // ảnh PNG gốc, IP-Adapter tự encode lại từ ảnh mỗi lần dùng).
    fun saveCharacterAnchor(storyId: String, characterId: String, imagePath: String) {
        val story = loadStory(storyId) ?: return
        val char = story.characters.find { it.id == characterId } ?: return
        saveCharacter(storyId, char.copy(anchorImagePath = imagePath))
    }

    // mục 95 TECHNICAL_STATUS.md — lưu kết quả generateTornReferenceImage().
    fun saveCharacterTornAnchor(storyId: String, characterId: String, imagePath: String) {
        val story = loadStory(storyId) ?: return
        val char = story.characters.find { it.id == characterId } ?: return
        saveCharacter(storyId, char.copy(tornAnchorImagePath = imagePath))
    }

    // Lấy ảnh anchor thật của nhân vật theo tên (dùng trực tiếp làm
    // referenceImagePath cho sdTxt2ImgWithReferenceAndPose).
    // mục 95 TECHNICAL_STATUS.md — preferTorn mặc định false (hành vi cũ
    // 100%). true + có tornAnchorImagePath hợp lệ -> ưu tiên ảnh đó thay vì
    // anchorImagePath thường, cho panel cần nhân vật ở trạng thái vừa vật
    // lộn/chiến đấu (xem SeedRegistry.resolveActionCategory() == "combat"
    // ở call site MangaPipeline.kt).
    fun getCharacterAnchor(storyId: String, name: String, preferTorn: Boolean = false): String? {
        val story = loadStory(storyId) ?: return null
        val char = story.characters.find { it.name.equals(name, ignoreCase = true) } ?: return null
        if (preferTorn) {
            char.tornAnchorImagePath?.takeIf { File(it).exists() }?.let { return it }
        }
        return char.anchorImagePath?.takeIf { File(it).exists() }
    }

    // Tự động phân loại nhân vật mới từ LLM output
    fun autoClassifyCharacter(name: String, appearances: Int, totalPanels: Int): CharacterRole {
        val ratio = appearances.toFloat() / totalPanels
        return when {
            ratio >= 0.5f -> CharacterRole.MAIN        // xuất hiện > 50% panel
            ratio >= 0.15f -> CharacterRole.SUPPORTING // xuất hiện 15-50%
            else -> CharacterRole.ONETIME              // xuất hiện < 15%
        }
    }

    // Phát hiện THẬT xung đột IP-Adapter (mục 12 TECHNICAL_STATUS.md) — đếm
    // trực tiếp bằng Kotlin, KHÔNG dựa vào việc LLM có tuân theo gợi ý "tránh
    // ghép 2 người" trong scenePrompt() hay không (soft hint, không đảm bảo).
    // Trả về map index panel -> danh sách tên nhân vật xung đột trong panel đó.
    // Panel được coi là ổn (không trả về) nếu:
    //  - có < 2 nhân vật dùng IP-Adapter (anchorImagePath != null), HOẶC
    //  - đã có model ghép cặp cho ĐÚNG nhóm LoRA của các nhân vật đó (xem
    //    hasConvertedPairModel — trường hợp này không dùng IP-Adapter nữa
    //    mà bake cả nhóm vào 1 checkpoint, nên không tính là xung đột).
    fun detectIpAdapterConflicts(story: Story, panelCharacterLists: List<List<String>>): Map<Int, List<String>> {
        val chars = story.characters
        val conflicts = mutableMapOf<Int, List<String>>()
        panelCharacterLists.forEachIndexed { index, names ->
            val involved = names.mapNotNull { n -> chars.find { it.name.equals(n, ignoreCase = true) } }
            val ipaOnly = involved.filter { it.anchorImagePath != null }
            if (ipaOnly.size >= 2) {
                val loraGroupIds = involved.filter { it.loraPath != null }.map { it.id }
                val coveredByPair = loraGroupIds.size == involved.size && hasConvertedPairModel(loraGroupIds)
                if (!coveredByPair) conflicts[index] = ipaOnly.map { it.name }
            }
        }
        return conflicts
    }

    // ── Chapter management ────────────────────────────────────────────────

    fun saveChapter(chapter: Chapter) {
        val dir = chapterDir(chapter.storyId, chapter.id).also { it.mkdirs() }
        File(dir, "chapter.json").writeText(gson.toJson(chapter))

        // Update story chapterIds
        val story = loadStory(chapter.storyId) ?: return
        if (chapter.id !in story.chapterIds) {
            saveStory(story.copy(
                chapterIds = story.chapterIds + chapter.id,
                updatedAt = System.currentTimeMillis()
            ))
        }
    }

    fun loadChapter(storyId: String, chapterId: String): Chapter? = try {
        val f = File(chapterDir(storyId, chapterId), "chapter.json")
        if (f.exists()) gson.fromJson(f.readText(), Chapter::class.java) else null
    } catch (e: Exception) { null }

    fun loadAllChapters(storyId: String): List<Chapter> {
        val story = loadStory(storyId) ?: return emptyList()
        return story.chapterIds.mapNotNull { loadChapter(storyId, it) }
            .sortedBy { it.chapterNumber }
    }

    // mục 68 TECHNICAL_STATUS.md — Xuất dataset (ảnh panel + caption chuẩn)
    // để train LoRA trên máy tính (mục 9 lịch sử — trước đây CHƯA CÓ GÌ,
    // kể cả tầng dữ liệu, xác nhận qua grep ở mục 66/67). Gom TẤT CẢ panel
    // đã DUYỆT (khác PENDING/REJECTED — REJECTED cố tình loại vì user đã
    // đánh dấu ảnh lỗi, không nên lẫn vào dataset train) trong TOÀN BỘ
    // chapter của truyện, lọc theo characterName nếu có -> cặp file
    // image_%04d.png + image_%04d.txt/panel — caption = ĐÚNG prompt THẬT
    // đã dùng lúc sinh panel đó (panel.prompt hoặc promptOverride nếu có,
    // KHÔNG suy diễn/viết lại), theo đúng chuẩn "ảnh.png + ảnh.txt cùng
    // tên" mà đa số tool train LoRA (kohya_ss, sd-scripts...) đọc được
    // trực tiếp. Nén thành 1 file .zip duy nhất dưới rootDir/
    // dataset_exports/ — nằm sẵn trong phạm vi FileProvider "outputs" của
    // file_paths.xml (path="/" = toàn bộ external-files-dir), share được
    // ngay qua Intent.ACTION_SEND từ UI, không cần khai báo path riêng.
    // characterName = null -> xuất TOÀN BỘ panel của truyện, không lọc.
    // Trả null nếu không có panel nào khớp điều kiện (không tạo file rỗng).
    fun exportDataset(storyId: String, characterName: String? = null): File? {
        val story = loadStory(storyId) ?: return null
        val panels = loadAllChapters(storyId).flatMap { it.panels }.filter { p ->
            p.status != PanelStatus.PENDING && p.status != PanelStatus.REJECTED &&
            p.status != PanelStatus.GENERATING && p.status != PanelStatus.FAILED &&
            (p.imagePath != null || p.upscaledPath != null) &&
            (characterName == null || p.scene.characters.contains(characterName))
        }
        if (panels.isEmpty()) return null

        fun sanitize(s: String) = s.replace(Regex("[^A-Za-z0-9_\\-]"), "_").take(30)
        val ts = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
        val exportDir = File(rootDir, "dataset_exports").apply { mkdirs() }
        val zipFile = File(exportDir, "${sanitize(story.title)}_${sanitize(characterName ?: "all")}_$ts.zip")

        java.util.zip.ZipOutputStream(zipFile.outputStream()).use { zos ->
            panels.forEachIndexed { i, p ->
                val srcFile = (p.upscaledPath ?: p.imagePath)?.let { File(it) } ?: return@forEachIndexed
                if (!srcFile.exists()) return@forEachIndexed
                val baseName = "image_%04d".format(i + 1)
                zos.putNextEntry(java.util.zip.ZipEntry("$baseName.png"))
                srcFile.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
                // caption = ĐÚNG prompt thật đã dùng để sinh (không phải
                // scene.description gốc tiếng Việt — đó là mô tả cảnh cho
                // LLM, khác prompt tag SD1.5 thật đưa vào model).
                val caption = p.overrideSettings?.promptOverride ?: p.prompt
                zos.putNextEntry(java.util.zip.ZipEntry("$baseName.txt"))
                zos.write(caption.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
        }
        return if (zipFile.exists() && zipFile.length() > 0) zipFile else null
    }

    // ── Directories ───────────────────────────────────────────────────────

    fun storyDir(storyId: String) = File(storiesDir, storyId)
    fun chapterDir(storyId: String, chapterId: String) = File(storyDir(storyId), "chapters/$chapterId")
    fun anchorsDir(storyId: String) = File(storyDir(storyId), "anchors").also { it.mkdirs() }

    // ── Textual Inversion (mục 12 TECHNICAL_STATUS.md — phương pháp thứ 3
    // để nhất quán nhân vật, NGOÀI LoRA/IP-Adapter, hoạt động thuần ở tầng
    // text-encoder, KHÔNG đụng UNet -> nhiều nhân vật TI khác nhau dùng
    // CHUNG 1 prompt/panel được, không bị giới hạn "1 slot" như IP-Adapter.
    // Yếu hơn LoRA/IP-Adapter về độ giống mặt (cộng đồng SD ghi nhận, CHƯA
    // tự kiểm chứng trên pipeline này), nhưng giải quyết đúng bài toán
    // nhiều-nhân-vật-1-khung mà 2 phương pháp kia không làm được. ──
    fun embeddingsDir(storyId: String) = File(storyDir(storyId), "embeddings").also { it.mkdirs() }

    // Trigger word = tên nhân vật đã sanitize (chữ thường, chỉ a-z0-9_) vì
    // PromptProcessor.hpp khớp theo TÊN FILE (không cần cú pháp <...>).
    // CẢNH BÁO cần ghi rõ cho user: nếu tên nhân vật trùng 1 từ tiếng Anh
    // thông dụng (vd nhân vật tên "Hero"), từ đó trong MỌI prompt (kể cả
    // không cố ý nói về nhân vật) sẽ bị thay bằng embedding — nên đặt tên
    // nhân vật tránh trùng từ thường dùng trong prompt, hoặc chấp nhận rủi ro.
    private fun sanitizeTriggerWord(name: String): String =
        name.lowercase().replace(Regex("[^a-z0-9_]"), "").ifBlank { "char" }

    /**
     * Copy 1 file .safetensors Textual Inversion (train sẵn trên PC, hoặc
     * lấy từ cộng đồng — CÙNG ĐỊNH DẠNG chuẩn AUTOMATIC1111/kohya_ss, không
     * cần convert riêng) vào embeddingsDir của truyện, đặt tên = trigger
     * word, rồi lưu vào Character. Trả về trigger word đã dùng, null nếu lỗi.
     */
    fun setCharacterEmbedding(storyId: String, characterId: String, sourceSafetensorsPath: String): String? {
        val story = loadStory(storyId) ?: return null
        val char = story.characters.find { it.id == characterId } ?: return null
        val src = File(sourceSafetensorsPath)
        if (!src.exists()) return null
        var trigger = sanitizeTriggerWord(char.name)
        val dir = embeddingsDir(storyId)
        // Né trùng tên với nhân vật KHÁC đã có trigger giống hệt (vd 2 nhân
        // vật cùng tên hiển thị khác nhau nhưng sanitize ra giống nhau).
        val collision = story.characters.any { it.id != characterId && it.embeddingTrigger == trigger }
        if (collision) trigger = "${trigger}_${characterId.takeLast(4)}"
        val dest = File(dir, "$trigger.safetensors")
        src.copyTo(dest, overwrite = true)
        saveCharacter(storyId, char.copy(embeddingPath = dest.absolutePath, embeddingTrigger = trigger))
        return trigger
    }
    fun outputDir(storyId: String, chapterId: String) = File(chapterDir(storyId, chapterId), "output").also {
        it.mkdirs()
        // mục 72 — phòng hờ outputDir() được gọi trước khi saveStory() lần
        // nào (không nên xảy ra theo luồng bình thường, nhưng đây là nơi
        // ĐỔ FILE THẬT SỰ NHIỀU nên phòng hờ thêm không thừa).
        val nomedia = File(it, ".nomedia")
        if (!nomedia.exists()) try { nomedia.writeText("") } catch (e: Exception) { }
    }

    // ── Nhập model từ UI (SAF picker) ────────────────────────────────────────
    // Do bộ nhớ app giờ nằm ở Android/data/com.mangalocal/files/MangaLocal
    // (không cần quyền, nhưng khó vào bằng trình quản lý file ngoài trên
    // Android 11+ — xem StoryManager init{}), user cần cách NHẬP file model
    // từ NGAY TRONG APP thay vì tự copy tay qua file manager. Dùng SAF
    // picker (OpenMultipleDocuments/OpenDocumentTree ở SettingsScreen.kt) —
    // app có quyền đọc file/thư mục do CHÍNH USER chọn, bất kể nằm ở đâu
    // (Download, Google Drive, thẻ nhớ...), không phụ thuộc scoped storage.

    /** Copy 1+ file (đã chọn qua OpenMultipleDocuments) vào destDir, giữ nguyên tên gốc. Trả về danh sách tên đã nhập. */
    fun importFiles(context: Context, uris: List<Uri>, destDir: File): List<String> {
        destDir.mkdirs()
        val imported = mutableListOf<String>()
        uris.forEach { uri ->
            val name = queryDisplayName(context, uri) ?: "file_${System.currentTimeMillis()}"
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    File(destDir, name).outputStream().use { output -> input.copyTo(output) }
                }
                imported += name
            } catch (_: Exception) { /* file lỗi thì bỏ qua, tiếp tục các file còn lại */ }
        }
        return imported
    }

    /** Copy TOÀN BỘ file (không đệ quy) trong 1 thư mục đã chọn (OpenDocumentTree) vào models/<modelId>/ — dùng cho model SD nhiều file (clip/unet/vae...). Trả về số file đã copy. */
    fun importSdModelFolder(context: Context, treeUri: Uri, modelId: String): Int {
        val safeId = modelId.ifBlank { "model_${System.currentTimeMillis()}" }
        val destDir = File(modelsDir, safeId).also { it.mkdirs() }
        val tree = DocumentFile.fromTreeUri(context, treeUri) ?: return 0
        var count = 0
        tree.listFiles().forEach { doc ->
            val name = doc.name
            if (doc.isFile && name != null) {
                try {
                    context.contentResolver.openInputStream(doc.uri)?.use { input ->
                        File(destDir, name).outputStream().use { output -> input.copyTo(output) }
                    }
                    count++
                } catch (_: Exception) { /* file lỗi thì bỏ qua, tiếp tục các file còn lại */ }
            }
        }
        return count
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        } catch (_: Exception) { null }
    }

    // ── Model scanning ────────────────────────────────────────────────────

    fun scanSdModels() = modelsDir.listFiles()
        ?.filter { it.extension in listOf("safetensors", "ckpt") }
        ?.map { ModelInfo(it.absolutePath, it.nameWithoutExtension, ModelType.SD15, it.length()) }
        ?.sortedBy { it.name } ?: emptyList()

    // mục 116 TECHNICAL_STATUS.md — SỬA LẠI TOÀN BỘ, đúng bài học
    // LocalNovel_Architecture_Spec.md mục 5.33/5.35/5.52: MNN-LLM (chính
    // engine MangaLocal đang dùng — xem jni_bridge.cpp) KHÔNG đọc file
    // .gguf trực tiếp. .gguf là định dạng CỦA llama.cpp; MNN-LLM cần 1
    // THƯ MỤC đã convert qua llmexport.py CHÍNH THỨC của MNN, chứa
    // config.json (+ weight .mnn riêng). Trước bản vá này, hàm quét đúng
    // đuôi .gguf — khớp với setupGuide() cũ (cũng bảo tải .gguf trực
    // tiếp) nhưng KHÔNG khớp với những gì native code thực sự cần — LLM
    // gần như chắc chắn không load được nếu build/test thật (đúng loại
    // lỗi "tài liệu và code đồng bộ với nhau nhưng cả 2 cùng sai so với
    // yêu cầu thật của thư viện ngoài" mà LocalNovel tốn nhiều vòng debug
    // mới phát hiện ra — ở đây phát hiện được TRƯỚC khi build nhờ đối
    // chiếu tài liệu bài học của dự án song song, không cần tự trải qua
    // lại đúng chuỗi lỗi đó).
    // Quét THƯ MỤC con của modelsDir có chứa config.json (đúng điểm vào
    // thật theo tài liệu chính thức MNN, xem comment llamaInit() trong
    // jni_bridge.cpp) — path trả về là ĐƯỜNG DẪN THƯ MỤC, không phải file.
    fun scanLlmModels() = modelsDir.listFiles()
        ?.filter { it.isDirectory && (File(it, "config.json").exists() || File(it, "llm_config.json").exists()) }
        ?.map { ModelInfo(it.absolutePath, it.name, ModelType.LLM,
            it.listFiles()?.sumOf { f -> f.length() } ?: 0L) }
        ?.sortedBy { it.name } ?: emptyList()

    fun scanLoras() = lorasDir.listFiles()
        ?.filter { it.extension == "safetensors" }
        ?.map { ModelInfo(it.absolutePath, it.nameWithoutExtension, ModelType.LORA, it.length()) }
        ?.sortedBy { it.name } ?: emptyList()

    fun scanEmbeddingSources() = embeddingSourcesDir.listFiles()
        ?.filter { it.extension == "safetensors" }
        ?.map { ModelInfo(it.absolutePath, it.nameWithoutExtension, ModelType.LORA, it.length()) }
        ?.sortedBy { it.name } ?: emptyList()

    // Gợi ý phương pháp theo vai trò (mục 13 TECHNICAL_STATUS.md) — CHỈ LÀ
    // GỢI Ý, user luôn có thể chọn khác. Logic: xuất hiện nhiều -> cần độ
    // giống cao nhất (LoRA, nhưng tốn công train nhất); trung bình -> IP-
    // Adapter (chỉ cần 1 ảnh, không cần train); ONETIME (bằng "xuất hiện 1
    // lần" trong hệ thống role hiện tại, gộp chung "ít" và "qua đường" theo
    // đúng 3 tier đang có — xem giải thích trong TECHNICAL_STATUS.md mục
    // 13) -> mặc định NONE (chỉ mô tả chữ), user tự nâng lên Textual
    // Inversion nếu vẫn muốn 1 chút nhận diện mà không tốn công train/tìm ảnh.
    fun suggestConsistencyMethod(role: CharacterRole): ConsistencyMethod = when (role) {
        CharacterRole.MAIN -> ConsistencyMethod.LORA
        CharacterRole.SUPPORTING -> ConsistencyMethod.IP_ADAPTER
        CharacterRole.ONETIME -> ConsistencyMethod.NONE
    }

    // Suy ra method HIỆN TẠI của 1 Character từ các field đã set (không lưu
    // field method riêng để tránh 2 nguồn sự thật lệch nhau — luôn tính từ
    // dữ liệu thật). Ưu tiên LoRA > IP-Adapter > TI > None nếu set nhiều hơn 1.
    fun currentConsistencyMethod(c: Character): ConsistencyMethod = when {
        c.loraPath != null && hasConvertedModel(c.id) -> ConsistencyMethod.LORA
        c.anchorImagePath != null -> ConsistencyMethod.IP_ADAPTER
        c.embeddingTrigger != null -> ConsistencyMethod.TEXTUAL_INVERSION
        else -> ConsistencyMethod.NONE
    }

    // ĐÃ SỬA (mục 26 TECHNICAL_STATUS.md) — các hàm has*() này CÒN NGUYÊN
    // tên file ncnn cũ (.param/.bin) từ TRƯỚC quyết định "MNN thay ncnn"
    // (mục 3), không khớp file .mnn thật engine hiện dùng — phát hiện khi
    // rà lại toàn bộ workflow lần cuối, sửa dứt điểm.
    fun hasEsrgan() = esrganDir.listFiles()?.any { it.name.startsWith("realesrgan_x") && it.extension == "mnn" } ?: false

    fun hasYolo() = File(yoloDir, "yolov8n.mnn").exists() // auto bubble (mục 6, vẫn CHƯA hoàn thiện native — xem TECHNICAL_STATUS.md)

    fun hasYoloPose() = File(yoloDir, "yolov8_pose.mnn").exists() // mục 19 — thay MediaPipe Pose

    fun hasMobileSam() = File(yoloDir, "mobile_sam_encoder.mnn").exists() && File(yoloDir, "mobile_sam_decoder.mnn").exists() // mục 21

    fun hasAugmentedUnet(modelId: String) = File(File(modelsDir, modelId), "unet_ipa_controlnet.mnn").exists() &&
        File(File(modelsDir, modelId), "ip_image_encoder.mnn").exists() // mục 6 — IP-Adapter + ControlNet-Pose

    // mục 67 TECHNICAL_STATUS.md — nối dây sdTxt2ImgWithCharactersAndPose
    // (mục 52b, native/JNI đã có sẵn nhưng CHƯA có nơi nào trong Kotlin gọi
    // tới trước mục này). Kiểm tra ĐÚNG file unet_ipa_mask_controlnet_
    // {N}char.mnn có tồn tại cho model+N cụ thể hay không — mỗi N cần 1
    // file riêng (không dynamic_axes, xem mục 52b), KHÔNG suy đoán.
    fun hasMultiCharMaskUnet(modelId: String, numCharacters: Int) =
        File(File(modelsDir, modelId), "unet_ipa_mask_controlnet_${numCharacters}char.mnn").exists() &&
        File(File(modelsDir, modelId), "ip_image_encoder.mnn").exists()

    // mục 69 TECHNICAL_STATUS.md — cùng pattern hasMultiCharMaskUnet() ở
    // trên, cho Regional Prompting (mục 56). Đúng tên file
    // tools/export_ipa_controlnet_regional_unet.py xuất ra.
    fun hasRegionalUnet(modelId: String, numRegions: Int) =
        File(File(modelsDir, modelId), "unet_regional_controlnet_${numRegions}col.mnn").exists()

    // mục 151 TECHNICAL_STATUS.md — cùng pattern 2 hàm trên, cho
    // Triple-Conditioning combo (mục 143). Đúng tên file
    // tools/export_ipa_controlnet_triple_combo_unet.py xuất ra — CẦN CẢ
    // ip_image_encoder.mnn (dùng chung với hasMultiCharMaskUnet(), model
    // encoder ảnh KHÔNG đổi giữa các pipeline).
    fun hasTripleComboUnet(modelId: String, numRegions: Int) =
        File(File(modelsDir, modelId), "unet_triple_combo_${numRegions}region.mnn").exists() &&
        File(File(modelsDir, modelId), "ip_image_encoder.mnn").exists()

    fun modelStatus() = mapOf(
        "SD Model (base, đã convert)" to listConvertedModels().isNotEmpty(),
        "LLM Model" to scanLlmModels().isNotEmpty(),
        "ESRGAN (Hires-fix)" to hasEsrgan(),
        "YOLOv8-pose (khung xương, mục 19)" to hasYoloPose(),
        "MobileSAM (mask thủ công, mục 21)" to hasMobileSam(),
        "IP-Adapter+ControlNet-Pose (UNet augmented, mục 6)" to
            listConvertedModels().any { hasAugmentedUnet(it.id) },
        "YOLOv8n (auto bubble — CHƯA hoàn thiện native, xem mục 6)" to hasYolo()
    )

    fun setupGuide() = """
📁 /sdcard/MangaLocal/

Toàn bộ file .mnn dưới đây KHÔNG tự tải được — phải chạy workflow
"Prepare SD1.5 model files" trên GitHub Actions (tab Actions trên trình
duyệt điện thoại cũng chạy được, không cần PC), tải Artifact về, rồi tự
copy vào đúng thư mục qua Files app / Google Drive.

models/<id>/          (mỗi thư mục = 1 model trong model_manifest.json)
  ├── clip.mnn, unet.mnn, vae_decoder.mnn, vae_encoder.mnn, tokenizer.json
  ├── pos_emb.bin, token_emb.bin
  └── (tùy chọn, cho IP-Adapter+ControlNet-Pose — mục 6):
      unet_ipa_controlnet.mnn, ip_image_encoder.mnn

models/                (LLM, MỖI THƯ MỤC RIÊNG trong models/ — mục 116)
  └── <ten-model>/
      ├── config.json         (BẮT BUỘC — đúng điểm vào MNN-LLM đọc trực
      │                        tiếp, KHÔNG PHẢI file .gguf)
      └── *.mnn, tokenizer.txt/json, embeddings_bf16.bin... (weight thật,
                               do llmexport.py sinh ra)

loras/                 (LoRA nhân vật — .safetensors GỐC, convert qua
                         màn hình Nhân vật, mục 14, không tự dùng trực tiếp)
  └── *.safetensors

embeddings_source/      (Textual Inversion GỐC — mục 13)
  └── *.safetensors

yolo/                   (dùng chung cho YOLOv8-pose + MobileSAM + auto bubble)
  ├── yolov8_pose.mnn         (mục 19 — BẮT BUỘC cho ControlNet-Pose + auto-fix mặt/tay)
  ├── mobile_sam_encoder.mnn  (mục 21 — mask thủ công, tùy chọn)
  ├── mobile_sam_decoder.mnn  (mục 21 — mask thủ công, tùy chọn)
  └── yolov8n.mnn             (auto bubble — CHƯA hoàn thiện native, xem mục 6)

esrgan/
  └── realesrgan_x4.mnn       (mục 20 — Hires-fix, tùy chọn nếu không dùng upscale)

Tất cả model .mnn trên đây chuẩn bị qua:
  .github/workflows/prepare_models.yml (chạy trên cloud — KHUYẾN NGHỊ)
Hoặc tự chạy tay từng script trong tools/ (export_sd15_base.py,
export_ipa_controlnet_unet.py, export_yolo_pose.py, export_esrgan.py,
export_mobilesam.py) rồi tự mnnconvert.

LLM: KHÔNG tải .gguf trực tiếp được nữa (mục 116 — MNN-LLM không đọc
GGUF). Cần convert model HuggingFace (vd Qwen2.5-3B-Instruct bản gốc,
KHÔNG phải bản GGUF) sang định dạng MNN qua script `llmexport.py` CHÍNH
THỨC của repo alibaba/MNN (xem transformers/llm/export/README.md) — quy
trình tương tự `prepare_models.yml` đã làm cho SD, đặt tên workflow mới
nếu tự động hoá (CHƯA làm — hiện phải tự chạy tay theo README của MNN).
    """.trimIndent()
}
