package com.mangalocal.pipeline

import com.mangalocal.model.Chapter
import com.mangalocal.model.PageSpec
import com.mangalocal.model.Panel
import java.io.File

/**
 * mục 260 TECHNICAL_STATUS.md — SỬA BỐ CỤC TRANG TRƯỚC KHI XUẤT PDF (hạng mục "UI sửa bố cục trang" ghi CHƯA ở mục 248/256/259).
 *
 * Nguồn ý tưởng (PDF, MangaFlow): bố cục phải là BIẾN TRUNG GIAN TƯỜNG MINH mà người dùng chỉnh được, không phải kết quả ngầm.
 * `PageTemplate.AUTO` (mục 248) đã cho danh sách trang tường minh nhưng chưa chỉnh được — file này là phần LOGIC THUẦN của việc chỉnh;
 * màn hình Compose nằm ở ui/PageLayoutScreen.kt.
 *
 * MÔ HÌNH: bố cục = danh sách trang; mỗi trang = (mẫu, các `Panel.index` theo thứ tự đọc). Mọi thao tác ở đây GIỮ NGUYÊN THỨ TỰ ĐỌC
 * của truyện (chỉ đổi chỗ ngắt trang và mẫu của từng trang), nên PDF không bao giờ lệch thứ tự với CBZ/video. Bất biến luôn đúng sau
 * mọi thao tác (đã fuzz ở tools/test_page_editor.py):
 *   1. mọi panel dùng được xuất hiện ĐÚNG 1 lần, theo đúng thứ tự gốc;
 *   2. 1 <= số panel mỗi trang <= sức chứa của mẫu (mẫu không đủ chỗ thì panel thừa KHÔNG bị mất — chuyển sang trang mới);
 *   3. mẫu ở mức trang không bao giờ là AUTO; tên mẫu lạ -> STACK_2; trang 1 panel -> SPLASH.
 * Vì sao cần bất biến 2: `PageLayout.cells` chỉ có số ô theo mẫu (STACK_2 = 2 ô); panel thứ 3 đặt vào mẫu 2 ô sẽ BỊ BỎ khỏi trang
 * (`cells.getOrNull(i) ?: return`), tức mất panel âm thầm trong PDF.
 *
 * GIỚI HẠN THẬT: không có thao tác ĐỔI THỨ TỰ panel (cố ý: đổi thứ tự trong PDF mà không đổi trong CBZ là bẫy); chưa chỉnh được kích
 * thước ô tự do (chỉ 5 mẫu có sẵn); CHƯA build-test.
 */
object PageLayoutEditor {

    const val MAX_PER_PAGE = 4

    /** Các mẫu chọn được cho MỘT trang (AUTO là chế độ của cả tài liệu, không phải mẫu của một trang). */
    val PAGE_TEMPLATES: List<PageTemplate> = listOf(
        PageTemplate.SPLASH, PageTemplate.STACK_2, PageTemplate.ONE_PLUS_TWO, PageTemplate.GRID_2X2, PageTemplate.FOUR_KOMA
    )

    fun capacity(t: PageTemplate): Int = when (t) {
        PageTemplate.SPLASH -> 1
        PageTemplate.STACK_2 -> 2
        PageTemplate.ONE_PLUS_TWO -> 3
        PageTemplate.GRID_2X2 -> 4
        PageTemplate.FOUR_KOMA -> 4
        PageTemplate.AUTO -> 2
    }

    fun templateOf(name: String): PageTemplate {
        val t = runCatching { PageTemplate.valueOf(name) }.getOrDefault(PageTemplate.STACK_2)
        return if (t == PageTemplate.AUTO) PageTemplate.STACK_2 else t
    }

    fun bestTemplate(n: Int): PageTemplate = when {
        n <= 1 -> PageTemplate.SPLASH
        n == 2 -> PageTemplate.STACK_2
        n == 3 -> PageTemplate.ONE_PLUS_TWO
        else -> PageTemplate.GRID_2X2
    }

    /** Mẫu hợp lệ cho trang n panel: 1 panel -> SPLASH; mẫu đủ chỗ -> giữ nguyên lựa chọn; thiếu chỗ -> mẫu tốt nhất cho n. */
    fun fit(t: PageTemplate, n: Int): PageTemplate {
        val tt = if (t == PageTemplate.AUTO) PageTemplate.STACK_2 else t
        return when {
            n <= 1 -> PageTemplate.SPLASH
            capacity(tt) >= n -> tt
            else -> bestTemplate(n)
        }
    }

    fun usable(panels: List<Panel>): List<Panel> =
        panels.filter { p -> (p.upscaledPath ?: p.imagePath)?.let { File(it).exists() } == true }

    // ── Dựng bố cục xuất phát ──────────────────────────────────────────────

    fun fromAuto(panels: List<Panel>): List<PageSpec> {
        val raw = PageLayoutPlanner.plan(panels.map { PageLayoutPlanner.beatOf(it.scene) }).map { pg ->
            PageSpec(fit(pg.template, pg.count).name, panels.subList(pg.start, pg.start + pg.count).map { it.index })
        }
        return normalize(raw, panels.map { it.index })
    }

    fun fromTemplate(t: PageTemplate, panels: List<Panel>): List<PageSpec> {
        if (t == PageTemplate.AUTO) return fromAuto(panels)
        val cap = capacity(t)
        val raw = panels.chunked(cap).map { c -> PageSpec(fit(t, c.size).name, c.map { it.index }) }
        return normalize(raw, panels.map { it.index })
    }

    /** Bố cục đang hiệu lực của chương: bản tuỳ chỉnh đã lưu (được chuẩn hoá lại), nếu chưa có thì dựng từ mẫu ở Cài đặt. */
    fun currentOrBase(ch: Chapter, settingsTemplateName: String): List<PageSpec> {
        val ok = usable(ch.panels)
        val saved = ch.pageLayout
        if (saved != null) return normalize(saved, ok.map { it.index })
        val t = runCatching { PageTemplate.valueOf(settingsTemplateName) }.getOrDefault(PageTemplate.STACK_2)
        return fromTemplate(t, ok)
    }

    // ── Chuẩn hoá (an toàn với dữ liệu cũ/hỏng/lệch sau khi thêm-xoá panel) ───────

    /**
     * Ép bố cục thoả bất biến 1-3 trên tập panel dùng được `validIdx` (theo thứ tự đọc).
     *  A. bỏ chỉ số không còn tồn tại, bỏ chỉ số trùng, bỏ trang rỗng; trang vượt sức chứa thì phần thừa thành trang mới;
     *  B. panel chưa có trong bố cục (mới thêm/mới có ảnh) được nối vào CUỐI theo từng cặp;
     *  C. gán lại chỉ số theo THỨ TỰ ĐỌC GỐC, giữ nguyên số panel và mẫu từng trang (bố cục cũ vẫn giữ hình dạng khi chương đổi).
     * Idempotent: normalize(normalize(x)) == normalize(x).
     */
    fun normalize(pages: List<PageSpec>, validIdx: List<Int>): List<PageSpec> {
        val order = validIdx.distinct()
        if (order.isEmpty()) return emptyList()
        val valid = order.toHashSet()
        val seen = HashSet<Int>()
        val groups = ArrayList<Pair<PageTemplate, Int>>()
        for (pg in pages) {
            val kept = pg.panelIndexes.filter { it in valid && seen.add(it) }
            if (kept.isEmpty()) continue
            val t = templateOf(pg.template)
            val first = minOf(kept.size, capacity(t))
            groups.add(fit(t, first) to first)
            var rest = kept.size - first
            while (rest > 0) {
                val take = minOf(rest, MAX_PER_PAGE)
                groups.add(bestTemplate(take) to take)
                rest -= take
            }
        }
        val missing = order.filter { it !in seen }
        for (c in missing.chunked(2)) groups.add(bestTemplate(c.size) to c.size)
        var pos = 0
        val out = ArrayList<PageSpec>(groups.size)
        for ((t, n) in groups) {
            out.add(PageSpec(t.name, order.subList(pos, pos + n).toList()))
            pos += n
        }
        return out
    }

    private fun finish(pages: List<PageSpec>): List<PageSpec> = normalize(pages, pages.flatMap { it.panelIndexes })

    // ── Thao tác (mỗi hàm THUẦN; tham số sai -> trả nguyên bản cũ) ──────────────────

    /** Đổi mẫu của trang `page`. Mẫu ít ô hơn số panel hiện có -> panel thừa chuyển sang trang MỚI ngay sau (không mất panel). */
    fun setTemplate(pages: List<PageSpec>, page: Int, t: PageTemplate): List<PageSpec> {
        if (page !in pages.indices || t == PageTemplate.AUTO) return pages
        val ids = pages[page].panelIndexes
        val head = ids.take(capacity(t))
        val out = ArrayList<PageSpec>(pages.size + 1)
        out.addAll(pages.subList(0, page))
        out.add(PageSpec(fit(t, head.size).name, head))
        for (c in ids.drop(head.size).chunked(MAX_PER_PAGE)) out.add(PageSpec(bestTemplate(c.size).name, c))
        out.addAll(pages.subList(page + 1, pages.size))
        return finish(out)
    }

    /** Tách trang `page` trước panel thứ `at` (1 <= at < số panel của trang). */
    fun splitPage(pages: List<PageSpec>, page: Int, at: Int): List<PageSpec> {
        if (page !in pages.indices) return pages
        val ids = pages[page].panelIndexes
        if (at < 1 || at >= ids.size) return pages
        val left = ids.subList(0, at).toList()
        val right = ids.subList(at, ids.size).toList()
        val out = ArrayList<PageSpec>(pages.size + 1)
        out.addAll(pages.subList(0, page))
        out.add(PageSpec(fit(templateOf(pages[page].template), left.size).name, left))
        out.add(PageSpec(bestTemplate(right.size).name, right))
        out.addAll(pages.subList(page + 1, pages.size))
        return finish(out)
    }

    /** Gộp trang `page` với trang kế tiếp (chỉ khi tổng <= MAX_PER_PAGE panel). */
    fun mergeWithNext(pages: List<PageSpec>, page: Int): List<PageSpec> {
        if (page < 0 || page + 1 >= pages.size) return pages
        val a = pages[page]
        val b = pages[page + 1]
        val n = a.panelIndexes.size + b.panelIndexes.size
        if (n > MAX_PER_PAGE) return pages
        val ta = templateOf(a.template)
        val t = if (a.panelIndexes.size > 1 && capacity(ta) >= n) ta else bestTemplate(n)
        val out = ArrayList<PageSpec>(pages.size - 1)
        out.addAll(pages.subList(0, page))
        out.add(PageSpec(t.name, a.panelIndexes + b.panelIndexes))
        out.addAll(pages.subList(page + 2, pages.size))
        return finish(out)
    }

    /** Đẩy panel CUỐI của trang `page` xuống đầu trang kế tiếp. Không làm khi trang chỉ còn 1 panel hoặc trang kế đã đủ MAX_PER_PAGE. */
    fun moveLastToNext(pages: List<PageSpec>, page: Int): List<PageSpec> {
        if (page < 0 || page + 1 >= pages.size) return pages
        val a = pages[page]
        val b = pages[page + 1]
        if (a.panelIndexes.size < 2 || b.panelIndexes.size >= MAX_PER_PAGE) return pages
        val newA = a.panelIndexes.dropLast(1)
        val newB = listOf(a.panelIndexes.last()) + b.panelIndexes
        val out = ArrayList<PageSpec>(pages)
        out[page] = PageSpec(fit(templateOf(a.template), newA.size).name, newA)
        out[page + 1] = PageSpec(fit(templateOf(b.template), newB.size).name, newB)
        return finish(out)
    }

    /** Đẩy panel ĐẦU của trang `page` lên cuối trang liền trước. Không làm khi trang chỉ còn 1 panel hoặc trang trước đã đủ MAX_PER_PAGE. */
    fun moveFirstToPrev(pages: List<PageSpec>, page: Int): List<PageSpec> {
        if (page < 1 || page >= pages.size) return pages
        val a = pages[page - 1]
        val b = pages[page]
        if (b.panelIndexes.size < 2 || a.panelIndexes.size >= MAX_PER_PAGE) return pages
        val newA = a.panelIndexes + b.panelIndexes.first()
        val newB = b.panelIndexes.drop(1)
        val out = ArrayList<PageSpec>(pages)
        out[page - 1] = PageSpec(fit(templateOf(a.template), newA.size).name, newA)
        out[page] = PageSpec(fit(templateOf(b.template), newB.size).name, newB)
        return finish(out)
    }

    // ── Dùng trong xuất PDF ──────────────────────────────────────────────

    /**
     * Bố cục tuỳ chỉnh -> danh sách (mẫu, panel) cho `PublishExporter.exportPdf`. `ok` = panel có ảnh theo thứ tự đọc.
     * `Panel.index` trùng nhau thì bố cục không đáng tin -> rơi về AUTO (không bao giờ bỏ panel).
     */
    fun resolve(pages: List<PageSpec>, ok: List<Panel>): List<Pair<PageTemplate, List<Panel>>> {
        val idx = ok.map { it.index }
        if (idx.size != idx.toSet().size) return PageLayoutPlanner.planPanels(ok)
        val byIdx = ok.associateBy { it.index }
        return normalize(pages, idx).map { pg -> templateOf(pg.template) to pg.panelIndexes.mapNotNull { byIdx[it] } }
    }

    // ── Hình học xem trước ───────────────────────────────────────────────

    /**
     * Sơ đồ ô của một trang để vẽ xem trước: danh sách HÀNG, mỗi hàng là các VỊ TRÍ panel (0..n-1) từ trái sang phải trên màn hình.
     * Khớp thứ tự ô của `PageLayout.cells` (đã kiểm ở test); `rtl` = lật ngang từng hàng như `PageLayout.cells(rtl = true)`.
     */
    fun cellRows(t: PageTemplate, n: Int, rtl: Boolean = false): List<List<Int>> {
        val rows: List<List<Int>> = when (PageLayout.effectiveTemplate(t, n)) {
            PageTemplate.SPLASH -> listOf(listOf(0))
            PageTemplate.STACK_2 -> listOf(listOf(0), listOf(1))
            PageTemplate.AUTO -> listOf(listOf(0), listOf(1))
            PageTemplate.FOUR_KOMA -> List(n.coerceIn(2, 4)) { listOf(it) }
            PageTemplate.GRID_2X2 -> listOf(listOf(0, 1), listOf(2, 3))
            PageTemplate.ONE_PLUS_TWO -> listOf(listOf(0), listOf(1, 2))
        }
        return if (rtl) rows.map { it.reversed() } else rows
    }
}
