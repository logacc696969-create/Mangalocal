package com.mangalocal.pipeline

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/**
 * Auto-Histogram Guard — mục 79/80 TECHNICAL_STATUS.md (TODO #8 trước đó,
 * nay đã code). Đề xuất "Auto-Histogram Guard" từ `bổ_sung_sd1_5.txt`:
 * đo độ sáng trung bình ảnh gốc TRƯỚC Ultrafix, nếu quá tối/quá sáng thì
 * chèn tag bù trừ vào prompt UPSCALE_REDRAW — thuần phân tích pixel-level,
 * KHÔNG cần model/inference mới, chi phí gần như 0 (chỉ đọc + downsample
 * 1 bitmap đã có sẵn, không decode thêm lần nào khác).
 *
 * CÁCH DÙNG: gọi TRƯỚC khi build prompt UPSCALE_REDRAW trong
 * `MangaPipeline.upscaleApprovedPanels()`, nối kết quả vào cuối
 * `ufPrompt` (positive prompt) — xem `MangaPipeline.kt`, biến `beforeUltrafix`.
 *
 * GIỚI HẠN THẬT:
 *  - Đo độ sáng trung bình (mean luminance) là chỉ số THÔ — không phân biệt
 *    được "ảnh tối vì cảnh đêm CHỦ Ý" với "ảnh tối do lỗi sinh ảnh ngẫu
 *    nhiên". Ngưỡng `DARK_THRESHOLD`/`BRIGHT_THRESHOLD` là kinh nghiệm phổ
 *    biến cho ảnh 8-bit sRGB thông thường, KHÔNG áp dụng đúng cho cảnh cố ý
 *    tối/sáng (night scene, cảnh cháy nổ...) — sẽ vô tình "sửa" cả cảnh
 *    đúng ý đồ. Cân nhắc: chỉ nên dùng tag GỢI Ý NHẸ (không ép buộc mạnh),
 *    để LLM/UNet vẫn có thể bỏ qua nếu ngữ cảnh prompt gốc mâu thuẫn.
 *  - Downsample về `SAMPLE_SIZE`×`SAMPLE_SIZE` trước khi tính trung bình để
 *    nhanh (không quét full-res) — độ chính xác giảm nhẹ nhưng đủ dùng cho
 *    mục đích phân loại thô (tối/sáng/bình thường), không cần chính xác
 *    tuyệt đối.
 *  - CHƯA BUILD-TEST.
 */
object HistogramGuard {

    // Ngưỡng mean luminance trên thang 0-255 (kinh nghiệm phổ biến xử lý
    // ảnh: <60 coi là tối, >200 coi là sáng/cháy sáng — dùng số tròn dễ
    // hiểu, KHÔNG phải số liệu đo thật từ tập dữ liệu của dự án này).
    private const val DARK_THRESHOLD = 60f
    private const val BRIGHT_THRESHOLD = 200f
    private const val SAMPLE_SIZE = 64 // downsample về 64x64 trước khi tính trung bình

    data class HistogramResult(val meanLuminance: Float, val isDark: Boolean, val isBright: Boolean)

    /**
     * Đo độ sáng trung bình của ảnh tại [imagePath]. Trả về null nếu không
     * đọc được file (an toàn — caller nên bỏ qua bù trừ nếu null, KHÔNG
     * throw để không làm gãy pipeline chính vì 1 bước phụ trợ).
     */
    fun analyze(imagePath: String): HistogramResult? {
        val file = File(imagePath)
        if (!file.exists()) return null
        return try {
            val opts = BitmapFactory.Options().apply { inSampleSize = 4 } // giảm tải decode trước, downsample tiếp sau
            val original = BitmapFactory.decodeFile(imagePath, opts) ?: return null
            val small = Bitmap.createScaledBitmap(original, SAMPLE_SIZE, SAMPLE_SIZE, true)
            if (small !== original) original.recycle()

            var sum = 0.0
            val pixels = IntArray(SAMPLE_SIZE * SAMPLE_SIZE)
            small.getPixels(pixels, 0, SAMPLE_SIZE, 0, 0, SAMPLE_SIZE, SAMPLE_SIZE)
            small.recycle()
            for (p in pixels) {
                val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
                // Công thức luminance chuẩn ITU-R BT.601 (dùng phổ biến, đủ
                // chính xác cho mục đích phân loại thô ở đây).
                sum += 0.299 * r + 0.587 * g + 0.114 * b
            }
            val mean = (sum / pixels.size).toFloat()
            HistogramResult(mean, isDark = mean < DARK_THRESHOLD, isBright = mean > BRIGHT_THRESHOLD)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Trả về đoạn tag GỢI Ý (nhẹ, không ép buộc) để nối vào cuối prompt
     * UPSCALE_REDRAW nếu ảnh quá tối/quá sáng. Trả về "" nếu bình thường
     * hoặc không đo được — an toàn, không tác dụng phụ.
     */
    fun suggestCompensationTag(result: HistogramResult?): String {
        if (result == null) return ""
        return when {
            result.isDark -> "slightly brighter exposure, balanced lighting"
            result.isBright -> "slightly reduced exposure, avoid overexposure"
            else -> ""
        }
    }
}
