package com.mangalocal.pipeline

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * mục 280 TECHNICAL_STATUS.md — ĐỘ SÂU 3D THẬT cho khung xương trích từ ảnh, bằng BlazePose GHUM 3D (MediaPipe Pose Landmark lite/full, Apache-2.0) chạy qua MNN (blazepose_wrapper.cpp).
 * Thay cho việc ĐOÁN độ sâu từ độ co ngắn (Pose3D.reconstructDepth, mục 279): mô hình trả toạ độ 3D THẬT theo mét (gốc giữa hông, y XUỐNG, z ÂM = gần camera — khớp quy ước z của dự án),
 * nên không còn mập mờ dấu ra-trước/ra-sau, và thân xoay vừa cũng được khôi phục. x, y của khung xương GIỮ NGUYÊN (do YOLO cho); chỉ `z` được thêm vào.
 *
 * Thuần Kotlin (không Android) để biên dịch và chạy thử độc lập — xem tools/kotlin_tests/BlazePoseLiftTest.kt và tools/test_blazepose_lift.py (chạy MÔ HÌNH THẬT).
 * BlazePose chỉ nhận MỘT người đã cắt: [roiFromPerson] dựng ROI vuông (có xoay cho thân thẳng đứng, như MediaPipe) từ khung xương YOLO; [sampleCrop] cắt 256×256 RGB 0..1 (HWC);
 * [parseOutput] đổi đầu ra về toạ độ ảnh gốc; [depthFor] ánh xạ 33 điểm → OpenPose BODY_18 và đặt z.
 *
 * Quy ước ĐÃ KIỂM bằng model thật trên ảnh thật (bus.jpg, hai người đứng): MediaPipe "trái" = bên trái của CHÍNH nhân vật (= OpenPose L); điểm ảnh x, y theo pixel của ảnh cắt 256; world theo mét.
 * Toạ độ x, y của dự án chuẩn hoá theo ảnh gốc (x/W, y/H). z tính theo bề NGANG khung (đúng quy ước của Pose3D: bên trong đổi sang đơn vị đẳng hướng x·aspect, y, z·aspect).
 * mục 282: [depthFor] nhận `aspect` = W/H của ảnh nguồn. Trước đây hệ số tỷ lệ s được khớp thẳng giữa (x/W, y/H) và mét nên với ảnh KHÔNG vuông nó pha trộn hai thang khác nhau (f/W cho x,
 * f/H cho y) và z lệch so với x, y tới ~|1 − W/H| (ảnh 810×1080: ~25%). Nay khớp trong đơn vị đẳng hướng (x·aspect, y) rồi đổi z về đơn vị bề ngang; ảnh vuông cho kết quả y hệt bản cũ.
 */
object BlazePoseLift {
    const val SIZE = 256
    const val RESULT_FLOATS = 1 + 39 * 5 + 39 * 3   // 313: [cờ có người] + [39 × (x_px, y_px, z, thấy-logit, hiện-logit)] + [39 × (x, y, z) mét]
    const val MIN_POSE_FLAG = 0.5f
    const val MIN_VISIBILITY = 0.5f
    /** MediaPipe mở rộng ROI 1,25× quanh vòng tròn bao thân. */
    const val ROI_SCALE = 1.25f

    /** ROI vuông tính bằng PIXEL ảnh gốc. [rotation] radian, dương = theo chiều kim đồng hồ trên ảnh (y xuống): điểm cục bộ (a, b) → ảnh (cx + a·cos − b·sin, cy + a·sin + b·cos). */
    data class Roi(val cx: Float, val cy: Float, val size: Float, val rotation: Float)

    /** Đầu ra đã đổi về khung ảnh gốc. world đã xoay theo ROI (xy), y xuống, z âm = gần camera. 33 điểm theo chỉ số MediaPipe. */
    class Lifted(
        val flag: Float,
        val imgX: FloatArray, val imgY: FloatArray, val visibility: FloatArray,
        val worldX: FloatArray, val worldY: FloatArray, val worldZ: FloatArray
    )

    /** OpenPose BODY_18 ← MediaPipe 33 (−1 = cổ: trung điểm hai vai). "Trái/phải" cùng nghĩa ở hai bên. */
    private val FROM_BLAZE = intArrayOf(0, -1, 12, 14, 16, 11, 13, 15, 24, 26, 28, 23, 25, 27, 5, 2, 8, 7)

    // ───────────────────────── ROI ─────────────────────────

    /**
     * ROI từ khung xương OpenPose-18 chuẩn hoá (x/W, y/H). Nếu đủ hai hông và hai vai: tâm = tâm hông, XOAY để vectơ tâm hông → tâm vai chỉ lên (như MediaPipe), cạnh = 2,5 × bán kính
     * (khoảng cách xa nhất từ tâm hông tới khớp đang hiện) — tức 2·r·1,25 của MediaPipe. Không thì dùng hộp [box] chuẩn hoá (x1, y1, x2, y2) hoặc hộp bao các khớp đang hiện, không xoay, cạnh = 1,25 × cạnh dài.
     * null nếu không có đủ thông tin.
     */
    fun roiFromPerson(person: List<StoryManager.PoseKeypoint>, imgW: Int, imgH: Int, box: FloatArray? = null): Roi? {
        if (person.size < 18 || imgW <= 0 || imgH <= 0) return null
        fun px(i: Int) = person[i].x * imgW
        fun py(i: Int) = person[i].y * imgH
        if (person[8].visible && person[11].visible && person[2].visible && person[5].visible) {
            val hx = (px(8) + px(11)) / 2f; val hy = (py(8) + py(11)) / 2f
            val vx = (px(2) + px(5)) / 2f - hx; val vy = (py(2) + py(5)) / 2f - hy
            if (hypot(vx, vy) > 8f) {
                var r = 0f
                for (i in 0 until 18) if (person[i].visible) r = max(r, hypot(px(i) - hx, py(i) - hy))
                val size = max(2f * r * ROI_SCALE, 64f)
                return Roi(hx, hy, size, atan2(vx, -vy))
            }
        }
        var x1: Float; var y1: Float; var x2: Float; var y2: Float
        if (box != null && box.size >= 4) { x1 = box[0] * imgW; y1 = box[1] * imgH; x2 = box[2] * imgW; y2 = box[3] * imgH }
        else {
            val v = person.filter { it.visible }
            if (v.size < 3) return null
            x1 = v.minOf { it.x } * imgW; x2 = v.maxOf { it.x } * imgW; y1 = v.minOf { it.y } * imgH; y2 = v.maxOf { it.y } * imgH
        }
        val side = max(x2 - x1, y2 - y1)
        if (side < 8f) return null
        return Roi((x1 + x2) / 2f, (y1 + y2) / 2f, max(side * ROI_SCALE, 64f), 0f)
    }

    // ───────────────────────── cắt ảnh ─────────────────────────

    /**
     * Cắt ROI thành SIZE×SIZE×3 float RGB 0..1, thứ tự HWC (đúng đầu vào NHWC của model). [argb] = pixel ARGB (Bitmap.getPixels) kích thước w×h. Nội suy song tuyến, quy ước tâm pixel
     * (điểm ảnh (u, v) lấy tại ((u+0,5)/SIZE − 0,5)·cạnh, giống PIL AFFINE/BILINEAR dùng khi kiểm); ngoài ảnh = đen (0). [out] tái sử dụng được.
     */
    fun sampleCrop(argb: IntArray, w: Int, h: Int, roi: Roi, out: FloatArray = FloatArray(SIZE * SIZE * 3)): FloatArray {
        val c = cos(roi.rotation); val s = sin(roi.rotation)
        val inv255 = 1f / 255f
        var o = 0
        for (v in 0 until SIZE) {
            val b = ((v + 0.5f) / SIZE - 0.5f) * roi.size
            for (u in 0 until SIZE) {
                val a = ((u + 0.5f) / SIZE - 0.5f) * roi.size
                val fx = roi.cx + a * c - b * s - 0.5f      // chỉ số pixel liên tục (tâm pixel i ở i + 0,5)
                val fy = roi.cy + a * s + b * c - 0.5f
                val x0 = floor(fx).toInt(); val y0 = floor(fy).toInt()
                val tx = fx - x0; val ty = fy - y0
                var r = 0f; var g = 0f; var bl = 0f
                for (dy in 0..1) for (dx in 0..1) {
                    val xi = x0 + dx; val yi = y0 + dy
                    if (xi < 0 || yi < 0 || xi >= w || yi >= h) continue
                    val wt = (if (dx == 0) 1f - tx else tx) * (if (dy == 0) 1f - ty else ty)
                    val p = argb[yi * w + xi]
                    r += wt * ((p shr 16) and 0xFF); g += wt * ((p shr 8) and 0xFF); bl += wt * (p and 0xFF)
                }
                out[o++] = r * inv255; out[o++] = g * inv255; out[o++] = bl * inv255
            }
        }
        return out
    }

    // ───────────────────────── đầu ra → ảnh gốc ─────────────────────────

    /** Điểm (u, v) theo pixel của ảnh cắt 256 → pixel ảnh gốc. */
    fun cropToImage(u: Float, v: Float, roi: Roi): Pair<Float, Float> {
        val c = cos(roi.rotation); val s = sin(roi.rotation)
        val a = (u / SIZE - 0.5f) * roi.size; val b = (v / SIZE - 0.5f) * roi.size
        return (roi.cx + a * c - b * s) to (roi.cy + a * s + b * c)
    }

    /**
     * Đổi đầu ra [raw] (313 float từ blazePoseRun) về khung ảnh gốc: điểm ảnh qua ROI ngược; điểm world xoay (x, y) theo cùng góc ROI (z giữ nguyên) như WorldLandmarkProjection của MediaPipe.
     * null nếu độ dài sai hoặc cờ "có người" < [MIN_POSE_FLAG].
     */
    fun parseOutput(raw: FloatArray, roi: Roi): Lifted? {
        if (raw.size != RESULT_FLOATS || raw[0] < MIN_POSE_FLAG) return null
        val c = cos(roi.rotation); val s = sin(roi.rotation)
        val ix = FloatArray(33); val iy = FloatArray(33); val vis = FloatArray(33)
        val wx = FloatArray(33); val wy = FloatArray(33); val wz = FloatArray(33)
        for (i in 0 until 33) {
            val l = 1 + 5 * i
            val p = cropToImage(raw[l], raw[l + 1], roi); ix[i] = p.first; iy[i] = p.second
            vis[i] = 1f / (1f + exp(-raw[l + 3]))
            val w0 = 1 + 195 + 3 * i
            val x = raw[w0]; val y = raw[w0 + 1]
            wx[i] = x * c - y * s; wy[i] = x * s + y * c; wz[i] = raw[w0 + 2]
        }
        return Lifted(raw[0], ix, iy, vis, wx, wy, wz)
    }

    // ───────────────────────── 33 điểm → OpenPose-18 với z ─────────────────────────

    /**
     * Trả BẢN SAO [person] (OpenPose-18, x, y chuẩn hoá theo ảnh) có `z` thật; x, y, visible giữ nguyên. z = (s / aspect) · (z_world − z_world của tâm hông), trong đó s (đơn vị CHIỀU CAO khung / mét)
     * khớp bình phương tối thiểu giữa vị trí ảnh của các khớp đang hiện (tin cậy ≥ [MIN_VISIBILITY]) so với tâm hông — ĐỔI sang đơn vị đẳng hướng (x·aspect, y) — và (x, y) world cùng khớp
     * (xấp xỉ phối cảnh yếu). [aspect] = rộng/cao ẢNH NGUỒN (mục 282); mặc định 1 = ảnh vuông (hành vi cũ). Chia thêm cho aspect để z cùng đơn vị bề ngang với x (quy ước Pose3D).
     * Khớp hiện ở YOLO nhưng BlazePose cho là bị che vẫn nhận z (ước lượng, không bỏ trống để khỏi lẫn z = 0 với z thật). null nếu thiếu hai hông, cờ thấp, aspect không hợp lệ, hoặc không khớp được tỷ lệ (s ≤ 0).
     */
    fun depthFor(person: List<StoryManager.PoseKeypoint>, lifted: Lifted, aspect: Float = 1f): MutableList<StoryManager.PoseKeypoint>? {
        if (!(aspect > 0f) || aspect.isInfinite()) return null
        if (person.size < 18 || lifted.flag < MIN_POSE_FLAG) return null
        if (!person[8].visible || !person[11].visible) return null
        val wx = FloatArray(18); val wy = FloatArray(18); val wz = FloatArray(18); val vis = FloatArray(18)
        for (i in 0 until 18) {
            val b = FROM_BLAZE[i]
            if (b >= 0) { wx[i] = lifted.worldX[b]; wy[i] = lifted.worldY[b]; wz[i] = lifted.worldZ[b]; vis[i] = lifted.visibility[b] }
            else {   // cổ = trung điểm hai vai
                wx[i] = (lifted.worldX[11] + lifted.worldX[12]) / 2f; wy[i] = (lifted.worldY[11] + lifted.worldY[12]) / 2f
                wz[i] = (lifted.worldZ[11] + lifted.worldZ[12]) / 2f; vis[i] = minOf(lifted.visibility[11], lifted.visibility[12])
            }
        }
        val hwx = (wx[8] + wx[11]) / 2f; val hwy = (wy[8] + wy[11]) / 2f; val hwz = (wz[8] + wz[11]) / 2f
        val hsx = (person[8].x + person[11].x) / 2f; val hsy = (person[8].y + person[11].y) / 2f
        var num = 0.0; var den = 0.0
        for (i in 0 until 18) {
            if (!person[i].visible || vis[i] < MIN_VISIBILITY || i == 8 || i == 11) continue
            val dwx = wx[i] - hwx; val dwy = wy[i] - hwy
            num += (person[i].x - hsx) * aspect * dwx + (person[i].y - hsy) * dwy      // đơn vị đẳng hướng (chiều cao khung): x·aspect
            den += dwx * dwx + dwy * dwy
        }
        if (den < 1e-6) return null
        val s = (num / den).toFloat()
        if (s <= 0f) return null
        val sz = s / aspect          // z theo bề NGANG khung (như x): 1 mét = s đơn vị chiều cao = s/aspect đơn vị bề ngang
        val out = person.toMutableList()
        for (i in 0 until 18) if (person[i].visible) out[i] = person[i].copy(z = sz * (wz[i] - hwz))
        return out
    }
}
