package com.mangalocal.pipeline

/**
 * mục 261 TECHNICAL_STATUS.md — bước LẬP kế hoạch liên tục kiểu CANVAS (việc treo từ 260.3: ContinuityChecker chỉ KIỂM sau khi sinh ảnh).
 *
 * Phạm vi CỐ Ý hẹp: chỉ ĐIỀN bối cảnh (`LOCATION_DRIFT`) — panel không khai bối cảnh nằm giữa các panel cùng một bối cảnh thì nhận bối cảnh đó, để
 * mỏ neo bối cảnh (Location anchor, mục 216-219) được dùng cho cả panel đó thay vì để nền trôi. Đây là phần DUY NHẤT của kế hoạch liên tục có thể suy
 * ra mà không đoán ý đồ nghệ thuật. KHÔNG điền nhân vật/vật thể thiếu (CHARACTER_GAP / PROP_GAP): hồi tưởng, cắt cảnh, cận cảnh một nhân vật là hợp lệ,
 * điền bừa sẽ chèn người vào panel không muốn có người — các cảnh báo đó vẫn chỉ ghi log ở ContinuityChecker.
 *
 * Dùng lại CHÍNH ContinuityChecker.check để quyết định "đây là trôi bối cảnh" (một nguồn sự thật, không viết lại điều kiện), rồi chỉ tra thêm TÊN GỐC
 * (đúng chữ hoa/thường của kịch bản) từ panel gần nhất phía trước có khai bối cảnh trong cùng đoạn liên tiếp. Hàm thuần: chạy được bằng kotlinc.
 *
 * GIỚI HẠN THẬT: đoán "panel bị bỏ trống bối cảnh = cùng bối cảnh hai bên" có thể sai khi kịch bản cố ý cắt sang nơi khác không khai (hiếm; có cờ để tắt);
 * chỉ chạy trên panel có chỉ số liên tiếp; không sửa nhân vật/vật thể; chưa thử trên truyện thật.
 */
object ContinuityPlanner {

    /** Mỗi mục: panelIndex -> tên bối cảnh (nguyên văn, đã trim) cần gán. Rỗng nếu không có gì để điền. */
    fun planLocationFill(entries: List<ContinuityChecker.Entry>): Map<Int, String> {
        if (entries.size < 3) return emptyMap()
        val drift = ContinuityChecker.check(entries).filter { it.kind == ContinuityChecker.Kind.LOCATION_DRIFT }
        if (drift.isEmpty()) return emptyMap()
        val sorted = entries.sortedBy { it.panelIndex }
        val byIndex = sorted.withIndex().associate { it.value.panelIndex to it.index }
        val out = LinkedHashMap<Int, String>()
        for (w in drift) {
            val pos = byIndex[w.panelIndex] ?: continue
            // đi lùi trong đoạn chỉ số LIÊN TIẾP tới panel gần nhất có khai bối cảnh -> lấy tên gốc
            var p = pos - 1
            var found: String? = null
            while (p >= 0 && sorted[p].panelIndex == sorted[p + 1].panelIndex - 1) {
                val loc = sorted[p].location.trim()
                if (loc.isNotEmpty()) { found = loc; break }
                p--
            }
            if (found != null && found.lowercase() == w.subject) out[w.panelIndex] = found
        }
        return out
    }
}
