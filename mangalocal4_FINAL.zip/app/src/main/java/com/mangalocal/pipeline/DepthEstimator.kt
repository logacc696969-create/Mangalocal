package com.mangalocal.pipeline

import kotlin.math.max
import kotlin.math.min

/**
 * mục 232 TECHNICAL_STATUS.md — Ước lượng ĐỘ SÂU đơn ảnh bằng MiDaS-small (MNN),
 * dùng để điền z THẬT cho khớp xương khi dò điểm chạm (ContactDetector).
 *
 * TẠI SAO CẦN: bố cục khung xương là (x, y, z, visible) nhưng z mặc định 0 ở hầu
 * hết template (PoseKeypoint.z = 0f) nên hình học 2D không phân biệt được "gối của
 * A nằm TRƯỚC thân B" với "gối của A thật sự chạm thân B" — đúng điểm yếu mà
 * tài liệu mục 168 (z-order) và cộng đồng (PersonaCraft ICCV 2025: skeleton 2D
 * thiếu depth) đã nêu. MiDaS đọc ẢNH ĐÃ SINH nên cho thứ tự gần/xa của chính cái
 * model vẽ ra, không phải của template.
 *
 * Model `midas_small_depth.mnn` nằm trong StoryManager.yoloDir (cùng thư mục
 * YOLOv8-pose). Thiếu model -> isReady()=false -> mọi chỗ gọi tự bỏ qua, hành vi
 * y như trước mục này.
 *
 * GIỚI HẠN THẬT:
 * - MiDaS cho độ sâu nghịch đảo TƯƠNG ĐỐI theo từng ảnh (chuẩn hoá 0..1 trong ảnh
 *   đó), không phải mét — chỉ so sánh gần/xa TRONG CÙNG MỘT ẢNH, đúng mục đích ở đây.
 * - Ảnh minh hoạ/anime: MiDaS huấn luyện trên ảnh thật nên có thể lệch; đã dùng
 *   trung vị cửa sổ 3x3 tại khớp để bớt nhiễu nhưng CHƯA đo độ tin cậy trên ảnh
 *   của dự án.
 * - CHƯA build-test; native wrapper mới chỉ kiểm cú pháp bằng header giả, script
 *   export CHƯA từng chạy thật (xem GIỚI HẠN trong tools/export_midas_depth.py).
 */
class DepthEstimator(private val storyManager: StoryManager) {

    private val ctx: Long = try {
        if (storyManager.hasMidas()) NativeBridge.midasInit(storyManager.yoloDir.absolutePath) else 0L
    } catch (e: Throwable) { 0L } // UnsatisfiedLinkError là Error, không phải Exception

    fun isReady() = ctx != 0L

    /** 256*256 float 0..1 (1 = gần nhất trong ảnh), hàng trước cột sau; null nếu lỗi. */
    fun estimate(imagePath: String): FloatArray? {
        if (ctx == 0L) return null
        return try {
            val d = NativeBridge.midasEstimate(ctx, imagePath)
            if (d.size == SIZE * SIZE) d else null
        } catch (e: Throwable) { null }
    }

    /**
     * Trả BẢN SAO của [skeleton] (bố cục 18 khớp x 4 float (x, y, z, visible) mỗi người)
     * với z của các khớp nhìn thấy thay bằng `1 - độ sâu MiDaS` tại (x, y) — quy ước
     * của ContactDetector/native: z NHỎ = GẦN camera. Khớp không nhìn thấy giữ nguyên.
     */
    fun applyDepth(depth: FloatArray, skeleton: FloatArray): FloatArray {
        val out = skeleton.copyOf()
        var i = 0
        while (i + 3 < out.size) {
            if (out[i + 3] > 0.5f) out[i + 2] = 1f - sampleMedian(depth, out[i], out[i + 1])
            i += 4
        }
        return out
    }

    private fun sampleMedian(depth: FloatArray, x: Float, y: Float): Float {
        val cx = (x.coerceIn(0f, 1f) * (SIZE - 1)).toInt()
        val cy = (y.coerceIn(0f, 1f) * (SIZE - 1)).toInt()
        val v = ArrayList<Float>(9)
        for (dy in -1..1) for (dx in -1..1) {
            val px = min(SIZE - 1, max(0, cx + dx)); val py = min(SIZE - 1, max(0, cy + dy))
            v.add(depth[py * SIZE + px])
        }
        v.sort()
        return v[4]
    }

    fun close() { if (ctx != 0L) try { NativeBridge.midasFree(ctx) } catch (e: Throwable) { } }

    companion object { const val SIZE = 256 }
}
