package com.mangalocal.pipeline

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Xử lý biểu hiện vật lý của da thịt và trang phục khi các nhân vật vật lộn/
 * dính chạm — vá gap "FleshDeformationEngine không tồn tại" đã phát hiện khi
 * đối chiếu `hoàn_thiện_sd1_5.txt` với source thật (mục 111 TECHNICAL_STATUS.md).
 *
 * Hoạt động THUẦN HÌNH HỌC (không gọi mô hình AI nào khác): đọc trực tiếp
 * [skeletonData] phẳng (định dạng OpenPose-18, N người x 18 khớp x 4 giá trị
 * [x,y,confidence,personIdx] — CÙNG định dạng mà FaceHandDetector/QualityGateChecker
 * đã dùng, xem [FaceHandDetector.detectHandOverBodyOverlaps]) để đo khoảng
 * cách giữa các khớp hông/cổ tay của từng cặp nhân vật, rồi tiêm cụm tag mô
 * tả biến dạng vật lý (vải nhăn/rách, da thịt co móp) tương ứng vào prompt.
 *
 * GIỚI HẠN THẬT: đây là heuristic khoảng cách 2D trên ảnh chuẩn hoá
 * (0..1), KHÔNG PHẢI mô phỏng vật lý thật — ngưỡng [COLLISION_THRESHOLD]
 * chọn theo kinh nghiệm, chưa đo trên ảnh thật của model MangaLocal. Chạy
 * TRƯỚC bước sinh ảnh (bổ sung tag vào prompt), KHÔNG thay thế
 * [FaceHandDetector.detectHandOverBodyOverlaps] (chạy SAU khi có ảnh, để
 * khoanh vùng inpaint) — hai cơ chế bổ trợ nhau, không trùng lặp.
 */
object FleshDeformationEngine {
    // Khoảng cách 2D (toạ độ chuẩn hoá 0..1) quy định ranh giới "va chạm sát"
    private const val COLLISION_THRESHOLD = 0.08f
    private const val FLOATS_PER_PERSON = 72 // 18 khớp x 4 giá trị/người, khớp quy ước FaceHandDetector

    private const val HIP_R = 8
    private const val HIP_L = 11
    private const val WRIST_R = 4

    data class DeformationResult(
        val isInteracting: Boolean,
        val hasHandContact: Boolean,
        val tags: String
    )

    /**
     * Phân tích khung xương phẳng, trả về [DeformationResult] gồm cụm tag để
     * nối thêm vào prompt hiện có. KHÔNG tự nối chuỗi — gọi nơi dùng tự quyết
     * định có áp dụng hay không (ví dụ chỉ áp khi action_category không phải
     * "neutral", xem [SeedRegistry.classifyAction]).
     */
    fun analyze(skeletonData: FloatArray, numPersonsHint: Int = -1): DeformationResult {
        if (skeletonData.isEmpty()) return DeformationResult(false, false, "")
        val numPersons = if (numPersonsHint > 0) numPersonsHint else skeletonData.size / FLOATS_PER_PERSON
        if (numPersons < 2) return DeformationResult(false, false, "")

        var isInteracting = false
        var hasHandContact = false

        for (i in 0 until numPersons - 1) {
            val offsetA = i * FLOATS_PER_PERSON
            if (offsetA + FLOATS_PER_PERSON > skeletonData.size) break
            val hipAX = skeletonData[offsetA + HIP_R * 4]
            val hipAY = skeletonData[offsetA + HIP_R * 4 + 1]

            for (j in i + 1 until numPersons) {
                val offsetB = j * FLOATS_PER_PERSON
                if (offsetB + FLOATS_PER_PERSON > skeletonData.size) break
                val hipBX = skeletonData[offsetB + HIP_L * 4]
                val hipBY = skeletonData[offsetB + HIP_L * 4 + 1]

                val distance = sqrt(
                    ((hipAX - hipBX) * (hipAX - hipBX) + (hipAY - hipBY) * (hipAY - hipBY)).toDouble()
                ).toFloat()
                if (distance < COLLISION_THRESHOLD * 2) isInteracting = true

                val wristAX = skeletonData[offsetA + WRIST_R * 4]
                val wristAY = skeletonData[offsetA + WRIST_R * 4 + 1]
                if (abs(wristAX - hipBX) < COLLISION_THRESHOLD && abs(wristAY - hipBY) < COLLISION_THRESHOLD) {
                    hasHandContact = true
                }
            }
        }

        val tags = StringBuilder()
        if (isInteracting) {
            tags.append(", (torn clothes:1.15), shredded fabric, ragged outfit, fabric tension, deep stress wrinkles")
        }
        if (hasHandContact) {
            tags.append(", (flesh compression:1.2), deep indentation on skin, fingers pressing into skin, realistic anatomy compression")
        }
        return DeformationResult(isInteracting, hasHandContact, tags.toString())
    }

    /** Tiện ích: áp trực tiếp lên 1 chuỗi prompt, trả về prompt gốc nếu không phát hiện gì. */
    fun injectInto(prompt: String, skeletonData: FloatArray, numPersonsHint: Int = -1): String {
        val result = analyze(skeletonData, numPersonsHint)
        return if (result.tags.isEmpty()) prompt else prompt + result.tags
    }
}
