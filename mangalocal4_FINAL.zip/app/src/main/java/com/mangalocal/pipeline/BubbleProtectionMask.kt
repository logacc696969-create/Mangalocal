package com.mangalocal.pipeline

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import java.io.File
import java.io.FileOutputStream

/**
 * Mặt nạ Bảo vệ Bubble thoại (Auto-Mask-Out Protective Layer) — mục 76
 * TECHNICAL_STATUS.md.
 *
 * Vấn đề: Khi chạy 1000 chương tự động, ADetailer/Inpaint không biết vị trí
 * ô thoại (bubble) nên khi vẽ lại sẽ đè chi tiết da thịt/tóc/vân vải lên
 * nền trắng của bubble, phá nát giao diện trang truyện.
 *
 * Giải pháp: Dùng lại BubbleEngine (YOLOv8n tách bubble — mục 1 dự án) để
 * bóc tách vùng bubble TRƯỚC khi đưa ảnh qua bất kỳ bước hậu kỳ nào. Tạo
 * một "Inverse Protection Mask" (mặt nạ bảo vệ đảo ngược):
 *  - Vùng CÓ bubble → MÀU ĐEN trong mask (= giữ nguyên, không inpaint)
 *  - Vùng KHÔNG có bubble → MÀU TRẮNG trong mask (= được phép inpaint)
 *
 * Khi kết hợp với maskPath của img2imgFix(): mask này được OR với mask lỗi
 * giải phẫu (từ QualityGate/auto-fix mặt/tay), đảm bảo không vùng nào có
 * bubble bị vẽ đè.
 *
 * ĐIỂM NỐI DÂY với code hiện có:
 *  - BubbleEngine.loadYolo()/freeYolo() và autoPplaceBubbles() đã có sẵn
 *    trong upscaleApprovedPanels() — lớp này được thiết kế LỒNG VÀO ĐÓ,
 *    không tạo instance YOLOv8 thứ 2.
 *  - MangaPipeline.buildMaskFileRefined() nhận thêm tham số
 *    [bubbleExclusionMask] tuỳ chọn (null = hành vi cũ, tương thích ngược).
 *
 * GIỚI HẠN THẬT:
 *  - BubbleEngine detect bubble ở KÍCH THƯỚC ẢNH gốc (trước upscale). Nếu
 *    gọi sau ESRGAN (ảnh lớn hơn), cần truyền đúng ảnh đã upscale vào.
 *  - Phát hiện bubble lúc sinh ảnh (trước khi đắp bubble thật) là DETECT
 *    bubble vẽ sẵn trong ảnh SD sinh ra (nếu ảnh có vùng trắng hình bầu dục
 *    tự nhiên từ diffusion, không phải bubble đắp tay). Tuỳ chất lượng
 *    YOLO với bubble diffusion, có thể detect lỗi. Fallback: nếu không
 *    detect được bubble nào → không áp protection mask, hành vi như cũ.
 *  - CHƯA BUILD-TEST.
 */
class BubbleProtectionMask {

    /**
     * Tạo mask bảo vệ từ kết quả detect bubble [bubbleRects] (toạ độ pixel
     * trong ảnh kích thước [imageW] × [imageH]).
     *
     * Trả về File bitmap mask TRẮNG-ĐEN (TRẮNG = được inpaint, ĐEN = bảo vệ).
     * Trả về null nếu không có bubble nào cần bảo vệ.
     */
    fun buildProtectionMask(
        bubbleRects: List<android.graphics.Rect>,
        imageW: Int, imageH: Int,
        outFile: File
    ): File? {
        if (bubbleRects.isEmpty()) return null

        // Tạo mask trắng (toàn bộ được phép inpaint)
        val mask = Bitmap.createBitmap(imageW, imageH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(mask)
        canvas.drawColor(Color.WHITE)

        // Tô ĐEN các vùng bubble (không được inpaint)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.FILL
        }
        for (rect in bubbleRects) {
            // Nới rộng thêm 10px quanh mỗi bubble để tránh chạm biên
            canvas.drawRect(
                RectF(
                    (rect.left - 10).coerceAtLeast(0).toFloat(),
                    (rect.top - 10).coerceAtLeast(0).toFloat(),
                    (rect.right + 10).coerceAtMost(imageW).toFloat(),
                    (rect.bottom + 10).coerceAtMost(imageH).toFloat()
                ),
                paint
            )
        }

        return try {
            FileOutputStream(outFile).use { fos ->
                mask.compress(Bitmap.CompressFormat.PNG, 100, fos)
            }
            mask.recycle()
            outFile
        } catch (e: Exception) {
            mask.recycle()
            null
        }
    }

    /**
     * Kết hợp [defectMask] (vùng CẦN sửa — trắng) với [protectionMask]
     * (vùng KHÔNG được sửa — đen) thành mask cuối: vùng CẦN sửa VÀ ĐƯỢC
     * PHÉP (không bị bubble che).
     *
     * Phép toán: final = defect AND (NOT protection)
     *  = trắng trong defect NHƯNG không bị protection tô đen.
     */
    fun combineMasks(
        defectMask: Bitmap, protectionMask: Bitmap, outFile: File
    ): File {
        val w = defectMask.width; val h = defectMask.height
        val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)

        // Vẽ defect mask (trắng = cần sửa)
        canvas.drawBitmap(defectMask, 0f, 0f, null)

        // Xoá các pixel bị bubble che (PorterDuff DST_OUT: vẽ mask đen lên → xoá trắng)
        val erasePaint = Paint().apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        }
        // Cần đảo ngược protectionMask (đen bubble → trắng để erase)
        val invertedProtect = invertBitmap(protectionMask)
        canvas.drawBitmap(invertedProtect, 0f, 0f, erasePaint)
        invertedProtect.recycle()

        return try {
            FileOutputStream(outFile).use { fos ->
                result.compress(Bitmap.CompressFormat.PNG, 100, fos)
            }
            result.recycle()
            outFile
        } catch (e: Exception) {
            result.recycle()
            outFile // trả về defect mask gốc nếu combine lỗi
        }
    }

    private fun invertBitmap(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint().apply {
            colorFilter = android.graphics.ColorMatrixColorFilter(
                android.graphics.ColorMatrix(floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                     0f,-1f, 0f, 0f, 255f,
                     0f, 0f,-1f, 0f, 255f,
                     0f, 0f, 0f, 1f,   0f
                ))
            )
        }
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }
}
