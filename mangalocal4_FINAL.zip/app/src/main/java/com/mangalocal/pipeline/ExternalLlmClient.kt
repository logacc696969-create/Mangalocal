package com.mangalocal.pipeline

import com.mangalocal.model.ExternalLlmConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Gọi LLM NGOÀI qua API chuẩn OpenAI-compatible (POST {baseUrl}/chat/completions)
 * — dùng được với OpenAI thật, OpenRouter, Groq, Together, hay server tự
 * host tương thích chuẩn này (LM Studio, Ollama qua lớp tương thích OpenAI,
 * text-generation-webui...). Đây là lựa chọn THAY THẾ cho LLM chạy local
 * trên máy (.gguf qua llama.cpp) — hữu ích khi máy yếu (không đủ RAM/NPU
 * chạy model local tốt) hoặc muốn dùng model mạnh hơn hẳn.
 *
 * LƯU Ý BẢO MẬT — khác hẳn RemoteGenerationClient (ảnh, tự host + mã hoá
 * hybrid RSA/AES riêng của app): đây là API THẬT của bên thứ 3, chỉ có TLS
 * chuẩn bảo vệ, KHÔNG có lớp mã hoá thêm nào của app. Toàn bộ văn bản kịch
 * bản gửi đi sẽ được xử lý bởi hạ tầng của nhà cung cấp API đó, theo đúng
 * chính sách riêng tư/lưu trữ của HỌ — không phải "app tự host" như Remote
 * GPU ảnh. Cân nhắc trước khi gửi nội dung thực sự riêng tư qua đây.
 */
class ExternalLlmClient(private val config: ExternalLlmConfig) {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(config.timeoutSeconds.toLong(), TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    private fun requireConfigured() {
        if (config.baseUrl.isBlank()) throw RuntimeException("Chưa nhập Base URL cho LLM ngoài (Cài đặt > LLM ngoài).")
        if (config.modelName.isBlank()) throw RuntimeException("Chưa nhập tên model cho LLM ngoài (Cài đặt > LLM ngoài).")
    }

    private fun chatRequest(jsonBody: String): () -> Request = {
        val url = config.baseUrl.trimEnd('/') + "/chat/completions"
        val b = Request.Builder().url(url).post(jsonBody.toRequestBody("application/json".toMediaType()))
        if (config.apiKey.isNotBlank()) b.addHeader("Authorization", "Bearer ${config.apiKey}")
        b.build()
    }

    /** Đọc nội dung trả lời từ kết quả HTTP (dùng chung cho biến thể suspend và biến thể chặn). */
    private fun chatContent(res: HttpResult): String {
        val respText = String(res.body, Charsets.UTF_8)
        if (res.code !in 200..299) throw RuntimeException("LLM API: " + HttpRetryPolicy.failureMessage(res.code, respText))
        return try {
            OpenAiChatJson.extractContent(respText)
        } catch (e: IllegalArgumentException) {
            throw RuntimeException("Không đọc được phản hồi API (kiểm tra lại Base URL/model): ${e.message}")
        }
    }

    /**
     * mục 266 — gửi body JSON tới {baseUrl}/chat/completions với THỬ LẠI khi bị giới hạn tần suất (HTTP 429/5xx/lỗi mạng; xem HttpRetryPolicy), rồi đọc
     * nội dung trả lời. Trước mục 266 mọi lỗi (kể cả 429 thường gặp ở bậc miễn phí) ném ngay ở lần đầu.
     */
    private suspend fun postChat(jsonBody: String): String = chatContent(HttpRetryExec.execute(client, chatRequest(jsonBody)))

    suspend fun generate(prompt: String, maxTokens: Int, temperature: Float): String =
        withContext(Dispatchers.IO) {
            requireConfigured()
            postChat(OpenAiChatJson.textBody(config.modelName, prompt, maxTokens, temperature))
        }

    /**
     * mục 266 — hỏi kèm MỘT ẢNH (chuẩn OpenAI vision: image_url dạng data URL), bản CHẶN (không suspend, chờ bằng Thread.sleep khi thử lại) cho giám khảo nhìn
     * ảnh qua API (ví dụ Gemini bậc miễn phí) thay cho model chạy trên máy — hàm gọi nó (VisionJudge.judge) không phải suspend và test_face_identity cấm runBlocking.
     * [imageBytes] nên là JPEG/PNG đã thu nhỏ (nơi gọi lo). CHƯA gọi thử với dịch vụ thật; model phải hỗ trợ ảnh, nếu không API báo 400.
     */
    fun generateWithImageBlocking(prompt: String, imageBytes: ByteArray, mime: String, maxTokens: Int, temperature: Float): String {
        requireConfigured()
        val body = OpenAiChatJson.visionBody(config.modelName, prompt, FreeImageApi.base64Encode(imageBytes), mime, maxTokens, temperature)
        return chatContent(HttpRetryExec.executeBlocking(client, chatRequest(body)))
    }

    /** Kiểm tra kết nối nhanh cho nút "Kiểm tra kết nối" ở Settings — ném exception kèm lý do nếu lỗi. */
    suspend fun testConnection(): String = generate("Reply with exactly the single word: OK", 10, 0f)
}
