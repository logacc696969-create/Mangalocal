package com.mangalocal.pipeline

import org.json.JSONObject
import java.io.File

/**
 * Từ điển Khái niệm động (Concept Dictionary) — mục 78
 * TECHNICAL_STATUS.md.
 *
 * Vấn đề: LLM dịch danh từ riêng (tên vũ khí đặc biệt, địa danh, tên kỹ
 * năng tiếng Anh của truyện...) MỖI LẦN, không tra cứu bản dịch cũ. Sau
 * 1000 chương, "Kiếm Bình Thiên Hạ" có thể bị dịch thành 5 tên SD tag khác
 * nhau, tạo ra phong cách không nhất quán.
 *
 * Giải pháp: Lưu mỗi cặp [khái niệm gốc → SD tag đã dùng] vào JSON.
 * LLMParser tra cứu dictionary TRƯỚC khi gọi LLM, inject vào prompt dưới
 * dạng "Ghi nhớ: [khái niệm_gốc] = [sd_tag_đã_dùng]. Luôn dùng bản này."
 * → LLM không tự bịa tag mới cho khái niệm đã có sẵn.
 *
 * Format file: storyDir/concept_dictionary.json
 * {
 *   "Kiếm Bình Thiên Hạ": "legendary straight sword, golden blade, ornate hilt",
 *   "Thiên Môn Cung": "ancient celestial palace, white marble, floating clouds"
 * }
 *
 * NGUỒN GỐC ENTRY:
 *  1. Tự động: khi LLM trả về tag cho khái niệm lần đầu, pipeline tự ghi
 *     vào dictionary (hàm recordFromLlmOutput).
 *  2. Thủ công: UI (EditConceptDialog chưa viết) cho user tự thêm/sửa.
 *
 * NỐI DÂY VỚI LLMParser:
 *  - LLMParser.buildPrompt() nhận thêm [conceptDict: Map<String, String>]
 *  - Inject vào system prompt ngay đầu promptTemplate():
 *    "Từ điển khái niệm cố định: ${dict.entries.joinToString("; ") {"${it.key}=${it.value}"}}"
 *  - Sau khi nhận kết quả từ LLM, gọi recordFromLlmOutput() để cập nhật dict.
 *
 * GIỚI HẠN THẬT:
 *  - Bộ lọc TOP-N theo độ liên quan (mục 146 — xem buildInjectionText())
 *    dựa trên KHỚP LITERAL từ khoá, không phải hiểu ngữ nghĩa — 1 khái
 *    niệm được nhắc tới bằng CÁCH VIẾT KHÁC (đồng nghĩa, viết tắt) trong
 *    chương sẽ KHÔNG được nhận diện là liên quan, dù thực chất có liên
 *    quan. Chấp nhận được vì vẫn tốt hơn hẳn "30 entry đầu tiên cố định"
 *    (hành vi cũ) — không cần hoàn hảo để có ích.
 *  - Phần "tự động ghi nhận từ LLM output" cần heuristic phát hiện "khái niệm
 *    mới lần đầu" (chưa trong dict) — hiện chưa implement, chỉ có API thủ công.
 *  - CHƯA CÓ UI để user thêm/sửa/xoá entry. CHƯA BUILD-TEST.
 */
class ConceptDictionary(private val storyDir: File) {

    private val file = File(storyDir, "concept_dictionary.json")
    private val dict = mutableMapOf<String, String>()

    init {
        if (file.exists()) {
            try {
                val json = JSONObject(file.readText())
                json.keys().forEach { key -> dict[key] = json.getString(key) }
            } catch (_: Exception) {}
        }
    }

    /** Tất cả entry hiện có — truyền cho LLMParser.buildPrompt(). */
    fun getAll(): Map<String, String> = dict.toMap()

    /**
     * Thêm/cập nhật entry thủ công — sẽ có UI gọi sau này.
     */
    fun put(concept: String, sdTag: String) {
        dict[concept.trim()] = sdTag.trim()
        persist()
    }

    /** Xoá entry theo khái niệm gốc. */
    fun remove(concept: String) { dict.remove(concept); persist() }

    /**
     * Ghi nhận cặp khái niệm-tag từ output của LLM.
     * Chỉ ghi nếu khái niệm CHƯA có trong dict (không ghi đè bản cũ tự động).
     *
     * [pairs]: list of (conceptVietnamese, sdTagEnglish) trích từ LLM output
     * bằng heuristic riêng (CHƯA IMPLEMENT — để trống trả về false).
     */
    fun recordFromLlmOutput(pairs: List<Pair<String, String>>): Boolean {
        var changed = false
        for ((concept, tag) in pairs) {
            if (concept.isBlank() || tag.isBlank()) continue
            if (!dict.containsKey(concept)) {
                dict[concept] = tag
                changed = true
            }
        }
        if (changed) persist()
        return changed
    }

    /**
     * Tạo đoạn text inject vào promptTemplate() của LLMParser.
     * Trả về rỗng nếu dict trống.
     *
     * mục 146 TECHNICAL_STATUS.md — đóng gap đã ghi ở GIỚI HẠN THẬT phía
     * trên ("chiến lược cắt TOP-N theo TF-IDF nhẹ — CHƯA làm"). [chapterText]
     * là văn bản chương ĐANG xử lý — dùng để chọn ra entry LIÊN QUAN nhất
     * thay vì luôn lấy 30 entry ĐẦU TIÊN theo thứ tự chèn (hành vi cũ, sai
     * ở chỗ: 1 truyện dài dần dần tích luỹ >30 khái niệm, entry chèn SỚM
     * NHẤT (thường là nhân vật/địa danh xuất hiện đầu truyện) mãi mãi
     * chiếm hết 30 suất dù chương hiện tại không hề nhắc tới chúng, trong
     * khi khái niệm MỚI xuất hiện đúng chương này lại bị cắt mất).
     *
     * KHÔNG dùng TF-IDF đúng nghĩa (cần 1 kho ngữ liệu (corpus) nhiều văn
     * bản để tính IDF — 1 truyện đơn lẻ không đủ để ước lượng "độ hiếm" có
     * ý nghĩa thống kê) — dùng bộ lọc RẺ hơn nhưng giải quyết ĐÚNG vấn đề
     * thật (context overflow do entry KHÔNG liên quan chương này): đếm số
     * lần khái niệm gốc xuất hiện literal trong [chapterText] (không phân
     * biệt hoa/thường) — entry XUẤT HIỆN trong chương này gần như chắc
     * chắn liên quan hơn entry không xuất hiện, không cần thống kê phức
     * tạp hơn để có tín hiệu tốt. Trong nhóm cùng KHÔNG xuất hiện (dict
     * lớn hơn maxEntries nhiều), giữ thứ tự chèn cũ làm tie-break (ổn định,
     * dễ đoán hành vi hơn xáo trộn ngẫu nhiên).
     */
    fun buildInjectionText(chapterText: String = "", maxEntries: Int = 30): String {
        if (dict.isEmpty()) return ""
        val entries = if (dict.size <= maxEntries || chapterText.isBlank()) {
            // Dict còn nhỏ (chưa cần cắt) HOẶC không có văn bản chương để
            // so khớp (caller cũ chưa truyền) -> giữ nguyên hành vi cũ
            // (30 entry đầu theo thứ tự chèn), không đổi gì cho case này.
            dict.entries.take(maxEntries)
        } else {
            val lowerText = chapterText.lowercase()
            dict.entries.toList()
                .sortedByDescending { (concept, _) ->
                    // đếm số lần xuất hiện literal — 0 nếu không xuất hiện.
                    var count = 0
                    var idx = lowerText.indexOf(concept.lowercase())
                    while (idx >= 0) {
                        count++
                        idx = lowerText.indexOf(concept.lowercase(), idx + 1)
                    }
                    count
                }
                .take(maxEntries)
        }
        val text = entries.joinToString("; ") { "\"${it.key}\"=\"${it.value}\"" }
        return "📖 TỪ ĐIỂN KHÁI NIỆM CỐ ĐỊNH (luôn dùng đúng bản này, KHÔNG tự ý dịch khác):\n$text"
    }

    private fun persist() {
        try {
            val json = JSONObject()
            dict.forEach { (k, v) -> json.put(k, v) }
            file.writeText(json.toString(2))
        } catch (_: Exception) {}
    }
}
