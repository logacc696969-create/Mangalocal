package com.mangalocal.pipeline

import com.mangalocal.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ImagePipeline(private val storyManager: StoryManager) {

    private var sdCtx: Long = 0
    private var sdAugmentedCtx: Long = 0
    private var loadedAugmentedDir = ""
    // mục 177 TECHNICAL_STATUS.md — SDXL Phase 2b, ctx RIÊNG (KHÔNG dùng
    // chung sdAugmentedCtx — model/pipeline C++ hoàn toàn khác nhau, xem
    // ip_adapter_sdxl.cpp).
    private var sdAugmentedSdxlCtx: Long = 0
    private var loadedAugmentedSdxlDir = ""
    private var loadedAugmentedSdxlEmbeddingsSig = ""
    // mục 207 TECHNICAL_STATUS.md — PLAIN SDXL (KHÔNG IP-Adapter), ctx
    // RIÊNG khỏi sdAugmentedSdxlCtx (mirror lý do sdCtx tách khỏi
    // sdAugmentedCtx — model/pipeline khác nhau: PipelineSdxlCpu thường vs
    // PipelineSdxlCpuAugmented). Dùng cho img2imgFixSdxl() (auto-fix vùng
    // nhỏ) — xem sdInitSdxl() trong NativeBridge.kt.
    private var sdSdxlCtx: Long = 0
    private var loadedSdxlDir = ""
    private var loadedSdxlEmbeddingsSig = ""
    private var esrganCtx: Long = 0
    private var loadedSdPath = ""
    // mục 144 TECHNICAL_STATUS.md — fingerprint thư mục Textual Inversion
    // embeddings đã nạp lần gần nhất cho MỖI pipeline (base/augmented) —
    // xem embeddingsSignature() bên dưới + giải thích tại loadSD().
    private var loadedSdEmbeddingsSig = ""
    private var loadedAugmentedEmbeddingsSig = ""

    /**
     * mục 144 TECHNICAL_STATUS.md — đóng gap "cache loadSD() không reload
     * khi Textual Inversion embeddings đổi giữa chừng" (còn treo từ mục 13
     * archive). Thay vì theo dõi TOÀN BỘ nội dung file (tốn, không cần
     * thiết — embeddings không sửa tại chỗ, chỉ thêm/xoá), chỉ cần fingerprint
     * RẺ: nối tên file + kích thước + lastModified của mọi file trong
     * `embeddingsDir` (sắp xếp theo tên để ổn định thứ tự) — đủ để phát hiện
     * thêm/xoá/ghi đè file mà không phải đọc nội dung .safetensors (có thể
     * vài chục MB/file). Thư mục không tồn tại/rỗng -> chuỗi rỗng ổn định,
     * không lỗi.
     */
    private fun embeddingsSignature(embeddingsDir: String): String {
        if (embeddingsDir.isBlank()) return ""
        val dir = File(embeddingsDir)
        val files = dir.listFiles() ?: return ""
        return files.sortedBy { it.name }
            .joinToString("|") { "${it.name}:${it.length()}:${it.lastModified()}" }
    }

    /**
     * Nạp pipeline "augmented" (IP-Adapter + ControlNet-Pose) — dùng
     * unet_ipa_controlnet.mnn xuất bởi tools/export_ipa_controlnet_unet.py,
     * KHÁC HẲN unet.mnn thường của loadSD(). Chỉ gọi khi thật sự cần giữ
     * nhất quán nhân vật (settings.useStoryDiffusion), không phải lúc nào
     * cũng nạp vì UNet augmented nặng hơn UNet thường (thêm ControlNet).
     */
    suspend fun loadSDAugmented(modelDir: String, embeddingsDir: String,
                                useOpenCL: Boolean = false, useNpu: Boolean = false) = withContext(Dispatchers.IO) {
        // mục 144 — reload nếu ĐỔI thư mục model HOẶC embeddings đã đổi
        // (thêm/xoá/ghi đè file Textual Inversion) kể từ lần nạp trước, xem
        // embeddingsSignature() + giải thích đầy đủ tại loadSD() bên dưới.
        val embSig = embeddingsSignature(embeddingsDir)
        if (modelDir == loadedAugmentedDir && embSig == loadedAugmentedEmbeddingsSig) return@withContext
        if (sdAugmentedCtx != 0L) { NativeBridge.sdFreeAugmented(sdAugmentedCtx); sdAugmentedCtx = 0 }
        sdAugmentedCtx = NativeBridge.sdInitAugmented(
            modelDir,
            "$modelDir/clip.mnn",
            "$modelDir/unet_ipa_controlnet.mnn",
            "$modelDir/vae_decoder.mnn",
            "$modelDir/vae_encoder.mnn",
            "$modelDir/ip_image_encoder.mnn",
            "$modelDir/tokenizer.json",
            embeddingsDir,
            useOpenCL, useNpu
        )
        if (sdAugmentedCtx == 0L) throw RuntimeException(
            "Không load được pipeline augmented tại $modelDir.\n" +
            "Kiểm tra đã chạy tools/export_ipa_controlnet_unet.py và convert sang .mnn chưa.\n" +
            "(xem logcat tag MangaLocal_IPAdapter)")
        loadedAugmentedDir = modelDir
        loadedAugmentedEmbeddingsSig = embSig
        // mục 67 TECHNICAL_STATUS.md — dùng CHUNG sdAugmentedCtx với bản
        // multi-char bên dưới, phải vô hiệu cache của bản đó (nếu không, gọi
        // xen kẽ 1-người/N-người sẽ tưởng nhầm N-char ctx vẫn còn hợp lệ).
        loadedMultiCharDir = ""; loadedMultiCharN = 0; loadedMultiCharWithLocation = false
    }

    /**
     * mục 177 TECHNICAL_STATUS.md — SDXL Phase 2b. Bản SDXL tương đương
     * loadSDAugmented() ở trên, dùng unet_ipa_controlnet_sdxl.mnn +
     * ip_image_encoder_sdxl.mnn xuất bởi
     * tools/export_ipa_controlnet_unet_sdxl.py. CHỈ phần cơ bản (1 nhân
     * vật, IP-Adapter + ControlNet-Pose) — xem "PHẠM VI" đầu
     * ip_adapter_sdxl.cpp. CHƯA build-test — xem GIỚI HẠN THẬT đầu file đó.
     */
    suspend fun loadSDAugmentedSdxl(modelDir: String, embeddingsDir: String,
                                     useOpenCL: Boolean = false, useNpu: Boolean = false) = withContext(Dispatchers.IO) {
        val embSig = embeddingsSignature(embeddingsDir)
        if (modelDir == loadedAugmentedSdxlDir && embSig == loadedAugmentedSdxlEmbeddingsSig) return@withContext
        if (sdAugmentedSdxlCtx != 0L) { NativeBridge.sdFreeAugmentedSdxl(sdAugmentedSdxlCtx); sdAugmentedSdxlCtx = 0 }
        sdAugmentedSdxlCtx = NativeBridge.sdInitAugmentedSdxl(
            modelDir,
            "$modelDir/clip_l.mnn",
            "$modelDir/clip_g.mnn",
            "$modelDir/unet_ipa_controlnet_sdxl.mnn",
            "$modelDir/vae_decoder.mnn",
            "$modelDir/vae_encoder.mnn",
            "$modelDir/ip_image_encoder_sdxl.mnn",
            "$modelDir/tokenizer.json",
            embeddingsDir,
            useOpenCL, useNpu
        )
        if (sdAugmentedSdxlCtx == 0L) throw RuntimeException(
            "Không load được pipeline augmented SDXL tại $modelDir.\n" +
            "Kiểm tra đã chạy tools/export_ipa_controlnet_unet_sdxl.py và convert sang .mnn chưa.\n" +
            "(xem logcat tag MangaLocal_IPAdapterSDXL)")
        loadedAugmentedSdxlDir = modelDir
        loadedAugmentedSdxlEmbeddingsSig = embSig
        // mục 178 — vô hiệu cache bản mask N-nhân-vật (dùng CHUNG
        // sdAugmentedSdxlCtx), mirror ĐÚNG lý do mục 67 (SD1.5).
        loadedMultiCharSdxlDir = ""; loadedMultiCharSdxlN = 0; loadedMultiCharSdxlWithLocation = false
    }

    // mục 207 TECHNICAL_STATUS.md — PLAIN SDXL, dùng file `unet_sdxl.mnn`
    // (KHÔNG phải `unet_ipa_controlnet_sdxl.mnn`) — mirror ĐÚNG
    // loadSDAugmentedSdxl() ở trên nhưng bỏ ip_image_encoder (không cần IP-
    // Adapter cho auto-fix vùng nhỏ). `unet_sdxl.mnn`/clip/vae/tokenizer
    // ĐÃ được prepare_models.yml export + copy CÙNG thư mục với model
    // augmented (mục 59) — không cần user làm gì thêm nếu đã có SDXL chạy
    // được, xem GIỚI HẠN THẬT ở comment C++ tương ứng.
    suspend fun loadSDSdxl(modelDir: String, embeddingsDir: String,
                           useOpenCL: Boolean = false, useNpu: Boolean = false) = withContext(Dispatchers.IO) {
        val embSig = embeddingsSignature(embeddingsDir)
        if (modelDir == loadedSdxlDir && embSig == loadedSdxlEmbeddingsSig) return@withContext
        if (sdSdxlCtx != 0L) { NativeBridge.sdFreeSdxl(sdSdxlCtx); sdSdxlCtx = 0 }
        sdSdxlCtx = NativeBridge.sdInitSdxl(
            modelDir,
            "$modelDir/clip_l.mnn",
            "$modelDir/clip_g.mnn",
            "$modelDir/unet_sdxl.mnn",
            "$modelDir/vae_decoder.mnn",
            "$modelDir/vae_encoder.mnn",
            "$modelDir/tokenizer.json",
            embeddingsDir,
            useOpenCL, useNpu
        )
        if (sdSdxlCtx == 0L) throw RuntimeException(
            "Không load được pipeline SDXL thường (auto-fix) tại $modelDir.\n" +
            "Cần file unet_sdxl.mnn trong thư mục này — tự có sẵn nếu đã bật " +
            "export_sdxl_base_variant HOẶC export_sdxl_augmented_variant lúc chạy " +
            "prepare_models.yml (mục 59/207); nếu thiếu, chạy lại workflow đó.\n" +
            "(xem logcat tag MangaLocal_IPAdapterSDXL)")
        loadedSdxlDir = modelDir
        loadedSdxlEmbeddingsSig = embSig
    }

    fun isSdxlBaseLoaded() = sdSdxlCtx != 0L

    // ĐỔI CHỮ KÝ: modelPath/loraPath/loraWeight/nThreads/useVulkan (thời
    // sd.cpp) -> modelDir/modelId/useOpenCL (thời MNN + model_manifest.json).
    // Lý do đổi: MNN cần NHIỀU file trong 1 thư mục (clip/unet/vae_decoder/
    // vae_encoder/tokenizer...), không phải 1 file .gguf/.safetensors duy
    // nhất như sd.cpp — nên đổi sang trỏ thư mục + id trong manifest thay vì
    // đường dẫn 1 file. Không giữ được chữ ký cũ ở lần đổi này.
    // mục 144 TECHNICAL_STATUS.md — ĐÃ ĐÓNG gap cache embeddings (trước ghi
    // "CẢNH BÁO CACHE (chưa xử lý)" ở đây — không còn đúng): giờ reload nếu
    // `embeddingsSignature(embeddingsDir)` khác lần nạp trước, kể cả khi
    // `modelId` không đổi — vd user vừa gán Textual Inversion cho 1 nhân vật
    // ngay trước khi generate tiếp, embedding mới được nạp NGAY, không phải
    // đợi đổi model khác rồi quay lại hay restart app.
    suspend fun loadSD(modelDir: String, modelId: String, useOpenCL: Boolean, embeddingsDir: String,
                       useNpu: Boolean = false, socModel: String = "") =
        withContext(Dispatchers.IO) {
            val embSig = embeddingsSignature(embeddingsDir)
            if (modelId == loadedSdPath && embSig == loadedSdEmbeddingsSig) return@withContext
            if (sdCtx != 0L) { NativeBridge.sdFree(sdCtx); sdCtx = 0 }
            sdCtx = NativeBridge.sdInit(modelDir, modelId, useOpenCL, embeddingsDir, useNpu, socModel)
            if (sdCtx == 0L) throw RuntimeException("Không load được SD model: $modelId\n(xem logcat tag MangaLocal_SDEngine để biết lý do cụ thể)")
            loadedSdPath = modelId
            loadedSdEmbeddingsSig = embSig
        }

    suspend fun loadEsrgan(scale: Int) = withContext(Dispatchers.IO) {
        if (esrganCtx != 0L || scale <= 1) return@withContext
        if (!storyManager.hasEsrgan()) throw RuntimeException(
            "Thiếu ESRGAN model.\nĐặt vào: ${storyManager.esrganDir.absolutePath}")
        esrganCtx = NativeBridge.esrganInit(scale, storyManager.esrganDir.absolutePath)
        if (esrganCtx == 0L) throw RuntimeException("ESRGAN init thất bại")
    }

    // mục 67 TECHNICAL_STATUS.md — bản N NHÂN VẬT (mục 52b) song song với
    // loadSDAugmented() ở trên (bản 1 nhân vật). unet TRỎ ĐÚNG file
    // unet_ipa_mask_controlnet_{N}char.mnn (mỗi N một file riêng, không
    // dùng chung — xem comment mục 52b/NativeBridge.kt). numCharacters
    // PHẢI khớp đúng N của file model, KHÔNG tự suy — gọi sai N sẽ ra
    // input embedding/mask shape lệch (native tự cắt/điền theo comment
    // ip_adapter.cpp nhưng vẫn nên gọi đúng N ngay từ đầu).
    private var loadedMultiCharDir = ""
    private var loadedMultiCharN = 0
    // mục 217 (đợt 2) TECHNICAL_STATUS.md — "Location Anchor" slot thứ
    // N+1. Model "_loc" và model không hậu tố có shape ip_image_embeds
    // KHÁC NHAU dù cùng numCharacters (N vs N+1 slot) — PHẢI coi là 2
    // "model đã nạp" khác nhau trong cache, không chỉ dựa vào modelDir/N
    // như trước, nếu không sẽ tưởng nhầm đã nạp đúng model.
    private var loadedMultiCharWithLocation = false
    // mục 178 TECHNICAL_STATUS.md — SDXL Phase 2c. Dùng CHUNG sdAugmentedSdxlCtx
    // với bản 1-người (mirror mục 67 — cùng lý do: model 1-người/N-người
    // KHÔNG bao giờ cần cùng lúc trong 1 phiên sinh ảnh, tái dùng ctx đỡ
    // tốn RAM hơn giữ 2 bản UNet SDXL ~2.6B tham số cùng lúc).
    private var loadedMultiCharSdxlDir = ""
    private var loadedMultiCharSdxlN = 0
    // mục 218 TECHNICAL_STATUS.md — mirror ĐÚNG loadedMultiCharWithLocation
    // (SD1.5) — model "_loc" và không "_loc" có shape ip_image_embeds khác
    // nhau dù cùng numCharacters, phải coi là 2 model "đã nạp" khác nhau.
    private var loadedMultiCharSdxlWithLocation = false
    // mục 179 TECHNICAL_STATUS.md — SDXL Phase 2d. Ctx RIÊNG (model +
    // input hoàn toàn khác — mirror ĐÚNG lý do sdRegionalCtx tách khỏi
    // sdAugmentedCtx ở bản SD1.5).
    private var sdRegionalSdxlCtx: Long = 0
    private var loadedRegionalSdxlDir = ""
    private var loadedRegionalSdxlN = -1
    // mục 180 TECHNICAL_STATUS.md — SDXL Phase 2e. Ctx RIÊNG (mirror
    // sdRegionalMaskCtx tách khỏi sdRegionalCtx ở bản SD1.5).
    private var sdRegionalMaskSdxlCtx: Long = 0
    private var loadedRegionalMaskSdxlDir = ""
    private var loadedRegionalMaskSdxlN = -1
    suspend fun loadSDAugmentedMultiChar(modelDir: String, embeddingsDir: String, numCharacters: Int,
                                          useOpenCL: Boolean = false, useNpu: Boolean = false,
                                          // mục 217 (đợt 2) — nạp biến thể "_loc" (N+1 slot, slot cuối
                                          // dành cho ảnh neo bối cảnh) thay vì bản N slot thường. Gọi nơi
                                          // này PHẢI đi kèm StoryManager.hasMultiCharMaskUnetWithLocation()
                                          // đã trả true từ trước (MangaPipeline.kt) — hàm này KHÔNG tự
                                          // kiểm tra, chỉ tự ghép tên file.
                                          withLocationSlot: Boolean = false) = withContext(Dispatchers.IO) {
        if (modelDir == loadedMultiCharDir && numCharacters == loadedMultiCharN && withLocationSlot == loadedMultiCharWithLocation) return@withContext
        if (sdAugmentedCtx != 0L) { NativeBridge.sdFreeAugmented(sdAugmentedCtx); sdAugmentedCtx = 0 }
        val locSuffix = if (withLocationSlot) "_loc" else ""
        val unetPath = "$modelDir/unet_ipa_mask_controlnet_${numCharacters}char${locSuffix}.mnn"
        sdAugmentedCtx = NativeBridge.sdInitAugmented(
            modelDir,
            "$modelDir/clip.mnn",
            unetPath,
            "$modelDir/vae_decoder.mnn",
            "$modelDir/vae_encoder.mnn",
            "$modelDir/ip_image_encoder.mnn",
            "$modelDir/tokenizer.json",
            embeddingsDir,
            useOpenCL, useNpu
        )
        if (sdAugmentedCtx == 0L) throw RuntimeException(
            "Không load được pipeline augmented $numCharacters-nhân-vật${if (withLocationSlot) " + bối cảnh" else ""} tại $modelDir.\n" +
            "Thiếu file $unetPath — kiểm tra đã chạy tools/export_ipa_controlnet_mask_unet.py " +
            "--num_characters $numCharacters" + (if (withLocationSlot) " --with_location_slot" else "") + " và convert sang .mnn chưa.\n(xem logcat tag MangaLocal_IPAdapter)")
        loadedMultiCharDir = modelDir
        loadedMultiCharN = numCharacters
        loadedMultiCharWithLocation = withLocationSlot
        // Vô hiệu cache của loadSDAugmented() bản 1-nhân-vật (dùng chung
        // sdAugmentedCtx) để lần gọi generatePanel() 1-nhân-vật kế tiếp
        // không tưởng nhầm đã nạp đúng unet, tự nạp lại.
        loadedAugmentedDir = ""
    }

    /**
     * mục 67 TECHNICAL_STATUS.md — nối dây thật sdTxt2ImgWithCharactersAndPose
     * (mục 52b, native đã xong từ trước nhưng CHƯA có nơi nào trong Kotlin
     * gọi tới — xác nhận qua grep, đây là điểm sửa chính của mục này).
     * referenceImagePaths/skeletonData PHẢI cùng thứ tự nhân vật (invariant
     * mục 32/33/52b) — MangaPipeline chịu trách nhiệm đảm bảo thứ tự khớp
     * scene.characters trước khi gọi hàm này.
     */
    suspend fun generatePanelMultiChar(
        panelIndex: Int, prompt: String, negativePrompt: String, stylePrompt: String,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        referenceImagePaths: List<String>, skeletonData: FloatArray,
        outDir: File, onProgress: (Int, Int) -> Unit,
        // mục 100 — Smooth Timestep Decay + consistencyStrength, mở rộng
        // mục 97/99 sang đường mask N-nhân-vật. Default = không đổi gì.
        ipDecayFloor: Float = 1.0f,
        ipDecayStartTimestep: Float = 999.0f,
        ipStaticScale: Float = 1.0f,
        // mục 147 TECHNICAL_STATUS.md — Per-Instance Decay: 3 mảng TUỲ
        // CHỌN, PHẢI cùng độ dài `referenceImagePaths` nếu truyền (1 giá
        // trị/nhân vật, cùng thứ tự). null (mặc định) = dùng 3 scalar
        // trên cho MỌI nhân vật, tương thích ngược tuyệt đối.
        ipDecayFloors: FloatArray? = null,
        ipDecayStartTimesteps: FloatArray? = null,
        ipStaticScales: FloatArray? = null,
        // mục 217 (đợt 2) TECHNICAL_STATUS.md — "Location Anchor" slot
        // thứ N+1. null = không dùng (mặc định, tương thích ngược tuyệt
        // đối). CHỈ có tác dụng nếu `sdAugmentedCtx` hiện đang trỏ tới
        // model .mnn export với `--with_location_slot` (đuôi "_loc") —
        // gọi hàm này với locationAnchorPath khác null trong khi model
        // đang nạp KHÔNG có slot bối cảnh sẽ KHÔNG lỗi (native tự bỏ qua,
        // xem GIỚI HẠN THẬT ip_adapter.cpp) nhưng CŨNG không có tác dụng
        // gì — MangaPipeline.kt PHẢI tự đảm bảo nạp đúng model trước khi
        // truyền tham số này (xem hasMultiCharMaskUnetWithLocation()).
        locationAnchorPath: String? = null,
        locationScale: Float = 0.5f
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val fullPrompt = prompt + ", " + stylePrompt
        // mục 134 TECHNICAL_STATUS.md — trước đây báo tiến trình GIẢ ("0
        // rồi nhảy thẳng lên steps") vì sdTxt2ImgWithCharactersAndPose
        // KHÔNG có callback per-step ở tầng native. Đã nối THẬT (xem
        // ip_adapter.cpp) — dùng ĐÚNG khuôn mẫu SDProgressCallback đã dùng
        // cho sdTxt2Img/sdImg2Img, không còn gọi onProgress(0,steps) giả.
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        // mục 161 TECHNICAL_STATUS.md — ghi ngữ cảnh crash TRƯỚC lời gọi
        // native rủi ro cao, để log crash (nếu có) biết đúng panel/hàm nào.
        NativeBridge.setCrashContext("generatePanelMultiChar panel=$panelIndex chars=${referenceImagePaths.size}" + (if (locationAnchorPath != null) " +loc" else ""))
        val ok = NativeBridge.sdTxt2ImgWithCharactersAndPose(
            sdAugmentedCtx, fullPrompt, negativePrompt,
            referenceImagePaths.toTypedArray(), skeletonData,
            width, height, steps, cfgScale, seed,
            outFile.absolutePath,
            ipDecayFloor, ipDecayStartTimestep, ipStaticScale,
            ipDecayFloors, ipDecayStartTimesteps, ipStaticScales,
            locationAnchorPath, locationScale, cb
        )
        if (!ok) throw RuntimeException("SD generate (multi-char mask) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // mục 69 TECHNICAL_STATUS.md — nối dây thật sdTxt2ImgRegional (mục 56,
    // native đã xong từ trước nhưng CHƯA có nơi nào trong Kotlin gọi tới —
    // xác nhận qua grep, giống hệt tình huống mục 67). unet TRỎ ĐÚNG file
    // unet_regional_controlnet_{N}col.mnn (xem tools/export_ipa_controlnet_
    // regional_unet.py — mỗi N cần 1 file riêng, không dynamic_axes).
    private var loadedRegionalDir = ""
    private var loadedRegionalN = 0
    private var sdRegionalCtx: Long = 0
    suspend fun loadSDRegional(modelDir: String, embeddingsDir: String, numRegions: Int,
                                useOpenCL: Boolean = false, useNpu: Boolean = false) = withContext(Dispatchers.IO) {
        if (modelDir == loadedRegionalDir && numRegions == loadedRegionalN) return@withContext
        if (sdRegionalCtx != 0L) { NativeBridge.sdFreeRegional(sdRegionalCtx); sdRegionalCtx = 0 }
        val unetPath = "$modelDir/unet_regional_controlnet_${numRegions}col.mnn"
        sdRegionalCtx = NativeBridge.sdInitRegional(
            modelDir, "$modelDir/clip.mnn", unetPath,
            "$modelDir/vae_decoder.mnn", "$modelDir/vae_encoder.mnn",
            "$modelDir/tokenizer.json", embeddingsDir, numRegions, useOpenCL, useNpu
        )
        if (sdRegionalCtx == 0L) throw RuntimeException(
            "Không load được pipeline Regional Prompting tại $modelDir.\n" +
            "Thiếu file $unetPath — kiểm tra đã chạy tools/export_ipa_controlnet_regional_unet.py " +
            "--num_regions $numRegions và convert sang .mnn chưa.\n(xem logcat tag MangaLocal_Regional)")
        loadedRegionalDir = modelDir
        loadedRegionalN = numRegions
    }

    /**
     * mục 69 TECHNICAL_STATUS.md — regionPrompts THỨ TỰ trái->phải, PHẢI
     * khớp đúng numRegions đã dùng lúc loadSDRegional(). controlHintRgb lấy
     * qua NativeBridge.renderSkeletonCanvas() (dùng LẠI renderSkeletons()
     * native — KHÔNG tự vẽ skeleton ở Kotlin, xem comment tại đó).
     */
    suspend fun generatePanelRegional(
        panelIndex: Int, regionPrompts: List<String>, negativePrompt: String,
        skeletonData: FloatArray, width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outDir: File, onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val controlSize = 512
        val controlHint = NativeBridge.renderSkeletonCanvas(skeletonData, controlSize)
        if (controlHint.isEmpty()) {
            // mục 69 — skeletonData rỗng/lỗi format: renderSkeletonCanvas()
            // trả mảng rỗng thay vì throw (xem comment native). Tự tạo
            // canvas ĐEN (toàn 0) đúng kích thước thay vì để native nhận
            // mảng sai độ dài rồi lỗi khó hiểu hơn — tương đương "không có
            // gợi ý tư thế nào" (ControlNet vẫn chạy được, chỉ không có
            // hint, đúng hành vi fallback của renderSkeletons() khi rỗng).
        }
        val safeHint = if (controlHint.size == controlSize * controlSize * 3) controlHint
            else ByteArray(controlSize * controlSize * 3)
        // mục 134 — nối progress callback per-step thật (trước đây gọi
        // onProgress(0,steps) giả rồi nhảy thẳng lên steps, xem ghi chú ở
        // generatePanelMultiChar() phía trên cho lý do đầy đủ).
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        NativeBridge.setCrashContext("generatePanelRegional panel=$panelIndex regions=${regionPrompts.size}")
        val ok = NativeBridge.sdTxt2ImgRegional(
            sdRegionalCtx, regionPrompts.toTypedArray(), negativePrompt,
            safeHint, controlSize, width, height, steps, cfgScale, seed, outFile.absolutePath, cb
        )
        if (!ok) throw RuntimeException("SD generate (regional) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // mục 172 TECHNICAL_STATUS.md — đối tác "mask hình dạng tuỳ ý" của
    // sdRegionalCtx/loadSDRegional() ngay trên (bản CỘT). Ctx RIÊNG — model
    // + input khác hẳn (thêm background prompt + mask thật thay vì suy cột
    // từ numRegions), không dùng chung được.
    private var sdRegionalMaskCtx: Long = 0
    private var loadedRegionalMaskDir = ""
    private var loadedRegionalMaskN = -1

    suspend fun loadSDRegionalMask(modelDir: String, embeddingsDir: String, numRegions: Int,
                                    useOpenCL: Boolean = false, useNpu: Boolean = false) = withContext(Dispatchers.IO) {
        if (modelDir == loadedRegionalMaskDir && numRegions == loadedRegionalMaskN) return@withContext
        if (sdRegionalMaskCtx != 0L) { NativeBridge.sdFreeRegionalMask(sdRegionalMaskCtx); sdRegionalMaskCtx = 0 }
        val unetPath = "$modelDir/unet_regional_mask_controlnet_${numRegions}char.mnn"
        sdRegionalMaskCtx = NativeBridge.sdInitRegionalMask(
            modelDir, "$modelDir/clip.mnn", unetPath,
            "$modelDir/vae_decoder.mnn", "$modelDir/vae_encoder.mnn",
            "$modelDir/tokenizer.json", embeddingsDir, numRegions, useOpenCL, useNpu
        )
        if (sdRegionalMaskCtx == 0L) throw RuntimeException(
            "Không load được pipeline Regional-Mask tại $modelDir.\n" +
            "Thiếu file $unetPath — kiểm tra đã chạy tools/export_ipa_controlnet_regional_mask_unet.py " +
            "--num_regions $numRegions và convert sang .mnn chưa.\n(xem logcat tag MangaLocal_RegionalMask)")
        loadedRegionalMaskDir = modelDir
        loadedRegionalMaskN = numRegions
    }

    fun isRegionalMaskLoaded() = sdRegionalMaskCtx != 0L

    /**
     * mục 172 TECHNICAL_STATUS.md — regionPrompts/regionMasks PHẢI CÙNG SỐ
     * LƯỢNG, CÙNG THỨ TỰ (khối i của regionMasks khớp regionPrompts[i]) —
     * KHÁC generatePanelRegional() ở trên: thứ tự này KHÔNG còn nghĩa
     * "trái->phải" (mask hình dạng tuỳ ý, không phải cột), chỉ cần khớp
     * ĐÚNG cặp prompt-mask. `regionMasks` là 1 mảng byte PHẲNG, N khối liên
     * tiếp, MỖI khối `width*height` byte (1 kênh, 0-255) — gọi từ
     * MangaPipeline.buildRegionMasksForPanel() (dựng bằng
     * buildCharacterBodyMaskFile(), mục 168/172). `backgroundPrompt` cho
     * phần ảnh không nhân vật nào claim — KHÔNG được để rỗng (model luôn
     * cần 1 embedding hợp lệ ở input này, chuỗi rỗng vẫn encode được,
     * chỉ là vector gần-neutral, không throw, nhưng NÊN truyền prompt scene
     * thật để hậu cảnh không trống trơn).
     */
    suspend fun generatePanelRegionalMask(
        panelIndex: Int, regionPrompts: List<String>, backgroundPrompt: String, negativePrompt: String,
        regionMasks: ByteArray, skeletonData: FloatArray, width: Int, height: Int,
        steps: Int, cfgScale: Float, seed: Long, outDir: File, onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val controlSize = 512
        val controlHint = NativeBridge.renderSkeletonCanvas(skeletonData, controlSize)
        val safeHint = if (controlHint.size == controlSize * controlSize * 3) controlHint
            else ByteArray(controlSize * controlSize * 3) // cùng fallback "khung đen" như generatePanelRegional()
        val expectedMaskBytes = regionPrompts.size * width * height
        if (regionMasks.size != expectedMaskBytes) {
            // mục 172 — log rõ thay vì throw cứng (cùng triết lý "log +
            // vẫn thử chạy" đã dùng ở phía native cho đúng trường hợp này) —
            // nhưng ở TẦNG KOTLIN này, sai kích thước gần như chắc chắn là
            // BUG gọi hàm sai (không phải dữ liệu người dùng), nên throw ở
            // đây AN TOÀN hơn để lộ lỗi ngay lúc phát triển thay vì để native
            // âm thầm cắt/thiếu byte.
            throw IllegalArgumentException(
                "generatePanelRegionalMask: regionMasks.size=${regionMasks.size}, kỳ vọng " +
                "$expectedMaskBytes (= ${regionPrompts.size} vùng x ${width}x$height) — buildRegionMasksForPanel() " +
                "có đang dùng đúng width/height của panel này không?")
        }
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        NativeBridge.setCrashContext("generatePanelRegionalMask panel=$panelIndex regions=${regionPrompts.size}")
        val ok = NativeBridge.sdTxt2ImgRegionalMask(
            sdRegionalMaskCtx, regionPrompts.toTypedArray(), backgroundPrompt, negativePrompt,
            regionMasks, safeHint, controlSize, width, height, steps, cfgScale, seed, outFile.absolutePath, cb
        )
        if (!ok) throw RuntimeException("SD generate (regional-mask) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // mục 151 TECHNICAL_STATUS.md — Triple-Conditioning combo. ctx RIÊNG
    // (không dùng chung sdRegionalCtx/sdAugmentedCtx — model + input khác
    // hẳn cả 2), tên file .mnn theo ĐÚNG convention export script
    // (`unet_triple_combo_{N}region.mnn`, xem tools/export_ipa_controlnet_
    // triple_combo_unet.py).
    private var sdTripleComboCtx: Long = 0
    private var loadedTripleComboDir = ""
    private var loadedTripleComboN = -1
    // mục 219 TECHNICAL_STATUS.md — mirror ĐÚNG loadedMultiCharWithLocation
    // (mục 217 đợt 2) — model "_loc" và không "_loc" có shape khác nhau
    // (thêm 2 input location_ip_embeds/location_scale) dù cùng numRegions.
    private var loadedTripleComboWithLocation = false

    // mục 222-225 TECHNICAL_STATUS.md — GLIGEN, pipeline HOÀN TOÀN RIÊNG
    // (không dùng chung sdAugmentedCtx/sdTripleComboCtx — model +
    // gligen_wrapper.cpp riêng, xem NativeBridge.kt).
    private var sdGligenCtx: Long = 0
    private var loadedGligenDir = ""
    // mục 226 — model "_char" (GLIGEN + IP-Adapter) và không "_char" là 2 file
    // .mnn KHÁC NHAU cùng thư mục: phải coi là 2 model "đã nạp" khác nhau
    // trong cache (mirror loadedMultiCharWithLocation, mục 217 đợt 2).
    private var loadedGligenWithCharacter = false

    suspend fun loadSDTripleCombo(modelDir: String, embeddingsDir: String, numRegions: Int,
                                   useOpenCL: Boolean = false, useNpu: Boolean = false,
                                   // mục 219 — mirror ĐÚNG loadSDAugmentedMultiChar() (mục 217 đợt 2).
                                   withLocationSlot: Boolean = false) = withContext(Dispatchers.IO) {
        if (modelDir == loadedTripleComboDir && numRegions == loadedTripleComboN && withLocationSlot == loadedTripleComboWithLocation) return@withContext
        if (sdTripleComboCtx != 0L) { NativeBridge.sdFreeTripleCombo(sdTripleComboCtx); sdTripleComboCtx = 0 }
        val locSuffix = if (withLocationSlot) "_loc" else ""
        val unetPath = "$modelDir/unet_triple_combo_${numRegions}region${locSuffix}.mnn"
        val ipEncoderPath = "$modelDir/ip_image_encoder.mnn"
        sdTripleComboCtx = NativeBridge.sdInitTripleCombo(
            modelDir, "$modelDir/clip.mnn", unetPath,
            "$modelDir/vae_decoder.mnn", "$modelDir/vae_encoder.mnn",
            ipEncoderPath, "$modelDir/tokenizer.json", embeddingsDir, numRegions, useOpenCL, useNpu
        )
        if (sdTripleComboCtx == 0L) throw RuntimeException(
            "Không load được pipeline Triple-Conditioning combo${if (withLocationSlot) " + bối cảnh" else ""} tại $modelDir.\n" +
            "Thiếu file $unetPath hoặc $ipEncoderPath — kiểm tra đã chạy tools/export_ipa_controlnet_triple_combo_unet.py " +
            "--num_regions $numRegions" + (if (withLocationSlot) " --with_location_slot" else "") + " và convert sang .mnn chưa.\n(xem logcat tag MangaLocal_TripleCombo)")
        loadedTripleComboDir = modelDir
        loadedTripleComboN = numRegions
        loadedTripleComboWithLocation = withLocationSlot
    }

    fun isTripleComboLoaded() = sdTripleComboCtx != 0L

    /**
     * mục 151 TECHNICAL_STATUS.md — regionPrompts/referenceImagePaths PHẢI
     * CÙNG ĐỘ DÀI, CÙNG THỨ TỰ (1 cột = 1 nhân vật, khớp cả prompt chữ lẫn
     * danh tính ảnh — xem GIỚI HẠN THẬT trong docstring export script:
     * ranh giới cột cứng, KHÔNG phù hợp cảnh ôm/đan xen). Tái dùng
     * renderSkeletonCanvas()/renderDepthHintCanvas() y hệt generatePanelRegional()
     * ở trên — 2 canvas RIÊNG (pose + depth), không phải 1.
     */
    suspend fun generatePanelTripleCombo(
        panelIndex: Int, regionPrompts: List<String>, negativePrompt: String,
        referenceImagePaths: List<String>, skeletonData: FloatArray,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outDir: File, onProgress: (Int, Int) -> Unit,
        poseScale: Float = 1.0f, depthScale: Float = 0.6f,
        ipDecayFloor: Float = 1.0f, ipDecayStartTimestep: Float = 999.0f,
        // mục 219 TECHNICAL_STATUS.md — "Location Anchor" đợt 3, mirror
        // ĐÚNG generatePanelMultiChar()/generatePanelMultiCharSdxl() (mục
        // 217/218) nhưng CƠ CHẾ ÁP DỤNG BÊN NATIVE KHÁC HẲN (cộng thêm 1
        // lượt IP-Adapter toàn ảnh, không phải 1 slot mask N+1 — xem GIỚI
        // HẠN THẬT trong tools/export_ipa_controlnet_triple_combo_unet.py
        // mục "mục 219", công thức MỚI chưa verify thực nghiệm).
        locationAnchorPath: String? = null, locationScale: Float = 0.5f
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val controlSize = 512
        val poseHint = NativeBridge.renderSkeletonCanvas(skeletonData, controlSize)
        val depthHint = NativeBridge.renderDepthHintCanvas(skeletonData, controlSize)
        val blankHint = ByteArray(controlSize * controlSize * 3)
        val safePoseHint = if (poseHint.size == blankHint.size) poseHint else blankHint
        val safeDepthHint = if (depthHint.size == blankHint.size) depthHint else blankHint
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        NativeBridge.setCrashContext("generatePanelTripleCombo panel=$panelIndex chars=${referenceImagePaths.size}" + (if (locationAnchorPath != null) " +loc" else ""))
        val ok = NativeBridge.sdTxt2ImgTripleCombo(
            sdTripleComboCtx, regionPrompts.toTypedArray(), negativePrompt,
            referenceImagePaths.toTypedArray(), safePoseHint, safeDepthHint, controlSize,
            width, height, steps, cfgScale, seed, outFile.absolutePath,
            poseScale, depthScale, ipDecayFloor, ipDecayStartTimestep,
            locationAnchorPath, locationScale, cb
        )
        if (!ok) throw RuntimeException("SD generate (triple combo) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // mục 222-225 TECHNICAL_STATUS.md — GLIGEN. Mirror ĐÚNG mẫu hình
    // loadSDTripleCombo()/loadSDAugmentedMultiChar() ở trên (cache theo
    // modelDir, giải phóng ctx cũ trước khi nạp lại).
    suspend fun loadSDGligen(modelDir: String, embeddingsDir: String,
                              useOpenCL: Boolean = false, useNpu: Boolean = false,
                              // mục 226 — true = nạp unet_gligen_char.mnn + ip_image_encoder.mnn
                              // (GLIGEN + IP-Adapter cho 1 nhân vật chính). PHẢI đi kèm
                              // StoryManager.hasGligenUnetWithCharacter() đã trả true từ
                              // MangaPipeline.kt — hàm này KHÔNG tự kiểm tra, chỉ ghép tên file.
                              withCharacterSlot: Boolean = false) = withContext(Dispatchers.IO) {
        if (modelDir == loadedGligenDir && withCharacterSlot == loadedGligenWithCharacter) return@withContext
        if (sdGligenCtx != 0L) { NativeBridge.sdFreeGligen(sdGligenCtx); sdGligenCtx = 0 }
        val unetPath = "$modelDir/unet_gligen${if (withCharacterSlot) "_char" else ""}.mnn"
        // RỖNG khi không có slot nhân vật -> native không tạo encoder ảnh.
        val ipEncoderPath = if (withCharacterSlot) "$modelDir/ip_image_encoder.mnn" else ""
        sdGligenCtx = NativeBridge.sdInitGligen(
            modelDir, "$modelDir/clip.mnn", unetPath,
            "$modelDir/vae_decoder.mnn", "$modelDir/vae_encoder.mnn",
            ipEncoderPath,
            "$modelDir/tokenizer.json", embeddingsDir, useOpenCL, useNpu
        )
        if (sdGligenCtx == 0L) throw RuntimeException(
            "Không load được pipeline GLIGEN${if (withCharacterSlot) " + nhân vật" else ""} tại $modelDir.\n" +
            "Thiếu file $unetPath — kiểm tra đã chạy tools/export_gligen_unet.py" +
            (if (withCharacterSlot) " --with_character_slot" else "") +
            " và convert sang .mnn chưa.\n(xem logcat tag MangaLocal_Gligen)")
        loadedGligenDir = modelDir
        loadedGligenWithCharacter = withCharacterSlot
    }

    // mục 222/223 Models.kt — objectBoxes: DANH SÁCH ObjectBox (label +
    // 4 toạ độ chuẩn hoá [0,1]) đã qua resolveObjectBoxes() (MangaPipeline.kt,
    // mục 224 — kết hợp tự động LLM đề xuất + override thủ công). Tách
    // thành 2 mảng riêng (labels/boxesFlat) NGAY TẠI ĐÂY (không phải ở
    // MangaPipeline.kt) để lớp gọi hàm này không cần biết JNI cần định
    // dạng mảng phẳng — giữ ranh giới rõ ràng "Kotlin nghiệp vụ" vs
    // "chuyển đổi sang JNI", đúng cách các hàm generatePanel* khác trong
    // file này đã phân chia.
    suspend fun generatePanelGligen(
        panelIndex: Int, prompt: String, negativePrompt: String, stylePrompt: String,
        objectBoxes: List<ObjectBox>,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outDir: File, onProgress: (Int, Int) -> Unit,
        // mục 226 — ảnh anchor 1 nhân vật chính; null = không dùng. CHỈ có tác
        // dụng nếu model đang nạp là biến thể "_char" (loadSDGligen withCharacterSlot=true).
        referenceImagePath: String? = null
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val fullPrompt = prompt + ", " + stylePrompt
        val labels = objectBoxes.map { it.label }.toTypedArray()
        val boxesFlat = FloatArray(objectBoxes.size * 4)
        objectBoxes.forEachIndexed { i, b ->
            boxesFlat[i * 4 + 0] = b.xmin; boxesFlat[i * 4 + 1] = b.ymin
            boxesFlat[i * 4 + 2] = b.xmax; boxesFlat[i * 4 + 3] = b.ymax
        }
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        NativeBridge.setCrashContext("generatePanelGligen panel=$panelIndex objs=${objectBoxes.size}" + (if (referenceImagePath != null) " +char" else ""))
        val ok = NativeBridge.sdTxt2ImgGligen(
            sdGligenCtx, fullPrompt, negativePrompt, labels, boxesFlat, referenceImagePath,
            width, height, steps, cfgScale, seed, outFile.absolutePath, cb
        )
        if (!ok) throw RuntimeException("SD generate (GLIGEN) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // mục 115/117 TECHNICAL_STATUS.md — Multi-Pass Inpainting Cascade,
    // lượt 2..N+1 (lượt 1 là generatePanelMultiChar()/generatePanelRegional()
    // ở trên, không đổi). Ghi ĐÈ lên outFile TRUYỀN VÀO (basePanelPath) —
    // cascade là chuỗi TUẦN TỰ, mỗi lượt sửa tiếp kết quả lượt trước, không
    // tạo file mới mỗi lần (khớp đúng ý nghĩa "cascade": người 2 inpaint
    // TRÊN NỀN ảnh đã có người 1 được sửa xong, không phải trên ảnh gốc).
    suspend fun inpaintCharacterInCascade(
        panelIndex: Int, characterOrderInCascade: Int,
        prompt: String, negativePrompt: String,
        basePanelPath: String, maskPath: String, referenceImagePath: String,
        skeletonData: FloatArray, denoiseStrength: Float,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outDir: File, onProgress: (Int, Int) -> Unit,
        ipDecayFloor: Float = 1.0f, ipDecayStartTimestep: Float = 999.0f, ipStaticScale: Float = 1.3f
    ): String = withContext(Dispatchers.IO) {
        // Seed lệch theo characterOrderInCascade để KHÔNG trùng seed lượt
        // nền (seed giống hệt + denoise thấp dễ ra kết quả gần như y hệt
        // input, không sửa được gì) — lệch cố định (deterministic), không
        // ngẫu nhiên (giữ khả năng tái tạo đúng kết quả cũ khi debug).
        val cascadeSeed = seed + (characterOrderInCascade + 1) * 733L
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex)) // GHI ĐÈ file nền
        onProgress(0, steps)
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, totalSteps: Int) = onProgress(step, totalSteps)
        }
        NativeBridge.setCrashContext("inpaintCharacterInCascade panel=$panelIndex charOrder=$characterOrderInCascade")
        val ok = NativeBridge.sdImg2ImgWithReferenceAndPose(
            sdAugmentedCtx, prompt, negativePrompt,
            basePanelPath, maskPath, referenceImagePath, skeletonData, denoiseStrength,
            width, height, steps, cfgScale, cascadeSeed, outFile.absolutePath,
            ipDecayFloor = ipDecayFloor, ipDecayStartTimestep = ipDecayStartTimestep,
            ipStaticScale = ipStaticScale, callback = cb
        )
        onProgress(steps, steps)
        if (!ok) throw RuntimeException("Cascade inpaint thất bại tại panel ${panelIndex + 1}, nhân vật thứ ${characterOrderInCascade + 1}")
        outFile.absolutePath
    }

    // mục 245 TECHNICAL_STATUS.md — inpaint 1 vùng MẶT bằng img2img + IP-Adapter tham chiếu DANH TÍNH (cộng đồng dùng IP-Adapter FaceID/
    // LoRA trong lượt ADetailer để giữ mặt khi vẽ lại riêng khuôn mặt). Tái dùng đúng hàm native sdImg2ImgWithReferenceAndPose của Cascade
    // (mục 117) nhưng: (1) ghi ra outFile RIÊNG — inpaintCharacterInCascade ghi đè ảnh nền; (2) pose chỉ ở mức vừa và depth tắt, kèm khung
    // xương của ĐÚNG người đó đã đổi sang toạ độ crop (nếu model .mnn cũ bỏ qua hệ số scale thì khung xương vẫn khớp mặt, không phải tư thế đứng giả).
    // Yêu cầu loadSDAugmented() đã gọi (isAugmentedLoaded()). Ném RuntimeException nếu native trả false — caller tự rơi về img2img thường.
    suspend fun inpaintWithIdentity(
        prompt: String, negativePrompt: String, inputPath: String, maskPath: String, referenceImagePath: String,
        personSkeleton: FloatArray, denoiseStrength: Float, width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outFile: File, ipStaticScale: Float, onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        NativeBridge.setCrashContext("inpaintWithIdentity ${outFile.name}")
        val ok = NativeBridge.sdImg2ImgWithReferenceAndPose(
            sdAugmentedCtx, prompt, negativePrompt, inputPath, maskPath, referenceImagePath, personSkeleton, denoiseStrength,
            width, height, steps, cfgScale, seed, outFile.absolutePath,
            poseConditioningScale = 0.5f, depthConditioningScale = 0f, depthActiveMinTimestep = 0f,
            ipDecayFloor = 1.0f, ipDecayStartTimestep = 999.0f, ipStaticScale = ipStaticScale, callback = cb
        )
        if (!ok) throw RuntimeException("inpaint giữ danh tính thất bại: ${outFile.name}")
        outFile.absolutePath
    }

    suspend fun generatePanel(
        panelIndex: Int,
        prompt: String,
        negativePrompt: String,
        stylePrompt: String,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        referenceImagePath: String?,
        // Toạ độ khung xương ĐÃ RETARGET (mục 32/33 TECHNICAL_STATUS.md) —
        // tính sẵn ở MangaPipeline qua PoseRetargeter.kt trước khi gọi hàm
        // này. Rỗng = không có pose cụ thể, native tự dùng fallback đứng.
        skeletonData: FloatArray,
        useStoryDiffusion: Boolean,
        outDir: File,
        onProgress: (Int, Int) -> Unit,
        // mục 81 TECHNICAL_STATUS.md — mặc định khớp NativeBridge (Pose ưu
        // thế, Depth hỗ trợ nhẹ, chỉ bật early-to-mid step). Model .mnn cũ
        // (chưa export lại) bỏ qua 3 giá trị này an toàn.
        poseConditioningScale: Float = 1.0f,
        depthConditioningScale: Float = 0.6f,
        depthActiveMinTimestep: Float = 300.0f,
        // Smooth Timestep Decay IP-Adapter — xem NativeBridge.kt cho ghi chú
        // đầy đủ. Default = không suy giảm gì (tương thích ngược).
        ipDecayFloor: Float = 1.0f,
        ipDecayStartTimestep: Float = 999.0f,
        // mục 9 — đóng gap "consistencyStrength chết", xem NativeBridge.kt.
        ipStaticScale: Float = 1.0f
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val fullPrompt = prompt + ", " + stylePrompt

        val ok = if (useStoryDiffusion && referenceImagePath != null) {
            // mục 134 TECHNICAL_STATUS.md — trước đây pipeline augmented
            // KHÔNG có callback tiến trình per-step (khác pipeline thường),
            // báo tiến trình GIẢ ở mức panel. Đã nối THẬT ở
            // sdTxt2ImgWithReferenceAndPose (ip_adapter.cpp) — dùng chung
            // đúng object SDProgressCallback với nhánh else bên dưới.
            val cb = object : NativeBridge.SDProgressCallback {
                override fun onProgress(step: Int, total: Int) = onProgress(step, total)
            }
            NativeBridge.setCrashContext("generatePanel(augmented) panel=$panelIndex")
            NativeBridge.sdTxt2ImgWithReferenceAndPose(
                sdAugmentedCtx, fullPrompt, negativePrompt, referenceImagePath, skeletonData,
                width, height, steps, cfgScale, seed,
                outFile.absolutePath,
                poseConditioningScale, depthConditioningScale, depthActiveMinTimestep,
                ipDecayFloor, ipDecayStartTimestep, ipStaticScale, cb
            )
        } else {
            val cb = object : NativeBridge.SDProgressCallback {
                override fun onProgress(step: Int, total: Int) = onProgress(step, total)
            }
            NativeBridge.setCrashContext("generatePanel(base) panel=$panelIndex")
            NativeBridge.sdTxt2Img(
                sdCtx, fullPrompt, negativePrompt,
                width, height, steps, cfgScale, seed,
                outFile.absolutePath, cb
            )
        }
        if (!ok) throw RuntimeException("SD generate thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    /**
     * mục 177 TECHNICAL_STATUS.md — SDXL Phase 2b. Bản SDXL tương đương
     * nhánh "augmented" của generatePanel() ở trên. **Cập nhật mục 184**:
     * NAY ĐÃ nối vào dispatch tự động qua `MangaPipeline.dispatchSdxlPanel()`
     * (Phase 3) — hàm này vẫn gọi được trực tiếp (test thủ công/màn hình
     * debug) nếu cần, không bắt buộc phải qua dispatch. width/height PHẢI
     * là 768 hoặc 1024 (mục 189/191-193 — 2 giá trị hợp lệ duy nhất, KHÔNG
     * tự do chọn số khác) và PHẢI khớp đúng độ phân giải model `.mnn` thật
     * đã export (`--image_size` lúc chạy `prepare_models.yml` — xem
     * `MangaPipeline.dispatchSdxlPanel()` để biết cách tự xác nhận qua file
     * `sdxl_resolution.txt`, mục 192/193) — khác SD1.5 (512, không kiểm
     * tra khớp vì luôn cùng 1 giá trị).
     */
    suspend fun generatePanelAugmentedSdxl(
        panelIndex: Int,
        prompt: String,
        negativePrompt: String,
        stylePrompt: String,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        referenceImagePath: String,
        skeletonData: FloatArray,
        outDir: File,
        onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val fullPrompt = prompt + ", " + stylePrompt
        // controlHintRgb PHẢI render sẵn qua renderSkeletonCanvas() — file
        // ip_adapter_sdxl.cpp KHÔNG cross-include pose_templates (xem
        // comment đầu file đó, cùng quy ước generatePanelTripleCombo() ở
        // dưới). controlSize dùng ĐÚNG width (SDXL luôn vuông ở Phase 2 cơ
        // bản này, xem export_ipa_controlnet_unet_sdxl.py).
        val controlSize = width
        val controlHint = NativeBridge.renderSkeletonCanvas(skeletonData, controlSize)
        val blankHint = ByteArray(controlSize * controlSize * 3)
        val safeControlHint = if (controlHint.size == blankHint.size) controlHint else blankHint
        // depthHintRgb — TUỲ CHỌN (mục 181 TECHNICAL_STATUS.md, Phase 2f).
        // Render từ CÙNG skeletonData (đã có z-value/mục 32) qua
        // renderDepthHintCanvas() có sẵn (mục 69) — mảng RỖNG nếu render
        // lỗi/sai kích thước (model tự coi là "không có depth", AN TOÀN,
        // không phải lỗi — xem onBeforeUnetRun() trong ip_adapter_sdxl.cpp).
        val depthHint = NativeBridge.renderDepthHintCanvas(skeletonData, controlSize)
        val safeDepthHint = if (depthHint.size == blankHint.size) depthHint else ByteArray(0)
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        NativeBridge.setCrashContext("generatePanelAugmentedSdxl panel=$panelIndex")
        val ok = NativeBridge.sdTxt2ImgWithReferenceAndPoseSdxl(
            sdAugmentedSdxlCtx, fullPrompt, negativePrompt, referenceImagePath, safeControlHint, safeDepthHint,
            controlSize, width, height, steps, cfgScale, seed, outFile.absolutePath, cb
        )
        if (!ok) throw RuntimeException("SD generate (augmented SDXL) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    /**
     * mục 178 TECHNICAL_STATUS.md — SDXL Phase 2c. Bản SDXL tương đương
     * loadSDAugmentedMultiChar() ở trên, dùng
     * unet_ipa_mask_controlnet_sdxl_{N}char.mnn xuất bởi
     * tools/export_ipa_controlnet_mask_unet_sdxl.py.
     */
    suspend fun loadSDAugmentedMultiCharSdxl(modelDir: String, embeddingsDir: String, numCharacters: Int,
                                              useOpenCL: Boolean = false, useNpu: Boolean = false,
                                              // mục 218 — mirror ĐÚNG loadSDAugmentedMultiChar() (SD1.5).
                                              withLocationSlot: Boolean = false) = withContext(Dispatchers.IO) {
        if (modelDir == loadedMultiCharSdxlDir && numCharacters == loadedMultiCharSdxlN && withLocationSlot == loadedMultiCharSdxlWithLocation) return@withContext
        if (sdAugmentedSdxlCtx != 0L) { NativeBridge.sdFreeAugmentedSdxl(sdAugmentedSdxlCtx); sdAugmentedSdxlCtx = 0 }
        val locSuffix = if (withLocationSlot) "_loc" else ""
        val unetPath = "$modelDir/unet_ipa_mask_controlnet_sdxl_${numCharacters}char${locSuffix}.mnn"
        sdAugmentedSdxlCtx = NativeBridge.sdInitAugmentedSdxl(
            modelDir,
            "$modelDir/clip_l.mnn",
            "$modelDir/clip_g.mnn",
            unetPath,
            "$modelDir/vae_decoder.mnn",
            "$modelDir/vae_encoder.mnn",
            "$modelDir/ip_image_encoder_sdxl.mnn",
            "$modelDir/tokenizer.json",
            embeddingsDir,
            useOpenCL, useNpu
        )
        if (sdAugmentedSdxlCtx == 0L) throw RuntimeException(
            "Không load được pipeline augmented SDXL $numCharacters-nhân-vật${if (withLocationSlot) " + bối cảnh" else ""} tại $modelDir.\n" +
            "Thiếu file $unetPath — kiểm tra đã chạy tools/export_ipa_controlnet_mask_unet_sdxl.py " +
            "--num_characters $numCharacters" + (if (withLocationSlot) " --with_location_slot" else "") + " và convert sang .mnn chưa.\n(xem logcat tag MangaLocal_IPAdapterSDXL)")
        loadedMultiCharSdxlDir = modelDir
        loadedMultiCharSdxlN = numCharacters
        loadedMultiCharSdxlWithLocation = withLocationSlot
        // Vô hiệu cache bản 1-người (dùng chung sdAugmentedSdxlCtx), mirror
        // ĐÚNG lý do mục 67 (SD1.5).
        loadedAugmentedSdxlDir = ""
    }

    /**
     * mục 178 TECHNICAL_STATUS.md — SDXL Phase 2c. Bản SDXL tương đương
     * generatePanelMultiChar() ở trên. characterMasks: mảng PHẲNG N khối
     * controlSize*controlSize byte, ĐÚNG thứ tự referenceImagePaths (mirror
     * buildRegionMasksForPanel() trong MangaPipeline.kt — hàm đó 100% Kotlin
     * thuần, KHÔNG phụ thuộc SD1.5/SDXL, tái dùng được nguyên vẹn để dựng
     * characterMasks cho hàm này, xem TECHNICAL_STATUS.md mục 178). KHÔNG
     * có tham số decay (khác bản SD1.5 — xem "PHẠM VI" đầu
     * tools/export_ipa_controlnet_mask_unet_sdxl.py).
     */
    suspend fun generatePanelMultiCharSdxl(
        panelIndex: Int, prompt: String, negativePrompt: String, stylePrompt: String,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        referenceImagePaths: List<String>, skeletonData: FloatArray, characterMasks: ByteArray,
        outDir: File, onProgress: (Int, Int) -> Unit,
        // mục 218 TECHNICAL_STATUS.md — "Location Anchor" slot thứ N+1,
        // mirror ĐÚNG generatePanelMultiChar() (SD1.5). Không có tham số
        // scale riêng ở đây (khác SD1.5) — scale slot bối cảnh đã đóng
        // băng lúc export (--location_scale), xem ip_adapter_sdxl.cpp.
        locationAnchorPath: String? = null
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val fullPrompt = prompt + ", " + stylePrompt
        val controlSize = width
        val controlHint = NativeBridge.renderSkeletonCanvas(skeletonData, controlSize)
        val blankHint = ByteArray(controlSize * controlSize * 3)
        val safeControlHint = if (controlHint.size == blankHint.size) controlHint else blankHint
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        NativeBridge.setCrashContext("generatePanelMultiCharSdxl panel=$panelIndex chars=${referenceImagePaths.size}" + (if (locationAnchorPath != null) " +loc" else ""))
        val ok = NativeBridge.sdTxt2ImgWithCharactersAndPoseSdxl(
            sdAugmentedSdxlCtx, fullPrompt, negativePrompt,
            referenceImagePaths.toTypedArray(), characterMasks, safeControlHint,
            controlSize, width, height, steps, cfgScale, seed, outFile.absolutePath,
            locationAnchorPath, cb
        )
        if (!ok) throw RuntimeException("SD generate (mask N-nhân-vật SDXL) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    /**
     * mục 179 TECHNICAL_STATUS.md — SDXL Phase 2d. Bản SDXL tương đương
     * loadSDRegional() ở trên, dùng unet_regional_controlnet_sdxl_{N}col.mnn
     * xuất bởi tools/export_ipa_controlnet_regional_unet_sdxl.py.
     */
    suspend fun loadSDRegionalSdxl(modelDir: String, embeddingsDir: String, numRegions: Int,
                                    useOpenCL: Boolean = false, useNpu: Boolean = false) = withContext(Dispatchers.IO) {
        if (modelDir == loadedRegionalSdxlDir && numRegions == loadedRegionalSdxlN) return@withContext
        if (sdRegionalSdxlCtx != 0L) { NativeBridge.sdFreeRegionalSdxl(sdRegionalSdxlCtx); sdRegionalSdxlCtx = 0 }
        val unetPath = "$modelDir/unet_regional_controlnet_sdxl_${numRegions}col.mnn"
        sdRegionalSdxlCtx = NativeBridge.sdInitRegionalSdxl(
            modelDir, "$modelDir/clip_l.mnn", "$modelDir/clip_g.mnn", unetPath,
            "$modelDir/vae_decoder.mnn", "$modelDir/vae_encoder.mnn",
            "$modelDir/tokenizer.json", embeddingsDir, numRegions, useOpenCL, useNpu
        )
        if (sdRegionalSdxlCtx == 0L) throw RuntimeException(
            "Không load được pipeline Regional Prompting SDXL tại $modelDir.\n" +
            "Thiếu file $unetPath — kiểm tra đã chạy tools/export_ipa_controlnet_regional_unet_sdxl.py " +
            "--num_regions $numRegions và convert sang .mnn chưa.\n(xem logcat tag MangaLocal_RegionalSDXL)")
        loadedRegionalSdxlDir = modelDir
        loadedRegionalSdxlN = numRegions
    }

    /**
     * mục 179 TECHNICAL_STATUS.md — SDXL Phase 2d. Bản SDXL tương đương
     * generatePanelRegional() ở trên. controlSize PHẢI là 768 hoặc 1024
     * (mục 189/191-193, khác 512 của SD1.5) — PHẢI khớp đúng --image_size
     * lúc export model này (`dispatchSdxlPanel()` tự xác nhận qua file
     * `sdxl_resolution.txt` nếu có, mục 192/193).
     */
    suspend fun generatePanelRegionalSdxl(
        panelIndex: Int, regionPrompts: List<String>, negativePrompt: String,
        skeletonData: FloatArray, width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outDir: File, onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val controlSize = width
        val controlHint = NativeBridge.renderSkeletonCanvas(skeletonData, controlSize)
        val safeHint = if (controlHint.size == controlSize * controlSize * 3) controlHint
            else ByteArray(controlSize * controlSize * 3)
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        NativeBridge.setCrashContext("generatePanelRegionalSdxl panel=$panelIndex regions=${regionPrompts.size}")
        val ok = NativeBridge.sdTxt2ImgRegionalSdxl(
            sdRegionalSdxlCtx, regionPrompts.toTypedArray(), negativePrompt,
            safeHint, controlSize, width, height, steps, cfgScale, seed, outFile.absolutePath, cb
        )
        if (!ok) throw RuntimeException("SD generate (regional SDXL) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    /**
     * mục 180 TECHNICAL_STATUS.md — SDXL Phase 2e. Bản SDXL tương đương
     * loadSDRegionalMask() ở trên.
     */
    suspend fun loadSDRegionalMaskSdxl(modelDir: String, embeddingsDir: String, numRegions: Int,
                                        useOpenCL: Boolean = false, useNpu: Boolean = false) = withContext(Dispatchers.IO) {
        if (modelDir == loadedRegionalMaskSdxlDir && numRegions == loadedRegionalMaskSdxlN) return@withContext
        if (sdRegionalMaskSdxlCtx != 0L) { NativeBridge.sdFreeRegionalMaskSdxl(sdRegionalMaskSdxlCtx); sdRegionalMaskSdxlCtx = 0 }
        val unetPath = "$modelDir/unet_regional_mask_controlnet_sdxl_${numRegions}char.mnn"
        sdRegionalMaskSdxlCtx = NativeBridge.sdInitRegionalMaskSdxl(
            modelDir, "$modelDir/clip_l.mnn", "$modelDir/clip_g.mnn", unetPath,
            "$modelDir/vae_decoder.mnn", "$modelDir/vae_encoder.mnn",
            "$modelDir/tokenizer.json", embeddingsDir, numRegions, useOpenCL, useNpu
        )
        if (sdRegionalMaskSdxlCtx == 0L) throw RuntimeException(
            "Không load được pipeline Regional-Mask SDXL tại $modelDir.\n" +
            "Thiếu file $unetPath — kiểm tra đã chạy tools/export_ipa_controlnet_regional_mask_unet_sdxl.py " +
            "--num_regions $numRegions và convert sang .mnn chưa.\n(xem logcat tag MangaLocal_RegionalMaskSDXL)")
        loadedRegionalMaskSdxlDir = modelDir
        loadedRegionalMaskSdxlN = numRegions
    }

    /**
     * mục 180 TECHNICAL_STATUS.md — SDXL Phase 2e. Bản SDXL tương đương
     * generatePanelRegionalMask() ở trên. controlSize mặc định = width,
     * PHẢI là 768 hoặc 1024 (mục 189/191-193, khác 512 SD1.5) — PHẢI khớp
     * đúng --image_size lúc export model.
     */
    suspend fun generatePanelRegionalMaskSdxl(
        panelIndex: Int, regionPrompts: List<String>, backgroundPrompt: String, negativePrompt: String,
        regionMasks: ByteArray, skeletonData: FloatArray, width: Int, height: Int,
        steps: Int, cfgScale: Float, seed: Long, outDir: File, onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val controlSize = width
        val controlHint = NativeBridge.renderSkeletonCanvas(skeletonData, controlSize)
        val safeHint = if (controlHint.size == controlSize * controlSize * 3) controlHint
            else ByteArray(controlSize * controlSize * 3)
        val expectedMaskBytes = regionPrompts.size * width * height
        if (regionMasks.size != expectedMaskBytes) {
            throw IllegalArgumentException(
                "generatePanelRegionalMaskSdxl: regionMasks.size=${regionMasks.size}, kỳ vọng " +
                "$expectedMaskBytes (= ${regionPrompts.size} vùng x ${width}x$height) — buildRegionMasksForPanel() " +
                "có đang dùng đúng width/height của panel này không?")
        }
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        NativeBridge.setCrashContext("generatePanelRegionalMaskSdxl panel=$panelIndex regions=${regionPrompts.size}")
        val ok = NativeBridge.sdTxt2ImgRegionalMaskSdxl(
            sdRegionalMaskSdxlCtx, regionPrompts.toTypedArray(), backgroundPrompt, negativePrompt,
            regionMasks, safeHint, controlSize, width, height, steps, cfgScale, seed, outFile.absolutePath, cb
        )
        if (!ok) throw RuntimeException("SD generate (regional-mask SDXL) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // img2img / inpaint / Ultrafix (mục 16 TECHNICAL_STATUS.md). Dùng sdCtx
    // (pipeline THƯỜNG, không phải augmented — Ultrafix/inpaint CHƯA thử
    // nghiệm kết hợp với IP-Adapter/ControlNet-Pose cùng lúc, để dành sau
    // nếu thực tế cần). Yêu cầu đã gọi loadSD() trước (giống generatePanel).
    //
    // maskPath = null -> img2img thường (vẽ lại toàn ảnh theo denoiseStrength).
    // maskPath != null -> inpaint thật, chỉ vẽ lại vùng trắng trong mask.
    // ultrafix = true -> upscale-vẽ-lại: inputPath PHẢI đã là ảnh upscale sẵn
    // (vd qua ESRGAN), width/height = kích thước ĐÍCH (đã upscale), không
    // phải kích thước gốc 512.
    suspend fun img2imgFix(
        panelIndex: Int, prompt: String, negativePrompt: String, stylePrompt: String,
        inputPath: String, maskPath: String?, denoiseStrength: Float,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        ultrafix: Boolean, ultrafixTile: Int, outDir: File, onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val suffix = if (ultrafix) "ultrafix" else "fix"
        val outFile = File(outDir, "panel_%03d_%s.png".format(panelIndex, suffix))
        val fullPrompt = prompt + ", " + stylePrompt
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        NativeBridge.setCrashContext("img2imgFix panel=$panelIndex ultrafix=$ultrafix")
        val ok = NativeBridge.sdImg2Img(
            sdCtx, fullPrompt, negativePrompt, inputPath, maskPath ?: "",
            denoiseStrength, width, height, steps, cfgScale, seed,
            ultrafix, ultrafixTile, outFile.absolutePath, cb
        )
        if (!ok) throw RuntimeException("img2img/inpaint thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // mục 207 TECHNICAL_STATUS.md — bản SDXL của img2imgFix() ở trên, dùng
    // cho tryAutoFixInteractions() khi panel đang dùng SDXL. KHÔNG có tham
    // số ultrafix (PipelineSdxlCpu chưa hỗ trợ — xem GIỚI HẠN THẬT ở
    // NativeBridge.kt/ip_adapter_sdxl.cpp). Yêu cầu loadSDSdxl() đã gọi
    // trước (giống img2imgFix() yêu cầu loadSD() đã gọi trước — không tự
    // load ở đây, để caller (MangaPipeline.kt) chủ động quyết định lúc nào
    // cần nạp, tránh nạp thừa nếu panel không cần auto-fix).
    suspend fun img2imgFixSdxl(
        panelIndex: Int, prompt: String, negativePrompt: String, stylePrompt: String,
        inputPath: String, maskPath: String?, denoiseStrength: Float,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outDir: File, onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_fix_sdxl.png".format(panelIndex))
        val fullPrompt = prompt + ", " + stylePrompt
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        NativeBridge.setCrashContext("img2imgFixSdxl panel=$panelIndex")
        val ok = NativeBridge.sdImg2ImgSdxl(
            sdSdxlCtx, fullPrompt, negativePrompt, inputPath, maskPath ?: "",
            denoiseStrength, width, height, steps, cfgScale, seed,
            outFile.absolutePath, cb
        )
        if (!ok) throw RuntimeException("img2img/inpaint SDXL thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    suspend fun upscale(inputPath: String, panelIndex: Int, outDir: File, option: UpscaleOption): String =
        withContext(Dispatchers.IO) {
            if (option == UpscaleOption.NONE) return@withContext inputPath
            val outFile = File(outDir, "panel_%03d_hd.png".format(panelIndex))
            val ok = NativeBridge.esrganUpscale(esrganCtx, inputPath, outFile.absolutePath, option.sharpen)
            if (!ok) throw RuntimeException("Upscale thất bại tại panel ${panelIndex + 1}")
            outFile.absolutePath
        }

    fun isSdLoaded() = sdCtx != 0L
    fun isAugmentedLoaded() = sdAugmentedCtx != 0L // mục 245

    fun freeAll() {
        if (sdCtx != 0L) { NativeBridge.sdFree(sdCtx); sdCtx = 0; loadedSdPath = ""; loadedSdEmbeddingsSig = "" }
        if (sdAugmentedCtx != 0L) {
            NativeBridge.sdFreeAugmented(sdAugmentedCtx); sdAugmentedCtx = 0
            loadedAugmentedDir = ""; loadedAugmentedEmbeddingsSig = ""
            // mục 206 TECHNICAL_STATUS.md — sdAugmentedCtx dùng CHUNG cho
            // cả đường 1-nhân-vật (loadedAugmentedDir/Sig, ngay trên) LẪN
            // Multi-Char Mask (loadedMultiCharDir/N — loadSDAugmentedMultiChar()
            // phía dưới, cùng ghi vào sdAugmentedCtx). Trước bản vá này
            // freeAll() chỉ reset cache đường 1-nhân-vật, BỎ SÓT cache
            // Multi-Char — gọi lại loadSDAugmentedMultiChar() với ĐÚNG
            // modelDir/numCharacters cũ ngay sau freeAll() sẽ bị check
            // cache đánh lừa "đã nạp sẵn" (dòng ~180), dùng nhầm ctx=0 (đã
            // free) cho generate() thật — ĐÚNG loại lỗi mục 131 đã tìm ra
            // cho sdRegionalCtx, chỉ là chưa ai soi lại riêng cho cặp
            // augmented/multiChar này khi Multi-Char Mask được thêm sau.
            loadedMultiCharDir = ""; loadedMultiCharN = 0; loadedMultiCharWithLocation = false
        }
        if (esrganCtx != 0L) { NativeBridge.esrganFree(esrganCtx); esrganCtx = 0 }
        // mục 131 TECHNICAL_STATUS.md — user hỏi "ngoài LLM ra các model
        // khác thì sao" dẫn tới audit toàn hệ thống, phát hiện sdRegionalCtx
        // (Regional Prompting UNet) tự free-cũ-trước-khi-tạo-mới ĐÚNG (dòng
        // ~166) nhưng BỊ THIẾU khỏi freeAll() — cùng loại bug với poseExtractor
        // (MangaPipeline.kt). Nếu 1 truyện từng dùng Regional Prompting rồi
        // chuyển hẳn sang chế độ khác, context UNet Regional (có thể vài
        // trăm MB - vài GB tuỳ model) vẫn giữ trong RAM vĩnh viễn dù
        // freeAll() được gọi tưởng đã dọn sạch hoàn toàn.
        // Reset CẢ path-cache (loadedRegionalDir/N) — không chỉ ctx=0.
        // Nếu chỉ reset ctx mà giữ nguyên cache path, lần loadSDRegional()
        // kế tiếp với CÙNG modelDir sẽ bị check `modelDir == loadedRegionalDir`
        // đánh lừa là "đã nạp sẵn", bỏ qua tái khởi tạo — dùng nhầm ctx=0
        // (đã free) cho generate() thật, gây crash hoặc lỗi âm thầm. Cùng
        // lỗi tiềm ẩn này KHÔNG xảy ra với sdCtx/sdAugmentedCtx ở trên vì 2
        // dòng đó đã tự reset path-cache riêng của chúng (loadedSdPath/
        // loadedAugmentedDir) — chỉ sdRegionalCtx bị bỏ sót bước này.
        if (sdRegionalCtx != 0L) {
            NativeBridge.sdFreeRegional(sdRegionalCtx); sdRegionalCtx = 0
            loadedRegionalDir = ""; loadedRegionalN = 0
        }
        // mục 151 TECHNICAL_STATUS.md — thêm ctx MỚI (Triple-Conditioning
        // combo) NGAY TỪ ĐẦU vào freeAll() + reset path-cache đầy đủ — rút
        // kinh nghiệm trực tiếp từ bug mục 131 vừa đọc ở trên (sdRegionalCtx
        // từng bị sót), không lặp lại cùng lỗi cho ctx mới thêm.
        if (sdTripleComboCtx != 0L) {
            NativeBridge.sdFreeTripleCombo(sdTripleComboCtx); sdTripleComboCtx = 0
            loadedTripleComboDir = ""; loadedTripleComboN = -1; loadedTripleComboWithLocation = false
        }
        // mục 206 TECHNICAL_STATUS.md — audit lại đúng danh sách ctx thật
        // (grep toàn bộ "private var sd.*Ctx: Long", không suy đoán) trong
        // lúc kiểm tra khả năng port Cascade cho SDXL — phát hiện 4 ctx
        // dưới đây bị THIẾU HẲN khỏi freeAll() (không phải thiếu path-cache
        // như sdAugmentedCtx ở trên — thiếu toàn bộ khối, y hệt đúng dạng
        // bug mục 131 nhưng chưa ai soi lại từ khi sdRegionalMaskCtx
        // (mục 172, SD1.5) và 3 ctx SDXL (mục 177/179/180) được thêm vào
        // SAU đợt audit mục 131/151). Hậu quả thật: 1 truyện dùng qua
        // Regional-Mask hoặc bất kỳ pipeline SDXL nào rồi freeAll() (đổi
        // truyện/dọn RAM chủ động) sẽ KHÔNG giải phóng ctx đó — rò vĩnh
        // viễn tới khi app bị kill, tích luỹ nếu đổi qua lại nhiều truyện/
        // nhiều pipeline trong 1 phiên dùng app.
        if (sdRegionalMaskCtx != 0L) {
            NativeBridge.sdFreeRegionalMask(sdRegionalMaskCtx); sdRegionalMaskCtx = 0
            loadedRegionalMaskDir = ""; loadedRegionalMaskN = -1
        }
        if (sdAugmentedSdxlCtx != 0L) {
            NativeBridge.sdFreeAugmentedSdxl(sdAugmentedSdxlCtx); sdAugmentedSdxlCtx = 0
            loadedAugmentedSdxlDir = ""; loadedAugmentedSdxlEmbeddingsSig = ""
            loadedMultiCharSdxlDir = ""; loadedMultiCharSdxlN = 0; loadedMultiCharSdxlWithLocation = false // mirror đúng lý do ở khối sdAugmentedCtx phía trên
        }
        // mục 207 TECHNICAL_STATUS.md — thêm ctx MỚI (PLAIN SDXL) NGAY TỪ
        // ĐẦU vào freeAll() + reset path-cache đầy đủ — rút kinh nghiệm
        // trực tiếp từ bug mục 206 (4 ctx SDXL/RegionalMask từng bị sót),
        // không lặp lại cùng lỗi cho ctx mới thêm ở đây.
        if (sdSdxlCtx != 0L) {
            NativeBridge.sdFreeSdxl(sdSdxlCtx); sdSdxlCtx = 0
            loadedSdxlDir = ""; loadedSdxlEmbeddingsSig = ""
        }
        if (sdRegionalSdxlCtx != 0L) {
            NativeBridge.sdFreeRegionalSdxl(sdRegionalSdxlCtx); sdRegionalSdxlCtx = 0
            loadedRegionalSdxlDir = ""; loadedRegionalSdxlN = -1
        }
        if (sdRegionalMaskSdxlCtx != 0L) {
            NativeBridge.sdFreeRegionalMaskSdxl(sdRegionalMaskSdxlCtx); sdRegionalMaskSdxlCtx = 0
            loadedRegionalMaskSdxlDir = ""; loadedRegionalMaskSdxlN = -1
        }
        // mục 225 TECHNICAL_STATUS.md — GLIGEN, ctx MỚI thêm NGAY LÚC VIẾT
        // (không đợi audit sau mới phát hiện thiếu) — rút kinh nghiệm trực
        // tiếp từ chuỗi bug mục 131→151→206→207 đọc ở trên: MỌI ctx mới
        // phải vào freeAll() NGAY, không phải việc "làm sau".
        if (sdGligenCtx != 0L) {
            NativeBridge.sdFreeGligen(sdGligenCtx); sdGligenCtx = 0
            loadedGligenDir = ""; loadedGligenWithCharacter = false
        }
    }

    fun freeEsrganOnly() {
        if (esrganCtx != 0L) { NativeBridge.esrganFree(esrganCtx); esrganCtx = 0 }
    }
}
