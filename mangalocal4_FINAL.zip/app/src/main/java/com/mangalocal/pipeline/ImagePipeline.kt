package com.mangalocal.pipeline

import com.mangalocal.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ImagePipeline(private val storyManager: StoryManager) {

    private var sdCtx: Long = 0
    private var sdAugmentedCtx: Long = 0
    private var loadedAugmentedDir = ""
    private var esrganCtx: Long = 0
    private var loadedSdPath = ""
    // mục 144 TECHNICAL_STATUS.md — fingerprint thư mục Textual Inversion
    // embeddings đã nạp lần gần nhất cho MỖI pipeline (base/augmented) —
    // xem embeddingsSignature() bên dưới + giải thích tại loadSD().
    private var loadedSdEmbeddingsSig = ""
    private var loadedAugmentedEmbeddingsSig = ""

    /**
     * mục 144 TECHNICAL_STATUS.md — đóng gap "cache loadSD() không reload
     * khi Textual Inversion embeddings đổi giữa chừng" (còn treo từ mục 13
     * archive). Thay vì theo dõi TOÀN BỘ nội dung file (tốn, không cần
     * thiết — embeddings không sửa tại chỗ, chỉ thêm/xoá), chỉ cần fingerprint
     * RẺ: nối tên file + kích thước + lastModified của mọi file trong
     * `embeddingsDir` (sắp xếp theo tên để ổn định thứ tự) — đủ để phát hiện
     * thêm/xoá/ghi đè file mà không phải đọc nội dung .safetensors (có thể
     * vài chục MB/file). Thư mục không tồn tại/rỗng -> chuỗi rỗng ổn định,
     * không lỗi.
     */
    private fun embeddingsSignature(embeddingsDir: String): String {
        if (embeddingsDir.isBlank()) return ""
        val dir = File(embeddingsDir)
        val files = dir.listFiles() ?: return ""
        return files.sortedBy { it.name }
            .joinToString("|") { "${it.name}:${it.length()}:${it.lastModified()}" }
    }

    /**
     * Nạp pipeline "augmented" (IP-Adapter + ControlNet-Pose) — dùng
     * unet_ipa_controlnet.mnn xuất bởi tools/export_ipa_controlnet_unet.py,
     * KHÁC HẲN unet.mnn thường của loadSD(). Chỉ gọi khi thật sự cần giữ
     * nhất quán nhân vật (settings.useStoryDiffusion), không phải lúc nào
     * cũng nạp vì UNet augmented nặng hơn UNet thường (thêm ControlNet).
     */
    suspend fun loadSDAugmented(modelDir: String, embeddingsDir: String,
                                useOpenCL: Boolean = false, useNpu: Boolean = false) = withContext(Dispatchers.IO) {
        // mục 144 — reload nếu ĐỔI thư mục model HOẶC embeddings đã đổi
        // (thêm/xoá/ghi đè file Textual Inversion) kể từ lần nạp trước, xem
        // embeddingsSignature() + giải thích đầy đủ tại loadSD() bên dưới.
        val embSig = embeddingsSignature(embeddingsDir)
        if (modelDir == loadedAugmentedDir && embSig == loadedAugmentedEmbeddingsSig) return@withContext
        if (sdAugmentedCtx != 0L) { NativeBridge.sdFreeAugmented(sdAugmentedCtx); sdAugmentedCtx = 0 }
        sdAugmentedCtx = NativeBridge.sdInitAugmented(
            modelDir,
            "$modelDir/clip.mnn",
            "$modelDir/unet_ipa_controlnet.mnn",
            "$modelDir/vae_decoder.mnn",
            "$modelDir/vae_encoder.mnn",
            "$modelDir/ip_image_encoder.mnn",
            "$modelDir/tokenizer.json",
            embeddingsDir,
            useOpenCL, useNpu
        )
        if (sdAugmentedCtx == 0L) throw RuntimeException(
            "Không load được pipeline augmented tại $modelDir.\n" +
            "Kiểm tra đã chạy tools/export_ipa_controlnet_unet.py và convert sang .mnn chưa.\n" +
            "(xem logcat tag MangaLocal_IPAdapter)")
        loadedAugmentedDir = modelDir
        loadedAugmentedEmbeddingsSig = embSig
        // mục 67 TECHNICAL_STATUS.md — dùng CHUNG sdAugmentedCtx với bản
        // multi-char bên dưới, phải vô hiệu cache của bản đó (nếu không, gọi
        // xen kẽ 1-người/N-người sẽ tưởng nhầm N-char ctx vẫn còn hợp lệ).
        loadedMultiCharDir = ""; loadedMultiCharN = 0
    }

    // ĐỔI CHỮ KÝ: modelPath/loraPath/loraWeight/nThreads/useVulkan (thời
    // sd.cpp) -> modelDir/modelId/useOpenCL (thời MNN + model_manifest.json).
    // Lý do đổi: MNN cần NHIỀU file trong 1 thư mục (clip/unet/vae_decoder/
    // vae_encoder/tokenizer...), không phải 1 file .gguf/.safetensors duy
    // nhất như sd.cpp — nên đổi sang trỏ thư mục + id trong manifest thay vì
    // đường dẫn 1 file. Không giữ được chữ ký cũ ở lần đổi này.
    // mục 144 TECHNICAL_STATUS.md — ĐÃ ĐÓNG gap cache embeddings (trước ghi
    // "CẢNH BÁO CACHE (chưa xử lý)" ở đây — không còn đúng): giờ reload nếu
    // `embeddingsSignature(embeddingsDir)` khác lần nạp trước, kể cả khi
    // `modelId` không đổi — vd user vừa gán Textual Inversion cho 1 nhân vật
    // ngay trước khi generate tiếp, embedding mới được nạp NGAY, không phải
    // đợi đổi model khác rồi quay lại hay restart app.
    suspend fun loadSD(modelDir: String, modelId: String, useOpenCL: Boolean, embeddingsDir: String,
                       useNpu: Boolean = false, socModel: String = "") =
        withContext(Dispatchers.IO) {
            val embSig = embeddingsSignature(embeddingsDir)
            if (modelId == loadedSdPath && embSig == loadedSdEmbeddingsSig) return@withContext
            if (sdCtx != 0L) { NativeBridge.sdFree(sdCtx); sdCtx = 0 }
            sdCtx = NativeBridge.sdInit(modelDir, modelId, useOpenCL, embeddingsDir, useNpu, socModel)
            if (sdCtx == 0L) throw RuntimeException("Không load được SD model: $modelId\n(xem logcat tag MangaLocal_SDEngine để biết lý do cụ thể)")
            loadedSdPath = modelId
            loadedSdEmbeddingsSig = embSig
        }

    suspend fun loadEsrgan(scale: Int) = withContext(Dispatchers.IO) {
        if (esrganCtx != 0L || scale <= 1) return@withContext
        if (!storyManager.hasEsrgan()) throw RuntimeException(
            "Thiếu ESRGAN model.\nĐặt vào: ${storyManager.esrganDir.absolutePath}")
        esrganCtx = NativeBridge.esrganInit(scale, storyManager.esrganDir.absolutePath)
        if (esrganCtx == 0L) throw RuntimeException("ESRGAN init thất bại")
    }

    // mục 67 TECHNICAL_STATUS.md — bản N NHÂN VẬT (mục 52b) song song với
    // loadSDAugmented() ở trên (bản 1 nhân vật). unet TRỎ ĐÚNG file
    // unet_ipa_mask_controlnet_{N}char.mnn (mỗi N một file riêng, không
    // dùng chung — xem comment mục 52b/NativeBridge.kt). numCharacters
    // PHẢI khớp đúng N của file model, KHÔNG tự suy — gọi sai N sẽ ra
    // input embedding/mask shape lệch (native tự cắt/điền theo comment
    // ip_adapter.cpp nhưng vẫn nên gọi đúng N ngay từ đầu).
    private var loadedMultiCharDir = ""
    private var loadedMultiCharN = 0
    suspend fun loadSDAugmentedMultiChar(modelDir: String, embeddingsDir: String, numCharacters: Int,
                                          useOpenCL: Boolean = false, useNpu: Boolean = false) = withContext(Dispatchers.IO) {
        if (modelDir == loadedMultiCharDir && numCharacters == loadedMultiCharN) return@withContext
        if (sdAugmentedCtx != 0L) { NativeBridge.sdFreeAugmented(sdAugmentedCtx); sdAugmentedCtx = 0 }
        val unetPath = "$modelDir/unet_ipa_mask_controlnet_${numCharacters}char.mnn"
        sdAugmentedCtx = NativeBridge.sdInitAugmented(
            modelDir,
            "$modelDir/clip.mnn",
            unetPath,
            "$modelDir/vae_decoder.mnn",
            "$modelDir/vae_encoder.mnn",
            "$modelDir/ip_image_encoder.mnn",
            "$modelDir/tokenizer.json",
            embeddingsDir,
            useOpenCL, useNpu
        )
        if (sdAugmentedCtx == 0L) throw RuntimeException(
            "Không load được pipeline augmented $numCharacters-nhân-vật tại $modelDir.\n" +
            "Thiếu file $unetPath — kiểm tra đã chạy tools/export_ipa_controlnet_mask_unet.py " +
            "--num_characters $numCharacters và convert sang .mnn chưa.\n(xem logcat tag MangaLocal_IPAdapter)")
        loadedMultiCharDir = modelDir
        loadedMultiCharN = numCharacters
        // Vô hiệu cache của loadSDAugmented() bản 1-nhân-vật (dùng chung
        // sdAugmentedCtx) để lần gọi generatePanel() 1-nhân-vật kế tiếp
        // không tưởng nhầm đã nạp đúng unet, tự nạp lại.
        loadedAugmentedDir = ""
    }

    /**
     * mục 67 TECHNICAL_STATUS.md — nối dây thật sdTxt2ImgWithCharactersAndPose
     * (mục 52b, native đã xong từ trước nhưng CHƯA có nơi nào trong Kotlin
     * gọi tới — xác nhận qua grep, đây là điểm sửa chính của mục này).
     * referenceImagePaths/skeletonData PHẢI cùng thứ tự nhân vật (invariant
     * mục 32/33/52b) — MangaPipeline chịu trách nhiệm đảm bảo thứ tự khớp
     * scene.characters trước khi gọi hàm này.
     */
    suspend fun generatePanelMultiChar(
        panelIndex: Int, prompt: String, negativePrompt: String, stylePrompt: String,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        referenceImagePaths: List<String>, skeletonData: FloatArray,
        outDir: File, onProgress: (Int, Int) -> Unit,
        // mục 100 — Smooth Timestep Decay + consistencyStrength, mở rộng
        // mục 97/99 sang đường mask N-nhân-vật. Default = không đổi gì.
        ipDecayFloor: Float = 1.0f,
        ipDecayStartTimestep: Float = 999.0f,
        ipStaticScale: Float = 1.0f,
        // mục 147 TECHNICAL_STATUS.md — Per-Instance Decay: 3 mảng TUỲ
        // CHỌN, PHẢI cùng độ dài `referenceImagePaths` nếu truyền (1 giá
        // trị/nhân vật, cùng thứ tự). null (mặc định) = dùng 3 scalar
        // trên cho MỌI nhân vật, tương thích ngược tuyệt đối.
        ipDecayFloors: FloatArray? = null,
        ipDecayStartTimesteps: FloatArray? = null,
        ipStaticScales: FloatArray? = null
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val fullPrompt = prompt + ", " + stylePrompt
        // mục 134 TECHNICAL_STATUS.md — trước đây báo tiến trình GIẢ ("0
        // rồi nhảy thẳng lên steps") vì sdTxt2ImgWithCharactersAndPose
        // KHÔNG có callback per-step ở tầng native. Đã nối THẬT (xem
        // ip_adapter.cpp) — dùng ĐÚNG khuôn mẫu SDProgressCallback đã dùng
        // cho sdTxt2Img/sdImg2Img, không còn gọi onProgress(0,steps) giả.
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        val ok = NativeBridge.sdTxt2ImgWithCharactersAndPose(
            sdAugmentedCtx, fullPrompt, negativePrompt,
            referenceImagePaths.toTypedArray(), skeletonData,
            width, height, steps, cfgScale, seed,
            outFile.absolutePath,
            ipDecayFloor, ipDecayStartTimestep, ipStaticScale,
            ipDecayFloors, ipDecayStartTimesteps, ipStaticScales, cb
        )
        if (!ok) throw RuntimeException("SD generate (multi-char mask) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // mục 69 TECHNICAL_STATUS.md — nối dây thật sdTxt2ImgRegional (mục 56,
    // native đã xong từ trước nhưng CHƯA có nơi nào trong Kotlin gọi tới —
    // xác nhận qua grep, giống hệt tình huống mục 67). unet TRỎ ĐÚNG file
    // unet_regional_controlnet_{N}col.mnn (xem tools/export_ipa_controlnet_
    // regional_unet.py — mỗi N cần 1 file riêng, không dynamic_axes).
    private var loadedRegionalDir = ""
    private var loadedRegionalN = 0
    private var sdRegionalCtx: Long = 0
    suspend fun loadSDRegional(modelDir: String, embeddingsDir: String, numRegions: Int,
                                useOpenCL: Boolean = false, useNpu: Boolean = false) = withContext(Dispatchers.IO) {
        if (modelDir == loadedRegionalDir && numRegions == loadedRegionalN) return@withContext
        if (sdRegionalCtx != 0L) { NativeBridge.sdFreeRegional(sdRegionalCtx); sdRegionalCtx = 0 }
        val unetPath = "$modelDir/unet_regional_controlnet_${numRegions}col.mnn"
        sdRegionalCtx = NativeBridge.sdInitRegional(
            modelDir, "$modelDir/clip.mnn", unetPath,
            "$modelDir/vae_decoder.mnn", "$modelDir/vae_encoder.mnn",
            "$modelDir/tokenizer.json", embeddingsDir, numRegions, useOpenCL, useNpu
        )
        if (sdRegionalCtx == 0L) throw RuntimeException(
            "Không load được pipeline Regional Prompting tại $modelDir.\n" +
            "Thiếu file $unetPath — kiểm tra đã chạy tools/export_ipa_controlnet_regional_unet.py " +
            "--num_regions $numRegions và convert sang .mnn chưa.\n(xem logcat tag MangaLocal_Regional)")
        loadedRegionalDir = modelDir
        loadedRegionalN = numRegions
    }

    /**
     * mục 69 TECHNICAL_STATUS.md — regionPrompts THỨ TỰ trái->phải, PHẢI
     * khớp đúng numRegions đã dùng lúc loadSDRegional(). controlHintRgb lấy
     * qua NativeBridge.renderSkeletonCanvas() (dùng LẠI renderSkeletons()
     * native — KHÔNG tự vẽ skeleton ở Kotlin, xem comment tại đó).
     */
    suspend fun generatePanelRegional(
        panelIndex: Int, regionPrompts: List<String>, negativePrompt: String,
        skeletonData: FloatArray, width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outDir: File, onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val controlSize = 512
        val controlHint = NativeBridge.renderSkeletonCanvas(skeletonData, controlSize)
        if (controlHint.isEmpty()) {
            // mục 69 — skeletonData rỗng/lỗi format: renderSkeletonCanvas()
            // trả mảng rỗng thay vì throw (xem comment native). Tự tạo
            // canvas ĐEN (toàn 0) đúng kích thước thay vì để native nhận
            // mảng sai độ dài rồi lỗi khó hiểu hơn — tương đương "không có
            // gợi ý tư thế nào" (ControlNet vẫn chạy được, chỉ không có
            // hint, đúng hành vi fallback của renderSkeletons() khi rỗng).
        }
        val safeHint = if (controlHint.size == controlSize * controlSize * 3) controlHint
            else ByteArray(controlSize * controlSize * 3)
        // mục 134 — nối progress callback per-step thật (trước đây gọi
        // onProgress(0,steps) giả rồi nhảy thẳng lên steps, xem ghi chú ở
        // generatePanelMultiChar() phía trên cho lý do đầy đủ).
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        val ok = NativeBridge.sdTxt2ImgRegional(
            sdRegionalCtx, regionPrompts.toTypedArray(), negativePrompt,
            safeHint, controlSize, width, height, steps, cfgScale, seed, outFile.absolutePath, cb
        )
        if (!ok) throw RuntimeException("SD generate (regional) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // mục 151 TECHNICAL_STATUS.md — Triple-Conditioning combo. ctx RIÊNG
    // (không dùng chung sdRegionalCtx/sdAugmentedCtx — model + input khác
    // hẳn cả 2), tên file .mnn theo ĐÚNG convention export script
    // (`unet_triple_combo_{N}region.mnn`, xem tools/export_ipa_controlnet_
    // triple_combo_unet.py).
    private var sdTripleComboCtx: Long = 0
    private var loadedTripleComboDir = ""
    private var loadedTripleComboN = -1

    suspend fun loadSDTripleCombo(modelDir: String, embeddingsDir: String, numRegions: Int,
                                   useOpenCL: Boolean = false, useNpu: Boolean = false) = withContext(Dispatchers.IO) {
        if (modelDir == loadedTripleComboDir && numRegions == loadedTripleComboN) return@withContext
        if (sdTripleComboCtx != 0L) { NativeBridge.sdFreeTripleCombo(sdTripleComboCtx); sdTripleComboCtx = 0 }
        val unetPath = "$modelDir/unet_triple_combo_${numRegions}region.mnn"
        val ipEncoderPath = "$modelDir/ip_image_encoder.mnn"
        sdTripleComboCtx = NativeBridge.sdInitTripleCombo(
            modelDir, "$modelDir/clip.mnn", unetPath,
            "$modelDir/vae_decoder.mnn", "$modelDir/vae_encoder.mnn",
            ipEncoderPath, "$modelDir/tokenizer.json", embeddingsDir, numRegions, useOpenCL, useNpu
        )
        if (sdTripleComboCtx == 0L) throw RuntimeException(
            "Không load được pipeline Triple-Conditioning combo tại $modelDir.\n" +
            "Thiếu file $unetPath hoặc $ipEncoderPath — kiểm tra đã chạy tools/export_ipa_controlnet_triple_combo_unet.py " +
            "--num_regions $numRegions và convert sang .mnn chưa.\n(xem logcat tag MangaLocal_TripleCombo)")
        loadedTripleComboDir = modelDir
        loadedTripleComboN = numRegions
    }

    fun isTripleComboLoaded() = sdTripleComboCtx != 0L

    /**
     * mục 151 TECHNICAL_STATUS.md — regionPrompts/referenceImagePaths PHẢI
     * CÙNG ĐỘ DÀI, CÙNG THỨ TỰ (1 cột = 1 nhân vật, khớp cả prompt chữ lẫn
     * danh tính ảnh — xem GIỚI HẠN THẬT trong docstring export script:
     * ranh giới cột cứng, KHÔNG phù hợp cảnh ôm/đan xen). Tái dùng
     * renderSkeletonCanvas()/renderDepthHintCanvas() y hệt generatePanelRegional()
     * ở trên — 2 canvas RIÊNG (pose + depth), không phải 1.
     */
    suspend fun generatePanelTripleCombo(
        panelIndex: Int, regionPrompts: List<String>, negativePrompt: String,
        referenceImagePaths: List<String>, skeletonData: FloatArray,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outDir: File, onProgress: (Int, Int) -> Unit,
        poseScale: Float = 1.0f, depthScale: Float = 0.6f,
        ipDecayFloor: Float = 1.0f, ipDecayStartTimestep: Float = 999.0f
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val controlSize = 512
        val poseHint = NativeBridge.renderSkeletonCanvas(skeletonData, controlSize)
        val depthHint = NativeBridge.renderDepthHintCanvas(skeletonData, controlSize)
        val blankHint = ByteArray(controlSize * controlSize * 3)
        val safePoseHint = if (poseHint.size == blankHint.size) poseHint else blankHint
        val safeDepthHint = if (depthHint.size == blankHint.size) depthHint else blankHint
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        val ok = NativeBridge.sdTxt2ImgTripleCombo(
            sdTripleComboCtx, regionPrompts.toTypedArray(), negativePrompt,
            referenceImagePaths.toTypedArray(), safePoseHint, safeDepthHint, controlSize,
            width, height, steps, cfgScale, seed, outFile.absolutePath,
            poseScale, depthScale, ipDecayFloor, ipDecayStartTimestep, cb
        )
        if (!ok) throw RuntimeException("SD generate (triple combo) thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // mục 115/117 TECHNICAL_STATUS.md — Multi-Pass Inpainting Cascade,
    // lượt 2..N+1 (lượt 1 là generatePanelMultiChar()/generatePanelRegional()
    // ở trên, không đổi). Ghi ĐÈ lên outFile TRUYỀN VÀO (basePanelPath) —
    // cascade là chuỗi TUẦN TỰ, mỗi lượt sửa tiếp kết quả lượt trước, không
    // tạo file mới mỗi lần (khớp đúng ý nghĩa "cascade": người 2 inpaint
    // TRÊN NỀN ảnh đã có người 1 được sửa xong, không phải trên ảnh gốc).
    suspend fun inpaintCharacterInCascade(
        panelIndex: Int, characterOrderInCascade: Int,
        prompt: String, negativePrompt: String,
        basePanelPath: String, maskPath: String, referenceImagePath: String,
        skeletonData: FloatArray, denoiseStrength: Float,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outDir: File, onProgress: (Int, Int) -> Unit,
        ipDecayFloor: Float = 1.0f, ipDecayStartTimestep: Float = 999.0f, ipStaticScale: Float = 1.3f
    ): String = withContext(Dispatchers.IO) {
        // Seed lệch theo characterOrderInCascade để KHÔNG trùng seed lượt
        // nền (seed giống hệt + denoise thấp dễ ra kết quả gần như y hệt
        // input, không sửa được gì) — lệch cố định (deterministic), không
        // ngẫu nhiên (giữ khả năng tái tạo đúng kết quả cũ khi debug).
        val cascadeSeed = seed + (characterOrderInCascade + 1) * 733L
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex)) // GHI ĐÈ file nền
        onProgress(0, steps)
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, totalSteps: Int) = onProgress(step, totalSteps)
        }
        val ok = NativeBridge.sdImg2ImgWithReferenceAndPose(
            sdAugmentedCtx, prompt, negativePrompt,
            basePanelPath, maskPath, referenceImagePath, skeletonData, denoiseStrength,
            width, height, steps, cfgScale, cascadeSeed, outFile.absolutePath,
            ipDecayFloor = ipDecayFloor, ipDecayStartTimestep = ipDecayStartTimestep,
            ipStaticScale = ipStaticScale, callback = cb
        )
        onProgress(steps, steps)
        if (!ok) throw RuntimeException("Cascade inpaint thất bại tại panel ${panelIndex + 1}, nhân vật thứ ${characterOrderInCascade + 1}")
        outFile.absolutePath
    }

    suspend fun generatePanel(
        panelIndex: Int,
        prompt: String,
        negativePrompt: String,
        stylePrompt: String,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        referenceImagePath: String?,
        // Toạ độ khung xương ĐÃ RETARGET (mục 32/33 TECHNICAL_STATUS.md) —
        // tính sẵn ở MangaPipeline qua PoseRetargeter.kt trước khi gọi hàm
        // này. Rỗng = không có pose cụ thể, native tự dùng fallback đứng.
        skeletonData: FloatArray,
        useStoryDiffusion: Boolean,
        outDir: File,
        onProgress: (Int, Int) -> Unit,
        // mục 81 TECHNICAL_STATUS.md — mặc định khớp NativeBridge (Pose ưu
        // thế, Depth hỗ trợ nhẹ, chỉ bật early-to-mid step). Model .mnn cũ
        // (chưa export lại) bỏ qua 3 giá trị này an toàn.
        poseConditioningScale: Float = 1.0f,
        depthConditioningScale: Float = 0.6f,
        depthActiveMinTimestep: Float = 300.0f,
        // Smooth Timestep Decay IP-Adapter — xem NativeBridge.kt cho ghi chú
        // đầy đủ. Default = không suy giảm gì (tương thích ngược).
        ipDecayFloor: Float = 1.0f,
        ipDecayStartTimestep: Float = 999.0f,
        // mục 9 — đóng gap "consistencyStrength chết", xem NativeBridge.kt.
        ipStaticScale: Float = 1.0f
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panelIndex))
        val fullPrompt = prompt + ", " + stylePrompt

        val ok = if (useStoryDiffusion && referenceImagePath != null) {
            // mục 134 TECHNICAL_STATUS.md — trước đây pipeline augmented
            // KHÔNG có callback tiến trình per-step (khác pipeline thường),
            // báo tiến trình GIẢ ở mức panel. Đã nối THẬT ở
            // sdTxt2ImgWithReferenceAndPose (ip_adapter.cpp) — dùng chung
            // đúng object SDProgressCallback với nhánh else bên dưới.
            val cb = object : NativeBridge.SDProgressCallback {
                override fun onProgress(step: Int, total: Int) = onProgress(step, total)
            }
            NativeBridge.sdTxt2ImgWithReferenceAndPose(
                sdAugmentedCtx, fullPrompt, negativePrompt, referenceImagePath, skeletonData,
                width, height, steps, cfgScale, seed,
                outFile.absolutePath,
                poseConditioningScale, depthConditioningScale, depthActiveMinTimestep,
                ipDecayFloor, ipDecayStartTimestep, ipStaticScale, cb
            )
        } else {
            val cb = object : NativeBridge.SDProgressCallback {
                override fun onProgress(step: Int, total: Int) = onProgress(step, total)
            }
            NativeBridge.sdTxt2Img(
                sdCtx, fullPrompt, negativePrompt,
                width, height, steps, cfgScale, seed,
                outFile.absolutePath, cb
            )
        }
        if (!ok) throw RuntimeException("SD generate thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    // img2img / inpaint / Ultrafix (mục 16 TECHNICAL_STATUS.md). Dùng sdCtx
    // (pipeline THƯỜNG, không phải augmented — Ultrafix/inpaint CHƯA thử
    // nghiệm kết hợp với IP-Adapter/ControlNet-Pose cùng lúc, để dành sau
    // nếu thực tế cần). Yêu cầu đã gọi loadSD() trước (giống generatePanel).
    //
    // maskPath = null -> img2img thường (vẽ lại toàn ảnh theo denoiseStrength).
    // maskPath != null -> inpaint thật, chỉ vẽ lại vùng trắng trong mask.
    // ultrafix = true -> upscale-vẽ-lại: inputPath PHẢI đã là ảnh upscale sẵn
    // (vd qua ESRGAN), width/height = kích thước ĐÍCH (đã upscale), không
    // phải kích thước gốc 512.
    suspend fun img2imgFix(
        panelIndex: Int, prompt: String, negativePrompt: String, stylePrompt: String,
        inputPath: String, maskPath: String?, denoiseStrength: Float,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        ultrafix: Boolean, ultrafixTile: Int, outDir: File, onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val suffix = if (ultrafix) "ultrafix" else "fix"
        val outFile = File(outDir, "panel_%03d_%s.png".format(panelIndex, suffix))
        val fullPrompt = prompt + ", " + stylePrompt
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        val ok = NativeBridge.sdImg2Img(
            sdCtx, fullPrompt, negativePrompt, inputPath, maskPath ?: "",
            denoiseStrength, width, height, steps, cfgScale, seed,
            ultrafix, ultrafixTile, outFile.absolutePath, cb
        )
        if (!ok) throw RuntimeException("img2img/inpaint thất bại tại panel ${panelIndex + 1}")
        outFile.absolutePath
    }

    suspend fun upscale(inputPath: String, panelIndex: Int, outDir: File, option: UpscaleOption): String =
        withContext(Dispatchers.IO) {
            if (option == UpscaleOption.NONE) return@withContext inputPath
            val outFile = File(outDir, "panel_%03d_hd.png".format(panelIndex))
            val ok = NativeBridge.esrganUpscale(esrganCtx, inputPath, outFile.absolutePath, option.sharpen)
            if (!ok) throw RuntimeException("Upscale thất bại tại panel ${panelIndex + 1}")
            outFile.absolutePath
        }

    fun isSdLoaded() = sdCtx != 0L

    fun freeAll() {
        if (sdCtx != 0L) { NativeBridge.sdFree(sdCtx); sdCtx = 0; loadedSdPath = ""; loadedSdEmbeddingsSig = "" }
        if (sdAugmentedCtx != 0L) { NativeBridge.sdFreeAugmented(sdAugmentedCtx); sdAugmentedCtx = 0; loadedAugmentedDir = ""; loadedAugmentedEmbeddingsSig = "" }
        if (esrganCtx != 0L) { NativeBridge.esrganFree(esrganCtx); esrganCtx = 0 }
        // mục 131 TECHNICAL_STATUS.md — user hỏi "ngoài LLM ra các model
        // khác thì sao" dẫn tới audit toàn hệ thống, phát hiện sdRegionalCtx
        // (Regional Prompting UNet) tự free-cũ-trước-khi-tạo-mới ĐÚNG (dòng
        // ~166) nhưng BỊ THIẾU khỏi freeAll() — cùng loại bug với poseExtractor
        // (MangaPipeline.kt). Nếu 1 truyện từng dùng Regional Prompting rồi
        // chuyển hẳn sang chế độ khác, context UNet Regional (có thể vài
        // trăm MB - vài GB tuỳ model) vẫn giữ trong RAM vĩnh viễn dù
        // freeAll() được gọi tưởng đã dọn sạch hoàn toàn.
        // Reset CẢ path-cache (loadedRegionalDir/N) — không chỉ ctx=0.
        // Nếu chỉ reset ctx mà giữ nguyên cache path, lần loadSDRegional()
        // kế tiếp với CÙNG modelDir sẽ bị check `modelDir == loadedRegionalDir`
        // đánh lừa là "đã nạp sẵn", bỏ qua tái khởi tạo — dùng nhầm ctx=0
        // (đã free) cho generate() thật, gây crash hoặc lỗi âm thầm. Cùng
        // lỗi tiềm ẩn này KHÔNG xảy ra với sdCtx/sdAugmentedCtx ở trên vì 2
        // dòng đó đã tự reset path-cache riêng của chúng (loadedSdPath/
        // loadedAugmentedDir) — chỉ sdRegionalCtx bị bỏ sót bước này.
        if (sdRegionalCtx != 0L) {
            NativeBridge.sdFreeRegional(sdRegionalCtx); sdRegionalCtx = 0
            loadedRegionalDir = ""; loadedRegionalN = 0
        }
        // mục 151 TECHNICAL_STATUS.md — thêm ctx MỚI (Triple-Conditioning
        // combo) NGAY TỪ ĐẦU vào freeAll() + reset path-cache đầy đủ — rút
        // kinh nghiệm trực tiếp từ bug mục 131 vừa đọc ở trên (sdRegionalCtx
        // từng bị sót), không lặp lại cùng lỗi cho ctx mới thêm.
        if (sdTripleComboCtx != 0L) {
            NativeBridge.sdFreeTripleCombo(sdTripleComboCtx); sdTripleComboCtx = 0
            loadedTripleComboDir = ""; loadedTripleComboN = -1
        }
    }

    fun freeEsrganOnly() {
        if (esrganCtx != 0L) { NativeBridge.esrganFree(esrganCtx); esrganCtx = 0 }
    }
}
