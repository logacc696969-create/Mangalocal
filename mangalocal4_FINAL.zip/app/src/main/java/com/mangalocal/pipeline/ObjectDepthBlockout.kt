package com.mangalocal.pipeline

import com.mangalocal.model.ObjectBox

/**
 * mục 260 TECHNICAL_STATUS.md — "KHỐI ĐỘ SÂU" CHO VẬT THỂ (blockout): ép VỊ TRÍ + KÍCH THƯỚC vật thể ở panel CÓ nhân vật bằng đúng ControlNet-Depth
 * mà đồ thị Triple-Combo đã có, KHÔNG cần model/đồ thị mới.
 *
 * Vấn đề (mục 225/259.5): GLIGEN (hộp vật thể) chỉ dùng được cho panel KHÔNG nhân vật; ở panel có nhân vật, `Scene.objectBoxes` chỉ được dùng để
 * KIỂM TRA tỉ lệ sau khi sinh (ScaleConsistencyChecker) chứ chưa điều khiển lúc sinh. Tra cứu (mục 260): ControlNet-Depth nhận bản đồ độ sâu
 * 512x512 đầy đủ và dựng cấu trúc theo bản đồ đó; "dựng khối thô rồi dùng làm depth" là cách cộng đồng dùng để khoá bố cục/tỉ lệ mà không sửa sampler.
 *
 * Cách làm: vẽ mỗi hộp vật thể thành MỘT MẢNG PHẲNG ở mức sáng [LEVEL] lên bản đồ độ sâu `renderDepthHintCanvas` đã có. Quy ước của bản đồ đó
 * (ip_adapter.cpp, mục 232): nền = 0 (xa vô cực), người/chi nằm trong [48..255] (kDepthFloor = 48, GẦN = sáng). LEVEL < 48 nên:
 *   - vật thể luôn nằm SAU mọi người (người đè lên vật thể đúng kiểu che khuất, không bao giờ bị vật thể xoá);
 *   - chỉ tô lên pixel TỐI HƠN LEVEL (nền, hoặc mảng vật thể khác tối hơn) — phép "gần thắng" như z-buffer của người.
 *
 * GIỚI HẠN THẬT (không hạ thấp):
 *   - CHƯA có ảnh thật nào chứng minh ControlNet-Depth biến mảng phẳng thành đúng vật thể; mảng chữ nhật dễ ra vật thể "vuông như hộp" (hợp bàn/tủ,
 *     không hợp vật tròn). Là THỬ NGHIỆM, mặc định TẮT (`GenerationSettings.objectDepthBlockout`).
 *   - Mặc định mọi vật thể nằm SAU người. Mục 263: hộp có `front = true` được vẽ SAU CÙNG ở mức SÁNG HƠN người trong hộp (che người đúng kiểu z-buffer) —
 *     xem [applyFront]. Hạn chế: một mức độ sâu cho cả hộp; che kín người trong hộp thì ControlNet không còn thấy người ở đó nên có CHỐT: nếu hộp phủ > 60%
 *     số pixel người của cả ảnh thì KHÔNG che, hộp rơi về "sau người" (giữ vị trí/kích thước, bỏ việc che).
 *   - Không biết hộp là vật gì (nhãn không đi vào bản đồ độ sâu; nhãn chỉ ở prompt chữ); chỉ ảnh hưởng nhánh Triple-Combo SD1.5 (nơi depth được nạp).
 *   - Độ mạnh thật do `depthConditioningScale` quyết định (chung cho người và vật thể) — chưa có thang riêng cho vật thể.
 */
object ObjectDepthBlockout {

    /** Mức sáng của mảng vật thể. PHẢI < mức sàn người của renderDepthHint (kDepthFloor = 48) — test đối chiếu thẳng với ip_adapter.cpp. */
    const val LEVEL = 36

    /** mục 263 — mức sàn của người trong bản đồ độ sâu (kDepthFloor trong ip_adapter.cpp): pixel >= mức này là người (hoặc vật "trước"). */
    const val PERSON_FLOOR = 48
    /** Vật "trước" sáng hơn pixel người sáng nhất trong hộp thêm ngần này (kẹp 255). */
    const val FRONT_MARGIN = 24
    /** Mức của vật "trước" khi trong hộp KHÔNG có người nào (không có gì để che): đủ sáng để nằm trước nền/vật phía sau, chưa chạm trần. */
    const val FRONT_MIN_LEVEL = 96
    /** Chốt che người: hộp "trước" phủ quá tỉ lệ % này TỔNG pixel người của cả ảnh thì không che (xem mô tả ở đầu file). Heuristic, CHƯA đo trên ảnh thật. */
    const val MAX_PERSON_OCCLUSION_PCT = 60

    /**
     * @param hint bản đồ độ sâu RGB `size*size*3` (3 kênh bằng nhau) từ NativeBridge.renderDepthHintCanvas
     * @return bản sao đã vẽ vật thể; sai kích thước/không có hộp -> trả NGUYÊN `hint` (không đổi hành vi)
     */
    fun apply(hint: ByteArray, size: Int, boxes: List<ObjectBox>): ByteArray {
        if (boxes.isEmpty() || size <= 0 || hint.size != size * size * 3) return hint
        val out = hint.copyOf()
        val level = LEVEL.toByte()
        for (b in boxes) {
            if (b.front) continue  // mục 263: hộp "trước người" vẽ ở lượt sau (applyFront)
            // Hộp suy biến (xmax<=xmin, ymax<=ymin) hoặc có NaN: bỏ qua TRƯỚC khi đổi sang pixel — floor/ceil sẽ nở hộp rộng 0 thành 1 pixel,
            // và so sánh với NaN luôn sai nên `!(a > b)` bắt được cả NaN.
            if (!(b.xmax > b.xmin && b.ymax > b.ymin)) continue
            val x0 = Math.floor((b.xmin.coerceIn(0f, 1f) * size).toDouble()).toInt().coerceIn(0, size)
            val x1 = Math.ceil((b.xmax.coerceIn(0f, 1f) * size).toDouble()).toInt().coerceIn(0, size)
            val y0 = Math.floor((b.ymin.coerceIn(0f, 1f) * size).toDouble()).toInt().coerceIn(0, size)
            val y1 = Math.ceil((b.ymax.coerceIn(0f, 1f) * size).toDouble()).toInt().coerceIn(0, size)
            if (x1 <= x0 || y1 <= y0) continue
            for (y in y0 until y1) {
                var i = (y * size + x0) * 3
                for (x in x0 until x1) {
                    if ((out[i].toInt() and 0xFF) < LEVEL) {
                        out[i] = level; out[i + 1] = level; out[i + 2] = level
                    }
                    i += 3
                }
            }
        }
        val fronts = boxes.filter { it.front }
        if (fronts.isNotEmpty()) applyFront(out, size, fronts)
        return out
    }

    /** Hộp chuẩn hoá -> pixel x0 tới x1 trừ 1 và y0 tới y1 trừ 1 (cận trên không gồm); null nếu suy biến hoặc NaN. Cùng quy tắc với lượt "sau người". */
    private fun pixelRect(b: ObjectBox, size: Int): IntArray? {
        if (!(b.xmax > b.xmin && b.ymax > b.ymin)) return null
        val x0 = Math.floor((b.xmin.coerceIn(0f, 1f) * size).toDouble()).toInt().coerceIn(0, size)
        val x1 = Math.ceil((b.xmax.coerceIn(0f, 1f) * size).toDouble()).toInt().coerceIn(0, size)
        val y0 = Math.floor((b.ymin.coerceIn(0f, 1f) * size).toDouble()).toInt().coerceIn(0, size)
        val y1 = Math.ceil((b.ymax.coerceIn(0f, 1f) * size).toDouble()).toInt().coerceIn(0, size)
        return if (x1 <= x0 || y1 <= y0) null else intArrayOf(x0, y0, x1, y1)
    }

    /**
     * mục 263 — vẽ các hộp "TRƯỚC người". Thống kê về người (tổng pixel người, pixel người trong hộp, mức sáng nhất) lấy từ ẢNH CHỤP sau lượt "sau người"
     * nên KHÔNG phụ thuộc thứ tự các hộp "trước" với nhau. Mỗi hộp: nếu phủ > MAX_PERSON_OCCLUSION_PCT tổng pixel người -> rơi về mức LEVEL (sau người);
     * ngược lại mức = min(255, người sáng nhất trong hộp + FRONT_MARGIN) (không có người: FRONT_MIN_LEVEL). Chỉ tô pixel TỐI HƠN mức (z-buffer).
     */
    private fun applyFront(out: ByteArray, size: Int, fronts: List<ObjectBox>) {
        val snap = out.copyOf()
        var totalPerson = 0
        for (i in 0 until size * size) if ((snap[i * 3].toInt() and 0xFF) >= PERSON_FLOOR) totalPerson++
        for (b in fronts) {
            val r = pixelRect(b, size) ?: continue
            var inBox = 0
            var maxP = 0
            for (y in r[1] until r[3]) for (x in r[0] until r[2]) {
                val v = snap[(y * size + x) * 3].toInt() and 0xFF
                if (v >= PERSON_FLOOR) { inBox++; if (v > maxP) maxP = v }
            }
            val tooMuch = totalPerson > 0 && inBox * 100 > totalPerson * MAX_PERSON_OCCLUSION_PCT
            val level = if (tooMuch) LEVEL else if (maxP > 0) minOf(255, maxP + FRONT_MARGIN) else FRONT_MIN_LEVEL
            val lb = level.toByte()
            for (y in r[1] until r[3]) {
                var i = (y * size + r[0]) * 3
                for (x in r[0] until r[2]) {
                    if ((out[i].toInt() and 0xFF) < level) { out[i] = lb; out[i + 1] = lb; out[i + 2] = lb }
                    i += 3
                }
            }
        }
    }
}
