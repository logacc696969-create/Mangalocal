package com.mangalocal.pipeline

import com.mangalocal.model.*
import java.io.File
import java.util.UUID

class BubbleEngine(private val storyManager: StoryManager) {

    private var yoloCtx: Long = 0

    fun loadYolo(): Boolean {
        if (!storyManager.hasYolo()) return false
        yoloCtx = NativeBridge.yoloInit(storyManager.yoloDir.absolutePath)
        return yoloCtx != 0L
    }

    fun freeYolo() {
        if (yoloCtx != 0L) { NativeBridge.yoloFree(yoloCtx); yoloCtx = 0 }
    }

    /**
     * Tự động đặt bubble dựa trên vị trí nhân vật trong ảnh.
     * YOLOv8 detect face → tính vị trí bubble không che mặt.
     */
    fun autoPplaceBubbles(imagePath: String, dialogues: List<DialogueLine>): List<Bubble> {
        if (dialogues.isEmpty()) return emptyList()

        val detections = if (yoloCtx != 0L && File(imagePath).exists()) {
            NativeBridge.yoloDetect(yoloCtx, imagePath)
                .toList()
                .chunked(5) // [x1,y1,x2,y2,conf]
                .filter { it.size == 5 && it[4] > 0.4f }
                .map { BoundingBox(it[0], it[1], it[2], it[3], it[4]) }
        } else emptyList()

        return dialogues.mapIndexed { i, dialogue ->
            val pos = calculateBubblePosition(detections, i, dialogues.size)
            Bubble(
                id = UUID.randomUUID().toString(),
                characterName = dialogue.characterName,
                text = dialogue.text,
                type = dialogue.type,
                xNorm = pos.first,
                yNorm = pos.second,
                widthNorm = 0.42f,
                isAutoPlaced = true
            )
        }
    }

    /**
     * Tính vị trí bubble tối ưu:
     * - Không đặt lên mặt nhân vật (từ detection boxes)
     * - Phân bố đều nếu có nhiều bubble
     * - Ưu tiên góc trên nếu không có detection
     */
    private fun calculateBubblePosition(
        detections: List<BoundingBox>,
        bubbleIndex: Int,
        totalBubbles: Int
    ): Pair<Float, Float> {
        // Chia màn hình thành các vùng an toàn
        val safeZones = listOf(
            Pair(0.05f, 0.04f),  // góc trên trái
            Pair(0.53f, 0.04f),  // góc trên phải
            Pair(0.05f, 0.55f),  // góc dưới trái
            Pair(0.53f, 0.55f),  // góc dưới phải
            Pair(0.05f, 0.28f),  // giữa trái
            Pair(0.53f, 0.28f)   // giữa phải
        )

        if (detections.isEmpty()) {
            // Không có detection → phân bố theo grid đơn giản
            val zone = safeZones[bubbleIndex % safeZones.size]
            return zone
        }

        // Tìm vùng ít bị che nhất
        val scored = safeZones.map { zone ->
            val overlap = detections.sumOf { det ->
                overlapArea(zone.first, zone.second, 0.42f, 0.18f,
                    det.x1, det.y1, det.x2 - det.x1, det.y2 - det.y1).toDouble()
            }
            Pair(zone, overlap)
        }.sortedBy { it.second }

        return scored[bubbleIndex % scored.size].first
    }

    private fun overlapArea(
        ax: Float, ay: Float, aw: Float, ah: Float,
        bx: Float, by: Float, bw: Float, bh: Float
    ): Float {
        val ox = maxOf(0f, minOf(ax + aw, bx + bw) - maxOf(ax, bx))
        val oy = maxOf(0f, minOf(ay + ah, by + bh) - maxOf(ay, by))
        return ox * oy
    }

    /**
     * Tạo bubble mặc định từ dialogue khi không có YOLO
     */
    fun defaultBubbles(dialogues: List<DialogueLine>): List<Bubble> {
        val positions = listOf(
            Pair(0.05f, 0.04f), Pair(0.53f, 0.04f),
            Pair(0.05f, 0.52f), Pair(0.53f, 0.52f),
            Pair(0.05f, 0.28f), Pair(0.53f, 0.28f)
        )
        return dialogues.mapIndexed { i, d ->
            val pos = positions[i % positions.size]
            Bubble(UUID.randomUUID().toString(), d.characterName, d.text, d.type,
                pos.first, pos.second, 0.40f, false)
        }
    }

    // ── mục 228 TECHNICAL_STATUS.md — đặt bubble THEO NGƯỜI NÓI ─────────────
    // Khác autoPplaceBubbles() ở trên (chỉ né các hộp YOLO, không biết AI
    // đang nói): nhận vị trí ĐẦU từng nhân vật (lấy từ chính khung xương đã
    // feed ControlNet cho panel — ảnh sinh ra bám theo khung xương nên đầu
    // nằm gần đúng chỗ đó), rồi:
    //  - đặt bubble GẦN người nói nhưng KHÔNG che đầu bất kỳ ai,
    //  - giữ thứ tự đọc (bubble sau không nằm cao hơn bubble trước),
    //  - gắn tail trỏ về miệng người nói (tailXNorm/tailYNorm).
    // NARRATION không có người nói -> đặt ở mép trên/dưới, không tail.
    // Hàm THUẦN (không đọc file/native) nên kiểm chứng được bằng mô phỏng
    // Python (tools/test_bubble_placement.py). Người nói không có trong
    // `heads` (khung xương thiếu/không khớp tên) -> bubble vẫn được đặt né
    // mặt nhưng KHÔNG có tail (an toàn hơn trỏ sai người).
    //
    // GIỚI HẠN THẬT: vị trí đầu là của khung xương ĐẦU VÀO, không phải đầu
    // dò lại từ ảnh — nếu ControlNet không bám khung xương (panel nhánh
    // GLIGEN/SDXL không dùng pose) đầu thật có thể lệch; người dùng vẫn kéo
    // được bubble/sửa tay như trước. Kích thước bubble ở đây chỉ là ƯỚC LƯỢNG
    // để né nhau; kích thước vẽ thật do ExportEngine.layoutBubble() quyết định.
    fun placeWithSpeakers(
        dialogues: List<DialogueLine>,
        heads: Map<String, Pair<Float, Float>>,
        widthNorm: Float = 0.42f
    ): List<Bubble> {
        if (dialogues.isEmpty()) return emptyList()
        val faceR = 0.09f
        val faceBoxes = heads.values.map { RectN(it.first - faceR, it.second - faceR, it.first + faceR, it.second + faceR) }
        val placed = mutableListOf<RectN>()
        val out = mutableListOf<Bubble>()
        var prevCenterY = -1f

        dialogues.forEach { d ->
            val h = estimateHeightNorm(d.text, widthNorm)
            val head = heads[d.characterName]
                ?: heads.entries.firstOrNull { it.key.equals(d.characterName, ignoreCase = true) }?.value
            val cands = mutableListOf<Pair<Float, Float>>()
            if (d.type == BubbleType.NARRATION || head == null) {
                cands += Pair(0.03f, 0.02f); cands += Pair(0.55f, 0.02f)
                cands += Pair(0.03f, 0.98f - h); cands += Pair(0.55f, 0.98f - h)
                for (z in listOf(Pair(0.05f, 0.30f), Pair(0.53f, 0.30f))) cands += z
            } else {
                val (hx, hy) = head
                cands += Pair(hx - widthNorm / 2f, hy - h - 0.12f)        // ngay trên đầu
                cands += Pair(hx - widthNorm + 0.05f, hy - h - 0.10f)     // trên-trái
                cands += Pair(hx - 0.05f, hy - h - 0.10f)                 // trên-phải
                cands += Pair(hx + 0.10f, hy - h / 2f)                    // bên phải
                cands += Pair(hx - 0.10f - widthNorm, hy - h / 2f)        // bên trái
                cands += Pair(hx - widthNorm / 2f, hy + 0.14f)            // dưới đầu (phương án cuối)
            }
            var best: RectN? = null
            var bestCost = Float.MAX_VALUE
            cands.forEach { (cx, cy) ->
                val x = cx.coerceIn(0.02f, (0.98f - widthNorm).coerceAtLeast(0.02f))
                val y = cy.coerceIn(0.02f, (0.98f - h).coerceAtLeast(0.02f))
                val r = RectN(x, y, x + widthNorm, y + h)
                var cost = 0f
                faceBoxes.forEach { cost += 1000f * r.overlapArea(it) / (faceR * faceR * 4f) }
                placed.forEach { cost += 300f * r.overlapArea(it) / (widthNorm * h) }
                if (head != null && d.type != BubbleType.NARRATION) {
                    cost += 5f * kotlin.math.hypot(r.cx() - head.first, r.cy() - head.second)
                }
                // Thứ tự đọc: bubble sau KHÔNG nên nằm cao hơn bubble trước.
                if (prevCenterY >= 0f) cost += 2f * (prevCenterY - r.cy()).coerceAtLeast(0f)
                if (cost < bestCost) { bestCost = cost; best = r }
            }
            val r = best!!
            placed += r
            prevCenterY = r.cy()
            val hasTail = head != null && d.type != BubbleType.NARRATION
            out += Bubble(
                id = UUID.randomUUID().toString(), characterName = d.characterName, text = d.text,
                type = d.type, xNorm = r.x1, yNorm = r.y1, widthNorm = widthNorm, isAutoPlaced = true,
                tailXNorm = if (hasTail) head!!.first else null,
                tailYNorm = if (hasTail) (head!!.second + 0.03f).coerceAtMost(0.98f) else null // ~miệng, thấp hơn tâm đầu
            )
        }
        return out
    }

    /** Ước lượng chiều cao bubble (chuẩn hoá) chỉ để né nhau lúc đặt chỗ. */
    fun estimateHeightNorm(text: String, widthNorm: Float): Float {
        val charsPerLine = (widthNorm / 0.026f).toInt().coerceAtLeast(8)
        val lines = ((text.length + charsPerLine - 1) / charsPerLine).coerceIn(1, 8)
        return (0.045f + lines * 0.036f).coerceAtMost(0.40f)
    }

    private data class RectN(val x1: Float, val y1: Float, val x2: Float, val y2: Float) {
        fun cx() = (x1 + x2) / 2f
        fun cy() = (y1 + y2) / 2f
        fun overlapArea(o: RectN): Float {
            val ox = maxOf(0f, minOf(x2, o.x2) - maxOf(x1, o.x1))
            val oy = maxOf(0f, minOf(y2, o.y2) - maxOf(y1, o.y1))
            return ox * oy
        }
    }

    data class BoundingBox(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val conf: Float)
}
