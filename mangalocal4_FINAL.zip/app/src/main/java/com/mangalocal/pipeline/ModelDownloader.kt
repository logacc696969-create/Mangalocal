package com.mangalocal.pipeline

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

// mục 161 TECHNICAL_STATUS.md (đợt 3) — "#4 Dynamic Model Delivery" (đề
// xuất từ đợt audit PDF ngoài, mục 146/161). TÁCH RIÊNG file này khỏi
// StoryManager.kt (nơi định nghĩa DownloadTarget/listDownloadTargets()) —
// đúng ranh giới đã có trong dự án: StoryManager chỉ đọc/ghi dữ liệu cục
// bộ (không I/O mạng), còn NetworkGenerationClient.kt (Remote GPU, mục
// 45/46) mới là nơi làm việc thật với mạng — ModelDownloader.kt theo đúng
// tiền lệ đó, không trộn 2 việc vào 1 class.
//
// GIỚI HẠN THẬT (đọc trước khi dùng):
// 1. KHÔNG resume (không dùng HTTP Range) — mất mạng giữa chừng phải tải
//    lại TỪ ĐẦU file đó. Model .mnn có thể vài trăm MB tới hơn 1GB (UNet
//    augmented) — trên mạng di động, mất giữa chừng nhiều lần là rủi ro
//    thật. Resume qua Range dễ thêm sau nếu cần (server hỗ trợ Range là
//    tiêu chuẩn HTTP, không cần đổi phía server) nhưng CHƯA làm ở đợt này
//    — ưu tiên có bản chạy được trước, tối ưu sau.
// 2. KHÔNG có checksum verify (sha256) sau khi tải xong — CHỈ kiểm tra
//    file tồn tại + kích thước > 0. File tải lỗi giữa chừng nhưng server
//    trả về đủ status 200 (hiếm nhưng có thể) sẽ KHÔNG bị phát hiện. Nếu
//    cần độ tin cậy cao hơn, nên bổ sung field sha256 vào
//    ManifestModelFiles.download tương lai — chưa làm vì thêm 1 lớp phức
//    tạp (tính hash tốn thời gian với file GB-size) trong khi mục tiêu
//    đợt này là "có tải được", không phải "tải hoàn hảo".
// 3. QUAN TRỌNG NHẤT: đây CHỈ LÀ HẠ TẦNG PHÍA APP. Không có URL thật nào
//    được điền sẵn trong assets/model_manifest.json — Claude không có
//    quyền mạng để tự tải/upload model thật lên bất kỳ đâu (sandbox này
//    KHÔNG có mạng, và kể cả có, Claude không biết bạn muốn host ở
//    đâu/GitHub repo nào). Người dùng THẬT phải tự:
//    a) Chạy prepare_models.yml xong, có các file .mnn trong Artifact.
//    b) Tạo 1 GitHub Release (KHÔNG PHẢI Actions Artifact — artifact hết
//       hạn theo `retention-days` trong workflow, hiện đang là 30 ngày,
//       không phù hợp lưu lâu dài; Release thì KHÔNG hết hạn, hỗ trợ file
//       tới 2GB/asset — xem https://docs.github.com/repositories/releasing-projects-on-github),
//       tự upload các file .mnn vào đó làm asset.
//    c) Copy URL asset (dạng
//       https://github.com/<user>/<repo>/releases/download/<tag>/<file>)
//       dán vào đúng field `download` tương ứng trong model_manifest.json
//       (bản LIVE trong rootDir, sửa qua máy tính/Files app rồi copy vào
//       máy, hoặc qua UI "Sửa URL tải" nếu đã bật — xem SettingsScreen.kt).
//    Không làm bước (b)/(c) thì toàn bộ danh sách `listDownloadTargets()`
//    sẽ có `url = null` cho mọi file — UI tự hiện "phải tự tải tay" đúng
//    y hệt hành vi TRƯỚC KHI có tính năng này, không có gì bị hỏng, chỉ
//    đơn giản là tính năng chưa có gì để tải.
object ModelDownloader {

    sealed class DownloadResult {
        data class Success(val bytesWritten: Long) : DownloadResult()
        data class Failed(val message: String) : DownloadResult()
    }

    // mục 161 (đợt 3) — tải 1 file, ghi ra `<dest>.part` trước rồi RENAME
    // sang tên thật chỉ khi tải xong trọn vẹn (đọc hết InputStream không
    // lỗi) — nếu app bị kill/mất mạng giữa chừng, lần sau `File(dest).exists()`
    // vẫn trả false đúng (file .part dở dang không tính là "đã có"), tự
    // thử lại sạch từ đầu thay vì để lại 1 file .mnn NỬA VỜI mà code khác
    // (sdInit() ở JNI) tưởng nhầm là hợp lệ rồi crash khó hiểu lúc load.
    suspend fun download(
        target: StoryManager.DownloadTarget,
        onProgress: (bytesDownloaded: Long, totalBytes: Long) -> Unit
    ): DownloadResult = withContext(Dispatchers.IO) {
        val url = target.url
        if (url.isNullOrBlank()) return@withContext DownloadResult.Failed("Không có URL khai báo trong model_manifest.json cho ${target.label}")
        val partFile = File(target.destFile.parentFile, target.destFile.name + ".part")
        var connection: HttpURLConnection? = null
        try {
            target.destFile.parentFile?.mkdirs()
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                instanceFollowRedirects = true // GitHub Release asset URL redirect qua objects.githubusercontent.com — BẮT BUỘC bật, tắt sẽ tải nhầm trang lỗi thay vì file thật
            }
            val code = connection.responseCode
            if (code !in 200..299) {
                return@withContext DownloadResult.Failed("Server trả về HTTP $code cho $url — kiểm tra URL còn hợp lệ không (Release có thể đã bị xoá/đổi tag)")
            }
            val total = connection.contentLengthLong // -1 nếu server không trả Content-Length — vẫn tải được, chỉ không tính được % chính xác
            var written = 0L
            connection.inputStream.use { input ->
                partFile.outputStream().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        written += n
                        onProgress(written, total)
                    }
                }
            }
            if (written <= 0L) {
                partFile.delete()
                return@withContext DownloadResult.Failed("Tải về 0 byte — URL có thể trỏ sai file")
            }
            partFile.renameTo(target.destFile)
            DownloadResult.Success(written)
        } catch (e: Exception) {
            partFile.delete() // dọn rác — không để lại .part mồ côi chiếm ổ cứng nếu lỗi giữa chừng
            DownloadResult.Failed(e.message ?: e.javaClass.simpleName)
        } finally {
            connection?.disconnect()
        }
    }

    // Tải tuần tự NHIỀU file — CỐ Ý tuần tự (không song song) để (1) dễ
    // theo dõi tiến trình tổng thể (progress cộng dồn, không phải N thanh
    // riêng), (2) không làm nghẽn băng thông di động khi tải file GB-size
    // (đúng bài học "Payload Network Choking" — dù đó nói về Remote GPU
    // panel nhỏ hơn nhiều, nguyên lý băng thông hạn chế trên mạng di động
    // vẫn áp dụng đây). Dừng ở file đầu tiên lỗi — trả về ngay, không thử
    // tiếp các file sau (để user thấy lỗi rõ ràng thay vì tải dở dang
    // hàng loạt rồi mới biết có cái hỏng).
    suspend fun downloadAll(
        targets: List<StoryManager.DownloadTarget>,
        onItemProgress: (target: StoryManager.DownloadTarget, bytesDownloaded: Long, totalBytes: Long) -> Unit,
        onItemDone: (target: StoryManager.DownloadTarget, result: DownloadResult) -> Unit
    ) {
        for (t in targets) {
            if (t.exists) continue // đã có sẵn — bỏ qua, không tải lại đè lên file user có thể đã tự copy tay từ trước
            if (t.url.isNullOrBlank()) continue // không có URL — giữ nguyên hành vi "phải tự tải tay"
            val result = download(t) { done, total -> onItemProgress(t, done, total) }
            onItemDone(t, result)
            if (result is DownloadResult.Failed) return
        }
    }
}
