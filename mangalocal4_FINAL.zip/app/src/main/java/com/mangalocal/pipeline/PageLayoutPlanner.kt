package com.mangalocal.pipeline

import com.mangalocal.model.Panel
import com.mangalocal.model.Scene

/**
 * mục 248 TECHNICAL_STATUS.md — LẬP BỐ CỤC TRANG TỰ ĐỘNG theo nhịp truyện (`PageTemplate.AUTO`).
 *
 * Bối cảnh: PDF (MangaFlow) đề xuất "LLM Layout Generator" — để LLM sinh cấu trúc trang từ kịch bản. Dự án KHÔNG làm
 * kiểu đó vì LLM chạy trên máy là Qwen2.5-3B (mục 215): xuất cấu trúc hình học sai định dạng là chuyện thường (chính
 * `planEmotionArc` mục 243 đã phải "bỏ lô sai định dạng"), và một trang PDF sai bố cục thì phá cả file xuất. Thay vào đó
 * là bộ lập XÁC ĐỊNH dùng dữ liệu cảnh ĐÃ CÓ (`actionCategory`, `cameraAngle`, số lời thoại), cùng các quy ước bố cục
 * phổ biến (tra cứu mục 248): kích thước ô thể hiện độ quan trọng/thời lượng; ô lớn cho khoảnh khắc chính; cảnh yên
 * tĩnh/hội thoại dùng lưới đều; hành động ≤ 3 ô/trang; trang toàn khổ (splash) dành cho đỉnh điểm và không lạm dụng;
 * không dùng một lưới cho mọi trang (đơn điệu).
 *
 * Thuật toán (tham lam, một lượt):
 *  - Mỗi panel có một "nhịp": HIGH (hành động tiếp xúc combat/embrace/kiss, cận cực độ, toàn cảnh thiết lập) /
 *    QUIET (có thoại, không hành động, khung trung/cận) / NORMAL.
 *  - Đỉnh điểm = panel hành động CUỐI CÙNG, chỉ khi truyện ≥ MIN_PANELS_FOR_SPLASH panel (có dồn nhịp trước đó) và
 *    không nằm ở trang đầu → 1 trang SPLASH (đúng 1 trang splash cho mỗi chương xuất).
 *  - Trang bắt đầu bằng panel HIGH (còn ≥ 3 panel) → "1 rộng + 2 dưới" (ô rộng là panel quan trọng).
 *  - Trang bắt đầu bằng panel QUIET và 3 panel kế đều không HIGH → lưới 2×2.
 *  - Còn lại → 2 panel dọc. Panel lẻ cuối cùng dùng ô trọn trang (xử lý ở `PageLayout.effectiveTemplate`).
 *  - Trang được cắt ngắn để panel đỉnh điểm luôn mở đầu một trang mới (không bị gói vào giữa nhóm).
 *
 * GIỚI HẠN THẬT:
 *  - Quy tắc nhịp là HEURISTIC từ tài liệu cộng đồng, chưa so với truyện thật; cameraAngle/actionCategory do LLM nhỏ
 *    gán nên có thể sai — bố cục sai chỉ làm trang kém đẹp, không làm mất panel (mọi panel xuất hiện đúng 1 lần, đúng thứ tự).
 *  - Không đọc nội dung ảnh, không nhìn thấy "panel nào đẹp hơn".
 *  - CHƯA build-test; CHƯA xem thử PDF thật.
 */
object PageLayoutPlanner {

    enum class Weight { QUIET, NORMAL, HIGH }

    /** action = HIGH vì hành động tiếp xúc (combat/embrace/kiss) — ứng viên cho trang đỉnh điểm. */
    data class Beat(val weight: Weight, val action: Boolean)

    data class Page(val template: PageTemplate, val start: Int, val count: Int)

    const val MIN_PANELS_FOR_SPLASH = 6

    fun beatOf(scene: Scene): Beat {
        val cat = scene.actionCategory
        val action = cat == "combat" || cat == "embrace" || cat == "kiss"
        val cam = scene.cameraAngle
        val high = action || cam == "extreme-close-up" || cam == "wide-shot"
        val quiet = !high && (cat == null || cat == "neutral") && scene.dialogue.isNotEmpty() &&
            (cam == "medium-shot" || cam == "close-up")
        val w = if (high) Weight.HIGH else if (quiet) Weight.QUIET else Weight.NORMAL
        return Beat(w, action)
    }

    /** Hàm THUẦN: nhịp từng panel → danh sách trang (mẫu, vị trí đầu, số panel). */
    fun plan(beats: List<Beat>): List<Page> {
        val n = beats.size
        val out = ArrayList<Page>()
        val climax = if (n >= MIN_PANELS_FOR_SPLASH) beats.indexOfLast { it.action } else -1
        var i = 0
        while (i < n) {
            val remaining = n - i
            val b = beats[i]
            var tpl: PageTemplate
            var take: Int
            if (i == climax && out.isNotEmpty()) {
                tpl = PageTemplate.SPLASH; take = 1
            } else if (remaining == 1) {
                tpl = PageTemplate.STACK_2; take = 1
            } else if (b.weight == Weight.HIGH && remaining >= 3) {
                tpl = PageTemplate.ONE_PLUS_TWO; take = 3
            } else if (b.weight == Weight.QUIET && remaining >= 4 &&
                (1..3).all { beats[i + it].weight != Weight.HIGH }) {
                tpl = PageTemplate.GRID_2X2; take = 4
            } else {
                tpl = PageTemplate.STACK_2; take = 2
            }
            // đỉnh điểm phải mở đầu một trang mới
            if (climax > i && climax < i + take) {
                take = climax - i
                tpl = PageTemplate.STACK_2
            }
            out.add(Page(tpl, i, take))
            i += take
        }
        return out
    }

    /** Dùng trong xuất PDF: danh sách (mẫu, các panel của trang). */
    fun planPanels(panels: List<Panel>): List<Pair<PageTemplate, List<Panel>>> =
        plan(panels.map { beatOf(it.scene) }).map { pg -> pg.template to panels.subList(pg.start, pg.start + pg.count) }
}
