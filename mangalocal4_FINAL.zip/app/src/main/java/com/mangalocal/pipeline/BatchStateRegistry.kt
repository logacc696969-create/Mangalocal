package com.mangalocal.pipeline

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * mục 142 TECHNICAL_STATUS.md — checkpoint cuốn chiếu cho
 * MainViewModel.runIndustrialBatch(). Trước mục này, tiến độ batch công
 * nghiệp (có thể chạy hàng trăm/1000 chương liên tiếp, mục 70) CHỈ sống
 * trong RAM (_batchProgress StateFlow) — nếu tiến trình app bị hệ điều
 * hành giết giữa chừng (OOM Killer, pin yếu, máy nóng quá ngưỡng — xem
 * ThermalMonitor), toàn bộ tiến độ mất trắng, user phải chạy lại từ đầu
 * kể cả những chương ĐÃ xong.
 *
 * GIỚI HẠN THẬT: đây là checkpoint ĐƠN GIẢN — chỉ lưu SỐ chương đã xong +
 * fingerprint (hash) của danh sách text chương gốc, KHÔNG lưu lại state
 * chi tiết bên trong 1 chương đang dở (per-panel). Nếu bị giết đúng lúc
 * đang xử lý chương thứ N, resume sẽ CHẠY LẠI TỪ ĐẦU chương N (không mất
 * N-1 chương trước, nhưng chương N tính lại từ đầu) — đánh đổi chấp nhận
 * được vì đơn giản hơn nhiều so với checkpoint per-panel, và 1 chương chỉ
 * mất vài phút chứ không phải hàng giờ như cả batch.
 */
class BatchStateRegistry(context: Context) {
    private val file = File(context.filesDir, "industrial_batch_checkpoint.json")

    data class Checkpoint(
        val storyId: String,
        val chaptersHash: String,
        val completedCount: Int,
        val totalCount: Int
    )

    /** Fingerprint danh sách text chương gốc — dùng để xác nhận resume đúng
     * batch (nếu user đổi văn bản dán vào rồi chạy lại, hash lệch -> KHÔNG
     * resume, chạy từ đầu, tránh resume nhầm sang nội dung khác). */
    fun hashChapters(texts: List<String>): String {
        val digest = MessageDigest.getInstance("SHA-256")
        texts.forEach { digest.update(it.toByteArray(Charsets.UTF_8)) }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun saveCheckpoint(cp: Checkpoint) {
        try {
            val json = JSONObject().apply {
                put("storyId", cp.storyId)
                put("chaptersHash", cp.chaptersHash)
                put("completedCount", cp.completedCount)
                put("totalCount", cp.totalCount)
            }
            file.writeText(json.toString())
        } catch (_: Exception) {
            // Lỗi ghi checkpoint KHÔNG được làm gãy batch đang chạy — chỉ mất
            // khả năng resume nếu bị giết giữa chừng, không mất kết quả đã có.
        }
    }

    fun loadCheckpointOrNull(): Checkpoint? {
        return try {
            if (!file.exists()) return null
            val json = JSONObject(file.readText())
            Checkpoint(
                storyId = json.getString("storyId"),
                chaptersHash = json.getString("chaptersHash"),
                completedCount = json.getInt("completedCount"),
                totalCount = json.getInt("totalCount")
            )
        } catch (_: Exception) {
            null
        }
    }

    fun clearCheckpoint() {
        try { if (file.exists()) file.delete() } catch (_: Exception) {}
    }

    /** Log 1 dòng cho chương bị lỗi trong lúc chạy công nghiệp (mục 142 —
     * error shunning, xem MainViewModel.runIndustrialBatch). Ghi file riêng
     * (KHÔNG dùng Log.e — muốn user tự đọc lại sau khi batch xong, không
     * cần logcat/adb). */
    fun appendErrorLog(storyId: String, chapterIndex: Int, message: String) {
        try {
            val logFile = File(file.parentFile, "industrial_batch_errors.txt")
            logFile.appendText("[$storyId] chương #${chapterIndex + 1}: $message\n")
        } catch (_: Exception) {}
    }
}
