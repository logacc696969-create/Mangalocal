package com.mangalocal.pipeline

import kotlin.math.roundToInt

/**
 * mục 261 TECHNICAL_STATUS.md — quyết định CÓ dùng Composable LoRA (Switch/Composite) cho một panel hay không, và dùng UNet nào.
 * Hàm THUẦN (không đọc file, không native, không Android) -> chạy được bằng kotlinc (tools/test_lora_compose_plan.py).
 *
 * Nguyên tắc: KHÔNG BAO GIỜ đoán. Thiếu bất kỳ điều kiện nào -> trả null và để đường cũ (model đã gộp sẵn) chạy như trước, để bật cờ không bao
 * giờ làm hỏng một lượt sinh ảnh. Điều kiện: bật cờ; đúng >= 2 nhân vật trong cảnh; mỗi nhân vật có LoRA và có model riêng đã convert với
 * `unet.mnn` TỒN TẠI; không trùng nhân vật; không vượt quá số UNet tối đa (1 chính + `lora_compose::kMaxExtras` phụ = 4, khớp LoraCompose.hpp).
 * Thứ tự biến thể = thứ tự nhân vật trong cảnh: bài Multi-LoRA Composition (arXiv 2402.16843) cho kết quả tốt nhất khi LoRA đầu được bật TRƯỚC.
 */
object LoraComposePlan {
    const val MAX_VARIANTS = 4   // = 1 + kMaxExtras (LoraCompose.hpp)
    const val MIN_TAU = 1
    const val MAX_TAU = 10       // thanh trượt Cài đặt; native kẹp rộng hơn (20)

    class CharModel(
        val characterId: String, val hasLora: Boolean, val unetPath: String?, val unetExists: Boolean,
        // mục 261.14 — clip.mnn của model nhân vật (đã gộp delta text-encoder của LoRA đó); không bắt buộc
        val clipPath: String? = null, val clipExists: Boolean = false,
        // mục 263 — clip_skip=2 lúc convert (null = không biết). Hai nhân vật ĐÃ BIẾT mà khác nhau -> không trộn (điều kiện văn bản lệch chuẩn giữa các UNet)
        val clipSkip2: Boolean? = null
    )

    enum class ClipSkipStatus { CONSISTENT, MISMATCH, UNKNOWN }

    /** MISMATCH nếu có hai giá trị ĐÃ BIẾT khác nhau; UNKNOWN nếu không ai biết; CONSISTENT nếu mọi giá trị đã biết giống nhau (nhân vật chưa biết không đổi kết luận). */
    fun clipSkipStatus(chars: List<CharModel>): ClipSkipStatus {
        val known = chars.mapNotNull { it.clipSkip2 }.toSet()
        return when {
            known.size > 1 -> ClipSkipStatus.MISMATCH
            known.isEmpty() -> ClipSkipStatus.UNKNOWN
            else -> ClipSkipStatus.CONSISTENT
        }
    }

    /** primaryModelId = id model nạp làm UNet chính; extraUnetPaths = unet.mnn các biến thể phụ (theo thứ tự). */
    class Choice(
        val primaryModelId: String, val extraUnetPaths: List<String>, val activeCount: Int, val tau: Int,
        // mục 261.11 — Regional Composite: trộn TỪNG PIXEL theo mask vùng từng nhân vật (cần `masks`); false = Switch/Composite thường
        val regional: Boolean = false, val masks: ContactMap.RegionMasks? = null,
        // activeCount khi KHÔNG dùng regional (Switch = 1, Composite = k theo cờ) — để quay về đúng chế độ người dùng chọn nếu thiếu mask
        val fallbackActiveCount: Int = activeCount,
        // mục 261.14 — CLIP RIÊNG của từng UNet phụ (song song extraUnetPaths; "" = dùng CLIP chính). Rỗng = không dùng CLIP riêng nào.
        val extraClipPaths: List<String> = emptyList()
    ) {
        /** Gắn mask vùng; không có mask (null) thì TẮT regional và quay về Switch/Composite theo cờ — KHÔNG đoán mask. */
        fun withMasks(m: ContactMap.RegionMasks?): Choice =
            if (regional && m != null) Choice(primaryModelId, extraUnetPaths, activeCount, tau, true, m, fallbackActiveCount, extraClipPaths)
            else Choice(primaryModelId, extraUnetPaths, fallbackActiveCount, tau, false, null, fallbackActiveCount, extraClipPaths)
    }

    /** mục 261.14 — danh sách clip.mnn cho các biến thể PHỤ ("" = dùng CLIP chính); rỗng nếu tắt hoặc không biến thể phụ nào có clip. */
    fun clipsFor(ownClip: Boolean, chars: List<CharModel>): List<String> {
        if (!ownClip) return emptyList()
        val out = chars.drop(1).map { c -> if (c.clipExists && !c.clipPath.isNullOrBlank()) c.clipPath else "" }
        return if (out.any { it.isNotEmpty() }) out else emptyList()
    }

    fun choose(enabled: Boolean, composite: Boolean, tauRaw: Float, chars: List<CharModel>, expectedCount: Int, regional: Boolean = false, ownClip: Boolean = false): Choice? {
        if (!enabled) return null
        if (expectedCount < 2 || chars.size != expectedCount) return null
        if (chars.size > MAX_VARIANTS) return null
        if (chars.map { it.characterId }.toSet().size != chars.size) return null
        if (clipSkipStatus(chars) == ClipSkipStatus.MISMATCH) return null  // mục 263
        for (c in chars) {
            if (!c.hasLora || !c.unetExists || c.unetPath.isNullOrBlank()) return null
        }
        val tau = (if (tauRaw.isFinite()) tauRaw else 5f).roundToInt().coerceIn(MIN_TAU, MAX_TAU)
        val k = chars.size
        return Choice(
            primaryModelId = chars[0].characterId,
            extraUnetPaths = chars.drop(1).map { it.unetPath!! },
            activeCount = if (composite || regional) k else 1,  // vùng = chạy ĐỦ k UNet mỗi bước (như Composite) rồi trộn theo mask
            tau = tau,
            regional = regional,
            fallbackActiveCount = if (composite) k else 1,
            // CLIP riêng: chỉ khi bật cờ VÀ có ít nhất một biến thể phụ có clip.mnn; biến thể thiếu clip -> "" (dùng CLIP chính)
            extraClipPaths = clipsFor(ownClip, chars)
        )
    }
}
