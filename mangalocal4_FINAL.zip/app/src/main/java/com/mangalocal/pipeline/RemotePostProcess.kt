package com.mangalocal.pipeline

/**
 * mục 250 TECHNICAL_STATUS.md — HẬU KỲ TRÊN SERVER TỪ XA (Remote GPU): hoán đổi mặt theo nhân vật (insightface/inswapper), sửa tay
 * (HandRefiner), chỉnh danh tính bằng FLUX Kontext. Hằng số + hàm THUẦN ở đây để kiểm thử riêng; phần gọi mạng ở
 * `RemoteGenerationClient.runImageTask`, phần điều phối ở `MangaPipeline.remotePostProcess`.
 *
 * GIẤY PHÉP (phải cho người dùng biết): trọng số insightface/inswapper và FLUX.1 Kontext [dev] mang giấy phép PHI THƯƠNG MẠI/nghiên cứu;
 * HandRefiner (hr16/ControlNet-HandRefiner-pruned) hiển thị Apache-2.0. Dùng cho dự án cá nhân thì ghi chú là đủ, nhưng KHÔNG dùng ảnh/kết quả
 * của các tác vụ này cho sản phẩm thương mại khi chưa kiểm tra điều khoản. Chỉ dùng cho NHÂN VẬT HƯ CẤU của bạn (ảnh neo do chính bạn tạo);
 * không đưa ảnh người thật vào khi chưa có sự đồng ý của họ.
 *
 * GIỚI HẠN THẬT: chưa chạy với server/GPU thật; mặt nhỏ/bị che có thể không dò được; Kontext chỉ dùng cho panel có ĐÚNG 1 nhân vật có ảnh neo
 * và chất lượng giữ danh tính theo kiểu ghép ảnh chưa được kiểm chứng.
 */
object RemotePostProcess {
    const val TASK_FACESWAP = "faceswap"
    const val TASK_HANDFIX = "handfix"
    const val TASK_KONTEXT = "kontext"
    /** Thời hạn đọc cho tác vụ ảnh (nạp model lần đầu có thể lâu). */
    const val TASK_READ_TIMEOUT_S = 900L

    /** Kontext nhận ảnh [cảnh | tham chiếu] ghép ngang; server cắt lấy phần cảnh. */
    const val KONTEXT_PROMPT =
        "In the left image, make the person look exactly like the person in the right reference photo " +
            "(same face, hair and identity). Keep the pose, clothing, lighting and background of the left image unchanged."

    class Target(val name: String, val box: FloatArray, val refPath: String, val shoulderNorm: Float? = null)

    /** Bề rộng vai chuẩn hoá (|x vai phải - x vai trái|) nếu cả hai khớp vai (2, 5) thấy được và đủ lớn; ngược lại null. Server dùng để cảnh báo đầu/vai bất thường. */
    fun shoulderNorm(joints: List<OutputVerifier.Joint>): Float? {
        if (joints.size < OutputVerifier.JOINTS || !joints[2].visible || !joints[5].visible) return null
        val w = kotlin.math.abs(joints[2].x - joints[5].x)
        return if (w >= 0.02f) w else null
    }

    /** Đọc khối tEXt `key` trong PNG (server nhúng báo cáo JSON ở khoá "mangalocal_report"). null nếu không có/PNG hỏng. */
    fun pngText(b: ByteArray, key: String): String? {
        if (!isPng(b)) return null
        var o = 8
        while (o + 12 <= b.size) {
            val len = ((b[o].toInt() and 0xff) shl 24) or ((b[o + 1].toInt() and 0xff) shl 16) or ((b[o + 2].toInt() and 0xff) shl 8) or (b[o + 3].toInt() and 0xff)
            if (len < 0 || o + 12L + len > b.size) return null
            val type = String(b, o + 4, 4, Charsets.US_ASCII)
            if (type == "tEXt") {
                var z = o + 8
                val end = o + 8 + len
                while (z < end && b[z].toInt() != 0) z++
                if (z < end && String(b, o + 8, z - (o + 8), Charsets.ISO_8859_1) == key) return String(b, z + 1, end - (z + 1), Charsets.ISO_8859_1)
            }
            if (type == "IEND") return null
            o += 12 + len
        }
        return null
    }

    class FaceSwapSummary(val notes: List<String>, val hasRevert: Boolean)

    /** Báo cáo JSON của tác vụ faceswap -> các dòng ghi chú tiếng Việt cho badge/log; hasRevert = có mặt bị hoàn nguyên (cần xem lại). */
    fun faceSwapSummary(json: String): FaceSwapSummary? {
        return try {
            val faces = org.json.JSONObject(json).optJSONArray("faces") ?: return null
            val notes = ArrayList<String>()
            var revert = false
            for (i in 0 until faces.length()) {
                val f = faces.getJSONObject(i)
                val id = f.optString("id", "#${i + 1}")
                when (f.optString("status")) {
                    "reverted" -> { revert = true; notes.add("Hoán đổi mặt «$id» bị HOÀN NGUYÊN: ${f.optString("reason")}") }
                    "restored" -> notes.add("Hoán đổi mặt «$id»: ${f.optString("reason")}")
                    "skipped" -> notes.add("Hoán đổi mặt «$id» bỏ qua: ${f.optString("reason")}")
                }
                if (f.has("flag")) notes.add("«$id»: ⚠ ${f.optString("flag")}")
                if (f.has("note")) notes.add("«$id»: ${f.optString("note")}")
            }
            FaceSwapSummary(notes, revert)
        } catch (e: Exception) {
            null
        }
    }

    /** PNG: 8 byte chữ ký 89 50 4E 47 0D 0A 1A 0A. */
    fun isPng(b: ByteArray): Boolean =
        b.size >= 8 && b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte() && b[2] == 'N'.code.toByte() && b[3] == 'G'.code.toByte() &&
            b[4] == 0x0D.toByte() && b[5] == 0x0A.toByte() && b[6] == 0x1A.toByte() && b[7] == 0x0A.toByte()

    fun panelFileName(panelIndex: Int): String = "panel_%03d_srv.png".format(panelIndex + 1)

    /**
     * Hộp đầu (chuẩn hoá 0..1: x1,y1,x2,y2) từ khung xương OpenPose-18. Tâm = trung bình các khớp đầu thấy được (mũi 0, mắt 14/15, tai 16/17).
     * Kích thước s theo thứ tự ưu tiên: bề rộng vai (2,5)·0.55; khoảng cách hai mắt·3.2; khoảng cách hai tai·1.6; mặc định 0.14 — kẹp [0.06, 0.35].
     * Hộp rộng ±0.6·s, cao ±0.75·s quanh tâm (rộng rãi: server chỉ cần ghép mặt dò được với hộp). Không có khớp đầu nào -> null.
     */
    fun headBox(joints: List<OutputVerifier.Joint>): FloatArray? {
        if (joints.size < OutputVerifier.JOINTS) return null
        var sx = 0f; var sy = 0f; var n = 0
        for (j in intArrayOf(0, 14, 15, 16, 17)) {
            val p = joints[j]
            if (p.visible) { sx += p.x; sy += p.y; n++ }
        }
        if (n == 0) return null
        val cx = sx / n; val cy = sy / n
        fun pair(a: Int, b: Int): Float? = if (joints[a].visible && joints[b].visible) kotlin.math.abs(joints[a].x - joints[b].x) else null
        val s = (pair(2, 5)?.times(0.55f) ?: pair(14, 15)?.times(3.2f) ?: pair(16, 17)?.times(1.6f) ?: 0.14f).coerceIn(0.06f, 0.35f)
        val x1 = (cx - 0.6f * s).coerceIn(0f, 1f); val x2 = (cx + 0.6f * s).coerceIn(0f, 1f)
        val y1 = (cy - 0.75f * s).coerceIn(0f, 1f); val y2 = (cy + 0.75f * s).coerceIn(0f, 1f)
        return if (x2 > x1 && y2 > y1) floatArrayOf(x1, y1, x2, y2) else null
    }
}
