package com.mangalocal.pipeline

import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

/**
 * Vách ngăn ranh giới nhân tạo (Artificial Barrier) — vá gap "SilhouetteFilter
 * không tồn tại" đã phát hiện khi đối chiếu `hoàn_thiện_sd1_5.txt` với source
 * thật (mục 111 TECHNICAL_STATUS.md).
 *
 * Ý tưởng gốc trong tài liệu là vẽ 1 line đen chạy dọc trục xương TRƯỚC khi
 * đưa ảnh qua MobileSAM click-to-mask, để mô hình phân đoạn nhận diện được
 * ranh giới giả giữa 2 cơ thể. Bản MangaLocal hiện tại KHÔNG dùng SAM
 * click-to-mask cho vùng giao thoa hông (`hip_overlap` trong
 * [MangaPipeline.tryAutoFixInteractions] — chỉ dùng rectangle + feather qua
 * [MangaPipeline.buildInteractionMaskFile]), nên áp dụng đúng nguyên lý ở
 * ĐÚNG tầng tương ứng: khắc (subtract) một dải đen mảnh dọc trục thân của
 * MỖI người vào chính mask inpaint hình chữ nhật đó, TRƯỚC khi feather. Vùng
 * bị khắc sẽ KHÔNG được vẽ đè trong lượt img2imgFix, giữ nguyên pixel gốc
 * dọc theo trục cơ thể — buộc phần da thịt sinh mới của 2 người phải dừng
 * lại đúng ranh giới đó thay vì tự do hoà lẫn.
 *
 * GIỚI HẠN THẬT: đây là 1 heuristic hình học 2D đơn giản (nối điểm giữa vai
 * và điểm giữa hông của TỪNG người thành 1 đoạn thẳng), KHÔNG PHẢI phân
 * đoạn ngữ nghĩa thật như SAM — có thể vẽ sai vị trí nếu OpenPose bắt nhầm
 * khớp (confidence thấp). Đã lọc bằng ngưỡng toạ độ hợp lệ (>0) trước khi vẽ.
 */
object SilhouetteFilter {
    private const val STROKE_WIDTH_PX = 4f
    private const val FEATHER_ON_STROKE_PX = 2f // mượt nhẹ hơn viền ngoài (15f) để giữ đường ranh rõ nét

    private const val NECK = 1
    private const val HIP_R = 8
    private const val HIP_L = 11

    /**
     * Vẽ vách ngăn cho 1 người lên [mask] hiện có (mask trắng=cho phép
     * inpaint, đen=giữ nguyên — đúng quy ước [MangaPipeline.buildInteractionMaskFile]).
     * Gọi SAU khi đã fill vùng trắng, TRƯỚC khi ghi file — [strokeAxis] chỉ
     * khắc (subtract) một dải đen mảnh, không đụng phần còn lại của mask.
     *
     * @param skeletonData mảng phẳng OpenPose-18 (18 khớp x 4 giá trị/người)
     * @param personIdx    chỉ số người trong [skeletonData] cần khắc trục
     */
    fun strokeAxis(canvas: Canvas, skeletonData: FloatArray, personIdx: Int, width: Int, height: Int) {
        val floatsPerPerson = 18 * 4
        val base = personIdx * floatsPerPerson
        if (base + floatsPerPerson > skeletonData.size) return

        val neckX = skeletonData[base + NECK * 4]; val neckY = skeletonData[base + NECK * 4 + 1]
        val hipRx = skeletonData[base + HIP_R * 4]; val hipRy = skeletonData[base + HIP_R * 4 + 1]
        val hipLx = skeletonData[base + HIP_L * 4]; val hipLy = skeletonData[base + HIP_L * 4 + 1]

        val validHips = listOf(hipRx to hipRy, hipLx to hipLy).filter { it.first > 0f && it.second > 0f }
        if (neckX <= 0f || neckY <= 0f || validHips.isEmpty()) return // khớp không hợp lệ — bỏ qua, không đoán bừa

        val hipCx = validHips.map { it.first }.average().toFloat()
        val hipCy = validHips.map { it.second }.average().toFloat()

        // Toạ độ chuẩn hoá 0..1 (đúng quy ước PoseRetargeter) -> pixel thật
        val x1 = neckX * width; val y1 = neckY * height
        val x2 = hipCx * width; val y2 = hipCy * height

        val barrierPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK // khắc: loại trừ khỏi vùng cho phép inpaint
            style = Paint.Style.STROKE
            strokeWidth = STROKE_WIDTH_PX
            strokeCap = Paint.Cap.ROUND
            maskFilter = BlurMaskFilter(FEATHER_ON_STROKE_PX, BlurMaskFilter.Blur.NORMAL)
        }
        canvas.drawLine(x1, y1, x2, y2, barrierPaint)
    }

    /** Tiện ích: khắc trục cho CẢ 2 người giao thoa trong 1 lần gọi. */
    fun strokeBarrierBetween(canvas: Canvas, skeletonData: FloatArray, personAIdx: Int, personBIdx: Int, width: Int, height: Int) {
        strokeAxis(canvas, skeletonData, personAIdx, width, height)
        strokeAxis(canvas, skeletonData, personBIdx, width, height)
    }
}
