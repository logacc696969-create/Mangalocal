package com.mangalocal.pipeline

import com.mangalocal.model.BoneProportions
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * Retarget khung xương theo tỷ lệ xương RIÊNG từng nhân vật (mục 31/32
 * TECHNICAL_STATUS.md) — thay thế hoàn toàn cách "kéo giãn theo vector từ
 * gốc hông" (mục 30, đã lỗi thời — gây góc khớp phi lý đúng như user chỉ
 * ra) bằng thuật toán Forward Kinematics giữ nguyên GÓC GẬP tự nhiên của
 * khớp, chỉ đổi ĐỘ DÀI xương, lan truyền từ gốc thân (hip-center) ra tới
 * đầu chi (bàn tay/bàn chân), có neo mặt đất CÓ ĐIỀU KIỆN cho tư thế độc
 * lập (mục 112/113 — xem isContactVariant()) — đúng ý nghĩa vật lý "Pose
 * Space Deformation + Root Translation" mà user cung cấp (không phải
 * Bio-IK đầy đủ, không giải constraint đa khớp — đây là bản ĐƠN GIẢN, nhẹ,
 * dùng lượng giác phẳng thuần, khả thi thật trên CPU di động).
 *
 * GIỚI HẠN THẬT (so với Bio-IK đầy đủ đã bàn và quyết định KHÔNG làm):
 * - KHÔNG giải "điểm chạm bắt buộc" (contact point) một cách chính xác —
 *   không có metadata nào trong pose_library.json ghi rõ TOẠ ĐỘ CHÍNH XÁC
 *   "tay người A phải chạm đúng gáy người B" (chỉ có actionTags dạng nhãn
 *   chữ như "hug"/"fight_lock", đủ để BIẾT có tiếp xúc, KHÔNG đủ để tính
 *   lại toạ độ chạm chính xác), nên bước "bù trừ xoay vai/hông để chạm
 *   đúng điểm khoá" CHƯA làm — cần thêm metadata điểm chạm mới làm được.
 *   Với tư thế tiếp xúc, hệ quả THẬT: nếu 2 người có tỷ lệ tay/chân khác
 *   nhau nhiều, điểm chạm gốc (thiết kế cho tỷ lệ 1.0/1.0) có thể hơi lệch
 *   sau khi retarget — CHƯA giải quyết được, chỉ đảm bảo KHÔNG làm lệch
 *   THÊM (không neo đất chồng lên, xem bước 4).
 * - Vẫn CÓ áp dụng đúng: giữ góc gập gốc + đổi độ dài + lan truyền từ gốc
 *   (bước 1-3), co giãn đầu theo neck (bước 1b, mục 113), neo mặt đất CÓ
 *   ĐIỀU KIỆN theo actionTags/bbox-overlap (bước 4, mục 112/113) — giải
 *   quyết "góc khớp phi lý" (cách cũ), "chân lơ lửng khi đứng độc lập"
 *   (mục 112), VÀ "đầu không to lên dù đặt headSizeRatio cao" (mục 113,
 *   trước đây document nhầm là bất khả thi — đã kiểm tra lại renderer
 *   C++ và xác nhận mũi/mắt/tai CÓ được vẽ, chỉ là chưa nối dây).
 * - Bù chân (khi áp dụng) dùng trung bình lệch Y của 2 mắt cá — đúng hoàn
 *   toàn với tư thế đối xứng (đứng thẳng), là xấp xỉ hợp lý (không tuyệt
 *   đối) với tư thế bất đối xứng mạnh (chạy, nhảy) NHƯNG vẫn ĐỘC LẬP
 *   (không tiếp xúc người khác — chạy/nhảy 1 mình vẫn nên neo đất).
 */


object PoseRetargeter {

    private fun dist(a: StoryManager.PoseKeypoint, b: StoryManager.PoseKeypoint) =
        sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y))

    private fun angle(from: StoryManager.PoseKeypoint, to: StoryManager.PoseKeypoint) =
        atan2(to.y - from.y, to.x - from.x)

    // mục 113 TECHNICAL_STATUS.md — phát hiện khi user chỉ ra ĐÚNG: bước 4
    // (neo mặt đất, mục 112) không được áp DỮ DẰN cho MỌI tư thế — truyện có
    // cả tư thế 2 người ĐỘC LẬP (đứng nói chuyện, chạy) LẪN tư thế TIẾP XÚC
    // THẬT (vật nhau, ôm, hôn — nơi vị trí tương đối 2 người là chủ đích
    // thiết kế của template, KHÔNG PHẢI ngẫu nhiên). Với tư thế tiếp xúc,
    // dịch cả khung xương theo trục dọc (để "neo mặt đất") sẽ PHÁ vỡ điểm
    // chạm đã thiết kế sẵn (vd tay người A đang đặt đúng vai người B — dịch
    // A xuống sẽ làm tay A lệch khỏi vai B). Phân biệt bằng:
    //   1. actionTags user đã gắn tay khi lưu pose (đáng tin nhất, xem
    //      guessPoseTemplate() cùng khuôn mẫu match theo tag).
    //   2. Fallback hình học: 2 người có bbox vùng hông/gối GIAO NHAU thật
    //      trong tư thế GỐC (trước khi retarget) — dấu hiệu chắc chắn có
    //      tiếp xúc dù chưa ai gắn tag (thư viện cũ/user quên gắn).
    private val CONTACT_TAG_REGEX = Regex(
        "hug|fight|combat|embrace|kiss|lock|wrestl|grip|grab|throw|carry|piggyback|choke|punch|kick|" +
        "contact|touch|" + // mục 129 — khớp với tag tự gợi ý (PoseEditorScreen.kt) khi phát hiện chồng lấn hình học nhưng KHÔNG rõ loại tương tác cụ thể (không đoán bừa "hug" hay "fight")
        "ôm|đánh|vật|hôn|siết|khoá|khóa|cõng|bế|đấm|đá|nắm|kéo|tiếp xúc|chạm",
        RegexOption.IGNORE_CASE
    )

    // mục 129 TECHNICAL_STATUS.md — tách phần kiểm tra hình học ra hàm
    // PUBLIC dùng chung, để PoseEditorScreen.kt (màn hình lưu tư thế mới
    // trích từ ảnh/video) TÁI DÙNG được cho tính năng "gợi ý nhãn tự động"
    // (mục 129 — trước đây trích khung xương từ ảnh/video CÓ THẬT, nhưng
    // gắn nhãn hành động 100% NHẬP TAY, model không gợi ý gì dù vừa nhận
    // diện xong hình học). KHÔNG viết logic hình học LẦN 2 ở nơi khác —
    // đúng nguyên tắc "1 nguồn sự thật" đã áp dụng xuyên suốt dự án.
    fun detectBboxContact(people: List<List<StoryManager.PoseKeypoint>>): Boolean {
        if (people.size < 2) return false
        val bboxes = people.mapNotNull { person ->
            val pts = listOf(8, 9, 11, 12).mapNotNull { idx -> person.getOrNull(idx)?.takeIf { it.visible } }
            if (pts.isEmpty()) null else {
                val xs = pts.map { it.x }; val ys = pts.map { it.y }
                floatArrayOf(xs.min(), ys.min(), xs.max(), ys.max())
            }
        }
        for (i in bboxes.indices) for (j in i + 1 until bboxes.size) {
            val a = bboxes[i]; val b = bboxes[j]
            if (a[0] < b[2] && b[0] < a[2] && a[1] < b[3] && b[1] < a[3]) return true
        }
        return false
    }

    private fun isContactVariant(variant: StoryManager.PoseVariant): Boolean {
        if (variant.actionTags.any { CONTACT_TAG_REGEX.containsMatchIn(it) }) return true
        return detectBboxContact(variant.people)
    }

    // Đặt lại 1 điểm "to" theo: gốc "from" + độ dài mới * hướng góc GỐC
    // (giữ nguyên góc, đổi độ dài) — đúng công thức "Angle Propagation"
    // (bước 3 tài liệu 7): toạ_độ_mới = toạ_độ_gốc(from) + chiều_dài_mới * góc_xoay_gốc.
    private fun placeAtAngleLength(
        from: StoryManager.PoseKeypoint, originalAngle: Float, newLength: Float, template: StoryManager.PoseKeypoint
    ) = template.copy(x = from.x + newLength * cos(originalAngle), y = from.y + newLength * sin(originalAngle))

    /**
     * Retarget 1 người trong khung xương (List<PoseKeypoint> OpenPose-18)
     * từ tỷ lệ nguồn (sourceProportions — tỷ lệ của người THẬT trong
     * video/ảnh gốc, mặc định 1.0 = người lớn) sang tỷ lệ đích (nhân vật cụ
     * thể đang vẽ). Nếu source==target, trả nguyên khung xương gốc (không
     * đổi gì, tránh sai số làm tròn không cần thiết).
     */
    fun retargetPerson(
        person: List<StoryManager.PoseKeypoint>, source: BoneProportions, target: BoneProportions,
        applyGroundAnchor: Boolean = true
    ): MutableList<StoryManager.PoseKeypoint> {
        if (source == target) return person.toMutableList()
        val out = person.toMutableList()

        // Điểm gốc (root) = hip-center — giữ NGUYÊN vị trí tuyệt đối, mọi
        // xương khác lan truyền TỪ đây ra (đúng "Root Translation" tài liệu
        // 7 — không cố định vai/hông độc lập, mà lấy 1 gốc chung).
        val rHip = out.getOrNull(8); val lHip = out.getOrNull(11)
        if (rHip?.visible != true || lHip?.visible != true) return out // thiếu điểm gốc, không retarget mù
        val hipCenter = StoryManager.PoseKeypoint((rHip.x + lHip.x) / 2, (rHip.y + lHip.y) / 2, 0f, true, 1f)
        // mục 118 TECHNICAL_STATUS.md — cùng quyết định "tiếp xúc hay độc
        // lập" với bước 4 (neo mặt đất, mục 113) — 2 quyết định NGƯỢC NHAU
        // về mặt áp dụng (neo đất CHỈ cho độc lập, IK CHỈ cho tiếp xúc) vì
        // lý do vật lý khác nhau: neo đất giả định 1 mặt sàn CHUNG (chỉ
        // đúng khi KHÔNG chạm nhau); IK giữ điểm chạm CỐ ĐỊNH (chỉ có ý
        // nghĩa khi CÓ chạm nhau) — không mâu thuẫn, là 2 mặt của cùng 1
        // phân loại gốc.
        val isContact = !applyGroundAnchor

        // 1. Trục thân: hip-center -> neck (giữ góc, đổi độ dài theo torsoRatio)
        val neck = out.getOrNull(1)
        var newNeck = neck
        if (neck?.visible == true) {
            val origLen = dist(hipCenter, neck)
            val origAngle = angle(hipCenter, neck)
            val newLen = origLen * (target.torsoRatio / source.torsoRatio)
            newNeck = placeAtAngleLength(hipCenter, origAngle, newLen, neck)
            out[1] = newNeck
        }

        // 1b. Đầu: mũi(0)/mắt(14,15)/tai(16,17) — mục 113 TECHNICAL_STATUS.md,
        // vá gap đã document sai lầm là "không thể áp dụng" ở lượt trước.
        // ĐÃ KIỂM TRA renderSkeletons() (ip_adapter.cpp): kBonePairs CÓ vẽ
        // {1,0} neck-nose, {0,14}/{14,16} nose-Reye-Rear, {0,15}/{15,17}
        // nose-Leye-Lear — tức đầu THẬT SỰ được vẽ ra ControlNet-Pose, không
        // chỉ có thân/tay/chân. Co giãn offset các điểm này so với neck GỐC
        // theo headSizeRatio, dịch theo neck MỚI — CÙNG khuôn mẫu offset-
        // theo-neck đã dùng cho vai (retargetArm bên dưới). headSizeRatio
        // cao hơn -> mũi/mắt/tai toả xa neck hơn -> đầu trông to hơn trong
        // khung xương ControlNet, đúng quy ước "trẻ em đầu to hơn thân".
        fun retargetHeadPoint(idx: Int) {
            val p = out.getOrNull(idx)
            if (neck == null || newNeck == null || p?.visible != true) return
            val ratio = target.headSizeRatio / source.headSizeRatio
            out[idx] = p.copy(x = newNeck.x + (p.x - neck.x) * ratio, y = newNeck.y + (p.y - neck.y) * ratio)
        }
        listOf(0, 14, 15, 16, 17).forEach { retargetHeadPoint(it) }

        // 2. Tay: neck -> shoulder (offset ngắn, KHÔNG coi là "xương" scale
        // riêng — giữ nguyên offset TƯƠNG ĐỐI so với neck cũ, dịch theo neck
        // mới) -> elbow (upperArmRatio) -> wrist (forearmRatio).
        fun retargetArm(shoulderIdx: Int, elbowIdx: Int, wristIdx: Int) {
            val shoulder = out.getOrNull(shoulderIdx); val elbow = out.getOrNull(elbowIdx); val wrist = out.getOrNull(wristIdx)
            if (neck == null || newNeck == null || shoulder?.visible != true) return
            // Dịch vai theo đúng offset gốc so với neck (neck đã có vị trí mới)
            val shoulderOffsetX = shoulder.x - neck.x; val shoulderOffsetY = shoulder.y - neck.y
            val newShoulder = shoulder.copy(x = newNeck.x + shoulderOffsetX, y = newNeck.y + shoulderOffsetY)
            out[shoulderIdx] = newShoulder

            if (elbow?.visible == true) {
                val origAngle = angle(shoulder, elbow)
                val newLen = dist(shoulder, elbow) * (target.upperArmRatio / source.upperArmRatio)
                val newElbow = placeAtAngleLength(newShoulder, origAngle, newLen, elbow)
                out[elbowIdx] = newElbow

                if (wrist?.visible == true) {
                    val origAngleF = angle(elbow, wrist)
                    val newLenF = dist(elbow, wrist) * (target.forearmRatio / source.forearmRatio)
                    val fkWrist = placeAtAngleLength(newElbow, origAngleF, newLenF, wrist)
                    out[wristIdx] = fkWrist

                    // mục 118 TECHNICAL_STATUS.md — CCD-IK, CHỈ áp dụng cho
                    // tư thế TIẾP XÚC (isContact — cùng quyết định với bước
                    // 4 neo mặt đất, mục 113: !applyGroundAnchor). Vá ĐÚNG
                    // giới hạn đã ghi ở docstring đầu file: "không giải điểm
                    // chạm bắt buộc — cần thêm metadata điểm chạm mới làm
                    // được". Metadata đó CHÍNH LÀ toạ độ GỐC của cổ tay
                    // (biến `wrist`, đọc TRƯỚC khi bước FK ở trên ghi đè) —
                    // template gốc (tỷ lệ 1.0/1.0) đã đặt tay ở vị trí đó
                    // THEO THIẾT KẾ (vd chạm đúng vai người kia); kéo cổ tay
                    // VỀ LẠI đúng toạ độ đó bằng IK, bất kể tỷ lệ tay mới
                    // dài/ngắn hơn — độ dài 2 xương MỚI (newLen/newLenF) vẫn
                    // được BẢO TOÀN tuyệt đối (CCD chỉ xoay góc khớp, không
                    // đổi độ dài), chỉ góc gập khuỷu ĐỔI để hướng đúng.
                    if (isContact) {
                        val (newMid, newEnd) = PoseInverseKinematics.solveTwoBoneChain(
                            newShoulder.x, newShoulder.y, newElbow.x, newElbow.y, fkWrist.x, fkWrist.y,
                            newLen, newLenF, wrist.x, wrist.y
                        )
                        out[elbowIdx] = newElbow.copy(x = newMid.first, y = newMid.second)
                        out[wristIdx] = fkWrist.copy(x = newEnd.first, y = newEnd.second)
                    }
                }
            }
        }
        retargetArm(2, 3, 4)   // vai phải - khuỷu phải - cổ tay phải
        retargetArm(5, 6, 7)   // vai trái - khuỷu trái - cổ tay trái

        // 3. Chân: hip(R/L) -> knee (upperLegRatio) -> ankle (lowerLegRatio),
        // hip giữ NGUYÊN vị trí tuyệt đối (chính là root, không lan truyền
        // qua neck) — khác tay (lan truyền qua neck), vì trục hông LÀ gốc.
        fun retargetLeg(hipIdx: Int, kneeIdx: Int, ankleIdx: Int) {
            val hip = out.getOrNull(hipIdx); val knee = out.getOrNull(kneeIdx); val ankle = out.getOrNull(ankleIdx)
            if (hip?.visible != true) return
            if (knee?.visible == true) {
                val origAngle = angle(hip, knee)
                val newLen = dist(hip, knee) * (target.upperLegRatio / source.upperLegRatio)
                val newKnee = placeAtAngleLength(hip, origAngle, newLen, knee)
                out[kneeIdx] = newKnee
                if (ankle?.visible == true) {
                    val origAngleA = angle(knee, ankle)
                    val newLenA = dist(knee, ankle) * (target.lowerLegRatio / source.lowerLegRatio)
                    val fkAnkle = placeAtAngleLength(newKnee, origAngleA, newLenA, ankle)
                    out[ankleIdx] = fkAnkle

                    // mục 128 TECHNICAL_STATUS.md — user chỉ ra ĐÚNG: giả
                    // định "chân chỉ cần neo đất, không cần điểm chạm bắt
                    // buộc" là khái quát hoá SAI, tự đặt ra không dựa trên
                    // logic thật đã có. Có RẤT NHIỀU tư thế chân cần điểm
                    // chạm chính xác y hệt tay: chân vòng qua eo người kia
                    // lúc ôm/vật, bàn chân đạp/đặt lên người đối phương lúc
                    // quật ngã, đứng trên ghế/vật thể (điểm chạm là MẶT VẬT
                    // THỂ, không phải "mặt đất" mặc định) — TẤT CẢ đều là
                    // "điểm chạm bắt buộc" đúng nghĩa, không khác gì tay.
                    // Sửa: áp CÙNG logic isContact (đã có sẵn, dùng chung
                    // quyết định isContactVariant() từ mục 113) cho chân,
                    // đối xứng HOÀN TOÀN với tay — không tạo phân biệt tay/
                    // chân nào nữa, chỉ còn phân biệt tiếp xúc/độc lập
                    // (đúng bản chất vấn đề, không phải đúng theo BỘ PHẬN
                    // cơ thể). Tư thế ĐỘC LẬP (nhón chân, đứng thẳng...) vẫn
                    // dùng neo mặt đất (bước 4) như cũ — 2 cơ chế không xung
                    // đột vì áp cho 2 loại tư thế khác nhau (contact dùng
                    // IK, independent dùng ground-anchor), không phải cả 2
                    // cùng lúc cho cùng 1 chân.
                    if (isContact) {
                        val (newMid, newEnd) = PoseInverseKinematics.solveTwoBoneChain(
                            hip.x, hip.y, newKnee.x, newKnee.y, fkAnkle.x, fkAnkle.y,
                            newLen, newLenA, ankle.x, ankle.y
                        )
                        out[kneeIdx] = newKnee.copy(x = newMid.first, y = newMid.second)
                        out[ankleIdx] = fkAnkle.copy(x = newEnd.first, y = newEnd.second)
                    }
                }
            }
        }
        retargetLeg(8, 9, 10)   // hông phải - gối phải - mắt cá phải
        retargetLeg(11, 12, 13) // hông trái - gối trái - mắt cá trái

        // 4. NEO MẶT ĐẤT (mục 112/113 TECHNICAL_STATUS.md) — CHỈ áp dụng khi
        // [applyGroundAnchor]=true, tức tư thế KHÔNG có tiếp xúc thật giữa 2
        // người (xem isContactVariant() — quyết định ở CẤP VARIANT, truyền
        // xuống đây qua retargetVariant(), không tự đoán ở đây). Với tư thế
        // ĐỘC LẬP (đứng cạnh nhau, chạy): bù lại việc bước 3 giữ hông CỐ
        // ĐỊNH rồi co chân TỪ ĐÓ — nếu không bù, nhân vật tỷ lệ < 1.0 (trẻ
        // em) sẽ có bàn chân LƠ LỬNG phía trên mặt sàn trong khi nhân vật
        // khác trong CÙNG khung vẫn đứng đúng mặt đất. Với tư thế TIẾP XÚC
        // (vật/ôm/hôn): KHÔNG áp — dịch cả khung xương sẽ phá vỡ điểm chạm
        // đã thiết kế sẵn trong template (vd tay đang đặt đúng vai người
        // kia). Giữ nguyên hành vi hip-anchor gốc cho trường hợp này — đúng
        // GIỚI HẠN THẬT đã ghi ở đầu file (không giải contact-point IK).
        if (applyGroundAnchor) {
            val origRAnkle = person.getOrNull(10); val origLAnkle = person.getOrNull(13)
            val newRAnkle = out.getOrNull(10); val newLAnkle = out.getOrNull(13)
            val origAnkleYs = listOfNotNull(
                origRAnkle?.takeIf { it.visible }?.y, origLAnkle?.takeIf { it.visible }?.y
            )
            val newAnkleYs = listOfNotNull(
                newRAnkle?.takeIf { it.visible }?.y, newLAnkle?.takeIf { it.visible }?.y
            )
            if (origAnkleYs.isNotEmpty() && newAnkleYs.isNotEmpty()) {
                val shiftY = origAnkleYs.average().toFloat() - newAnkleYs.average().toFloat()
                if (shiftY != 0f) {
                    for (i in out.indices) {
                        val kp = out[i]
                        if (kp.visible) out[i] = kp.copy(y = kp.y + shiftY)
                    }
                }
            }
        }

        return out
    }

    /**
     * Retarget CẢ 1 PoseVariant (nhiều người) — gán mỗi vị trí `people[i]`
     * cho ĐÚNG 1 nhân vật cụ thể theo `characterProportions[i]` (danh sách
     * PHẢI cùng thứ tự với scene.characters — đây chính là chỗ GIẢI QUYẾT
     * lỗ hổng "skeleton không biết ai là ai" đã ghi ở mục 12: trước đây
     * native tự vẽ people[0]/people[1] không biết ứng với nhân vật nào; giờ
     * Kotlin (biết chính xác thứ tự scene.characters) gán tường minh TRƯỚC
     * khi gửi toạ độ cho native — native giờ chỉ vẽ, không cần biết danh
     * tính nữa).
     */
    fun retargetVariant(
        variant: StoryManager.PoseVariant, characterProportions: List<BoneProportions>
    ): List<List<StoryManager.PoseKeypoint>> {
        // mục 113 — quyết định "tiếp xúc hay độc lập" 1 LẦN cho CẢ variant
        // (không phải từng người riêng — 2 người trong 1 tư thế vật nhau
        // PHẢI cùng chung quyết định, không thể người A neo đất còn người B
        // không, sẽ lệch pha ngay lập tức).
        val groundAnchor = !isContactVariant(variant)
        return variant.people.mapIndexed { i, person ->
            val target = characterProportions.getOrNull(i) ?: BoneProportions() // thiếu nhân vật ứng -> giữ chuẩn người lớn
            retargetPerson(person, variant.sourceProportions, target, applyGroundAnchor = groundAnchor)
        }
    }
}
