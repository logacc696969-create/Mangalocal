package com.mangalocal.pipeline

/**
 * mục 251 TECHNICAL_STATUS.md — BỐ CỤC TƯƠNG TÁC từ InteractDiffusion rồi RENDER LẠI bằng pipeline của dự án.
 *
 * Vấn đề kiến trúc đã nêu ở mục 250: InteractDiffusion dựng cả khung từ SD1.5 gốc (không checkpoint siêu thực/LoRA/pose/IP-Adapter của dự án,
 * ~512px) nên không thể dùng làm ẢNH CUỐI. Cách giải quyết: dùng nó làm NGUỒN BỐ CỤC — server sinh ảnh tương tác (ôm/hôn/đánh) → app chạy
 * YOLOv8-pose (đã có) trên ảnh đó để lấy KHUNG XƯƠNG hai người đang tiếp xúc → khung xương này thay khung xương mẫu của panel → ControlNet-pose +
 * IP-Adapter + checkpoint/LoRA của dự án vẽ ảnh cuối ở độ phân giải của dự án. Ảnh InteractDiffusion bị bỏ sau khi trích khung xương.
 * Mô hình huấn luyện theo HICO-DET, danh sách đối tượng `person` có hug/kiss/hit (tra cứu mục 251) nên chỉ áp dụng cho embrace/kiss/combat.
 *
 * GIỚI HẠN THẬT: chưa chạy với model thật; YOLO có thể không dò đủ 2 người khi ôm sát (khi đó dùng khung xương mẫu); khung xương dò được không có z
 * (không có thông tin che khuất cho depth hint); prompt cố định tiếng Anh (mô tả tiếng Việt không dùng được với CLIP); chỉ 2 nhân vật.
 */
object InteractionLayout {
    val ACTION_PHRASES: Map<String, String> = mapOf("embrace" to "hugging", "kiss" to "kissing", "combat" to "hitting")
    const val MIN_VISIBLE_JOINTS = 10
    const val MIN_BOX_JOINTS = 3
    const val BOX_PAD = 0.03f

    fun actionPhrase(category: String?): String? = category?.let { ACTION_PHRASES[it] }

    fun prompt(category: String?): String? = actionPhrase(category)?.let { "two people $it, photo" }

    /** Hộp (chuẩn hoá 0..1) quanh các khớp thấy được, nới BOX_PAD, kẹp trong ảnh; < MIN_BOX_JOINTS khớp thì null. */
    fun personBox(p: OutputVerifier.Person, pad: Float = BOX_PAD): FloatArray? {
        var x1 = Float.MAX_VALUE; var y1 = Float.MAX_VALUE; var x2 = -Float.MAX_VALUE; var y2 = -Float.MAX_VALUE; var n = 0
        for (j in p.joints) if (j.visible) {
            x1 = minOf(x1, j.x); y1 = minOf(y1, j.y); x2 = maxOf(x2, j.x); y2 = maxOf(y2, j.y); n++
        }
        if (n < MIN_BOX_JOINTS) return null
        val box = floatArrayOf((x1 - pad).coerceIn(0f, 1f), (y1 - pad).coerceIn(0f, 1f), (x2 + pad).coerceIn(0f, 1f), (y2 + pad).coerceIn(0f, 1f))
        return if (box[2] > box[0] && box[3] > box[1]) box else null
    }

    fun hasEnoughJoints(p: OutputVerifier.Person): Boolean = p.joints.count { it.visible } >= MIN_VISIBLE_JOINTS

    /**
     * Sắp xếp người dò được theo THỨ TỰ người của khung xương mẫu (ghép tham lam theo trọng tâm). Trả null nếu có người mẫu không ghép được hoặc
     * người dò được quá ít khớp (không tin khung xương thiếu).
     */
    fun orderedDetected(template: List<OutputVerifier.Person>, detected: List<OutputVerifier.Person>): List<OutputVerifier.Person>? {
        if (template.isEmpty()) return null
        val map = OutputVerifier.greedyMatch(template, detected).associate { it.first to it.second }
        if (map.size < template.size) return null
        val out = template.indices.map { detected[map.getValue(it)] }
        return if (out.all { hasEnoughJoints(it) }) out else null
    }

    /** Làm phẳng thành mảng skeletonData (x, y, z=0, visible 0/1) × 18 khớp mỗi người — cùng bố cục mà `resolveSkeletonData` trả. */
    fun flatten(persons: List<OutputVerifier.Person>): FloatArray {
        val out = FloatArray(persons.size * OutputVerifier.JOINTS * OutputVerifier.FLOATS_PER_JOINT)
        var o = 0
        for (p in persons) for (j in p.joints) {
            out[o] = j.x; out[o + 1] = j.y; out[o + 2] = 0f; out[o + 3] = if (j.visible) 1f else 0f
            o += OutputVerifier.FLOATS_PER_JOINT
        }
        return out
    }

    /** Hợp lệ để dùng làm khung xương: đúng bội 72 float và đúng số người mong đợi. */
    fun isValidLayout(layout: List<Float>?, expectedPersons: Int): Boolean {
        val per = OutputVerifier.JOINTS * OutputVerifier.FLOATS_PER_JOINT
        return layout != null && layout.isNotEmpty() && layout.size % per == 0 && layout.size / per == expectedPersons
    }
}
