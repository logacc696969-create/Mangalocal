package com.mangalocal.pipeline

import android.os.Bundle
import android.os.Message

// mục 161 TECHNICAL_STATUS.md (đợt 8 — "#5 Multi-Process Isolation", đề
// xuất từ đợt audit PDF ngoài, mục 146/161). User chỉ ra ĐÚNG: nhiều thứ
// tôi tưởng "chỉ build thật mới biết" thực ra là quy ước đã tài liệu hoá
// (Messenger IPC pattern, Application đa tiến trình, Application.
// getProcessName() — đã tra cứu web xác nhận, xem TECHNICAL_STATUS.md).
// NHƯNG cũng tra ra 1 ràng buộc THẬT không thu nhỏ được: con trỏ native
// (jlong ptr — MNN Interpreter/Session) KHÔNG thể đi qua ranh giới tiến
// trình (đặc tính hệ điều hành, không phải hành vi Android riêng) — nghĩa
// là MangaPipeline/ImagePipeline/NativeBridge phải chuyển TRỌN VẸN sang
// tiến trình `:inference` cùng nhau, không tách nhỏ được như #3.
//
// Dùng Messenger (không phải AIDL) — đúng khuyến nghị tra cứu được: case
// này là request/response + callback đơn giản (sinh 1 chương, nhận
// progress + kết quả), không cần API đa phương thức phức tạp AIDL nhắm
// tới. Dữ liệu (Story/Chapter/GenerationSettings) đóng gói qua Gson
// (THƯ VIỆN ĐÃ DÙNG SẴN khắp StoryManager.kt) thành chuỗi JSON nhét vào
// Bundle — KHÔNG viết Parcelable mới cho từng data class (bề mặt lỗi lớn,
// dễ quên field khi data class đổi) — tái dùng đúng cơ chế serialize đã
// chứng minh hoạt động của dự án thay vì phát minh đường mới.
object GenerationProtocol {
    // Client (MainViewModel, tiến trình UI) -> Service (tiến trình :inference)
    const val MSG_RUN_GENERATION = 10
    const val MSG_CANCEL = 11

    // Service -> Client
    const val MSG_PROGRESS = 20
    const val MSG_RESULT = 21
    const val MSG_ERROR = 22

    // Bundle keys — dùng chung cho cả 2 chiều, tránh gõ nhầm string rải rác
    private const val KEY_REQUEST_ID = "requestId"
    private const val KEY_STORY_ID = "storyId"
    private const val KEY_CHAPTER_ID = "chapterId"
    private const val KEY_SETTINGS_JSON = "settingsJson"
    private const val KEY_PIPELINE_STATE_JSON = "pipelineStateJson"
    private const val KEY_PURGE_AFTER = "purgeAfter"
    private const val KEY_ERROR = "error"

    // mục 161 (đợt 8) — requestId (UUID) đi kèm MỌI message 2 chiều, để
    // client PHÂN BIỆT được response ứng với đúng lượt gọi nào — quan
    // trọng vì Service có thể bị kill/khởi động lại giữa chừng
    // (onServiceDisconnected), client cần biết 1 response đến có còn
    // "hợp lệ" với lượt generation ĐANG chờ hay là response trễ từ 1 lượt
    // cũ đã bị huỷ/thay thế.

    fun buildRunGenerationMessage(requestId: String, storyId: String, chapterId: String, settingsJson: String, purgeAfter: Boolean = false): Message =
        Message.obtain(null, MSG_RUN_GENERATION).apply {
            data = Bundle().apply {
                putString(KEY_REQUEST_ID, requestId)
                putString(KEY_STORY_ID, storyId)
                putString(KEY_CHAPTER_ID, chapterId)
                putString(KEY_SETTINGS_JSON, settingsJson)
                putBoolean(KEY_PURGE_AFTER, purgeAfter)
            }
        }

    data class RunGenerationRequest(val requestId: String, val storyId: String, val chapterId: String, val settingsJson: String, val purgeAfter: Boolean)
    fun parseRunGenerationMessage(msg: Message): RunGenerationRequest? {
        val d = msg.data ?: return null
        val id = d.getString(KEY_REQUEST_ID) ?: return null
        val storyId = d.getString(KEY_STORY_ID) ?: return null
        val chapterId = d.getString(KEY_CHAPTER_ID) ?: return null
        val g = d.getString(KEY_SETTINGS_JSON) ?: return null
        return RunGenerationRequest(id, storyId, chapterId, g, d.getBoolean(KEY_PURGE_AFTER, false))
    }

    fun buildProgressMessage(requestId: String, pipelineStateJson: String): Message =
        Message.obtain(null, MSG_PROGRESS).apply {
            data = Bundle().apply {
                putString(KEY_REQUEST_ID, requestId)
                putString(KEY_PIPELINE_STATE_JSON, pipelineStateJson)
            }
        }

    data class ProgressUpdate(val requestId: String, val pipelineStateJson: String)
    fun parseProgressMessage(msg: Message): ProgressUpdate? {
        val d = msg.data ?: return null
        val id = d.getString(KEY_REQUEST_ID) ?: return null
        val s = d.getString(KEY_PIPELINE_STATE_JSON) ?: return null
        return ProgressUpdate(id, s)
    }

    // mục 161 TECHNICAL_STATUS.md (đợt 10 — user hỏi đúng: rủi ro cao thì
    // tra cứu tìm giải pháp tốt hơn thay vì chỉ đoán). Tra cứu xác nhận
    // (tài liệu Android chính thức): Binder transaction buffer 1MB DÙNG
    // CHUNG cho MỌI giao dịch đang chạy của CẢ TIẾN TRÌNH (không phải
    // 1MB/message riêng) — khuyến nghị chính thức "giữ dưới vài chục KB".
    // `Story.characters` nhúng THẲNG toàn bộ danh sách nhân vật (kể cả
    // `anchorVersions` mục 161 đợt 2) — với quy mô "1000 chương" dự án
    // hướng tới (nhiều nhân vật onetime tích luỹ), gửi NGUYÊN `Chapter` JSON
    // 2 CHIỀU (cả lúc gửi request LẪN lúc nhận result) là rủi ro THẬT, không
    // phải giả định — ĐÃ SỬA: chỉ gửi `chapterId`, phía nhận (dù Service hay
    // Client) tự `storyManager.loadChapter()` từ đĩa (2 tiến trình dùng
    // CHUNG file hệ thống vật lý — đọc file không cần qua Binder, không có
    // giới hạn 1MB nào áp dụng).
    fun buildResultMessage(requestId: String, chapterId: String): Message =
        Message.obtain(null, MSG_RESULT).apply {
            data = Bundle().apply {
                putString(KEY_REQUEST_ID, requestId)
                putString(KEY_CHAPTER_ID, chapterId)
            }
        }

    data class ResultPayload(val requestId: String, val chapterId: String)
    fun parseResultMessage(msg: Message): ResultPayload? {
        val d = msg.data ?: return null
        val id = d.getString(KEY_REQUEST_ID) ?: return null
        val c = d.getString(KEY_CHAPTER_ID) ?: return null
        return ResultPayload(id, c)
    }

    fun buildErrorMessage(requestId: String, error: String): Message =
        Message.obtain(null, MSG_ERROR).apply {
            data = Bundle().apply {
                putString(KEY_REQUEST_ID, requestId)
                putString(KEY_ERROR, error)
            }
        }

    data class ErrorPayload(val requestId: String, val error: String)
    fun parseErrorMessage(msg: Message): ErrorPayload? {
        val d = msg.data ?: return null
        val id = d.getString(KEY_REQUEST_ID) ?: return null
        val e = d.getString(KEY_ERROR) ?: return null
        return ErrorPayload(id, e)
    }
}
