package com.mangalocal.pipeline

import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * mục 238 TECHNICAL_STATUS.md — hình học vùng KHUÔN MẶT từ khung xương, cho lượt vẽ lại biểu cảm
 * (MangaPipeline.tryExpressionFacePass).
 *
 * Cộng đồng xử lý biểu cảm bằng cách nào (đã tra cứu, xem mục 238): prompt chữ một mình cho biểu cảm
 * chung chung/nhạt (bài "Panel-by-Panel Souls", NeurIPS 2025 Creative AI, arXiv 2511.16038: text-to-image
 * "consistently fail" với biểu cảm tinh tế); cách phổ biến cho SD1.5/SDXL là KHOÁ SEED + vẽ lại CHỈ vùng
 * mặt bằng ADetailer/inpaint với prompt biểu cảm, điều chỉnh nhẹ (book.st-hakky.com, help.scenario.com),
 * và crop rộng vừa đủ gồm cả tóc cho kết quả hài hoà hơn crop sát mặt (cùng bài NeurIPS). Giới hạn đã
 * được chính bài đó ghi nhận: mặt xoay quá ~45° và mặt nhỏ/xa kém ổn định.
 *
 * Hàm THUẦN: bố cục khung xương là `18 khớp × (x, y, z, visible)`, x/y chuẩn hoá 0..1, chỉ số OpenPose-18
 * (0 mũi, 1 cổ, 2/5 vai, 14/15 mắt, 16/17 tai).
 *
 * HẰNG SỐ TỈ LỆ KHUÔN MẶT (heuristic giải phẫu trung bình, KHÔNG hiệu chỉnh trên nhân vật anime/truyện):
 * khoảng cách hai mắt ≈ 0.42 × bề rộng đầu; từ lông mày tới cằm ≈ 1.0 × bề rộng đầu; tâm vùng đặc trưng nằm
 * dưới đường mắt ≈ 0.35 × bề rộng đầu. Vùng đặc trưng CHỈ gồm mày–mắt–mũi–miệng–cằm (rộng 0.85 × bề rộng
 * đầu) để KHÔNG vẽ lại đường viền tóc/tai — giảm lệch danh tính.
 */
object ExpressionFace {

    private const val FPP = 18 * 4
    const val EYE_TO_HEAD_WIDTH = 0.42f
    const val HEAD_WIDTH_FROM_SHOULDER = 0.38f
    const val FEATURE_WIDTH = 0.85f
    const val FEATURE_HEIGHT = 1.0f
    const val CENTER_BELOW_EYES = 0.35f
    const val MIN_HEAD_WIDTH_PX = 28f // mặt nhỏ hơn thế (theo cạnh ngắn ảnh) -> bỏ qua: quá nhỏ/xa, kém ổn định

    data class FaceBox(val personIdx: Int, val rect: Rect, val threeQuarter: Boolean, val headWidthPx: Float)

    private fun vis(sk: FloatArray, base: Int, j: Int) = sk[base + j * 4 + 3] > 0.5f
    private fun px(sk: FloatArray, base: Int, j: Int) = sk[base + j * 4]
    private fun py(sk: FloatArray, base: Int, j: Int) = sk[base + j * 4 + 1]

    /**
     * Trả vùng mặt của từng người ĐỦ ĐIỀU KIỆN: mũi nhìn thấy và có ít nhất 1 mắt nhìn thấy (loại mặt quay lưng/
     * úp). Chỉ 1 mắt = 3/4 hoặc nghiêng -> `threeQuarter = true` (vẫn trả vùng nhưng caller có thể thận trọng hơn).
     */
    fun faceBoxes(sk: FloatArray, numPersons: Int, imgW: Int, imgH: Int): List<FaceBox> {
        if (sk.isEmpty() || imgW <= 0 || imgH <= 0) return emptyList()
        val n = min(numPersons, sk.size / FPP)
        val minSide = min(imgW, imgH).toFloat()
        val out = ArrayList<FaceBox>()
        for (i in 0 until n) {
            val b = i * FPP
            if (!vis(sk, b, 0)) continue
            val rEye = vis(sk, b, 14); val lEye = vis(sk, b, 15)
            if (!rEye && !lEye) continue
            val eyeMidX: Float; val eyeMidY: Float
            val bothEyes = rEye && lEye
            if (bothEyes) {
                eyeMidX = (px(sk, b, 14) + px(sk, b, 15)) / 2f; eyeMidY = (py(sk, b, 14) + py(sk, b, 15)) / 2f
            } else {
                val e = if (rEye) 14 else 15
                eyeMidX = px(sk, b, e); eyeMidY = py(sk, b, e)
            }
            val shoulderW = if (vis(sk, b, 2) && vis(sk, b, 5))
                hypot((px(sk, b, 2) - px(sk, b, 5)) * imgW, (py(sk, b, 2) - py(sk, b, 5)) * imgH) else 0f
            val eyeDistPx = if (bothEyes)
                hypot((px(sk, b, 14) - px(sk, b, 15)) * imgW, (py(sk, b, 14) - py(sk, b, 15)) * imgH) else 0f
            var headW = when {
                bothEyes && eyeDistPx > 0f -> eyeDistPx / EYE_TO_HEAD_WIDTH
                shoulderW > 0f -> shoulderW * HEAD_WIDTH_FROM_SHOULDER
                else -> 0f
            }
            // Kẹp theo bề rộng vai khi biết (chống mắt đo sai làm vùng phình/xẹp bất thường).
            if (shoulderW > 0f) headW = headW.coerceIn(0.28f * shoulderW, 0.55f * shoulderW)
            if (headW <= 0f || headW < MIN_HEAD_WIDTH_PX * (minSide / 512f)) continue
            val cx = if (bothEyes) (eyeMidX + px(sk, b, 0)) / 2f * imgW else px(sk, b, 0) * imgW
            val cy = eyeMidY * imgH + CENTER_BELOW_EYES * headW
            val halfW = FEATURE_WIDTH * headW / 2f
            val halfH = FEATURE_HEIGHT * headW / 2f
            val rect = Rect(
                (cx - halfW).toInt().coerceIn(0, imgW), (cy - halfH).toInt().coerceIn(0, imgH),
                (cx + halfW).toInt().coerceIn(0, imgW), (cy + halfH).toInt().coerceIn(0, imgH)
            )
            if (rect.width() < 8 || rect.height() < 8) continue
            out += FaceBox(i, rect, !bothEyes, headW)
        }
        return out
    }
}
