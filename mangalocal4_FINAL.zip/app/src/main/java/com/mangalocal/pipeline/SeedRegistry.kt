package com.mangalocal.pipeline

import com.mangalocal.model.GenerationSettings
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Kho lưu trữ Seed thông minh (Seed Registry Cache) — mục 75
 * TECHNICAL_STATUS.md.
 *
 * Vận hành:
 *  - Mỗi khi QualityGateChecker.evaluate() trả về QualityReport.passed = true
 *    NGAY LẦN ĐẦU (không cần retry), pipeline tự động lưu seed vào kho theo
 *    key = [numPersons]_[actionCategory].
 *  - Ở các panel tiếp theo cùng cấu trúc (cùng numPersons + actionCategory),
 *    thay vì random seed hoàn toàn, pipeline bốc 1 seed từ kho (xoay vòng).
 *    Mục tiêu: giảm tần suất sinh ảnh lỗi ngay từ lượt đầu.
 *
 * actionCategory được trích từ action keywords trong scene.action:
 *  "hug/ôm/ôm chầm"    → "embrace"
 *  "fight/đánh/vật nhau" → "combat"
 *  mặc định              → "neutral"
 *
 * File JSON lưu tại: storyDir/seed_registry.json
 * Format: { "key": [seed1, seed2, ...], ... }
 * Giới hạn: tối đa MAX_PER_KEY seed mỗi key (hàng đợi FIFO, seed cũ nhất
 * bị đẩy ra khi vượt giới hạn).
 *
 * GIỚI HẠN THẬT:
 *  - Seed "hoàn hảo" theo QualityGate chỉ đảm bảo không có LỖI GIẢI PHẪU
 *    (số chi đúng). Không đảm bảo ảnh đẹp về mặt thẩm mỹ/bố cục.
 *  - Registry DÙNG CHUNG cho toàn bộ model/story; nếu đổi model thì seed từ
 *    model cũ không còn phù hợp — nên xoá registry sau khi đổi model (UI
 *    chưa có, nhắc trong comment).
 *  - CHƯA BUILD-TEST.
 */
class SeedRegistry(private val storyDir: File) {

    companion object {
        private const val FILENAME = "seed_registry.json"
        private const val MAX_PER_KEY = 20
        private const val MIN_SAMPLES_BEFORE_REUSE = 3 // cần ít nhất 3 seed trước khi bắt đầu dùng lại

        /**
         * Danh sách actionCategory hợp lệ — DÙNG CHUNG cho cả 2 nguồn phân
         * loại (heuristic regex bên dưới VÀ field LLM tự trả ở
         * `Scene.actionCategory`, mục 85). Giữ đúng 1 nguồn sự thật duy
         * nhất cho tập giá trị hợp lệ, tránh 2 nơi định nghĩa lệch nhau
         * theo thời gian (LLMParser.kt tham chiếu list này khi build
         * prompt schema).
         */
        val VALID_CATEGORIES = setOf("embrace", "combat", "kiss", "run", "neutral")

        /** Phân loại action thô từ mô tả scene (heuristic regex — dùng làm FALLBACK). */
        fun classifyAction(action: String): String {
            val lower = action.lowercase()
            return when {
                Regex("hug|ôm|ôm chầm|ôm siết|vòng tay").containsMatchIn(lower) -> "embrace"
                Regex("fight|đánh|vật|đấm|đá|combat|wrestl").containsMatchIn(lower) -> "combat"
                Regex("kiss|hôn|nụ hôn").containsMatchIn(lower) -> "kiss"
                Regex("run|chạy|sprint|flee|trốn").containsMatchIn(lower) -> "run"
                else -> "neutral"
            }
        }

        /**
         * Nguồn thật để MangaPipeline.kt gọi (thay vì gọi thẳng
         * `classifyAction()`) — ưu tiên `scene.actionCategory` do LLM tự
         * trả (LLMParser.kt, mục 85) nếu có VÀ nằm trong [VALID_CATEGORIES]
         * (phòng LLM trả giá trị lạ ngoài enum đã định nghĩa trong prompt).
         * Rơi về heuristic regex cũ (`classifyAction(scene.action)`) trong
         * mọi trường hợp còn lại — null, rỗng, hoặc giá trị không hợp lệ.
         * Không throw, không log lỗi ở tầng này — sai lệch phân loại chỉ
         * ảnh hưởng chất lượng gợi ý seed (mục 75), không phải lỗi nghiêm
         * trọng cần chặn pipeline.
         */
        fun resolveActionCategory(scene: com.mangalocal.model.Scene): String {
            val fromLlm = scene.actionCategory?.trim()?.lowercase()
            return if (fromLlm != null && fromLlm in VALID_CATEGORIES) fromLlm
            else classifyAction(scene.action)
        }

        private fun makeKey(numPersons: Int, actionCategory: String) =
            "${numPersons}p_${actionCategory}"
    }

    private val file = File(storyDir, FILENAME)
    private val data = mutableMapOf<String, ArrayDeque<Long>>()

    init {
        if (file.exists()) {
            try {
                val json = JSONObject(file.readText())
                json.keys().forEach { key ->
                    val arr = json.getJSONArray(key)
                    data[key] = ArrayDeque<Long>().also { dq ->
                        for (i in 0 until arr.length()) dq.addLast(arr.getLong(i))
                    }
                }
            } catch (_: Exception) { /* corrupt file — start fresh */ }
        }
    }

    /**
     * Đề xuất seed từ kho cho panel có [numPersons] người và [actionCategory].
     * Trả về null nếu chưa đủ mẫu (MIN_SAMPLES_BEFORE_REUSE).
     */
    fun suggestSeed(numPersons: Int, actionCategory: String): Long? {
        val key = makeKey(numPersons, actionCategory)
        val queue = data[key] ?: return null
        if (queue.size < MIN_SAMPLES_BEFORE_REUSE) return null
        // Xoay vòng: lấy seed đầu, đẩy về cuối để dùng lại công bằng
        val seed = queue.removeFirst()
        queue.addLast(seed)
        return seed
    }

    /**
     * Ghi nhận seed [seed] là "hoàn hảo" cho cấu trúc [numPersons]/[actionCategory].
     * Gọi khi QualityGateChecker.passed = true NGAY LẦN ĐẦU (không retry).
     */
    fun recordPerfectSeed(numPersons: Int, actionCategory: String, seed: Long) {
        val key = makeKey(numPersons, actionCategory)
        val queue = data.getOrPut(key) { ArrayDeque() }
        if (seed in queue) return // không ghi trùng
        queue.addLast(seed)
        while (queue.size > MAX_PER_KEY) queue.removeFirst()
        persist()
    }

    private fun persist() {
        try {
            val json = JSONObject()
            data.forEach { (k, v) ->
                val arr = JSONArray(); v.forEach { arr.put(it) }
                json.put(k, arr)
            }
            file.writeText(json.toString(2))
        } catch (_: Exception) {}
    }

    /** Xoá toàn bộ registry — nên gọi khi người dùng đổi SD model. */
    fun clear() { data.clear(); file.delete() }
}
