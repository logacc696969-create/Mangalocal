package com.mangalocal.pipeline

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Tự động phát hiện phần cứng và chọn config tối ưu.
 * Không hardcode cho bất kỳ thiết bị cụ thể nào — hoạt động tốt trên
 * mọi Snapdragon có Adreno GPU, tự scale khi đổi máy.
 */
class RuntimeOptimizer(private val context: Context) {

    data class HardwareProfile(
        val chipset: String,
        val adrenoGen: Int,          // 6xx, 7xx, 8xx...
        val bigCores: Int,           // số big core tối ưu cho LLM
        val ramGb: Int,
        val openClSupported: Boolean,
        val vulkanSupported: Boolean,
        val recommendedThreads: Int,
        val recommendedBackend: LlmBackend,
        val recommendedQuantization: QuantType
    )

    enum class LlmBackend { CPU_ONLY, OPENCL_ADRENO, VULKAN }
    enum class QuantType { Q4_0_PURE, Q4_K_M, Q8_0 }

    data class OptimalConfig(
        val nThreads: Int,
        val useGpuForLlm: Boolean,
        val gpuBackend: LlmBackend,
        val nGpuLayers: Int,         // số layer offload lên GPU (0 = CPU only)
        val recommendedQuantization: QuantType,
        val sdUseVulkan: Boolean,
        val sdNThreads: Int,
        val explanation: List<String>  // giải thích cho người dùng
    )

    // ── Detect hardware ───────────────────────────────────────────────────

    fun detectHardware(): HardwareProfile {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramGb = (memInfo.totalMem / 1_073_741_824L).toInt()

        val chipset = detectChipset()
        val adrenoGen = detectAdrenoGen(chipset)
        val bigCores = detectBigCores()
        val openCl = checkOpenCLSupport()
        val vulkan = checkVulkanSupport()

        val backend = when {
            openCl && adrenoGen >= 700 -> LlmBackend.OPENCL_ADRENO  // 7xx+ OpenCL verified
            openCl && adrenoGen >= 600 -> LlmBackend.OPENCL_ADRENO  // 6xx thử nghiệm
            vulkan -> LlmBackend.VULKAN
            else -> LlmBackend.CPU_ONLY
        }

        // Q4_0 nhanh hơn trên Adreno OpenCL, Q4_K_M tốt hơn cho CPU-only
        val quant = when {
            backend == LlmBackend.OPENCL_ADRENO -> QuantType.Q4_0_PURE
            ramGb >= 12 -> QuantType.Q4_K_M
            else -> QuantType.Q4_0_PURE
        }

        return HardwareProfile(
            chipset = chipset,
            adrenoGen = adrenoGen,
            bigCores = bigCores,
            ramGb = ramGb,
            openClSupported = openCl,
            vulkanSupported = vulkan,
            recommendedThreads = bigCores,
            recommendedBackend = backend,
            recommendedQuantization = quant
        )
    }

    /**
     * Tính config tối ưu dựa trên hardware profile.
     * Tự động scale cho máy mới khi đổi thiết bị.
     */
    fun computeOptimalConfig(profile: HardwareProfile): OptimalConfig {
        val explanations = mutableListOf<String>()

        // ── LLM threads ───────────────────────────────────────────────────
        val llmThreads = profile.bigCores.coerceIn(2, 6)
        explanations.add("LLM: ${llmThreads} threads (big cores: ${profile.bigCores})")

        // ── LLM GPU offload ───────────────────────────────────────────────
        val useGpu = profile.openClSupported || profile.vulkanSupported
        val gpuLayers = when {
            !useGpu -> 0
            profile.ramGb >= 16 -> 999  // offload hết lên GPU nếu đủ RAM
            profile.ramGb >= 8 -> 20    // offload một phần
            else -> 0
        }
        if (useGpu) {
            explanations.add("LLM GPU: ${profile.recommendedBackend.name}, ${gpuLayers} layers offloaded")
        } else {
            explanations.add("LLM: CPU-only (không có OpenCL/Vulkan support)")
        }

        // ── SD threads ────────────────────────────────────────────────────
        // SD dùng ít thread hơn vì nó cần bandwidth RAM nhiều hơn compute
        val sdThreads = (profile.bigCores / 2).coerceAtLeast(2)
        explanations.add("SD: ${sdThreads} threads + Vulkan upscale")

        // ── Quantization recommendation ───────────────────────────────────
        explanations.add("Quantization khuyến nghị: ${profile.recommendedQuantization.name}")

        return OptimalConfig(
            nThreads = llmThreads,
            useGpuForLlm = useGpu,
            gpuBackend = profile.recommendedBackend,
            nGpuLayers = gpuLayers,
            recommendedQuantization = profile.recommendedQuantization,
            sdUseVulkan = profile.vulkanSupported,
            sdNThreads = sdThreads,
            explanation = explanations
        )
    }

    // ── Hardware detection helpers ────────────────────────────────────────

    private fun detectChipset(): String {
        // Đọc từ /proc/cpuinfo hoặc system properties
        return try {
            val cpuInfo = File("/proc/cpuinfo").readText()
            val hardware = cpuInfo.lines()
                .find { it.startsWith("Hardware", ignoreCase = true) }
                ?.substringAfter(":")?.trim() ?: ""
            if (hardware.isNotEmpty()) hardware
            else Build.HARDWARE ?: "unknown"
        } catch (e: Exception) { Build.HARDWARE ?: "unknown" }
    }

    private fun detectAdrenoGen(chipset: String): Int {
        // Map chipset → Adreno generation
        val lower = chipset.lowercase()
        return when {
            lower.contains("8 gen 3") || lower.contains("8gen3") -> 750  // Adreno 750
            lower.contains("8 gen 2") || lower.contains("8gen2") -> 740  // Adreno 740
            lower.contains("8 gen 1") || lower.contains("8gen1") -> 730  // Adreno 730
            lower.contains("888") || lower.contains("sm8350")    -> 660  // Adreno 660
            lower.contains("865") || lower.contains("sm8250")    -> 650  // Adreno 650
            lower.contains("855") || lower.contains("sm8150")    -> 640  // Adreno 640
            lower.contains("8 elite") || lower.contains("8elite")-> 830  // Adreno 830
            else -> {
                // Fallback: đọc từ GPU renderer string
                detectAdrenoGenFromGpu()
            }
        }
    }

    // mục 63 TECHNICAL_STATUS.md — tự dò SoC ID/HEXAGON_ARCH cho chế độ QNN
    // offline (mục 62, trước đó ghi rõ "KHÔNG tự dò được — user phải tự
    // biết đúng chip máy"). Bảng ánh xạ SM-number -> (socId, hexagonArch)
    // ĐÃ TRA XÁC NHẬN qua 2 nguồn ĐỘC LẬP (không đoán):
    //   (1) Tài liệu chính thức MNN (docs/inference/npu.md — 8 Gen 1/2/3/
    //       Elite -> HEXAGON_ARCH 69/73/75/79, socId 36/43/57/69).
    //   (2) Code THẬT của Google LiteRT (google-ai-edge/LiteRT, file
    //       target.py định nghĩa SocModel enum cho QNN) — dòng comment gốc
    //       "SM8450 # Snapdragon 8 Gen 1 — HTP v69" xác nhận ĐỘC LẬP khớp
    //       đúng HEXAGON_ARCH=69 của 8 Gen 1 từ nguồn (1), củng cố độ tin
    //       cậy thay vì chỉ dựa 1 nguồn.
    // CHỈ liệt 4 dòng CÓ ĐỦ 2 NGUỒN xác nhận khớp nhau — các biến thể
    // "Plus"/"for Galaxy" (SM8475, SM8550-AC, SM8650-AC...) CHƯA CÓ socId
    // xác nhận riêng (có thể dùng chung HEXAGON_ARCH với bản gốc cùng thế
    // hệ theo suy luận hợp lý, nhưng socId khác thì CHƯA xác nhận) — KHÔNG
    // đoán, trả null cho các biến thể đó, để hàm gọi tự xử lý "không dò
    // được" thay vì áp liều 1 giá trị có thể sai.
    data class QnnSocTarget(val socId: Int, val hexagonArch: Int, val socModel: String)

    // mục 65 TECHNICAL_STATUS.md — thêm SM8350 (Snapdragon 888, chip máy
    // DEV CHÍNH của dự án: ASUS Zenfone 8 16GB RAM). Nguồn xác nhận:
    //   (1) MNN THẬT — apps/Android/MnnLlmChat/.../qnn/QnnModule.kt (file
    //       source chính thức, dòng 23-41 theo DeepWiki index) liệt bảng
    //       sQnnLibMap: "SM8350 -> V68 (mã tên model 30_v68), Snapdragon
    //       888 (2020)" — cho CẢ socId=30 lẫn hexagonArch=68 khớp nhau.
    //   (2) Google LiteRT THẬT — litert/python/aot/vendors/qualcomm/
    //       target.py (trích trực tiếp trong GitHub issue #8223 của repo
    //       google-ai-edge/LiteRT) liệt "SM8350" là 1 giá trị hợp lệ của
    //       enum SocModel dùng cho QNN AOT compile — XÁC NHẬN ĐỘC LẬP rằng
    //       SM8350 THẬT SỰ là 1 target QNN được hỗ trợ (nguồn này không tự
    //       ghi rõ số hexagonArch, chỉ xác nhận sự tồn tại của SoC này
    //       trong hệ QNN — khác 4 dòng dưới có cả 2 nguồn cùng cho ra ĐÚNG
    //       số hexagonArch).
    private val knownQnnSocs = mapOf(
        "SM8450" to QnnSocTarget(36, 69, "SM8450"),   // Snapdragon 8 Gen 1
        "SM8550" to QnnSocTarget(43, 73, "SM8550"),   // Snapdragon 8 Gen 2
        "SM8650" to QnnSocTarget(57, 75, "SM8650"),   // Snapdragon 8 Gen 3
        "SM8750" to QnnSocTarget(69, 79, "SM8750"),   // Snapdragon 8 Elite
        "SM8350" to QnnSocTarget(30, 68, "SM8350"),   // Snapdragon 888 (Zenfone 8 — máy dev chính của dự án, mục 65)
    )

    fun detectQnnSoc(): QnnSocTarget? {
        // Ưu tiên Build.SOC_MODEL (API 31+, Android 12+) — API CHÍNH THỨC
        // của Android dành riêng cho việc này, đáng tin hơn hẳn suy từ
        // /proc/cpuinfo (định dạng "Hardware" field không chuẩn hoá, khác
        // nhau tuỳ OEM). Máy chạy được QNN NPU chắc chắn đủ mới để có
        // Build.SOC_MODEL (chip flagship 8-series đời 2022+ đều Android
        // 12+ sẵn), nên yêu cầu API 31+ ở đây KHÔNG loại bỏ thiết bị đích
        // thật nào.
        val socModelRaw = if (Build.VERSION.SDK_INT >= 31) {
            try { Build.SOC_MODEL } catch (e: Exception) { null }
        } else null

        if (!socModelRaw.isNullOrBlank()) {
            knownQnnSocs[socModelRaw.uppercase()]?.let { return it }
        }

        // Fallback máy cũ hơn API 31 (hiếm với NPU target, nhưng vẫn thử
        // cho đầy đủ): dò SM-number trong chuỗi chipset đã có sẵn từ
        // detectChipset() qua regex, KHÔNG đoán field mới.
        val chipsetStr = detectChipset()
        val match = Regex("SM8[0-9]{3}").find(chipsetStr.uppercase())
        if (match != null) {
            knownQnnSocs[match.value]?.let { return it }
        }

        return null  // Không dò được — CHƯA đoán, gọi hàm PHẢI tự xử lý (vd tắt lựa chọn NPU offline tự động, để user tự chọn thủ công)
    }

    private fun detectAdrenoGenFromGpu(): Int {
        return try {
            // Đọc từ OpenGL ES renderer string qua property
            val renderer = android.opengl.GLES20.GL_RENDERER?.toString() ?: ""
            val match = Regex("Adreno\\s*(\\d+)").find(renderer)
            match?.groupValues?.get(1)?.toIntOrNull() ?: 600
        } catch (e: Exception) { 600 }
    }

    private fun detectBigCores(): Int {
        return try {
            // Đọc max frequency của các core để phân loại big/little
            val coreCount = Runtime.getRuntime().availableProcessors()
            val freqs = (0 until coreCount).mapNotNull { cpu ->
                File("/sys/devices/system/cpu/cpu$cpu/cpufreq/cpuinfo_max_freq")
                    .takeIf { it.exists() }?.readText()?.trim()?.toLongOrNull()
            }
            if (freqs.isEmpty()) return (coreCount / 2).coerceAtLeast(2)

            val maxFreq = freqs.max()
            val threshold = maxFreq * 0.7f  // core có freq > 70% max = "big"
            val bigCount = freqs.count { it >= threshold }
            bigCount.coerceIn(2, 6)
        } catch (e: Exception) { 4 }
    }

    private fun checkOpenCLSupport(): Boolean {
        return try {
            // Kiểm tra libOpenCL.so có tồn tại không
            listOf(
                "/vendor/lib64/libOpenCL.so",
                "/system/lib64/libOpenCL.so",
                "/vendor/lib64/libOpenCL_adreno.so"
            ).any { File(it).exists() }
        } catch (e: Exception) { false }
    }

    private fun checkVulkanSupport(): Boolean {
        return try {
            context.packageManager.hasSystemFeature("android.hardware.vulkan.version")
        } catch (e: Exception) { true } // Snapdragon 888 có Vulkan
    }

    // ── Public summary ────────────────────────────────────────────────────

    fun getHardwareSummary(): String {
        val p = detectHardware()
        val c = computeOptimalConfig(p)
        return buildString {
            appendLine("📱 Phần cứng phát hiện:")
            appendLine("  Chipset: ${p.chipset}")
            appendLine("  Adreno: ~${p.adrenoGen}")
            appendLine("  Big cores: ${p.bigCores}")
            appendLine("  RAM: ${p.ramGb}GB")
            appendLine("  OpenCL: ${if (p.openClSupported) "✓" else "✗"}")
            appendLine("  Vulkan: ${if (p.vulkanSupported) "✓" else "✗"}")
            appendLine()
            appendLine("⚡ Config tối ưu:")
            c.explanation.forEach { appendLine("  • $it") }
            appendLine()
            appendLine("📦 Quantization khuyến nghị: ${c.recommendedQuantization.name}")
            appendLine("  Q4_0: nhanh hơn trên Adreno OpenCL")
            appendLine("  Q4_K_M: chất lượng tốt hơn cho CPU-only")
        }
    }
}
