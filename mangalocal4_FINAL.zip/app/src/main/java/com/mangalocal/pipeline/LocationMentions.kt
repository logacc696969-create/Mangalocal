package com.mangalocal.pipeline

import com.mangalocal.model.Scene
import java.text.Normalizer

/**
 * mục 249 TECHNICAL_STATUS.md — @-MENTION BỐI CẢNH trong văn bản truyện (kiểu References của Civitai Comics, tra cứu từ PDF):
 * người dùng gõ `@Tên bối cảnh đã có` hoặc `@[Tên bối cảnh mới]` ngay trong văn bản để CHỈ ĐỊNH nơi xảy ra cảnh, thay vì chờ LLM nhỏ
 * tự đặt tên (mục 216 ghi rõ LLM hay đặt tên lệch nhau).
 *
 * Cách hoạt động (3 lớp):
 *  1. `find`: tìm mention. `@[...]` nhận tên bất kỳ; `@Tên` chỉ nhận khi KHỚP tên bối cảnh đã biết (không phân biệt hoa/thường/dấu,
 *     lấy tên dài nhất, và phải kết thúc ở ranh giới từ) — để địa chỉ email/`@nhắc_ai_đó` không bị hiểu nhầm.
 *  2. `strip`: văn bản gửi LLM đã bỏ ký hiệu `@`/`[]` (còn lại tên thường) + một dòng hướng dẫn thêm vào storyGuidance.
 *  3. `apply`: sau khi LLM trả cảnh, mention là "dính theo vị trí" (kiểu dòng slug trong kịch bản): bối cảnh áp dụng từ vị trí thẻ
 *     tới thẻ kế tiếp. Cảnh thứ i/n được coi là ứng với đoạn văn [i/n, (i+1)/n). LLM được quyền CHỌN giữa các bối cảnh đã nhắc
 *     (để sửa sai lệch ở biên) nhưng KHÔNG được bịa nơi khác khi người dùng đã gắn thẻ ở vị trí đó.
 *
 * GIỚI HẠN THẬT:
 *  - Ánh xạ cảnh ↔ vị trí trong văn bản là XẤP XỈ theo tỉ lệ (LLM không trả offset): cảnh sát biên giữa hai bối cảnh có thể bị gán
 *    sang bên kia; chỉ cứu được khi LLM tự chọn đúng một bối cảnh đã nhắc.
 *  - Chỉ chỉ định BỐI CẢNH, không chỉ định nhân vật (nhân vật đã nhận diện theo tên).
 *  - CHƯA build-test; chưa thử với LLM thật.
 */
object LocationMentions {

    data class Mention(val name: String, val start: Int, val end: Int, val known: Boolean)

    const val MAX_BRACKET_NAME = 60

    /** Chữ thường, bỏ dấu (đ -> d), gộp khoảng trắng — để so tên không phân biệt hoa/thường/dấu. */
    fun fold(s: String): String {
        val d = Normalizer.normalize(s.replace('đ', 'd').replace('Đ', 'D'), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return d.lowercase().replace(Regex("\\s+"), " ").trim()
    }

    private fun isWordChar(c: Char) = c.isLetterOrDigit() || c == '_'

    fun find(text: String, known: List<String>): List<Mention> {
        val byLen = known.filter { it.isNotBlank() }.distinct().sortedByDescending { it.length }
        val out = ArrayList<Mention>()
        var i = 0
        while (i < text.length) {
            if (text[i] != '@' || (i > 0 && isWordChar(text[i - 1]))) { i++; continue }
            val after = i + 1
            if (after < text.length && text[after] == '[') {
                val close = text.indexOf(']', after + 1)
                if (close in (after + 2)..(after + 1 + MAX_BRACKET_NAME) && text.substring(after + 1, close).none { it == '\n' }) {
                    val raw = text.substring(after + 1, close).trim()
                    if (raw.isNotEmpty()) {
                        val canon = byLen.firstOrNull { fold(it) == fold(raw) } ?: raw
                        out.add(Mention(canon, i, close + 1, byLen.any { it == canon }))
                        i = close + 1
                        continue
                    }
                }
                i++
                continue
            }
            var matched = false
            for (name in byLen) {
                val endIdx = after + name.length
                if (endIdx <= text.length && fold(text.substring(after, endIdx)) == fold(name) &&
                    (endIdx == text.length || !isWordChar(text[endIdx]))) {
                    out.add(Mention(name, i, endIdx, true))
                    i = endIdx
                    matched = true
                    break
                }
            }
            if (!matched) i++
        }
        return out
    }

    /** Bỏ ký hiệu: `@[Tên]` -> `Tên`, `@Tên` -> `Tên` (chỉ với mention đã nhận ra). */
    fun strip(text: String, mentions: List<Mention>): String {
        if (mentions.isEmpty()) return text
        val sb = StringBuilder()
        var pos = 0
        for (m in mentions.sortedBy { it.start }) {
            if (m.start < pos) continue
            sb.append(text, pos, m.start).append(m.name)
            pos = m.end
        }
        sb.append(text, pos, text.length)
        return sb.toString()
    }

    /** Cảnh i/n nhận mention CUỐI CÙNG có vị trí đầu < hết đoạn của cảnh i; chưa có mention nào thì null. */
    fun assign(sceneCount: Int, textLength: Int, mentions: List<Mention>): List<String?> {
        if (sceneCount <= 0) return emptyList()
        val sorted = mentions.sortedBy { it.start }
        return List(sceneCount) { i ->
            var chosen: String? = null
            for (m in sorted) {
                if (m.start.toLong() * sceneCount < (i + 1L) * maxOf(textLength, 1)) chosen = m.name else break
            }
            chosen
        }
    }

    /** Chuẩn hoá tên LLM trả về về đúng tên trong [names] (không phân biệt hoa/thường/dấu); không khớp thì giữ nguyên. */
    fun snap(raw: String, names: Collection<String>): String {
        val f = fold(raw)
        return names.firstOrNull { fold(it) == f } ?: raw
    }

    /** Dòng hướng dẫn thêm vào prompt khi có mention (rỗng nếu không có). */
    fun guidanceFor(mentions: List<Mention>): String {
        if (mentions.isEmpty()) return ""
        val names = mentions.map { it.name }.distinct()
        return "\nBối cảnh do người dùng chỉ định trong văn bản (từ vị trí nhắc tới lần nhắc kế tiếp, tên đúng nguyên văn): " +
            names.joinToString(", ") { "\"$it\"" } +
            ". Đặt location_name đúng nguyên văn tên đó cho các panel xảy ra tại đó.\n"
    }

    /** Hậu xử lý danh sách cảnh sau khi LLM trả về (xem mô tả lớp 3 ở đầu file). */
    fun apply(scenes: List<Scene>, textLength: Int, mentions: List<Mention>, known: List<String>): List<Scene> {
        val mentionedNames = mentions.map { it.name }.distinct()
        val pool = (mentionedNames + known).distinct()
        val sticky = assign(scenes.size, textLength, mentions)
        return scenes.mapIndexed { i, sc ->
            val snapped = sc.locationName?.takeIf { it.isNotBlank() }?.let { snap(it, pool) }
            val chosen = when {
                mentions.isEmpty() -> snapped
                snapped != null && mentionedNames.any { it == snapped } -> snapped
                else -> sticky[i] ?: snapped
            }
            if (chosen == sc.locationName) sc else sc.copy(locationName = chosen)
        }
    }
}
