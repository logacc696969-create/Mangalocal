package com.mangalocal.pipeline

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.google.gson.GsonBuilder
import com.mangalocal.model.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.min

/**
 * mục 233 TECHNICAL_STATUS.md — XUẤT BẢN: template bố cục trang, chuẩn KDP, dải dọc
 * Webtoon, metadata JSON. Thực hiện các hạng mục "CHƯA làm" ở bảng mục 230 (PDF bổ
 * sung gọi là "Template Engine + ghép trang", "KDP-ready", "metadata Webtoon").
 *
 * THÔNG SỐ ĐÃ TRA CỨU (không viết theo trí nhớ):
 * - KDP (kdp.amazon.com/help G201834260 + GVBQ3CMEQW3W2VL6 + G201857950): trang có bleed
 *   = rộng trim + 0.125", cao trim + 0.25" (6x9 -> 6.125x9.25 in); lề ngoài/trên/dưới tối
 *   thiểu 0.25" (không bleed) hoặc 0.375" (có bleed); lề trong (gutter) 0.375" cho 24–150
 *   trang, 0.5" cho 151–300, 0.625" cho 301–500, 0.75" cho 501–700, 0.875" cho 701–828
 *   (BẢNG ĐẦY ĐỦ đã đối chiếu trực tiếp trang chính thức GVBQ3CMEQW3W2VL6 + G201857950 ở
 *   mục 247 — trước đó các mốc giữa là nội suy, nay đã xác nhận trùng khớp).
 * - KDP chỉ in sách đọc phải -> trái (RTL) cho Hebrew, Yiddish và tiếng Nhật; với RTL, số
 *   trang chẵn nằm ở trang PHẢI và số lẻ ở trang TRÁI (G201857950) -> trang 1 là trang trái,
 *   lề trong (gutter) của nó nằm bên PHẢI.
 * - Webtoon Canvas: rộng 800px, mỗi ảnh cao tối đa 1280px, JPG/PNG, tối đa ~2MB/ảnh (nguồn:
 *   hướng dẫn chính thức Clip Studio và nhiều hướng dẫn khác; một nguồn đơn lẻ nói 800px
 *   cao — coi là ngoại lệ). Mã dưới cắt dải theo 800x1280 và nén JPEG tới khi <= 2MB.
 *
 * GIỚI HẠN THẬT:
 * - Mặc định sách đọc TRÁI -> PHẢI (trang lẻ = mặt phải). Chế độ phải -> trái (mục 247,
 *   `rightToLeft`) lật gutter theo quy tắc KDP ở trên và lật thứ tự ô theo chiều ngang;
 *   KHÔNG tự đảo thứ tự trang trong PDF (trang 1 vẫn là trang đầu của chương). Khi tải lên
 *   KDP phải chọn ngôn ngữ/hướng đọc được hỗ trợ RTL (Hebrew, Yiddish, Nhật) — truyện tiếng
 *   Việt không chọn được RTL trên KDP.
 * - Panel đặt kiểu "contain" (vừa khít trong ô, không cắt) để KHÔNG cắt mất bubble/khuôn
 *   mặt; nên khi ô lệch tỉ lệ với ảnh sẽ có viền trắng. Chưa có chế độ cắt lấp đầy.
 * - Bubble được vẽ vào ảnh (bitmap) trước khi đặt vào trang -> không còn là chữ vector.
 * - Dải Webtoon cắt ngang panel khi hết 1280px (nền tảng ghép liền lại); không tự chọn
 *   điểm cắt đẹp.
 * - Không có API tải lên nền tảng nào: chỉ tạo file. Metadata chỉ gồm trường dự án THẬT
 *   có (tên truyện, mô tả, nhân vật...), không tự bịa thẻ/tag.
 * - CHƯA build-test; hình học bố cục đã mô phỏng bằng Python (tools/test_page_layout.py).
 */
enum class PageTemplate(val label: String, val panelsPerPage: Int) {
    STACK_2("2 panel dọc (mặc định)", 2),
    GRID_2X2("Lưới 2×2", 4),
    ONE_PLUS_TWO("1 rộng + 2 dưới", 3),
    FOUR_KOMA("4 dải dọc (4-koma)", 4),
    SPLASH("1 panel mỗi trang", 1),
    AUTO("Tự chọn theo cảnh (nhịp truyện)", 2)   // mục 248 — xem PageLayoutPlanner; mỗi trang một mẫu riêng
}

/** pageWidthPt/pageHeightPt tính bằng point (1/72 inch). */
enum class PageProfile(val label: String, val pageWidthPt: Float, val pageHeightPt: Float,
                       val hasBleed: Boolean, val kdp: Boolean) {
    A4("A4 (mặc định)", 595f, 842f, false, false),
    KDP_6X9("KDP 6×9 in, không bleed", 432f, 648f, false, true),
    KDP_6X9_BLEED("KDP 6×9 in, có bleed (6.125×9.25 in)", 441f, 666f, true, true)
}

data class ExportExtras(
    val pageTemplate: PageTemplate = PageTemplate.STACK_2,
    val pageProfile: PageProfile = PageProfile.A4,
    val rightToLeft: Boolean = false,      // mục 247 — manga phải -> trái (PDF)
    val webtoonZip: Boolean = false,
    val metadataJson: Boolean = false,
    val kenBurnsVideo: Boolean = false,
    val videoPack: Boolean = false,        // mục 244
    val videoSpeech: Boolean = false,      // mục 248 — kèm âm thanh TTS từng câu thoại trong gói video
    val videoRemote: RemoteEndpointConfig? = null,   // mục 249 — khác null: tạo clip.mp4 từng panel trên server từ xa (SVD)
    val videoTarget: String = "KEEP",
    val videoSecondsPerPanel: Float = 3f,
    val story: Story? = null
) {
    /** true = phải dùng PublishExporter.exportPdf thay vì ExportEngine.exportPdf cũ. */
    val usesCustomPdf get() = pageTemplate != PageTemplate.STACK_2 || pageProfile != PageProfile.A4 || rightToLeft
}

/** Hình học bố cục trang — hàm THUẦN để kiểm chứng riêng. */
object PageLayout {

    fun effectiveTemplate(t: PageTemplate, n: Int): PageTemplate = when {
        n <= 1 -> PageTemplate.SPLASH
        t == PageTemplate.GRID_2X2 -> when (n) { 2 -> PageTemplate.STACK_2; 3 -> PageTemplate.ONE_PLUS_TWO; else -> PageTemplate.GRID_2X2 }
        t == PageTemplate.ONE_PLUS_TWO -> if (n == 2) PageTemplate.STACK_2 else PageTemplate.ONE_PLUS_TWO
        t == PageTemplate.AUTO -> PageTemplate.STACK_2   // AUTO được tách thành mẫu cụ thể từng trang ở exportPdf; nhánh này chỉ để an toàn
        else -> t
    }

    private fun rows(c: RectF, g: Float, k: Int): List<RectF> {
        val rh = (c.height() - g * (k - 1)) / k
        return List(k) { i ->
            val top = c.top + i * (rh + g)
            RectF(c.left, top, c.right, top + rh)
        }
    }

    /** Thứ tự ô theo hướng đọc; rtl = lật ngang từng ô trong vùng nội dung (mục 247). */
    fun cells(t: PageTemplate, n: Int, c: RectF, g: Float, rtl: Boolean = false): List<RectF> {
        val base = cellsLeftToRight(t, n, c, g)
        if (!rtl) return base
        return base.map { r -> RectF(c.left + c.right - r.right, r.top, c.left + c.right - r.left, r.bottom) }
    }

    private fun cellsLeftToRight(t: PageTemplate, n: Int, c: RectF, g: Float): List<RectF> {
        val w = c.width(); val h = c.height()
        return when (effectiveTemplate(t, n)) {
            PageTemplate.SPLASH -> listOf(RectF(c))
            PageTemplate.STACK_2 -> rows(c, g, 2)
            PageTemplate.AUTO -> rows(c, g, 2)
            PageTemplate.FOUR_KOMA -> rows(c, g, n.coerceIn(2, 4))
            PageTemplate.GRID_2X2 -> {
                val cw = (w - g) / 2f; val ch = (h - g) / 2f
                listOf(
                    RectF(c.left, c.top, c.left + cw, c.top + ch),
                    RectF(c.left + cw + g, c.top, c.right, c.top + ch),
                    RectF(c.left, c.top + ch + g, c.left + cw, c.bottom),
                    RectF(c.left + cw + g, c.top + ch + g, c.right, c.bottom)
                )
            }
            PageTemplate.ONE_PLUS_TWO -> {
                val cw = (w - g) / 2f; val ch = (h - g) / 2f
                listOf(
                    RectF(c.left, c.top, c.right, c.top + ch),
                    RectF(c.left, c.top + ch + g, c.left + cw, c.bottom),
                    RectF(c.left + cw + g, c.top + ch + g, c.right, c.bottom)
                )
            }
        }
    }

    /** Lề trong (gutter) tối thiểu KDP theo tổng số trang, đơn vị point. Xem ghi chú nguồn ở đầu file. */
    fun kdpGutterPt(pages: Int): Float = when {
        pages <= 150 -> 27f   // 0.375"  (đã xác nhận)
        pages <= 300 -> 36f   // 0.5"    (đã xác nhận — trang KDP chính thức, mục 247)
        pages <= 500 -> 45f   // 0.625"  (đã xác nhận)
        pages <= 700 -> 54f   // 0.75"   (đã xác nhận)
        else -> 63f           // 0.875"  (đã xác nhận cho 701–828 trang)
    }

    /** Vùng nội dung; pageNumber1 bắt đầu từ 1, trang lẻ = mặt phải (sách đọc trái -> phải). */
    fun contentRect(profile: PageProfile, pageNumber1: Int, totalPages: Int, rtl: Boolean = false): RectF {
        val w = profile.pageWidthPt; val h = profile.pageHeightPt
        if (!profile.kdp) return RectF(12f, 12f, w - 12f, h - 12f) // giữ lề 12 như exportPdf cũ
        val outside = if (profile.hasBleed) 27f else 18f           // 0.375" có bleed / 0.25" không
        val inside = kdpGutterPt(totalPages)
        // LTR: trang lẻ = trang phải. RTL (KDP G201857950): số chẵn ở trang phải, số lẻ ở trang trái.
        val rightHand = if (rtl) pageNumber1 % 2 == 0 else pageNumber1 % 2 == 1
        val left = if (rightHand) inside else outside
        val right = w - (if (rightHand) outside else inside)
        return RectF(left, outside, right, h - outside)
    }

    /** Đặt ảnh vừa khít trong ô, căn giữa, giữ tỉ lệ. */
    fun fitRect(cell: RectF, imgW: Int, imgH: Int): RectF {
        val s = min(cell.width() / imgW, cell.height() / imgH)
        val w = imgW * s; val h = imgH * s
        val cx = (cell.left + cell.right) / 2f; val cy = (cell.top + cell.bottom) / 2f
        return RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
    }
}

class PublishExporter(private val engine: ExportEngine) {

    private fun sanitize(raw: String): String {
        val cleaned = raw.trim()
            .replace(Regex("[/\\\\:*?\"<>|\\x00-\\x1F]"), "_")
            .replace(Regex("\\s+"), " ")
            .replace(Regex("_+"), "_")
            .trim('_', ' ', '.')
            .take(100)
        return cleaned.ifBlank { "chapter" }
    }

    private fun usable(panels: List<Panel>) =
        panels.filter { p -> (p.upscaledPath ?: p.imagePath)?.let { File(it).exists() } == true }

    fun exportPdf(
        panels: List<Panel>, outDir: File, title: String, fileBaseName: String,
        template: PageTemplate, profile: PageProfile, rtl: Boolean = false
    ): String {
        val ok = usable(panels)
        if (ok.isEmpty()) throw IllegalStateException("Không có panel nào có ảnh để xuất PDF")
        // mục 248: AUTO = mỗi trang một mẫu theo nhịp truyện; các mẫu khác = mọi trang cùng một mẫu như cũ.
        val plan: List<Pair<PageTemplate, List<Panel>>> =
            if (template == PageTemplate.AUTO) PageLayoutPlanner.planPanels(ok)
            else ok.chunked(template.panelsPerPage).map { template to it }
        val doc = PdfDocument()
        val frame = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.2f }
        val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        val gutter = if (profile.kdp) 9f else 8f

        plan.forEachIndexed { idx, (pageTemplate, chunk) ->
            val info = PdfDocument.PageInfo.Builder(profile.pageWidthPt.toInt(), profile.pageHeightPt.toInt(), idx + 1).create()
            val page = doc.startPage(info)
            val c = page.canvas
            c.drawColor(Color.WHITE)
            val content = PageLayout.contentRect(profile, idx + 1, plan.size, rtl)
            if (!profile.kdp && idx == 0) {
                c.drawText(title, 20f, 28f, Paint().apply {
                    color = Color.BLACK; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true
                })
                content.top += 30f
            }
            val cells = PageLayout.cells(pageTemplate, chunk.size, content, gutter, rtl)
            chunk.forEachIndexed { i, panel ->
                val cell = cells.getOrNull(i) ?: return@forEachIndexed
                val path = panel.upscaledPath ?: panel.imagePath ?: return@forEachIndexed
                val bmp = engine.renderPanelWithBubbles(path, panel.bubbles) ?: return@forEachIndexed
                val dst = PageLayout.fitRect(cell, bmp.width, bmp.height)
                c.drawBitmap(bmp, null, dst, bmpPaint)
                bmp.recycle()
                c.drawRect(dst, frame)
            }
            doc.finishPage(page)
        }

        val suffix = (if (profile != PageProfile.A4) "_${profile.name}" else "") +
            (if (template != PageTemplate.STACK_2) "_${template.name}" else "") +
            (if (rtl) "_RTL" else "")
        val out = File(outDir, "${sanitize(fileBaseName)}$suffix.pdf")
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
        return out.absolutePath
    }

    /** ZIP các ảnh JPEG 800px rộng, mỗi ảnh cao tối đa [maxSegmentHeightPx], mỗi ảnh <= ~2MB. */
    fun exportWebtoonZip(
        panels: List<Panel>, outDir: File, fileBaseName: String,
        widthPx: Int = 800, maxSegmentHeightPx: Int = 1280, gapPx: Int = 24
    ): String {
        val ok = usable(panels)
        if (ok.isEmpty()) throw IllegalStateException("Không có panel nào có ảnh để xuất Webtoon")
        val base = sanitize(fileBaseName)
        val out = File(outDir, "${base}_webtoon.zip")
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            val seg = Bitmap.createBitmap(widthPx, maxSegmentHeightPx, Bitmap.Config.ARGB_8888)
            val segCanvas = Canvas(seg)
            segCanvas.drawColor(Color.WHITE)
            var segY = 0
            var segIndex = 0

            fun flush(heightUsed: Int) {
                if (heightUsed <= 0) return
                segIndex++
                val part = if (heightUsed < maxSegmentHeightPx) Bitmap.createBitmap(seg, 0, 0, widthPx, heightUsed) else seg
                zip.putNextEntry(ZipEntry("%s_%03d.jpg".format(base, segIndex)))
                zip.write(compressUnder(part, 2_000_000))
                zip.closeEntry()
                if (part !== seg) part.recycle()
                segCanvas.drawColor(Color.WHITE)
                segY = 0
            }

            ok.forEach { panel ->
                val path = panel.upscaledPath ?: panel.imagePath ?: return@forEach
                val bmp = engine.renderPanelWithBubbles(path, panel.bubbles) ?: return@forEach
                val scaledH = (bmp.height * widthPx.toFloat() / bmp.width).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(bmp, widthPx, scaledH, true)
                if (scaled !== bmp) bmp.recycle()
                var srcY = 0
                while (srcY < scaledH) {
                    val take = min(maxSegmentHeightPx - segY, scaledH - srcY)
                    segCanvas.drawBitmap(scaled, Rect(0, srcY, widthPx, srcY + take), Rect(0, segY, widthPx, segY + take), null)
                    segY += take
                    srcY += take
                    if (segY >= maxSegmentHeightPx) flush(segY)
                }
                scaled.recycle()
                segY = min(segY + gapPx, maxSegmentHeightPx)
                if (segY >= maxSegmentHeightPx) flush(segY)
            }
            flush(segY)
            seg.recycle()
        }
        return out.absolutePath
    }

    private fun compressUnder(bmp: Bitmap, maxBytes: Int): ByteArray {
        var q = 92
        while (true) {
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, q, bos)
            val bytes = bos.toByteArray()
            if (bytes.size <= maxBytes || q <= 40) return bytes
            q -= 8
        }
    }

    /** JSON mô tả chương để người dùng tự điền khi tải lên nền tảng — chỉ chứa dữ liệu dự án THẬT có. */
    fun exportMetadata(chapter: Chapter, outDir: File, fileBaseName: String, extras: ExportExtras): String {
        val story = extras.story
        val map = linkedMapOf<String, Any?>(
            "tool" to "MangaLocal",
            "storyTitle" to (story?.title ?: ""),
            "synopsis" to (story?.description ?: ""),
            "chapterTitle" to chapter.title,
            "chapterNumber" to chapter.chapterNumber,
            "panelCount" to usable(chapter.panels).size,
            "characters" to (story?.characters?.map { it.name } ?: emptyList<String>()),
            "style" to chapter.style.name,
            "pdfProfile" to extras.pageProfile.name,
            "pdfTemplate" to extras.pageTemplate.name,
            "readingDirection" to (if (extras.rightToLeft) "rtl" else "ltr"),
            "exportedAtEpochMs" to System.currentTimeMillis()
        )
        val json = GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create().toJson(map)
        val out = File(outDir, "${sanitize(fileBaseName)}_metadata.json")
        out.writeText(json, Charsets.UTF_8)
        return out.absolutePath
    }
}
