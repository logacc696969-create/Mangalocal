package com.mangalocal.pipeline

import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

/** Kết quả một yêu cầu HTTP đã nhận được phản hồi (đọc hết thân). */
class HttpResult(val code: Int, val contentType: String?, val body: ByteArray)

/**
 * mục 266 TECHNICAL_STATUS.md — thực thi yêu cầu HTTP CÓ THỬ LẠI theo [HttpRetryPolicy] (phần quyết định đã kiểm thử bằng kotlinc ở tools/test_http_retry.py,
 * vòng lặp này kiểm hành vi ở tools/test_http_retry_exec.py với OkHttp giả có kịch bản). Dùng chung cho ExternalLlmClient (chữ + ảnh) và FreeImageClient.
 * Trước đây lỗi 429 của bậc miễn phí ném thẳng lên và nhiều nhánh gọi LLM nuốt lỗi bằng `catch`.
 *
 * Trả về: phản hồi 2xx, HOẶC phản hồi lỗi KHÔNG thử lại được (401/403/404/400...) để nơi gọi dựng thông báo riêng.
 * Ném RuntimeException (tiếng Việt) khi bỏ cuộc sau khi đáng thử lại (hết lượt, hết hạn mức ngày, Retry-After quá lâu, lỗi mạng).
 *
 * HAI biến thể dùng CHUNG một logic quyết định (attemptOnce/nextStep): [execute] chờ bằng `delay` (trong coroutine), [executeBlocking] chờ bằng Thread.sleep
 * cho mã không phải suspend (giám khảo VLM qua API gọi từ hàm thường — tránh `runBlocking`, vốn bị tools/test_face_identity.py cấm trong luồng suspend).
 * [build] được gọi MỖI lần thử (OkHttp không dùng lại được Request có thân một lần). [sleeper]/[jitter] tiêm được để test không phải chờ thật.
 */
object HttpRetryExec {
    private class Attempt(val code: Int, val contentType: String?, val retryAfter: String?, val bytes: ByteArray, val netMsg: String?)

    private sealed class Step {
        class Done(val result: HttpResult) : Step()
        class Wait(val delayMs: Long) : Step()
    }

    private fun attemptOnce(client: OkHttpClient, build: () -> Request): Attempt {
        var code = HttpRetryPolicy.NETWORK_ERROR
        var contentType: String? = null
        var retryAfter: String? = null
        var bytes = ByteArray(0)
        var netMsg: String? = null
        try {
            client.newCall(build()).execute().use { resp ->
                code = resp.code
                contentType = resp.header("Content-Type")
                retryAfter = resp.header("Retry-After")
                bytes = resp.body?.bytes() ?: ByteArray(0)
            }
        } catch (e: IOException) {
            code = HttpRetryPolicy.NETWORK_ERROR   // lỗi giữa chừng khi đọc thân (đã có mã) vẫn là lỗi mạng, KHÔNG được coi là thành công với thân rỗng
            netMsg = e.message ?: e.javaClass.simpleName
        }
        return Attempt(code, contentType, retryAfter, bytes, netMsg)
    }

    private fun nextStep(a: Attempt, attempt: Int, maxAttempts: Int, jitter: Double, onWait: (String) -> Unit): Step {
        if (a.code in 200..299) return Step.Done(HttpResult(a.code, a.contentType, a.bytes))
        val bodyText: String = a.netMsg ?: String(a.bytes, Charsets.UTF_8)
        return when (val decision = HttpRetryPolicy.decide(a.code, a.retryAfter, bodyText, attempt, maxAttempts, System.currentTimeMillis(), jitter)) {
            is HttpRetryPolicy.Decision.Retry -> {
                onWait(decision.reason)
                Step.Wait(decision.delayMs)
            }
            is HttpRetryPolicy.Decision.GiveUp -> {
                // lỗi vĩnh viễn (401/404...) -> trả về để nơi gọi dựng thông báo riêng; lỗi tạm thời đã hết cách -> ném
                if (!HttpRetryPolicy.isRetryable(a.code)) Step.Done(HttpResult(a.code, a.contentType, a.bytes))
                else throw RuntimeException(HttpRetryPolicy.failureMessage(a.code, bodyText) + " — " + decision.reason)
            }
        }
    }

    suspend fun execute(
        client: OkHttpClient,
        build: () -> Request,
        maxAttempts: Int = HttpRetryPolicy.DEFAULT_MAX_ATTEMPTS,
        onWait: (String) -> Unit = {},
        sleeper: suspend (Long) -> Unit = { delay(it) },
        jitter: () -> Double = { Math.random() }
    ): HttpResult {
        var attempt = 1
        while (true) {
            when (val step = nextStep(attemptOnce(client, build), attempt, maxAttempts, jitter(), onWait)) {
                is Step.Done -> return step.result
                is Step.Wait -> {
                    sleeper(step.delayMs)
                    attempt++
                }
            }
        }
    }

    /** Như [execute] nhưng chờ bằng Thread.sleep, gọi được từ hàm thường (không suspend). */
    fun executeBlocking(
        client: OkHttpClient,
        build: () -> Request,
        maxAttempts: Int = HttpRetryPolicy.DEFAULT_MAX_ATTEMPTS,
        onWait: (String) -> Unit = {},
        sleeper: (Long) -> Unit = { Thread.sleep(it) },
        jitter: () -> Double = { Math.random() }
    ): HttpResult {
        var attempt = 1
        while (true) {
            when (val step = nextStep(attemptOnce(client, build), attempt, maxAttempts, jitter(), onWait)) {
                is Step.Done -> return step.result
                is Step.Wait -> {
                    sleeper(step.delayMs)
                    attempt++
                }
            }
        }
    }
}
