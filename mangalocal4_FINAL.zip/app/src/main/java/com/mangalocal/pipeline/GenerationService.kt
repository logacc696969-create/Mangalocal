package com.mangalocal.pipeline

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.*
import androidx.core.app.NotificationCompat
import com.google.gson.Gson
import com.mangalocal.MainActivity
import com.mangalocal.model.Chapter
import com.mangalocal.model.GenerationSettings
import com.mangalocal.model.Story
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

// mục 77 TECHNICAL_STATUS.md — RAM Purge / WakeLock: bổ sung PARTIAL_WAKE_LOCK
// + WifiLock vào Foreground Service ĐÃ CÓ SẴN từ trước.
//
// mục 161 TECHNICAL_STATUS.md (đợt 8 — "#5 Multi-Process Isolation", đề
// xuất từ đợt audit PDF ngoài, mục 146/161). VIẾT LẠI HẲN — trước đây
// Service này chỉ giữ WakeLock/Notification, KHÔNG host pipeline thật
// (grep xác nhận `LocalBinder` KHÔNG được dùng ở đâu trong toàn dự án —
// `pipeline.runGeneration()` chạy THẲNG trong tiến trình UI qua
// `viewModelScope.launch` ở MainViewModel.kt, Service chỉ "sống cùng" nhờ
// `startForegroundService()` fire-and-forget). Giờ Service THẬT SỰ host
// `MangaPipeline` + chạy trong tiến trình riêng `:inference` (khai ở
// AndroidManifest.xml) — nếu native (JNI, MNN) crash, CHỈ tiến trình
// `:inference` chết, tiến trình UI (nhận `onServiceDisconnected` qua
// `ServiceConnection`) SỐNG, không văng app.
//
// GIỚI HẠN THẬT — CHƯA build-test, đây là thay đổi kiến trúc lớn nhất
// phiên này (xem TECHNICAL_STATUS.md mục 161 đợt 8 để biết đầy đủ). MỚI
// CHUYỂN được đường sinh 1 chương (`confirmRoutingAndGenerate()`,
// MainViewModel.kt) qua IPC — `runIndustrialBatch()` và các hàm khác của
// MangaPipeline (`regeneratePanel`, model download, cleanup...) VẪN chạy
// trong tiến trình UI như cũ, CHƯA chuyển — cố ý làm 1 đường ĐÚNG TRỌN
// VẸN trước, không làm nửa vời nhiều đường cùng lúc.
class GenerationService : Service() {
    private val CH = "manga_gen"
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val gson = Gson()

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // mục 161 (đợt 8) — GIỮ RIÊNG storyManager (không lấy qua
    // pipeline.storyManager — field đó `private` trong MangaPipeline,
    // đúng ý đồ đóng gói ban đầu) — khớp ĐÚNG khuôn mẫu MainViewModel.kt
    // đã dùng (tự giữ 1 bản `storyManager` + truyền vào constructor
    // MangaPipeline riêng), không phá encapsulation của MangaPipeline.
    private val storyManager: StoryManager by lazy { StoryManager(applicationContext) }
    private val pipeline: MangaPipeline by lazy {
        MangaPipeline(storyManager, ThermalMonitor(applicationContext), RuntimeOptimizer(applicationContext))
    }

    @Volatile private var activeRequestId: String? = null
    private var progressJob: Job? = null

    // mục 161 (đợt 8) — Messenger THAY cho LocalBinder cũ (đã xác nhận
    // KHÔNG ai dùng LocalBinder — an toàn đổi hẳn, không phá call site
    // nào). Handler chạy trên MAIN THREAD của tiến trình :inference (mặc
    // định của Messenger không truyền Looper riêng) — CHỈ làm việc nhẹ
    // (parse request, launch coroutine) trong handleMessage(), KHÔNG gọi
    // trực tiếp pipeline.runGeneration() (suspend, chạy lâu) ở đây — sẽ
    // block Binder thread/ANR.
    private val incomingHandler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            when (msg.what) {
                GenerationProtocol.MSG_RUN_GENERATION -> handleRunGeneration(msg)
                GenerationProtocol.MSG_CANCEL -> handleCancel()
                else -> super.handleMessage(msg)
            }
        }
    }
    private val messenger = Messenger(incomingHandler)

    override fun onCreate() { super.onCreate(); createChannel() }
    override fun onBind(i: Intent): IBinder = messenger.binder

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startForeground(1, buildNotif("Đang tạo truyện tranh..."))
        acquireLocks()
        return START_STICKY
    }

    private fun acquireLocks() {
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK, "MangaLocal::GenerationWakeLock"
            ).apply { acquire(12 * 60 * 60 * 1000L) } // tối đa 12h, phòng hờ batch cực dài
        }
        if (wifiLock == null) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(
                WifiManager.WIFI_MODE_FULL_HIGH_PERF, "MangaLocal::GenerationWifiLock"
            ).apply { acquire() }
        }
    }
    private fun releaseLocks() {
        wakeLock?.takeIf { it.isHeld }?.release(); wakeLock = null
        wifiLock?.takeIf { it.isHeld }?.release(); wifiLock = null
    }

    // mục 161 (đợt 8) — xử lý 1 lượt sinh chương qua IPC. `msg.replyTo`
    // (Messenger của client) dùng để gửi progress/kết quả/lỗi NGƯỢC lại —
    // cơ chế bidirectional CHUẨN của Messenger (không cần thêm AIDL
    // callback interface).
    private fun handleRunGeneration(msg: Message) {
        val replyTo = msg.replyTo
        val req = GenerationProtocol.parseRunGenerationMessage(msg)
        if (req == null || replyTo == null) return  // message hỏng — im lặng bỏ qua, không biết gửi lỗi đi đâu nếu replyTo null

        activeRequestId = req.requestId
        progressJob?.cancel()

        serviceScope.launch {
            try {
                // mục 161 (đợt 10) — ĐỌC story/chapter TỪ ĐĨA bằng ID (thay
                // vì Gson-deserialize từ JSON nhét trong Bundle) — xem lý do
                // đầy đủ (giới hạn Binder 1MB, Story.characters phình theo
                // quy mô nhiều chương) ở comment trong GenerationProtocol.kt.
                // 2 tiến trình dùng CHUNG file hệ thống vật lý (cùng 1 app,
                // cùng filesDir) — đọc file không qua Binder, không giới hạn
                // 1MB nào áp dụng. Client ĐÃ save chapter (dạng "prepared",
                // chưa sinh ảnh) ra đĩa TRƯỚC khi gửi request — xem
                // MainViewModel.runGenerationViaService().
                val story = storyManager.loadStory(req.storyId)
                    ?: throw IllegalStateException("Không tìm thấy Story id=${req.storyId} trên đĩa")
                val chapter = storyManager.loadChapter(req.storyId, req.chapterId)
                    ?: throw IllegalStateException("Không tìm thấy Chapter id=${req.chapterId} trên đĩa — client phải save() trước khi gửi request")
                val settings = gson.fromJson(req.settingsJson, GenerationSettings::class.java)

                // Relay pipeline.state (StateFlow) -> Messenger, CHỈ khi
                // requestId còn khớp (tránh gửi progress của lượt CŨ nếu có
                // lượt MỚI ghi đè activeRequestId giữa chừng).
                progressJob = pipeline.state.onEach { state ->
                    if (activeRequestId != req.requestId) return@onEach
                    try {
                        // mục 161 (đợt 10) — cắt `log` còn 50 dòng GẦN NHẤT
                        // trước khi serialize gửi qua Binder — list này
                        // KHÔNG có giới hạn ở tầng MangaPipeline (phát triển
                        // không giới hạn suốt 1 lượt sinh chương, an toàn khi
                        // còn là tham chiếu trong-process, nhưng qua IPC mỗi
                        // tick progress lại copy TOÀN BỘ list — phát triển
                        // O(n²) theo thời gian nếu không cắt). CHỈ cắt bản
                        // gửi qua Binder — KHÔNG đổi `_state` gốc dùng bởi
                        // đường in-process (regeneratePanel/industrial batch
                        // khi chưa tách IPC) vẫn cần đủ log như cũ.
                        val trimmed = if (state.log.size > 50) state.copy(log = state.log.takeLast(50)) else state
                        replyTo.send(GenerationProtocol.buildProgressMessage(req.requestId, gson.toJson(trimmed)))
                    } catch (e: DeadObjectException) {
                        // Client (tiến trình UI) đã biến mất/unbind — không có
                        // gì để làm ở đây, dừng ở catch ngoài bên dưới
                        // (pipeline vẫn chạy tới cùng, không huỷ giữa chừng —
                        // tránh mất công đã sinh; kết quả LƯU vào đĩa qua
                        // StoryManager dù không ai nhận được message nữa).
                    }
                }.launchIn(serviceScope)

                val result = pipeline.runGeneration(story, chapter, settings)
                storyManager.saveChapter(result)

                if (activeRequestId == req.requestId) {
                    // mục 161 (đợt 10) — gửi lại ĐÚNG chapterId (đã save ở
                    // dòng trên) thay vì nguyên JSON — client tự
                    // storyManager.loadChapter() đọc lại bản mới nhất từ
                    // đĩa, tránh gửi lại toàn bộ Chapter (nhiều panel) qua
                    // Binder lần thứ 2.
                    replyTo.send(GenerationProtocol.buildResultMessage(req.requestId, result.id))
                }

                // mục 161 TECHNICAL_STATUS.md (đợt 9) — SỬA LỖI phát hiện
                // ngay khi rà lại đợt này: TRƯỚC KHI có dòng này,
                // `purgeEnginesBetweenChapters()`/`System.gc()` phía
                // MainViewModel.runIndustrialBatch() gọi vào INSTANCE
                // MangaPipeline của TIẾN TRÌNH UI (rỗng, không tải model
                // gì) — hoàn toàn KHÔNG có tác dụng dọn RAM native thật
                // (native context/session THẬT nằm ở đây, tiến trình
                // :inference). Giờ purge ĐÚNG CHỖ — chỉ khi
                // `purgeAfter=true` (client set khi CÒN chương tiếp theo
                // trong batch, khớp đúng điều kiện gốc `done < chapters.size`
                // đã có trước khi tách IPC).
                if (req.purgeAfter) {
                    pipeline.purgeEnginesBetweenChapters()
                    System.gc()
                    Runtime.getRuntime().gc()
                }
            } catch (e: Exception) {
                if (activeRequestId == req.requestId) {
                    try {
                        replyTo.send(GenerationProtocol.buildErrorMessage(req.requestId, e.message ?: e.javaClass.simpleName))
                    } catch (_: DeadObjectException) { /* client đã mất, không gửi được cũng không sao */ }
                }
            } finally {
                progressJob?.cancel()
                if (activeRequestId == req.requestId) activeRequestId = null
            }
        }
    }

    private fun handleCancel() {
        // mục 83 TECHNICAL_STATUS.md — cancelSafely() đã có sẵn trên
        // MangaPipeline, xử lý đúng việc JNI blocking không cooperative-
        // cancellable. Gọi lại đúng cơ chế đó thay vì tự phát minh mới.
        serviceScope.launch { pipeline.cancelSafely() }
    }

    override fun onDestroy() {
        progressJob?.cancel()
        serviceScope.cancel()
        releaseLocks()
        super.onDestroy()
    }

    private fun buildNotif(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH)
            .setContentTitle("MangaLocal").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentIntent(pi).setOngoing(true).build()
    }

    private fun createChannel() {
        NotificationChannel(CH, "Tạo truyện", NotificationManager.IMPORTANCE_LOW)
            .also { getSystemService(NotificationManager::class.java).createNotificationChannel(it) }
    }
}
