package com.mangalocal.pipeline

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Binder
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.mangalocal.MainActivity

// mục 77 TECHNICAL_STATUS.md — RAM Purge / WakeLock: bổ sung PARTIAL_WAKE_LOCK
// + WifiLock vào Foreground Service ĐÃ CÓ SẴN từ trước (không tạo service
// mới — service này đã khai báo đúng trong AndroidManifest.xml với đủ
// foregroundServiceType="dataSync", chỉ CHƯA có WakeLock/WifiLock và CHƯA
// được bind/gọi từ MainViewModel.runIndustrialBatch() — 2 gap thật, xử lý
// cả 2 ở đây + MainViewModel.kt).
class GenerationService : Service() {
    inner class LocalBinder : Binder() { fun get() = this@GenerationService }
    private val binder = LocalBinder()
    private val CH = "manga_gen"
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onCreate() { super.onCreate(); createChannel() }
    override fun onBind(i: Intent): IBinder = binder
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startForeground(1, buildNotif("Đang tạo truyện tranh..."))

        // PARTIAL_WAKE_LOCK — ngăn CPU ngủ giữa chừng batch công nghiệp khi
        // màn hình tắt (mục 77). Không dùng SCREEN_DIM/SCREEN_BRIGHT — chỉ
        // cần CPU chạy, không cần màn hình sáng (tiết kiệm pin hơn).
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK, "MangaLocal::GenerationWakeLock"
            ).apply { acquire(12 * 60 * 60 * 1000L) } // tối đa 12h, phòng hờ batch cực dài
        }
        // WifiLock — ngăn WiFi bị hệ thống tắt khi màn hình tắt lâu (quan
        // trọng cho luồng Remote GPU — BackendRouter/RemoteGenerationClient
        // cần WiFi sống xuyên suốt batch).
        if (wifiLock == null) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(
                WifiManager.WIFI_MODE_FULL_HIGH_PERF, "MangaLocal::GenerationWifiLock"
            ).apply { acquire() }
        }
        return START_STICKY
    }

    fun update(text: String) = getSystemService(NotificationManager::class.java).notify(1, buildNotif(text))
    fun stop() {
        wakeLock?.takeIf { it.isHeld }?.release(); wakeLock = null
        wifiLock?.takeIf { it.isHeld }?.release(); wifiLock = null
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onDestroy() {
        wakeLock?.takeIf { it.isHeld }?.release()
        wifiLock?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    private fun buildNotif(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH)
            .setContentTitle("MangaLocal").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentIntent(pi).setOngoing(true).build()
    }

    private fun createChannel() {
        NotificationChannel(CH, "Tạo truyện", NotificationManager.IMPORTANCE_LOW)
            .also { getSystemService(NotificationManager::class.java).createNotificationChannel(it) }
    }
}
