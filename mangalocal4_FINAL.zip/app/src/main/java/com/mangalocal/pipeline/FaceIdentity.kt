package com.mangalocal.pipeline

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sqrt

/**
 * mục 246 TECHNICAL_STATUS.md — "CỔNG DANH TÍNH": đo khuôn mặt sau khi vẽ lại/đổi biểu cảm có còn là cùng một người không.
 *
 * Cộng đồng đo giữ danh tính bằng COSINE giữa embedding nhận dạng khuôn mặt (ArcFace; PuLID dùng CurricularFace) của khuôn mặt gốc và khuôn mặt
 * sinh ra, SAU KHI căn chỉnh 5 điểm về khuôn 112×112 — PuLID/InstantID/IP-Adapter FaceID đều báo thước đo này (Face Sim ~0.5–0.7 là mức tốt trên
 * SDXL; một bài loại ảnh dưới 0.6 là thất bại danh tính). Bảng điểm đích `arcface_dst` lấy từ insightface/utils/face_align.py.
 *
 * Dự án chỉ có 2 điểm mắt từ khung xương (không có miệng) nên căn chỉnh bằng phép biến đổi đồng dạng đúng-2-điểm (xoay + tỉ lệ + tịnh tiến) về
 * hai mắt của khuôn mẫu; chuẩn là 5 điểm nên căn chỉnh này kém chính xác hơn — hệ quả: điểm giống có thể thấp hơn thực tế một chút.
 *
 * GIỚI HẠN THẬT:
 * - ArcFace huấn luyện trên ảnh THẬT: với nhân vật phong cách anime/tranh vẽ điểm không tin cậy. Với mục tiêu ảnh siêu thực thì phù hợp.
 * - Đổi biểu cảm vốn làm điểm giảm (bài "Turn That Frown Upside Down": Face Sim không phù hợp khi biểu cảm thay đổi) — nên ngưỡng phải rộng hơn
 *   so với kiểm tra "cùng ảnh"; ngưỡng mặc định 0.5 là ƯỚC LƯỢNG chưa hiệu chỉnh — luôn ghi log điểm đo để bạn tự chỉnh.
 * - Cần `arcface_mbf.mnn` (bước CI tuỳ chọn); thiếu model thì cổng tự bỏ qua. Chưa build-test.
 */
object FaceIdentity {
    /** Hai điểm mắt của khuôn mẫu ArcFace 112×112 (insightface arcface_dst, điểm 0 và 1): mắt ở bên TRÁI ảnh trước, rồi mắt bên phải. */
    const val DST_EYE1_X = 38.2946f; const val DST_EYE1_Y = 51.6963f
    const val DST_EYE2_X = 73.5318f; const val DST_EYE2_Y = 51.5014f
    const val SIZE = 112

    /**
     * Ma trận đồng dạng 2×3 [a, -b, tx, b, a, ty] đưa mắt1 → DST_EYE1 và mắt2 → DST_EYE2 (đúng tuyệt đối cho cả hai điểm).
     * (x1,y1) là mắt xuất hiện bên TRÁI ảnh (khớp OpenPose 14 khi nhìn chính diện), (x2,y2) là mắt bên phải. Trả null nếu hai mắt trùng nhau.
     */
    fun similarityFromEyes(x1: Float, y1: Float, x2: Float, y2: Float): FloatArray? {
        val vx = x2 - x1; val vy = y2 - y1
        val n2 = vx * vx + vy * vy
        if (n2 < 1e-6f) return null
        val dx = DST_EYE2_X - DST_EYE1_X; val dy = DST_EYE2_Y - DST_EYE1_Y
        // z = v_d / v_s (chia số phức)
        val a = (dx * vx + dy * vy) / n2
        val b = (dy * vx - dx * vy) / n2
        val tx = DST_EYE1_X - (a * x1 - b * y1)
        val ty = DST_EYE1_Y - (b * x1 + a * y1)
        return floatArrayOf(a, -b, tx, b, a, ty)
    }

    fun cosine(a: FloatArray, b: FloatArray): Float {
        if (a.isEmpty() || a.size != b.size) return Float.NaN
        var dot = 0.0; var na = 0.0; var nb = 0.0
        for (i in a.indices) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        if (na < 1e-12 || nb < 1e-12) return Float.NaN
        return (dot / (sqrt(na) * sqrt(nb))).toFloat()
    }
}

/** Đo độ giống danh tính giữa hai ảnh cùng kích thước/cùng bố cục tại cùng vị trí mắt. */
class FaceIdentityGuard(private val storyManager: StoryManager) {
    private val ctx: Long = try {
        if (storyManager.hasArcFace()) NativeBridge.arcfaceInit(storyManager.yoloDir.absolutePath) else 0L
    } catch (e: Throwable) { 0L } // UnsatisfiedLinkError là Error

    fun isReady() = ctx != 0L

    /**
     * Embedding của khuôn mặt trong [imagePath] tại hai mắt (toạ độ CHUẨN HOÁ 0..1 của ảnh đó): mắt bên trái ảnh ([ex1],[ey1]) rồi mắt bên phải.
     * Null khi lỗi. [tmpDir] chứa ảnh 112×112 tạm.
     */
    fun embedding(imagePath: String, ex1: Float, ey1: Float, ex2: Float, ey2: Float, tmpDir: File): FloatArray? {
        if (ctx == 0L) return null
        var src: Bitmap? = null
        var aligned: Bitmap? = null
        val tmp = File(tmpDir, "arcface_in_${System.nanoTime()}.png")
        return try {
            src = BitmapFactory.decodeFile(imagePath) ?: return null
            val m = FaceIdentity.similarityFromEyes(ex1 * src.width, ey1 * src.height, ex2 * src.width, ey2 * src.height) ?: return null
            val matrix = Matrix().apply { setValues(floatArrayOf(m[0], m[1], m[2], m[3], m[4], m[5], 0f, 0f, 1f)) }
            aligned = Bitmap.createBitmap(FaceIdentity.SIZE, FaceIdentity.SIZE, Bitmap.Config.ARGB_8888)
            Canvas(aligned).apply { drawColor(android.graphics.Color.BLACK); drawBitmap(src, matrix, Paint(Paint.FILTER_BITMAP_FLAG)) }
            FileOutputStream(tmp).use { aligned.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val e = NativeBridge.arcfaceEmbed(ctx, tmp.absolutePath)
            if (e.size == 512) e else null
        } catch (e: Throwable) { null } finally {
            src?.recycle(); aligned?.recycle(); tmp.delete()
        }
    }

    /** Cosine giữa khuôn mặt ở [pathA] và [pathB] (cùng vị trí mắt chuẩn hoá). Null khi không đo được. */
    fun similarity(pathA: String, pathB: String, ex1: Float, ey1: Float, ex2: Float, ey2: Float, tmpDir: File): Float? {
        val a = embedding(pathA, ex1, ey1, ex2, ey2, tmpDir) ?: return null
        val b = embedding(pathB, ex1, ey1, ex2, ey2, tmpDir) ?: return null
        return FaceIdentity.cosine(a, b).takeIf { !it.isNaN() }
    }

    fun close() { if (ctx != 0L) try { NativeBridge.arcfaceFree(ctx) } catch (e: Throwable) { } }
}
