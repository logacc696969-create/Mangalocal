package com.mangalocal.pipeline

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import com.mangalocal.model.Panel
import com.mangalocal.model.GenerationSettings
import java.io.File
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Hệ thống Tự động Gác cổng chất lượng (First Gate Quality Analytics) — mục 74
 * TECHNICAL_STATUS.md.
 *
 * Thay thế đôi mắt người dùng bằng bộ lọc tự động ngay sau khi ảnh gốc
 * (Txt2Img) được sinh ra, TRƯỚC khi đưa vào upscale hay lưu trữ:
 *
 *  1. Dùng lại ĐÚNG kết quả YOLOv8-pose đã detect sẵn (FaceHandDetector suy
 *     từ pose keypoint — mục 20) — KHÔNG chạy inference lần 2, không tốn thêm
 *     tài nguyên.
 *  2. Tự động đếm chi (tay/chân) theo convention OpenPose COCO-18: mỗi người
 *     có đúng 2 tay (cổ tay 7+4) + 2 chân (mắt cá 10+13). Nếu phát hiện số
 *     chi bất thường vượt ngưỡng → IS_DEFECTIVE.
 *  3. Tự động đo khoảng cách Euclidean giữa khớp liền kề (vai–khuỷu–cổ tay,
 *     hông–gối–mắt cá). Nếu tỷ lệ co giãn vượt 3.0x đơn vị tham chiếu vai-
 *     hông → xương dị thường → IS_DEFECTIVE.
 *  4. Kết quả: IS_DEFECTIVE → MangaPipeline tự tăng seed và gọi lại UNet tối
 *     đa MAX_RETRY lần (mặc định 3). Người dùng KHÔNG nhìn thấy ảnh lỗi.
 *
 * GIỚI HẠN THẬT (nói rõ, không phóng đại):
 *  - Phát hiện chi dư dựa trên SKELETON 2D: nếu chi bị ẩn hoàn toàn (occlusion
 *    thật trong ảnh) mà pose model vẫn ảo giác ra keypoint (lỗi MediaPipe đã
 *    ghi ở mục 18), counter có thể đếm sai. Ngưỡng 3.0x là kinh nghiệm (mục
 *    19 dự án cũng dùng ngưỡng này), không phải số liệu khoa học chính xác.
 *  - MAX_RETRY=3: sau 3 lần vẫn fail → chấp nhận ảnh tốt nhất trong 3 lần
 *    (ít lỗi nhất theo score) thay vì block vô hạn.
 *  - CHƯA BUILD-TEST lần nào — như mọi phần Kotlin mới của dự án.
 */
class QualityGateChecker {

    companion object {
        const val MAX_RETRY = 3
        // Ngưỡng tỷ lệ xương: nếu đoạn xương > REF_SEGMENT_RATIO × đoạn vai-hông
        // thì coi là bất thường. 3.0x = giữ nguyên ngưỡng đã dùng ở mục 19.
        const val BONE_LENGTH_RATIO_THRESHOLD = 3.0f
        // Ngưỡng số chi VÃO VƯỢT so với tổng người × 2 (mỗi người có đúng 2 tay
        // và 2 chân). VD: 2 người → expect 4 tay + 4 chân = 8 chi; nếu phát hiện
        // ≥9 chi khả năng → flagged.
        const val EXTRA_LIMB_THRESHOLD = 1
    }

    data class QualityReport(
        val passed: Boolean,
        val defectScore: Float, // 0 = hoàn hảo, cao hơn = nhiều lỗi hơn
        val reasons: List<String>
    )

    // OpenPose COCO-18 indices dùng xuyên suốt dự án (khớp ip_adapter.cpp kBonePairs)
    // Người thứ i trong skeleton data: person[i].joints = FloatArray[18*4] (x,y,conf,vis)
    private val WRIST_INDICES  = listOf(7, 4)   // right wrist, left wrist
    private val ANKLE_INDICES  = listOf(10, 13) // right ankle, left ankle
    private val SHOULDER_INDICES = listOf(2, 5) // right shoulder, left shoulder
    private val HIP_INDICES    = listOf(8, 11)  // right hip, left hip
    private val ELBOW_INDICES  = listOf(6, 3)   // right elbow, left elbow
    private val KNEE_INDICES   = listOf(9, 12)  // right knee, left knee

    /**
     * Đánh giá chất lượng giải phẫu dựa trên [skeletonData] đã retarget (FloatArray
     * phẳng theo đúng format MangaPipeline.resolveSkeletonData() trả về).
     *
     * [numExpectedPersons] = số nhân vật LLM dự kiến trong panel này.
     */
    fun evaluate(skeletonData: FloatArray, numExpectedPersons: Int): QualityReport {
        if (skeletonData.isEmpty()) return QualityReport(true, 0f, emptyList())

        val valuesPerJoint = 4 // x, y, conf, vis
        val jointsPerPerson = 18
        val floatsPerPerson = jointsPerPerson * valuesPerJoint
        val numPersonsDetected = skeletonData.size / floatsPerPerson

        val reasons = mutableListOf<String>()
        var defectScore = 0f

        // ── 1. Kiểm tra số người detect được vs. kỳ vọng ──────────────────────
        if (numPersonsDetected > numExpectedPersons + 1) {
            reasons += "Phát hiện $numPersonsDetected người (kỳ vọng $numExpectedPersons) — có thể thừa nhân vật phụ"
            defectScore += (numPersonsDetected - numExpectedPersons) * 0.3f
        }

        // ── 2. Đếm chi VÀ kiểm tra tỷ lệ xương cho từng người ────────────────
        var totalVisibleWrists = 0
        var totalVisibleAnkles = 0

        for (personIdx in 0 until minOf(numPersonsDetected, numExpectedPersons + 1)) {
            val base = personIdx * floatsPerPerson
            val joints = Array(jointsPerPerson) { ji ->
                Triple(
                    skeletonData[base + ji * valuesPerJoint],     // x
                    skeletonData[base + ji * valuesPerJoint + 1], // y
                    skeletonData[base + ji * valuesPerJoint + 2]  // conf
                )
            }

            // Đếm chi visible (conf > 0.3)
            val visibleWrists = WRIST_INDICES.count { joints[it].third > 0.3f }
            val visibleAnkles = ANKLE_INDICES.count { joints[it].third > 0.3f }
            totalVisibleWrists += visibleWrists
            totalVisibleAnkles += visibleAnkles

            // Tham chiếu vai-hông để đánh giá tỷ lệ xương
            val refSegLen = segmentLength(
                joints[SHOULDER_INDICES[0]], joints[HIP_INDICES[0]],
                joints[SHOULDER_INDICES[1]], joints[HIP_INDICES[1]]
            )

            if (refSegLen > 0.01f) {
                // Kiểm tra cẳng tay: vai→khuỷu và khuỷu→cổ tay
                for (side in 0..1) {
                    val sLen = segLen(joints[SHOULDER_INDICES[side]], joints[ELBOW_INDICES[side]])
                    val fLen = segLen(joints[ELBOW_INDICES[side]], joints[WRIST_INDICES[side]])
                    if (sLen / refSegLen > BONE_LENGTH_RATIO_THRESHOLD) {
                        reasons += "Người ${personIdx+1}: cánh tay ${if(side==0) "phải" else "trái"} dài bất thường (×${"%.1f".format(sLen/refSegLen)} tham chiếu)"
                        defectScore += 0.5f
                    }
                    if (fLen / refSegLen > BONE_LENGTH_RATIO_THRESHOLD) {
                        reasons += "Người ${personIdx+1}: cẳng tay ${if(side==0) "phải" else "trái"} dài bất thường"
                        defectScore += 0.5f
                    }
                }
                // Kiểm tra chân
                for (side in 0..1) {
                    val thighLen = segLen(joints[HIP_INDICES[side]], joints[KNEE_INDICES[side]])
                    val shinLen  = segLen(joints[KNEE_INDICES[side]], joints[ANKLE_INDICES[side]])
                    if (thighLen / refSegLen > BONE_LENGTH_RATIO_THRESHOLD) {
                        reasons += "Người ${personIdx+1}: đùi ${if(side==0) "phải" else "trái"} dài bất thường"
                        defectScore += 0.5f
                    }
                    if (shinLen / refSegLen > BONE_LENGTH_RATIO_THRESHOLD) {
                        reasons += "Người ${personIdx+1}: cẳng chân dài bất thường"
                        defectScore += 0.3f
                    }
                }
            }
        }

        // ── 3. Kiểm tra số chi tổng thể ────────────────────────────────────────
        val expectedWrists = numExpectedPersons * 2
        val expectedAnkles = numExpectedPersons * 2
        if (totalVisibleWrists > expectedWrists + EXTRA_LIMB_THRESHOLD) {
            reasons += "Phát hiện $totalVisibleWrists cổ tay (kỳ vọng $expectedWrists) — có thể thừa tay"
            defectScore += (totalVisibleWrists - expectedWrists) * 0.6f
        }
        if (totalVisibleAnkles > expectedAnkles + EXTRA_LIMB_THRESHOLD) {
            reasons += "Phát hiện $totalVisibleAnkles mắt cá chân (kỳ vọng $expectedAnkles) — có thể thừa chân"
            defectScore += (totalVisibleAnkles - expectedAnkles) * 0.6f
        }

        return QualityReport(
            passed = defectScore < 1.0f,
            defectScore = defectScore,
            reasons = reasons
        )
    }

    // Độ dài đoạn thẳng giữa 2 khớp, dùng giá trị trung bình của 2 bên (left/right)
    // khi cả 2 đều đủ tự tin (>0.3); nếu 1 bên thiếu thì chỉ dùng bên còn lại.
    private fun segmentLength(
        a1: Triple<Float,Float,Float>, b1: Triple<Float,Float,Float>,
        a2: Triple<Float,Float,Float>, b2: Triple<Float,Float,Float>
    ): Float {
        val l1 = if (a1.third > 0.3f && b1.third > 0.3f) segLen(a1, b1) else -1f
        val l2 = if (a2.third > 0.3f && b2.third > 0.3f) segLen(a2, b2) else -1f
        return when {
            l1 >= 0f && l2 >= 0f -> (l1 + l2) / 2f
            l1 >= 0f -> l1
            l2 >= 0f -> l2
            else -> 0f
        }
    }

    private fun segLen(a: Triple<Float,Float,Float>, b: Triple<Float,Float,Float>): Float {
        val dx = b.first - a.first; val dy = b.second - a.second
        return sqrt(dx*dx + dy*dy)
    }
}
