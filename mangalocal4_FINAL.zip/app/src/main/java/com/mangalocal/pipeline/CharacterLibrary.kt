package com.mangalocal.pipeline

import com.google.gson.GsonBuilder
import com.mangalocal.model.BoneProportions
import com.mangalocal.model.Character
import com.mangalocal.model.CharacterRole
import java.io.File
import java.text.Normalizer
import java.util.UUID

/**
 * mục 248 TECHNICAL_STATUS.md — THƯ VIỆN NHÂN VẬT TOÀN CỤC (Character Memory): lưu một nhân vật ra thư mục dùng chung của
 * ứng dụng rồi nhập vào truyện khác, để cùng một người giữ nguyên ngoại hình xuyên truyện (kiểu "character memory" của
 * MythForge — tra cứu từ PDF; ở đây KHÔNG dùng LlamaIndex/embedding, chỉ là hồ sơ + ảnh neo).
 *
 * Lưu gì: tên, anchor prompt, negative prompt, seed, vai trò, LoRA + trọng số, embedding + từ kích hoạt, tỉ lệ xương,
 * ảnh anchor, ảnh anchor "rách", ảnh anchor theo biểu cảm. Mỗi nhân vật = một thư mục `character_library/<slug>/` gồm
 * `character.json` + các ảnh (sao chép, không tham chiếu — xoá truyện gốc không làm mất mục thư viện).
 *
 * KHÔNG lưu: id (nhập vào là id MỚI), các phiên bản anchor theo chương (gắn với chương của truyện gốc), file LoRA/embedding
 * (chỉ ghi ĐƯỜNG DẪN — cùng thiết bị mới còn đúng; nhập vào máy khác/đã xoá file thì bỏ trường đó và vẫn nhập phần còn lại).
 *
 * GIỚI HẠN THẬT: CHƯA build-test, chưa thử trên thiết bị; không có giao diện đổi tên/sửa mục thư viện (nhập rồi sửa trong truyện).
 */
object CharacterLibrary {

    const val SCHEMA = 1
    const val FILE = "character.json"

    data class Entry(val dirName: String, val name: String, val role: String, val hasAnchor: Boolean, val savedAt: Long)

    private class Stored(
        val schema: Int = SCHEMA,
        val savedAt: Long = 0L,
        val name: String = "",
        val anchorPrompt: String = "",
        val negativePrompt: String = "",
        val seed: Long = 0L,
        val role: String = CharacterRole.MAIN.name,
        val loraPath: String? = null,
        val loraWeight: Float = 0.75f,
        val embeddingPath: String? = null,
        val embeddingTrigger: String? = null,
        val boneProportions: BoneProportions = BoneProportions(),
        val anchorFile: String? = null,
        val tornFile: String? = null,
        val expressionFiles: Map<String, String> = emptyMap()
    )

    private val gson = GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create()

    fun libraryDir(appContext: android.content.Context): File = File(appContext.filesDir, "character_library")

    /** Tên thư mục an toàn: bỏ dấu tiếng Việt, chữ thường, ký tự lạ -> "_", tối đa 40 ký tự; rỗng -> "nhan_vat". */
    fun slug(name: String): String {
        val d = Normalizer.normalize(name.trim().replace('đ', 'd').replace('Đ', 'D'), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        val s = d.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(40).trim('_')
        return s.ifEmpty { "nhan_vat" }
    }

    /** Tên thư mục chưa trùng: slug, slug_2, slug_3... */
    fun uniqueDirName(name: String, existing: Set<String>): String {
        val base = slug(name)
        if (base !in existing) return base
        var n = 2
        while ("${base}_$n" in existing) n++
        return "${base}_$n"
    }

    /** Tên nhân vật chưa trùng trong truyện (không phân biệt hoa/thường): "An", "An (2)", "An (3)"... */
    fun uniqueCharacterName(name: String, existing: Set<String>): String {
        val taken = existing.map { it.trim().lowercase() }.toSet()
        val base = name.trim().ifEmpty { "Nhân vật" }
        if (base.lowercase() !in taken) return base
        var n = 2
        while ("$base ($n)".lowercase() in taken) n++
        return "$base ($n)"
    }

    /** Khoá biểu cảm -> phần tên file an toàn. */
    fun safeKey(key: String): String = key.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').ifEmpty { "x" }

    private fun ext(path: String): String = File(path).extension.lowercase().takeIf { it in setOf("png", "jpg", "jpeg", "webp") } ?: "png"

    /** Lưu nhân vật vào thư viện; trả về mục mới hoặc null nếu không ghi được. */
    fun export(libDir: File, c: Character, now: Long = System.currentTimeMillis()): Entry? = try {
        libDir.mkdirs()
        val dirName = uniqueDirName(c.name, libDir.list()?.toSet() ?: emptySet())
        val dir = File(libDir, dirName)
        dir.mkdirs()
        fun copyIn(src: String?, dest: String): String? {
            if (src.isNullOrBlank()) return null
            val f = File(src)
            if (!f.isFile) return null
            f.copyTo(File(dir, dest), overwrite = true)
            return dest
        }
        val anchor = c.anchorImagePath?.let { copyIn(it, "anchor.${ext(it)}") }
        val torn = c.tornAnchorImagePath?.let { copyIn(it, "torn.${ext(it)}") }
        val expr = LinkedHashMap<String, String>()
        c.expressionAnchors?.forEach { (k, v) -> copyIn(v, "expr_${safeKey(k)}.${ext(v)}")?.let { expr[k] = it } }
        val stored = Stored(
            savedAt = now, name = c.name, anchorPrompt = c.anchorPrompt, negativePrompt = c.negativePrompt, seed = c.seed,
            role = c.role.name, loraPath = c.loraPath, loraWeight = c.loraWeight,
            embeddingPath = c.embeddingPath, embeddingTrigger = c.embeddingTrigger, boneProportions = c.boneProportions,
            anchorFile = anchor, tornFile = torn, expressionFiles = expr
        )
        File(dir, FILE).writeText(gson.toJson(stored), Charsets.UTF_8)
        Entry(dirName, c.name, c.role.name, anchor != null, now)
    } catch (e: Exception) {
        null
    }

    private fun read(dir: File): Stored? = try {
        val f = File(dir, FILE)
        if (!f.isFile) null else gson.fromJson(f.readText(Charsets.UTF_8), Stored::class.java)?.takeIf { it.name.isNotBlank() }
    } catch (e: Exception) {
        null
    }

    /** Các mục trong thư viện, mới lưu trước. */
    fun list(libDir: File): List<Entry> =
        (libDir.listFiles()?.filter { it.isDirectory } ?: emptyList()).mapNotNull { d ->
            read(d)?.let { Entry(d.name, it.name, it.role, it.anchorFile != null && File(d, it.anchorFile).isFile, it.savedAt) }
        }.sortedByDescending { it.savedAt }

    /**
     * Đọc một mục và dựng `Character` MỚI (id mới, tên không trùng với [existingNames]); ảnh được sao chép vào [anchorsDir].
     * Caller tự `saveCharacter`. Trả null nếu không đọc được. File LoRA/embedding không còn tồn tại -> bỏ trường đó.
     */
    fun importFrom(libDir: File, dirName: String, existingNames: Set<String>, anchorsDir: File): Character? {
        val dir = File(libDir, dirName)
        val s = read(dir) ?: return null
        val id = UUID.randomUUID().toString()
        anchorsDir.mkdirs()
        fun copyOut(rel: String?, tag: String): String? {
            if (rel.isNullOrBlank()) return null
            val src = File(dir, rel)
            if (!src.isFile) return null
            val dst = File(anchorsDir, "${id}_$tag.${ext(rel)}")
            src.copyTo(dst, overwrite = true)
            return dst.absolutePath
        }
        val expr = LinkedHashMap<String, String>()
        s.expressionFiles.forEach { (k, rel) -> copyOut(rel, "expr_${safeKey(k)}")?.let { expr[k] = it } }
        return Character(
            id = id,
            name = uniqueCharacterName(s.name, existingNames),
            anchorPrompt = s.anchorPrompt,
            negativePrompt = s.negativePrompt,
            seed = s.seed,
            role = runCatching { CharacterRole.valueOf(s.role) }.getOrDefault(CharacterRole.MAIN),
            loraPath = s.loraPath?.takeIf { File(it).isFile },
            loraWeight = s.loraWeight,
            anchorImagePath = copyOut(s.anchorFile, "anchor"),
            tornAnchorImagePath = copyOut(s.tornFile, "torn"),
            expressionAnchors = expr.takeIf { it.isNotEmpty() },
            embeddingPath = s.embeddingPath?.takeIf { File(it).isFile },
            embeddingTrigger = s.embeddingTrigger,
            boneProportions = s.boneProportions
        )
    }

    fun delete(libDir: File, dirName: String): Boolean {
        val d = File(libDir, dirName)
        // chỉ xoá thư mục con trực tiếp của thư viện (chống tên chứa "../")
        return d.parentFile?.canonicalPath == libDir.canonicalPath && d.isDirectory && d.deleteRecursively()
    }
}
