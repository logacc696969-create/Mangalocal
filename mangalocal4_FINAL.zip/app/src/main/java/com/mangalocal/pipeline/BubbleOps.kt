package com.mangalocal.pipeline

import com.mangalocal.model.Bubble

/**
 * mục 249 TECHNICAL_STATUS.md — thao tác THUẦN cho màn sửa bubble: bật/tắt đuôi, kéo đích đuôi, đổi thứ tự lớp.
 * Tách khỏi Compose để kiểm thử riêng (tools/test_bubble_ops.py).
 *
 * "Lớp" (z-order) = thứ tự trong danh sách: bộ vẽ khi xuất (ExportEngine/PublishExporter) duyệt `bubbles.forEach`, nên phần tử
 * ĐỨNG SAU được vẽ SAU = nằm TRÊN. Không thêm trường zIndex mới (bubble đã lưu cũ vẫn đọc đúng).
 *
 * GIỚI HẠN THẬT: chưa có chọn font/cỡ chữ (bộ vẽ tự co chữ theo khung); chưa build-test; chưa thử cảm ứng trên máy.
 */
object BubbleOps {

    /** Đích đuôi mặc định khi bật đuôi bằng tay: giữa chiều ngang bubble, thấp hơn đỉnh bubble 25% chiều cao ảnh. */
    const val TAIL_DEFAULT_DY = 0.25f
    const val TAIL_MAX_Y = 0.98f

    fun defaultTail(b: Bubble): Pair<Float, Float> =
        Pair((b.xNorm + b.widthNorm / 2f).coerceIn(0f, 1f), (b.yNorm + TAIL_DEFAULT_DY).coerceIn(0f, TAIL_MAX_Y))

    /** Bật: giữ đuôi sẵn có (không ghi đè vị trí đã kéo), chưa có thì đặt mặc định. Tắt: bỏ đuôi (null/null). */
    fun withTail(b: Bubble, enabled: Boolean): Bubble {
        if (!enabled) return b.copy(tailXNorm = null, tailYNorm = null)
        if (b.tailXNorm != null && b.tailYNorm != null) return b
        val (x, y) = defaultTail(b)
        return b.copy(tailXNorm = x, tailYNorm = y)
    }

    /** Dịch đích đuôi (đơn vị chuẩn hoá); bubble không có đuôi thì không đổi; kẹp trong ảnh. */
    fun moveTail(b: Bubble, dxNorm: Float, dyNorm: Float): Bubble {
        val tx = b.tailXNorm ?: return b
        val ty = b.tailYNorm ?: return b
        return b.copy(tailXNorm = (tx + dxNorm).coerceIn(0f, 1f), tailYNorm = (ty + dyNorm).coerceIn(0f, 1f))
    }

    /** delta > 0: đưa lên trên (về cuối danh sách); delta < 0: xuống dưới. Kẹp ở hai đầu; id không có -> giữ nguyên. */
    fun moveInStack(list: List<Bubble>, id: String, delta: Int): List<Bubble> {
        val from = list.indexOfFirst { it.id == id }
        if (from < 0 || delta == 0) return list
        val to = (from + delta).coerceIn(0, list.size - 1)
        if (to == from) return list
        val m = list.toMutableList()
        val item = m.removeAt(from)
        m.add(to, item)
        return m
    }
}
