package com.mangalocal.pipeline

import com.mangalocal.model.Bubble

/**
 * mục 249 TECHNICAL_STATUS.md — thao tác THUẦN cho màn sửa bubble: bật/tắt đuôi, kéo đích đuôi, đổi thứ tự lớp.
 * Tách khỏi Compose để kiểm thử riêng (tools/test_bubble_ops.py).
 *
 * "Lớp" (z-order) = thứ tự trong danh sách: bộ vẽ khi xuất (ExportEngine/PublishExporter) duyệt `bubbles.forEach`, nên phần tử
 * ĐỨNG SAU được vẽ SAU = nằm TRÊN. Không thêm trường zIndex mới (bubble đã lưu cũ vẫn đọc đúng).
 *
 * mục 258: đã thêm chọn font + cỡ chữ riêng từng bubble (fontStyle/fontScale). GIỚI HẠN THẬT: chỉ dùng được 5 họ font CÓ SẴN của Android
 * (không đóng gói file font riêng nên không có font kiểu truyện tranh/viết tay); chữ Việt có dấu hiển thị theo font hệ thống;
 * chưa thử cảm ứng trên máy.
 */
object BubbleOps {

    /** Đích đuôi mặc định khi bật đuôi bằng tay: giữa chiều ngang bubble, thấp hơn đỉnh bubble 25% chiều cao ảnh. */
    const val TAIL_DEFAULT_DY = 0.25f
    const val TAIL_MAX_Y = 0.98f

    // ---- mục 258: font + cỡ chữ ----
    const val FONT_SCALE_MIN = 0.6f
    const val FONT_SCALE_MAX = 2.0f

    /** Họ font có sẵn của Android. Ánh xạ sang Typeface nằm ở ExportEngine (lớp này giữ thuần để test được). */
    enum class BubbleFont(val label: String) { SANS("Thường"), BOLD("Đậm"), SERIF("Có chân"), MONO("Đơn cách"), ITALIC("Nghiêng") }

    /** Tên lưu trong Bubble.fontStyle -> font. null/lạ -> SANS (không bao giờ lỗi với dữ liệu cũ hoặc sai). */
    fun fontOf(name: String?): BubbleFont = BubbleFont.values().firstOrNull { it.name == name } ?: BubbleFont.SANS

    /** Hệ số cỡ chữ hiệu lực: null -> 1.0 (hành vi cũ); giá trị lạ bị kẹp. */
    fun scaleOf(b: Bubble): Float {
        val s = b.fontScale ?: return 1f
        return if (s.isNaN()) 1f else s.coerceIn(FONT_SCALE_MIN, FONT_SCALE_MAX)
    }

    /** Ghi font + cỡ chữ. Giá trị mặc định (1.0 và SANS) lưu lại thành null để bubble không bị "đóng dấu" tuỳ chỉnh vô ích. */
    fun withFont(b: Bubble, scale: Float, font: BubbleFont): Bubble {
        val sc = if (scale.isNaN()) 1f else scale.coerceIn(FONT_SCALE_MIN, FONT_SCALE_MAX)
        return b.copy(
            fontScale = if (kotlin.math.abs(sc - 1f) < 0.01f) null else sc,
            fontStyle = if (font == BubbleFont.SANS) null else font.name
        )
    }

    fun defaultTail(b: Bubble): Pair<Float, Float> =
        Pair((b.xNorm + b.widthNorm / 2f).coerceIn(0f, 1f), (b.yNorm + TAIL_DEFAULT_DY).coerceIn(0f, TAIL_MAX_Y))

    /** Bật: giữ đuôi sẵn có (không ghi đè vị trí đã kéo), chưa có thì đặt mặc định. Tắt: bỏ đuôi (null/null). */
    fun withTail(b: Bubble, enabled: Boolean): Bubble {
        if (!enabled) return b.copy(tailXNorm = null, tailYNorm = null)
        if (b.tailXNorm != null && b.tailYNorm != null) return b
        val (x, y) = defaultTail(b)
        return b.copy(tailXNorm = x, tailYNorm = y)
    }

    /** Dịch đích đuôi (đơn vị chuẩn hoá); bubble không có đuôi thì không đổi; kẹp trong ảnh. */
    fun moveTail(b: Bubble, dxNorm: Float, dyNorm: Float): Bubble {
        val tx = b.tailXNorm ?: return b
        val ty = b.tailYNorm ?: return b
        return b.copy(tailXNorm = (tx + dxNorm).coerceIn(0f, 1f), tailYNorm = (ty + dyNorm).coerceIn(0f, 1f))
    }

    /** delta > 0: đưa lên trên (về cuối danh sách); delta < 0: xuống dưới. Kẹp ở hai đầu; id không có -> giữ nguyên. */
    fun moveInStack(list: List<Bubble>, id: String, delta: Int): List<Bubble> {
        val from = list.indexOfFirst { it.id == id }
        if (from < 0 || delta == 0) return list
        val to = (from + delta).coerceIn(0, list.size - 1)
        if (to == from) return list
        val m = list.toMutableList()
        val item = m.removeAt(from)
        m.add(to, item)
        return m
    }
}
