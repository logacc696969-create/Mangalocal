package com.mangalocal.pipeline

/**
 * mục 259 TECHNICAL_STATUS.md — GIÁM KHẢO NHÌN-HIỂU ẢNH (VLM) cho kiểm tra sau sinh.
 *
 * Vì sao: OutputVerifier đếm người bằng YOLOv8-pose (hình học khung xương). Một model nhìn-hiểu ảnh nhỏ chạy bằng CHÍNH engine MNN-LLM của
 * dự án (Qwen2.5-VL 3B / Qwen3-VL đã convert sang MNN) cho một "ý kiến thứ hai" độc lập: đếm người và (với cảnh ôm/vật) có tiếp xúc thân thể hay
 * không. Đây là hướng thay thế khả thi cho các phương pháp dùng MLLM làm giám khảo (CoT-Diff, Place-it-R1, PhysicsRM) mà MNN không chạy được.
 *
 * Cách gọi (đã đối chiếu với hướng dẫn Arm/MNN): prompt = "<img>đường_dẫn_ảnh</img>câu hỏi" đi qua Llm::response() — chính đường
 * NativeBridge.llamaGenerate hiện dùng; mỗi model là một handle riêng (llamaInit trả 0 khi không nạp được).
 *
 * GIỚI HẠN THẬT (đọc trước khi tin):
 *  - Tắt mặc định; chỉ chạy khi bật "Kiểm tra ảnh SAU khi sinh" VÀ đặt thư mục model VL (visionJudgeModelDir).
 *  - APK phải build với enable_vlm=true (MNN_BUILD_LLM_OMNI + LLM_SUPPORT_VISION + OpenCV/imgcodecs của MNN); bản thường không nạp được model VL
 *    và bước này tự bỏ qua (có log), không làm hỏng sinh ảnh.
 *  - Model VL nhỏ đếm sai ở cảnh đông/che khuất; chỉ CẢNH BÁO (như OutputVerifier), không tự sinh lại. Câu trả lời không phân tích được thì
 *    KHÔNG bị coi là lỗi.
 *  - Mỗi panel thêm vài giây (mã hoá ảnh) tới chục giây trên máy yếu; model ~2 GB RAM. Chưa chạy với model thật.
 *  - Kiểm tra GIẤY PHÉP từng model (không phải model nào cũng Apache-2.0).
 */
object VisionJudge {
    const val MAX_PEOPLE = 30
    const val MAX_ANSWER_TOKENS = 12
    /**
     * mục 266 — giám khảo QUA API: model đám mây (ví dụ Gemini) có thể "suy nghĩ" trước khi trả lời và phần suy nghĩ tính vào max_tokens của kiểu OpenAI, nên
     * 12 token (đủ cho model trên máy) có thể cho câu trả lời RỖNG; dùng trần rộng hơn (câu hỏi vẫn bắt trả một số/YES/NO nên câu trả lời vẫn ngắn).
     */
    const val MAX_ANSWER_TOKENS_API = 256

    fun countPrompt(imagePath: String): String =
        "<img>$imagePath</img>How many people are visible in this image? Answer with a single number only."

    fun contactPrompt(imagePath: String): String =
        "<img>$imagePath</img>Are at least two of the people in physical contact with each other " +
            "(for example hugging, grappling or holding each other)? Answer YES or NO only."

    /**
     * mục 266 — bỏ thẻ `<img>đường_dẫn</img>` ở ĐẦU prompt (chỉ có nghĩa với MNN-LLM trên máy) để còn câu hỏi thuần gửi kèm ẢNH qua API.
     * Không có thẻ thì giữ nguyên (chỉ cắt khoảng trắng). Đường dẫn ảnh KHÔNG được lọt vào nội dung gửi ra ngoài.
     */
    fun stripImageTag(prompt: String): String = prompt.replace(Regex("^\\s*<img>.*?</img>", RegexOption.DOT_MATCHES_ALL), "").trim()

    private val WORD_NUMBERS = mapOf(
        "zero" to 0, "none" to 0, "nobody" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10
    )

    /** Số người từ câu trả lời tự do: số nguyên đầu tiên (0..30) hoặc từ chỉ số ("two"); null nếu không hiểu hoặc vô lý (> 30). */
    fun parseCount(answer: String): Int? {
        val digits = Regex("\\d+").find(answer)?.value
        if (digits != null) {
            val n = digits.toIntOrNull() ?: return null
            return if (n in 0..MAX_PEOPLE) n else null
        }
        for (tok in answer.lowercase().split(Regex("[^a-z]+"))) {
            val v = WORD_NUMBERS[tok]
            if (v != null) return v
        }
        return null
    }

    /** YES/NO từ từ chữ cái ĐẦU TIÊN của câu trả lời; mọi thứ khác -> null (không đoán). */
    fun parseYesNo(answer: String): Boolean? {
        val tok = answer.lowercase().split(Regex("[^a-z]+")).firstOrNull { it.isNotEmpty() } ?: return null
        return when (tok) {
            "yes" -> true
            "no" -> false
            else -> null
        }
    }

    private val CONTACT_REGEX = Regex(
        "hug|embrac|kiss|grappl|wrestl|fight|punch|choke|strangl|cuddl|carry|carried|hold|grab|lift|" +
            "ôm|hôn|vật|đánh|đấm|bóp cổ|siết|bế|cõng|nắm|giữ|túm|nhấc"
    )

    /** Hành động của cảnh có ngụ ý tiếp xúc thân thể không (từ khoá Anh + Việt, không phân biệt hoa/thường). */
    fun isContactAction(action: String): Boolean = CONTACT_REGEX.containsMatchIn(action.lowercase())

    class Verdict(val counted: Int?, val contact: Boolean?, val rawCount: String, val rawContact: String)

    /** [ask] gửi một prompt tới model VL và trả câu trả lời (được tiêm vào để test mà không cần model thật). */
    fun judge(imagePath: String, askContact: Boolean, ask: (String) -> String): Verdict {
        val rc = ask(countPrompt(imagePath))
        val rk = if (askContact) ask(contactPrompt(imagePath)) else ""
        return Verdict(parseCount(rc), if (askContact) parseYesNo(rk) else null, rc.trim(), rk.trim())
    }

    /** Lý do cảnh báo (tiếng Việt). Không hiểu được câu trả lời (null) thì KHÔNG phạt. */
    fun reasons(v: Verdict, expectedPeople: Int, expectContact: Boolean, suppressCount: Boolean = false): List<String> {
        val out = ArrayList<String>()
        val c = v.counted
        // mục 262: suppressCount = bộ phân xử (PersonCountArbiter) đã để detector thắng -> không thêm lý do đếm của VLM (lý do tiếp xúc vẫn giữ)
        if (!suppressCount && c != null && c != expectedPeople) out.add("Giám khảo ảnh (VLM) đếm $c người, kịch bản cần $expectedPeople")
        if (expectContact && v.contact == false) out.add("Giám khảo ảnh (VLM) không thấy tiếp xúc thân thể mà cảnh yêu cầu")
        return out
    }
}
