package com.mangalocal.pipeline

/**
 * mục 249 TECHNICAL_STATUS.md — `ComicInfo.xml` cho file CBZ (chuẩn metadata de facto của ComicRack/Anansi Project).
 *
 * Tra cứu mục 249 (nhiều nguồn khớp nhau): trường `<Manga>` có đúng 4 giá trị "Unknown" | "No" | "Yes" | "YesAndRightToLeft";
 * `YesAndRightToLeft` báo trình đọc hiển thị phải → trái. Tệp đặt ở GỐC kho nén, đúng hoa/thường `ComicInfo.xml`; thư viện
 * nghiêm ngặt (Komga, Kavita, KOReader theo một thư viện tra được) cần: KHÔNG có namespace ở phần tử gốc, UTF-8, có khai báo XML,
 * giá trị enum đúng hoa/thường; trang được thêm theo thứ tự đọc (thứ tự trong kho là chuẩn), tên có đệm số 0.
 *
 * GIỚI HẠN THẬT: chỉ ghi vài trường cơ bản (Title, Series, Number, PageCount, LanguageISO, Manga); không ghi bảng `<Pages>`.
 * Chưa kiểm chứng với trình đọc thật; chưa build-test.
 */
object ComicInfoXml {

    /** Ký tự hợp lệ trong XML 1.0: tab, LF, CR, U+0020–U+D7FF, U+E000–U+FFFD và cặp thay thế (ký tự ngoài BMP). */
    private fun validXmlChar(c: Char): Boolean =
        c == '\t' || c == '\n' || c == '\r' || c in ' '..'\uD7FF' || c in '\uE000'..'\uFFFD' || c.isSurrogate()

    fun escape(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (c in s) {
            if (!validXmlChar(c)) continue
            when (c) {
                '&' -> sb.append("&amp;")
                '<' -> sb.append("&lt;")
                '>' -> sb.append("&gt;")
                '"' -> sb.append("&quot;")
                '\'' -> sb.append("&apos;")
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    /** `number` null hoặc âm -> bỏ trường; `series`/`title`/`languageIso` rỗng -> bỏ trường. */
    fun build(title: String, series: String, number: Int?, pageCount: Int, languageIso: String?, rightToLeft: Boolean): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<ComicInfo>\n")
        if (title.isNotBlank()) sb.append("  <Title>").append(escape(title.trim())).append("</Title>\n")
        if (series.isNotBlank()) sb.append("  <Series>").append(escape(series.trim())).append("</Series>\n")
        if (number != null && number >= 0) sb.append("  <Number>").append(number).append("</Number>\n")
        sb.append("  <PageCount>").append(maxOf(pageCount, 0)).append("</PageCount>\n")
        if (!languageIso.isNullOrBlank()) sb.append("  <LanguageISO>").append(escape(languageIso.trim())).append("</LanguageISO>\n")
        sb.append("  <Manga>").append(if (rightToLeft) "YesAndRightToLeft" else "No").append("</Manga>\n")
        sb.append("</ComicInfo>\n")
        return sb.toString()
    }
}
