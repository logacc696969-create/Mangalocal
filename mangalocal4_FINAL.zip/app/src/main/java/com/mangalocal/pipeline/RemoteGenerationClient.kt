package com.mangalocal.pipeline

import android.util.Base64
import com.mangalocal.model.RemoteEndpointConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.CertificatePinner
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.spec.X509EncodedKeySpec
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Gọi generate ảnh trên GPU thuê ngoài (Colab / RunPod / Vast.ai...) qua
 * remote_server/app.py (xem thư mục tools/remote_server/ trong repo).
 *
 * MÔ HÌNH BẢO MẬT THẬT — đọc kỹ trước khi tưởng nhầm đây là "không ai soi
 * được", đã giải thích với người dùng ở nơi khác, nhắc lại ngắn gọn ở đây
 * vì đây là chỗ code thực thi:
 *
 * 1. Mã hoá hybrid RSA-OAEP + AES-256-GCM giữa APK và TIẾN TRÌNH PYTHON
 *    trên server, KHÔNG dừng ở tầng TLS thường — nghĩa là: kể cả bên trung
 *    gian mạng đứng giữa (vd hạ tầng ngrok/Cloudflare Tunnel nếu dùng Colab,
 *    ISP, proxy công ty...) CÓ đọc được gói tin TLS (vd ngrok tự giải mã ở
 *    edge của họ rồi mới chuyển tiếp), thì NỘI DUNG bên trong (prompt, ảnh)
 *    vẫn là ciphertext đối với họ — vì lớp mã hoá này độc lập với TLS, chỉ
 *    APK và đúng tiến trình Python cầm private key mới giải mã được.
 * 2. NHƯNG: tiến trình Python đó chạy TRÊN hạ tầng của chủ GPU thuê (Google/
 *    chủ máy RunPod-Vast.ai). Ngay lúc server giải mã để chạy model, dữ liệu
 *    ở dạng plaintext trong RAM/VRAM của VM đó — nếu CHÍNH chủ hạ tầng
 *    (không phải bên trung gian mạng) cố tình soi VM đang chạy, lớp mã hoá
 *    này KHÔNG chặn được (không có cách nào chặn được bằng phần mềm thuần –
 *    xem RemoteSecurityTier.CONFIDENTIAL_COMPUTING trong Models.kt).
 * 3. Xác thực khoá công khai server (fingerprint) là XÁC THỰC LẦN ĐẦU
 *    (Trust On First Use) — người dùng nên tự đối chiếu fingerprint hiển
 *    thị trong app với fingerprint in ra ở log Colab/terminal server lúc
 *    khởi động, GIỐNG cách WhatsApp/Signal safety number hoạt động — nếu
 *    bỏ qua bước đối chiếu này, 1 bên trung gian chủ động (active MITM) về
 *    lý thuyết có thể tự giả làm server lúc TOFU (lần kết nối đầu tiên).
 *
 * Tóm gọn: lớp mã hoá này có giá trị thật (chống trung gian mạng thụ động/
 * chủ động sau TOFU), nhưng KHÔNG phải "end-to-end tuyệt đối chống mọi bên"
 * như yêu cầu ban đầu — không ai làm được điều đó với GPU thuê thường.
 */
class RemoteGenerationClient(private val config: RemoteEndpointConfig) {

    private val client: OkHttpClient by lazy {
        val builder = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(config.timeoutSeconds.toLong(), TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            // SỬA (user hỏi về lộ thông tin thiết bị): OkHttp mặc định tự
            // thêm header "User-Agent: okhttp/x.x.x" — không lộ máy cụ thể
            // gì, nhưng cũng không cần thiết phải để lộ ngay cả tên thư
            // viện đang dùng. Thay bằng chuỗi chung chung, không đổi gì
            // khác (KHÔNG gửi model máy/Android ID/bất kỳ định danh thiết
            // bị nào trước đây và bây giờ cũng vậy).
            .addInterceptor { chain ->
                chain.proceed(chain.request().newBuilder()
                    .header("User-Agent", "MangaLocalClient")
                    .build())
            }
        // Certificate pinning CHỈ áp dụng được khi baseUrl cố định (RunPod/VPS
        // riêng) — với Colab+ngrok domain đổi mỗi lần chạy lại nên thường để
        // trống (pinnedCertSha256 rỗng = bỏ qua bước này, dựa vào CA hệ thống).
        if (config.pinnedCertSha256.isNotBlank()) {
            val host = java.net.URI(config.baseUrl).host
            builder.certificatePinner(
                CertificatePinner.Builder()
                    .add(host, "sha256/${config.pinnedCertSha256}")
                    .build()
            )
        }
        builder.build()
    }

    private var serverPublicKeyCache: java.security.PublicKey? = null
    private var serverFingerprintCache: String? = null

    /**
     * Gọi 1 lần trước request đầu tiên (hoặc khi user bấm "Kiểm tra kết nối"
     * ở SettingsScreen) — lấy public key server + fingerprint để user tự đối
     * chiếu (TOFU, xem giải thích ở đầu file). Trả về fingerprint dạng
     * "AB:CD:12:..." để hiển thị lên UI.
     */
    suspend fun fetchServerFingerprint(): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("${config.baseUrl}/pubkey").get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw RuntimeException("Không lấy được public key server: HTTP ${resp.code}")
            val body = JSONObject(resp.body?.string() ?: "{}")
            val pemB64 = body.getString("public_key_der_b64")
            val keyBytes = Base64.decode(pemB64, Base64.NO_WRAP)
            val pubKey = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(keyBytes))
            serverPublicKeyCache = pubKey
            val fp = MessageDigest.getInstance("SHA-256").digest(keyBytes)
                .joinToString(":") { "%02X".format(it) }
            serverFingerprintCache = fp
            fp
        }
    }

    /**
     * Sinh 1 panel trên remote server. Ném exception nếu lỗi (network, auth,
     * server báo lỗi generate...) — caller (BackendRouter/MangaPipeline) tự
     * quyết định fallback về local hay báo lỗi cho user, KHÔNG tự âm thầm
     * fallback ở tầng này (fallback âm thầm có thể khiến user tưởng đã chạy
     * remote trong khi thực ra local, sai với kỳ vọng minh bạch đã bàn).
     *
     * SỬA (server giờ hỗ trợ đầy đủ — xem tools/remote_server/app.py):
     * thêm 3 tham số optional để đạt tính năng ngang bằng local:
     *   - referenceImagePath: ảnh anchor nhân vật (null = không dùng IP-Adapter)
     *   - skeletonData: mảng float phẳng CÙNG format gửi cho native local
     *     (18 khớp * 4 giá trị/người, xem MangaPipeline.resolveSkeletonData) —
     *     server tự vẽ lại thành ảnh điều kiện ControlNet-Pose.
     *   - loraId: tên file LoRA KHÔNG kèm đuôi .safetensors — server phải đã
     *     có sẵn file này từ trước (đồng bộ tay, xem README.md) — KHÔNG upload
     *     file LoRA qua đường này (file lớn, không hợp lý gửi mỗi request).
     */
    suspend fun generatePanel(
        prompt: String, negativePrompt: String, width: Int, height: Int,
        steps: Int, cfgScale: Float, seed: Long, outFile: File,
        referenceImagePath: String? = null, skeletonData: FloatArray? = null, loraId: String? = null
    ): Unit = withContext(Dispatchers.IO) {
        if (!config.enabled || config.baseUrl.isBlank())
            throw IllegalStateException("Remote endpoint chưa bật/cấu hình (Cài đặt > Remote GPU)")

        val pubKey = serverPublicKeyCache ?: run { fetchServerFingerprint(); serverPublicKeyCache!! }

        // 1. Tạo AES-256-GCM key ngẫu nhiên, DÙNG 1 LẦN cho đúng request này
        //    (không tái sử dụng giữa các panel — mỗi panel 1 key mới, đúng
        //    khuyến nghị "ephemeral session key" chuẩn).
        val aesKey = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()

        // 2. Payload thật (prompt + tham số + optional IP-Adapter/ControlNet/LoRA) -> mã hoá AES-GCM
        val payloadJson = JSONObject().apply {
            put("prompt", prompt); put("negative_prompt", negativePrompt)
            put("width", width); put("height", height)
            put("steps", steps); put("cfg_scale", cfgScale); put("seed", seed)
            if (loraId != null) put("lora_id", loraId)
            if (config.remoteModelId.isNotBlank()) {
                put("model_id", config.remoteModelId)
                put("model_type", config.remoteModelType.name.lowercase())
            }
            if (referenceImagePath != null) {
                val refBytes = File(referenceImagePath).readBytes()
                put("reference_image_b64", Base64.encodeToString(refBytes, Base64.NO_WRAP))
            }
            if (skeletonData != null && skeletonData.isNotEmpty()) {
                put("skeleton_data", org.json.JSONArray().apply {
                    skeletonData.forEach { put(it.toDouble()) }
                })
            }
        }.toString()
        val (ivBytes, cipherBytes) = aesGcmEncrypt(aesKey, payloadJson.toByteArray(Charsets.UTF_8))

        // 3. Bọc AES key bằng RSA-OAEP public key của server -> chỉ tiến
        //    trình Python cầm private key tương ứng mới mở được, không phải
        //    bất kỳ trung gian nào đứng giữa (xem giải thích đầu file).
        val wrappedKey = rsaOaepEncrypt(pubKey, aesKey.encoded)

        val reqBody = JSONObject().apply {
            put("wrapped_key_b64", Base64.encodeToString(wrappedKey, Base64.NO_WRAP))
            put("iv_b64", Base64.encodeToString(ivBytes, Base64.NO_WRAP))
            put("ciphertext_b64", Base64.encodeToString(cipherBytes, Base64.NO_WRAP))
        }.toString()

        val request = Request.Builder()
            .url("${config.baseUrl}/generate")
            .addHeader("Authorization", "Bearer ${config.authToken}")
            .post(reqBody.toRequestBody("application/json".toMediaType()))
            .build()

        // SỬA (thêm hàng đợi/rate-limit phía server — xem app.py
        // _MAX_QUEUE_DEPTH): server có thể trả 429 khi đang xử lý/xếp hàng
        // quá nhiều request cùng lúc — đây là tín hiệu "thử lại sau", KHÔNG
        // phải lỗi cứng. Tự thử lại vài lần với khoảng chờ tăng dần trước
        // khi thật sự báo lỗi cho user.
        var lastError: Exception? = null
        for (attempt in 0 until 5) {
            if (attempt > 0) delay(1500L * attempt) // 1.5s, 3s, 4.5s, 6s — chờ hàng đợi vơi bớt
            try {
                client.newCall(request).execute().use { resp ->
                    if (resp.code == 429) {
                        lastError = RuntimeException("Server remote đang bận (hàng đợi đầy) — đã thử lại ${attempt + 1} lần")
                        return@use  // rơi xuống vòng lặp, thử lại
                    }
                    if (!resp.isSuccessful) {
                        val errBody = resp.body?.string()?.take(300) ?: ""
                        throw RuntimeException("Remote generate thất bại: HTTP ${resp.code} $errBody")
                    }
                    val respJson = JSONObject(resp.body?.string() ?: throw RuntimeException("Remote trả về rỗng"))
                    // Server dùng LẠI cùng aesKey (đã biết qua bước 2, không cần bọc
                    // RSA lại cho chiều về — ciphertext ảnh lớn hơn nhiều prompt, RSA
                    // chỉ phù hợp payload nhỏ như key 256-bit) + IV MỚI cho chiều
                    // response (không tái dùng IV, bắt buộc với GCM).
                    val respIv = Base64.decode(respJson.getString("iv_b64"), Base64.NO_WRAP)
                    val respCipher = Base64.decode(respJson.getString("ciphertext_b64"), Base64.NO_WRAP)
                    val imageBytes = aesGcmDecrypt(aesKey, respIv, respCipher)
                    outFile.writeBytes(imageBytes)
                    return@withContext
                }
            } catch (ex: Exception) {
                lastError = ex
            }
        }
        throw lastError ?: RuntimeException("Remote generate thất bại (không rõ lý do) sau nhiều lần thử")
    }

    // ── Crypto helpers ───────────────────────────────────────────────────
    private fun aesGcmEncrypt(key: SecretKey, plaintext: ByteArray): Pair<ByteArray, ByteArray> {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return iv to cipher.doFinal(plaintext)
    }

    private fun aesGcmDecrypt(key: SecretKey, iv: ByteArray, ciphertext: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext)
    }

    private fun rsaOaepEncrypt(pubKey: java.security.PublicKey, data: ByteArray): ByteArray {
        // SỬA BUG THẬT (mục 103 TECHNICAL_STATUS.md) — ĐÃ KIỂM CHỨNG BẰNG
        // THỰC NGHIỆM (Java+Python chạy thật trong sandbox, không suy đoán):
        // chuỗi transformation "RSA/ECB/OAEPWithSHA-256AndMGF1Padding" KHÔNG
        // kèm OAEPParameterSpec tường minh -> JCE (Sun/Conscrypt) mặc định
        // dùng MGF1 = SHA-1, DÙ hash chính đã ghi rõ SHA-256 trong tên. Server
        // Python (app.py) dùng ĐÚNG SHA-256 cho CẢ 2 (main hash + MGF1) — 2
        // bên KHÔNG khớp nhau. Bản cũ (dòng dưới, đã comment) sẽ khiến MỌI
        // request remote-GPU thất bại ngay bước đầu ("Không giải mã được
        // session key") — vì server luôn nhận sai ciphertext OAEP.
        //   val cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding")
        //   cipher.init(Cipher.ENCRYPT_MODE, pubKey)  // <- THIẾU OAEPParameterSpec, rơi về MGF1=SHA-1
        // Sửa: truyền OAEPParameterSpec TƯỜNG MINH, ép MGF1 = SHA-256, khớp
        // đúng rsa_padding.OAEP(mgf=MGF1(SHA256()), algorithm=SHA256()) phía
        // app.py. Đã verify: mã hoá bằng cấu hình này (Java) rồi giải mã
        // bằng đúng code app.py (Python) — ra ĐÚNG giá trị gốc.
        val cipher = Cipher.getInstance("RSA/ECB/OAEPPadding")
        val oaepParams = javax.crypto.spec.OAEPParameterSpec(
            "SHA-256", "MGF1", java.security.spec.MGF1ParameterSpec.SHA256,
            javax.crypto.spec.PSource.PSpecified.DEFAULT
        )
        cipher.init(Cipher.ENCRYPT_MODE, pubKey, oaepParams)
        return cipher.doFinal(data)
    }
}
