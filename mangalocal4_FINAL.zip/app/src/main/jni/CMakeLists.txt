cmake_minimum_required(VERSION 3.22.1)
project(mangalocal_native CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

set(TP ${CMAKE_SOURCE_DIR}/third_party)

# ─────────────────────────────────────────────────────────────────────────
# LLM — CHUYỂN từ llama.cpp sang MNN-LLM (mở lại quyết định cũ trong
# handoff mục 3, theo yêu cầu rõ ràng của user: "tối thiểu phải chạy GPU"
# áp dụng cho MỌI model, không riêng phần sinh ảnh).
#
# Lý do đủ để mở lại quyết định "giữ llama.cpp":
#  - MNN-LLM có backend OpenCL/QNN thật cho LLM (llama.cpp trên Android
#    không có đường GPU/NPU ổn định như đã ghi trong build history mục 4).
#  - Theo benchmark chính thức của Alibaba, MNN-LLM nhanh hơn llama.cpp
#    ngay cả khi CHỈ chạy CPU (8.6x prefill, 2.3x decode) — không phải
#    đánh đổi, mà lợi ở cả 2 mặt.
#  - Dùng chung 1 thư viện MNN cho cả LLM lẫn Diffusion, đỡ phải build
#    2 third-party riêng (llama.cpp + MNN).
# ─────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────
# MNN — thay thế stable-diffusion.cpp + ncnn (quyết định đã chốt, xem
# handoff mục 3 và mục 8 — đừng quay lại sd.cpp/ncnn).
#
# GIAI ĐOẠN HIỆN TẠI: CPU + OpenCL (Adreno GPU) — thỏa yêu cầu "tối thiểu
# phải chạy GPU". KHÔNG bật MNN_QNN ở bước này.
#
# Lý do KHÔNG bật QNN ngay: backend QNN của MNN cần thư viện nhị phân thật
# từ Qualcomm QNN SDK (tải qua Qualcomm Package Manager, cần tài khoản
# Qualcomm ID — không tự động tải được trong GitHub Actions ẩn danh).
# Tên cờ CMake đúng của MNN là MNN_QNN (KHÔNG PHẢI MNN_SUPPORT_QNN như bản
# cũ — đó là tên sai, đã kiểm chứng lại với source thật alibaba/MNN).
# Khi nào có QNN SDK thật (tải thủ công, đóng gói base64 vào GitHub Secret
# hoặc release asset riêng), mới bật lại MNN_QNN=ON và set MNN_QNN_SDK_ROOT
# trỏ đúng thư mục SDK đó.
set(MNN_BUILD_OPENCV     OFF CACHE BOOL "" FORCE)
set(MNN_BUILD_TOOLS      OFF CACHE BOOL "" FORCE)
set(MNN_BUILD_DEMO       OFF CACHE BOOL "" FORCE)
set(MNN_BUILD_TEST       OFF CACHE BOOL "" FORCE)
set(MNN_BUILD_CONVERTER  OFF CACHE BOOL "" FORCE)
set(MNN_SEP_BUILD        OFF CACHE BOOL "" FORCE)

# mục 259 TECHNICAL_STATUS.md — GIÁM KHẢO NHÌN-HIỂU ẢNH (VLM) qua MNN-LLM "omni". OPT-IN, mặc định OFF để KHÔNG đổi build đang chạy tốt
# (bật thêm OpenCV/imgcodecs của MNN là thay đổi build lớn, chưa từng chạy trên CI của dự án). Bật qua `-Pmangalocal.enableVlm=true` (Gradle)
# hoặc input enable_vlm của workflow. Bộ cờ (mục 274 — bỏ MNN_BUILD_LLM_OMNI vì kéo theo âm thanh, xem khối bên dưới): LLM_SUPPORT_VISION + MNN_BUILD_OPENCV + MNN_IMGCODECS.
# Phải đặt SAU dòng `MNN_BUILD_OPENCV OFF` ở trên (FORCE ghi đè) và TRƯỚC add_subdirectory(MNN).
option(MANGALOCAL_ENABLE_VLM "Bật MNN-LLM nhìn-hiểu ảnh (cần OpenCV + imgcodecs của MNN)" OFF)
if(MANGALOCAL_ENABLE_VLM)
  # mục 274 — KHÔNG đặt MNN_BUILD_LLM_OMNI: CMake của MNN (nhánh master) khi OMNI=ON ép luôn MNN_BUILD_AUDIO=ON -> dựng MNNAudio; với MNN_SEP_BUILD=OFF của dự án thì
  # MNNAudio là thư viện OBJECT và tools/audio/CMakeLists.txt:35 có add_custom_command(TARGET MNNAudio POST_BUILD …) -> CMake 3.22.1 báo lỗi cấu hình (log CI #137:
  # "Target MNNAudio is an OBJECT library that may not have PRE_BUILD, PRE_LINK, or POST_BUILD commands"). README chính thức của MNN (transformers/README.md): bản CHỈ nhìn ảnh
  # chỉ cần LLM_SUPPORT_VISION + MNN_BUILD_OPENCV + MNN_IMGCODECS; âm thanh là bộ cờ riêng (LLM_SUPPORT_AUDIO + MNN_BUILD_AUDIO). Giám khảo VLM chỉ cần nhìn ảnh.
  set(LLM_SUPPORT_VISION ON CACHE BOOL "" FORCE)
  set(MNN_BUILD_AUDIO OFF CACHE BOOL "" FORCE)
  set(MNN_BUILD_OPENCV   ON CACHE BOOL "" FORCE)
  set(MNN_IMGCODECS      ON CACHE BOOL "" FORCE)
endif()

# Bắt buộc để có API sinh ảnh (transformers/diffusion) — thiếu cờ này thì
# dù MNN build xong cũng không có gì để gọi sinh ảnh cả.
set(MNN_BUILD_DIFFUSION  ON  CACHE BOOL "" FORCE)

# Bắt buộc để có API MNN-LLM (Llm::createLLM, response()...) — thay thế
# llama.cpp cho bước parse truyện chữ / tạo kịch bản panel.
set(MNN_BUILD_LLM               ON CACHE BOOL "" FORCE)
set(MNN_LOW_MEMORY              ON CACHE BOOL "" FORCE)
set(MNN_CPU_WEIGHT_DEQUANT_GEMM ON CACHE BOOL "" FORCE)
set(MNN_SUPPORT_TRANSFORMER_FUSE ON CACHE BOOL "" FORCE)

# OpenCL = đường GPU chính cho Adreno 660 trên Snapdragon 888. Đây là
# OpenCL nội bộ của MNN (tự vendor, tự biên dịch kernel .cl thành C++ lúc
# build), KHÁC HẲN GGML_OPENCL của llama.cpp (thứ đã tắt ở trên vì thiếu
# header hệ thống) — không được suy luận "OpenCL đã fail nên MNN cũng
# fail", đây là 2 cơ chế build OpenCL độc lập nhau.
set(MNN_OPENCL           ON  CACHE BOOL "" FORCE)
set(MNN_VULKAN           OFF CACHE BOOL "" FORCE)

# fp16 trên ARMv8.2+ (Snapdragon 888 = Kryo 680, có hỗ trợ) — giảm bộ nhớ,
# tăng tốc, không hardcode riêng cho SD888 vì đây chỉ là bật khả năng dùng
# fp16 NẾU CPU hỗ trợ, tự phát hiện lúc runtime qua Precision_Low.
set(MNN_ARM82            ON  CACHE BOOL "" FORCE)

# QNN — TẮT ở giai đoạn này (xem giải thích trên). Không xoá dòng dưới,
# chỉ đổi OFF -> ON sau khi có QNN SDK thật.
#
# CẬP NHẬT (mục 60 TECHNICAL_STATUS.md): MnnUtils.hpp::createMnnSession()
# giờ ĐÃ CÓ cascade NPU->GPU->CPU thật cho diffusion (trước đây chỉ LLM có,
# xem jni_bridge.cpp) — dùng forward type MNN_FORWARD_NN (ô dùng CHUNG QNN/
# CoreML/NNAPI trong MNN, đã tra xác nhận qua tài liệu chính thức MNN, xem
# comment trong MnnUtils.hpp). Cascade này AN TOÀN dùng được ngay cả khi
# MANGALOCAL_ENABLE_QNN=OFF (mặc định) — chỉ đơn giản là nhánh NPU sẽ luôn
# thất bại (không có backend nào đăng ký ở forward type đó) và rớt xuống
# OpenCL/CPU như bình thường, không crash.
option(MANGALOCAL_ENABLE_QNN "Bật MNN_QNN khi đã có Qualcomm QNN SDK thật" OFF)
if(MANGALOCAL_ENABLE_QNN)
  if(NOT DEFINED MNN_QNN_SDK_ROOT)
    message(FATAL_ERROR "MANGALOCAL_ENABLE_QNN=ON nhưng thiếu -DMNN_QNN_SDK_ROOT=<đường dẫn Qualcomm QNN SDK đã giải nén>")
  endif()
  set(MNN_QNN ON CACHE BOOL "" FORCE)

  # HEXAGON_ARCH — bảng tra đầy đủ từ tài liệu chính thức MNN
  # (docs/inference/npu.md, mục "明确硬件架构" — SOC ID liệt kê để tham
  # khảo đối chiếu dù project này không dùng tới):
  #   8 Gen 1 (SOC ID 36) -> HEXAGON_ARCH 69
  #   8 Gen 2 (SOC ID 43) -> HEXAGON_ARCH 73
  #   8 Gen 3 (SOC ID 57) -> HEXAGON_ARCH 75   (mặc định CMake này dùng)
  #   8 Elite (SOC ID 69) -> HEXAGON_ARCH 79
  # Chip khác: tra bảng hỗ trợ thiết bị chính thức của Qualcomm.
  # ĐỊNH NGHĨA TRƯỚC khối MANGALOCAL_QNN_MODE bên dưới — biến này được
  # dùng để dựng tên file trong MANGALOCAL_QNN_LIB_LIST của cả 2 nhánh
  # online/offline (lỗi thứ tự đã có ở lần viết đầu — biến dùng TRƯỚC khi
  # định nghĩa sẽ ra chuỗi rỗng trong tên file, đã tự phát hiện và sửa
  # trước khi báo cáo, không phải do build test thật phát hiện).
  if(NOT DEFINED MANGALOCAL_QNN_HEXAGON_ARCH)
    set(MANGALOCAL_QNN_HEXAGON_ARCH "75")
  endif()

  # mục 62 TECHNICAL_STATUS.md — THÊM CHẾ ĐỘ OFFLINE (đúng cách local-dream
  # THẬT SỰ dùng — xem mục 61 phần so sánh). Trước đó (mục 60/61) chỉ có
  # chế độ ONLINE (biên dịch đồ thị QNN NGAY LÚC CHẠY trên máy — đơn giản
  # hơn nhưng chưa proven bằng, chưa ai chạy thật). Đọc kỹ tài liệu chính
  # thức MNN (docs/inference/npu.md, mục "离线构图模式") phát hiện: chế độ
  # OFFLINE **KHÔNG cần đổi API runtime** (không cần Module API như lo
  # ngại ban đầu) — chỉ cần nạp ĐÚNG FILE THAY THẾ (do công cụ
  # `MNN2QNNModel` sinh ra TRÊN MÁY KHÁC, x86_64 Linux, có QNN SDK) bằng
  # backend **CPU thường (type=0)** — QNN được gói kín trong 1 "Plugin op"
  # chạy trên CPU backend, tự đọc file `.bin` QNN đi kèm. Nghĩa là pipeline
  # C++ hiện có (Interpreter::createSession, KHÔNG phải Module API) VẪN
  # DÙNG ĐƯỢC NGUYÊN — chỉ cần trỏ đúng tên file model khác + backend CPU
  # (xem mnn_diffusion_pipeline.cpp phần đọc field "npu_offline" mới trong
  # model_manifest.json).
  #
  # 2 chế độ KHÔNG COMPILE CHUNG ĐƯỢC trong 1 build (`MNN_WITH_PLUGIN`
  # ngược nhau: online cần OFF, offline cần ON — theo đúng tài liệu chính
  # thức) — chọn 1 trong 2 qua biến dưới đây.
  set(MANGALOCAL_QNN_MODE "online" CACHE STRING "Che do QNN: 'online' (bien dich luc chay, mac dinh) hoac 'offline' (nap file da convert san tren PC, dung cach local-dream that su lam)")
  if(MANGALOCAL_QNN_MODE STREQUAL "offline")
    set(MNN_QNN_CONVERT_MODE OFF CACHE BOOL "" FORCE)  # OFF ở app device — ON chỉ cần lúc build CÔNG CỤ MNN2QNNModel trên máy Linux riêng, KHÔNG phải lúc build app này
    set(MNN_WITH_PLUGIN     ON  CACHE BOOL "" FORCE)
    set(MANGALOCAL_QNN_LIB_LIST
        "aarch64-android/libQnnHtp.so"
        "aarch64-android/libQnnSystem.so"  # THAY libQnnHtpPrepare.so (chỉ online mới cần) — offline cần libQnnSystem.so, ĐÚNG theo tài liệu, không đoán
        "aarch64-android/libQnnHtpV${MANGALOCAL_QNN_HEXAGON_ARCH}Stub.so"
        "hexagon-v${MANGALOCAL_QNN_HEXAGON_ARCH}/unsigned/libQnnHtpV${MANGALOCAL_QNN_HEXAGON_ARCH}Skel.so")
  else()
    set(MNN_QNN_CONVERT_MODE OFF CACHE BOOL "" FORCE)
    set(MNN_WITH_PLUGIN     OFF CACHE BOOL "" FORCE)
    set(MANGALOCAL_QNN_LIB_LIST
        "aarch64-android/libQnnHtp.so"
        "aarch64-android/libQnnHtpPrepare.so"  # CHỈ online cần (đúng ghi chú "only needed in the online case" trong tài liệu gốc)
        "aarch64-android/libQnnHtpV${MANGALOCAL_QNN_HEXAGON_ARCH}Stub.so"
        "hexagon-v${MANGALOCAL_QNN_HEXAGON_ARCH}/unsigned/libQnnHtpV${MANGALOCAL_QNN_HEXAGON_ARCH}Skel.so")
  endif()

  # mục 61/62 — ĐÓNG GÓI thư viện QNN runtime thật (danh sách tuỳ theo chế
  # độ online/offline ở trên). Nguồn: "${QNN_SDK_ROOT}/lib/..." (chính QNN
  # SDK qua biến MNN_QNN_SDK_ROOT) — ĐÃ TRA XÁC NHẬN 2 LẦN qua tài liệu
  # chính thức docs/inference/npu.md (lần 1 tra nhầm nguồn khác, đã tự sửa
  # trước khi báo cáo, xem mục 61).
  set(QNN_SDK_LIB "${MNN_QNN_SDK_ROOT}/lib")
  set(QNN_JNILIBS_DEST "${CMAKE_CURRENT_SOURCE_DIR}/../jniLibs/${ANDROID_ABI}")
  file(MAKE_DIRECTORY "${QNN_JNILIBS_DEST}")
  foreach(QNN_LIB_FILE ${MANGALOCAL_QNN_LIB_LIST})
    get_filename_component(QNN_LIB_NAME "${QNN_LIB_FILE}" NAME)
    set(QNN_LIB_SRC "${QNN_SDK_LIB}/${QNN_LIB_FILE}")
    if(EXISTS "${QNN_LIB_SRC}")
      file(COPY "${QNN_LIB_SRC}" DESTINATION "${QNN_JNILIBS_DEST}")
      message(STATUS "MangaLocal QNN (${MANGALOCAL_QNN_MODE}): da copy ${QNN_LIB_NAME} -> jniLibs/${ANDROID_ABI}/")
    else()
      # KHÔNG FATAL_ERROR — QNN SDK có thể có cấu trúc thư mục hơi khác
      # theo phiên bản, cảnh báo rõ thay vì chặn build, để người build tự
      # kiểm tra đường dẫn thật trong SDK của họ.
      message(WARNING "MangaLocal QNN: KHONG THAY ${QNN_LIB_SRC} - APK se KHONG co NPU that du MNN_QNN=ON (cascade trong MnnUtils.hpp van an toan, chi la khong tang toc). Kiem tra lai cau truc thu muc QNN SDK that (co the khac theo phien ban).")
    endif()
  endforeach()
else()
  set(MNN_QNN OFF CACHE BOOL "" FORCE)
endif()

add_subdirectory(${TP}/MNN mnn_build EXCLUDE_FROM_ALL)

# ─────────────────────────────────────────────────────────────────────────
# CPU optimization chung cho toàn bộ native lib (LLM + MNN đều hưởng lợi)
# ─────────────────────────────────────────────────────────────────────────
add_compile_options(-march=armv8.2-a+dotprod+fp16 -O3 -ffast-math -fvisibility=hidden)

# mục 270 TECHNICAL_STATUS.md — LoRA TÁCH RỜI qua MNN Module (UnetModule.hpp). OPT-IN, mặc định OFF: build thường KHÔNG biên dịch đường này.
# Cờ phải nhất quán ở MỌI file .cpp include PipelineSd15Cpu.hpp (layout lớp phụ thuộc cờ) nên dùng add_compile_definitions toàn thư mục, đặt SAU
# add_subdirectory(MNN) để không đụng tới mã MNN. Bật qua `-Pmangalocal.enableLoraModule=true` (Gradle) hoặc input enable_lora_module của workflow.
option(MANGALOCAL_ENABLE_LORA_MODULE "Bật đường module LoRA tách rời (*.lora.mnn) qua MNN Module — CHƯA thử trên máy thật" OFF)
if(MANGALOCAL_ENABLE_LORA_MODULE)
  add_compile_definitions(MANGALOCAL_LORA_MODULE=1)
endif()

add_library(mangalocal_native SHARED
    native_crash_handler.cpp
    jni_bridge.cpp
    esrgan_wrapper.cpp
    yolo_wrapper.cpp
    yolo_pose_wrapper.cpp
    # mục 232 TECHNICAL_STATUS.md — MiDaS-small ước lượng độ sâu ĐƠN ẢNH (điền z thật cho khớp xương)
    midas_depth_wrapper.cpp
    blazepose_wrapper.cpp          # mục 280: BlazePose GHUM 3D (độ sâu khớp THẬT) — một người đã cắt, CPU
    # mục 246 TECHNICAL_STATUS.md — ArcFace MobileFaceNet: thước đo danh tính cho cổng danh tính khi vẽ lại mặt
    arcface_wrapper.cpp
    mobile_sam_wrapper.cpp
    mnn_diffusion_pipeline.cpp
    sd_model_converter.cpp
    ip_adapter.cpp
    regional_prompting.cpp
    # mục 151 TECHNICAL_STATUS.md — nối dây Triple-Conditioning combo
    # (Regional Prompting + IP-Adapter mask + Depth ControlNet cùng lúc).
    triple_combo.cpp
    # mục 172/173 TECHNICAL_STATUS.md — Regional Prompting bản MASK tuỳ ý
    # (Attention Couple). File này ĐÃ TỒN TẠI trong cây nguồn và ĐÃ được
    # MangaPipeline.kt dispatch tới (useRegionalMask, mục 173) + khai báo
    # external fun trong NativeBridge.kt (sdInitRegionalMask/
    # sdTxt2ImgRegionalMask/sdFreeRegionalMask) từ trước, NHƯNG chưa từng
    # được thêm vào add_library() ở đây — bug "chưa nối dây" thật: thiếu
    # dòng này thì 3 hàm JNI trên KHÔNG được biên dịch/link vào .so, mọi
    # lời gọi từ Kotlin sẽ ném UnsatisfiedLinkError ngay khi chạy tới
    # nhánh useRegionalMask (không phải lỗi biên dịch — CMake không báo
    # thiếu vì file không được liệt kê không phải lỗi cú pháp). Phát hiện
    # bằng cách đối chiếu trực tiếp danh sách source ở đây với toàn bộ
    # file .cpp có trong app/src/main/jni/, không phải suy đoán. Đã thêm
    # dòng này để khớp đúng 1-1 giữa file .cpp tồn tại và file được build.
    regional_mask_prompting.cpp
    # mục 177 TECHNICAL_STATUS.md — SDXL Phase 2b (IP-Adapter + ControlNet-
    # Pose cho SDXL). File MỚI, độc lập (không include chéo, xem comment
    # đầu ip_adapter_sdxl.cpp) — ĐĂNG KÝ NGAY Ở ĐÂY CÙNG LƯỢT viết file,
    # KHÔNG lặp lại đúng bug vừa tự phát hiện+vá ở regional_mask_prompting.cpp
    # phía trên (thiếu dòng add_library() khiến file tồn tại nhưng không
    # bao giờ được biên dịch).
    ip_adapter_sdxl.cpp
    # mục 179 TECHNICAL_STATUS.md — SDXL Phase 2d (Regional Prompting).
    regional_prompting_sdxl.cpp
    # mục 180 TECHNICAL_STATUS.md — SDXL Phase 2e (Regional-Mask/Attention Couple).
    regional_mask_prompting_sdxl.cpp
    # mục 225 TECHNICAL_STATUS.md — GLIGEN (grounding bounding-box cho vật
    # thể nền, mục 222/223/224). File MỚI, độc lập (không include chéo,
    # cùng quy ước ip_adapter_sdxl.cpp) — ĐĂNG KÝ NGAY CÙNG LƯỢT viết file,
    # học ĐÚNG bài học mục 175 đã tự phát hiện ở trên (KHÔNG phải mục 173
    # — tự kiểm tra lại số mục lúc viết dòng này, phát hiện trích nhầm số,
    # sửa ngay): thiếu dòng này thì file .cpp tồn tại nhưng KHÔNG được biên
    # dịch/link, mọi lời gọi JNI từ Kotlin sẽ ném UnsatisfiedLinkError im
    # lặng lúc CHẠY (không phải lỗi biên dịch) — không lặp lại đúng lỗi đó
    # lần nữa.
    gligen_wrapper.cpp
    stb_impl.cpp
)

target_include_directories(mangalocal_native PRIVATE
    ${TP}/MNN/include
    ${TP}/MNN/transformers/diffusion/include
    ${TP}/MNN/transformers/llm/engine/include
    ${TP}/stb
    ${TP}/xtensor/include
    ${TP}/xtl/include
    ${TP}/xsimd/include
    ${TP}/tokenizers-cpp/include
    ${TP}/json/include
    ${TP}/xtensor-blas/include
    ${CMAKE_SOURCE_DIR}
    ${CMAKE_SOURCE_DIR}/sd_engine
)

# tokenizers-cpp là wrapper C++ quanh thư viện Rust (HuggingFace tokenizers)
# — build ra 1 static lib Rust qua cargo, cross-compile cho Android. Cần
# add_subdirectory để nó tự chạy bước cargo build (xem build.yml — đã thêm
# cài Rust + target aarch64-linux-android trước bước build.gradle).
add_subdirectory(${TP}/tokenizers-cpp tokenizers_cpp_build EXCLUDE_FROM_ALL)

target_link_libraries(mangalocal_native PRIVATE
    # Tên target "llm" theo quy ước file libllm.a/libllm.so mà MNN xuất ra
    # (xem transformers/README.md chính thức). CHƯA kiểm chứng tên target
    # CMake nội bộ chính xác 100% — nếu bước link báo không tìm thấy target
    # "llm", xem log configure của MNN (nó sẽ liệt kê toàn bộ target thật)
    # rồi đổi tên ở đây, đây là lỗi tự lộ ra ngay, không im lặng.
    MNN MNN_Express llm
    tokenizers_cpp
    android log jnigraphics
)

target_compile_options(mangalocal_native PRIVATE -fvisibility=hidden)

# ─────────────────────────────────────────────────────────────────────────
# mục 252/253 TECHNICAL_STATUS.md — GIỚI HẠN SONG SONG khi biên dịch các file nặng
# xtensor (Pipeline.hpp kéo vào ~9 file .cpp, mỗi file -O3 -ffast-math). Ninja mặc
# định chạy (số CPU + 2) tiến trình cùng lúc. Runner thật (log Build #127): 4 CPU,
# 15988 MB RAM => ~6 tiến trình clang xtensor × ~2-2.5 GB ≈ sát giới hạn 16 GB, có
# thể bị OOM-kill giữa chừng (clang: "Killed"/"signal") mà log chỉ báo "ninja ...
# exit value 1". Số file xtensor tăng dần theo từng mục (ip_adapter_sdxl,
# regional_*_sdxl, triple_combo, gligen_wrapper) nên rủi ro tăng theo. CHỈ ảnh hưởng
# thời gian biên dịch của riêng target này (tối đa 2 file song song), KHÔNG đổi mã
# sinh ra. Phòng ngừa — CHƯA có bằng chứng là NGUYÊN NHÂN lỗi build #123; bước
# `ninja -k 0 -j2` trong build.yml xác nhận/loại trừ. Gỡ 2 dòng dưới nếu thừa.
# APPEND để không ghi đè pool nào MNN/tokenizers-cpp có thể đã khai báo.
set_property(GLOBAL APPEND PROPERTY JOB_POOLS mangalocal_heavy=2)
set_target_properties(mangalocal_native PROPERTIES JOB_POOL_COMPILE mangalocal_heavy)
