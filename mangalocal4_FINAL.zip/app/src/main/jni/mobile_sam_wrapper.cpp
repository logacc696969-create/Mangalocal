// MobileSAM click-to-mask (mục 21 TECHNICAL_STATUS.md — "Inpaint Anything"
// cho UI mask thủ công ở PHASE CUỐI, sau khi mọi quy trình tự động vẫn
// sai). User chạm 1 điểm trên vùng lỗi -> trả về mask chính xác theo đúng
// khối đó -> mask này feed thẳng vào sdImg2Img() ĐÃ CÓ (mục 16) — CÙNG 1
// inpainting với auto-fix mặt/tay, không viết inpainting riêng, đúng yêu
// cầu.
//
// TẠI SAO MOBILESAM: đã tra cứu xác nhận (không đoán) — nhẹ nhất họ SAM
// cho mobile (<10M tham số, encoder TinyViT), CHÍNH XÁC HƠN và NHANH HƠN
// FastSAM (dù FastSAM dùng kiến trúc YOLOv8-seg — không có lý do chọn
// FastSAM ở đây dù đang ưu tiên YOLO cho các việc khác). Tài liệu chính
// thức samexporter: "MobileSAM is the best choice for CPU-only environments
// with tight latency requirements" — đúng môi trường CPU-only trên di động.
//
// ĐÁNH ĐỔI KỸ THUẬT ĐÃ CHỌN (ghi rõ để không quên): encoder chạy LẠI MỖI
// LẦN CLICK (không cache image_embeddings qua nhiều click) — đơn giản hoá
// native code, chấp nhận được vì đây là tool DÙNG HIẾM (chỉ khi auto-fix
// vẫn sai), không phải tương tác liên tục thời gian thực. Muốn tối ưu sau
// (cache embeddings, chỉ decoder chạy lại mỗi click) thì sửa handle giữ
// image_embeddings qua nhiều lần gọi — CHƯA làm.
//
// mục 288 — ĐÃ CHẠY THẬT lần đầu (export_mobilesam.py -> mnnconvert -> MNN 3.6.1, ảnh bus.jpg) và phát hiện 4 lỗi của bản cũ:
//   (1) encoder ONNX nhận tensor 3 chiều HWC [cao,rộng,3], bản cũ nạp NCHW 4 chiều => MNN "Broad cast error", đầu ra rỗng => click-to-mask KHÔNG CHẠY;
//   (2) MNN::Interpreter từ chối tạo session cho decoder (shape phụ thuộc nội dung đầu vào) => buộc dùng Module API;
//   (3) toạ độ click phải ở hệ 1024 + điểm đệm nhãn -1 (bản cũ truyền toạ độ ảnh gốc);
//   (4) đầu ra `masks` của đồ thị lệch 6,7%–27,9% so với PyTorch => dùng low_res_masks + hậu xử lý native.
// Toàn bộ logic nằm trong mobile_sam_core.hpp / mobile_sam_post.hpp (test được bằng g++, xem tools/test_mobile_sam_core.py); file này chỉ còn JNI + đọc/ghi ảnh.
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <memory>

#include "mobile_sam_core.hpp"

extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
int            stbi_write_png(const char*, int, int, int, const void*, int);
}

#define TAG "MobileSAM_MNN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

struct MobileSamHandle {
    mobilesam::Engine engine;
    bool ok = false;

    explicit MobileSamHandle(const std::string& modelDir) {
        const std::string encPath = modelDir + "/mobile_sam_encoder.mnn";
        const std::string decPath = modelDir + "/mobile_sam_decoder.mnn";
        std::string err;
        if (!engine.load(encPath, decPath, /*numThread=*/4, &err)) { LOGE("nap MobileSAM that bai: %s", err.c_str()); return; }
        ok = true;
        LOGI("MobileSAM (MNN Module API) nap OK: %s / %s", encPath.c_str(), decPath.c_str());
    }
};

static std::string j2s_ms(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_mobileSamInit(JNIEnv* e, jobject, jstring jDir) {
    auto* h = new MobileSamHandle(j2s_ms(e, jDir));
    if (!h->ok) { delete h; return 0; }
    return reinterpret_cast<jlong>(h);
}

// Trả về đường dẫn file PNG mask đã ghi (trắng = vùng cần inpaint, đen = giữ nguyên — CÙNG QUY ƯỚC với buildMaskFile() trong MangaPipeline.kt
// để feed thẳng vào sdImg2Img() không cần chuyển đổi gì thêm). Rỗng ("") nếu lỗi.
// clickX/clickY: toạ độ PIXEL theo đúng ảnh gốc tại jImg; hàm tự quy đổi sang hệ 1024 mà decoder cần.
extern "C" JNIEXPORT jstring JNICALL
Java_com_mangalocal_pipeline_NativeBridge_mobileSamClickToMask(
    JNIEnv* e, jobject, jlong ptr, jstring jImg, jfloat clickX, jfloat clickY, jstring jOutMask) {
    auto* h = reinterpret_cast<MobileSamHandle*>(ptr);
    if (!h || !h->ok) { LOGE("mobileSamClickToMask goi khi chua init"); return e->NewStringUTF(""); }

    const std::string imgPath = j2s_ms(e, jImg);
    const std::string outPath = j2s_ms(e, jOutMask);
    int W = 0, H = 0, c = 0;
    unsigned char* pixels = stbi_load(imgPath.c_str(), &W, &H, &c, 3);
    if (!pixels) { LOGE("khong doc duoc anh: %s", imgPath.c_str()); return e->NewStringUTF(""); }

    std::vector<unsigned char> mask; std::string err; float iou = -1.f;
    const bool good = h->engine.clickToMask(pixels, W, H, clickX, clickY, &mask, &err, &iou);
    stbi_image_free(pixels);
    if (!good) { LOGE("click-to-mask that bai: %s", err.c_str()); return e->NewStringUTF(""); }

    if (!stbi_write_png(outPath.c_str(), W, H, 1, mask.data(), W)) { LOGE("khong ghi duoc mask: %s", outPath.c_str()); return e->NewStringUTF(""); }
    LOGI("click-to-mask xong: %s (%dx%d) iou_pred=%.3f", outPath.c_str(), W, H, iou);
    return e->NewStringUTF(outPath.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_mobileSamFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<MobileSamHandle*>(ptr);
}
