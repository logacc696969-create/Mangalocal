// regional_prompting.cpp — mục 56 TECHNICAL_STATUS.md: Regional Prompting
// THẬT (gán PROMPT CHỮ riêng cho từng vùng ảnh — ưu tiên #1 trong bảng gap
// user dán vào). Đối tác native của tools/export_ipa_controlnet_regional_unet.py
// — ĐỌC DOCSTRING FILE ĐÓ TRƯỚC (giải thích đầy đủ nguồn thật đã tra, cơ chế
// splice theo cột, và lý do trace batch=2 khác hẳn mục 51/52).
//
// KHÁC ip_adapter.cpp (PipelineSd15CpuAugmented dùng onBeforeUnetRun() hook
// nhẹ, GIỮ NGUYÊN input "encoder_hidden_states" cũ + thêm input tuỳ chọn):
// model regional có input HOÀN TOÀN KHÁC tên/shape (không có
// "encoder_hidden_states", thay bằng "uncond_encoder_hidden_states" +
// "region_encoder_hidden_states") — PHẢI override thẳng beginDenoise()/
// runUnetStep() (không chỉ hook nhẹ), vì code gốc PipelineSd15Cpu::
// beginDenoise()/runUnetStep() gọi getSessionInput(..., "encoder_hidden_states")
// KHÔNG kiểm tra null trước khi dùng — dùng thẳng lên model regional (thiếu
// input đó) sẽ crash null-deref ngay, không phải lỗi mềm.

#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <memory>
#include <fstream>
#include <cmath>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

#include "sd_engine/Config.hpp"
#include "sd_engine/MnnUtils.hpp"
#include "sd_engine/PipelineSd15Cpu.hpp"

#define TAG "MangaLocal_Regional"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::string j2s_rp(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c);
    e->ReleaseStringUTFChars(js, c);
    return s;
}

// PipelineSd15CpuRegional — kế thừa CLIP/VAE encode/decode NGUYÊN VẸN từ
// PipelineSd15Cpu (không đổi gì ở đó, model clip_v2.mnn/vae*.mnn dùng
// CHUNG với mọi pipeline khác của dự án — chỉ UNet + cách gọi nó khác).
class PipelineSd15CpuRegional : public PipelineSd15Cpu {
public:
    PipelineSd15CpuRegional(TextEncoder &text_encoder, const std::string &model_dir,
                             std::string clip_path, std::string unet_regional_path,
                             std::string vae_decoder_path, std::string vae_encoder_path,
                             int num_regions)
        : PipelineSd15Cpu(text_encoder, model_dir, clip_path, unet_regional_path,
                          vae_decoder_path, vae_encoder_path, /*use_v_pred=*/false),
          num_regions_(num_regions) {}

    // Gọi 1 lần trước khi sinh ảnh — uncondEmbed: 1×77×768 (prompt âm,
    // toàn ảnh). regionEmbeds: N×77×768 (1 hàng/vùng, ĐÚNG THỨ TỰ cột
    // trái->phải — vùng 0 = cột trái nhất). controlHint: canvas RGB pose
    // (giống bản gốc/mask), controlSize: kích thước ảnh (PHẢI vuông, PHẢI
    // khớp --image_size lúc export model này — xem GIỚI HẠN THẬT trong
    // export script).
    void setConditioning(const std::vector<float>& uncondEmbed,
                          const std::vector<float>& regionEmbeds,
                          const std::vector<uint8_t>& controlHintRgb, int controlSize) {
        uncondEmbed_ = uncondEmbed;
        regionEmbeds_ = regionEmbeds;
        controlHintRgb_ = controlHintRgb;
        controlSize_ = controlSize;
        hasConditioning_ = true;
    }

protected:
    // Override THẲNG (không dùng onBeforeUnetRun hook) — input hoàn toàn
    // khác pattern base class, xem giải thích đầu file.
    void beginDenoise(const GenerationRequest &req) override {
        unet_interpreter_ = createMnnInterpreterMmap(unet_path_.c_str());
        if (!unet_interpreter_) throw std::runtime_error("Failed to create MNN UNET (regional) interpreter!");

        unet_session_ = createMnnSession(unet_interpreter_, sessionOptions(req, "unet_regional_cache"));
        if (!unet_session_) throw std::runtime_error("Failed to create MNN UNET (regional) session!");

        auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
        auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
        auto uncondIn = unet_interpreter_->getSessionInput(unet_session_, "uncond_encoder_hidden_states");
        auto regionIn = unet_interpreter_->getSessionInput(unet_session_, "region_encoder_hidden_states");
        auto hintIn = unet_interpreter_->getSessionInput(unet_session_, "control_hint");
        if (!samp || !ts || !uncondIn || !regionIn || !hintIn) {
            throw std::runtime_error(
                "Model unet_regional_*.mnn thieu 1 trong cac input bat buoc "
                "(sample/timestep/uncond_encoder_hidden_states/region_encoder_hidden_states/control_hint) "
                "- co dung dung file model regional khong?");
        }

        unet_interpreter_->resizeTensor(samp, {2, 4, req.height / 8, req.width / 8});
        unet_interpreter_->resizeTensor(ts, {1});
        unet_interpreter_->resizeTensor(uncondIn, {1, 77, text_embedding_size});
        unet_interpreter_->resizeTensor(regionIn, {num_regions_, 77, text_embedding_size});
        unet_interpreter_->resizeTensor(hintIn, {2, 3, req.height, req.width});
        unet_interpreter_->resizeSession(unet_session_);
        if (req.use_opencl) unet_interpreter_->updateCacheFile(unet_session_);
        unet_interpreter_->releaseModel();
    }

    void runUnetStep(const GenerationRequest &req, const float *latents_batch2,
                     float timestep_f, bool /*skip_uncond*/, Conditioning & /*cond*/,
                     float *out_batch2) override {
        if (!hasConditioning_) {
            LOGE("runUnetStep (regional) goi truoc setConditioning() - anh se sai/rac");
        }
        const int timestep = static_cast<int>(timestep_f);
        auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
        auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
        auto uncondIn = unet_interpreter_->getSessionInput(unet_session_, "uncond_encoder_hidden_states");
        auto regionIn = unet_interpreter_->getSessionInput(unet_session_, "region_encoder_hidden_states");
        auto hintIn = unet_interpreter_->getSessionInput(unet_session_, "control_hint");

        size_t batch2_count = (size_t)2 * 4 * (req.height / 8) * (req.width / 8);
        MNN::Tensor samp_h(samp, MNN::Tensor::CAFFE);
        MNN::Tensor ts_h(ts, MNN::Tensor::CAFFE);
        MNN::Tensor uncond_h(uncondIn, MNN::Tensor::CAFFE);
        MNN::Tensor region_h(regionIn, MNN::Tensor::CAFFE);
        MNN::Tensor hint_h(hintIn, MNN::Tensor::CAFFE);

        memcpy(samp_h.host<float>(), latents_batch2, batch2_count * sizeof(float));
        memcpy(ts_h.host<int>(), &timestep, sizeof(int));
        memcpy(uncond_h.host<float>(), uncondEmbed_.data(),
               std::min(uncondEmbed_.size(), (size_t)uncond_h.elementSize()) * sizeof(float));
        memcpy(region_h.host<float>(), regionEmbeds_.data(),
               std::min(regionEmbeds_.size(), (size_t)region_h.elementSize()) * sizeof(float));
        // control_hint — ảnh RGB khung xương, chuẩn hoá [0,1], NCHW — ĐÚNG
        // pattern đã xác nhận trong ip_adapter.cpp::onBeforeUnetRun() (copy
        // nguyên, không suy đoán lại), lặp cho CẢ 2 batch (uncond & cond
        // dùng CHUNG 1 pose — điều kiện không gian, không liên quan gì tới
        // vùng prompt).
        int size = controlSize_;
        size_t plane = (size_t)3 * size * size;
        for (int b = 0; b < 2; b++) {
            for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
                const uint8_t *p = controlHintRgb_.data() + ((size_t)y * size + x) * 3;
                for (int ch = 0; ch < 3; ch++)
                    hint_h.host<float>()[b * plane + (size_t)ch * size * size + y * size + x] = p[ch] / 255.f;
            }
        }

        samp->copyFromHostTensor(&samp_h);
        ts->copyFromHostTensor(&ts_h);
        uncondIn->copyFromHostTensor(&uncond_h);
        regionIn->copyFromHostTensor(&region_h);
        hintIn->copyFromHostTensor(&hint_h);

        unet_interpreter_->runSession(unet_session_);

        auto output = unet_interpreter_->getSessionOutput(unet_session_, "out_sample");
        MNN::Tensor out_h(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&out_h);
        memcpy(out_batch2, out_h.host<float>(), batch2_count * sizeof(float));
    }

private:
    int num_regions_;
    bool hasConditioning_ = false;
    std::vector<float> uncondEmbed_;
    std::vector<float> regionEmbeds_;
    std::vector<uint8_t> controlHintRgb_;  // canvas RGB thô 0-255, HWC — ĐÚNG format renderSkeletons() ở ip_adapter.cpp trả về, chuẩn hoá [0,1] lúc copy vào tensor trong runUnetStep()
    int controlSize_ = 512;
};

// Encode 1 chuỗi prompt thô (KHÔNG có emphasis weighting phức tạp, vì
// regional prompting không đi qua ProcessedPromptPair 2-vế thông thường —
// tái dùng processPromptPair(prompt, "") rồi lấy .positive_embeddings, ép
// buộc dùng đúng pipeline tokenize+weight THẬT đã có, không tự viết
// tokenizer riêng) rồi chạy qua clip_v2.mnn để ra hidden_state cuối cùng
// 77×768 — TÁI DÙNG đúng logic run_side() bên trong PipelineSd15Cpu::
// encodeText() (không public, nên viết lại 1 bản NGẮN Ở ĐÂY, cùng thuật
// toán chứ không suy đoán).
static std::vector<float> encodeOnePrompt(TextEncoder &textEncoder, MNN::Interpreter *clipInterp,
                                           MNN::Session *clipSession, int textEmbeddingSize,
                                           const std::string &prompt) {
    ProcessedPromptPair pair = textEncoder.processPromptPair(prompt, "");
    auto input = clipInterp->getSessionInput(clipSession, "input_embedding");
    memcpy(input->host<float>(), pair.positive_embeddings.data(),
           77 * textEmbeddingSize * sizeof(float));
    clipInterp->runSession(clipSession);
    auto out = clipInterp->getSessionOutput(clipSession, "last_hidden_state");
    std::vector<float> result(77 * textEmbeddingSize);
    memcpy(result.data(), out->host<float>(), result.size() * sizeof(float));
    return result;
}

struct SdRegionalHandle {
    std::unique_ptr<TextEncoder> textEncoder;
    std::unique_ptr<PipelineSd15CpuRegional> pipeline;
    std::string clipPath;  // giữ lại để tự mở phiên CLIP riêng khi encode N region prompt (xem sdTxt2ImgRegional)
    // mục 61 TECHNICAL_STATUS.md — trước đây hardcode use_opencl=false, xem
    // ghi chú tương ứng trong SdAugmentedHandle (ip_adapter.cpp).
    bool useOpenCL = false;
    bool useNpu = false;
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdInitRegional(JNIEnv* e, jobject,
    jstring jModelDir, jstring jClip, jstring jUnetRegional, jstring jVaeDec,
    jstring jVaeEnc, jstring jTokenizer, jstring jEmbeddingsDir, jint jNumRegions,
    jboolean jUseOpenCL, jboolean jUseNpu) {

    std::string dir = j2s_rp(e, jModelDir);
    try {
        auto handle = std::make_unique<SdRegionalHandle>();
        handle->useOpenCL = jUseOpenCL;
        handle->useNpu = jUseNpu;
        handle->textEncoder = std::make_unique<TextEncoder>(false, false);
        handle->textEncoder->loadTokenizer(j2s_rp(e, jTokenizer));
        handle->textEncoder->loadEmbeddingTables(dir);
        std::string embeddingsDir = j2s_rp(e, jEmbeddingsDir);
        if (!embeddingsDir.empty()) handle->textEncoder->loadTextualInversions(embeddingsDir);

        handle->clipPath = j2s_rp(e, jClip);
        handle->pipeline = std::make_unique<PipelineSd15CpuRegional>(
            *handle->textEncoder, dir, handle->clipPath, j2s_rp(e, jUnetRegional),
            j2s_rp(e, jVaeDec), j2s_rp(e, jVaeEnc), (int)jNumRegions);
        if (!handle->pipeline->initialize()) { LOGE("PipelineSd15CpuRegional initialize() fail"); return 0; }

        return reinterpret_cast<jlong>(handle.release());
    } catch (const std::exception &ex) {
        LOGE("sdInitRegional loi: %s", ex.what());
        return 0;
    }
}

// jRegionPrompts: mảng String[] N phần tử, THỨ TỰ trái->phải (vùng 0 = cột
// trái nhất — ĐÚNG khớp thứ tự đã export trong tools/
// export_ipa_controlnet_regional_unet.py). jSkeletonData: giống mọi hàm
// pose khác trong dự án (renderSkeletons() ở ip_adapter.cpp) — NHƯNG file
// này KHÔNG include ip_adapter.cpp (tránh phụ thuộc chéo 2 file .cpp) nên
// KHÔNG tái dùng được renderSkeletons() trực tiếp — controlHint ở đây tạm
// nhận THẲNG buffer RGB đã dựng sẵn từ phía Kotlin/JNI khác (xem TECHNICAL_
// STATUS.md mục 56 phần "CHƯA làm" — đây là 1 hạn chế THẬT, không phải
// thiếu sót ẩn).
// mục 134 TECHNICAL_STATUS.md — nối progress callback per-step cho nhánh
// Regional Prompting (trước đây KHÔNG có, Kotlin phải báo tiến trình giả
// "0 rồi nhảy thẳng lên steps"). Thêm tham số `cb` CUỐI danh sách, copy
// NGUYÊN VĂN khuôn mẫu AttachCurrentThread/DetachCurrentThread đã dùng ở
// ip_adapter.cpp (sdImg2ImgWithReferenceAndPose) — file này KHÔNG include
// ip_adapter.cpp (tránh phụ thuộc chéo, xem comment đầu file) nên viết lại
// đúng cùng đoạn code thay vì gọi hàm chung, không phải phát minh cách mới.
extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgRegional(JNIEnv* e, jobject,
    jlong ptr, jobjectArray jRegionPrompts, jstring jNegPrompt,
    jbyteArray jControlHintRgb, jint controlSize,
    jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut, jobject cb) {

    auto *handle = reinterpret_cast<SdRegionalHandle *>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgRegional: chua init"); return JNI_FALSE; }

    jsize numRegions = jRegionPrompts ? e->GetArrayLength(jRegionPrompts) : 0;
    if (numRegions < 2) { LOGE("sdTxt2ImgRegional: can it nhat 2 vung prompt"); return JNI_FALSE; }

    // Mở 1 phiên CLIP TẠM để encode N+1 prompt (N vùng + 1 âm) — dùng ĐÚNG
    // helper createMnnInterpreterMmap()/createMnnSession() mà
    // PipelineSd15Cpu::encodeText() cũng dùng (MnnUtils.hpp, protected
    // nhưng encodeText() bản thân không fit use-case N-prompt-độc-lập của
    // regional prompting — xem comment encodeOnePrompt() ở trên — nên viết
    // lại vòng lặp riêng, TÁI DÙNG đúng 2 helper tạo interpreter/session).
    MNN::Interpreter *clipInterp = createMnnInterpreterMmap(handle->clipPath.c_str());
    if (!clipInterp) { LOGE("Khong mo duoc clip_v2.mnn"); return JNI_FALSE; }
    MnnSessionOptions clipOpts;  // CLIP luôn chạy CPU, giống encodeText()
    MNN::Session *clipSession = createMnnSession(clipInterp, clipOpts);
    if (!clipSession) { delete clipInterp; LOGE("Khong tao duoc clip session"); return JNI_FALSE; }
    auto clipInput = clipInterp->getSessionInput(clipSession, "input_embedding");
    clipInterp->resizeTensor(clipInput, {1, 77, text_embedding_size});
    clipInterp->resizeSession(clipSession);
    clipInterp->releaseModel();

    std::vector<float> uncondEmbed = encodeOnePrompt(
        *handle->textEncoder, clipInterp, clipSession, text_embedding_size, j2s_rp(e, jNegPrompt));

    std::vector<float> regionEmbeds;
    regionEmbeds.reserve((size_t)numRegions * 77 * text_embedding_size);
    for (jsize i = 0; i < numRegions; i++) {
        auto jp = (jstring)e->GetObjectArrayElement(jRegionPrompts, i);
        std::vector<float> emb = encodeOnePrompt(
            *handle->textEncoder, clipInterp, clipSession, text_embedding_size, j2s_rp(e, jp));
        e->DeleteLocalRef(jp);
        regionEmbeds.insert(regionEmbeds.end(), emb.begin(), emb.end());
    }
    clipInterp->releaseSession(clipSession);
    delete clipInterp;

    std::vector<uint8_t> controlHint;  // canvas RGB thô 0-255, HWC — Kotlin dựng sẵn (dự án CHƯA có hàm dựng skeleton canvas dùng chung giữa 2 file .cpp, xem TECHNICAL_STATUS.md mục 56 phần "CHƯA làm")
    if (jControlHintRgb) {
        jsize n = e->GetArrayLength(jControlHintRgb);
        controlHint.resize(n);
        jbyte *buf = e->GetByteArrayElements(jControlHintRgb, nullptr);
        memcpy(controlHint.data(), buf, n);
        e->ReleaseByteArrayElements(jControlHintRgb, buf, JNI_ABORT);
    }

    handle->pipeline->setConditioning(uncondEmbed, regionEmbeds, controlHint, controlSize);

    GenerationRequest req;
    req.prompt = "";  // KHÔNG dùng — model regional lấy prompt qua setConditioning(), req.prompt chỉ giữ chỗ cho GenerationRequest hợp lệ
    req.negative_prompt = "";
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = handle->useOpenCL; req.use_npu = handle->useNpu; req.img2img = false;

    // Progress callback — mục 134, khuôn mẫu GIỐNG HỆT các hàm trong
    // ip_adapter.cpp (viết lại tại chỗ, không include chéo file — xem
    // comment đầu file).
    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    auto progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_rp(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char *>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
    } catch (const std::exception &ex) {
        LOGE("generate() (regional) loi: %s", ex.what());
    }
    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdFreeRegional(JNIEnv *, jobject, jlong ptr) {
    delete reinterpret_cast<SdRegionalHandle *>(ptr);
}
