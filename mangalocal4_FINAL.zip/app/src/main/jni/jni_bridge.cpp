#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>

#include <sstream>
#include <memory>
#include <mutex>    // mục 116 TECHNICAL_STATUS.md — generateMutex chống race condition
#include <fstream>  // mục 116 TECHNICAL_STATUS.md — dò config.json/llm_config.json
// llama.h ĐÃ BỎ — chuyển LLM sang MNN-LLM (mở lại quyết định cũ, xem
// comment trong CMakeLists.txt). Header thật của MNN-LLM nằm ở
// transformers/llm/engine/include/llm/llm.hpp — API createLLM/load/
// response đã xác nhận qua tài liệu chính thức MNN (mnn-docs.readthedocs.io),
// KHÔNG phải đoán như phần diffusion.
#include "llm/llm.hpp"
// stable-diffusion.h / story_consistency.h ĐÃ BỎ — chuyển engine sinh ảnh
// sang MNN-Diffusion (xem handoff mục 3 và 8). Phần SD thật sẽ nằm ở
// jni/mnn_diffusion_pipeline.cpp, CHƯA VIẾT — đang chờ bước build in ra
// header thật của MNN transformers/diffusion (xem build.yml, step
// "Print MNN diffusion headers"). Các hàm sd* dưới đây tạm thời là STUB
// trả về thất bại có log rõ ràng, để APK vẫn build được và các phần khác
// (LLM, ESRGAN, YOLO, UI) test được ngay, không phải chờ toàn bộ pipeline
// sinh ảnh viết xong mới có APK chạy được.

#define TAG "MangaLocal"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::string j2s(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

// ── LLM (MNN-LLM) ──────────────────────────────────────────────────────────
//
// Backend fallback: thử NPU (QNN) trước -> GPU (OpenCL) -> CPU. Đây là
// cùng cơ chế "thử rồi bắt lỗi, không whitelist chip cứng" đã áp dụng cho
// phần diffusion. Với build hiện tại (MANGALOCAL_ENABLE_QNN=OFF mặc định,
// xem CMakeLists.txt), nhánh "qnn" sẽ luôn rơi xuống "opencl" — vẫn thỏa
// yêu cầu tối thiểu GPU. Khi có QNN SDK thật và bật MANGALOCAL_ENABLE_QNN,
// nhánh "qnn" mới có cơ hội thành công thật.
//
// THAM SỐ nGpuLayers (giữ tên cũ từ thời llama.cpp để không phải sửa
// LLMParser.kt/RuntimeOptimizer.kt): với MNN-LLM không có khái niệm
// "offload từng layer" như llama.cpp — MNN chọn NGUYÊN backend cho cả
// model. Ở đây diễn giải lại: nGpuLayers > 0 nghĩa là "được phép thử
// GPU/NPU", 0 nghĩa là "ép CPU" (dùng khi cần chẩn đoán lỗi, giống ý
// nghĩa cũ). Ý NGHĨA SỐ LƯỢNG LAYER KHÔNG CÒN ÁP DỤNG — cần xem lại
// RuntimeOptimizer.kt có tính toán gì dựa trên độ lớn con số đó không,
// nếu có phải sửa logic bên Kotlin cho khớp diễn giải mới (0/greater-than-0
// thay vì số layer cụ thể).

struct MnnLlmHandle {
    std::unique_ptr<MNN::Transformer::Llm> llm;
    // mục 116 TECHNICAL_STATUS.md — LocalNovel_Architecture_Spec.md mục
    // 5.67: 2 lệnh generate() chạy ĐÈ LÊN NHAU trên CÙNG 1 handle gây
    // heap corruption thật (30 SIGSEGV liên tiếp, đã xác nhận qua log
    // thật của dự án đó, backtrace rơi đúng vào MNN::ThreadPool). MNN-LLM
    // (chính engine MangaLocal đang dùng, xác nhận qua comment "chuyển
    // LLM sang MNN-LLM" đầu file) KHÔNG được thiết kế để gọi response()
    // đồng thời từ nhiều luồng trên CÙNG 1 instance Llm — mutate chung
    // KV-cache/buffer ThreadPool/tensor nội bộ. MangaLocal trước mục này
    // KHÔNG có khoá nào quanh llamaGenerate() — rủi ro CÓ THẬT, đặc biệt
    // sau khi mục 114 (TECHNICAL_STATUS.md) thêm cache LLMParser cho nút
    // "Dịch" (nhiều lần bấm liên tiếp giờ dùng CHUNG 1 ctx/handle thay vì
    // luôn tạo instance mới như trước — vô tình MỞ ra đúng loại race
    // condition này, dù trước mục 114 rủi ro thấp hơn vì mỗi lần bấm là
    // 1 handle riêng). std::mutex đơn giản, đủ dùng (không cần đếm lồng
    // như MnnBridge.kt của LocalNovel vì Kotlin coroutine gọi generate()
    // là hàm lá, không có khái niệm pipeline lồng nhau ở tầng JNI này).
    std::mutex generateMutex;
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_llamaInit(JNIEnv* e, jobject, jstring jPath, jint nT, jint nCtx, jint nGpuLayers) {
    using namespace MNN::Transformer;
    std::string rawPath = j2s(e, jPath);

    // mục 116 TECHNICAL_STATUS.md — LocalNovel_Architecture_Spec.md mục
    // 5.33/5.35: Llm::createLLM() cần đường dẫn tới 1 FILE config.json
    // THẬT, KHÔNG PHẢI thư mục — dự án đó từng truyền thẳng đường dẫn
    // thư mục model (y hệt cách MangaLocal đang làm ở đây trước khi vá:
    // rawPath = llmModelPath từ Settings, luôn là 1 FILE .gguf theo
    // scanLlmModels() cũ) và load() trả về false/rỗng suốt nhiều vòng
    // debug trước khi tìm ra nguyên nhân. QUAN TRỌNG HƠN: MNN-LLM không
    // đọc GGUF trực tiếp — .gguf là định dạng CỦA llama.cpp, MNN cần
    // định dạng converted riêng (config.json tham chiếu weight .mnn qua
    // llmexport.py chính thức của MNN, xem README transformers/llm của
    // alibaba/MNN). Nếu rawPath là 1 file .gguf, đoạn dò dưới đây sẽ
    // KHÔNG tìm thấy config.json (đúng — vì nó thực sự không tồn tại
    // cho định dạng gguf), createLLM() sẽ nhận đúng thông báo lỗi rõ
    // ràng thay vì im lặng thất bại như trước.
    //
    // Thứ tự ưu tiên ĐÚNG theo tài liệu chính thức MNN (mục 5.35 LocalNovel
    // đã tra cứu và xác nhận qua alibaba/MNN/transformers/README.md):
    // config.json là điểm vào THẬT dùng bởi createLLM()/llm_demo; llm_config.json
    // chỉ là file được config.json tự tham chiếu bên trong (field "llm_config"),
    // KHÔNG phải điểm vào trực tiếp — ưu tiên NGƯỢC (llm_config.json trước)
    // là sai, LocalNovel đã tự mắc lỗi này 1 lần (mục 33) rồi tự sửa lại
    // (mục 35) — áp dụng đúng thứ tự đã sửa ngay từ đầu ở đây, không lặp
    // lại đúng lỗi đã biết trước.
    std::string configPath = rawPath;
    if (rawPath.size() < 5 || rawPath.substr(rawPath.size() - 5) != ".json") {
        // rawPath không phải sẵn 1 file .json -> coi là thư mục, dò bên trong
        std::string tryConfig = rawPath + "/config.json";
        std::string tryLlmConfig = rawPath + "/llm_config.json";
        std::ifstream fConfig(tryConfig);
        std::ifstream fLlmConfig(tryLlmConfig);
        if (fConfig.good()) {
            configPath = tryConfig;
        } else if (fLlmConfig.good()) {
            configPath = tryLlmConfig;
            LOGI("Khong thay config.json, dung llm_config.json du phong: %s", tryLlmConfig.c_str());
        } else {
            LOGE("KHONG TIM THAY config.json/llm_config.json trong: %s "
                 "(neu day la file .gguf: MNN-LLM KHONG doc GGUF truc tiep, "
                 "can convert qua llmexport.py chinh thuc cua MNN sang dinh "
                 "dang config.json + weight .mnn truoc)", rawPath.c_str());
            return 0;
        }
    }
    auto* handle = new MnnLlmHandle();
    handle->llm.reset(Llm::createLLM(configPath));
    if (!handle->llm) {
        LOGE("MNN-LLM createLLM that bai: %s", configPath.c_str());
        delete handle;
        return 0;
    }

    bool loaded = false;
    // mục 116 TECHNICAL_STATUS.md — LocalNovel_Architecture_Spec.md mục
    // 5.37/5.54: "use_mmap": true (tài liệu chính thức MNN khuyến nghị
    // BẬT cho thiết bị di động, tránh cấp phát 1 khối RAM liên tục lớn
    // gây OOM khi nạp model vài GB) VÀ, riêng cho OpenCL, 3 tham số tăng
    // tốc thật LocalNovel xác nhận qua tài liệu chính thức MNN:
    // "precision":"low" (ưu tiên fp16 trên GPU Adreno di động),
    // "memory":"low" (lượng tử hoá runtime, giảm băng thông bộ nhớ — nút
    // thắt cổ chai LỚN NHẤT khi chạy LLM trên GPU di động, không phải
    // tốc độ tính toán thuần), "thread_num" (giá trị tài liệu MNN chỉ
    // định riêng cho suy luận OpenCL). Trước mục này, MangaLocal chỉ có
    // đúng "backend_type" — hoàn toàn không có 4 tham số trên.
    const char* kUseMmap = R"(, "use_mmap": true)";
    if (nGpuLayers > 0) {
        try {
            std::string qnnCfg = std::string(R"({"backend_type": "qnn")") + kUseMmap + "}";
            handle->llm->set_config(qnnCfg);
            handle->llm->load();
            LOGI("MNN-LLM nap OK voi backend QNN");
            loaded = true;
        } catch (const std::exception& qnnErr) {
            LOGI("QNN khong kha dung cho LLM (%s), thu OpenCL", qnnErr.what());
        }
        if (!loaded) {
            try {
                std::string openclCfg = std::string(
                    R"({"backend_type": "opencl", "precision": "low", "memory": "low", "thread_num": 68)"
                ) + kUseMmap + "}";
                handle->llm->set_config(openclCfg);
                handle->llm->load();
                LOGI("MNN-LLM nap OK voi backend OpenCL (GPU), da toi uu precision/memory/thread_num");
                loaded = true;
            } catch (const std::exception& glErr) {
                LOGI("OpenCL khong kha dung cho LLM (%s), roi ve CPU", glErr.what());
            }
        }
    }
    if (!loaded) {
        try {
            std::string cpuCfg = std::string(R"({"backend_type": "cpu")") + kUseMmap + "}";
            handle->llm->set_config(cpuCfg);
            handle->llm->load();
            LOGI("MNN-LLM nap OK voi backend CPU");
            loaded = true;
        } catch (const std::exception& cpuErr) {
            LOGE("MNN-LLM load() that bai ca CPU: %s", cpuErr.what());
        }
    }

    if (!loaded) { delete handle; return 0; }
    LOGI("LLM init xong: threads=%d ctx=%d gpu_layers(hint)=%d", nT, nCtx, nGpuLayers);
    return reinterpret_cast<jlong>(handle);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_mangalocal_pipeline_NativeBridge_llamaGenerate(JNIEnv* e, jobject, jlong ptr, jstring jp, jint maxTok, jfloat temp) {
    auto* h = reinterpret_cast<MnnLlmHandle*>(ptr);
    if (!h || !h->llm) { LOGE("llamaGenerate goi khi chua init"); return e->NewStringUTF(""); }

    // mục 116 TECHNICAL_STATUS.md — khoá chống 2 lệnh generate() chạy đè
    // lên nhau trên CÙNG 1 handle (xem giải thích đầy đủ ở comment
    // generateMutex trong struct MnnLlmHandle). Lệnh gọi thứ 2 trên CÙNG
    // ctx giờ CHỜ (xếp hàng) thay vì chạy song song làm hỏng bộ nhớ nội
    // bộ của Llm — mỗi LLMParser Kotlin có ctx RIÊNG (xem LLMParser.kt),
    // nên các tác vụ LLM ĐỘC LẬP (vd panel A dùng parser chính, panel B
    // dùng tearParser) vẫn chạy song song bình thường, khoá này CHỈ chặn
    // đúng trường hợp CÙNG 1 ctx bị gọi 2 lần chồng chéo (vd user bấm
    // liên tục nút "Dịch" dùng cachedTranslateParser, mục 114).
    std::lock_guard<std::mutex> lock(h->generateMutex);

    std::string prompt = j2s(e, jp);
    std::ostringstream out;
    try {
        // Chữ ký response() chính xác (số tham số, có nhận max_tokens hay
        // không) CHƯA kiểm chứng 100% — đây là điểm duy nhất trong đoạn
        // MNN-LLM này còn rủi ro, sẽ tự lộ ra ngay ở lỗi compile nếu sai,
        // khác với lỗi ngầm lúc runtime. Xem log build.yml step "Print
        // MNN LLM headers" nếu bước biên dịch báo lỗi ở dòng này.
        h->llm->response(prompt, &out, nullptr, maxTok);
    } catch (const std::exception& ex) {
        LOGE("MNN-LLM response loi: %s", ex.what());
        return e->NewStringUTF("");
    }
    return e->NewStringUTF(out.str().c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_llamaFree(JNIEnv*, jobject, jlong ptr) {
    auto* h = reinterpret_cast<MnnLlmHandle*>(ptr);
    delete h; // unique_ptr tự giải phóng Llm*
}

