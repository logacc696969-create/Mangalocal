// MiDaS-small — ước lượng độ sâu ĐƠN ẢNH (mục 232 TECHNICAL_STATUS.md).
// Hoàn thành phần native mà mục 221 cố ý bỏ dở (tools/export_midas_depth.py
// chỉ export ONNX, "chưa có native wrapper"). Bám SÁT ĐÚNG khuôn
// yolo_pose_wrapper.cpp (đã build PASS ở CI): cùng cách nạp MNN::Interpreter /
// Session / Tensor, cùng resize TAY bằng stbi_load (không dùng
// MNN::CV::ImageProcess chưa kiểm chứng), cùng fallback OpenCL -> CPU.
//
// Model: midas_small_depth.mnn, input [1,3,256,256] RGB (export cố định 256 —
// xem export_midas_depth.py), chuẩn hoá ImageNet mean/std như small_transform
// của intel-isl/MiDaS. Output là ĐỘ SÂU NGHỊCH ĐẢO TƯƠNG ĐỐI (giá trị LỚN =
// GẦN camera hơn), KHÔNG phải mét — đúng lưu ý #3 trong docstring script export.
//
// Hàm này trả về bản đồ đã CHUẨN HOÁ min-max về 0..1 (1 = gần nhất, 0 = xa
// nhất TRONG CHÍNH ẢNH ĐÓ) kích thước cố định 256x256, để Kotlin tự lấy mẫu
// tại từng khớp xương. Không đoán tên tensor: dùng getSessionInputAll /
// getSessionOutputAll và kiểm tra số phần tử output == 256*256; khác đi thì
// trả mảng RỖNG + log (fail rõ ràng thay vì đọc sai âm thầm).
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cstring>
#include <memory>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
}

#define TAG "MiDaS_MNN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

struct MidasWrapper {
    std::shared_ptr<MNN::Interpreter> net;
    MNN::Session* session = nullptr;
    static const int kSize = 256;
    bool ok = false;

    MidasWrapper(const std::string& modelDir) {
        std::string modelPath = modelDir + "/midas_small_depth.mnn";
        net.reset(MNN::Interpreter::createFromFile(modelPath.c_str()));
        if (!net) { LOGE("khong doc duoc model: %s", modelPath.c_str()); return; }

        MNN::ScheduleConfig config;
        config.type = MNN_FORWARD_OPENCL;
        config.numThread = 4;
        MNN::BackendConfig backendConfig;
        backendConfig.precision = MNN::BackendConfig::Precision_Low;
        config.backendConfig = &backendConfig;

        session = net->createSession(config);
        if (!session) {
            LOGE("createSession OpenCL fail, roi ve CPU");
            config.type = MNN_FORWARD_CPU;
            session = net->createSession(config);
        }
        if (!session) { LOGE("createSession CPU cung fail"); return; }
        ok = true;
        LOGI("MiDaS-small (MNN) nap OK: %s", modelPath.c_str());
    }

    std::vector<float> estimate(const std::string& imagePath) {
        std::vector<float> result;
        if (!ok) { LOGE("estimate goi khi chua init xong"); return result; }

        int w, h, c;
        unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("load fail: %s", imagePath.c_str()); return result; }

        // Resize thẳng (kéo giãn) về 256x256 — cùng cách export cố định 256x256
        // không giữ tỉ lệ; tỉ lệ khung hình KHÔNG ảnh hưởng thứ tự gần/xa tương đối.
        std::vector<float> chw((size_t)3 * kSize * kSize);
        const float mean[3] = {0.485f, 0.456f, 0.406f};
        const float stdv[3] = {0.229f, 0.224f, 0.225f};
        for (int y = 0; y < kSize; y++) {
            int srcY = std::min(h - 1, (int)((float)y * h / kSize));
            for (int x = 0; x < kSize; x++) {
                int srcX = std::min(w - 1, (int)((float)x * w / kSize));
                const unsigned char* sp = data + ((size_t)srcY * w + srcX) * 3;
                for (int ch = 0; ch < 3; ch++)
                    chw[(size_t)ch * kSize * kSize + (size_t)y * kSize + x] = (sp[ch] / 255.f - mean[ch]) / stdv[ch];
            }
        }
        stbi_image_free(data);

        auto inputs = net->getSessionInputAll(session);
        if (inputs.empty()) { LOGE("model khong co input tensor"); return result; }
        MNN::Tensor* input = inputs.begin()->second;
        net->resizeTensor(input, {1, 3, kSize, kSize});
        net->resizeSession(session);

        MNN::Tensor hostIn(input, MNN::Tensor::CAFFE);
        std::memcpy(hostIn.host<float>(), chw.data(), chw.size() * sizeof(float));
        input->copyFromHostTensor(&hostIn);

        net->runSession(session);

        auto outputs = net->getSessionOutputAll(session);
        if (outputs.empty()) { LOGE("model khong co output tensor"); return result; }
        MNN::Tensor* output = outputs.begin()->second;
        MNN::Tensor hostOut(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&hostOut);

        long count = 1;
        for (int d : hostOut.shape()) count *= d;
        if (count != (long)kSize * kSize) {
            LOGE("output co %ld phan tu, ky vong %d — model .mnn co dung MiDaS-small 256 khong?", count, kSize * kSize);
            return result;
        }
        const float* raw = hostOut.host<float>();
        float mn = raw[0], mx = raw[0];
        for (long i = 1; i < count; i++) { mn = std::min(mn, raw[i]); mx = std::max(mx, raw[i]); }
        float range = mx - mn;
        result.resize((size_t)count);
        if (range < 1e-6f) { std::fill(result.begin(), result.end(), 0.5f); return result; }
        for (long i = 0; i < count; i++) result[(size_t)i] = (raw[i] - mn) / range; // 1 = gần nhất
        return result;
    }

    ~MidasWrapper() {
        if (session && net) net->releaseSession(session);
    }
};

static std::string j2s_md(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_midasInit(JNIEnv* e, jobject, jstring jDir) {
    auto* w = new MidasWrapper(j2s_md(e, jDir));
    if (!w->ok) { delete w; return 0; }
    return reinterpret_cast<jlong>(w);
}

// Trả về 256*256 float (hàng trước, cột sau), 0..1, 1 = gần camera nhất trong ảnh.
// Mảng rỗng nếu lỗi (Kotlin phải tự kiểm tra size == 0).
extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_mangalocal_pipeline_NativeBridge_midasEstimate(JNIEnv* e, jobject, jlong ptr, jstring jImg) {
    if (!ptr) return e->NewFloatArray(0);
    auto* m = reinterpret_cast<MidasWrapper*>(ptr);
    auto depth = m->estimate(j2s_md(e, jImg));
    jfloatArray result = e->NewFloatArray((jsize)depth.size());
    if (!depth.empty()) e->SetFloatArrayRegion(result, 0, (jsize)depth.size(), depth.data());
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_midasFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<MidasWrapper*>(ptr);
}
