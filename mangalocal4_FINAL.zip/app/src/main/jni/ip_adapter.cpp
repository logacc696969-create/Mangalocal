// ip_adapter.cpp — chạy UNet đã gộp sẵn IP-Adapter (giữ nhân vật) +
// ControlNet-OpenPose (giữ tư thế), xuất bởi tools/export_ipa_controlnet_unet.py.
//
// KHÔNG đoán API MNN ở đây — chỉ dùng lại đúng MNN::Interpreter/Session/
// Tensor đã dùng ổn định ở esrgan_wrapper.cpp/yolo_wrapper.cpp, cộng với
// Pipeline/PipelineSd15Cpu thật đã port. Phần "chưa chắc chắn" duy nhất là
// tên 2 tensor input mới ("control_hint", "ip_image_embeds") và tên output
// ("image_embeds") của ip_image_encoder.mnn — CHÍNH LÀ TÊN TÔI TỰ ĐẶT
// trong script export_ipa_controlnet_unet.py, nên đây không phải đoán API
// người khác, mà là tự thiết kế + tự dùng, khớp theo thiết kế.
//
// THƯ VIỆN TƯ THẾ (pose template): đọc từ pose_library.json thật (sinh ra
// bởi tools/extract_pose_library.py chạy MediaPipe Pose trên ảnh thật),
// KHÔNG còn hardcode toạ độ tự đoán trong file này nữa (xem namespace
// pose_templates bên dưới, hàm loadLibrary()).

#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <cmath>
#include <memory>
#include <map>
#include <fstream>
#include <algorithm>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

#include "sd_engine/PipelineSd15Cpu.hpp"
#include "sd_engine/TextEncoder.hpp"

extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
}
#include "sd_engine/stb_image_resize2.h"  // dùng include thật thay vì tự khai báo extern, tránh lệch chữ ký ABI

// mục 115 TECHNICAL_STATUS.md — 2 helper resize/mask ĐÃ tồn tại thật trong
// mnn_diffusion_pipeline.cpp (dùng cho sdImg2Img), external linkage (không
// có `static`), cùng biên dịch vào 1 thư viện .so — khai báo forward ở đây
// để tái dùng nguyên vẹn, KHÔNG copy-paste lại logic resize/mask (tránh 2
// bản triển khai lệch nhau theo thời gian).
std::vector<float> resizeToCHWFloat(const unsigned char* src, int srcW, int srcH,
                                     int srcChannels, int dstW, int dstH);
void resizeMaskBoth(const unsigned char* src, int srcW, int srcH, int dstW, int dstH,
                     std::vector<float>& maskFull, std::vector<float>& maskLatent);

#define TAG "MangaLocal_IPAdapter"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ─────────────────────────────────────────────────────────────────────────
// 1. Thư viện tư thế (OpenPose COCO-18 điểm, toạ độ chuẩn hoá 0..1, có z)
//
// ĐÃ SỬA (so với bản đầu tiên): KHÔNG còn hardcode toạ độ tự đoán trong
// C++ nữa — đọc từ "pose_library.json" (assets), sinh ra bởi
// tools/extract_pose_library.py chạy MediaPipe Pose trên ẢNH THẬT. z lấy
// trực tiếp từ MediaPipe ("giá trị càng nhỏ càng gần camera" — tài liệu
// chính thức Google), dùng để sắp thứ tự vẽ, giải quyết đúng vấn đề "tay
// ai đè lên người ai" khi nhiều nhân vật đan vào nhau. Nếu thiếu file
// pose_library.json, fallback về 1 tư thế đứng đơn giản (không phải bịa
// nhiều tư thế phức tạp như bản cũ).
// ─────────────────────────────────────────────────────────────────────────
namespace pose_templates {

struct Keypoint { float x, y, z; bool visible; };
using Skeleton = std::array<Keypoint, 18>;  // thứ tự chuẩn COCO-18 của OpenPose

// Cặp khớp nối để vẽ (chuẩn OpenPose COCO-18 pairs) — định dạng kỹ thuật
// công khai của OpenPose, không phải nội dung sáng tạo riêng.
const std::vector<std::pair<int,int>> kBonePairs = {
    {1,2},{1,5},{2,3},{3,4},{5,6},{6,7},{1,8},{8,9},{9,10},
    {1,11},{11,12},{12,13},{1,0},{0,14},{14,16},{0,15},{15,17}
};

const std::vector<std::array<int,3>> kBoneColors = {
    {255,0,0},{255,85,0},{255,170,0},{255,255,0},{170,255,0},{85,255,0},
    {0,255,0},{0,255,85},{0,255,170},{0,255,255},{0,170,255},{0,85,255},
    {0,0,255},{85,0,255},{170,0,255},{255,0,255},{255,0,170}
};

inline Skeleton fallbackStanding() {
    // Dùng KHI KHÔNG có pose_library.json — chỉ 1 tư thế đơn giản, không
    // bịa thêm tư thế phức tạp (ôm/vật lộn) vì không có ảnh thật kiểm
    // chứng thì thà không có còn hơn có sai.
    Skeleton s{};
    float coords[18][2] = {
        {0.5f,0.10f},{0.5f,0.20f},{0.42f,0.22f},{0.38f,0.35f},{0.35f,0.48f},
        {0.58f,0.22f},{0.62f,0.35f},{0.65f,0.48f},{0.46f,0.50f},{0.45f,0.68f},
        {0.44f,0.85f},{0.54f,0.50f},{0.55f,0.68f},{0.56f,0.85f},
        {0.48f,0.09f},{0.52f,0.09f},{0.46f,0.10f},{0.54f,0.10f}
    };
    for (int i = 0; i < 18; i++) s[i] = {coords[i][0], coords[i][1], 0.f, true};
    return s;
}

struct PoseVariant { std::string angle; std::vector<Skeleton> people; };

// ĐÃ XOÁ loadLibrary()/pickVariant() khỏi file này (mục 33 TECHNICAL_STATUS.md
// — đổi kiến trúc: đọc pose_library.json + chọn variant + RETARGET theo tỷ
// lệ xương từng nhân vật giờ làm ở Kotlin, PoseRetargeter.kt — vì CHỈ
// Kotlin mới biết chính xác scene.characters[i] ứng với người thứ mấy
// trong khung xương, native không có thông tin đó (đúng lỗ hổng "skeleton
// không có tên" đã ghi ở mục 12). Native giờ CHỈ VẼ toạ độ đã nhận sẵn.

// Đọc toạ độ khung xương ĐÃ RETARGET từ Kotlin — mảng float phẳng, mỗi
// người 18 khớp * 4 giá trị (x, y, z, visible dạng 0.0/1.0) = 72 float.
// Rỗng hoặc lỗi format -> trả vector rỗng (gọi nơi khác tự fallback).
inline std::vector<Skeleton> parseSkeletonsFromFloatArray(const float* data, int len) {
    std::vector<Skeleton> result;
    const int stride = 18 * 4;
    if (len <= 0 || len % stride != 0) {
        if (len != 0) LOGE("skeletonData length %d khong chia het cho %d - bo qua", len, stride);
        return result;
    }
    int numPeople = len / stride;
    for (int p = 0; p < numPeople; p++) {
        Skeleton s{};
        for (int k = 0; k < 18; k++) {
            int base = p * stride + k * 4;
            s[k] = {data[base], data[base+1], data[base+2], data[base+3] > 0.5f};
        }
        result.push_back(s);
    }
    return result;
}

// Vẽ khung xương (nhiều người) lên canvas RGB size x size, nền đen.
// ĐÃ SỬA: sắp theo z trước khi vẽ (xa vẽ trước, gần vẽ đè lên sau) —
// trước đây vẽ theo thứ tự bất kỳ, không xét độ sâu.
inline std::vector<uint8_t> renderSkeletons(std::vector<Skeleton> people, int size) {
    std::sort(people.begin(), people.end(), [](const Skeleton& a, const Skeleton& b) {
        auto avgZ = [](const Skeleton& s) {
            float sum = 0; int n = 0;
            for (auto& k : s) if (k.visible) { sum += k.z; n++; }
            return n ? sum / n : 0.f;
        };
        return avgZ(a) > avgZ(b);  // z lớn hơn (xa camera hơn) vẽ TRƯỚC
    });

    std::vector<uint8_t> canvas((size_t)size * size * 3, 0);
    auto putPixel = [&](int x, int y, int r, int g, int b) {
        if (x < 0 || y < 0 || x >= size || y >= size) return;
        uint8_t* p = canvas.data() + ((size_t)y * size + x) * 3;
        p[0] = (uint8_t)r; p[1] = (uint8_t)g; p[2] = (uint8_t)b;
    };
    auto drawLine = [&](float x1, float y1, float x2, float y2, int r, int g, int b) {
        int steps = size / 4;
        for (int i = 0; i <= steps; i++) {
            float t = (float)i / steps;
            int x = (int)((x1 + (x2 - x1) * t) * size);
            int y = (int)((y1 + (y2 - y1) * t) * size);
            for (int ox = -3; ox <= 3; ox++)
                for (int oy = -3; oy <= 3; oy++)
                    putPixel(x + ox, y + oy, r, g, b);
        }
    };
    for (auto& person : people) {
        for (size_t i = 0; i < kBonePairs.size(); i++) {
            auto [a, b] = kBonePairs[i];
            if (!person[a].visible || !person[b].visible) continue;
            auto c = kBoneColors[i % kBoneColors.size()];
            drawLine(person[a].x, person[a].y, person[b].x, person[b].y, c[0], c[1], c[2]);
        }
    }
    return canvas;
}

// MỤC 46/51 TECHNICAL_STATUS.md — DEPTH HINT cho ControlNet-Depth (giải
// quyết "ai trước ai sau" khi nhân vật đan vào nhau — mục 6.4, trước đây
// "CHƯA BẮT ĐẦU"). KHÔNG cần model ước lượng độ sâu riêng (MiDaS/Depth-
// Anything, tốn thêm 1 model .mnn + suy luận riêng) — tận dụng LUÔN giá
// trị z SẴN CÓ trên từng khớp (đã có cho renderSkeletons() ở trên, cùng
// nguồn dữ liệu). Đây là depth THÔ (chỉ ước lượng theo người/khớp, không
// phải depth map trù mật thật cho toàn cảnh) — đủ để ControlNet-Depth biết
// vùng nào (khớp/chi nào) gần camera hơn vùng nào, đúng đích bài toán "ai
// trước ai sau" khi 2 người chồng lấn, KHÔNG nhằm mục đích tái tạo độ sâu
// cảnh chính xác tuyệt đối.
//
// Quy ước GIÁ TRỊ PIXEL: theo đúng convention chuẩn ControlNet-Depth (model
// lllyasviel/control_v11f1p_sd15_depth train trên output MiDaS) — GẦN
// camera = SÁNG hơn, XA = TỐI hơn. Khớp z nhỏ hơn (gần hơn, theo đúng quy
// ước đã dùng ở renderSkeletons()/comment "z lớn hơn = xa hơn") -> giá trị
// pixel LỚN hơn (sáng hơn).
//
// Chuẩn hoá min-max NGAY TRONG CẢNH HIỆN TẠI (không đoán range tuyệt đối
// của z từ MediaPipe, vì tài liệu không nêu con số cụ thể) — đảm bảo LUÔN
// thể hiện được thứ tự trước/sau tương đối giữa những người có mặt trong
// khung hình, bất kể đơn vị z gốc là gì.
inline std::vector<uint8_t> renderDepthHint(std::vector<Skeleton> people, int size) {
    std::vector<uint8_t> canvas((size_t)size * size * 3, 0);
    if (people.empty()) return canvas;

    float zMin = 1e9f, zMax = -1e9f;
    for (auto& person : people)
        for (auto& k : person)
            if (k.visible) { zMin = std::min(zMin, k.z); zMax = std::max(zMax, k.z); }
    if (zMin > zMax) return canvas;  // không có khớp nào visible
    float range = std::max(zMax - zMin, 1e-4f);  // tránh chia 0 nếu mọi khớp cùng z (ảnh 1 người đứng thẳng, ít lệch sâu)

    // Vẽ THEO THỨ TỰ XA -> GẦN (giống renderSkeletons) để người/chi gần hơn
    // đè lên đúng như occlusion thật lúc render ảnh cuối.
    std::sort(people.begin(), people.end(), [](const Skeleton& a, const Skeleton& b) {
        auto avgZ = [](const Skeleton& s) {
            float sum = 0; int n = 0;
            for (auto& k : s) if (k.visible) { sum += k.z; n++; }
            return n ? sum / n : 0.f;
        };
        return avgZ(a) > avgZ(b);
    });

    auto putPixel = [&](int x, int y, uint8_t v) {
        if (x < 0 || y < 0 || x >= size || y >= size) return;
        uint8_t* p = canvas.data() + ((size_t)y * size + x) * 3;
        p[0] = p[1] = p[2] = v;  // depth map chuẩn: 3 kênh bằng nhau (ảnh xám)
    };
    // Vẽ ĐẶC (dày hơn renderSkeletons — 6px thay vì 3px mỗi phía) để xấp xỉ
    // vùng cơ thể/chi thay vì chỉ đường xương mảnh — occlusion cần vùng có
    // diện tích, không phải đường kẻ mảnh gần như không phủ được gì. Nội
    // suy z DỌC THEO từng đoạn chi (xem vòng lặp bên dưới) thay vì 1 giá
    // trị phẳng cho cả chi, nên vẽ trực tiếp trong vòng lặp per-person.
    for (auto& person : people) {
        for (auto& [a, b] : kBonePairs) {
            if (!person[a].visible || !person[b].visible) continue;
            // Nội suy z tuyến tính giữa 2 đầu khớp cho TỪNG ĐOẠN chi — chi
            // nghiêng theo trục ống kính (1 đầu gần/1 đầu xa) vẫn thể hiện
            // được gradient, không chỉ 1 giá trị phẳng cho cả chi.
            float za = person[a].z, zb = person[b].z;
            // Đảo dấu vì z NHỎ hơn = GẦN hơn = pixel value phải LỚN hơn (sáng hơn)
            float va = 255.f * (1.f - (za - zMin) / range);
            float vb = 255.f * (1.f - (zb - zMin) / range);
            int steps = size / 3;
            for (int i = 0; i <= steps; i++) {
                float t = (float)i / steps;
                float x = person[a].x + (person[b].x - person[a].x) * t;
                float y = person[a].y + (person[b].y - person[a].y) * t;
                uint8_t v = (uint8_t)std::clamp(va + (vb - va) * t, 0.f, 255.f);
                int px = (int)(x * size), py = (int)(y * size);
                for (int ox = -6; ox <= 6; ox++)
                    for (int oy = -6; oy <= 6; oy++)
                        putPixel(px + ox, py + oy, v);
            }
        }
    }
    return canvas;
}

// Multi-IP-Adapter CÓ MASK VÙNG (mục "Multi-IP-Adapter / Regional Prompting
// local" cuối TECHNICAL_STATUS.md — trước đây "CHỦ ĐỘNG CHƯA làm", giờ làm
// theo API "IP-Adapter masking" CHÍNH THỨC của diffusers, xem docstring đầu
// tools/export_ipa_controlnet_mask_unet.py, KHÔNG phải Regional Prompting
// tự chế attention nội bộ).
//
// renderCharacterMasks(): dựng 2 mask nhị phân (1 kênh, 0 hoặc 255) — mỗi
// mask đúng bằng bounding-box (đã nới rộng biên) của khung xương người thứ
// `personIndex` trong `people` — TÁI DÙNG chính toạ độ đã retargeted từ
// Kotlin (cùng nguồn dữ liệu renderSkeletons()/renderDepthHint() đã dùng,
// đúng thứ tự person[i] <-> scene.characters[i], đã xác lập từ mục 32/33).
//
// GIỚI HẠN THẬT: đây là mask HÌNH CHỮ NHẬT theo bounding box, KHÔNG PHẢI
// segmentation theo đường viền cơ thể thật (cần model segment riêng, tốn
// thêm 1 model .mnn không cần thiết cho bài toán "tách vùng ảnh 2 nhân vật"
// — bounding box đã đủ để IPAdapterAttnProcessor tách 2 tín hiệu identity
// không cạnh tranh toàn ảnh). Nếu 2 người đứng SÁT/CHỒNG NHAU, 2 bounding
// box có thể chồng lấn — mask KHÔNG bắt buộc phải rời nhau theo API thật
// (đã xác nhận qua tài liệu), chỉ là ranh giới sẽ mềm hơn ở vùng chồng lấn,
// KHÔNG lỗi, không crash.
inline std::vector<uint8_t> renderCharacterMask(const std::vector<Skeleton>& people,
                                                 size_t personIndex, int size) {
    std::vector<uint8_t> canvas((size_t)size * size, 0);  // 1 kênh, khác renderSkeletons/renderDepthHint (3 kênh)
    if (personIndex >= people.size()) return canvas;  // không có người này -> mask rỗng, IP-Adapter tương ứng không ảnh hưởng gì

    const Skeleton& s = people[personIndex];
    float minX = 1e9f, minY = 1e9f, maxX = -1e9f, maxY = -1e9f;
    bool any = false;
    for (auto& k : s) {
        if (!k.visible) continue;
        any = true;
        minX = std::min(minX, k.x); maxX = std::max(maxX, k.x);
        minY = std::min(minY, k.y); maxY = std::max(maxY, k.y);
    }
    if (!any) return canvas;

    // Nới rộng biên 10% mỗi phía — tránh cắt cụt đúng ngay rìa khớp ngoài
    // cùng (tay/chân thường vượt ra ngoài bounding box của riêng các ĐIỂM
    // khớp một chút do có độ dày cơ thể thật).
    float marginX = (maxX - minX) * 0.10f + 0.02f;
    float marginY = (maxY - minY) * 0.10f + 0.02f;
    minX = std::clamp(minX - marginX, 0.f, 1.f);
    maxX = std::clamp(maxX + marginX, 0.f, 1.f);
    minY = std::clamp(minY - marginY, 0.f, 1.f);
    maxY = std::clamp(maxY + marginY, 0.f, 1.f);

    int px0 = (int)(minX * size), px1 = (int)(maxX * size);
    int py0 = (int)(minY * size), py1 = (int)(maxY * size);
    for (int y = std::max(0, py0); y < std::min(size, py1); y++)
        for (int x = std::max(0, px0); x < std::min(size, px1); x++)
            canvas[(size_t)y * size + x] = 255;
    return canvas;
}

}  // namespace pose_templates

// ─────────────────────────────────────────────────────────────────────────
// 2. Bộ mã hoá ảnh nhân vật -> image_embeds (chạy ip_image_encoder.mnn)
// ─────────────────────────────────────────────────────────────────────────
class IpImageEncoder {
public:
    explicit IpImageEncoder(const std::string& modelPath) {
        net_.reset(MNN::Interpreter::createFromFile(modelPath.c_str()));
        if (!net_) { LOGE("IpImageEncoder: khong doc duoc %s", modelPath.c_str()); return; }
        MNN::ScheduleConfig cfg; cfg.type = MNN_FORWARD_CPU; cfg.numThread = 4;
        session_ = net_->createSession(cfg);
        ok_ = session_ != nullptr;
    }
    bool ok() const { return ok_; }

    // Trả về embedding thô (đọc shape thật từ tensor, không hardcode số).
    bool encode(const std::string& imagePath, std::vector<float>& outEmbed, std::vector<int>& outShape) {
        if (!ok_) return false;
        int w, h, c;
        unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("IpImageEncoder: load anh fail %s", imagePath.c_str()); return false; }

        std::vector<unsigned char> resized(224 * 224 * 3);
        stbir_resize_uint8_srgb(data, w, h, 0, resized.data(), 224, 224, 0, STBIR_RGB);
        stbi_image_free(data);

        auto inputs = net_->getSessionInputAll(session_);
        if (inputs.empty()) { LOGE("ip_image_encoder.mnn khong co input"); return false; }
        MNN::Tensor* input = inputs.begin()->second;

        MNN::Tensor hostIn(input, MNN::Tensor::CAFFE);
        // Chuẩn hoá CLIP: mean/std xấp xỉ chuẩn OpenAI CLIP ViT (0.481,0.457,0.408)/(0.268,0.261,0.275)
        const float mean[3] = {0.481f, 0.457f, 0.408f};
        const float stdv[3] = {0.268f, 0.261f, 0.275f};
        for (int y = 0; y < 224; y++) for (int x = 0; x < 224; x++) {
            unsigned char* p = resized.data() + (y * 224 + x) * 3;
            for (int ch = 0; ch < 3; ch++)
                hostIn.host<float>()[ch*224*224 + y*224 + x] = (p[ch]/255.f - mean[ch]) / stdv[ch];
        }
        input->copyFromHostTensor(&hostIn);
        net_->runSession(session_);

        auto outputs = net_->getSessionOutputAll(session_);
        if (outputs.empty()) { LOGE("ip_image_encoder.mnn khong co output"); return false; }
        MNN::Tensor* output = outputs.begin()->second;
        MNN::Tensor hostOut(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&hostOut);

        outShape = hostOut.shape();
        size_t n = 1; for (int d : outShape) n *= (size_t)std::max(1, d);
        outEmbed.assign(hostOut.host<float>(), hostOut.host<float>() + n);
        return true;
    }
private:
    std::shared_ptr<MNN::Interpreter> net_;
    MNN::Session* session_ = nullptr;
    bool ok_ = false;
};

// ─────────────────────────────────────────────────────────────────────────
// 3. Pipeline mở rộng — override hook đã thêm ở PipelineSd15Cpu.hpp để nạp
//    thêm "control_hint" + "ip_image_embeds" trước mỗi bước UNet.
// ─────────────────────────────────────────────────────────────────────────
class PipelineSd15CpuAugmented : public PipelineSd15Cpu {
public:
    PipelineSd15CpuAugmented(TextEncoder& te, const std::string& dir,
        const std::string& clip, const std::string& unet,
        const std::string& vaeDec, const std::string& vaeEnc, bool vPred)
        : PipelineSd15Cpu(te, dir, clip, unet, vaeDec, vaeEnc, vPred) {}

    // Gọi 1 lần trước khi bắt đầu sinh ảnh — set embedding nhân vật + tư thế.
    // depthHintRgb: THÊM MỚI (mục 51 TECHNICAL_STATUS.md) — RỖNG (mặc định)
    // = không gửi depth, hoạt động y hệt bản cũ (tương thích ngược với
    // unet.mnn CHƯA re-export thêm input "depth_hint"). Chỉ truyền vào khi
    // đã dùng bản unet.mnn MỚI (xuất bởi export_ipa_controlnet_depth_unet.py).
    void setConditioning(const std::vector<float>& ipEmbed, const std::vector<int>& ipShape,
                          const std::vector<uint8_t>& controlHintRgb, int controlSize,
                          const std::vector<uint8_t>& depthHintRgb = {}) {
        ipEmbed_ = ipEmbed; ipShape_ = ipShape;
        controlHintRgb_ = controlHintRgb; controlSize_ = controlSize;
        depthHintRgb_ = depthHintRgb;
        hasConditioning_ = true;
        // Reset trạng thái "nhiều nhân vật có mask" từ lần gọi TRƯỚC (nếu
        // có) — pipeline object này được TÁI SỬ DỤNG qua nhiều lần sinh ảnh
        // trên cùng 1 ctx (xem sdInitAugmented/handle->pipeline), nên nếu
        // không reset, 1 lần gọi setConditioning() (1 nhân vật) SAU 1 lần
        // gọi setConditioningMultiCharacter() sẽ vô tình còn sót mask/embed
        // cũ — bug im lặng rất khó phát hiện (ảnh vẫn ra, chỉ sai âm thầm).
        hasMultiCharacter_ = false;
        multiEmbeds_.clear(); multiMasks_.clear();
    }

    // Multi-IP-Adapter CÓ MASK VÙNG, N NHÂN VẬT (mục 52 TECHNICAL_STATUS.md
    // — TỔNG QUÁT HOÁ từ bản chỉ-2-nhân-vật ban đầu). Xem docstring đầu
    // tools/export_ipa_controlnet_mask_unet.py cho API thật đã dùng.
    //
    // ipEmbeds: 1 phần tử/nhân vật, mỗi phần tử là embedding THÔ (1 lần gọi
    // IpImageEncoder::encode() RIÊNG/nhân vật — model ip_image_encoder.mnn
    // KHÔNG đổi, vẫn encode 1 ảnh/lần) — ghép lại thành tensor
    // [1,N,tokens,dim] ngay TRONG onBeforeUnetRun() bên dưới.
    // maskHints: 1 phần tử/nhân vật, canvas 1 kênh (0/255) từ
    // renderCharacterMask(), PHẢI cùng controlSize với controlHintRgb, PHẢI
    // cùng thứ tự với ipEmbeds (person[i] <-> ipEmbeds[i] <-> maskHints[i]).
    //
    // LƯU Ý: N ở đây là số nhân vật APP TRUYỀN VÀO, KHÔNG nhất thiết bằng N
    // mà model .mnn đã được export cho — onBeforeUnetRun() tự đọc N THẬT
    // của model qua elementSize() của chính tensor lúc chạy (KHÔNG đoán,
    // KHÔNG hardcode 2) và tự cắt bớt/điền thiếu cho khớp, kèm LOGE cảnh
    // báo nếu lệch (vd model export cho 2 nhân vật nhưng app truyền 3 ảnh).
    void setConditioningMultiCharacter(const std::vector<std::vector<float>>& ipEmbeds,
                          const std::vector<int>& ipShape,
                          const std::vector<uint8_t>& controlHintRgb, int controlSize,
                          const std::vector<std::vector<uint8_t>>& maskHints) {
        ipEmbed_ = ipEmbeds.empty() ? std::vector<float>{} : ipEmbeds[0];  // giữ cho đường fallback 1-nhân-vật cũ vẫn có dữ liệu hợp lý
        multiEmbeds_ = ipEmbeds; ipShape_ = ipShape;
        controlHintRgb_ = controlHintRgb; controlSize_ = controlSize;
        multiMasks_ = maskHints;
        depthHintRgb_.clear();  // 2 tính năng (depth / mask nhiều nhân vật) độc lập, chưa hỗ trợ dùng CHUNG 1 model (xem TECHNICAL_STATUS.md)
        hasConditioning_ = true;
        hasMultiCharacter_ = true;
    }

    // Bản 2-nhân-vật CŨ — giữ lại để KHÔNG phá call site hiện có
    // (sdTxt2ImgWithTwoReferencesAndPose), chỉ là lớp mỏng gọi bản tổng quát.
    void setConditioningTwoCharacters(const std::vector<float>& ipEmbed1,
                          const std::vector<float>& ipEmbed2, const std::vector<int>& ipShape,
                          const std::vector<uint8_t>& controlHintRgb, int controlSize,
                          const std::vector<uint8_t>& maskHint1, const std::vector<uint8_t>& maskHint2) {
        setConditioningMultiCharacter({ipEmbed1, ipEmbed2}, ipShape, controlHintRgb, controlSize,
                                       {maskHint1, maskHint2});
    }

protected:
    void onBeforeUnetRun(MNN::Interpreter* unetInterp, MNN::Session* unetSess) override {
        if (!hasConditioning_) return;  // không có điều kiện phụ -> chạy như bản gốc

        // ip_image_embeds — tên tự đặt trong export_ipa_controlnet_unet.py.
        // TỰ NHẬN BIẾT model 1 nhân vật (shape [1,tokens,dim]) hay model
        // mask N nhân vật (shape [1,N,tokens,dim]) qua elementSize() THẬT
        // của tensor — N ở đây là N mà MODEL ĐÃ EXPORT (cố định trong file
        // .mnn), suy ra bằng cách chia elementSize() cho kích thước 1
        // embedding, KHÔNG đoán, KHÔNG hardcode 2 — giống cách depth_hint
        // đã tự nhận biết model cũ/mới ở dưới.
        if (auto* t = unetInterp->getSessionInput(unetSess, "ip_image_embeds")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            size_t total = (size_t)host.elementSize();
            if (hasMultiCharacter_ && !multiEmbeds_.empty() && !multiEmbeds_[0].empty()) {
                size_t single = multiEmbeds_[0].size();
                size_t nModel = (single > 0 && total % single == 0) ? total / single : 0;
                if (nModel == 0) {
                    LOGE("ip_image_embeds shape khong chia het cho embedding 1 nhan vat - model nay co dung dinh dang mask-N-nhan-vat khong?");
                    size_t n = std::min(single, total);
                    memcpy(host.host<float>(), multiEmbeds_[0].data(), n * sizeof(float));
                } else {
                    if (nModel != multiEmbeds_.size()) {
                        LOGE("Model nay xuat cho %zu nhan vat nhung app truyen %zu anh tham chieu - se cat bot/dien 0 cho khop",
                             nModel, multiEmbeds_.size());
                    }
                    size_t nWrite = std::min(nModel, multiEmbeds_.size());
                    for (size_t i = 0; i < nWrite; i++) {
                        size_t ni = std::min(multiEmbeds_[i].size(), single);
                        memcpy(host.host<float>() + i * single, multiEmbeds_[i].data(), ni * sizeof(float));
                    }
                    // Model mong NHIỀU nhân vật hơn app truyền (hiếm, vd
                    // thiếu ảnh 1 nhân vật) — điền 0, an toàn hơn để rác
                    // chưa khởi tạo.
                    if (nModel > multiEmbeds_.size()) {
                        std::fill(host.host<float>() + multiEmbeds_.size() * single,
                                  host.host<float>() + nModel * single, 0.f);
                    }
                }
            } else {
                size_t single = ipEmbed_.size();
                size_t n = std::min(single, total);
                memcpy(host.host<float>(), ipEmbed_.data(), n * sizeof(float));
            }
            t->copyFromHostTensor(&host);
        } else {
            LOGE("Model nay khong co input 'ip_image_embeds' - co phai unet.mnn chua phai ban augmented?");
        }

        // ip_adapter_masks — CHỈ có ở model mask N nhân vật (tools/
        // export_ipa_controlnet_mask_unet.py), TUỲ CHỌN giống depth_hint —
        // model cũ (1 nhân vật/depth) hợp lệ không có input này. N (số mặt
        // phẳng mask) suy từ elementSize() thật / (controlSize_^2), KHÔNG
        // hardcode 2 — cùng nguyên tắc với ip_image_embeds ở trên.
        if (auto* t = unetInterp->getSessionInput(unetSess, "ip_adapter_masks")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            int size = controlSize_;
            size_t plane = (size_t)size * size;
            size_t total = (size_t)host.elementSize();
            size_t nModel = (plane > 0 && total % plane == 0) ? total / plane : 0;
            if (hasMultiCharacter_ && !multiMasks_.empty() && nModel > 0) {
                size_t nWrite = std::min(nModel, multiMasks_.size());
                for (size_t i = 0; i < nWrite; i++) {
                    const auto& m = multiMasks_[i];
                    for (size_t px = 0; px < plane; px++)
                        host.host<float>()[i * plane + px] = (px < m.size() ? m[px] / 255.f : 1.f);
                }
                // Thiếu mask cho phần nhân vật model mong nhưng app không
                // truyền đủ — điền 1.0 (mask "phủ hết ảnh", KHÔNG mask) cho
                // vùng đó, AN TOÀN HƠN 0.0 (0.0 sẽ tắt hẳn identity vùng đó).
                if (nModel > multiMasks_.size()) {
                    std::fill(host.host<float>() + multiMasks_.size() * plane,
                              host.host<float>() + nModel * plane, 1.f);
                }
            } else {
                // Model cần mask nhưng caller chưa truyền (gọi setConditioning()
                // 1-nhân-vật nhầm lên model N-nhân-vật) — điền TOÀN BỘ = 1.0,
                // xem lý do ở nhánh trên.
                std::fill(host.host<float>(), host.host<float>() + host.elementSize(), 1.f);
            }
            t->copyFromHostTensor(&host);
        }

        // control_hint — ảnh RGB khung xương, chuẩn hoá [0,1], NCHW
        if (auto* t = unetInterp->getSessionInput(unetSess, "control_hint")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            int size = controlSize_;
            for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
                const uint8_t* p = controlHintRgb_.data() + ((size_t)y*size+x)*3;
                for (int ch = 0; ch < 3; ch++)
                    host.host<float>()[(size_t)ch*size*size + y*size + x] = p[ch] / 255.f;
            }
            t->copyFromHostTensor(&host);
        } else {
            LOGE("Model nay khong co input 'control_hint' - co phai unet.mnn chua phai ban augmented?");
        }

        // depth_hint — THÊM MỚI, TUỲ CHỌN (mục 51 TECHNICAL_STATUS.md).
        // KHÔNG log lỗi nếu model không có input này — khác 2 input trên
        // (luôn bắt buộc có ở MỌI bản augmented) — model CŨ (chưa re-export
        // depth) hợp lệ không có input này, đây là hành vi ĐÚNG, không phải lỗi.
        if (auto* t = unetInterp->getSessionInput(unetSess, "depth_hint")) {
            if (!depthHintRgb_.empty()) {
                MNN::Tensor host(t, MNN::Tensor::CAFFE);
                int size = controlSize_;
                for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
                    const uint8_t* p = depthHintRgb_.data() + ((size_t)y*size+x)*3;
                    for (int ch = 0; ch < 3; ch++)
                        host.host<float>()[(size_t)ch*size*size + y*size + x] = p[ch] / 255.f;
                }
                t->copyFromHostTensor(&host);
            } else {
                // Model MỚI (có input depth_hint) nhưng caller chưa truyền depth
                // (vd panel không có ≥2 người chồng lấn, không cần depth) — gửi
                // canvas đen (không có thông tin depth) thay vì để tensor rác
                // chưa khởi tạo, an toàn hơn.
                MNN::Tensor host(t, MNN::Tensor::CAFFE);
                std::fill(host.host<float>(), host.host<float>() + host.elementSize(), 0.f);
                t->copyFromHostTensor(&host);
            }
        }

        // pose_scale / depth_scale / depth_active_min_timestep — THÊM MỚI,
        // TUỲ CHỌN (mục 81 TECHNICAL_STATUS.md — giải quyết "loãng" tín
        // hiệu khi cộng đều 2 ControlNet, đề xuất trong bổ_sung_sd1_5.txt,
        // dùng ĐÚNG 2 tham số diffusers thật — controlnet_conditioning_scale
        // + control_guidance_start/end — thay vì tự nghĩ ra cơ chế mới).
        // Model CŨ (export trước mục 81) không có 3 input này — bỏ qua an
        // toàn, hành vi y hệt trước (cộng 1:1, luôn bật depth mọi step).
        // Giá trị mặc định khi caller chưa set gì (poseScale_/depthScale_
        // khởi tạo 1.0f/0.6f, depthActiveMinTimestep_ khởi tạo 300.0f —
        // XẤP XỈ tương đương control_guidance_end≈0.7, xem docstring
        // export_ipa_controlnet_depth_unet.py mục 81 cho giải thích đầy đủ).
        if (auto* t = unetInterp->getSessionInput(unetSess, "pose_scale")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            host.host<float>()[0] = poseScale_;
            t->copyFromHostTensor(&host);
        }
        if (auto* t = unetInterp->getSessionInput(unetSess, "depth_scale")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            host.host<float>()[0] = depthScale_;
            t->copyFromHostTensor(&host);
        }
        if (auto* t = unetInterp->getSessionInput(unetSess, "depth_active_min_timestep")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            host.host<float>()[0] = depthActiveMinTimestep_;
            t->copyFromHostTensor(&host);
        }
        // mục 146 TECHNICAL_STATUS.md — depth_ramp_width: THÊM MỚI, TUỲ
        // CHỌN, cùng nguyên tắc tương thích ngược. Model CŨ (trước mục 146)
        // không có input này -> bỏ qua an toàn -> hành vi y hệt cổng cứng
        // gốc (không hồi quy). Default 100.0f (suy giảm mượt trên cửa sổ
        // 100 timestep quanh ngưỡng, xem export_ipa_controlnet_depth_unet.py
        // cho lý do chọn cổng mượt thay cổng cứng).
        if (auto* t = unetInterp->getSessionInput(unetSess, "depth_ramp_width")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            host.host<float>()[0] = depthRampWidth_;
            t->copyFromHostTensor(&host);
        }

        // ip_decay_floor / ip_decay_start_timestep — Smooth Timestep Decay
        // cho IP-Adapter, THÊM MỚI, TUỲ CHỌN (mở rộng mục 81 sang IP-Adapter
        // — scale ĐÚNG output attention qua attn processor đã bọc, xem
        // tools/ip_adapter_decay.py cho cơ chế đầy đủ + GIỚI HẠN THẬT còn
        // lại: phụ thuộc cấu trúc nội bộ diffusers cài lúc export, script
        // tự dừng lỗi rõ ràng nếu không bọc được — KHÔNG còn là xấp xỉ
        // scale-input như bản đầu tiên, nhưng CHƯA xác nhận A/B trên ảnh
        // thật vì chưa build-test).
        // Model CŨ (export trước tính năng này) không có 2 input này — bỏ
        // qua an toàn, hành vi y hệt trước (embeds không suy giảm gì).
        // mục 147 TECHNICAL_STATUS.md — Per-Instance Decay (đóng gap xác
        // nhận thật ở mục 146: trước đây 1 scalar dùng chung cho MỌI nhân
        // vật). 3 input này giờ CÓ THỂ là vector [N] (model mới, mask
        // N-nhân-vật) hoặc vẫn scalar [1] (model cũ/đường 1-nhân-vật) —
        // suy N từ elementSize() THẬT của tensor, cùng nguyên tắc với
        // ip_image_embeds/ip_adapter_masks ở trên, KHÔNG hardcode.
        if (auto* t = unetInterp->getSessionInput(unetSess, "ip_decay_floor")) {
            writePerCharacterOrScalar(t, multiIpDecayFloor_, ipDecayFloor_);
        }
        if (auto* t = unetInterp->getSessionInput(unetSess, "ip_decay_start_timestep")) {
            writePerCharacterOrScalar(t, multiIpDecayStartTimestep_, ipDecayStartTimestep_);
        }
        if (auto* t = unetInterp->getSessionInput(unetSess, "ip_static_scale")) {
            writePerCharacterOrScalar(t, multiIpStaticScale_, ipStaticScale_);
        }
    }

public:
    // mục 156 TECHNICAL_STATUS.md — BUG THẬT tìm được qua build CI lần đầu
    // (Build APK #88, 6 lỗi compile): `setControlNetBalance()`/
    // `setIpAdapterDecay()`/`setIpAdapterDecayMultiCharacter()` rơi vào
    // đúng vùng `protected:` (mở ra bởi `onBeforeUnetRun()` phía trên —
    // hàm đó PHẢI protected vì override virtual protected của base class,
    // nhưng KHÔNG có `public:` nào đóng lại vùng đó trước khi 3 setter này
    // được khai báo) — trong khi cả 3 hàm này BẮT BUỘC phải gọi được từ
    // hàm JNI tự do bên ngoài (`handle->pipeline->setControlNetBalance(...)`
    // — không phải hàm thành viên/friend của lớp). `clang` báo lỗi truy
    // cập C++ thật, ĐÚNG theo chuẩn ngôn ngữ — không phải lỗi build CI, mà
    // là lỗi code thật đã tồn tại từ mục 81 (setControlNetBalance) và mục
    // 97 (setIpAdapterDecay), TRƯỚC CẢ mục 146/147 — chỉ là chưa từng lộ ra
    // vì dự án CHƯA build-test lần nào cho tới bây giờ. Thêm `public:` ở
    // đây để đóng vùng protected lại — 3 setter quay về public, khớp đúng
    // ý đồ gốc (gọi được từ JNI, giống `setConditioning()` ở đầu class).

    // mục 81 — setter tuỳ chọn cho 3 tham số cân bằng ControlNet, gọi TRƯỚC
    // khi sinh ảnh (giống setConditioning). Không gọi thì dùng default ở
    // trên (tương đương hành vi "giảm nhẹ ảnh hưởng Depth" theo khuyến nghị
    // tài liệu diffusers, KHÔNG PHẢI hành vi cộng 1:1 cũ — nếu muốn y hệt
    // bản CŨ, gọi setControlNetBalance(1.0f, 1.0f, 0.0f) tường minh).
    // mục 146 TECHNICAL_STATUS.md — thêm depthRampWidth vào setter có sẵn
    // thay vì tạo setter riêng (cùng nhóm tham số "cân bằng ControlNet",
    // luôn gọi cùng lúc từ MangaPipeline.kt). Default 100.0f (khớp default
    // Python export) — gọi setControlNetBalance(_, _, _, 0.0f) tường minh
    // nếu muốn quay lại hành vi cổng cứng gốc.
    void setControlNetBalance(float poseScale, float depthScale, float depthActiveMinTimestep,
                               float depthRampWidth = 100.0f) {
        poseScale_ = poseScale; depthScale_ = depthScale; depthActiveMinTimestep_ = depthActiveMinTimestep;
        depthRampWidth_ = depthRampWidth;
    }

    // Smooth Timestep Decay cho IP-Adapter — setter tuỳ chọn, cùng khuôn
    // mẫu setControlNetBalance() ở trên. Không gọi thì dùng default bên
    // dưới (ipDecayFloor_=1.0f = KHÔNG suy giảm gì, tương thích ngược tuyệt
    // đối với mọi hành vi trước đây, kể cả khi model .mnn MỚI đã có input
    // này nhưng caller quên gọi setter).
    // ipStaticScale — mục 9: tầng nhân RIÊNG cho "Mức độ nhất quán"
    // (consistencyStrength), độc lập với decay theo timestep (xem
    // forward() Python cho công thức nhân 2 tầng). Default 1.0f = cường
    // độ IP-Adapter gốc, không đổi gì so với hành vi trước khi có tham số
    // này.
    void setIpAdapterDecay(float ipDecayFloor, float ipDecayStartTimestep, float ipStaticScale) {
        ipDecayFloor_ = ipDecayFloor; ipDecayStartTimestep_ = ipDecayStartTimestep; ipStaticScale_ = ipStaticScale;
    }

    // mục 147 TECHNICAL_STATUS.md — Per-Instance Decay: setter RIÊNG cho
    // đường mask N-nhân-vật (khác setIpAdapterDecay() ở trên — đường
    // 1-nhân-vật giữ nguyên, không cần vector). 3 vector PHẢI cùng độ dài
    // (khớp số nhân vật thật của panel), không bắt buộc khớp N model .mnn
    // mong — writePerCharacterOrScalar() tự bù/cắt cho khớp lúc chạy.
    // KHÔNG gọi hàm này (giữ 3 vector rỗng) -> writePerCharacterOrScalar()
    // tự fallback về scalar setIpAdapterDecay() phía trên cho MỌI nhân vật
    // — tương thích ngược hoàn toàn với hành vi trước mục 147.
    void setIpAdapterDecayMultiCharacter(const std::vector<float>& floors,
                                          const std::vector<float>& startTimesteps,
                                          const std::vector<float>& staticScales) {
        multiIpDecayFloor_ = floors;
        multiIpDecayStartTimestep_ = startTimesteps;
        multiIpStaticScale_ = staticScales;
    }

private:
    // mục 147 — helper dùng chung cho 3 input Per-Instance Decay. TỰ NHẬN
    // BIẾT model cũ (input scalar, elementSize()==1) hay model mới (vector
    // [N], N=elementSize()) — cùng nguyên tắc ip_image_embeds/ip_adapter_masks
    // ở trên (KHÔNG hardcode N). `multiValues` thiếu/ngắn hơn N model mong
    // -> điền `scalarFallback` cho phần thiếu (an toàn hơn 0/rác — 0 sẽ tắt
    // hẳn identity nhân vật đó).
    void writePerCharacterOrScalar(MNN::Tensor* t, const std::vector<float>& multiValues, float scalarFallback) {
        MNN::Tensor host(t, MNN::Tensor::CAFFE);
        size_t total = (size_t)host.elementSize();
        if (total <= 1) {
            host.host<float>()[0] = multiValues.empty() ? scalarFallback : multiValues[0];
        } else {
            size_t nWrite = std::min(total, multiValues.size());
            for (size_t i = 0; i < nWrite; i++) host.host<float>()[i] = multiValues[i];
            for (size_t i = nWrite; i < total; i++) host.host<float>()[i] = scalarFallback;
        }
        t->copyFromHostTensor(&host);
    }
    bool hasConditioning_ = false;
    bool hasMultiCharacter_ = false;   // true <=> setConditioningMultiCharacter()/setConditioningTwoCharacters() (mục 52 "Multi-IP-Adapter co mask")
    std::vector<float> ipEmbed_;
    std::vector<std::vector<float>> multiEmbeds_;   // TOÀN BỘ N nhân vật khi hasMultiCharacter_ (multiEmbeds_[0] == ipEmbed_); N do model .mnn export quyết định, đọc ra tại runtime, không hardcode
    std::vector<int> ipShape_;
    std::vector<uint8_t> controlHintRgb_;
    std::vector<uint8_t> depthHintRgb_;
    std::vector<std::vector<uint8_t>> multiMasks_;  // canvas 1 kênh (0/255)/nhân vật, renderCharacterMask(), cùng thứ tự multiEmbeds_
    int controlSize_ = 512;
    // mục 81 TECHNICAL_STATUS.md — xem setControlNetBalance()/docstring
    // export_ipa_controlnet_depth_unet.py cho giải thích đầy đủ.
    float poseScale_ = 1.0f;
    float depthScale_ = 0.6f;
    float depthActiveMinTimestep_ = 300.0f;
    // mục 146 — độ rộng cửa sổ suy giảm mượt, xem setControlNetBalance().
    float depthRampWidth_ = 100.0f;
    // Smooth Timestep Decay IP-Adapter — default = KHÔNG suy giảm (floor=1.0
    // khiến effective_scale luôn =1.0 bất kể ramp, xem forward() Python).
    float ipDecayFloor_ = 1.0f;
    float ipDecayStartTimestep_ = 999.0f;
    // mục 9 — tầng nhân riêng cho "Mức độ nhất quán" (consistencyStrength),
    // default 1.0f = cường độ IP-Adapter gốc.
    float ipStaticScale_ = 1.0f;
    // mục 147 — 3 vector Per-Instance Decay cho đường mask N-nhân-vật, xem
    // setIpAdapterDecayMultiCharacter(). Rỗng theo mặc định (fallback về
    // scalar phía trên, tương thích ngược).
    std::vector<float> multiIpDecayFloor_;
    std::vector<float> multiIpDecayStartTimestep_;
    std::vector<float> multiIpStaticScale_;
};

// ─────────────────────────────────────────────────────────────────────────
// 4. JNI — nối vào sdTxt2ImgWithReference (đã là stub từ trước)
// ─────────────────────────────────────────────────────────────────────────
static std::string j2s_ip(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

// Handle riêng cho pipeline augmented — KHÁC SdHandle trong
// mnn_diffusion_pipeline.cpp (pipeline chuẩn không có input phụ).
struct SdAugmentedHandle {
    std::unique_ptr<TextEncoder> textEncoder;
    std::unique_ptr<PipelineSd15CpuAugmented> pipeline;
    std::unique_ptr<IpImageEncoder> ipEncoder;
    // mục 61 TECHNICAL_STATUS.md — trước đây hardcode use_opencl=false ở
    // MỌI hàm sinh ảnh bên dưới dù sessionOptions() (kế thừa từ
    // PipelineSd15Cpu) đã hỗ trợ sẵn cascade NPU->GPU->CPU (mục 60) — KHÔNG
    // có rào cản kỹ thuật nào, thuần là thiếu sót chưa nối dây. Sửa dứt
    // điểm ở đây.
    bool useOpenCL = false;
    bool useNpu = false;
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdInitAugmented(JNIEnv* e, jobject,
    jstring jModelDir, jstring jClip, jstring jUnetAugmented, jstring jVaeDec,
    jstring jVaeEnc, jstring jIpEncoderPath, jstring jTokenizer, jstring jEmbeddingsDir,
    jboolean jUseOpenCL, jboolean jUseNpu) {

    std::string dir = j2s_ip(e, jModelDir);
    try {
        auto handle = std::make_unique<SdAugmentedHandle>();
        handle->useOpenCL = jUseOpenCL;
        handle->useNpu = jUseNpu;
        handle->textEncoder = std::make_unique<TextEncoder>(false, false);
        handle->textEncoder->loadTokenizer(j2s_ip(e, jTokenizer));
        handle->textEncoder->loadEmbeddingTables(dir);
        // Textual Inversion — xem ghi chú tương ứng trong mnn_diffusion_pipeline.cpp sdInit().
        std::string embeddingsDir = j2s_ip(e, jEmbeddingsDir);
        if (!embeddingsDir.empty()) handle->textEncoder->loadTextualInversions(embeddingsDir);

        handle->pipeline = std::make_unique<PipelineSd15CpuAugmented>(
            *handle->textEncoder, dir, j2s_ip(e, jClip), j2s_ip(e, jUnetAugmented),
            j2s_ip(e, jVaeDec), j2s_ip(e, jVaeEnc), false);
        if (!handle->pipeline->initialize()) { LOGE("PipelineSd15CpuAugmented initialize() fail"); return 0; }

        handle->ipEncoder = std::make_unique<IpImageEncoder>(j2s_ip(e, jIpEncoderPath));
        if (!handle->ipEncoder->ok()) { LOGE("IpImageEncoder load fail"); return 0; }

        return reinterpret_cast<jlong>(handle.release());
    } catch (const std::exception& ex) {
        LOGE("sdInitAugmented loi: %s", ex.what());
        return 0;
    }
}

// mục 134 TECHNICAL_STATUS.md — nối progress callback per-step cho nhánh
// augmented (trước đây CHỈ sdImg2ImgWithReferenceAndPose có, hàm txt2img
// augmented này thì KHÔNG — Kotlin phải báo tiến trình giả "0 rồi nhảy
// thẳng lên steps" vì JNI không có đường truyền callback). Thêm tham số
// `cb` CUỐI danh sách (giữ tương thích vị trí các tham số cũ, đúng quy
// ước JNI khớp theo descriptor đầy đủ, không theo tên) — copy NGUYÊN VĂN
// khuôn mẫu AttachCurrentThread/DetachCurrentThread đã kiểm chứng ở
// `sdImg2ImgWithReferenceAndPose` ngay bên dưới (không phát minh cách
// mới). Đồng thời đổi cấu trúc trả về sang biến `ok` set 1 LẦN rồi free
// `cbGlobal` sau try/catch — bản gốc trả về TRỰC TIẾP nhiều điểm trong
// try (`return JNI_TRUE`/`return JNI_FALSE` giữa chừng) sẽ RÒ RỈ
// `cbGlobal` (global ref không được `DeleteGlobalRef`) nếu không sửa
// cấu trúc — đây là style ĐÃ ĐÚNG sẵn ở sdImg2ImgWithReferenceAndPose,
// áp dụng lại cho nhất quán và an toàn.
extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgWithReferenceAndPose(JNIEnv* e, jobject,
    jlong ptr, jstring jPrompt, jstring jNeg, jstring jRefImage, jfloatArray jSkeletonData,
    jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut,
    jfloat jPoseScale, jfloat jDepthScale, jfloat jDepthActiveMinTimestep,
    jfloat jIpDecayFloor, jfloat jIpDecayStartTimestep, jfloat jIpStaticScale, jobject cb) {

    auto* handle = reinterpret_cast<SdAugmentedHandle*>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgWithReferenceAndPose: chua init"); return JNI_FALSE; }

    std::vector<float> ipEmbed; std::vector<int> ipShape;
    if (!handle->ipEncoder->encode(j2s_ip(e, jRefImage), ipEmbed, ipShape)) {
        LOGE("Encode anh tham chieu that bai");
        return JNI_FALSE;
    }

    // Toạ độ khung xương ĐÃ RETARGET theo tỷ lệ từng nhân vật, tính sẵn ở
    // Kotlin (PoseRetargeter.kt, mục 32/33 TECHNICAL_STATUS.md) — native
    // KHÔNG còn tự đọc pose_library.json/chọn variant nữa.
    std::vector<pose_templates::Skeleton> chosen;
    if (jSkeletonData) {
        jsize len = e->GetArrayLength(jSkeletonData);
        std::vector<float> buf(len);
        e->GetFloatArrayRegion(jSkeletonData, 0, len, buf.data());
        chosen = pose_templates::parseSkeletonsFromFloatArray(buf.data(), (int)len);
    }
    if (chosen.empty()) {
        LOGI("Khong co skeleton data hop le tu Kotlin, dung fallback don gian");
        chosen = {pose_templates::fallbackStanding()};
    }
    auto controlHint = pose_templates::renderSkeletons(chosen, 512);
    // depth_hint (mục 51 TECHNICAL_STATUS.md) — chỉ thật sự HỮU ÍCH khi có
    // ≥2 người trong cảnh (occlusion chỉ xảy ra khi ≥2 người chồng lấn) —
    // vẫn tính cho trường hợp 1 người (rẻ, không hại gì) để logic đơn giản,
    // model MỚI (nếu có input depth_hint) tự dùng được luôn.
    auto depthHint = pose_templates::renderDepthHint(chosen, 512);

    handle->pipeline->setConditioning(ipEmbed, ipShape, controlHint, 512, depthHint);
    // mục 81 TECHNICAL_STATUS.md — Kotlin truyền tường minh, không dùng
    // default C++ nếu caller có ý kiến khác (vd A/B test giá trị).
    handle->pipeline->setControlNetBalance((float)jPoseScale, (float)jDepthScale, (float)jDepthActiveMinTimestep);
    // Smooth Timestep Decay IP-Adapter — xem docstring setIpAdapterDecay().
    handle->pipeline->setIpAdapterDecay((float)jIpDecayFloor, (float)jIpDecayStartTimestep, (float)jIpStaticScale);

    GenerationRequest req;
    req.prompt = j2s_ip(e, jPrompt);
    req.negative_prompt = j2s_ip(e, jNeg);
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = handle->useOpenCL; req.use_npu = handle->useNpu; req.img2img = false;

    // Progress callback — GIỐNG HỆT sdImg2ImgWithReferenceAndPose bên dưới
    // (mục 134, tái dùng khuôn mẫu đã kiểm chứng, không viết mới).
    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    ProgressCallback progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_ip(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char*>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
    } catch (const std::exception& ex) {
        LOGE("generate() (augmented) loi: %s", ex.what());
    }
    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

// ─────────────────────────────────────────────────────────────────────────
// 4b. JNI — img2img CÓ IP-Adapter (mục 115/117 TECHNICAL_STATUS.md,
//    "Multi-Pass Inpainting Cascade"). TRƯỚC hàm này, dự án có 2 nửa
//    RIÊNG BIỆT không ghép được: sdImg2Img (mnn_diffusion_pipeline.cpp)
//    có img2img+mask nhưng KHÔNG có IP-Adapter; sdTxt2ImgWithReferenceAndPose
//    (ở trên) có IP-Adapter nhưng LUÔN img2img=false. Hàm này GHÉP đúng cả
//    2 nửa — cần cho cascade sinh CẢNH ĐÔNG NGƯỜI theo nhiều lượt: lượt 1
//    sinh bố cục chung (sdTxt2ImgWithReferenceAndPose/TwoReferences hiện
//    có, không đổi), lượt 2..N+1 (Kotlin, MangaPipeline.kt) gọi hàm NÀY
//    lặp lại cho TỪNG nhân vật — img2img có mask khoanh đúng vùng cơ thể
//    người đó, denoise vừa phải (không full 1.0), CHỈ dùng ĐÚNG 1 ảnh
//    tham chiếu (identity) của người đó ở cường độ cao — "khoá" lại đúng
//    danh tính từng người mà không đụng phần còn lại của ảnh đã có.
//
// AN TOÀN KỸ THUẬT (đã đọc kỹ Pipeline.hpp/PipelineSd15CpuAugmented trước
// khi viết, không đoán): setConditioning()/setControlNetBalance()/
// setIpAdapterDecay() chỉ GHI vào state của handle->pipeline, ĐƯỢC ĐỌC bên
// trong onBeforeUnetRun() — hook này chạy TRONG vòng lặp denoise chung
// (generate()), ĐỘC LẬP HOÀN TOÀN với việc req.img2img là true hay false
// (cờ đó chỉ quyết định latent BAN ĐẦU lấy từ ảnh input hay noise thuần —
// xem generate() trong PipelineSd15CpuAugmented.hpp). 2 cơ chế không đụng
// chạm nhau — ghép an toàn, không cần sửa gì trong Pipeline.hpp.
// ─────────────────────────────────────────────────────────────────────────
extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdImg2ImgWithReferenceAndPose(JNIEnv* e, jobject,
    jlong ptr, jstring jPrompt, jstring jNeg, jstring jInputImage, jstring jMaskImage,
    jstring jRefImage, jfloatArray jSkeletonData, jfloat denoiseStrength,
    jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut,
    jfloat jPoseScale, jfloat jDepthScale, jfloat jDepthActiveMinTimestep,
    jfloat jIpDecayFloor, jfloat jIpDecayStartTimestep, jfloat jIpStaticScale, jobject cb) {

    auto* handle = reinterpret_cast<SdAugmentedHandle*>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdImg2ImgWithReferenceAndPose: chua init"); return JNI_FALSE; }

    // Phần IP-Adapter — GIỐNG HỆT sdTxt2ImgWithReferenceAndPose ở trên,
    // KHÔNG viết lại logic riêng (tránh 2 bản lệch nhau theo thời gian).
    std::vector<float> ipEmbed; std::vector<int> ipShape;
    if (!handle->ipEncoder->encode(j2s_ip(e, jRefImage), ipEmbed, ipShape)) {
        LOGE("sdImg2ImgWithReferenceAndPose: encode anh tham chieu that bai");
        return JNI_FALSE;
    }
    std::vector<pose_templates::Skeleton> chosen;
    if (jSkeletonData) {
        jsize len = e->GetArrayLength(jSkeletonData);
        std::vector<float> buf(len);
        e->GetFloatArrayRegion(jSkeletonData, 0, len, buf.data());
        chosen = pose_templates::parseSkeletonsFromFloatArray(buf.data(), (int)len);
    }
    if (chosen.empty()) {
        LOGI("sdImg2ImgWithReferenceAndPose: khong co skeleton hop le, dung fallback don gian");
        chosen = {pose_templates::fallbackStanding()};
    }
    auto controlHint = pose_templates::renderSkeletons(chosen, 512);
    auto depthHint = pose_templates::renderDepthHint(chosen, 512);
    handle->pipeline->setConditioning(ipEmbed, ipShape, controlHint, 512, depthHint);
    handle->pipeline->setControlNetBalance((float)jPoseScale, (float)jDepthScale, (float)jDepthActiveMinTimestep);
    handle->pipeline->setIpAdapterDecay((float)jIpDecayFloor, (float)jIpDecayStartTimestep, (float)jIpStaticScale);

    // Phần img2img+mask — GIỐNG HỆT sdImg2Img (mnn_diffusion_pipeline.cpp),
    // tái dùng đúng 2 helper resize/mask đã khai báo forward ở đầu file
    // này (không copy lại logic resize/pool 8x8 latent).
    std::string inputPath = j2s_ip(e, jInputImage);
    int srcW, srcH, srcC;
    unsigned char* srcPixels = stbi_load(inputPath.c_str(), &srcW, &srcH, &srcC, 3);
    if (!srcPixels) {
        LOGE("sdImg2ImgWithReferenceAndPose: khong doc duoc anh input: %s", inputPath.c_str());
        return JNI_FALSE;
    }

    GenerationRequest req;
    req.prompt = j2s_ip(e, jPrompt);
    req.negative_prompt = j2s_ip(e, jNeg);
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = handle->useOpenCL; req.use_npu = handle->useNpu;
    req.img2img = true;
    req.denoise_strength = denoiseStrength;
    req.img_data = resizeToCHWFloat(srcPixels, srcW, srcH, srcC, w, h);
    stbi_image_free(srcPixels);

    std::string maskPath = j2s_ip(e, jMaskImage);
    if (!maskPath.empty()) {
        int mw, mh, mc;
        unsigned char* maskPixels = stbi_load(maskPath.c_str(), &mw, &mh, &mc, 1);
        if (!maskPixels) {
            LOGE("sdImg2ImgWithReferenceAndPose: khong doc duoc mask: %s (bo qua, img2img toan anh)", maskPath.c_str());
        } else {
            resizeMaskBoth(maskPixels, mw, mh, w, h, req.mask_data_full, req.mask_data);
            stbi_image_free(maskPixels);
            req.has_mask = true;
            req.user_supplied_mask = true;
        }
    }

    // Progress callback — GIỐNG HỆT sdImg2Img, tái dùng đúng khuôn mẫu
    // AttachCurrentThread/DetachCurrentThread đã kiểm chứng (dùng ở nhiều
    // nơi khác trong dự án, không phải lần đầu viết).
    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    ProgressCallback progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_ip(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char*>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
        LOGI("sdImg2ImgWithReferenceAndPose xong: %dx%d, mask=%d", result.width, result.height, (int)req.has_mask);
    } catch (const std::exception& ex) {
        LOGE("sdImg2ImgWithReferenceAndPose: generate() loi: %s", ex.what());
    }
    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

// ─────────────────────────────────────────────────────────────────────────
// 5. JNI — 2 nhân vật, MASK VÙNG (mục "Multi-IP-Adapter co mask" —
//    TECHNICAL_STATUS.md, trước đây "CHỦ ĐỘNG CHƯA làm"). Dùng ctx đã
//    sdInitAugmented() NHƯNG với unetAugmentedPath TRỎ TỚI
//    unet_ipa_mask_controlnet.mnn (bản 2 nhân vật, xem tools/
//    export_ipa_controlnet_mask_unet.py) — KHÔNG dùng lẫn với
//    unet_ipa_controlnet.mnn (1 nhân vật/depth) — 2 file .mnn có input
//    "ip_image_embeds" KHÁC shape nhau, gọi nhầm sẽ bị LOGE cảnh báo ở
//    onBeforeUnetRun() (không crash, nhưng ảnh ra sai) chứ không tự kiểm
//    tra được từ phía Kotlin — người dùng workflow phải tự chọn đúng model
//    theo số nhân vật, giống cách chọn model theo checkpoint hiện có.
// ─────────────────────────────────────────────────────────────────────────
extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgWithTwoReferencesAndPose(JNIEnv* e, jobject,
    jlong ptr, jstring jPrompt, jstring jNeg, jstring jRefImage1, jstring jRefImage2,
    jfloatArray jSkeletonData, jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut) {

    auto* handle = reinterpret_cast<SdAugmentedHandle*>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgWithTwoReferencesAndPose: chua init"); return JNI_FALSE; }

    // Mỗi nhân vật encode RIÊNG qua đúng 1 model ip_image_encoder.mnn (KHÔNG
    // đổi so với bản 1-nhân-vật) — ghép 2 kết quả lại ở tầng native
    // (onBeforeUnetRun), không cần encoder thứ 2.
    std::vector<float> ipEmbed1, ipEmbed2; std::vector<int> ipShape1, ipShape2;
    if (!handle->ipEncoder->encode(j2s_ip(e, jRefImage1), ipEmbed1, ipShape1)) {
        LOGE("Encode anh tham chieu nhan vat 1 that bai");
        return JNI_FALSE;
    }
    if (!handle->ipEncoder->encode(j2s_ip(e, jRefImage2), ipEmbed2, ipShape2)) {
        LOGE("Encode anh tham chieu nhan vat 2 that bai");
        return JNI_FALSE;
    }

    // skeletonData: giống sdTxt2ImgWithReferenceAndPose — đã retargeted từ
    // Kotlin, THỨ TỰ person[0]/person[1] PHẢI khớp đúng thứ tự refImage1/
    // refImage2 (cùng invariant đã xác lập ở mục 32/33 — Kotlin chịu trách
    // nhiệm giữ đúng thứ tự này, native không tự đối chiếu được).
    std::vector<pose_templates::Skeleton> chosen;
    if (jSkeletonData) {
        jsize len = e->GetArrayLength(jSkeletonData);
        std::vector<float> buf(len);
        e->GetFloatArrayRegion(jSkeletonData, 0, len, buf.data());
        chosen = pose_templates::parseSkeletonsFromFloatArray(buf.data(), (int)len);
    }
    if (chosen.size() < 2) {
        // Cần ÍT NHẤT 2 người để mask có ý nghĩa — thiếu dữ liệu skeleton
        // cho 1 trong 2 người thì dùng fallback đứng đơn giản CHO CẢ 2 (dàn
        // sang trái/phải) thay vì chỉ 1 người như fallbackStanding() gốc,
        // để mask trái/phải vẫn tách được vùng dù pose không chính xác.
        LOGI("Khong du 2 skeleton hop le tu Kotlin, dung fallback dan trai/phai don gian");
        auto s1 = pose_templates::fallbackStanding();
        auto s2 = pose_templates::fallbackStanding();
        for (auto& k : s1) k.x *= 0.5f;               // dồn sang nửa trái khung hình
        for (auto& k : s2) k.x = k.x * 0.5f + 0.5f;    // dồn sang nửa phải khung hình
        chosen = {s1, s2};
    }
    auto controlHint = pose_templates::renderSkeletons(chosen, 512);
    auto maskHint1 = pose_templates::renderCharacterMask(chosen, 0, 512);
    auto maskHint2 = pose_templates::renderCharacterMask(chosen, 1, 512);

    handle->pipeline->setConditioningTwoCharacters(ipEmbed1, ipEmbed2, ipShape1,
                                                    controlHint, 512, maskHint1, maskHint2);

    GenerationRequest req;
    req.prompt = j2s_ip(e, jPrompt);
    req.negative_prompt = j2s_ip(e, jNeg);
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = handle->useOpenCL; req.use_npu = handle->useNpu; req.img2img = false;

    try {
        GenerationResult result = handle->pipeline->generate(req, [](int,int,const std::string&){});
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_ip(e, jOut), std::ios::binary);
        if (!out) return JNI_FALSE;
        out.write(reinterpret_cast<const char*>(png.data()), (std::streamsize)png.size());
        return JNI_TRUE;
    } catch (const std::exception& ex) {
        LOGE("generate() (augmented, 2 nhan vat) loi: %s", ex.what());
        return JNI_FALSE;
    }
}

// ─────────────────────────────────────────────────────────────────────────
// 6. JNI — TỔNG QUÁT HOÁ mục 5: N NHÂN VẬT thay vì cố định 2 (mục 52
//    TECHNICAL_STATUS.md — user hỏi "nếu ảnh có >2 nhân vật thì sao").
//    jRefImagePaths: mảng String[] (String[] Java -> jobjectArray JNI),
//    1 phần tử/nhân vật, THỨ TỰ PHẢI khớp thứ tự người trong skeletonData
//    (person[i] <-> jRefImagePaths[i], cùng invariant đã có ở mục 32/33).
//    N THẬT SỰ dùng được bị GIỚI HẠN BỞI MODEL .mnn ĐÃ EXPORT (cố định lúc
//    export_ipa_controlnet_mask_unet.py --num_characters N, xem tool đó) —
//    hàm này KHÔNG tự đổi N của model, chỉ tự cắt bớt/điền thiếu cho khớp
//    N thật của model (xem onBeforeUnetRun(), có LOGE cảnh báo nếu lệch).
//    sdTxt2ImgWithTwoReferencesAndPose() (mục 5) VẪN GIỮ NGUYÊN, không xoá
//    — chỉ là trường hợp N=2 của hàm này, giữ lại cho code Kotlin cũ (nếu
//    có) không phải sửa.
// ─────────────────────────────────────────────────────────────────────────
extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgWithCharactersAndPose(JNIEnv* e, jobject,
    jlong ptr, jstring jPrompt, jstring jNeg, jobjectArray jRefImagePaths,
    jfloatArray jSkeletonData, jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut,
    jfloat jIpDecayFloor, jfloat jIpDecayStartTimestep, jfloat jIpStaticScale,
    jfloatArray jIpDecayFloors, jfloatArray jIpDecayStartTimesteps, jfloatArray jIpStaticScales,
    jobject cb) {

    auto* handle = reinterpret_cast<SdAugmentedHandle*>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgWithCharactersAndPose: chua init"); return JNI_FALSE; }
    if (!jRefImagePaths) { LOGE("sdTxt2ImgWithCharactersAndPose: refImagePaths null"); return JNI_FALSE; }

    jsize numChars = e->GetArrayLength(jRefImagePaths);
    if (numChars <= 0) { LOGE("sdTxt2ImgWithCharactersAndPose: can it nhat 1 nhan vat"); return JNI_FALSE; }

    // Encode RIÊNG từng ảnh qua đúng 1 model ip_image_encoder.mnn (KHÔNG
    // đổi so với bản 1/2-nhân-vật) — số lần gọi = số nhân vật, tăng tuyến
    // tính theo N (chi phí compute trên điện thoại tăng theo N, không có
    // cách nào tránh — mỗi nhân vật cần 1 ảnh tham chiếu riêng để encode).
    std::vector<std::vector<float>> ipEmbeds;
    std::vector<int> ipShape;  // dùng chung shape (mọi nhân vật cùng 1 model encoder -> cùng shape)
    for (jsize i = 0; i < numChars; i++) {
        auto* jpath = (jstring)e->GetObjectArrayElement(jRefImagePaths, i);
        std::vector<float> embed; std::vector<int> shape;
        bool ok = handle->ipEncoder->encode(j2s_ip(e, jpath), embed, shape);
        e->DeleteLocalRef(jpath);
        if (!ok) {
            LOGE("Encode anh tham chieu nhan vat %d that bai", (int)i);
            return JNI_FALSE;
        }
        if (i == 0) ipShape = shape;
        ipEmbeds.push_back(std::move(embed));
    }

    std::vector<pose_templates::Skeleton> chosen;
    if (jSkeletonData) {
        jsize len = e->GetArrayLength(jSkeletonData);
        std::vector<float> buf(len);
        e->GetFloatArrayRegion(jSkeletonData, 0, len, buf.data());
        chosen = pose_templates::parseSkeletonsFromFloatArray(buf.data(), (int)len);
    }
    if ((jsize)chosen.size() < numChars) {
        // Thiếu skeleton cho đủ N người — dàn đều fallback đứng đơn giản
        // theo chiều ngang (chia khung hình thành numChars cột dọc bằng
        // nhau) để mask vẫn tách được vùng dù pose không chính xác. Với N
        // lớn (>=4), các cột hẹp dần — mask vẫn hợp lệ về mặt kỹ thuật
        // nhưng CHẤT LƯỢNG PHÂN TÁCH GIẢM RÕ RỆT (xem giới hạn thực tế ở
        // cuối comment này).
        LOGI("Khong du %d skeleton hop le tu Kotlin, dung fallback dan cot don gian", (int)numChars);
        chosen.clear();
        for (jsize i = 0; i < numChars; i++) {
            auto s = pose_templates::fallbackStanding();
            float lo = (float)i / (float)numChars, hi = (float)(i + 1) / (float)numChars;
            for (auto& k : s) k.x = lo + k.x * (hi - lo);
            chosen.push_back(s);
        }
    }
    auto controlHint = pose_templates::renderSkeletons(chosen, 512);
    std::vector<std::vector<uint8_t>> maskHints;
    for (jsize i = 0; i < numChars; i++)
        maskHints.push_back(pose_templates::renderCharacterMask(chosen, (size_t)i, 512));

    handle->pipeline->setConditioningMultiCharacter(ipEmbeds, ipShape, controlHint, 512, maskHints);
    // Smooth Timestep Decay + consistencyStrength (mục 97/99/100) — TRƯỚC
    // ĐÂY hàm này KHÔNG gọi setIpAdapterDecay(), khiến 2 tham số Settings
    // đó không có tác dụng gì ở đường multi-char dù model .mnn export theo
    // mục 100 đã có input — đã nối nốt ở đây.
    handle->pipeline->setIpAdapterDecay((float)jIpDecayFloor, (float)jIpDecayStartTimestep, (float)jIpStaticScale);
    // mục 147 TECHNICAL_STATUS.md — Per-Instance Decay: 3 mảng MỚI, TUỲ
    // CHỌN (null hợp lệ — Kotlin chưa truyền/model .mnn cũ chưa hỗ trợ ->
    // fallback scalar 3 dòng trên, tương thích ngược hoàn toàn). Nếu Kotlin
    // TRUYỀN đủ (thường = numChars phần tử, khớp Scene.expression từng
    // người tại panel này, xem MangaPipeline.kt), mỗi nhân vật được suy
    // giảm ĐỘC LẬP thay vì dùng chung 1 giá trị.
    if (jIpDecayFloors && jIpDecayStartTimesteps && jIpStaticScales) {
        auto readArr = [&](jfloatArray arr) {
            std::vector<float> v;
            jsize len = e->GetArrayLength(arr);
            v.resize(len);
            e->GetFloatArrayRegion(arr, 0, len, v.data());
            return v;
        };
        handle->pipeline->setIpAdapterDecayMultiCharacter(
            readArr(jIpDecayFloors), readArr(jIpDecayStartTimesteps), readArr(jIpStaticScales));
    }

    GenerationRequest req;
    req.prompt = j2s_ip(e, jPrompt);
    req.negative_prompt = j2s_ip(e, jNeg);
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = handle->useOpenCL; req.use_npu = handle->useNpu; req.img2img = false;

    // Progress callback — mục 134, khuôn mẫu GIỐNG HỆT
    // sdTxt2ImgWithReferenceAndPose/sdImg2ImgWithReferenceAndPose ở trên.
    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    ProgressCallback progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_ip(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char*>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
    } catch (const std::exception& ex) {
        LOGE("generate() (augmented, %d nhan vat) loi: %s", (int)numChars, ex.what());
    }
    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

// GIỚI HẠN THỰC TẾ khi N > 2 (nói rõ, không phóng đại — mục 52
// TECHNICAL_STATUS.md):
//   1. Model .mnn CỐ ĐỊNH shape lúc export (dự án này KHÔNG dùng
//      dynamic_axes ở bất kỳ export script nào) — muốn dùng N=3 hay N=4
//      PHẢI export riêng 1 file unet_ipa_mask_controlnet.mnn cho ĐÚNG N đó
//      (xem --num_characters trong tools/export_ipa_controlnet_mask_unet.py
//      và prepare_models.yml), không thể "vừa dùng N=2 vừa dùng N=4" trên
//      cùng 1 file model.
//   2. Chất lượng: tài liệu/PR chính thức của diffusers mà dự án này tra
//      cứu (xem mục 52) chỉ đưa ví dụ CỤ THỂ cho 2 ảnh/mask — cơ chế NHÂN
//      LOÊN được (list N ảnh/N mask là hợp lệ theo API), nhưng CHƯA có xác
//      nhận thật (kể cả từ tài liệu bên thứ 3) về việc N>=4 vùng ảnh vẫn
//      giữ tách bạch tốt trên 1 panel 512x512 — vùng mỗi nhân vật càng nhỏ,
//      IP-Adapter càng ít pixel để "bám" đặc trưng khuôn mặt/trang phục,
//      NHIỀU KHẢ NĂNG chất lượng giữ identity giảm dần theo N tăng (dự
//      đoán hợp lý dựa trên cơ chế, KHÔNG PHẢI đã đo thật — cần test trên
//      thiết bị thật với N=3/4 mới biết mức độ cụ thể).
//   3. Chi phí: N lần encode ảnh (CPU/OpenCL, rẻ) + UNet 1 lần/step vẫn y
//      hệt (self-attention/cross-attention chỉ tăng theo tổng số token
//      ip_image_embeds, không tăng theo N model pass) — tăng chi phí chủ
//      yếu ở BƯỚC EXPORT/DUNG LƯỢNG MODEL (mỗi N cần 1 file .mnn riêng),
//      không phải chi phí runtime trên điện thoại tăng vọt.
// Khuyến nghị thực tế: N=2 là trường hợp có xác nhận nguồn thật rõ ràng
// nhất; N=3 nhiều khả năng vẫn ổn (mở rộng tự nhiên của cùng cơ chế); N>=4
// nên test kỹ trước khi dùng trong production, tuong tu moi phan native
// khac cua du an (CHƯA XÁC NHẬN CHẠY THẬT).

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdFreeAugmented(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<SdAugmentedHandle*>(ptr);
}

// mục 69 TECHNICAL_STATUS.md — đóng gap mục 56/67 ("dự án CHƯA có hàm
// dựng skeleton canvas dùng chung giữa Kotlin và regional_prompting.cpp",
// xem comment NativeBridge.kt.sdTxt2ImgRegional). KHÔNG viết lại thuật
// toán vẽ skeleton ở Kotlin (rủi ro lệch màu/định dạng so với
// renderSkeletons() ĐANG DÙNG THẬT cho ip_adapter.cpp — 2 bản vẽ khác
// nhau sẽ cho ControlNet 2 kiểu input khác nhau, model sẽ phản ứng khác
// nhau dù cùng 1 tư thế). Thay vào đó: export THẲNG hàm renderSkeletons()
// đã có sẵn qua JNI, Kotlin gọi lại ĐÚNG hàm này — đảm bảo Regional
// Prompting dùng CHÍNH XÁC cùng 1 định dạng canvas với pipeline IP-Adapter
// đã build-test được (dù cả 2 đều CHƯA chạy thật trên máy — ít nhất KHÔNG
// tự tạo thêm 1 nguồn lệch pha mới giữa 2 nhánh).
// skeletonData: cùng định dạng resolveSkeletonData() Kotlin đã trả (N
// người * 18 khớp * 4 float [x,y,z,visible]). Trả về mảng byte RGB HWC
// size*size*3, hoặc mảng RỖNG nếu skeletonData không hợp lệ (Kotlin tự
// fallback sang canvas đen/không vẽ gì nếu nhận mảng rỗng, KHÔNG throw).
extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_mangalocal_pipeline_NativeBridge_renderSkeletonCanvas(JNIEnv* e, jobject,
    jfloatArray jSkeletonData, jint size) {

    std::vector<pose_templates::Skeleton> chosen;
    if (jSkeletonData) {
        jsize len = e->GetArrayLength(jSkeletonData);
        std::vector<float> buf(len);
        e->GetFloatArrayRegion(jSkeletonData, 0, len, buf.data());
        chosen = pose_templates::parseSkeletonsFromFloatArray(buf.data(), (int)len);
    }
    if (chosen.empty()) {
        LOGE("renderSkeletonCanvas: skeletonData rong/khong hop le, tra mang rong");
        return e->NewByteArray(0);
    }
    auto canvas = pose_templates::renderSkeletons(chosen, (int)size);
    jbyteArray result = e->NewByteArray((jsize)canvas.size());
    e->SetByteArrayRegion(result, 0, (jsize)canvas.size(), reinterpret_cast<const jbyte*>(canvas.data()));
    return result;
}

// mục 151 TECHNICAL_STATUS.md — SONG SINH với renderSkeletonCanvas() ở
// trên (copy nguyên cấu trúc, chỉ đổi hàm render bên trong) — cần cho
// pipeline Triple-Conditioning combo (tools/export_ipa_controlnet_triple_
// combo_unet.py, mục 143/147): file triple_combo.cpp KHÔNG include
// ip_adapter.cpp (đúng quy ước "không phụ thuộc chéo .cpp" đã áp dụng cho
// regional_prompting.cpp — xem comment đầu file đó), nên PHẢI có 1 JNI
// entry point ĐỘC LẬP ở đây (nơi pose_templates::renderDepthHint() sẵn có)
// để Kotlin gọi lấy buffer RGB rồi truyền tiếp — ĐÚNG cách renderSkeletonCanvas
// đã làm cho control_hint của Regional Prompting.
extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_mangalocal_pipeline_NativeBridge_renderDepthHintCanvas(JNIEnv* e, jobject,
    jfloatArray jSkeletonData, jint size) {

    std::vector<pose_templates::Skeleton> chosen;
    if (jSkeletonData) {
        jsize len = e->GetArrayLength(jSkeletonData);
        std::vector<float> buf(len);
        e->GetFloatArrayRegion(jSkeletonData, 0, len, buf.data());
        chosen = pose_templates::parseSkeletonsFromFloatArray(buf.data(), (int)len);
    }
    if (chosen.empty()) {
        LOGE("renderDepthHintCanvas: skeletonData rong/khong hop le, tra mang rong");
        return e->NewByteArray(0);
    }
    auto canvas = pose_templates::renderDepthHint(chosen, (int)size);
    jbyteArray result = e->NewByteArray((jsize)canvas.size());
    e->SetByteArrayRegion(result, 0, (jsize)canvas.size(), reinterpret_cast<const jbyte*>(canvas.data()));
    return result;
}
