// ip_adapter_sdxl.cpp — mục 177 TECHNICAL_STATUS.md (SDXL Phase 2b). Chạy
// UNet SDXL đã gộp sẵn IP-Adapter (giữ nhân vật, 1 người) + ControlNet-
// OpenPose-SDXL (giữ tư thế), xuất bởi
// tools/export_ipa_controlnet_unet_sdxl.py — bản SDXL tương đương
// ip_adapter.cpp (SD1.5), CHỈ phần cơ bản nhất (xem "PHẠM VI" bên dưới).
//
// KHÔNG include chéo ip_adapter.cpp (đúng quy ước "không phụ thuộc chéo
// .cpp" đã áp dụng cho regional_prompting.cpp/triple_combo.cpp/
// regional_mask_prompting.cpp — xem comment đầu triple_combo.cpp) — file
// này TỰ CHỨA 1 bản `IpImageEncoderSdxl` riêng (copy gần như nguyên văn
// `IpImageEncoder` của ip_adapter.cpp — API hoàn toàn generic, không có gì
// SD1.5-specific trong lớp đó) và KHÔNG tự vẽ pose — nhận thẳng
// `controlHintRgb: ByteArray` đã render sẵn từ Kotlin (gọi
// NativeBridge.renderSkeletonCanvas() có sẵn từ mục 69, ĐÚNG quy ước
// triple_combo.cpp/regional_mask_prompting.cpp đã dùng, KHÔNG phải quy
// ước cũ hơn của chính ip_adapter.cpp).
//
// PHẠM VI CÓ CHỦ ĐÍCH — CHỈ BẢN CƠ BẢN NHẤT (xem docstring đầu
// tools/export_ipa_controlnet_unet_sdxl.py để biết lý do đầy đủ): 1 nhân
// vật, IP-Adapter + ControlNet-Pose, KHÔNG depth, KHÔNG mask N-nhân-vật,
// KHÔNG Regional Prompting, KHÔNG Smooth Timestep Decay, KHÔNG cân bằng
// ControlNet (pose_scale/depth_scale) — tất cả những thứ đó đã có cho
// SD1.5 qua RẤT NHIỀU đợt riêng (mục 51/52/56/81/97/146/147), nhồi hết vào
// đây cùng lúc là rủi ro chồng rủi ro không cần thiết.
//
// GIỚI HẠN THẬT — đọc kỹ trước khi tin đây là "đã xong" (mục 177):
//   1. CHƯA build-test — như MỌI phần khác của dự án (mục 0), không có
//      GPU/NDK/thiết bị thật trong sandbox lúc viết.
//   2. `encodePNG`/`createMnnInterpreterMmap`/`createMnnSession`/
//      `GenerationRequest`/`GenerationResult` dùng qua include gián tiếp
//      (PipelineSdxlCpu.hpp -> Pipeline.hpp/MnnUtils.hpp) giống hệt
//      triple_combo.cpp/regional_mask_prompting.cpp — CHƯA verify lại
//      bằng linker thật (không có NDK trong sandbox).
//   3. `onBeforeUnetRun()` hook vừa được THÊM MỚI vào PipelineSdxlCpu.hpp
//      (mục 177) — bản mục 59 gốc KHÔNG có hook này (chỉ base txt2img
//      cần), nên đây là thay đổi vào 1 file NỀN đã có, không chỉ file mới
//      — rủi ro cao hơn 1 chút so với chỉ thêm file mới, đã cố gắng mirror
//      CHÍNH XÁC PipelineSd15Cpu.hpp (đã build-CI qua ít nhất 1 lần, xem
//      mục 156) để giảm rủi ro.
//   4. KIẾN TRÚC IP-Adapter+ControlNet CÙNG LÚC trên UNet SDXL trong 1 lần
//      forward() CHƯA có xác nhận thật nào (kể cả bên thứ 3) — khác SD1.5
//      (đã build-test được, mục 4/28) — xem đầy đủ ở docstring
//      export_ipa_controlnet_unet_sdxl.py.
//   5. Hiệu năng CPU/OpenCL CHƯA đo — UNet SDXL ~2.6B tham số, có bằng
//      chứng THẬT (wiki local-dream, dự án gốc port kiến trúc pipeline)
//      cho thấy SDXL có thể cần NPU (Snapdragon 8 Gen 3+) mới chạy đủ
//      nhanh để dùng được — xem TECHNICAL_STATUS.md mục 177.

#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <memory>
#include <fstream>
#include <algorithm>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

#include "sd_engine/PipelineSdxlCpu.hpp"
#include "sd_engine/TextEncoder.hpp"

extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
}
#include "sd_engine/stb_image_resize2.h"  // dùng include thật, tránh lệch chữ ký ABI (giống ip_adapter.cpp)

#define TAG "MangaLocal_IPAdapterSDXL"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ─────────────────────────────────────────────────────────────────────────
// 1. Image encoder — COPY gần như nguyên văn IpImageEncoder (ip_adapter.cpp)
//    — API generic (resize 224x224 + chuẩn hoá CLIP chuẩn), KHÔNG có gì
//    SD1.5-specific. Encoder SDXL dùng OpenCLIP-ViT-bigG-14 (khác ViT-H-14
//    của SD1.5) nhưng tiền xử lý ảnh đầu vào GIỐNG HỆT (chuẩn CLIP chung,
//    chỉ khác chiều embedding OUTPUT — mà hàm này đã TỰ đọc shape thật từ
//    tensor, không hardcode số, nên không cần đổi gì).
// ─────────────────────────────────────────────────────────────────────────
class IpImageEncoderSdxl {
public:
    explicit IpImageEncoderSdxl(const std::string& modelPath) {
        net_.reset(MNN::Interpreter::createFromFile(modelPath.c_str()));
        if (!net_) { LOGE("IpImageEncoderSdxl: khong doc duoc %s", modelPath.c_str()); return; }
        MNN::ScheduleConfig cfg; cfg.type = MNN_FORWARD_CPU; cfg.numThread = 4;
        session_ = net_->createSession(cfg);
        ok_ = session_ != nullptr;
    }
    bool ok() const { return ok_; }

    bool encode(const std::string& imagePath, std::vector<float>& outEmbed, std::vector<int>& outShape) {
        if (!ok_) return false;
        int w, h, c;
        unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("IpImageEncoderSdxl: load anh fail %s", imagePath.c_str()); return false; }

        std::vector<unsigned char> resized(224 * 224 * 3);
        stbir_resize_uint8_srgb(data, w, h, 0, resized.data(), 224, 224, 0, STBIR_RGB);
        stbi_image_free(data);

        auto inputs = net_->getSessionInputAll(session_);
        if (inputs.empty()) { LOGE("ip_image_encoder_sdxl.mnn khong co input"); return false; }
        MNN::Tensor* input = inputs.begin()->second;

        MNN::Tensor hostIn(input, MNN::Tensor::CAFFE);
        const float mean[3] = {0.481f, 0.457f, 0.408f};
        const float stdv[3] = {0.268f, 0.261f, 0.275f};
        for (int y = 0; y < 224; y++) for (int x = 0; x < 224; x++) {
            unsigned char* p = resized.data() + (y * 224 + x) * 3;
            for (int ch = 0; ch < 3; ch++)
                hostIn.host<float>()[ch*224*224 + y*224 + x] = (p[ch]/255.f - mean[ch]) / stdv[ch];
        }
        input->copyFromHostTensor(&hostIn);
        net_->runSession(session_);

        auto outputs = net_->getSessionOutputAll(session_);
        if (outputs.empty()) { LOGE("ip_image_encoder_sdxl.mnn khong co output"); return false; }
        MNN::Tensor* output = outputs.begin()->second;
        MNN::Tensor hostOut(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&hostOut);

        outShape = hostOut.shape();
        size_t n = 1; for (int d : outShape) n *= (size_t)std::max(1, d);
        outEmbed.assign(hostOut.host<float>(), hostOut.host<float>() + n);
        return true;
    }
private:
    std::shared_ptr<MNN::Interpreter> net_;
    MNN::Session* session_ = nullptr;
    bool ok_ = false;
};

// ─────────────────────────────────────────────────────────────────────────
// 2. Pipeline mở rộng — override hook onBeforeUnetRun() vừa thêm vào
//    PipelineSdxlCpu.hpp (mục 177) để nạp thêm "control_hint" +
//    "ip_image_embeds" trước mỗi bước UNet. KHÁC PipelineSd15CpuAugmented:
//    KHÔNG có setConditioningMultiCharacter()/depth/decay — bản cơ bản
//    nhất, xem "PHẠM VI" ở đầu file.
// ─────────────────────────────────────────────────────────────────────────
class PipelineSdxlCpuAugmented : public PipelineSdxlCpu {
public:
    PipelineSdxlCpuAugmented(TextEncoder& te, const std::string& dir,
        const std::string& clipL, const std::string& clipG, const std::string& unet,
        const std::string& vaeDec, const std::string& vaeEnc)
        : PipelineSdxlCpu(te, dir, clipL, clipG, unet, vaeDec, vaeEnc) {}

    // Gọi 1 lần trước khi bắt đầu sinh ảnh — set embedding nhân vật + tư
    // thế (controlHintRgb ĐÃ RENDER SẴN từ Kotlin, xem comment đầu file).
    // depthHintRgb: TUỲ CHỌN (mục 181 TECHNICAL_STATUS.md, Phase 2f) — rỗng
    // = không set (mirror ĐÚNG hành vi optional của depth_hint SD1.5).
    void setConditioning(const std::vector<float>& ipEmbed, const std::vector<int>& ipShape,
                          const std::vector<uint8_t>& controlHintRgb, int controlWidth, int controlHeight,
                          const std::vector<uint8_t>& depthHintRgb = {}) {
        ipEmbed_ = ipEmbed; ipShape_ = ipShape;
        controlHintRgb_ = controlHintRgb; controlWidth_ = controlWidth; controlHeight_ = controlHeight;
        depthHintRgb_ = depthHintRgb;
        hasConditioning_ = true;
        // mục 178 TECHNICAL_STATUS.md — reset trạng thái multi-character
        // của lần gọi TRƯỚC (pipeline object TÁI SỬ DỤNG qua nhiều lần sinh
        // ảnh trên cùng ctx) — mirror ĐÚNG lý do đã có ở ip_adapter.cpp
        // (SD1.5, setConditioning()), tránh bug im lặng "sót mask cũ".
        hasMultiCharacter_ = false;
        multiEmbeds_.clear(); multiMasks_.clear();
    }

    // mục 178 TECHNICAL_STATUS.md (SDXL Phase 2c) — Multi-IP-Adapter CÓ
    // MASK VÙNG, N NHÂN VẬT. Mirror ĐÚNG setConditioningMultiCharacter()
    // (SD1.5, ip_adapter.cpp mục 52) — cùng invariant: ipEmbeds[i] <->
    // maskHints[i] <-> person i, N model ĐỌC THẬT từ tensor lúc chạy
    // (KHÔNG hardcode), KHÔNG có decay (khác SD1.5 — xem "PHẠM VI" đầu
    // tools/export_ipa_controlnet_mask_unet_sdxl.py).
    void setConditioningMultiCharacter(const std::vector<std::vector<float>>& ipEmbeds,
                          const std::vector<int>& ipShape,
                          const std::vector<uint8_t>& controlHintRgb, int controlWidth, int controlHeight,
                          const std::vector<std::vector<uint8_t>>& maskHints) {
        ipEmbed_ = ipEmbeds.empty() ? std::vector<float>{} : ipEmbeds[0];
        multiEmbeds_ = ipEmbeds; ipShape_ = ipShape;
        controlHintRgb_ = controlHintRgb; controlWidth_ = controlWidth; controlHeight_ = controlHeight;
        multiMasks_ = maskHints;
        hasConditioning_ = true;
        hasMultiCharacter_ = true;
    }

protected:
    void onBeforeUnetRun(MNN::Interpreter* unetInterp, MNN::Session* unetSess) override {
        if (!hasConditioning_) return;  // không có điều kiện phụ -> chạy như base txt2img SDXL (mục 59)

        // ip_image_embeds — tên tự đặt trong export_ipa_controlnet_unet_sdxl.py
        // (giống hệt quy ước ip_image_embeds của SD1.5, xem ip_adapter.cpp).
        // mục 178 — TỰ NHẬN BIẾT model 1 nhân vật hay N nhân vật qua
        // elementSize() THẬT (mirror ĐÚNG logic ip_adapter.cpp dòng
        // 465-501, không hardcode N).
        if (auto* t = unetInterp->getSessionInput(unetSess, "ip_image_embeds")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            size_t total = (size_t)host.elementSize();
            if (hasMultiCharacter_ && !multiEmbeds_.empty() && !multiEmbeds_[0].empty()) {
                size_t single = multiEmbeds_[0].size();
                size_t nModel = (single > 0 && total % single == 0) ? total / single : 0;
                if (nModel == 0) {
                    LOGE("ip_image_embeds shape khong chia het cho embedding 1 nhan vat - model nay co dung dinh dang mask-N-nhan-vat khong?");
                    size_t n = std::min(single, total);
                    memcpy(host.host<float>(), multiEmbeds_[0].data(), n * sizeof(float));
                } else {
                    if (nModel != multiEmbeds_.size()) {
                        LOGE("Model nay xuat cho %zu nhan vat nhung app truyen %zu anh tham chieu - se cat bot/dien 0 cho khop",
                             nModel, multiEmbeds_.size());
                    }
                    size_t nWrite = std::min(nModel, multiEmbeds_.size());
                    for (size_t i = 0; i < nWrite; i++) {
                        size_t ni = std::min(multiEmbeds_[i].size(), single);
                        memcpy(host.host<float>() + i * single, multiEmbeds_[i].data(), ni * sizeof(float));
                    }
                    if (nModel > multiEmbeds_.size()) {
                        std::fill(host.host<float>() + multiEmbeds_.size() * single,
                                  host.host<float>() + nModel * single, 0.f);
                    }
                }
            } else {
                size_t single = ipEmbed_.size();
                size_t n = std::min(single, total);
                memcpy(host.host<float>(), ipEmbed_.data(), n * sizeof(float));
            }
            t->copyFromHostTensor(&host);
        } else {
            LOGE("Model nay khong co input 'ip_image_embeds' - co phai unet_ipa_controlnet_sdxl.mnn chua?");
        }

        // ip_adapter_masks — CHỈ có ở model mask N-nhân-vật, TUỲ CHỌN (model
        // 1-người hợp lệ không có input này). Mirror ĐÚNG ip_adapter.cpp
        // dòng 503-541 (N suy từ elementSize()/(width*height), KHÔNG
        // hardcode; thiếu mask -> điền 1.0 = "không mask", AN TOÀN hơn 0.0).
        if (auto* t = unetInterp->getSessionInput(unetSess, "ip_adapter_masks")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            size_t plane = (size_t)controlWidth_ * controlHeight_;
            size_t total = (size_t)host.elementSize();
            size_t nModel = (plane > 0 && total % plane == 0) ? total / plane : 0;
            if (hasMultiCharacter_ && !multiMasks_.empty() && nModel > 0) {
                size_t nWrite = std::min(nModel, multiMasks_.size());
                for (size_t i = 0; i < nWrite; i++) {
                    const auto& m = multiMasks_[i];
                    for (size_t px = 0; px < plane; px++)
                        host.host<float>()[i * plane + px] = (px < m.size() ? m[px] / 255.f : 1.f);
                }
                if (nModel > multiMasks_.size()) {
                    std::fill(host.host<float>() + multiMasks_.size() * plane,
                              host.host<float>() + nModel * plane, 1.f);
                }
            } else {
                std::fill(host.host<float>(), host.host<float>() + host.elementSize(), 1.f);
            }
            t->copyFromHostTensor(&host);
        }

        // control_hint — ảnh RGB khung xương, chuẩn hoá [0,1], NCHW — cùng
        // layout đã xác nhận qua tra cứu web cho SD1.5 (mục 161 đợt 7, xem
        // ip_adapter.cpp) — NCHW là quy ước cố định PyTorch/ONNX, không đổi
        // theo kiến trúc SD1.5/SDXL.
        if (auto* t = unetInterp->getSessionInput(unetSess, "control_hint")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            int width = controlWidth_, height = controlHeight_;
            for (int y = 0; y < height; y++) for (int x = 0; x < width; x++) {
                const uint8_t* p = controlHintRgb_.data() + ((size_t)y*width+x)*3;
                for (int ch = 0; ch < 3; ch++)
                    host.host<float>()[(size_t)ch*height*width + y*width + x] = p[ch] / 255.f;
            }
            t->copyFromHostTensor(&host);
        } else {
            LOGE("Model nay khong co input 'control_hint' - co phai unet_ipa_controlnet_sdxl.mnn chua?");
        }

        // depth_hint — THÊM MỚI, TUỲ CHỌN (mục 181 TECHNICAL_STATUS.md,
        // Phase 2f). KHÔNG log lỗi nếu model không có input này — model CŨ
        // (chưa re-export depth, tức file mục 177) hợp lệ không có input
        // này, đây là hành vi ĐÚNG — mirror CHÍNH XÁC ip_adapter.cpp dòng
        // 565-588 (SD1.5, mục 51).
        if (auto* t = unetInterp->getSessionInput(unetSess, "depth_hint")) {
            MNN::Tensor host(t, MNN::Tensor::CAFFE);
            if (!depthHintRgb_.empty()) {
                int width = controlWidth_, height = controlHeight_;
                for (int y = 0; y < height; y++) for (int x = 0; x < width; x++) {
                    const uint8_t* p = depthHintRgb_.data() + ((size_t)y*width+x)*3;
                    for (int ch = 0; ch < 3; ch++)
                        host.host<float>()[(size_t)ch*height*width + y*width + x] = p[ch] / 255.f;
                }
            } else {
                // Model MỚI (có input depth_hint) nhưng caller chưa truyền
                // depth (vd panel không có ≥2 người chồng lấn) — gửi canvas
                // đen thay vì để tensor rác chưa khởi tạo, an toàn hơn.
                std::fill(host.host<float>(), host.host<float>() + host.elementSize(), 0.f);
            }
            t->copyFromHostTensor(&host);
        }
        // text_embeds/time_ids — KHÔNG cần set ở đây: base class
        // PipelineSdxlCpu::runUnetStep() (mục 59) đã tự ghi 2 input đó từ
        // cond.pooled/cond.time_ids TRƯỚC KHI gọi onBeforeUnetRun() (xem
        // thứ tự lệnh gọi trong PipelineSdxlCpu.hpp) — model augmented CHỈ
        // THÊM 2 input mới (control_hint/ip_image_embeds) so với base, 3
        // input gốc (sample/timestep/encoder_hidden_states) + 2 input SDXL
        // (text_embeds/time_ids) giữ NGUYÊN cơ chế base, không cần ghi đè.
    }

private:
    bool hasConditioning_ = false;
    bool hasMultiCharacter_ = false;  // mục 178 — mirror ip_adapter.cpp
    std::vector<float> ipEmbed_;
    std::vector<int> ipShape_;
    std::vector<uint8_t> controlHintRgb_;
    std::vector<uint8_t> depthHintRgb_;  // mục 181 — rỗng = không set (optional)
    int controlWidth_ = 1024;
    int controlHeight_ = 1024;
    std::vector<std::vector<float>> multiEmbeds_;   // mục 178 — 1 phần tử/nhân vật
    std::vector<std::vector<uint8_t>> multiMasks_;  // mục 178 — 1 phần tử/nhân vật
};

// ─────────────────────────────────────────────────────────────────────────
// 3. JNI
// ─────────────────────────────────────────────────────────────────────────
static std::string j2s_ipx(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

struct SdAugmentedSdxlHandle {
    std::unique_ptr<TextEncoder> textEncoder;
    std::unique_ptr<PipelineSdxlCpuAugmented> pipeline;
    std::unique_ptr<IpImageEncoderSdxl> ipEncoder;
    // mục 60/61 TECHNICAL_STATUS.md — nối ĐÚNG NGAY TỪ ĐẦU (không lặp lại
    // bug "hardcode use_opencl=false" mà mục 61 từng phải vá cho SD1.5) —
    // SDXL (~2.6B tham số) cần GPU/NPU nhiều hơn hẳn SD1.5 để có cơ hội
    // chạy được ở tốc độ chấp nhận được, xem GIỚI HẠN THẬT đầu file.
    bool useOpenCL = false;
    bool useNpu = false;
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdInitAugmentedSdxl(JNIEnv* e, jobject,
    jstring jModelDir, jstring jClipL, jstring jClipG, jstring jUnetAugmented,
    jstring jVaeDec, jstring jVaeEnc, jstring jIpEncoderPath, jstring jTokenizer,
    jstring jEmbeddingsDir, jboolean jUseOpenCL, jboolean jUseNpu) {

    std::string dir = j2s_ipx(e, jModelDir);
    try {
        auto handle = std::make_unique<SdAugmentedSdxlHandle>();
        handle->useOpenCL = jUseOpenCL;
        handle->useNpu = jUseNpu;
        handle->textEncoder = std::make_unique<TextEncoder>(/*sdxl=*/true, /*anima=*/false);
        handle->textEncoder->loadTokenizer(j2s_ipx(e, jTokenizer));
        handle->textEncoder->loadEmbeddingTables(dir);
        std::string embeddingsDir = j2s_ipx(e, jEmbeddingsDir);
        if (!embeddingsDir.empty()) handle->textEncoder->loadTextualInversions(embeddingsDir);

        handle->pipeline = std::make_unique<PipelineSdxlCpuAugmented>(
            *handle->textEncoder, dir, j2s_ipx(e, jClipL), j2s_ipx(e, jClipG),
            j2s_ipx(e, jUnetAugmented), j2s_ipx(e, jVaeDec), j2s_ipx(e, jVaeEnc));
        if (!handle->pipeline->initialize()) { LOGE("PipelineSdxlCpuAugmented initialize() fail"); return 0; }

        handle->ipEncoder = std::make_unique<IpImageEncoderSdxl>(j2s_ipx(e, jIpEncoderPath));
        if (!handle->ipEncoder->ok()) { LOGE("IpImageEncoderSdxl load fail"); return 0; }

        return reinterpret_cast<jlong>(handle.release());
    } catch (const std::exception& ex) {
        LOGE("sdInitAugmentedSdxl loi: %s", ex.what());
        return 0;
    }
}

// controlHintRgb: ĐÃ RENDER SẴN từ Kotlin (NativeBridge.renderSkeletonCanvas(),
// có sẵn từ mục 69) — KHÁC sdTxt2ImgWithReferenceAndPose (SD1.5, nhận
// skeleton THÔ rồi tự vẽ qua pose_templates trong CÙNG file) vì file này
// KHÔNG được include chéo pose_templates (xem comment đầu file).
// depthHintRgb: TUỲ CHỌN, MỚI (mục 181 TECHNICAL_STATUS.md, Phase 2f) —
// render qua NativeBridge.renderDepthHintCanvas() (có sẵn từ mục 69, cùng
// cặp với renderSkeletonCanvas()) — truyền mảng RỖNG (size 0) nếu panel
// không cần depth (vd chỉ 1 người, không ai chồng lấn).
extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgWithReferenceAndPoseSdxl(JNIEnv* e, jobject,
    jlong ptr, jstring jPrompt, jstring jNeg, jstring jRefImage,
    jbyteArray jControlHintRgb, jbyteArray jDepthHintRgb, jint controlSize, jint w, jint h, jint steps, jfloat cfg,
    jlong seed, jstring jOut, jobject cb) {

    auto* handle = reinterpret_cast<SdAugmentedSdxlHandle*>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgWithReferenceAndPoseSdxl: chua init"); return JNI_FALSE; }

    std::vector<float> ipEmbed; std::vector<int> ipShape;
    if (!handle->ipEncoder->encode(j2s_ipx(e, jRefImage), ipEmbed, ipShape)) {
        LOGE("Encode anh tham chieu that bai");
        return JNI_FALSE;
    }

    std::vector<uint8_t> controlHint;
    if (jControlHintRgb) {
        jsize len = e->GetArrayLength(jControlHintRgb);
        controlHint.resize(len);
        e->GetByteArrayRegion(jControlHintRgb, 0, len, reinterpret_cast<jbyte*>(controlHint.data()));
    }
    size_t expectedLen = (size_t)controlSize * controlSize * 3;
    if (controlHint.size() != expectedLen) {
        LOGE("controlHintRgb sai kich thuoc (nhan %zu, can %zu) - dung canvas den thay the",
             controlHint.size(), expectedLen);
        controlHint.assign(expectedLen, 0);
    }

    // depthHintRgb — TUỲ CHỌN thật: mảng null/rỗng là hợp lệ (nghĩa là
    // "không có depth hint", KHÔNG phải lỗi) — chỉ validate kích thước nếu
    // caller THẬT SỰ truyền dữ liệu.
    std::vector<uint8_t> depthHint;
    if (jDepthHintRgb) {
        jsize len = e->GetArrayLength(jDepthHintRgb);
        if (len > 0) {
            depthHint.resize(len);
            e->GetByteArrayRegion(jDepthHintRgb, 0, len, reinterpret_cast<jbyte*>(depthHint.data()));
            if (depthHint.size() != expectedLen) {
                LOGE("depthHintRgb sai kich thuoc (nhan %zu, can %zu) - bo qua depth cho panel nay",
                     depthHint.size(), expectedLen);
                depthHint.clear();
            }
        }
    }

    handle->pipeline->setConditioning(ipEmbed, ipShape, controlHint, (int)controlSize, (int)controlSize, depthHint);

    GenerationRequest req;
    req.prompt = j2s_ipx(e, jPrompt);
    req.negative_prompt = j2s_ipx(e, jNeg);
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = handle->useOpenCL; req.use_npu = handle->useNpu; req.img2img = false;

    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    ProgressCallback progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_ipx(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char*>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
    } catch (const std::exception& ex) {
        LOGE("generate() (augmented SDXL) loi: %s", ex.what());
    }
    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

// mục 178 TECHNICAL_STATUS.md (SDXL Phase 2c) — Mask N-nhân-vật. Mirror
// ĐÚNG sdTxt2ImgWithCharactersAndPose (SD1.5) NHƯNG nhận controlHintRgb
// ĐÃ RENDER SẴN (không tự vẽ, xem comment đầu file) — characterMasks là
// mảng PHẲNG N khối width*height byte liên tiếp, ĐÚNG thứ tự
// referenceImagePaths (cùng invariant mục 172/178: khối i <-> ảnh i <->
// nhân vật i). KHÔNG có tham số decay (khác SD1.5 — xem "PHẠM VI" đầu
// tools/export_ipa_controlnet_mask_unet_sdxl.py).
extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgWithCharactersAndPoseSdxl(JNIEnv* e, jobject,
    jlong ptr, jstring jPrompt, jstring jNeg, jobjectArray jRefImagePaths,
    jbyteArray jCharacterMasks, jbyteArray jControlHintRgb, jint controlSize,
    jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut, jobject cb) {

    auto* handle = reinterpret_cast<SdAugmentedSdxlHandle*>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgWithCharactersAndPoseSdxl: chua init"); return JNI_FALSE; }

    jsize numChars = e->GetArrayLength(jRefImagePaths);
    std::vector<std::vector<float>> ipEmbeds;
    std::vector<int> ipShape;
    for (jsize i = 0; i < numChars; i++) {
        auto jPath = (jstring)e->GetObjectArrayElement(jRefImagePaths, i);
        std::vector<float> embed; std::vector<int> shape;
        if (!handle->ipEncoder->encode(j2s_ipx(e, jPath), embed, shape)) {
            LOGE("Encode anh tham chieu nhan vat %d that bai", (int)i);
            e->DeleteLocalRef(jPath);
            return JNI_FALSE;
        }
        ipEmbeds.push_back(embed);
        if (i == 0) ipShape = shape;
        e->DeleteLocalRef(jPath);
    }

    std::vector<uint8_t> controlHint;
    if (jControlHintRgb) {
        jsize len = e->GetArrayLength(jControlHintRgb);
        controlHint.resize(len);
        e->GetByteArrayRegion(jControlHintRgb, 0, len, reinterpret_cast<jbyte*>(controlHint.data()));
    }
    size_t expectedControlLen = (size_t)controlSize * controlSize * 3;
    if (controlHint.size() != expectedControlLen) {
        LOGE("controlHintRgb sai kich thuoc (nhan %zu, can %zu) - dung canvas den thay the",
             controlHint.size(), expectedControlLen);
        controlHint.assign(expectedControlLen, 0);
    }

    // characterMasks: PHẲNG, N khối controlSize*controlSize byte — tách lại
    // thành N vector riêng (mirror cách Kotlin/C++ SD1.5 xử lý, xem
    // ip_adapter.cpp renderCharacterMask() call site).
    std::vector<uint8_t> masksFlat;
    if (jCharacterMasks) {
        jsize len = e->GetArrayLength(jCharacterMasks);
        masksFlat.resize(len);
        e->GetByteArrayRegion(jCharacterMasks, 0, len, reinterpret_cast<jbyte*>(masksFlat.data()));
    }
    size_t plane = (size_t)controlSize * controlSize;
    std::vector<std::vector<uint8_t>> maskHints;
    for (jsize i = 0; i < numChars; i++) {
        size_t off = (size_t)i * plane;
        if (off + plane <= masksFlat.size()) {
            maskHints.emplace_back(masksFlat.begin() + off, masksFlat.begin() + off + plane);
        } else {
            LOGE("characterMasks thieu du lieu cho nhan vat %d - dung mask trang (khong claim vung nao)", (int)i);
            maskHints.emplace_back(plane, 0);
        }
    }

    handle->pipeline->setConditioningMultiCharacter(ipEmbeds, ipShape, controlHint,
                                                      (int)controlSize, (int)controlSize, maskHints);

    GenerationRequest req;
    req.prompt = j2s_ipx(e, jPrompt);
    req.negative_prompt = j2s_ipx(e, jNeg);
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = handle->useOpenCL; req.use_npu = handle->useNpu; req.img2img = false;

    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    ProgressCallback progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_ipx(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char*>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
    } catch (const std::exception& ex) {
        LOGE("generate() (mask N-nhan-vat SDXL) loi: %s", ex.what());
    }
    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdFreeAugmentedSdxl(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<SdAugmentedSdxlHandle*>(ptr);
}
