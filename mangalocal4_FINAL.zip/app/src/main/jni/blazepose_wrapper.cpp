// BlazePose GHUM 3D (MediaPipe Pose Landmark, lite/full) — toạ độ 3D THẬT của khớp từ MỘT người đã cắt (mục 280 TECHNICAL_STATUS.md).
// Thay cho "đoán độ sâu từ độ co ngắn" của Pose3D (mục 279, nhạy nhiễu, mập mờ dấu ra-trước/ra-sau).
//
// Bám SÁT khuôn midas_depth_wrapper.cpp / yolo_pose_wrapper.cpp: cùng MNN::Interpreter / Session / Tensor, cùng JNI. KHÁC: (1) CPU-only (tập op của model chưa kiểm trên OpenCL;
// BlazePose lite ~30–60 ms trên CPU là đủ), (2) đầu vào NHWC (model tflite → MNN giữ nguyên layout TensorFlow), (3) KHÔNG đọc ảnh/resize ở đây: Kotlin đã cắt+xoay ROI và đưa vào
// đúng 256*256*3 float RGB 0..1 (HWC) — việc cắt ROI nằm ở BlazePoseLift.kt (thuần Kotlin, kiểm bằng kotlinc).
//
// Model (tools/export_blazepose.py hoặc workflow export_blazepose.yml; nguồn mediapipe v0.8.10 pose_landmark_{lite,full}.tflite, Apache-2.0): blazepose_full.mnn nếu có, không thì
// blazepose_lite.mnn, trong thư mục truyền vào blazePoseInit (StoryManager.yoloDir). ĐÃ KIỂM bằng Python MNN 3.6.2: input_1 [1,256,256,3] float32; output (tên sau chuyển đổi giữ nguyên)
// Identity [1,195] = 39 điểm × (x_px, y_px, z, độ-thấy-logit, độ-hiện-diện-logit) theo pixel của ảnh 256; Identity_1 [1,1] = xác suất có người; Identity_4 [1,117] = 39 điểm "world"
// × (x, y, z) theo MÉT, gốc = giữa hai hông, y hướng XUỐNG, z ÂM = gần camera; Identity_2 (mặt nạ) và Identity_3 (bản đồ nhiệt) bỏ qua. Không đoán tên tensor: chọn output theo SỐ PHẦN TỬ
// (195 / 117 / 1); thiếu cái nào thì trả mảng RỖNG + log (fail rõ ràng thay vì đọc sai âm thầm).
//
// Trả về float[313] = [cờ có người (1)] + [39*5 điểm ảnh] + [39*3 điểm world]. Mảng rỗng nếu lỗi.
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <cstring>
#include <memory>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

#define TAG "BlazePose_MNN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {
constexpr int kSize = 256;
constexpr int kInputFloats = kSize * kSize * 3;
constexpr int kLandmarkFloats = 39 * 5;   // 195
constexpr int kWorldFloats = 39 * 3;      // 117
constexpr int kResultFloats = 1 + kLandmarkFloats + kWorldFloats;  // 313

bool fileExists(const std::string& p) {
    FILE* f = std::fopen(p.c_str(), "rb");
    if (!f) return false;
    std::fclose(f);
    return true;
}
}  // namespace

struct BlazePoseWrapper {
    std::shared_ptr<MNN::Interpreter> net;
    MNN::Session* session = nullptr;
    bool ok = false;

    explicit BlazePoseWrapper(const std::string& modelDir) {
        std::string modelPath = modelDir + "/blazepose_full.mnn";
        if (!fileExists(modelPath)) modelPath = modelDir + "/blazepose_lite.mnn";
        if (!fileExists(modelPath)) { LOGE("khong thay blazepose_full.mnn / blazepose_lite.mnn trong %s", modelDir.c_str()); return; }
        net.reset(MNN::Interpreter::createFromFile(modelPath.c_str()));
        if (!net) { LOGE("khong doc duoc model: %s", modelPath.c_str()); return; }

        MNN::ScheduleConfig config;
        config.type = MNN_FORWARD_CPU;
        config.numThread = 4;
        MNN::BackendConfig backendConfig;
        backendConfig.precision = MNN::BackendConfig::Precision_Normal;  // không dùng Low: toạ độ khớp cần đủ chính xác
        config.backendConfig = &backendConfig;
        session = net->createSession(config);
        if (!session) { LOGE("createSession CPU fail"); return; }

        auto inputs = net->getSessionInputAll(session);
        if (inputs.empty()) { LOGE("model khong co input tensor"); return; }
        MNN::Tensor* input = inputs.begin()->second;
        if (input->elementSize() != kInputFloats) {
            LOGE("input co %d phan tu, ky vong %d — co dung BlazePose pose_landmark 256x256 khong?", input->elementSize(), kInputFloats);
            return;
        }
        LOGI("da nap %s", modelPath.c_str());
        ok = true;
    }

    // rgb: kSize*kSize*3 float, hàng-trước-cột-sau, RGB, 0..1. Trả kResultFloats float, hoặc rỗng nếu lỗi.
    std::vector<float> run(const float* rgb, int count) {
        std::vector<float> result;
        if (count != kInputFloats) { LOGE("dau vao co %d float, ky vong %d", count, kInputFloats); return result; }
        auto inputs = net->getSessionInputAll(session);
        if (inputs.empty()) return result;
        MNN::Tensor* input = inputs.begin()->second;

        // layout host = layout của input (model tflite → TENSORFLOW = NHWC); dữ liệu Kotlin đưa vào là HWC nên khớp.
        MNN::Tensor hostIn(input, input->getDimensionType());
        if (hostIn.elementSize() != kInputFloats) { LOGE("host input co %d phan tu", hostIn.elementSize()); return result; }
        std::memcpy(hostIn.host<float>(), rgb, (size_t)kInputFloats * sizeof(float));
        input->copyFromHostTensor(&hostIn);

        if (net->runSession(session) != MNN::NO_ERROR) { LOGE("runSession loi"); return result; }

        const float* flag = nullptr; const float* lm = nullptr; const float* world = nullptr;
        std::vector<std::unique_ptr<MNN::Tensor>> keep;   // giữ host tensor sống tới khi copy xong
        auto outputs = net->getSessionOutputAll(session);
        for (auto& kv : outputs) {
            MNN::Tensor* out = kv.second;
            int n = out->elementSize();
            if (n != 1 && n != kLandmarkFloats && n != kWorldFloats) continue;   // bỏ mặt nạ 65536 và bản đồ nhiệt 159744
            std::unique_ptr<MNN::Tensor> host(new MNN::Tensor(out, out->getDimensionType()));
            out->copyToHostTensor(host.get());
            const float* p = host->host<float>();
            if (n == 1) flag = p; else if (n == kLandmarkFloats) lm = p; else world = p;
            keep.push_back(std::move(host));
        }
        if (!flag || !lm || !world) {
            LOGE("thieu output (flag=%d landmarks=%d world=%d) — model .mnn co dung BlazePose khong?", flag != nullptr, lm != nullptr, world != nullptr);
            return result;
        }
        result.resize(kResultFloats);
        result[0] = flag[0];
        std::memcpy(result.data() + 1, lm, (size_t)kLandmarkFloats * sizeof(float));
        std::memcpy(result.data() + 1 + kLandmarkFloats, world, (size_t)kWorldFloats * sizeof(float));
        return result;
    }

    ~BlazePoseWrapper() {
        if (session && net) net->releaseSession(session);
    }
};

static std::string j2s_bp(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_blazePoseInit(JNIEnv* e, jobject, jstring jDir) {
    auto* w = new BlazePoseWrapper(j2s_bp(e, jDir));
    if (!w->ok) { delete w; return 0; }
    return reinterpret_cast<jlong>(w);
}

// Vào: 256*256*3 float RGB 0..1 (HWC). Ra: 313 float [cờ, 39*5 điểm ảnh, 39*3 điểm world] hoặc mảng RỖNG nếu lỗi (Kotlin phải kiểm size == 0).
extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_mangalocal_pipeline_NativeBridge_blazePoseRun(JNIEnv* e, jobject, jlong ptr, jfloatArray jRgb) {
    if (!ptr || !jRgb) return e->NewFloatArray(0);
    auto* w = reinterpret_cast<BlazePoseWrapper*>(ptr);
    jsize n = e->GetArrayLength(jRgb);
    std::vector<float> in((size_t)n);
    if (n > 0) e->GetFloatArrayRegion(jRgb, 0, n, in.data());
    auto out = w->run(in.data(), (int)n);
    jfloatArray result = e->NewFloatArray((jsize)out.size());
    if (!out.empty()) e->SetFloatArrayRegion(result, 0, (jsize)out.size(), out.data());
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_blazePoseFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<BlazePoseWrapper*>(ptr);
}
