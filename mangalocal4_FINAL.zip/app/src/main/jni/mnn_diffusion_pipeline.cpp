// mnn_diffusion_pipeline.cpp — adapter JNI của MangaLocal.
//
// KHÔNG chứa logic nghiệp vụ sinh ảnh — toàn bộ thuật toán (scheduler,
// VAE tiling, CFG...) nằm trong sd_engine/Pipeline.hpp thật (port từ
// local-dream, xem NOTICE_local-dream.md). File này chỉ:
//   1. Đọc model_manifest.json để biết dùng Pipeline con nào + file nào.
//   2. Dựng TextEncoder + Pipeline con tương ứng.
//   3. Gọi Pipeline::generate() thật, ghi kết quả ra PNG.
//   4. Bắn callback tiến trình về Kotlin.
//
// GIAI ĐOẠN HIỆN TẠI: "sd15_cpu" hoạt động đầy đủ nhất (mục 1-58
// TECHNICAL_STATUS.md). "sdxl_cpu" MỚI THÊM ở mục 59 — CHẠY ĐƯỢC VỀ MẶT
// KIẾN TRÚC (không cần QNN SDK, comment cũ ở đây trước ghi "sdxl cần QNN
// SDK thật" — ĐÃ SỬA, không còn đúng: QNN chỉ cần thiết để CHẠY NHANH trên
// NPU, không phải điều kiện BẮT BUỘC để chạy được — CPU vẫn chạy được về
// nguyên tắc, chỉ CHẬM HƠN NHIỀU do UNet SDXL ~2.6B tham số so với ~860M
// của SD1.5, xem TECHNICAL_STATUS.md mục 59 cho chi tiết rủi ro hiệu năng
// CHƯA ĐO ĐƯỢC). "anima" vẫn CHƯA làm.

#include <jni.h>
#include <android/log.h>
#include <string>
#include <fstream>
#include <memory>
#include <stdexcept>
#include <cmath>
#include <algorithm>
#include <vector>

#include <nlohmann/json.hpp>

#include "sd_engine/Pipeline.hpp"
#include "sd_engine/PipelineSd15Cpu.hpp"
#include "sd_engine/PipelineSdxlCpu.hpp"
#include "sd_engine/TextEncoder.hpp"
#include "sd_engine/SDUtils.hpp"  // GenerationResult + stb write helpers dùng chung

#define TAG "MangaLocal_SDEngine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

// Bọc TextEncoder + Pipeline trong 1 handle để trả về jlong cho Kotlin.
struct SdHandle {
    std::unique_ptr<TextEncoder> textEncoder;
    std::unique_ptr<Pipeline> pipeline;
    bool useOpenCL = false;
    bool useNpu = false;  // mục 60 TECHNICAL_STATUS.md
    // mục 64 TECHNICAL_STATUS.md — true khi ResolvedModel::npu_required=true
    // VÀ đang dùng cascade NPU online (KHÔNG cần thiết khi usingNpuOffline,
    // vì bản thân việc nạp đúng file offline đã LÀ chạy NPU rồi, xem
    // sdInit()). Thread xuống GenerationRequest::require_npu ở mỗi lần gọi
    // txt2img/img2img để MnnUtils::createMnnSession() không âm thầm rớt
    // xuống OpenCL/CPU.
    bool requireNpu = false;
};

// Đọc model_manifest.json trong assets, tìm entry theo id. Ném exception
// có thông điệp RÕ tên field/model thiếu — không để lỗi im lặng, đúng yêu
// cầu đã thống nhất trước đó (kiểm tra tường minh khi model không khớp).
struct ResolvedModel {
    std::string pipeline_type;
    std::string dir;
    std::string tokenizer, clip, unet, vae_decoder, vae_encoder, pos_emb, token_emb;
    bool use_v_pred = false;
    // SDXL-only (mục 59 TECHNICAL_STATUS.md) — rỗng khi pipeline_type != "sdxl_cpu".
    std::string clip_g, pos_emb_2, token_emb_2;
    // mục 62 TECHNICAL_STATUS.md — file "unet" THAY THẾ khi dùng chế độ QNN
    // offline (sinh bởi công cụ MNN2QNNModel trên máy khác, xem CMakeLists.txt
    // MANGALOCAL_QNN_MODE) — RỖNG nếu manifest không khai báo (bình thường,
    // hầu hết model sẽ không có mục này cho tới khi ai đó tự convert +
    // đóng gói thủ công, giống cách local-dream phân phối model NPU).
    std::string unet_npu_offline;
    // mục 64 TECHNICAL_STATUS.md — "SD1.5 bắt buộc phải dùng NPU, SDXL vẫn
    // fallback GPU được". Đọc RIÊNG từng model entry (KHÔNG suy ra từ
    // pipeline_type) — cho phép dev tự quyết định model SD1.5 nào bắt
    // buộc NPU (ví dụ bản NPU-only tải riêng) và model SD1.5 nào vẫn
    // dùng cascade thường, giống đúng cách local-dream phân phối 2 gói
    // model tách biệt (QNN-only vs MNN thường) thay vì ép cả app.
    bool npu_required = false;
};

ResolvedModel resolveModel(const std::string& manifestPath, const std::string& baseModelDir,
                           const std::string& modelId, const std::string& socModel) {
    std::ifstream f(manifestPath);
    if (!f) throw std::runtime_error("Khong doc duoc model_manifest.json tai: " + manifestPath);

    nlohmann::json j;
    try {
        f >> j;
    } catch (const std::exception& e) {
        throw std::runtime_error(std::string("model_manifest.json bi loi cu phap JSON: ") + e.what());
    }

    if (!j.contains("models") || !j["models"].is_array())
        throw std::runtime_error("model_manifest.json thieu mang 'models'");

    for (auto& m : j["models"]) {
        if (m.value("id", "") != modelId) continue;

        ResolvedModel r;
        r.pipeline_type = m.value("pipeline", "");
        // mục 59 TECHNICAL_STATUS.md — thêm "sdxl_cpu" bên cạnh "sd15_cpu"
        // đã có. KHÔNG gộp chung 1 nhánh đọc file — 2 kiến trúc cần field
        // khác hẳn nhau (SDXL cần thêm clip_g/token_emb_2/pos_emb_2).
        if (r.pipeline_type != "sd15_cpu" && r.pipeline_type != "sdxl_cpu")
            throw std::runtime_error("Model '" + modelId + "' khai bao pipeline='" + r.pipeline_type +
                                      "' - GIAI DOAN NAY CHI HO TRO 'sd15_cpu' hoac 'sdxl_cpu' (xem TECHNICAL_STATUS.md muc 59)");

        r.dir = baseModelDir + "/" + m.value("dir", modelId);
        r.use_v_pred = m.value("use_v_pred", false);
        r.npu_required = m.value("npu_required", false);  // mục 64 TECHNICAL_STATUS.md

        if (!m.contains("files")) throw std::runtime_error("Model '" + modelId + "' thieu field 'files'");
        auto& files = m["files"];
        auto need = [&](const char* key) -> std::string {
            if (!files.contains(key))
                throw std::runtime_error("Model '" + modelId + "' thieu file khai bao: files." + std::string(key));
            return r.dir + "/" + files.value(key, "");
        };
        r.tokenizer   = need("tokenizer");
        r.pos_emb     = need("pos_emb");
        r.token_emb   = need("token_emb");
        if (r.pipeline_type == "sdxl_cpu") {
            // "clip" dùng chung TÊN FIELD với sd15_cpu nhưng Ở ĐÂY là CLIP-L
            // (encoder 1) — giữ tên "clip" (không đổi thành "clip_l") để
            // model_manifest.json ít field khác biệt nhất có thể giữa 2 loại
            // pipeline, dễ đọc/sửa tay hơn.
            r.clip        = need("clip");        // clip_l.mnn
            r.clip_g      = need("clip_g");      // clip_g.mnn — CHỈ SDXL
            r.token_emb_2 = need("token_emb_2"); // CHỈ SDXL
            r.pos_emb_2   = need("pos_emb_2");   // CHỈ SDXL
            r.unet        = need("unet");        // unet_sdxl.mnn (tên file tuỳ chọn trong manifest, không bắt buộc trùng tên)
        } else {
            r.clip        = need("clip");
            r.unet        = need("unet");
        }
        r.vae_decoder = need("vae_decoder");
        // vae_encoder optional (không có -> không hỗ trợ img2img, vẫn chạy txt2img OK)
        if (files.contains("vae_encoder")) r.vae_encoder = r.dir + "/" + files.value("vae_encoder", "");
        // mục 62/63 TECHNICAL_STATUS.md — "npu_offline" TUỲ CHỌN, giờ là
        // MẢNG (mục 63 — trước đây 1 object cho đúng 1 chip, không đủ khi
        // nhiều dòng máy). Chọn phần tử có "soc_model" KHỚP ĐÚNG socModel
        // truyền vào (Kotlin đã tự dò qua RuntimeOptimizer.detectQnnSoc(),
        // xem sdInit() bên dưới) — không khớp máy nào -> unet_npu_offline
        // rỗng, tự động rớt về UNet CPU/OpenCL bình thường (an toàn).
        if (files.contains("npu_offline") && files["npu_offline"].is_array() && !socModel.empty()) {
            for (auto& variant : files["npu_offline"]) {
                if (variant.value("soc_model", "") == socModel && variant.contains("unet")) {
                    r.unet_npu_offline = r.dir + "/" + variant.value("unet", "");
                    break;
                }
            }
        }

        return r;
    }
    throw std::runtime_error("Khong tim thay model id='" + modelId + "' trong model_manifest.json");
}

// Kiểm tra file thật sự tồn tại trước khi đưa vào Pipeline — tránh crash
// mù ở tầng dưới (giống lỗ hổng đã nêu ở bản gốc getSessionInput không
// check null). Không thay được kiểm tra nội bộ của MNN, nhưng bắt được
// sớm nhất các lỗi "quên copy file" / "gõ sai tên file trong manifest".
void requireFileExists(const std::string& path, const char* label) {
    std::ifstream f(path);
    if (!f.good())
        throw std::runtime_error(std::string("Thieu file (") + label + "): " + path);
}

}  // namespace

static std::string j2s(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c);
    e->ReleaseStringUTFChars(js, c);
    return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdInit(JNIEnv* e, jobject,
    jstring jModelDir, jstring jModelId, jboolean jUseOpenCL, jstring jEmbeddingsDir,
    jboolean jUseNpu, jstring jSocModel) {

    std::string modelDir = j2s(e, jModelDir);
    std::string modelId  = j2s(e, jModelId);
    std::string manifestPath = modelDir + "/../model_manifest.json";
    // XÁC NHẬN: modelDir truyền vào đây = storyManager.modelsDir
    // ("MangaLocal/models"), manifestFile = "MangaLocal/model_manifest.json"
    // (xem StoryManager.kt) — 2 thư mục cùng cấp trong "MangaLocal/", nên
    // "../model_manifest.json" là đúng theo thiết kế, không còn là giả định
    // chưa kiểm chứng như trước. Nếu sau này đổi cấu trúc thư mục trong
    // StoryManager.kt, PHẢI sửa đồng bộ dòng này.

    try {
        std::string socModel = j2s(e, jSocModel);  // "" hợp lệ nếu không dò được (mục 63) — resolveModel() tự bỏ qua npu_offline khi rỗng
        ResolvedModel rm = resolveModel(manifestPath, modelDir, modelId, socModel);
        bool isSdxl = (rm.pipeline_type == "sdxl_cpu");

        // mục 62 TECHNICAL_STATUS.md — chế độ QNN OFFLINE: nếu user bật
        // useNpu VÀ manifest có khai báo "npu_offline.unet" cho model này,
        // DÙNG FILE ĐÓ THAY unet thường + TẮT cờ NPU-online (offline mode
        // KHÔNG dùng MNN_FORWARD_NN — nó dùng CPU backend thường, QNN được
        // gói kín trong Plugin op bên trong CHÍNH file .mnn thay thế đó, xem
        // giải thích đầy đủ trong CMakeLists.txt). effectiveUseNpu=false
        // truyền xuống Pipeline vì KHÔNG cần cascade thử MNN_FORWARD_NN nữa
        // — bản thân việc nạp ĐÚNG FILE offline này đã là "dùng NPU" rồi.
        bool usingNpuOffline = jUseNpu && !rm.unet_npu_offline.empty();
        std::string unetPath = usingNpuOffline ? rm.unet_npu_offline : rm.unet;
        bool effectiveUseNpu = jUseNpu && !usingNpuOffline;  // NPU online cascade CHỈ khi KHÔNG có bản offline khả dụng
        if (usingNpuOffline) {
            LOGI("Dung UNet NPU OFFLINE: %s (CHUA XAC NHAN file nay khop dung SOC/HEXAGON_ARCH may that - nguoi dung/dev tu dam bao, xem TECHNICAL_STATUS.md muc 62)", unetPath.c_str());
        }

        // mục 64 TECHNICAL_STATUS.md — "SD1.5 bắt buộc phải dùng NPU".
        // Chặn NGAY tại đây (trước khi tốn thời gian nạp tokenizer/CLIP)
        // nếu model yêu cầu NPU bắt buộc mà máy/người dùng không thoả:
        //   - usingNpuOffline=true  -> ĐÃ thoả (chạy NPU qua file offline).
        //   - jUseNpu=true (và không có offline) -> thoả ĐIỀU KIỆN BẬT, còn
        //     có tạo session NPU thành công lúc generate() hay không do
        //     require_npu=true ở dưới quyết định (không rớt xuống GPU/CPU).
        //   - Còn lại (NPU switch đang TẮT) -> báo lỗi rõ ràng ngay, không
        //     để app chạy im lặng bằng CPU/GPU rồi người dùng tưởng nhầm.
        if (rm.npu_required && !usingNpuOffline && !jUseNpu) {
            throw std::runtime_error(
                "Model '" + modelId + "' bat buoc phai dung NPU (npu_required=true trong "
                "model_manifest.json) nhung cong tac NPU dang TAT va khong co ban offline "
                "khop chip may nay. Bat cong tac 'NPU (Qualcomm QNN)' trong Cai dat, hoac "
                "chon model SD1.5 khac khong yeu cau NPU bat buoc.");
        }

        requireFileExists(rm.tokenizer, "tokenizer");
        requireFileExists(rm.clip, isSdxl ? "clip_l" : "clip");
        requireFileExists(unetPath, usingNpuOffline ? "npu_offline.unet" : "unet");
        requireFileExists(rm.vae_decoder, "vae_decoder");
        requireFileExists(rm.pos_emb, "pos_emb");
        requireFileExists(rm.token_emb, "token_emb");
        if (!rm.vae_encoder.empty()) requireFileExists(rm.vae_encoder, "vae_encoder");
        if (isSdxl) {
            requireFileExists(rm.clip_g, "clip_g");
            requireFileExists(rm.pos_emb_2, "pos_emb_2");
            requireFileExists(rm.token_emb_2, "token_emb_2");
        }

        auto handle = std::make_unique<SdHandle>();
        handle->useOpenCL = jUseOpenCL;
        handle->useNpu = effectiveUseNpu;  // mục 60/62 TECHNICAL_STATUS.md
        // mục 64 TECHNICAL_STATUS.md — chỉ cần require_npu=true cho nhánh
        // cascade ONLINE; usingNpuOffline đã tự đảm bảo chạy NPU bằng cách
        // nạp đúng file khác, không cần ép thêm gì ở tầng createMnnSession.
        handle->requireNpu = rm.npu_required && !usingNpuOffline;

        handle->textEncoder = std::make_unique<TextEncoder>(/*sdxl=*/isSdxl, /*anima=*/false);
        handle->textEncoder->loadTokenizer(rm.tokenizer);
        handle->textEncoder->loadEmbeddingTables(rm.dir);
        // Textual Inversion (mục 12 TECHNICAL_STATUS.md — phương pháp thứ 3
        // ngoài LoRA/IP-Adapter). Thư mục rỗng/không tồn tại -> loadEmbeddings
        // return sớm, không lỗi (đã đọc PromptProcessor::loadEmbeddings ở trên).
        std::string embeddingsDir = j2s(e, jEmbeddingsDir);
        if (!embeddingsDir.empty()) handle->textEncoder->loadTextualInversions(embeddingsDir);

        if (isSdxl) {
            auto sdxl = std::make_unique<PipelineSdxlCpu>(
                *handle->textEncoder, rm.dir, rm.clip, rm.clip_g,
                unetPath, rm.vae_decoder, rm.vae_encoder);  // unetPath (khong phai rm.unet) - xem nhanh npu_offline muc 62
            if (!sdxl->initialize()) {
                LOGE("PipelineSdxlCpu initialize() that bai cho model '%s'", modelId.c_str());
                return 0;
            }
            handle->pipeline = std::move(sdxl);
        } else {
            auto sd15 = std::make_unique<PipelineSd15Cpu>(
                *handle->textEncoder, rm.dir, rm.clip, unetPath,
                rm.vae_decoder, rm.vae_encoder, rm.use_v_pred);  // unetPath (khong phai rm.unet) - xem nhanh npu_offline muc 62
            if (!sd15->initialize()) {
                LOGE("Pipeline initialize() that bai cho model '%s'", modelId.c_str());
                return 0;
            }
            handle->pipeline = std::move(sd15);
        }

        LOGI("SD init OK: model=%s pipeline=%s dir=%s opencl=%d", modelId.c_str(),
             rm.pipeline_type.c_str(), rm.dir.c_str(), (int)jUseOpenCL);
        return reinterpret_cast<jlong>(handle.release());

    } catch (const std::exception& ex) {
        LOGE("sdInit that bai: %s", ex.what());
        return 0;
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2Img(JNIEnv* e, jobject,
    jlong ptr, jstring jPrompt, jstring jNeg, jint w, jint h, jint steps,
    jfloat cfg, jlong seed, jstring jOut, jobject cb) {

    auto* handle = reinterpret_cast<SdHandle*>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2Img goi khi chua init"); return JNI_FALSE; }

    GenerationRequest req;
    req.prompt = j2s(e, jPrompt);
    req.negative_prompt = j2s(e, jNeg);
    req.width = w; req.height = h;
    req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed;
    req.use_opencl = handle->useOpenCL;
    req.use_npu = handle->useNpu;  // mục 60 TECHNICAL_STATUS.md
    req.require_npu = handle->requireNpu;  // mục 64 TECHNICAL_STATUS.md
    req.img2img = false;

    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;

    ProgressCallback progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        // SDUtils.hpp thật chỉ có encodePNG() trả về bytes trong bộ nhớ
        // (không có hàm ghi thẳng ra file) — tự ghi file ở đây.
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char*>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
        LOGI("txt2img xong: %dx%d trong %dms (buoc dau %dms)",
             result.width, result.height, result.generation_time_ms, result.first_step_time_ms);
    } catch (const std::exception& ex) {
        LOGE("generate() loi: %s", ex.what());
    }

    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<SdHandle*>(ptr);
}

// ── img2img / inpaint / Ultrafix (upscale-vẽ-lại) THẬT ─────────────────────
// Pipeline.hpp (port từ local-dream) đã có SẴN toàn bộ logic này
// (GenerationRequest.img2img/has_mask/ultrafix) — file này TRƯỚC ĐÂY hardcode
// req.img2img=false, KHÔNG dùng gì cả. Đây là lần đầu nối dây thật (mục 16
// TECHNICAL_STATUS.md).
//
// Contract của GenerationRequest (đọc comment gốc Pipeline.hpp dòng ~38-43):
//   img_data:       [1,3,H,W] float, -1..1
//   mask_data:      [1,4,H/8,W/8] float, 0..1 (mask KHÔNG GIAN LATENT)
//   mask_data_full: [1,3,H,W] float, 0..1 (mask không gian pixel)
// Cả 2 mask đều PHẢI tự tính, pipeline KHÔNG tự suy ra cái này từ cái kia
// (đã đọc kỹ chỗ validate ở Pipeline.hpp dòng ~869 để xác nhận).
//
// CỐ Ý tự viết resize bilinear bằng tay thay vì dùng stb_image_resize2 (dù
// build.yml có tải về) — CHƯA tự kiểm chứng chữ ký hàm thật của thư viện đó
// (không có mạng để tra lúc viết file này), nên né rủi ro đoán sai API,
// giống đúng cách yolo_wrapper.cpp đã né MNN::CV::ImageProcess trước đây.

// mục 157 TECHNICAL_STATUS.md — BUG THẬT tìm được qua build CI (Build APK
// #91, lỗi LINKER "undefined symbol: resizeToCHWFloat"/"resizeMaskBoth").
// 2 hàm này TRƯỚC ĐÂY nằm trong `namespace { ... }` (vô danh) — có TÁC
// DỤNG Y HỆT `static` (internal linkage, chỉ dùng được TRONG CHÍNH file
// này) — mâu thuẫn trực tiếp với comment ở `ip_adapter.cpp` khai báo
// `extern` 2 hàm này với lời giải thích "external linkage (không có
// `static`)" — ĐÚNG là không có `static`, nhưng namespace vô danh cho
// hiệu ứng linkage GIỐNG HỆT — 1 cạm bẫy C++ kinh điển mà đọc code tĩnh
// (kể cả đọc kỹ) rất dễ bỏ sót, CHỈ linker thật mới bắt được. Bug có từ
// trước (lúc `resizeToCHWFloat`/`resizeMaskBoth` lần đầu thêm), không
// phải do các mục gần đây gây ra — chỉ chưa từng lộ ra vì chưa build-test
// lần nào cho tới bây giờ. Đã bỏ hẳn `namespace { ... }` bao ngoài (chỉ
// bao đúng 2 hàm này, không còn gì khác trong đó) — trả về external
// linkage tự nhiên, đúng ý đồ gốc.

// Resize + normalize ảnh RGB uint8 (srcW x srcH) -> [1,3,dstH,dstW] float
// -1..1, channel-first, bilinear tự viết (arithmetic đơn giản, không phụ
// thuộc API ngoài chưa kiểm chứng).
std::vector<float> resizeToCHWFloat(const unsigned char* src, int srcW, int srcH,
                                     int srcChannels, int dstW, int dstH) {
    std::vector<float> out((size_t)3 * dstH * dstW);
    for (int y = 0; y < dstH; y++) {
        float srcYf = (y + 0.5f) * srcH / dstH - 0.5f;
        int y0 = (int)std::floor(srcYf); int y1 = y0 + 1;
        float fy = srcYf - y0;
        y0 = std::max(0, std::min(y0, srcH - 1));
        y1 = std::max(0, std::min(y1, srcH - 1));
        for (int x = 0; x < dstW; x++) {
            float srcXf = (x + 0.5f) * srcW / dstW - 0.5f;
            int x0 = (int)std::floor(srcXf); int x1 = x0 + 1;
            float fx = srcXf - x0;
            x0 = std::max(0, std::min(x0, srcW - 1));
            x1 = std::max(0, std::min(x1, srcW - 1));
            for (int c = 0; c < 3; c++) {
                int sc = (srcChannels >= 3) ? c : 0; // ảnh xám -> lặp lại 3 kênh
                float v00 = src[((size_t)y0*srcW + x0)*srcChannels + sc];
                float v01 = src[((size_t)y0*srcW + x1)*srcChannels + sc];
                float v10 = src[((size_t)y1*srcW + x0)*srcChannels + sc];
                float v11 = src[((size_t)y1*srcW + x1)*srcChannels + sc];
                float top = v00 + (v01 - v00) * fx;
                float bot = v10 + (v11 - v10) * fx;
                float val = (top + (bot - top) * fy) / 255.f; // 0..1
                out[(size_t)c*dstH*dstW + y*dstW + x] = val * 2.f - 1.f; // -1..1
            }
        }
    }
    return out;
}

// Resize + normalize ảnh mask (1 kênh xám, trắng=vẽ lại/đen=giữ nguyên) ->
// mask_data_full [1,3,H,W] 0..1 VÀ mask_data latent [1,4,H/8,W/8] 0..1
// (average-pool xuống 1/8, lặp lại 4 kênh — quy ước latent channels chuẩn).
void resizeMaskBoth(const unsigned char* src, int srcW, int srcH,
                     int dstW, int dstH,
                     std::vector<float>& maskFull, std::vector<float>& maskLatent) {
    maskFull.assign((size_t)3 * dstH * dstW, 0.f);
    std::vector<float> gray((size_t)dstH * dstW);
    for (int y = 0; y < dstH; y++) {
        int sy = std::min(srcH - 1, (int)((y + 0.5f) * srcH / dstH));
        for (int x = 0; x < dstW; x++) {
            int sx = std::min(srcW - 1, (int)((x + 0.5f) * srcW / dstW));
            float v = src[(size_t)sy*srcW + sx] / 255.f;
            gray[(size_t)y*dstW + x] = v;
            for (int c = 0; c < 3; c++) maskFull[(size_t)c*dstH*dstW + y*dstW + x] = v;
        }
    }
    int lw = dstW / 8, lh = dstH / 8;
    maskLatent.assign((size_t)4 * lh * lw, 0.f);
    for (int ly = 0; ly < lh; ly++) {
        for (int lx = 0; lx < lw; lx++) {
            // average-pool khối 8x8 tương ứng
            float sum = 0.f; int cnt = 0;
            for (int dy = 0; dy < 8; dy++) for (int dx = 0; dx < 8; dx++) {
                int py = ly*8+dy, px = lx*8+dx;
                if (py < dstH && px < dstW) { sum += gray[(size_t)py*dstW+px]; cnt++; }
            }
            float avg = cnt > 0 ? sum / cnt : 0.f;
            for (int c = 0; c < 4; c++) maskLatent[(size_t)c*lh*lw + ly*lw + lx] = avg;
        }
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdImg2Img(JNIEnv* e, jobject,
    jlong ptr, jstring jPrompt, jstring jNeg, jstring jInputImage, jstring jMaskImage,
    jfloat denoiseStrength, jint w, jint h, jint steps, jfloat cfg, jlong seed,
    jboolean jUltrafix, jint jUltrafixTile, jstring jOut, jobject cb) {

    auto* handle = reinterpret_cast<SdHandle*>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdImg2Img goi khi chua init"); return JNI_FALSE; }

    std::string inputPath = j2s(e, jInputImage);
    int srcW, srcH, srcC;
    unsigned char* srcPixels = stbi_load(inputPath.c_str(), &srcW, &srcH, &srcC, 3);
    if (!srcPixels) { LOGE("Khong doc duoc anh input img2img: %s", inputPath.c_str()); return JNI_FALSE; }

    GenerationRequest req;
    req.prompt = j2s(e, jPrompt);
    req.negative_prompt = j2s(e, jNeg);
    req.width = w; req.height = h;
    req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed;
    req.use_opencl = handle->useOpenCL;
    req.use_npu = handle->useNpu;  // mục 60 TECHNICAL_STATUS.md
    req.require_npu = handle->requireNpu;  // mục 64 TECHNICAL_STATUS.md
    req.img2img = true;
    req.denoise_strength = denoiseStrength;
    req.img_data = resizeToCHWFloat(srcPixels, srcW, srcH, srcC, w, h);
    stbi_image_free(srcPixels);

    std::string maskPath = j2s(e, jMaskImage);
    if (!maskPath.empty()) {
        int mw, mh, mc;
        unsigned char* maskPixels = stbi_load(maskPath.c_str(), &mw, &mh, &mc, 1); // ép về 1 kênh xám
        if (!maskPixels) {
            LOGE("Khong doc duoc mask: %s (bo qua, chay img2img khong mask)", maskPath.c_str());
        } else {
            resizeMaskBoth(maskPixels, mw, mh, w, h, req.mask_data_full, req.mask_data);
            stbi_image_free(maskPixels);
            req.has_mask = true;
            req.user_supplied_mask = true;
        }
    }

    req.ultrafix = jUltrafix;
    if (jUltrafixTile > 0) req.ultrafix_tile = jUltrafixTile;

    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    ProgressCallback progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char*>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
        LOGI("img2img xong: %dx%d trong %dms (ultrafix=%d, mask=%d)",
             result.width, result.height, result.generation_time_ms, (int)jUltrafix, (int)req.has_mask);
    } catch (const std::exception& ex) {
        LOGE("img2img generate() loi: %s", ex.what());
    }

    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

// sdTxt2ImgWithReference / sdSaveLatentEmbedding (tên cũ, thời còn là
// stub) ĐÃ THAY BẰNG sdInitAugmented/sdTxt2ImgWithReferenceAndPose/
// sdFreeAugmented THẬT trong ip_adapter.cpp — xem NativeBridge.kt.

// mục 142 TECHNICAL_STATUS.md — cặp JNI đọc/ghi g_generation_interrupted
// (khai báo trong sd_engine/Pipeline.hpp, dùng chung cho MỌI Pipeline
// subclass vì là biến toàn cục — 1 app chỉ chạy 1 lượt generate() tại 1
// thời điểm bất kỳ, xem generationMutex phía Kotlin MainViewModel.kt mục
// 71, nên KHÔNG cần phân biệt theo instance/context). KHÔNG thay thế cơ
// chế cancelSafely()/withTimeoutOrNull() đã có ở mục 84 — bổ trợ, xem giải
// thích đầy đủ tại khai báo g_generation_interrupted.
extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_signalInterruptNative(JNIEnv*, jobject) {
    g_generation_interrupted.store(true);
    LOGI("signalInterruptNative: da bat co ngat, cho step dang chay hien tai ket thuc");
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_clearInterruptNative(JNIEnv*, jobject) {
    g_generation_interrupted.store(false);
}

