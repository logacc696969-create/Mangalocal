// native_crash_handler.cpp — bắt crash Ở TẦNG NATIVE (SIGSEGV/SIGABRT/...).
//
// MangaLocalApplication.kt (phía Kotlin) chỉ bắt được exception Java/Kotlin
// (Thread.UncaughtExceptionHandler) — một crash THẬT SỰ trong code C++
// (con trỏ null, abort() từ MNN/abseil/sentencepiece, v.v.) là một TÍN HIỆU
// hệ điều hành (signal), không phải Java exception, nên handler Kotlin
// không bao giờ thấy được. File này cài sẵn signal handler ở tầng native để
// bắt đúng loại crash đó, ghi thông tin cơ bản ra file, rồi mới để hệ thống
// xử lý tiếp như bình thường (app vẫn "tiếp tục dừng" như cũ — chỉ thêm
// bước ghi log trước đó).
//
// LƯU Ý: bên trong 1 signal handler chỉ được gọi các hàm async-signal-safe
// (open/write/close/raise/sigaction...) — KHÔNG được malloc, KHÔNG được
// dùng std::string/std::cout, nên phần dưới cố tình viết bằng C thuần +
// buffer cấp phát sẵn. strsignal() không được đảm bảo an toàn 100% theo
// chuẩn POSIX nhưng thực tế dùng ổn định trên Bionic (libc Android) cho
// mục đích chẩn đoán tạm thời như thế này.
#include <jni.h>
#include <signal.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

namespace {

char g_crash_log_path[512] = {0};
struct sigaction g_old_handlers[64];

// mục 161 TECHNICAL_STATUS.md — "bậc 1" trong roadmap PDF-audit: nâng cấp
// crash handler CÓ SẴN (không thêm thư viện ngoài như Breakpad — build NDK
// của dự án đã fragile qua 4 vòng #88/#91/#94/#97, thêm 1 dependency native
// mới không phải việc "rẻ" như đánh giá ban đầu). Thêm 1 buffer ghi NGỮ
// CẢNH hiện tại (panel nào, hàm nào đang chạy) — Kotlin gọi setCrashContext()
// NGAY TRƯỚC mỗi lời gọi JNI sinh ảnh rủi ro cao (đúng những call site đã
// audit ở mục 149 — 33 external fun). Buffer này CHỈ được ghi (strncpy) từ
// luồng Kotlin gọi bình thường (không phải trong signal handler — an toàn
// dùng strncpy/JNI ở đó), signal handler chỉ ĐỌC lại char* thô (an toàn
// async-signal-safe, không malloc). Không có context nào set (rỗng) vẫn
// hoạt động y hệt hành vi cũ — tương thích ngược, không có call site nào
// bắt buộc phải sửa nếu chưa kịp nối.
char g_crash_context[256] = {0};

void CrashHandler(int signum, siginfo_t* info, void* /*ucontext*/) {
    if (g_crash_log_path[0] != '\0') {
        int fd = open(g_crash_log_path, O_WRONLY | O_CREAT | O_TRUNC, 0666);
        if (fd >= 0) {
            char buf[640];
            int len = snprintf(buf, sizeof(buf),
                "[NATIVE CRASH]\nsignal=%d (%s)\nfault_addr=%p\n"
                "context=%s\n\n"
                "(Ghi async-signal-safe nen khong co ten ham/stack trace chi "
                "tiet - chi du de phan biet loai loi: SIGSEGV=truy cap bo nho "
                "sai/con tro null, SIGABRT=do abort()/assert() trong thu vien "
                "C++ (MNN/abseil/sentencepiece/tokenizers...), "
                "SIGBUS/SIGILL/SIGFPE=khac. 'context' la chuoi Kotlin ghi "
                "gan nhat truoc crash qua setCrashContext() - neu rong nghia "
                "la crash xay ra ngoai vung da boc context, vd luc load "
                "model/dlopen.)\n",
                signum, strsignal(signum), info ? info->si_addr : nullptr,
                g_crash_context[0] != '\0' ? g_crash_context : "(rong/khong ro)");
            if (len > 0) write(fd, buf, (size_t)len);
            close(fd);
        }
    }
    // Khôi phục handler mặc định của hệ thống rồi tự raise lại — để
    // debuggerd/hệ thống vẫn xử lý crash tiếp như bình thường sau khi ta đã
    // kịp ghi log, không nuốt mất crash gốc.
    if (signum >= 0 && signum < 64) {
        sigaction(signum, &g_old_handlers[signum], nullptr);
    }
    raise(signum);
}

void InstallHandlers() {
    // Cấp 1 vùng stack RIÊNG cho signal handler (sigaltstack) — phòng
    // trường hợp crash là do TRÀN STACK (đệ quy sâu, buffer cấp phát trên
    // stack quá lớn trong MNN/tokenizer...): lúc đó stack của thread đang
    // chạy đã hết sạch, nếu handler chạy chung stack đó sẽ tự crash tiếp
    // ngay lập tức, không kịp ghi gì cả — đúng kiểu triệu chứng "chưa kịp
    // ghi 1 dòng log nào".
    static char alt_stack[SIGSTKSZ * 4];
    stack_t ss;
    ss.ss_sp = alt_stack;
    ss.ss_size = sizeof(alt_stack);
    ss.ss_flags = 0;
    sigaltstack(&ss, nullptr);

    int signals[] = {SIGSEGV, SIGABRT, SIGBUS, SIGILL, SIGFPE};
    for (int s : signals) {
        struct sigaction sa;
        memset(&sa, 0, sizeof(sa));
        sa.sa_sigaction = CrashHandler;
        sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
        sigaction(s, &sa, (s >= 0 && s < 64) ? &g_old_handlers[s] : nullptr);
    }
}

// Ưu tiên cao nhất còn cho phép với code người dùng (101) — đảm bảo handler
// này được cài đặt TRƯỚC các static initializer khác trong cùng thư viện
// .so (MNN/abseil/sentencepiece...), phòng trường hợp crash xảy ra ngay lúc
// dlopen() (System.loadLibrary phía Kotlin), tức TRƯỚC khi Kotlin kịp gọi
// bất kỳ hàm JNI nào để set đường dẫn file log — nếu vậy g_crash_log_path
// vẫn rỗng nên sẽ không ghi được gì, nhưng ít nhất handler cũng không làm
// hỏng thêm gì, và các crash XẢY RA SAU đó (khi đã set path) sẽ được ghi.
__attribute__((constructor(101)))
void EarlyInstallCrashHandler() {
    InstallHandlers();
}

}  // namespace

extern "C"
JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_setCrashLogPath(JNIEnv* env, jobject /*thiz*/, jstring path) {
    if (!path) return;
    const char* c = env->GetStringUTFChars(path, nullptr);
    if (c) {
        strncpy(g_crash_log_path, c, sizeof(g_crash_log_path) - 1);
        g_crash_log_path[sizeof(g_crash_log_path) - 1] = '\0';
        env->ReleaseStringUTFChars(path, c);
    }
}

// mục 161 TECHNICAL_STATUS.md — gọi hàm này NGAY TRƯỚC mỗi lời gọi JNI sinh
// ảnh rủi ro cao (Kotlin, ImagePipeline.kt) để nếu crash xảy ra TRONG lúc
// gọi đó, file log sẽ ghi lại đúng panel/hàm nào đang chạy. An toàn gọi từ
// luồng Kotlin bình thường (KHÔNG phải trong signal handler) nên
// GetStringUTFChars/strncpy ở đây không vi phạm ràng buộc async-signal-safe
// (khác hẳn CrashHandler() phía trên — hàm đó chỉ ĐỌC g_crash_context thô).
extern "C"
JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_setCrashContext(JNIEnv* env, jobject /*thiz*/, jstring context) {
    if (!context) { g_crash_context[0] = '\0'; return; }
    const char* c = env->GetStringUTFChars(context, nullptr);
    if (c) {
        strncpy(g_crash_context, c, sizeof(g_crash_context) - 1);
        g_crash_context[sizeof(g_crash_context) - 1] = '\0';
        env->ReleaseStringUTFChars(context, c);
    }
}
