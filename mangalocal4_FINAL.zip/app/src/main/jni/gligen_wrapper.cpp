// gligen_wrapper.cpp — GLIGEN (Grounded Language-to-Image Generation,
// Li et al., CVPR 2023) — chạy model UNet đã export bởi
// tools/export_gligen_unet.py (mục 223 TECHNICAL_STATUS.md), trả lời câu
// hỏi user (mục 222): "cây phải cao hơn người" — ép tỷ lệ bằng bounding
// box hình học thay vì hy vọng SD1.5 tự hiểu chữ.
//
// mục 224/225 TECHNICAL_STATUS.md — user chỉ ra ĐÚNG 2 lần liên tiếp:
// (1) không cần tải cả checkpoint mới viết được — kiến trúc CHUNG đã tra
// cứu qua source/config thật (mục 224); (2) không nên "chờ có file .onnx
// thật" mới viết native — CONTRACT (tên/shape tensor) do CHÍNH
// export_gligen_unet.py tự định nghĩa, không phải thứ cần "khám phá" từ
// 1 file lạ. File này viết dựa ĐÚNG trên contract đó, mirror CHÍNH XÁC
// mẫu hình PipelineSd15CpuAugmented (ip_adapter.cpp, mục 51/52) — kế thừa
// PipelineSd15Cpu có sẵn (KHÔNG viết lại vòng lặp khử nhiễu/VAE), CHỈ
// override onBeforeUnetRun() để nạp thêm 3 input "gligen_*".
//
// GIỚI HẠN THẬT (đọc trước khi tin đây "chắc chắn chạy đúng"):
// 1. CHƯA build-test bằng thực thi thật — giống MỌI file .cpp khác viết
//    trong dự án này TRƯỚC KHI CI build lần đầu (không phải ngoại lệ,
//    cũng không phải yếu hơn — mirror ĐÚNG mức độ tin cậy mà
//    ip_adapter.cpp/triple_combo.cpp CŨNG từng có ở thời điểm mới viết).
// 2. "positive_embeddings" cho mỗi nhãn = embedding TẠI VỊ TRÍ TOKEN EOS
//    (49407) của chuỗi 77-token — ĐÂY LÀ SUY LUẬN dựa trên quy ước
//    "pooled output" CHUẨN của CLIP (lấy hidden state tại vị trí EOS,
//    dùng phổ biến trong HuggingFace `CLIPTextModel` cho `pooler_output`)
//    — CHƯA tự đọc được source thật của riêng preprocessing GLIGEN gốc để
//    xác nhận 100% đúng quy ước NÀY (khác mức tin cậy "verbatim source"
//    đã có cho chính `PositionNet.forward()`, xem export_gligen_unet.py).
//    Nếu ảnh ra sai/lem khi test thật, nghi ngờ ĐẦU TIÊN nên là chỗ này.
// 3. max_objs/positive_len đọc ĐỘNG từ shape tensor thật của model đã nạp
//    (KHÔNG hardcode 30/768) — đúng điều user chỉ ra ở mục 224: đổi sang
//    checkpoint GLIGEN khác (miễn cùng kiến trúc `attention_type="gated"`)
//    KHÔNG cần sửa file này.
// 4. CHƯA quyết định cách phối hợp với IP-Adapter/mask N-nhân-vật khi 1
//    panel vừa có nhân vật vừa có vật thể nền (mục 223 "VIỆC CÒN LẠI" #2)
//    — pipeline NÀY hiện ĐỘC LẬP, không tự kết hợp identity nhân vật.
//    MangaPipeline.kt (Kotlin, CHƯA nối — xem VIỆC CÒN LẠI) sẽ là nơi
//    quyết định KHI NÀO dùng pipeline này thay vì Mc/base.

#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <array>
#include <cstring>
#include <algorithm>
#include <fstream>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

#include <memory>

#include "sd_engine/Config.hpp"
#include "sd_engine/MnnUtils.hpp"
#include "sd_engine/PipelineSd15Cpu.hpp"
#include "sd_engine/TextEncoder.hpp"

// mục 226 — khai báo stb y hệt triple_combo.cpp (implementation nằm ở
// stb_impl.cpp, đã đăng ký CMake từ trước) để encode ảnh nhân vật.
extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
}
#include "sd_engine/stb_image_resize2.h"

#define TAG "MangaLocal_Gligen"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::string j2s_gligen(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

// mục 226 TECHNICAL_STATUS.md — COPY NGUYÊN VĂN TcIpImageEncoder
// (triple_combo.cpp, chính nó copy nguyên văn IpImageEncoder của
// ip_adapter.cpp — đã dùng thật ở đường mask N-nhân-vật), chỉ đổi tên lớp
// theo quy ước "không #include chéo giữa các file .cpp pipeline". Chuẩn
// hoá CLIP ViT xấp xỉ OpenAI, resize 224x224 — xem ip_adapter.cpp cho
// giải thích chi tiết. DÙNG CHUNG file ip_image_encoder.mnn với các
// pipeline IP-Adapter khác (cùng checkpoint IP-Adapter -> cùng encoder).
class GlIpImageEncoder {
public:
    explicit GlIpImageEncoder(const std::string& modelPath) {
        net_.reset(MNN::Interpreter::createFromFile(modelPath.c_str()));
        if (!net_) { LOGE("GlIpImageEncoder: khong doc duoc %s", modelPath.c_str()); return; }
        MNN::ScheduleConfig cfg; cfg.type = MNN_FORWARD_CPU; cfg.numThread = 4;
        session_ = net_->createSession(cfg);
        ok_ = session_ != nullptr;
    }
    bool ok() const { return ok_; }

    bool encode(const std::string& imagePath, std::vector<float>& outEmbed, std::vector<int>& outShape) {
        if (!ok_) return false;
        int w, h, c;
        unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("GlIpImageEncoder: load anh fail %s", imagePath.c_str()); return false; }

        std::vector<unsigned char> resized(224 * 224 * 3);
        stbir_resize_uint8_srgb(data, w, h, 0, resized.data(), 224, 224, 0, STBIR_RGB);
        stbi_image_free(data);

        auto inputs = net_->getSessionInputAll(session_);
        if (inputs.empty()) { LOGE("ip_image_encoder.mnn khong co input"); return false; }
        MNN::Tensor* input = inputs.begin()->second;

        MNN::Tensor hostIn(input, MNN::Tensor::CAFFE);
        const float mean[3] = {0.481f, 0.457f, 0.408f};
        const float stdv[3] = {0.268f, 0.261f, 0.275f};
        for (int y = 0; y < 224; y++) for (int x = 0; x < 224; x++) {
            unsigned char* p = resized.data() + (y * 224 + x) * 3;
            for (int ch = 0; ch < 3; ch++)
                hostIn.host<float>()[ch*224*224 + y*224 + x] = (p[ch]/255.f - mean[ch]) / stdv[ch];
        }
        input->copyFromHostTensor(&hostIn);
        net_->runSession(session_);

        auto outputs = net_->getSessionOutputAll(session_);
        if (outputs.empty()) { LOGE("ip_image_encoder.mnn khong co output"); return false; }
        MNN::Tensor* output = outputs.begin()->second;
        MNN::Tensor hostOut(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&hostOut);

        outShape = hostOut.shape();
        size_t n = 1; for (int d : outShape) n *= (size_t)std::max(1, d);
        outEmbed.assign(hostOut.host<float>(), hostOut.host<float>() + n);
        return true;
    }
private:
    std::shared_ptr<MNN::Interpreter> net_;
    MNN::Session* session_ = nullptr;
    bool ok_ = false;
};

// mục 225 TECHNICAL_STATUS.md — subclass PipelineSd15Cpu, mirror CHÍNH XÁC
// mẫu hình PipelineSd15CpuAugmented (ip_adapter.cpp) — chỉ hook
// onBeforeUnetRun(), KHÔNG override beginDenoise() (model GLIGEN vẫn giữ
// nguyên tên input chuẩn "sample"/"timestep"/"encoder_hidden_states" như
// base, CHỈ THÊM 3 input tuỳ chọn "gligen_*" — đúng cách
// export_gligen_unet.py trace, KHÔNG đổi cấu trúc input gốc).
class PipelineSd15CpuGligen : public PipelineSd15Cpu {
 public:
    PipelineSd15CpuGligen(TextEncoder &text_encoder, const std::string &model_dir,
                          std::string clip_path, std::string unet_path,
                          std::string vae_decoder_path, std::string vae_encoder_path)
        : PipelineSd15Cpu(text_encoder, model_dir, std::move(clip_path), std::move(unet_path),
                          std::move(vae_decoder_path), std::move(vae_encoder_path),
                          /*use_v_pred=*/false) {}

    // Gọi TRƯỚC generate() — lưu nhãn/box THÔ, KHÔNG encode ngay (encode
    // thật xảy ra trong onBeforeUnetRun(), lúc đó mới biết chắc model đã
    // nạp có đúng input "gligen_*" hay không — tránh phí công encode nếu
    // ai lỡ nạp nhầm model .mnn thường (không có GLIGEN) vào pipeline này).
    void setObjectBoxes(std::vector<std::string> labels, std::vector<std::array<float, 4>> boxes) {
        labels_ = std::move(labels);
        boxes_ = std::move(boxes);
    }

    // mục 226 TECHNICAL_STATUS.md — embedding ảnh nhân vật (đã encode qua
    // GlIpImageEncoder), RỖNG = không có nhân vật cho panel này. CHỈ có
    // tác dụng nếu model đang nạp là biến thể "_char" (có input
    // "ip_image_embeds") — xem onBeforeUnetRun().
    void setCharacterEmbed(std::vector<float> embed) { characterEmbed_ = std::move(embed); }

 protected:
    void onBeforeUnetRun(MNN::Interpreter *unetInterp, MNN::Session *unetSess) override {
        // mục 226 — feed ip_image_embeds TRƯỚC, độc lập với 3 input gligen_*
        // (2 cơ chế khác nhau cùng nằm trong 1 model, xem export_gligen_unet.py
        // AugmentedUNetGligen). Graceful-optional theo tên tensor: model KHÔNG
        // phải biến thể "_char" thì getSessionInput trả null -> bỏ qua, hành vi
        // y hệt trước mục 226. Nếu model CÓ input này nhưng không có embed
        // nhân vật (characterEmbed_ rỗng) vẫn PHẢI ghi 0 — không bỏ trống
        // tensor MNN (tránh giữ rác lần chạy trước, cùng lý do mục 219).
        auto ipEmbedsIn = unetInterp->getSessionInput(unetSess, "ip_image_embeds");
        if (ipEmbedsIn) {
            MNN::Tensor h(ipEmbedsIn, MNN::Tensor::CAFFE);
            size_t total = (size_t)h.elementSize();
            size_t n = std::min(characterEmbed_.size(), total);
            if (n > 0) memcpy(h.host<float>(), characterEmbed_.data(), n * sizeof(float));
            if (n < total) memset(h.host<float>() + n, 0, (total - n) * sizeof(float));
            if (!characterEmbed_.empty() && characterEmbed_.size() != total)
                LOGE("ip_image_embeds: embed nhan vat %zu phan tu nhung tensor model can %zu - cat/dem 0, "
                     "kiem tra ip_image_encoder.mnn co cung checkpoint IP-Adapter voi luc export khong",
                     characterEmbed_.size(), total);
            ipEmbedsIn->copyFromHostTensor(&h);
        }

        auto boxesIn = unetInterp->getSessionInput(unetSess, "gligen_boxes");
        auto embedsIn = unetInterp->getSessionInput(unetSess, "gligen_positive_embeddings");
        auto masksIn = unetInterp->getSessionInput(unetSess, "gligen_masks");
        // Graceful-optional — ĐÚNG pattern pose_scale/depth_scale
        // (triple_combo.cpp)/ip_static_scale (ip_adapter.cpp): model không
        // export GLIGEN thì 3 tensor này không tồn tại trong graph,
        // getSessionInput() trả null, BỎ QUA hoàn toàn — KHÔNG throw,
        // hành vi giống hệt chạy 1 UNet thường không có gì đặc biệt.
        if (!boxesIn || !embedsIn || !masksIn) {
            if (!labels_.empty())
                LOGE("Model UNet dang nap KHONG co input gligen_* - object_boxes se KHONG co "
                     "tac dung gi panel nay (dung nham model chua export GLIGEN?)");
            return;
        }

        // mục 224 TECHNICAL_STATUS.md — dò max_objs/positive_len THẬT từ
        // chính shape tensor đã nạp, KHÔNG hardcode 30/768 — tự thích ứng
        // nếu ai export lại với --max_objs khác hoặc checkpoint GLIGEN
        // khác (miễn cùng kiến trúc `attention_type="gated"` — đúng điều
        // user chỉ ra: kiến trúc dùng chung, không phải hardcode 1 bản).
        auto boxesShape = boxesIn->shape();    // kỳ vọng [1, max_objs, 4]
        auto embedsShape = embedsIn->shape();  // kỳ vọng [1, max_objs, positive_len]
        if (boxesShape.size() != 3 || embedsShape.size() != 3 || boxesShape[2] != 4) {
            LOGE("Shape gligen_boxes/gligen_positive_embeddings bat thuong (khong dung [1,N,4]/"
                 "[1,N,C]) - model co the export tu ban script khac quy uoc - BO QUA slot GLIGEN panel nay");
            return;
        }
        int maxObjs = boxesShape[1];
        int positiveLen = embedsShape[2];
        if (maxObjs <= 0 || positiveLen <= 0) {
            LOGE("maxObjs/positiveLen doc duoc <= 0 - BO QUA slot GLIGEN panel nay");
            return;
        }

        int n = std::min((int)labels_.size(), maxObjs);
        if ((int)labels_.size() > maxObjs)
            LOGI("Co %d vat the nhung model chi ho tro toi da %d - cat bot %d vat the cuoi",
                 (int)labels_.size(), maxObjs, (int)labels_.size() - maxObjs);

        std::vector<float> boxesData((size_t)maxObjs * 4, 0.0f);
        std::vector<float> embedsData((size_t)maxObjs * positiveLen, 0.0f);
        std::vector<float> masksData((size_t)maxObjs, 0.0f);

        for (int i = 0; i < n; i++) {
            boxesData[(size_t)i * 4 + 0] = boxes_[i][0];
            boxesData[(size_t)i * 4 + 1] = boxes_[i][1];
            boxesData[(size_t)i * 4 + 2] = boxes_[i][2];
            boxesData[(size_t)i * 4 + 3] = boxes_[i][3];
            masksData[i] = 1.0f;
            auto emb = encodeLabelPooled(labels_[i], positiveLen);
            if ((int)emb.size() == positiveLen)
                memcpy(&embedsData[(size_t)i * positiveLen], emb.data(), (size_t)positiveLen * sizeof(float));
            else
                LOGE("Encode nhan '%s' that bai/sai kich thuoc - slot %d dung embedding 0 "
                     "(mask van =1, co the lam anh nhieu o vung box do)", labels_[i].c_str(), i);
        }
        // Slot đệm (i >= n): boxesData/embedsData giữ nguyên 0.0f, masksData
        // giữ 0.0f — PositionNet (bên trong model, xem export_gligen_unet.py)
        // tự thay bằng embedding NULL ĐÃ HỌC khi mask=0 (xác nhận qua source
        // thật PositionNet.forward(), KHÔNG phải "0 là an toàn" tự suy ra).

        auto writeTensor = [&](MNN::Tensor *t, const float *src, size_t count) {
            MNN::Tensor h(t, MNN::Tensor::CAFFE);
            memcpy(h.host<float>(), src, count * sizeof(float));
            t->copyFromHostTensor(&h);
        };
        writeTensor(boxesIn, boxesData.data(), boxesData.size());
        writeTensor(embedsIn, embedsData.data(), embedsData.size());
        writeTensor(masksIn, masksData.data(), masksData.size());
    }

 private:
    std::vector<std::string> labels_;
    std::vector<std::array<float, 4>> boxes_;
    std::vector<float> characterEmbed_;

    // mục 224/225 TECHNICAL_STATUS.md — encode 1 nhãn chữ qua ĐÚNG
    // clip.mnn đã dùng cho prompt chính (clip_path_, protected từ
    // PipelineSd15Cpu) — mirror CHÍNH XÁC cách
    // PipelineSd15Cpu::encodeText() (sd_engine/PipelineSd15Cpu.hpp) tạo
    // interpreter tạm/chạy 1 lần, KHÁC ở bước cuối: lấy embedding TẠI VỊ
    // TRÍ TOKEN EOS (pooled) thay vì lấy nguyên chuỗi 77 token — xem GIỚI
    // HẠN THẬT #2 đầu file cho mức tin cậy thật của bước này.
    std::vector<float> encodeLabelPooled(const std::string &label, int expectedLen) {
        std::vector<float> result;

        auto pp = text_encoder_.processWeightedPrompt(label);
        if ((int)pp.weighted_embeddings.size() != 77 * text_embedding_size) {
            LOGE("processWeightedPrompt('%s') tra ve kich thuoc bat thuong", label.c_str());
            return result;
        }

        // Vị trí token EOS = vị trí ĐẦU TIÊN có id == 49407 trong pp.ids
        // (ProcessedPrompt.ids, TextEncoder.hpp comment "CLIP (pad 49407)"
        // — 49407 dùng CHUNG cho cả EOS lẫn đệm, argmax/tìm-đầu-tiên luôn
        // ra đúng vị trí EOS thật vì nó xuất hiện TRƯỚC mọi ô đệm phía
        // sau). Không tìm thấy (toàn bộ 77 token đều < 49407, gần như
        // không thể xảy ra với chuỗi ngắn) -> dùng vị trí cuối (76) làm
        // phương án dự phòng thay vì lỗi cứng.
        int eosPos = 76;
        for (size_t i = 0; i < pp.ids.size(); i++) {
            if (pp.ids[i] == 49407) { eosPos = (int)i; break; }
        }

        MNN::Interpreter *interpreter = createMnnInterpreterMmap(clip_path_.c_str());
        if (!interpreter) { LOGE("Khong tao duoc interpreter clip.mnn tam cho nhan '%s'", label.c_str()); return result; }
        MnnSessionOptions opts;  // CLIP luôn chạy CPU, giống encodeText()
        MNN::Session *session = createMnnSession(interpreter, opts);
        if (!session) { delete interpreter; LOGE("Khong tao duoc session clip.mnn tam cho nhan '%s'", label.c_str()); return result; }

        auto input = interpreter->getSessionInput(session, "input_embedding");
        interpreter->resizeTensor(input, {1, 77, text_embedding_size});
        interpreter->resizeSession(session);
        interpreter->releaseModel();

        {
            MNN::Tensor h(input, MNN::Tensor::CAFFE);
            memcpy(h.host<float>(), pp.weighted_embeddings.data(),
                   (size_t)77 * text_embedding_size * sizeof(float));
            input->copyFromHostTensor(&h);
        }
        interpreter->runSession(session);
        auto out = interpreter->getSessionOutput(session, "last_hidden_state");
        MNN::Tensor outHost(out, MNN::Tensor::CAFFE);
        out->copyToHostTensor(&outHost);

        result.resize(text_embedding_size);
        memcpy(result.data(), outHost.host<float>() + (size_t)eosPos * text_embedding_size,
               (size_t)text_embedding_size * sizeof(float));
        if ((int)result.size() != expectedLen)
            LOGE("positive_len model (%d) khac text_embedding_size du an (%d) - dung nham checkpoint GLIGEN khac SD1.5?",
                 expectedLen, text_embedding_size);

        interpreter->releaseSession(session);
        delete interpreter;
        return result;
    }
};

// ─────────────────────────────────────────────────────────────────────────
// JNI — mirror CHÍNH XÁC sdInitAugmented/sdFreeAugmented/
// sdTxt2ImgWithReferenceAndPose (ip_adapter.cpp)
// ─────────────────────────────────────────────────────────────────────────
struct SdGligenHandle {
    std::unique_ptr<TextEncoder> textEncoder;
    std::unique_ptr<PipelineSd15CpuGligen> pipeline;
    // mục 226 — chỉ tạo khi jIpEncoderPath không rỗng (biến thể "_char").
    std::unique_ptr<GlIpImageEncoder> ipEncoder;
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdInitGligen(JNIEnv *e, jobject,
    jstring jModelDir, jstring jClip, jstring jUnet,
    jstring jVaeDec, jstring jVaeEnc,
    // mục 226 — RỖNG = không dùng slot nhân vật (biến thể unet_gligen.mnn
    // thường); thứ tự này (sau jVaeEnc, trước jTokenizer) mirror sdInitAugmented.
    jstring jIpEncoderPath,
    jstring jTokenizer, jstring jEmbeddingsDir,
    jboolean, jboolean) {  // useOpenCL/useNpu giữ nguyên chữ ký cho đồng bộ
                            // với mọi hàm sdInit* khác, nhưng CHƯA dùng ở
                            // đây (mục 225 GIỚI HẠN THẬT: pipeline GLIGEN
                            // này CHƯA test OpenCL/NPU, mặc định CPU an
                            // toàn — thêm sau khi có kiểm chứng thật, xem
                            // VIỆC CÒN LẠI mục 225).
    try {
        auto *handle = new SdGligenHandle();
        handle->textEncoder = std::make_unique<TextEncoder>();
        handle->textEncoder->loadTokenizer(j2s_gligen(e, jTokenizer));
        std::string embeddingsDir = j2s_gligen(e, jEmbeddingsDir);
        if (!embeddingsDir.empty()) handle->textEncoder->loadTextualInversions(embeddingsDir);

        std::string ipEncoderPath = j2s_gligen(e, jIpEncoderPath);
        if (!ipEncoderPath.empty()) {
            handle->ipEncoder = std::make_unique<GlIpImageEncoder>(ipEncoderPath);
            if (!handle->ipEncoder->ok()) {
                // Không chặn cả pipeline — chỉ tắt riêng slot nhân vật, model
                // "_char" vẫn chạy được (ip_image_embeds sẽ = 0, xem onBeforeUnetRun).
                LOGE("sdInitGligen: ip_image_encoder khong nap duoc (%s) - tiep tuc KHONG co slot nhan vat", ipEncoderPath.c_str());
                handle->ipEncoder.reset();
            }
        }
        handle->pipeline = std::make_unique<PipelineSd15CpuGligen>(
            *handle->textEncoder, j2s_gligen(e, jModelDir),
            j2s_gligen(e, jClip), j2s_gligen(e, jUnet),
            j2s_gligen(e, jVaeDec), j2s_gligen(e, jVaeEnc));
        if (!handle->pipeline->initialize()) {
            LOGE("PipelineSd15CpuGligen initialize() fail");
            delete handle;
            return 0;
        }
        return reinterpret_cast<jlong>(handle);
    } catch (const std::exception &ex) {
        LOGE("sdInitGligen that bai: %s", ex.what());
        return 0;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdFreeGligen(JNIEnv *, jobject, jlong ptr) {
    delete reinterpret_cast<SdGligenHandle *>(ptr);
}

// mục 222/223 Models.kt — jLabels/jBoxesFlat CÙNG ĐỘ DÀI logic (jBoxesFlat
// = 4 * so_luong_nhan, thu tu [xmin,ymin,xmax,ymax] lien tiep tung vat the,
// DUNG THU TU VOI jLabels) — mirror cach du an truyen mang phang cho cac
// tensor khac (vd characterMasks trong ip_adapter_sdxl.cpp).
extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgGligen(JNIEnv *e, jobject,
    jlong ptr, jstring jPrompt, jstring jNeg,
    jobjectArray jLabels, jfloatArray jBoxesFlat,
    // mục 226 — null/rỗng = không có nhân vật (hoặc model không phải "_char")
    jstring jReferenceImagePath,
    jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut,
    jobject cb) {
    auto *handle = reinterpret_cast<SdGligenHandle *>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgGligen: chua init"); return JNI_FALSE; }

    std::vector<std::string> labels;
    std::vector<std::array<float, 4>> boxes;
    if (jLabels && jBoxesFlat) {
        jsize n = e->GetArrayLength(jLabels);
        jsize flatLen = e->GetArrayLength(jBoxesFlat);
        if (flatLen != n * 4) {
            LOGE("sdTxt2ImgGligen: jBoxesFlat do dai %d khong khop 4x so nhan (%d) - BO QUA toan bo object_boxes panel nay",
                 (int)flatLen, (int)n);
        } else {
            std::vector<float> flat(flatLen);
            e->GetFloatArrayRegion(jBoxesFlat, 0, flatLen, flat.data());
            for (jsize i = 0; i < n; i++) {
                auto jLabel = (jstring)e->GetObjectArrayElement(jLabels, i);
                labels.push_back(j2s_gligen(e, jLabel));
                e->DeleteLocalRef(jLabel);
                boxes.push_back({flat[i*4+0], flat[i*4+1], flat[i*4+2], flat[i*4+3]});
            }
        }
    }
    handle->pipeline->setObjectBoxes(labels, boxes);

    // mục 226 — encode ảnh tham chiếu nhân vật (nếu có + encoder đã nạp).
    // Lỗi encode KHÔNG chặn panel — chỉ log, embed rỗng -> ip_image_embeds=0.
    std::vector<float> characterEmbed;
    std::string refPath = jReferenceImagePath ? j2s_gligen(e, jReferenceImagePath) : std::string();
    if (!refPath.empty()) {
        if (!handle->ipEncoder) {
            LOGE("sdTxt2ImgGligen: co anh tham chieu nhung ip_image_encoder chua nap (init khong truyen jIpEncoderPath?) - BO QUA nhan vat");
        } else {
            std::vector<int> shape;
            if (!handle->ipEncoder->encode(refPath, characterEmbed, shape)) {
                LOGE("sdTxt2ImgGligen: encode anh nhan vat that bai (%s) - tiep tuc KHONG co nhan vat", refPath.c_str());
                characterEmbed.clear();
            }
        }
    }
    handle->pipeline->setCharacterEmbed(std::move(characterEmbed));

    GenerationRequest req;
    req.prompt = j2s_gligen(e, jPrompt);
    req.negative_prompt = j2s_gligen(e, jNeg);
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg; req.seed = (unsigned)seed;
    req.use_opencl = false; req.use_npu = false; req.require_npu = false;  // xem GIỚI HẠN THẬT sdInitGligen

    // mục 134 TECHNICAL_STATUS.md — progress callback per-step, mirror
    // CHÍNH XÁC pattern JVM-attach/detach thật của ip_adapter.cpp (KHÔNG
    // dùng thẳng JNIEnv* e gốc — generate() có thể gọi callback từ ngữ
    // cảnh khác, JNIEnv của thread gốc không an toàn để tái sử dụng trực
    // tiếp qua 1 vòng lặp dài).
    JavaVM *jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    ProgressCallback progress = [jvm, cbGlobal](int step, int total, const std::string &) {
        if (!cbGlobal || !jvm) return;
        JNIEnv *env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_gligen(e, jOut), std::ios::binary);
        bool ok = false;
        if (out) {
            out.write(reinterpret_cast<const char *>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
        if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
        if (!ok) LOGE("sdTxt2ImgGligen: ghi PNG that bai");
        return ok ? JNI_TRUE : JNI_FALSE;
    } catch (const std::exception &ex) {
        if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
        LOGE("sdTxt2ImgGligen that bai: %s", ex.what());
        return JNI_FALSE;
    }
}
