// mục 286 TECHNICAL_STATUS.md — gọi callback tiến trình `onProgress(II)V` (SDProgressCallback bên Kotlin) AN TOÀN.
//
// VẤN ĐỀ của mẫu cũ (14 chỗ: ip_adapter*, regional_*, triple_combo, gligen_wrapper, mnn_diffusion_pipeline):
//     jvm->AttachCurrentThread(&env, nullptr);  GetObjectClass(...);  CallVoidMethod(...);  jvm->DetachCurrentThread();
//   Pipeline::generate gọi `progress` ĐỒNG BỘ ngay trên luồng đã gọi hàm JNI — tức một luồng JAVA, đang có khung Java trong ngăn xếp (không có std::thread nào).
//   1) Trên luồng đó `DetachCurrentThread()` bị ART từ chối bằng LOG(FATAL) "attempting to detach while still running code": JavaVMExt::DetachCurrentThread →
//      Runtime::DetachCurrentThread → `if (self->HasManagedStack()) LOG(FATAL)` (runtime/runtime.cc, đã đọc mã nguồn AOSP). Nghĩa là app abort ở step ĐẦU TIÊN có callback.
//      (HotSpot chỉ trả JNI_ERR — nên thử bằng JDK không thấy sập; xem tools/test_jni_progress.py.)
//   2) Dù không abort, `jclass cls` là tham chiếu cục bộ tạo mỗi step và chỉ được giải phóng khi hàm JNI kết thúc ⇒ rò theo số step.
//   3) Exception do callback ném ra (RuntimeException ở Kotlin) bị để treo; lời gọi JNI kế tiếp là hành vi không xác định.
//
// CÁCH ĐÚNG: GetEnv trước. Chỉ khi luồng CHƯA gắn vào JVM (JNI_EDETACHED — luồng native thuần) mới Attach và nhớ để Detach; luồng Java (JNI_OK) dùng env sẵn có và KHÔNG detach.
// Mọi tham chiếu cục bộ nằm trong một local frame (PushLocalFrame/PopLocalFrame); exception treo được xoá.
// Chưa chạy trên thiết bị Android thật (xem mục 286); đã kiểm trên JVM thật bằng tools/test_jni_progress.py với bộ đếm Attach/Detach chèn vào JavaVM.
#pragma once
#include <jni.h>

namespace mangalocal {
namespace jni_detail {
// NDK khai báo AttachCurrentThread(JNIEnv**, void*), OpenJDK khai báo AttachCurrentThread(void**, void*): chọn theo kiểu tham số thật để cùng một mã biên dịch được ở cả hai.
template <typename VM>
inline auto attachThread(VM* vm, JNIEnv** env, int) -> decltype(vm->AttachCurrentThread(env, nullptr)) { return vm->AttachCurrentThread(env, nullptr); }
template <typename VM>
inline jint attachThread(VM* vm, JNIEnv** env, long) { return vm->AttachCurrentThread(reinterpret_cast<void**>(env), nullptr); }
}  // namespace jni_detail

// Gọi `cb.onProgress(step, total)`. Không làm gì nếu thiếu jvm/callback. KHÔNG ném, KHÔNG để exception treo, KHÔNG detach luồng mà nó không tự attach.
inline void jniCallProgress(JavaVM* jvm, jobject cbGlobal, int step, int total) {
    if (!jvm || !cbGlobal) return;
    JNIEnv* env = nullptr;
    bool attachedHere = false;
    const jint st = jvm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    if (st == JNI_EDETACHED) {
        if (jni_detail::attachThread(jvm, &env, 0) != JNI_OK || !env) return;
        attachedHere = true;
    } else if (st != JNI_OK || !env) {
        return;
    }
    if (env->PushLocalFrame(8) == 0) {
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = cls ? env->GetMethodID(cls, "onProgress", "(II)V") : nullptr;
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        if (env->ExceptionCheck()) env->ExceptionClear();   // callback Kotlin ném lỗi: không để treo sang lời gọi JNI sau
        env->PopLocalFrame(nullptr);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();       // phòng trường hợp PushLocalFrame thất bại (OOM) để lại exception
    if (attachedHere) jvm->DetachCurrentThread();
}
}  // namespace mangalocal
