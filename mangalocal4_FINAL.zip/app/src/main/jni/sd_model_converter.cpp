// sd_model_converter.cpp — adapter JNI cho việc convert model/LoRA NGAY
// TRÊN ĐIỆN THOẠI. Gọi thẳng `generateMNNModels()` thật của local-dream
// (port trong sd_engine/SafeTensor2MNN.hpp) — hàm đó tự đọc
// model.safetensors + lora.N.safetensors, merge LoRA bằng phép nhân ma
// trận (KHÔNG PHẢI training, chỉ 1 phép tính, đủ nhẹ để chạy trên CPU
// điện thoại), rồi ghi ra unet.mnn.weight/vae*.mnn.weight.
//
// ĐIỀU KIỆN TIÊN QUYẾT — đọc kỹ trước khi dùng tính năng này:
// generateMNNModels() KHÔNG tự dựng đồ thị .mnn từ đầu — nó cần đã có sẵn
// unet.mnn/vae_decoder.mnn/vae_encoder.mnn "khung" (cấu trúc đồ thị cố
// định, trọng số bên trong là placeholder) rồi mới PATCH trọng số thật
// vào (xem hàm patchModel() mở file .mnn có sẵn ở chế độ đọc-ghi, không
// tạo mới). File "khung" này KHÔNG có trong local-dream-master.zip bạn
// upload (không phải mã nguồn, là tài nguyên build) — bạn cần tự lấy nó
// từ gói model gốc của local-dream (họ tải riêng, không nằm trong git)
// và đặt sẵn vào thư mục model TRƯỚC khi gọi hàm convert này. Nếu thiếu,
// patchModel() sẽ lặng lẽ không ghi được (seekp fail) — ĐÃ THÊM kiểm tra
// tồn tại file khung bên dưới để báo lỗi rõ thay vì im lặng.

#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <fstream>

#include "sd_engine/SafeTensor2MNN.hpp"

#define TAG "MangaLocal_SDConverter"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::string j2s_c(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c);
    e->ReleaseStringUTFChars(js, c);
    return s;
}

static bool fileExists(const std::string& path) {
    std::ifstream f(path);
    return f.good();
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdConvertModel(JNIEnv* e, jobject,
    jstring jDir, jstring jSafetensorFile, jboolean jClipSkip2,
    jobjectArray jLoraFiles, jfloatArray jLoraWeights, jboolean jOrthogonalLora) {

    std::string dir = j2s_c(e, jDir);
    std::string safetensorFile = j2s_c(e, jSafetensorFile);

    // Kiểm tra tường minh file khung .mnn đã có sẵn chưa — không để
    // patchModel() thất bại âm thầm (xem giải thích ở đầu file).
    for (const char* templ : {"unet.mnn", "vae_decoder.mnn", "vae_encoder.mnn"}) {
        std::string p = dir + "/" + templ;
        if (!fileExists(p)) {
            LOGE("Thieu file khung '%s' - phai co san TRUOC khi convert (xem comment dau file sd_model_converter.cpp). Duong dan: %s", templ, p.c_str());
            return JNI_FALSE;
        }
    }
    if (!fileExists(dir + "/" + safetensorFile)) {
        LOGE("Khong tim thay file checkpoint: %s", (dir + "/" + safetensorFile).c_str());
        return JNI_FALSE;
    }

    std::vector<std::string> loras;
    std::vector<float> loraWeights;
    if (jLoraFiles) {
        int n = e->GetArrayLength(jLoraFiles);
        for (int i = 0; i < n; i++) {
            auto js = (jstring)e->GetObjectArrayElement(jLoraFiles, i);
            std::string loraFile = j2s_c(e, js);
            e->DeleteLocalRef(js);
            if (!fileExists(dir + "/" + loraFile)) {
                LOGE("Khong tim thay file LoRA: %s", (dir + "/" + loraFile).c_str());
                return JNI_FALSE;
            }
            loras.push_back(loraFile);
        }
    }
    if (jLoraWeights) {
        int n = e->GetArrayLength(jLoraWeights);
        jfloat* buf = e->GetFloatArrayElements(jLoraWeights, nullptr);
        for (int i = 0; i < n; i++) loraWeights.push_back(buf[i]);
        e->ReleaseFloatArrayElements(jLoraWeights, buf, JNI_ABORT);
    }

    try {
        LOGI("Bat dau convert: dir=%s checkpoint=%s so_lora=%zu orthogonal_lora=%s",
             dir.c_str(), safetensorFile.c_str(), loras.size(), jOrthogonalLora ? "true" : "false");
        generateMNNModels(dir, safetensorFile, jClipSkip2, loras, loraWeights, (bool)jOrthogonalLora);
        bool ok = fileExists(dir + "/finished");
        LOGI("Convert xong, ket qua: %s", ok ? "THANH CONG" : "THAT BAI (khong thay marker 'finished')");
        return ok ? JNI_TRUE : JNI_FALSE;
    } catch (const std::exception& ex) {
        LOGE("Convert loi: %s", ex.what());
        return JNI_FALSE;
    }
}
