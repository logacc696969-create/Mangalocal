// triple_combo.cpp — mục 151 TECHNICAL_STATUS.md: nối dây phía app cho
// model Triple-Conditioning combo (Regional Prompting + IP-Adapter mask +
// Depth ControlNet CÙNG LÚC 1 UNet, export bởi tools/export_ipa_controlnet_
// triple_combo_unet.py, mục 143). ĐỌC DOCSTRING FILE PYTHON ĐÓ TRƯỚC —
// giải thích đầy đủ vì sao gộp thủ công 2 khối logic thay vì ghép thẳng 2
// pipeline có sẵn, và các đơn giản hoá có chủ đích (ranh giới cột cứng,
// IP-Adapter không cộng vào vế uncond).
//
// KHÔNG include ip_adapter.cpp/regional_prompting.cpp (giữ đúng quy ước
// "không phụ thuộc chéo giữa các file .cpp pipeline" đã áp dụng nhất quán
// trong dự án — xem comment đầu regional_prompting.cpp) — 2 khối nhỏ cần
// dùng lại (IpImageEncoder, encode 1 prompt qua CLIP) được VIẾT LẠI Ở ĐÂY,
// COPY logic đã xác nhận đúng từ 2 file kia, không suy đoán lại.
//
// pose_hint/depth_hint: KHÔNG tự render trong file này (namespace
// pose_templates nằm trong ip_adapter.cpp, không cross-include được) — nhận
// THẲNG buffer RGB đã dựng sẵn từ Kotlin, gọi qua 2 JNI entry point ĐỘC LẬP
// đã có sẵn: renderSkeletonCanvas() (pose_hint) và renderDepthHintCanvas()
// (depth_hint, MỚI thêm ở ip_adapter.cpp cùng mục 151) — đúng cách
// regional_prompting.cpp đã làm cho control_hint của riêng nó.

#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <memory>
#include <fstream>
#include <cmath>
#include <algorithm>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

#include "sd_engine/Config.hpp"
#include "sd_engine/MnnUtils.hpp"
#include "sd_engine/PipelineSd15Cpu.hpp"
#include "sd_engine/TextEncoder.hpp"

extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
}
#include "sd_engine/stb_image_resize2.h"

#define TAG "MangaLocal_TripleCombo"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::string j2s_tc(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c);
    e->ReleaseStringUTFChars(js, c);
    return s;
}

// COPY NGUYÊN VĂN từ ip_adapter.cpp::IpImageEncoder (đã xác nhận đúng,
// dùng thật ở đường mask N-nhân-vật) — chỉ đổi tên biến cho gọn, KHÔNG đổi
// logic. Xem file đó cho giải thích chi tiết (chuẩn hoá CLIP ViT xấp xỉ
// OpenAI, resize 224x224).
class TcIpImageEncoder {
public:
    explicit TcIpImageEncoder(const std::string& modelPath) {
        net_.reset(MNN::Interpreter::createFromFile(modelPath.c_str()));
        if (!net_) { LOGE("TcIpImageEncoder: khong doc duoc %s", modelPath.c_str()); return; }
        MNN::ScheduleConfig cfg; cfg.type = MNN_FORWARD_CPU; cfg.numThread = 4;
        session_ = net_->createSession(cfg);
        ok_ = session_ != nullptr;
    }
    bool ok() const { return ok_; }

    bool encode(const std::string& imagePath, std::vector<float>& outEmbed, std::vector<int>& outShape) {
        if (!ok_) return false;
        int w, h, c;
        unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("TcIpImageEncoder: load anh fail %s", imagePath.c_str()); return false; }

        std::vector<unsigned char> resized(224 * 224 * 3);
        stbir_resize_uint8_srgb(data, w, h, 0, resized.data(), 224, 224, 0, STBIR_RGB);
        stbi_image_free(data);

        auto inputs = net_->getSessionInputAll(session_);
        if (inputs.empty()) { LOGE("ip_image_encoder.mnn khong co input"); return false; }
        MNN::Tensor* input = inputs.begin()->second;

        MNN::Tensor hostIn(input, MNN::Tensor::CAFFE);
        const float mean[3] = {0.481f, 0.457f, 0.408f};
        const float stdv[3] = {0.268f, 0.261f, 0.275f};
        for (int y = 0; y < 224; y++) for (int x = 0; x < 224; x++) {
            unsigned char* p = resized.data() + (y * 224 + x) * 3;
            for (int ch = 0; ch < 3; ch++)
                hostIn.host<float>()[ch*224*224 + y*224 + x] = (p[ch]/255.f - mean[ch]) / stdv[ch];
        }
        input->copyFromHostTensor(&hostIn);
        net_->runSession(session_);

        auto outputs = net_->getSessionOutputAll(session_);
        if (outputs.empty()) { LOGE("ip_image_encoder.mnn khong co output"); return false; }
        MNN::Tensor* output = outputs.begin()->second;
        MNN::Tensor hostOut(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&hostOut);

        outShape = hostOut.shape();
        size_t n = 1; for (int d : outShape) n *= (size_t)std::max(1, d);
        outEmbed.assign(hostOut.host<float>(), hostOut.host<float>() + n);
        return true;
    }
private:
    std::shared_ptr<MNN::Interpreter> net_;
    MNN::Session* session_ = nullptr;
    bool ok_ = false;
};

// COPY logic từ regional_prompting.cpp::encodeOnePrompt() — TÁI DÙNG đúng
// processPromptPair() (tokenize+weight thật), viết lại ngắn ở đây theo
// đúng quy ước không cross-include.
static std::vector<float> tcEncodeOnePrompt(TextEncoder &textEncoder, MNN::Interpreter *clipInterp,
                                             MNN::Session *clipSession, int textEmbeddingSize,
                                             const std::string &prompt) {
    ProcessedPromptPair pair = textEncoder.processPromptPair(prompt, "");
    auto input = clipInterp->getSessionInput(clipSession, "input_embedding");
    memcpy(input->host<float>(), pair.positive_embeddings.data(),
           77 * textEmbeddingSize * sizeof(float));
    clipInterp->runSession(clipSession);
    auto out = clipInterp->getSessionOutput(clipSession, "last_hidden_state");
    std::vector<float> result(77 * textEmbeddingSize);
    memcpy(result.data(), out->host<float>(), result.size() * sizeof(float));
    return result;
}

// PipelineSd15CpuTripleCombo — override THẲNG beginDenoise()/runUnetStep()
// (KHÔNG dùng onBeforeUnetRun hook), giống hệt lý do PipelineSd15CpuRegional
// đã làm: model này có input HOÀN TOÀN KHÁC tên/shape base class
// (uncond_encoder_hidden_states/region_encoder_hidden_states/region_ip_embeds/
// pose_hint/depth_hint — không có "encoder_hidden_states" gốc).
class PipelineSd15CpuTripleCombo : public PipelineSd15Cpu {
public:
    PipelineSd15CpuTripleCombo(TextEncoder &text_encoder, const std::string &model_dir,
                                std::string clip_path, std::string unet_triple_path,
                                std::string vae_decoder_path, std::string vae_encoder_path,
                                int num_regions)
        : PipelineSd15Cpu(text_encoder, model_dir, clip_path, unet_triple_path,
                          vae_decoder_path, vae_encoder_path, /*use_v_pred=*/false),
          num_regions_(num_regions) {}

    // uncondEmbed: 1×77×768. regionEmbeds: N×77×768 (ĐÚNG thứ tự cột
    // trái->phải, khớp regionIpEmbeds cùng thứ tự — 1 nhân vật = 1 cột =
    // 1 hàng ở CẢ 2 mảng, xem docstring export script cho lý do ràng buộc
    // này). regionIpEmbeds: N × (shape do ip_image_encoder.mnn trả ra —
    // ĐỌC THẬT lúc encode, không hardcode). poseHintRgb/depthHintRgb: canvas
    // RGB 0-255 HWC, ĐÚNG kích thước controlSize x controlSize (vuông, khớp
    // --image_size lúc export — xem GIỚI HẠN THẬT trong export script).
    void setConditioning(const std::vector<float>& uncondEmbed,
                          const std::vector<float>& regionEmbeds,
                          const std::vector<float>& regionIpEmbeds,
                          const std::vector<int>& ipEmbedShapePerChar,
                          const std::vector<uint8_t>& poseHintRgb,
                          const std::vector<uint8_t>& depthHintRgb,
                          int controlSize,
                          float poseScale, float depthScale,
                          float ipDecayFloor, float ipDecayStartTimestep) {
        uncondEmbed_ = uncondEmbed;
        regionEmbeds_ = regionEmbeds;
        regionIpEmbeds_ = regionIpEmbeds;
        ipEmbedShapePerChar_ = ipEmbedShapePerChar;
        poseHintRgb_ = poseHintRgb;
        depthHintRgb_ = depthHintRgb;
        controlSize_ = controlSize;
        poseScale_ = poseScale; depthScale_ = depthScale;
        ipDecayFloor_ = ipDecayFloor; ipDecayStartTimestep_ = ipDecayStartTimestep;
        hasConditioning_ = true;
    }

protected:
    void beginDenoise(const GenerationRequest &req) override {
        unet_interpreter_ = createMnnInterpreterMmap(unet_path_.c_str());
        if (!unet_interpreter_) throw std::runtime_error("Failed to create MNN UNET (triple combo) interpreter!");

        unet_session_ = createMnnSession(unet_interpreter_, sessionOptions(req, "unet_triple_combo_cache"));
        if (!unet_session_) throw std::runtime_error("Failed to create MNN UNET (triple combo) session!");

        auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
        auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
        auto uncondIn = unet_interpreter_->getSessionInput(unet_session_, "uncond_encoder_hidden_states");
        auto regionIn = unet_interpreter_->getSessionInput(unet_session_, "region_encoder_hidden_states");
        auto ipIn = unet_interpreter_->getSessionInput(unet_session_, "region_ip_embeds");
        auto poseIn = unet_interpreter_->getSessionInput(unet_session_, "pose_hint");
        auto depthIn = unet_interpreter_->getSessionInput(unet_session_, "depth_hint");
        if (!samp || !ts || !uncondIn || !regionIn || !ipIn || !poseIn || !depthIn) {
            throw std::runtime_error(
                "Model unet_triple_combo_*.mnn thieu 1 trong cac input bat buoc "
                "(sample/timestep/uncond_encoder_hidden_states/region_encoder_hidden_states/"
                "region_ip_embeds/pose_hint/depth_hint) - co dung dung file model triple combo khong?");
        }

        unet_interpreter_->resizeTensor(samp, {2, 4, req.height / 8, req.width / 8});
        unet_interpreter_->resizeTensor(ts, {1});
        unet_interpreter_->resizeTensor(uncondIn, {1, 77, text_embedding_size});
        unet_interpreter_->resizeTensor(regionIn, {num_regions_, 77, text_embedding_size});
        // region_ip_embeds — shape [N, ...rest] với "...rest" đọc THẬT từ
        // ip_image_encoder.mnn lúc encode (ipEmbedShapePerChar_ đã bỏ sẵn
        // chiều batch=1 gốc trước khi truyền vào đây, xem JNI phía dưới) —
        // KHÔNG hardcode rank/kích thước, đúng nguyên tắc toàn dự án.
        {
            std::vector<int> ipShape; ipShape.push_back(num_regions_);
            for (int d : ipEmbedShapePerChar_) ipShape.push_back(d);
            unet_interpreter_->resizeTensor(ipIn, ipShape);
        }
        unet_interpreter_->resizeTensor(poseIn, {2, 3, req.height, req.width});
        unet_interpreter_->resizeTensor(depthIn, {2, 3, req.height, req.width});
        unet_interpreter_->resizeSession(unet_session_);
        if (req.use_opencl) unet_interpreter_->updateCacheFile(unet_session_);
        unet_interpreter_->releaseModel();
    }

    void runUnetStep(const GenerationRequest &req, const float *latents_batch2,
                     float timestep_f, bool /*skip_uncond*/, Conditioning & /*cond*/,
                     float *out_batch2) override {
        if (!hasConditioning_) {
            LOGE("runUnetStep (triple combo) goi truoc setConditioning() - anh se sai/rac");
        }
        const int timestep = static_cast<int>(timestep_f);
        auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
        auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
        auto uncondIn = unet_interpreter_->getSessionInput(unet_session_, "uncond_encoder_hidden_states");
        auto regionIn = unet_interpreter_->getSessionInput(unet_session_, "region_encoder_hidden_states");
        auto ipIn = unet_interpreter_->getSessionInput(unet_session_, "region_ip_embeds");
        auto poseIn = unet_interpreter_->getSessionInput(unet_session_, "pose_hint");
        auto depthIn = unet_interpreter_->getSessionInput(unet_session_, "depth_hint");
        // 4 input scalar — KHÔNG resizeTensor (shape cố định lúc export,
        // đúng tiền lệ mọi input scalar khác trong dự án — xem
        // ip_adapter.cpp::onBeforeUnetRun cho pose_scale/depth_scale).
        auto poseScaleIn = unet_interpreter_->getSessionInput(unet_session_, "pose_scale");
        auto depthScaleIn = unet_interpreter_->getSessionInput(unet_session_, "depth_scale");
        auto decayFloorIn = unet_interpreter_->getSessionInput(unet_session_, "ip_decay_floor");
        auto decayStartIn = unet_interpreter_->getSessionInput(unet_session_, "ip_decay_start_timestep");

        size_t batch2_count = (size_t)2 * 4 * (req.height / 8) * (req.width / 8);
        MNN::Tensor samp_h(samp, MNN::Tensor::CAFFE);
        MNN::Tensor ts_h(ts, MNN::Tensor::CAFFE);
        MNN::Tensor uncond_h(uncondIn, MNN::Tensor::CAFFE);
        MNN::Tensor region_h(regionIn, MNN::Tensor::CAFFE);
        MNN::Tensor ip_h(ipIn, MNN::Tensor::CAFFE);
        MNN::Tensor pose_h(poseIn, MNN::Tensor::CAFFE);
        MNN::Tensor depth_h(depthIn, MNN::Tensor::CAFFE);

        memcpy(samp_h.host<float>(), latents_batch2, batch2_count * sizeof(float));
        memcpy(ts_h.host<int>(), &timestep, sizeof(int));
        memcpy(uncond_h.host<float>(), uncondEmbed_.data(),
               std::min(uncondEmbed_.size(), (size_t)uncond_h.elementSize()) * sizeof(float));
        memcpy(region_h.host<float>(), regionEmbeds_.data(),
               std::min(regionEmbeds_.size(), (size_t)region_h.elementSize()) * sizeof(float));
        memcpy(ip_h.host<float>(), regionIpEmbeds_.data(),
               std::min(regionIpEmbeds_.size(), (size_t)ip_h.elementSize()) * sizeof(float));

        // pose_hint / depth_hint — canvas RGB Kotlin dựng sẵn (qua
        // renderSkeletonCanvas()/renderDepthHintCanvas(), xem comment đầu
        // file), chuẩn hoá [0,1], NCHW, LẶP cho cả 2 batch (uncond & cond
        // dùng CHUNG 1 điều kiện không gian — ĐÚNG cách regional_prompting.cpp
        // đã làm cho control_hint, không phải suy đoán lại).
        int size = controlSize_;
        size_t plane = (size_t)3 * size * size;
        for (int b = 0; b < 2; b++) {
            for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
                const uint8_t *pp = poseHintRgb_.data() + ((size_t)y * size + x) * 3;
                const uint8_t *pd = depthHintRgb_.data() + ((size_t)y * size + x) * 3;
                for (int ch = 0; ch < 3; ch++) {
                    pose_h.host<float>()[b * plane + (size_t)ch * size * size + y * size + x] = pp[ch] / 255.f;
                    depth_h.host<float>()[b * plane + (size_t)ch * size * size + y * size + x] = pd[ch] / 255.f;
                }
            }
        }

        samp->copyFromHostTensor(&samp_h);
        ts->copyFromHostTensor(&ts_h);
        uncondIn->copyFromHostTensor(&uncond_h);
        regionIn->copyFromHostTensor(&region_h);
        ipIn->copyFromHostTensor(&ip_h);
        poseIn->copyFromHostTensor(&pose_h);
        depthIn->copyFromHostTensor(&depth_h);
        if (poseScaleIn) { MNN::Tensor h(poseScaleIn, MNN::Tensor::CAFFE); h.host<float>()[0] = poseScale_; poseScaleIn->copyFromHostTensor(&h); }
        if (depthScaleIn) { MNN::Tensor h(depthScaleIn, MNN::Tensor::CAFFE); h.host<float>()[0] = depthScale_; depthScaleIn->copyFromHostTensor(&h); }
        if (decayFloorIn) { MNN::Tensor h(decayFloorIn, MNN::Tensor::CAFFE); h.host<float>()[0] = ipDecayFloor_; decayFloorIn->copyFromHostTensor(&h); }
        if (decayStartIn) { MNN::Tensor h(decayStartIn, MNN::Tensor::CAFFE); h.host<float>()[0] = ipDecayStartTimestep_; decayStartIn->copyFromHostTensor(&h); }

        unet_interpreter_->runSession(unet_session_);

        auto output = unet_interpreter_->getSessionOutput(unet_session_, "out_sample");
        MNN::Tensor out_h(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&out_h);
        memcpy(out_batch2, out_h.host<float>(), batch2_count * sizeof(float));
    }

private:
    int num_regions_;
    bool hasConditioning_ = false;
    std::vector<float> uncondEmbed_;
    std::vector<float> regionEmbeds_;
    std::vector<float> regionIpEmbeds_;
    std::vector<int> ipEmbedShapePerChar_;
    std::vector<uint8_t> poseHintRgb_;
    std::vector<uint8_t> depthHintRgb_;
    int controlSize_ = 512;
    float poseScale_ = 1.0f, depthScale_ = 0.6f;
    float ipDecayFloor_ = 1.0f, ipDecayStartTimestep_ = 999.0f;
};

struct SdTripleComboHandle {
    std::unique_ptr<TextEncoder> textEncoder;
    std::unique_ptr<PipelineSd15CpuTripleCombo> pipeline;
    std::unique_ptr<TcIpImageEncoder> ipEncoder;
    std::string clipPath;
    bool useOpenCL = false;
    bool useNpu = false;
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdInitTripleCombo(JNIEnv* e, jobject,
    jstring jModelDir, jstring jClip, jstring jUnetTriple, jstring jVaeDec, jstring jVaeEnc,
    jstring jIpEncoderPath, jstring jTokenizer, jstring jEmbeddingsDir, jint jNumRegions,
    jboolean jUseOpenCL, jboolean jUseNpu) {

    std::string dir = j2s_tc(e, jModelDir);
    try {
        auto handle = std::make_unique<SdTripleComboHandle>();
        handle->useOpenCL = jUseOpenCL;
        handle->useNpu = jUseNpu;
        handle->textEncoder = std::make_unique<TextEncoder>(false, false);
        handle->textEncoder->loadTokenizer(j2s_tc(e, jTokenizer));
        handle->textEncoder->loadEmbeddingTables(dir);
        std::string embeddingsDir = j2s_tc(e, jEmbeddingsDir);
        if (!embeddingsDir.empty()) handle->textEncoder->loadTextualInversions(embeddingsDir);

        handle->ipEncoder = std::make_unique<TcIpImageEncoder>(j2s_tc(e, jIpEncoderPath));
        if (!handle->ipEncoder->ok()) { LOGE("sdInitTripleCombo: ip_image_encoder.mnn khong mo duoc"); return 0; }

        handle->clipPath = j2s_tc(e, jClip);
        handle->pipeline = std::make_unique<PipelineSd15CpuTripleCombo>(
            *handle->textEncoder, dir, handle->clipPath, j2s_tc(e, jUnetTriple),
            j2s_tc(e, jVaeDec), j2s_tc(e, jVaeEnc), (int)jNumRegions);
        if (!handle->pipeline->initialize()) { LOGE("PipelineSd15CpuTripleCombo initialize() fail"); return 0; }

        return reinterpret_cast<jlong>(handle.release());
    } catch (const std::exception &ex) {
        LOGE("sdInitTripleCombo loi: %s", ex.what());
        return 0;
    }
}

// jRegionPrompts: N prompt CHỮ (đúng thứ tự cột — dùng
// MangaPipeline.buildRegionPrompts() phía Kotlin, TÁI DÙNG nguyên hàm đã
// có cho Regional Prompting thường, không viết lại).
// jReferenceImagePaths: N đường dẫn ảnh neo (ĐÚNG thứ tự khớp jRegionPrompts
// — 1 cột = 1 nhân vật = 1 phần tử ở CẢ 2 mảng).
// jPoseHintRgb/jDepthHintRgb: 2 canvas RGB thô Kotlin dựng sẵn qua
// renderSkeletonCanvas()/renderDepthHintCanvas().
extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgTripleCombo(JNIEnv* e, jobject,
    jlong ptr, jobjectArray jRegionPrompts, jstring jNegPrompt,
    jobjectArray jReferenceImagePaths,
    jbyteArray jPoseHintRgb, jbyteArray jDepthHintRgb, jint controlSize,
    jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut,
    jfloat jPoseScale, jfloat jDepthScale, jfloat jIpDecayFloor, jfloat jIpDecayStartTimestep,
    jobject cb) {

    auto *handle = reinterpret_cast<SdTripleComboHandle *>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgTripleCombo: chua init"); return JNI_FALSE; }

    jsize numRegions = jRegionPrompts ? e->GetArrayLength(jRegionPrompts) : 0;
    jsize numImages = jReferenceImagePaths ? e->GetArrayLength(jReferenceImagePaths) : 0;
    if (numRegions < 2 || numRegions != numImages) {
        LOGE("sdTxt2ImgTripleCombo: can >=2 vung VA so anh tham chieu phai khop so prompt (prompt=%d, anh=%d)",
             (int)numRegions, (int)numImages);
        return JNI_FALSE;
    }

    // Mở 1 phiên CLIP TẠM để encode N+1 prompt (N vùng + 1 âm) — ĐÚNG cách
    // regional_prompting.cpp::sdTxt2ImgRegional đã làm, copy nguyên (không
    // gọi chéo file, xem quy ước đầu file).
    MNN::Interpreter *clipInterp = createMnnInterpreterMmap(handle->clipPath.c_str());
    if (!clipInterp) { LOGE("Khong mo duoc clip_v2.mnn"); return JNI_FALSE; }
    MnnSessionOptions clipOpts;
    MNN::Session *clipSession = createMnnSession(clipInterp, clipOpts);
    if (!clipSession) { delete clipInterp; LOGE("Khong tao duoc clip session"); return JNI_FALSE; }
    auto clipInput = clipInterp->getSessionInput(clipSession, "input_embedding");
    clipInterp->resizeTensor(clipInput, {1, 77, text_embedding_size});
    clipInterp->resizeSession(clipSession);
    clipInterp->releaseModel();

    std::vector<float> uncondEmbed = tcEncodeOnePrompt(
        *handle->textEncoder, clipInterp, clipSession, text_embedding_size, j2s_tc(e, jNegPrompt));

    std::vector<float> regionEmbeds;
    regionEmbeds.reserve((size_t)numRegions * 77 * text_embedding_size);
    for (jsize i = 0; i < numRegions; i++) {
        auto jp = (jstring)e->GetObjectArrayElement(jRegionPrompts, i);
        std::vector<float> emb = tcEncodeOnePrompt(
            *handle->textEncoder, clipInterp, clipSession, text_embedding_size, j2s_tc(e, jp));
        e->DeleteLocalRef(jp);
        regionEmbeds.insert(regionEmbeds.end(), emb.begin(), emb.end());
    }
    clipInterp->releaseSession(clipSession);
    delete clipInterp;

    // Encode N ảnh tham chiếu qua ip_image_encoder.mnn — ĐỌC shape THẬT
    // của nhân vật đầu tiên (bỏ chiều batch=1 gốc) làm chuẩn cho mọi
    // người còn lại (giả định hợp lý: cùng 1 model encoder, mọi ảnh input
    // ra shape giống hệt nhau) — nếu người sau ra shape KHÁC (không nên
    // xảy ra, nhưng phòng hờ), CẮT/ĐỆM 0 cho khớp thay vì crash.
    std::vector<float> regionIpEmbeds;
    std::vector<int> perCharShape;  // shape 1 người, ĐÃ bỏ chiều batch=1 đầu
    size_t perCharCount = 0;
    for (jsize i = 0; i < numImages; i++) {
        auto jp = (jstring)e->GetObjectArrayElement(jReferenceImagePaths, i);
        std::string path = j2s_tc(e, jp);
        e->DeleteLocalRef(jp);
        std::vector<float> embed; std::vector<int> shape;
        if (!handle->ipEncoder->encode(path, embed, shape)) {
            LOGE("sdTxt2ImgTripleCombo: encode anh tham chieu #%d that bai (%s)", (int)i, path.c_str());
            return JNI_FALSE;
        }
        if (i == 0) {
            perCharShape = (shape.size() > 1 && shape[0] == 1)
                ? std::vector<int>(shape.begin() + 1, shape.end()) : shape;
            perCharCount = embed.size();
            regionIpEmbeds.reserve((size_t)numImages * perCharCount);
        }
        size_t n = std::min(embed.size(), perCharCount);
        regionIpEmbeds.insert(regionIpEmbeds.end(), embed.begin(), embed.begin() + (long)n);
        if (n < perCharCount) regionIpEmbeds.insert(regionIpEmbeds.end(), perCharCount - n, 0.f);
    }

    std::vector<uint8_t> poseHint, depthHint;
    if (jPoseHintRgb) {
        jsize n = e->GetArrayLength(jPoseHintRgb);
        poseHint.resize(n);
        jbyte *buf = e->GetByteArrayElements(jPoseHintRgb, nullptr);
        memcpy(poseHint.data(), buf, n);
        e->ReleaseByteArrayElements(jPoseHintRgb, buf, JNI_ABORT);
    }
    if (jDepthHintRgb) {
        jsize n = e->GetArrayLength(jDepthHintRgb);
        depthHint.resize(n);
        jbyte *buf = e->GetByteArrayElements(jDepthHintRgb, nullptr);
        memcpy(depthHint.data(), buf, n);
        e->ReleaseByteArrayElements(jDepthHintRgb, buf, JNI_ABORT);
    }

    handle->pipeline->setConditioning(uncondEmbed, regionEmbeds, regionIpEmbeds, perCharShape,
                                       poseHint, depthHint, controlSize,
                                       (float)jPoseScale, (float)jDepthScale,
                                       (float)jIpDecayFloor, (float)jIpDecayStartTimestep);

    GenerationRequest req;
    req.prompt = ""; req.negative_prompt = "";
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = handle->useOpenCL; req.use_npu = handle->useNpu; req.img2img = false;

    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    auto progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_tc(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char *>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
    } catch (const std::exception &ex) {
        LOGE("generate() (triple combo) loi: %s", ex.what());
    }
    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdFreeTripleCombo(JNIEnv *, jobject, jlong ptr) {
    delete reinterpret_cast<SdTripleComboHandle *>(ptr);
}

/* ═══════════════════════════════════════════════════════════════════════
 * GIỚI HẠN THẬT (mục 151 TECHNICAL_STATUS.md — đọc trước khi tin đây "xong"):
 *
 * 1. CHƯA build-test — như mọi phần khác của dự án (mục 0). File PHỨC TẠP
 *    NHẤT được viết trong 1 lượt của dự án (kết hợp 2 pipeline có sẵn) —
 *    rủi ro lỗi tinh vi (sai thứ tự tensor, sai giả định shape) CAO HƠN
 *    các file nhỏ khác, dù đã cố gắng bám sát pattern đã xác nhận đúng ở
 *    2 file nguồn (regional_prompting.cpp/ip_adapter.cpp) từng dòng một.
 * 2. `encodePNG`/`createMnnInterpreterMmap`/`createMnnSession`/`GenerationResult`
 *    — dùng qua include gián tiếp (Pipeline.hpp/MnnUtils.hpp) giống hệt 2
 *    file kia, CHƯA verify lại bằng linker thật (không có NDK trong sandbox).
 * 3. `region_ip_embeds` giả định MỌI nhân vật cho ra shape output GIỐNG
 *    NHAU từ ip_image_encoder.mnn (hợp lý — cùng 1 model, cùng input size
 *    224x224 — nhưng CHƯA kiểm chứng bằng chạy thật).
 * 4. Model .mnn cần có TRƯỚC (`unet_triple_combo_{N}region.mnn`,
 *    export từ tools/export_ipa_controlnet_triple_combo_unet.py rồi
 *    `mnnconvert` — chưa chạy thử) — file .cpp này chỉ là code GỌI model,
 *    không tạo ra model.
 * ═══════════════════════════════════════════════════════════════════════ */
