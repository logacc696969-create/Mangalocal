// regional_prompting_sdxl.cpp — mục 179 TECHNICAL_STATUS.md (SDXL Phase
// 2d). Bản SDXL tương đương regional_prompting.cpp (SD1.5, mục 56/69) —
// ĐỌC COMMENT ĐẦU FILE ĐÓ TRƯỚC: model regional có input HOÀN TOÀN KHÁC
// tên/shape base ("uncond_encoder_hidden_states"/"region_encoder_hidden_
// states" thay vì "encoder_hidden_states") — PHẢI override THẲNG
// beginDenoise()/runUnetStep(), KHÔNG dùng hook onBeforeUnetRun() nhẹ (đã
// thêm ở PipelineSdxlCpu.hpp cho ip_adapter_sdxl.cpp, KHÔNG áp dụng được
// ở đây vì input hoàn toàn khác cấu trúc, không phải "thêm optional trên
// nền cũ").
//
// KHÁC BẢN SD1.5: thêm "uncond_text_embeds"/"region_text_embeds"/
// "time_ids" (bắt buộc cho ControlNet+UNet SDXL, xem tools/
// export_ipa_controlnet_regional_unet_sdxl.py điểm "PHẦN THÊM CHO SDXL").
// Không cross-include ip_adapter_sdxl.cpp/regional_prompting.cpp (đúng quy
// ước "không phụ thuộc chéo .cpp" toàn dự án) — controlHintRgb nhận THẲNG
// từ Kotlin (renderSkeletonCanvas() có sẵn, mục 69).

#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <memory>
#include <fstream>
#include <cmath>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

#include "sd_engine/Config.hpp"
#include "sd_engine/MnnUtils.hpp"
#include "sd_engine/PipelineSdxlCpu.hpp"

#define TAG "MangaLocal_RegionalSDXL"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::string j2s_rpx(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c);
    e->ReleaseStringUTFChars(js, c);
    return s;
}

// PipelineSdxlCpuRegional — kế thừa CLIP-L/CLIP-bigG/VAE encode/decode
// NGUYÊN VẸN từ PipelineSdxlCpu (không đổi gì ở đó) — CHỈ UNet + cách gọi
// nó khác hẳn (override thẳng, mirror ĐÚNG PipelineSd15CpuRegional).
class PipelineSdxlCpuRegional : public PipelineSdxlCpu {
public:
    PipelineSdxlCpuRegional(TextEncoder& te, const std::string& dir,
        const std::string& clipL, const std::string& clipG, const std::string& unetRegional,
        const std::string& vaeDec, const std::string& vaeEnc, int numRegions)
        : PipelineSdxlCpu(te, dir, clipL, clipG, unetRegional, vaeDec, vaeEnc),
          numRegions_(numRegions) {}

    // uncondEmbed/regionEmbeds: 77*2048-dim/vùng (nối CLIP-L+CLIP-bigG, xem
    // encodeOnePromptXL() bên dưới). uncondPooled/regionPooled: 1280-dim/
    // vùng. controlHintRgb: canvas RGB pose ĐÃ RENDER SẴN từ Kotlin.
    // controlSize PHẢI khớp --image_size lúc export model này.
    void setConditioning(const std::vector<float>& uncondEmbed,
                          const std::vector<float>& regionEmbeds,
                          const std::vector<float>& uncondPooled,
                          const std::vector<float>& regionPooled,
                          const std::vector<uint8_t>& controlHintRgb, int controlSize) {
        uncondEmbed_ = uncondEmbed; regionEmbeds_ = regionEmbeds;
        uncondPooled_ = uncondPooled; regionPooled_ = regionPooled;
        controlHintRgb_ = controlHintRgb; controlSize_ = controlSize;
        hasConditioning_ = true;
    }

protected:
    void beginDenoise(const GenerationRequest& req) override {
        unet_interpreter_ = createMnnInterpreterMmap(unet_path_.c_str());
        if (!unet_interpreter_) throw std::runtime_error("Failed to create MNN UNET (regional SDXL) interpreter!");

        unet_session_ = createMnnSession(unet_interpreter_, sessionOptions(req, "unet_regional_sdxl_cache"));
        if (!unet_session_) throw std::runtime_error("Failed to create MNN UNET (regional SDXL) session!");

        auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
        auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
        auto uncondIn = unet_interpreter_->getSessionInput(unet_session_, "uncond_encoder_hidden_states");
        auto regionIn = unet_interpreter_->getSessionInput(unet_session_, "region_encoder_hidden_states");
        auto uncondTextEmb = unet_interpreter_->getSessionInput(unet_session_, "uncond_text_embeds");
        auto regionTextEmb = unet_interpreter_->getSessionInput(unet_session_, "region_text_embeds");
        auto timeIds = unet_interpreter_->getSessionInput(unet_session_, "time_ids");
        auto hintIn = unet_interpreter_->getSessionInput(unet_session_, "control_hint");
        if (!samp || !ts || !uncondIn || !regionIn || !uncondTextEmb || !regionTextEmb || !timeIds || !hintIn) {
            throw std::runtime_error(
                "Model unet_regional_controlnet_sdxl_*.mnn thieu 1 trong cac input bat buoc "
                "(sample/timestep/uncond_encoder_hidden_states/region_encoder_hidden_states/"
                "uncond_text_embeds/region_text_embeds/time_ids/control_hint) - co dung dung "
                "file model regional SDXL khong?");
        }

        unet_interpreter_->resizeTensor(samp, {2, 4, req.height / 8, req.width / 8});
        unet_interpreter_->resizeTensor(ts, {1});
        unet_interpreter_->resizeTensor(uncondIn, {1, 77, text_embedding_size + text_embedding_size_2});
        unet_interpreter_->resizeTensor(regionIn, {numRegions_, 77, text_embedding_size + text_embedding_size_2});
        unet_interpreter_->resizeTensor(uncondTextEmb, {1, text_embedding_size_2});
        unet_interpreter_->resizeTensor(regionTextEmb, {numRegions_, text_embedding_size_2});
        unet_interpreter_->resizeTensor(timeIds, {2, 6});
        unet_interpreter_->resizeTensor(hintIn, {2, 3, req.height, req.width});
        unet_interpreter_->resizeSession(unet_session_);
        if (req.use_opencl) unet_interpreter_->updateCacheFile(unet_session_);
        unet_interpreter_->releaseModel();
    }

    void runUnetStep(const GenerationRequest& req, const float* latents_batch2,
                     float timestep_f, bool /*skip_uncond*/, Conditioning& /*cond*/,
                     float* out_batch2) override {
        if (!hasConditioning_) LOGE("runUnetStep (regional SDXL) goi truoc setConditioning() - anh se sai/rac");
        const int timestep = static_cast<int>(timestep_f);
        auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
        auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
        auto uncondIn = unet_interpreter_->getSessionInput(unet_session_, "uncond_encoder_hidden_states");
        auto regionIn = unet_interpreter_->getSessionInput(unet_session_, "region_encoder_hidden_states");
        auto uncondTextEmb = unet_interpreter_->getSessionInput(unet_session_, "uncond_text_embeds");
        auto regionTextEmb = unet_interpreter_->getSessionInput(unet_session_, "region_text_embeds");
        auto timeIds = unet_interpreter_->getSessionInput(unet_session_, "time_ids");
        auto hintIn = unet_interpreter_->getSessionInput(unet_session_, "control_hint");

        size_t batch2_count = (size_t)2 * 4 * (req.height / 8) * (req.width / 8);
        MNN::Tensor samp_h(samp, MNN::Tensor::CAFFE);
        MNN::Tensor ts_h(ts, MNN::Tensor::CAFFE);
        MNN::Tensor uncond_h(uncondIn, MNN::Tensor::CAFFE);
        MNN::Tensor region_h(regionIn, MNN::Tensor::CAFFE);
        MNN::Tensor uncondTextEmb_h(uncondTextEmb, MNN::Tensor::CAFFE);
        MNN::Tensor regionTextEmb_h(regionTextEmb, MNN::Tensor::CAFFE);
        MNN::Tensor timeIds_h(timeIds, MNN::Tensor::CAFFE);
        MNN::Tensor hint_h(hintIn, MNN::Tensor::CAFFE);

        memcpy(samp_h.host<float>(), latents_batch2, batch2_count * sizeof(float));
        memcpy(ts_h.host<int>(), &timestep, sizeof(int));
        memcpy(uncond_h.host<float>(), uncondEmbed_.data(),
               std::min(uncondEmbed_.size(), (size_t)uncond_h.elementSize()) * sizeof(float));
        memcpy(region_h.host<float>(), regionEmbeds_.data(),
               std::min(regionEmbeds_.size(), (size_t)region_h.elementSize()) * sizeof(float));
        memcpy(uncondTextEmb_h.host<float>(), uncondPooled_.data(),
               std::min(uncondPooled_.size(), (size_t)uncondTextEmb_h.elementSize()) * sizeof(float));
        memcpy(regionTextEmb_h.host<float>(), regionPooled_.data(),
               std::min(regionPooled_.size(), (size_t)regionTextEmb_h.elementSize()) * sizeof(float));
        // time_ids — GIỐNG NHAU cho uncond/cond VÀ cho mọi vùng (điều kiện
        // toàn cục về kích thước ảnh, không phụ thuộc nội dung prompt) —
        // mirror đúng cond.time_ids ở PipelineSdxlCpu::runUnetStep() base.
        for (int b = 0; b < 2; b++) {
            timeIds_h.host<float>()[b*6+0] = (float)req.width;
            timeIds_h.host<float>()[b*6+1] = (float)req.height;
            timeIds_h.host<float>()[b*6+2] = 0.f;
            timeIds_h.host<float>()[b*6+3] = 0.f;
            timeIds_h.host<float>()[b*6+4] = (float)req.width;
            timeIds_h.host<float>()[b*6+5] = (float)req.height;
        }
        int size = controlSize_;
        size_t plane = (size_t)3 * size * size;
        for (int b = 0; b < 2; b++) {
            for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
                const uint8_t* p = controlHintRgb_.data() + ((size_t)y * size + x) * 3;
                for (int ch = 0; ch < 3; ch++)
                    hint_h.host<float>()[b * plane + (size_t)ch * size * size + y * size + x] = p[ch] / 255.f;
            }
        }

        samp->copyFromHostTensor(&samp_h);
        ts->copyFromHostTensor(&ts_h);
        uncondIn->copyFromHostTensor(&uncond_h);
        regionIn->copyFromHostTensor(&region_h);
        uncondTextEmb->copyFromHostTensor(&uncondTextEmb_h);
        regionTextEmb->copyFromHostTensor(&regionTextEmb_h);
        timeIds->copyFromHostTensor(&timeIds_h);
        hintIn->copyFromHostTensor(&hint_h);

        unet_interpreter_->runSession(unet_session_);

        auto output = unet_interpreter_->getSessionOutput(unet_session_, "out_sample");
        MNN::Tensor out_h(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&out_h);
        memcpy(out_batch2, out_h.host<float>(), batch2_count * sizeof(float));
    }

private:
    int numRegions_;
    bool hasConditioning_ = false;
    std::vector<float> uncondEmbed_, regionEmbeds_, uncondPooled_, regionPooled_;
    std::vector<uint8_t> controlHintRgb_;
    int controlSize_ = 1024;
};

// mục 179 — encode 1 prompt qua CẢ CLIP-L + CLIP-bigG rồi nối, TRẢ VỀ CẢ
// hidden (77*2048) LẪN pooled (1280) — mirror ĐÚNG logic run_side() trong
// PipelineSdxlCpu::encodeText() (đã đọc trước khi viết, xem file đó), viết
// lại 1 bản NGẮN dùng riêng cho N-prompt-độc-lập (giống lý do
// encodeOnePrompt() SD1.5 viết riêng thay vì tái dùng encodeText() protected).
static void encodeOnePromptXL(TextEncoder& textEncoder, const std::string& clipLPath, const std::string& clipGPath,
                               const std::string& prompt, std::vector<float>& outHidden, std::vector<float>& outPooled) {
    ProcessedPromptPair pair = textEncoder.processPromptPair(prompt, "");

    MNN::Interpreter* interpL = createMnnInterpreterMmap(clipLPath.c_str());
    MnnSessionOptions optsL;
    MNN::Session* sessL = createMnnSession(interpL, optsL);
    auto inputL = interpL->getSessionInput(sessL, "input_embedding");
    interpL->resizeTensor(inputL, {1, 77, text_embedding_size});
    interpL->resizeSession(sessL);
    interpL->releaseModel();

    MNN::Interpreter* interpG = createMnnInterpreterMmap(clipGPath.c_str());
    MnnSessionOptions optsG;
    MNN::Session* sessG = createMnnSession(interpG, optsG);
    auto inputG = interpG->getSessionInput(sessG, "input_embedding");
    auto inputG_ids = interpG->getSessionInput(sessG, "input_ids_2");
    interpG->resizeTensor(inputG, {1, 77, text_embedding_size_2});
    interpG->resizeTensor(inputG_ids, {1, 77});
    interpG->resizeSession(sessG);
    interpG->releaseModel();

    // pair.ids/positive_embeddings* là CẶP [negative, positive] — dùng vế
    // "positive" (index 77:154 cho ids, positive_embeddings* cho embedding)
    // vì processPromptPair(prompt, "") đặt PROMPT của mình vào vế positive.
    memcpy(inputL->host<float>(), pair.positive_embeddings.data(), 77 * text_embedding_size * sizeof(float));
    interpL->runSession(sessL);
    auto outL = interpL->getSessionOutput(sessL, "last_hidden_state");
    MNN::Tensor outL_h(outL, MNN::Tensor::CAFFE);
    outL->copyToHostTensor(&outL_h);

    memcpy(inputG->host<float>(), pair.positive_embeddings_2.data(), 77 * text_embedding_size_2 * sizeof(float));
    MNN::Tensor idsG_h(inputG_ids, MNN::Tensor::CAFFE);
    for (int i = 0; i < 77; i++) idsG_h.host<int>()[i] = pair.ids[77 + i];
    inputG_ids->copyFromHostTensor(&idsG_h);
    interpG->runSession(sessG);
    auto outG_hidden = interpG->getSessionOutput(sessG, "last_hidden_state");
    auto outG_pooled = interpG->getSessionOutput(sessG, "pooled_output");
    MNN::Tensor outG_hidden_h(outG_hidden, MNN::Tensor::CAFFE);
    MNN::Tensor outG_pooled_h(outG_pooled, MNN::Tensor::CAFFE);
    outG_hidden->copyToHostTensor(&outG_hidden_h);
    outG_pooled->copyToHostTensor(&outG_pooled_h);

    const int dim1 = text_embedding_size, dim2 = text_embedding_size_2, dimTotal = dim1 + dim2;
    outHidden.assign((size_t)77 * dimTotal, 0.f);
    for (int t = 0; t < 77; t++) {
        memcpy(outHidden.data() + (size_t)t * dimTotal, outL_h.host<float>() + (size_t)t * dim1, dim1 * sizeof(float));
        memcpy(outHidden.data() + (size_t)t * dimTotal + dim1, outG_hidden_h.host<float>() + (size_t)t * dim2, dim2 * sizeof(float));
    }
    outPooled.assign(outG_pooled_h.host<float>(), outG_pooled_h.host<float>() + text_embedding_size_2);

    interpL->releaseSession(sessL); delete interpL;
    interpG->releaseSession(sessG); delete interpG;
}

struct SdRegionalSdxlHandle {
    std::unique_ptr<TextEncoder> textEncoder;
    std::unique_ptr<PipelineSdxlCpuRegional> pipeline;
    std::string clipLPath, clipGPath;
    bool useOpenCL = false;
    bool useNpu = false;
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdInitRegionalSdxl(JNIEnv* e, jobject,
    jstring jModelDir, jstring jClipL, jstring jClipG, jstring jUnetRegional,
    jstring jVaeDec, jstring jVaeEnc, jstring jTokenizer, jstring jEmbeddingsDir,
    jint jNumRegions, jboolean jUseOpenCL, jboolean jUseNpu) {

    std::string dir = j2s_rpx(e, jModelDir);
    try {
        auto handle = std::make_unique<SdRegionalSdxlHandle>();
        handle->useOpenCL = jUseOpenCL;
        handle->useNpu = jUseNpu;
        handle->textEncoder = std::make_unique<TextEncoder>(/*sdxl=*/true, /*anima=*/false);
        handle->textEncoder->loadTokenizer(j2s_rpx(e, jTokenizer));
        handle->textEncoder->loadEmbeddingTables(dir);
        std::string embeddingsDir = j2s_rpx(e, jEmbeddingsDir);
        if (!embeddingsDir.empty()) handle->textEncoder->loadTextualInversions(embeddingsDir);

        handle->clipLPath = j2s_rpx(e, jClipL);
        handle->clipGPath = j2s_rpx(e, jClipG);
        handle->pipeline = std::make_unique<PipelineSdxlCpuRegional>(
            *handle->textEncoder, dir, handle->clipLPath, handle->clipGPath, j2s_rpx(e, jUnetRegional),
            j2s_rpx(e, jVaeDec), j2s_rpx(e, jVaeEnc), (int)jNumRegions);
        if (!handle->pipeline->initialize()) { LOGE("PipelineSdxlCpuRegional initialize() fail"); return 0; }

        return reinterpret_cast<jlong>(handle.release());
    } catch (const std::exception& ex) {
        LOGE("sdInitRegionalSdxl loi: %s", ex.what());
        return 0;
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgRegionalSdxl(JNIEnv* e, jobject,
    jlong ptr, jobjectArray jRegionPrompts, jstring jNegPrompt,
    jbyteArray jControlHintRgb, jint controlSize,
    jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut, jobject cb) {

    auto* handle = reinterpret_cast<SdRegionalSdxlHandle*>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgRegionalSdxl: chua init"); return JNI_FALSE; }

    jsize numRegions = jRegionPrompts ? e->GetArrayLength(jRegionPrompts) : 0;
    if (numRegions < 2) { LOGE("sdTxt2ImgRegionalSdxl: can it nhat 2 vung prompt"); return JNI_FALSE; }

    std::vector<float> uncondHidden, uncondPooled;
    encodeOnePromptXL(*handle->textEncoder, handle->clipLPath, handle->clipGPath,
                       j2s_rpx(e, jNegPrompt), uncondHidden, uncondPooled);

    std::vector<float> regionHidden, regionPooled;
    regionHidden.reserve((size_t)numRegions * 77 * (text_embedding_size + text_embedding_size_2));
    regionPooled.reserve((size_t)numRegions * text_embedding_size_2);
    for (jsize i = 0; i < numRegions; i++) {
        auto jp = (jstring)e->GetObjectArrayElement(jRegionPrompts, i);
        std::vector<float> h, p;
        encodeOnePromptXL(*handle->textEncoder, handle->clipLPath, handle->clipGPath, j2s_rpx(e, jp), h, p);
        e->DeleteLocalRef(jp);
        regionHidden.insert(regionHidden.end(), h.begin(), h.end());
        regionPooled.insert(regionPooled.end(), p.begin(), p.end());
    }

    std::vector<uint8_t> controlHint;
    if (jControlHintRgb) {
        jsize n = e->GetArrayLength(jControlHintRgb);
        controlHint.resize(n);
        jbyte* buf = e->GetByteArrayElements(jControlHintRgb, nullptr);
        memcpy(controlHint.data(), buf, n);
        e->ReleaseByteArrayElements(jControlHintRgb, buf, JNI_ABORT);
    }

    handle->pipeline->setConditioning(uncondHidden, regionHidden, uncondPooled, regionPooled, controlHint, controlSize);

    GenerationRequest req;
    req.prompt = ""; req.negative_prompt = "";
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = handle->useOpenCL; req.use_npu = handle->useNpu; req.img2img = false;

    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    auto progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_rpx(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char*>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
    } catch (const std::exception& ex) {
        LOGE("generate() (regional SDXL) loi: %s", ex.what());
    }
    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdFreeRegionalSdxl(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<SdRegionalSdxlHandle*>(ptr);
}
