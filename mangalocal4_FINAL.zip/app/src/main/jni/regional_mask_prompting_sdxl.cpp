// regional_mask_prompting_sdxl.cpp — mục 180 TECHNICAL_STATUS.md (SDXL
// Phase 2e). Bản SDXL tương đương regional_mask_prompting.cpp (SD1.5, mục
// 172) — COPY CẤU TRÚC từ regional_prompting_sdxl.cpp (bản cột SDXL, mục
// 179, ĐỌC COMMENT ĐẦU FILE ĐÓ TRƯỚC) — CHỈ khác: thêm 2 input model
// ("background_encoder_hidden_states"/"background_text_embeds",
// "region_masks") và setConditioning() nhận thêm mask thật + prompt nền,
// giống hệt cách regional_mask_prompting.cpp (SD1.5) khác regional_
// prompting.cpp (SD1.5). region_masks nhận THẲNG buffer đã dựng sẵn từ
// Kotlin (MangaPipeline.buildCharacterBodyMaskFile(), có SAM từ mục 168) —
// không tự vẽ ở C++, cùng lựa chọn có chủ đích như bản SD1.5.

#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <memory>
#include <fstream>
#include <cmath>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

#include "sd_engine/Config.hpp"
#include "sd_engine/MnnUtils.hpp"
#include "sd_engine/PipelineSdxlCpu.hpp"

#define TAG "MangaLocal_RegionalMaskSDXL"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::string j2s_rmpx(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c);
    e->ReleaseStringUTFChars(js, c);
    return s;
}

class PipelineSdxlCpuRegionalMask : public PipelineSdxlCpu {
public:
    PipelineSdxlCpuRegionalMask(TextEncoder& te, const std::string& dir,
        const std::string& clipL, const std::string& clipG, const std::string& unetRegionalMask,
        const std::string& vaeDec, const std::string& vaeEnc, int numRegions)
        : PipelineSdxlCpu(te, dir, clipL, clipG, unetRegionalMask, vaeDec, vaeEnc),
          numRegions_(numRegions) {}

    void setConditioning(const std::vector<float>& uncondEmbed, const std::vector<float>& backgroundEmbed,
                          const std::vector<float>& regionEmbeds, const std::vector<uint8_t>& regionMasks,
                          const std::vector<float>& uncondPooled, const std::vector<float>& backgroundPooled,
                          const std::vector<uint8_t>& controlHintRgb, int controlSize) {
        uncondEmbed_ = uncondEmbed; backgroundEmbed_ = backgroundEmbed;
        regionEmbeds_ = regionEmbeds; regionMasks_ = regionMasks;
        uncondPooled_ = uncondPooled; backgroundPooled_ = backgroundPooled;
        controlHintRgb_ = controlHintRgb; controlSize_ = controlSize;
        hasConditioning_ = true;
    }

protected:
    void beginDenoise(const GenerationRequest& req) override {
        unet_interpreter_ = createMnnInterpreterMmap(unet_path_.c_str());
        if (!unet_interpreter_) throw std::runtime_error("Failed to create MNN UNET (regional-mask SDXL) interpreter!");

        unet_session_ = createMnnSession(unet_interpreter_, sessionOptions(req, "unet_regional_mask_sdxl_cache"));
        if (!unet_session_) throw std::runtime_error("Failed to create MNN UNET (regional-mask SDXL) session!");

        auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
        auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
        auto uncondIn = unet_interpreter_->getSessionInput(unet_session_, "uncond_encoder_hidden_states");
        auto bgIn = unet_interpreter_->getSessionInput(unet_session_, "background_encoder_hidden_states");
        auto regionIn = unet_interpreter_->getSessionInput(unet_session_, "region_encoder_hidden_states");
        auto maskIn = unet_interpreter_->getSessionInput(unet_session_, "region_masks");
        auto uncondTextEmb = unet_interpreter_->getSessionInput(unet_session_, "uncond_text_embeds");
        auto bgTextEmb = unet_interpreter_->getSessionInput(unet_session_, "background_text_embeds");
        auto timeIds = unet_interpreter_->getSessionInput(unet_session_, "time_ids");
        auto hintIn = unet_interpreter_->getSessionInput(unet_session_, "control_hint");
        if (!samp || !ts || !uncondIn || !bgIn || !regionIn || !maskIn || !uncondTextEmb || !bgTextEmb || !timeIds || !hintIn) {
            throw std::runtime_error(
                "Model unet_regional_mask_controlnet_sdxl_*.mnn thieu 1 trong cac input bat buoc - "
                "co dung dung file model regional-mask SDXL khong?");
        }

        unet_interpreter_->resizeTensor(samp, {2, 4, req.height / 8, req.width / 8});
        unet_interpreter_->resizeTensor(ts, {1});
        unet_interpreter_->resizeTensor(uncondIn, {1, 77, text_embedding_size + text_embedding_size_2});
        unet_interpreter_->resizeTensor(bgIn, {1, 77, text_embedding_size + text_embedding_size_2});
        unet_interpreter_->resizeTensor(regionIn, {numRegions_, 77, text_embedding_size + text_embedding_size_2});
        unet_interpreter_->resizeTensor(maskIn, {numRegions_, req.height, req.width});
        unet_interpreter_->resizeTensor(uncondTextEmb, {1, text_embedding_size_2});
        unet_interpreter_->resizeTensor(bgTextEmb, {1, text_embedding_size_2});
        unet_interpreter_->resizeTensor(timeIds, {2, 6});
        unet_interpreter_->resizeTensor(hintIn, {2, 3, req.height, req.width});
        unet_interpreter_->resizeSession(unet_session_);
        if (req.use_opencl) unet_interpreter_->updateCacheFile(unet_session_);
        unet_interpreter_->releaseModel();
    }

    void runUnetStep(const GenerationRequest& req, const float* latents_batch2,
                     float timestep_f, bool /*skip_uncond*/, Conditioning& /*cond*/,
                     float* out_batch2) override {
        if (!hasConditioning_) LOGE("runUnetStep (regional-mask SDXL) goi truoc setConditioning() - anh se sai/rac");
        const int timestep = static_cast<int>(timestep_f);
        auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
        auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
        auto uncondIn = unet_interpreter_->getSessionInput(unet_session_, "uncond_encoder_hidden_states");
        auto bgIn = unet_interpreter_->getSessionInput(unet_session_, "background_encoder_hidden_states");
        auto regionIn = unet_interpreter_->getSessionInput(unet_session_, "region_encoder_hidden_states");
        auto maskIn = unet_interpreter_->getSessionInput(unet_session_, "region_masks");
        auto uncondTextEmb = unet_interpreter_->getSessionInput(unet_session_, "uncond_text_embeds");
        auto bgTextEmb = unet_interpreter_->getSessionInput(unet_session_, "background_text_embeds");
        auto timeIds = unet_interpreter_->getSessionInput(unet_session_, "time_ids");
        auto hintIn = unet_interpreter_->getSessionInput(unet_session_, "control_hint");

        size_t batch2_count = (size_t)2 * 4 * (req.height / 8) * (req.width / 8);
        MNN::Tensor samp_h(samp, MNN::Tensor::CAFFE);
        MNN::Tensor ts_h(ts, MNN::Tensor::CAFFE);
        MNN::Tensor uncond_h(uncondIn, MNN::Tensor::CAFFE);
        MNN::Tensor bg_h(bgIn, MNN::Tensor::CAFFE);
        MNN::Tensor region_h(regionIn, MNN::Tensor::CAFFE);
        MNN::Tensor mask_h(maskIn, MNN::Tensor::CAFFE);
        MNN::Tensor uncondTextEmb_h(uncondTextEmb, MNN::Tensor::CAFFE);
        MNN::Tensor bgTextEmb_h(bgTextEmb, MNN::Tensor::CAFFE);
        MNN::Tensor timeIds_h(timeIds, MNN::Tensor::CAFFE);
        MNN::Tensor hint_h(hintIn, MNN::Tensor::CAFFE);

        memcpy(samp_h.host<float>(), latents_batch2, batch2_count * sizeof(float));
        memcpy(ts_h.host<int>(), &timestep, sizeof(int));
        memcpy(uncond_h.host<float>(), uncondEmbed_.data(),
               std::min(uncondEmbed_.size(), (size_t)uncond_h.elementSize()) * sizeof(float));
        memcpy(bg_h.host<float>(), backgroundEmbed_.data(),
               std::min(backgroundEmbed_.size(), (size_t)bg_h.elementSize()) * sizeof(float));
        memcpy(region_h.host<float>(), regionEmbeds_.data(),
               std::min(regionEmbeds_.size(), (size_t)region_h.elementSize()) * sizeof(float));
        memcpy(uncondTextEmb_h.host<float>(), uncondPooled_.data(),
               std::min(uncondPooled_.size(), (size_t)uncondTextEmb_h.elementSize()) * sizeof(float));
        memcpy(bgTextEmb_h.host<float>(), backgroundPooled_.data(),
               std::min(backgroundPooled_.size(), (size_t)bgTextEmb_h.elementSize()) * sizeof(float));

        size_t mask_elems = std::min(regionMasks_.size(), (size_t)mask_h.elementSize());
        for (size_t i = 0; i < mask_elems; i++) mask_h.host<float>()[i] = regionMasks_[i] / 255.f;

        for (int b = 0; b < 2; b++) {
            timeIds_h.host<float>()[b*6+0] = (float)req.width;
            timeIds_h.host<float>()[b*6+1] = (float)req.height;
            timeIds_h.host<float>()[b*6+2] = 0.f;
            timeIds_h.host<float>()[b*6+3] = 0.f;
            timeIds_h.host<float>()[b*6+4] = (float)req.width;
            timeIds_h.host<float>()[b*6+5] = (float)req.height;
        }
        int size = controlSize_;
        size_t plane = (size_t)3 * size * size;
        for (int b = 0; b < 2; b++) {
            for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
                const uint8_t* p = controlHintRgb_.data() + ((size_t)y * size + x) * 3;
                for (int ch = 0; ch < 3; ch++)
                    hint_h.host<float>()[b * plane + (size_t)ch * size * size + y * size + x] = p[ch] / 255.f;
            }
        }

        samp->copyFromHostTensor(&samp_h);
        ts->copyFromHostTensor(&ts_h);
        uncondIn->copyFromHostTensor(&uncond_h);
        bgIn->copyFromHostTensor(&bg_h);
        regionIn->copyFromHostTensor(&region_h);
        maskIn->copyFromHostTensor(&mask_h);
        uncondTextEmb->copyFromHostTensor(&uncondTextEmb_h);
        bgTextEmb->copyFromHostTensor(&bgTextEmb_h);
        timeIds->copyFromHostTensor(&timeIds_h);
        hintIn->copyFromHostTensor(&hint_h);

        unet_interpreter_->runSession(unet_session_);

        auto output = unet_interpreter_->getSessionOutput(unet_session_, "out_sample");
        MNN::Tensor out_h(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&out_h);
        memcpy(out_batch2, out_h.host<float>(), batch2_count * sizeof(float));
    }

private:
    int numRegions_;
    bool hasConditioning_ = false;
    std::vector<float> uncondEmbed_, backgroundEmbed_, regionEmbeds_, uncondPooled_, backgroundPooled_;
    std::vector<uint8_t> regionMasks_, controlHintRgb_;
    int controlSize_ = 1024;
};

// mirror encodeOnePromptXL() (regional_prompting_sdxl.cpp) — copy riêng ở
// đây vì KHÔNG cross-include (đúng quy ước toàn dự án).
static void encodeOnePromptRMXL(TextEncoder& textEncoder, const std::string& clipLPath, const std::string& clipGPath,
                                 const std::string& prompt, std::vector<float>& outHidden, std::vector<float>& outPooled) {
    ProcessedPromptPair pair = textEncoder.processPromptPair(prompt, "");

    MNN::Interpreter* interpL = createMnnInterpreterMmap(clipLPath.c_str());
    MnnSessionOptions optsL;
    MNN::Session* sessL = createMnnSession(interpL, optsL);
    auto inputL = interpL->getSessionInput(sessL, "input_embedding");
    interpL->resizeTensor(inputL, {1, 77, text_embedding_size});
    interpL->resizeSession(sessL);
    interpL->releaseModel();

    MNN::Interpreter* interpG = createMnnInterpreterMmap(clipGPath.c_str());
    MnnSessionOptions optsG;
    MNN::Session* sessG = createMnnSession(interpG, optsG);
    auto inputG = interpG->getSessionInput(sessG, "input_embedding");
    auto inputG_ids = interpG->getSessionInput(sessG, "input_ids_2");
    interpG->resizeTensor(inputG, {1, 77, text_embedding_size_2});
    interpG->resizeTensor(inputG_ids, {1, 77});
    interpG->resizeSession(sessG);
    interpG->releaseModel();

    memcpy(inputL->host<float>(), pair.positive_embeddings.data(), 77 * text_embedding_size * sizeof(float));
    interpL->runSession(sessL);
    auto outL = interpL->getSessionOutput(sessL, "last_hidden_state");
    MNN::Tensor outL_h(outL, MNN::Tensor::CAFFE);
    outL->copyToHostTensor(&outL_h);

    memcpy(inputG->host<float>(), pair.positive_embeddings_2.data(), 77 * text_embedding_size_2 * sizeof(float));
    MNN::Tensor idsG_h(inputG_ids, MNN::Tensor::CAFFE);
    for (int i = 0; i < 77; i++) idsG_h.host<int>()[i] = pair.ids[77 + i];
    inputG_ids->copyFromHostTensor(&idsG_h);
    interpG->runSession(sessG);
    auto outG_hidden = interpG->getSessionOutput(sessG, "last_hidden_state");
    auto outG_pooled = interpG->getSessionOutput(sessG, "pooled_output");
    MNN::Tensor outG_hidden_h(outG_hidden, MNN::Tensor::CAFFE);
    MNN::Tensor outG_pooled_h(outG_pooled, MNN::Tensor::CAFFE);
    outG_hidden->copyToHostTensor(&outG_hidden_h);
    outG_pooled->copyToHostTensor(&outG_pooled_h);

    const int dim1 = text_embedding_size, dim2 = text_embedding_size_2, dimTotal = dim1 + dim2;
    outHidden.assign((size_t)77 * dimTotal, 0.f);
    for (int t = 0; t < 77; t++) {
        memcpy(outHidden.data() + (size_t)t * dimTotal, outL_h.host<float>() + (size_t)t * dim1, dim1 * sizeof(float));
        memcpy(outHidden.data() + (size_t)t * dimTotal + dim1, outG_hidden_h.host<float>() + (size_t)t * dim2, dim2 * sizeof(float));
    }
    outPooled.assign(outG_pooled_h.host<float>(), outG_pooled_h.host<float>() + text_embedding_size_2);

    interpL->releaseSession(sessL); delete interpL;
    interpG->releaseSession(sessG); delete interpG;
}

struct SdRegionalMaskSdxlHandle {
    std::unique_ptr<TextEncoder> textEncoder;
    std::unique_ptr<PipelineSdxlCpuRegionalMask> pipeline;
    std::string clipLPath, clipGPath;
    bool useOpenCL = false;
    bool useNpu = false;
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdInitRegionalMaskSdxl(JNIEnv* e, jobject,
    jstring jModelDir, jstring jClipL, jstring jClipG, jstring jUnetRegionalMask,
    jstring jVaeDec, jstring jVaeEnc, jstring jTokenizer, jstring jEmbeddingsDir,
    jint jNumRegions, jboolean jUseOpenCL, jboolean jUseNpu) {

    std::string dir = j2s_rmpx(e, jModelDir);
    try {
        auto handle = std::make_unique<SdRegionalMaskSdxlHandle>();
        handle->useOpenCL = jUseOpenCL;
        handle->useNpu = jUseNpu;
        handle->textEncoder = std::make_unique<TextEncoder>(/*sdxl=*/true, /*anima=*/false);
        handle->textEncoder->loadTokenizer(j2s_rmpx(e, jTokenizer));
        handle->textEncoder->loadEmbeddingTables(dir);
        std::string embeddingsDir = j2s_rmpx(e, jEmbeddingsDir);
        if (!embeddingsDir.empty()) handle->textEncoder->loadTextualInversions(embeddingsDir);

        handle->clipLPath = j2s_rmpx(e, jClipL);
        handle->clipGPath = j2s_rmpx(e, jClipG);
        handle->pipeline = std::make_unique<PipelineSdxlCpuRegionalMask>(
            *handle->textEncoder, dir, handle->clipLPath, handle->clipGPath, j2s_rmpx(e, jUnetRegionalMask),
            j2s_rmpx(e, jVaeDec), j2s_rmpx(e, jVaeEnc), (int)jNumRegions);
        if (!handle->pipeline->initialize()) { LOGE("PipelineSdxlCpuRegionalMask initialize() fail"); return 0; }

        return reinterpret_cast<jlong>(handle.release());
    } catch (const std::exception& ex) {
        LOGE("sdInitRegionalMaskSdxl loi: %s", ex.what());
        return 0;
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgRegionalMaskSdxl(JNIEnv* e, jobject,
    jlong ptr, jobjectArray jRegionPrompts, jstring jBackgroundPrompt, jstring jNegPrompt,
    jbyteArray jRegionMasks, jbyteArray jControlHintRgb, jint controlSize,
    jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut, jobject cb) {

    auto* handle = reinterpret_cast<SdRegionalMaskSdxlHandle*>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgRegionalMaskSdxl: chua init"); return JNI_FALSE; }

    jsize numRegions = jRegionPrompts ? e->GetArrayLength(jRegionPrompts) : 0;
    if (numRegions < 2) { LOGE("sdTxt2ImgRegionalMaskSdxl: can it nhat 2 vung"); return JNI_FALSE; }

    std::vector<float> uncondHidden, uncondPooled, bgHidden, bgPooled;
    encodeOnePromptRMXL(*handle->textEncoder, handle->clipLPath, handle->clipGPath,
                         j2s_rmpx(e, jNegPrompt), uncondHidden, uncondPooled);
    encodeOnePromptRMXL(*handle->textEncoder, handle->clipLPath, handle->clipGPath,
                         j2s_rmpx(e, jBackgroundPrompt), bgHidden, bgPooled);

    std::vector<float> regionHidden, regionPooledUnused;
    regionHidden.reserve((size_t)numRegions * 77 * (text_embedding_size + text_embedding_size_2));
    for (jsize i = 0; i < numRegions; i++) {
        auto jp = (jstring)e->GetObjectArrayElement(jRegionPrompts, i);
        std::vector<float> h, p;
        encodeOnePromptRMXL(*handle->textEncoder, handle->clipLPath, handle->clipGPath, j2s_rmpx(e, jp), h, p);
        e->DeleteLocalRef(jp);
        regionHidden.insert(regionHidden.end(), h.begin(), h.end());
        // pooled per-vùng KHÔNG dùng (model chỉ nhận uncond/background pooled,
        // xem forward() Python — added_cond_kwargs dùng background làm đại
        // diện cho vế cond, giống ControlNet) — bỏ qua p ở đây, không phải
        // thiếu sót.
    }

    std::vector<uint8_t> regionMasks;
    if (jRegionMasks) {
        jsize n = e->GetArrayLength(jRegionMasks);
        regionMasks.resize(n);
        jbyte* buf = e->GetByteArrayElements(jRegionMasks, nullptr);
        memcpy(regionMasks.data(), buf, n);
        e->ReleaseByteArrayElements(jRegionMasks, buf, JNI_ABORT);
    }
    size_t expectedMaskBytes = (size_t)numRegions * controlSize * controlSize;
    if (regionMasks.size() != expectedMaskBytes) {
        LOGE("sdTxt2ImgRegionalMaskSdxl: region_masks kich thuoc sai (%zu byte, ky vong %zu) - "
             "Kotlin co dung dung controlSize khong?", regionMasks.size(), expectedMaskBytes);
    }

    std::vector<uint8_t> controlHint;
    if (jControlHintRgb) {
        jsize n = e->GetArrayLength(jControlHintRgb);
        controlHint.resize(n);
        jbyte* buf = e->GetByteArrayElements(jControlHintRgb, nullptr);
        memcpy(controlHint.data(), buf, n);
        e->ReleaseByteArrayElements(jControlHintRgb, buf, JNI_ABORT);
    }

    handle->pipeline->setConditioning(uncondHidden, bgHidden, regionHidden, regionMasks,
                                        uncondPooled, bgPooled, controlHint, controlSize);

    GenerationRequest req;
    req.prompt = ""; req.negative_prompt = "";
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = handle->useOpenCL; req.use_npu = handle->useNpu; req.img2img = false;

    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    auto progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_rmpx(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char*>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
    } catch (const std::exception& ex) {
        LOGE("generate() (regional-mask SDXL) loi: %s", ex.what());
    }
    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdFreeRegionalMaskSdxl(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<SdRegionalMaskSdxlHandle*>(ptr);
}
