// mục 288 TECHNICAL_STATUS.md — phần THUẦN THUẬT TOÁN của MobileSAM click-to-mask (không phụ thuộc MNN/JNI nên test được bằng g++ thường).
//
// Hợp đồng ĐÃ ĐO THẬT trên model xuất bằng tools/export_mobilesam.py (samexporter 0.5.0, MobileSAM mobile_sam.pt, MNN 3.6.1, ảnh bus.jpg):
//  1. Encoder ONNX/MNN nhận ĐÚNG MỘT tensor 3 CHIỀU [cao, rộng, 3] (HWC, float 0..255, RGB) — chuẩn hoá ImageNet + resize + pad nằm TRONG đồ thị
//     (--use-preprocess). KHÔNG phải NCHW 4 chiều [1,3,1024,1024] như bản wrapper cũ (MNN báo "Broad cast error" và trả tensor rỗng).
//  2. Decoder nhận toạ độ click ở HỆ 1024 (cạnh dài = 1024), tức = toạ độ ảnh gốc × (1024 / max(W,H)); và phải có điểm đệm (0,0) nhãn -1
//     (chuẩn SAM khi không có hộp). Bản cũ truyền thẳng toạ độ ảnh gốc => mask rỗng/sai chỗ khi ảnh lớn hơn 1024.
//  3. Đầu ra `masks` (đã co giãn về kích thước gốc TRONG đồ thị) KHÔNG đáng tin: lệch 6,7%–27,9% điểm ảnh so với đáp án PyTorch vì bước cắt/resize
//     bị đóng cứng theo kích thước giả lập 1500x2250 lúc xuất. Dùng `low_res_masks` (1x1x256x256, khớp PyTorch sai số < 0,02) rồi hậu xử lý Ở ĐÂY:
//     bilinear 256->1024, cắt vùng chứa ảnh [0:newH, 0:newW], bilinear về HxW gốc, ngưỡng > 0. (Khớp PyTorch SamOnnxModel: lệch 0,0000–0,0002%.)
#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace mobilesam {

constexpr int kInput = 1024;   // chuẩn SAM — cố định theo kiến trúc
constexpr int kLow = 256;      // low_res_masks 256x256 (= kInput/4)

struct Letterbox {
  int newW = 0, newH = 0;  // kích thước vùng chứa ảnh trong khung 1024x1024 (phần còn lại là pad đen)
  float scale = 1.f;       // = kInput / max(W,H); toạ độ gốc * scale = toạ độ trong khung 1024
};

/** RGB uint8 (W*H*3) -> HWC float 0..255 kích thước kInput x kInput x 3, ảnh dán góc trên-trái, phần dư = 0 (đen). Lấy mẫu láng giềng gần nhất. */
inline bool letterboxHWC(const unsigned char *rgb, int W, int H, std::vector<float> *out, Letterbox *lb) {
  if (!rgb || W < 1 || H < 1 || !out || !lb) return false;
  const float scale = (float)kInput / (float)std::max(W, H);
  const int newW = std::max(1, std::min(kInput, (int)(W * scale)));
  const int newH = std::max(1, std::min(kInput, (int)(H * scale)));
  out->assign((std::size_t)kInput * kInput * 3, 0.f);
  for (int y = 0; y < newH; ++y) {
    const int sy = std::min(H - 1, (int)(y / scale));
    for (int x = 0; x < newW; ++x) {
      const int sx = std::min(W - 1, (int)(x / scale));
      const unsigned char *sp = rgb + ((std::size_t)sy * W + sx) * 3;
      float *dp = out->data() + ((std::size_t)y * kInput + x) * 3;
      dp[0] = sp[0]; dp[1] = sp[1]; dp[2] = sp[2];
    }
  }
  lb->newW = newW; lb->newH = newH; lb->scale = scale;
  return true;
}

/** Bilinear giống torch.nn.functional.interpolate(mode="bilinear", align_corners=False, không antialias): nguồn sh x sw (bước dòng srcStride) -> đích dh x dw. */
inline void resizeBilinear(const float *src, int srcStride, int sh, int sw, float *dst, int dh, int dw) {
  const float ry = (float)sh / (float)dh, rx = (float)sw / (float)dw;
  std::vector<int> x0(dw), x1(dw); std::vector<float> wx(dw);
  for (int x = 0; x < dw; ++x) {
    float fx = (x + 0.5f) * rx - 0.5f; if (fx < 0.f) fx = 0.f;
    int i0 = std::min((int)fx, sw - 1); x0[x] = i0; x1[x] = std::min(i0 + 1, sw - 1);
    wx[x] = std::min(std::max(fx - (float)i0, 0.f), 1.f);
  }
  for (int y = 0; y < dh; ++y) {
    float fy = (y + 0.5f) * ry - 0.5f; if (fy < 0.f) fy = 0.f;
    int j0 = std::min((int)fy, sh - 1), j1 = std::min(j0 + 1, sh - 1);
    const float wy = std::min(std::max(fy - (float)j0, 0.f), 1.f);
    const float *r0 = src + (std::size_t)j0 * srcStride, *r1 = src + (std::size_t)j1 * srcStride;
    float *d = dst + (std::size_t)y * dw;
    for (int x = 0; x < dw; ++x) {
      const float top = r0[x0[x]] * (1.f - wx[x]) + r0[x1[x]] * wx[x];
      const float bot = r1[x0[x]] * (1.f - wx[x]) + r1[x1[x]] * wx[x];
      d[x] = top * (1.f - wy) + bot * wy;
    }
  }
}

/** low_res (kLow*kLow logits) -> mask W*H, 255 nơi logit > 0 còn lại 0. `lb` là kết quả letterboxHWC của CHÍNH ảnh đó. */
inline bool postprocessLowRes(const float *low, const Letterbox &lb, int W, int H, std::vector<unsigned char> *mask) {
  if (!low || !mask || W < 1 || H < 1 || lb.newW < 1 || lb.newH < 1) return false;
  std::vector<float> up((std::size_t)kInput * kInput);
  resizeBilinear(low, kLow, kLow, kLow, up.data(), kInput, kInput);
  std::vector<float> full((std::size_t)W * H);
  resizeBilinear(up.data(), kInput, lb.newH, lb.newW, full.data(), H, W);  // chỉ phần [0:newH, 0:newW] của khung 1024
  mask->assign((std::size_t)W * H, 0);
  for (std::size_t i = 0; i < full.size(); ++i) (*mask)[i] = full[i] > 0.f ? 255 : 0;
  return true;
}

}  // namespace mobilesam
