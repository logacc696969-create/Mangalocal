// mục 288 TECHNICAL_STATUS.md — động cơ MobileSAM click-to-mask bằng MNN::Express::Module (KHÔNG dùng MNN::Interpreter).
//
// VÌ SAO MODULE API: đồ thị decoder cần NỘI DUNG đầu vào để tính shape (đầu vào orig_im_size); MNN::Interpreter::createSession TỪ CHỐI
// (đo thật MNN 3.6.1: "Interpreter don't support case for shape compute need input content, please use module api instead", createSession trả null).
// Chỉ dùng những lời gọi đã chạy thật ở UnetModule.hpp (createRuntimeManager, Module::Config, Module::load, _Input, writeMap, onForward, _Convert, readMap).
// Cổng đo thật: encoder in {input_image} out {image_embeddings 1x256x64x64}; decoder in {image_embeddings, point_coords, point_labels, mask_input,
// has_mask_input, orig_im_size} out dùng {iou_predictions, low_res_masks} (bỏ `masks` — xem mobile_sam_post.hpp, mục 3 — và cũng bỏ luôn phần upsample nặng trong đồ thị).
// Chi tiết hợp đồng + số đo: mobile_sam_post.hpp.
#pragma once
#include <cstring>
#include <memory>
#include <string>
#include <vector>

#include <MNN/Interpreter.hpp>
#include <MNN/expr/Executor.hpp>
#include <MNN/expr/Expr.hpp>
#include <MNN/expr/ExprCreator.hpp>
#include <MNN/expr/Module.hpp>
#include <MNN/expr/NeuralNetWorkOp.hpp>

#include "mobile_sam_post.hpp"

namespace mobilesam {

class Engine {
 public:
  bool ready() const { return enc_ && dec_; }

  bool load(const std::string &encPath, const std::string &decPath, int numThread, std::string *err) {
    using namespace MNN::Express;
    MNN::ScheduleConfig sc;
    sc.type = MNN_FORWARD_CPU;  // ViT nặng, ưu tiên CPU ổn định (chưa benchmark OpenCL cho đồ thị này)
    sc.numThread = numThread < 1 ? 1 : numThread;
    rt_.reset(Executor::RuntimeManager::createRuntimeManager(sc));
    if (!rt_) return fail(err, "không tạo được RuntimeManager CPU");
    Module::Config mc;
    mc.shapeMutable = true;  // encoder nhận [cao,rộng,3] động; decoder nhận số điểm động
    mc.rearrange = false;
    enc_.reset(Module::load({"input_image"}, {"image_embeddings"}, encPath.c_str(), rt_, &mc));
    if (!enc_) return fail(err, "Module::load encoder thất bại: " + encPath);
    dec_.reset(Module::load({"image_embeddings", "point_coords", "point_labels", "mask_input", "has_mask_input", "orig_im_size"},
                            {"iou_predictions", "low_res_masks"}, decPath.c_str(), rt_, &mc));
    if (!dec_) { enc_.reset(); return fail(err, "Module::load decoder thất bại: " + decPath); }
    return true;
  }

  /** rgb: W*H*3 uint8. (clickX, clickY): toạ độ ẢNH GỐC (px). mask: W*H, 255 = vùng được chọn. iouPred (tuỳ chọn) = điểm tin cậy decoder. */
  bool clickToMask(const unsigned char *rgb, int W, int H, float clickX, float clickY, std::vector<unsigned char> *mask, std::string *err,
                   float *iouPred = nullptr) {
    using namespace MNN::Express;
    if (!ready()) return fail(err, "chưa nạp model");
    if (!rgb || W < 1 || H < 1 || !mask) return fail(err, "tham số không hợp lệ");
    if (!(clickX >= 0.f && clickX <= (float)W && clickY >= 0.f && clickY <= (float)H)) return fail(err, "toạ độ click ngoài ảnh");

    std::vector<float> hwc; Letterbox lb;
    if (!letterboxHWC(rgb, W, H, &hwc, &lb)) return fail(err, "letterbox thất bại");

    // Encoder: tensor 3 CHIỀU [1024,1024,3], cờ NCHW (đo thật: dữ liệu HWC liền khối; NHWC làm MNN hoán vị sai/segfault).
    auto in = _Input({kInput, kInput, 3}, NCHW, halide_type_of<float>());
    std::memcpy(in->writeMap<float>(), hwc.data(), hwc.size() * sizeof(float));
    auto eo = enc_->onForward({in});
    if (eo.size() != 1 || eo[0].get() == nullptr) return fail(err, "encoder không trả đúng 1 đầu ra");
    auto emb = _Convert(eo[0], NCHW);
    const auto *ei = emb->getInfo();
    const std::size_t embN = (std::size_t)256 * 64 * 64;
    if (!ei || (std::size_t)ei->size != embN) return fail(err, "kích thước image_embeddings không khớp (cần 1x256x64x64)");
    const float *ep = emb->readMap<float>();
    if (!ep) return fail(err, "readMap image_embeddings null");

    auto vEmb = _Input({1, 256, 64, 64}, NCHW, halide_type_of<float>());
    std::memcpy(vEmb->writeMap<float>(), ep, embN * sizeof(float));
    auto vPts = _Input({1, 2, 2}, NCHW, halide_type_of<float>());
    auto vLab = _Input({1, 2}, NCHW, halide_type_of<float>());
    auto vMaskIn = _Input({1, 1, kLow, kLow}, NCHW, halide_type_of<float>());
    auto vHas = _Input({1}, NCHW, halide_type_of<float>());
    auto vSize = _Input({2}, NCHW, halide_type_of<float>());
    float *pp = vPts->writeMap<float>();
    pp[0] = clickX * lb.scale; pp[1] = clickY * lb.scale;  // HỆ 1024, không phải toạ độ gốc
    pp[2] = 0.f; pp[3] = 0.f;                              // điểm đệm
    float *pl = vLab->writeMap<float>(); pl[0] = 1.f; pl[1] = -1.f;
    std::memset(vMaskIn->writeMap<float>(), 0, (std::size_t)kLow * kLow * sizeof(float));
    vHas->writeMap<float>()[0] = 0.f;
    float *ps = vSize->writeMap<float>(); ps[0] = (float)H; ps[1] = (float)W;  // vẫn phải cấp (cổng của đồ thị) dù không dùng đầu ra `masks`

    auto dout = dec_->onForward({vEmb, vPts, vLab, vMaskIn, vHas, vSize});
    if (dout.size() != 2 || dout[0].get() == nullptr || dout[1].get() == nullptr) return fail(err, "decoder không trả đúng 2 đầu ra");
    auto iou = _Convert(dout[0], NCHW);
    auto low = _Convert(dout[1], NCHW);
    const auto *li = low->getInfo();
    if (!li || (std::size_t)li->size != (std::size_t)kLow * kLow) return fail(err, "kích thước low_res_masks không khớp (cần 1x1x256x256)");
    const float *lp = low->readMap<float>();
    if (!lp) return fail(err, "readMap low_res_masks null");
    if (iouPred) { const float *ip = iou->readMap<float>(); *iouPred = ip ? ip[0] : -1.f; }
    if (!postprocessLowRes(lp, lb, W, H, mask)) return fail(err, "hậu xử lý mask thất bại");
    return true;
  }

 private:
  static bool fail(std::string *err, const std::string &m) { if (err) *err = m; return false; }
  std::shared_ptr<MNN::Express::Executor::RuntimeManager> rt_;
  std::shared_ptr<MNN::Express::Module> enc_, dec_;
};

}  // namespace mobilesam
