#ifndef PIPELINESDXLCPU_HPP
#define PIPELINESDXLCPU_HPP

#include <MNN/Interpreter.hpp>
#include <memory>
#include <stdexcept>
#include <string>

#include "Config.hpp"
#include "MnnUtils.hpp"
#include "Pipeline.hpp"

// PipelineSdxlCpu — mục 59 TECHNICAL_STATUS.md ("Xây hệ sinh thái SDXL").
//
// KHÔNG viết từ đầu — cắm vào ĐÚNG extension point mà lớp `Pipeline` (base
// class) đã chờ sẵn TỪ TRƯỚC (phát hiện khi rà lại trước khi viết, không
// phải do phiên này thiết kế): `Pipeline(text_encoder, dir, sdxl=true,
// use_v_pred)`, `vaeScale()` đã tự trả 0.13025 khi `sdxl_`, `textHiddenDim()`
// đã tự trả 768+1280, `textPooledDim()` đã tự trả 1280, và quan trọng nhất —
// `encodePrompts()` (trong Pipeline.hpp, KHÔNG override) đã TỰ SINH
// `cond.time_ids` (original_size=target_size=req.height/width, crop=0,0 —
// trường hợp phổ biến nhất, không cắt/resize khác tỉ lệ) — lớp này KHÔNG
// cần tự tính time_ids, chỉ cần ĐỌC `cond.time_ids`/`cond.pooled` trong
// `runUnetStep()`. `TextEncoder` (TextEncoder.hpp) cũng đã có sẵn toàn bộ
// logic 2 bộ token/pos-embedding (`token_emb_2_`/`pos_emb_2_`,
// `ProcessedPromptPair::negative_embeddings_2`/`positive_embeddings_2`) khi
// khởi tạo `TextEncoder(/*sdxl=*/true, false)` — mirror ĐÚNG những gì đã
// xác nhận đọc trong TextEncoder.hpp, không đoán.
//
// File duy nhất PHẢI viết mới: 2 CLIP session (encoder 1 = CLIP-L 768-dim,
// encoder 2 = CLIP-bigG 1280-dim + pooled output), UNet nhận thêm 2 input
// "text_embeds"/"time_ids" (added_cond_kwargs của SDXL — xem docstring đầu
// tools/export_sdxl_base.py cho nguồn API thật đã tra), và VAE ở độ phân
// giải NATIVE 1024x1024 (SDXL không sinh tốt ở 512x512, khác SD1.5).
class PipelineSdxlCpu : public Pipeline {
 public:
  PipelineSdxlCpu(TextEncoder &text_encoder, const std::string &model_dir,
                  std::string clip_l_path, std::string clip_g_path,
                  std::string unet_path, std::string vae_decoder_path,
                  std::string vae_encoder_path)
      : Pipeline(text_encoder, model_dir, /*sdxl=*/true, /*use_v_pred=*/false),
        clip_l_path_(std::move(clip_l_path)),
        clip_g_path_(std::move(clip_g_path)),
        unet_path_(std::move(unet_path)),
        vae_decoder_path_(std::move(vae_decoder_path)),
        vae_encoder_path_(std::move(vae_encoder_path)) {}

  bool initialize() override { return true; }

  bool supportsImg2Img() const override { return !vae_encoder_path_.empty(); }

 protected:
  bool canSkipUncond() const override { return false; }  // giống PipelineSd15Cpu — MNN chạy chung 1 graph call cho cả batch, không tách được
  bool previewSupported() const override { return false; }

  // vaeTilePixelSize()/vaeTilingSupported() GIỮ MẶC ĐỊNH base class (512 /
  // false) — Ultrafix/tiling cho SDXL CHƯA làm ở mục này (xem "CHƯA LÀM"
  // trong TECHNICAL_STATUS.md mục 59), phạm vi mục này CHỈ txt2img nền
  // tảng, đúng tinh thần "hoàn thiện SD1.5 trước, giờ mới XÂY NỀN SDXL"
  // — không cố nhồi mọi tính năng SD1.5 đã có (IP-Adapter/ControlNet/mask/
  // regional/LoRA-orthogonal) vào cùng 1 lượt, rủi ro chồng rủi ro.

  // encodeText() — 2 lượt CLIP RIÊNG (encoder 1 rồi encoder 2), ĐÚNG cách
  // ProcessedPromptPair đã tách sẵn 2 bộ embedding (negative_embeddings/
  // positive_embeddings = CLIP-L 768-dim; negative_embeddings_2/
  // positive_embeddings_2 = CLIP-bigG 1280-dim, xem TextEncoder.hpp đã đọc
  // trước khi viết). cond.hidden (2048-dim) = NỐI [CLIP-L output,
  // CLIP-bigG output] theo đúng thứ tự thật của diffusers
  // (StableDiffusionXLPipeline.encode_prompt(): `torch.concat([hidden_1,
  // hidden_2], dim=-1)`, hidden_1 trước — đã tra xác nhận, không đoán thứ
  // tự). cond.pooled (1280-dim) = CHỈ lấy pooled/projected output của
  // encoder 2 (CLIP-bigG có `text_projection` cho pooled, CLIP-L trong SDXL
  // KHÔNG dùng pooled của nó — đã xác nhận qua source `encode_prompt()`,
  // pooled_prompt_embeds chỉ gán từ index cuối cùng trong vòng lặp 2
  // encoder, tức encoder 2).
  //
  // PHÁT HIỆN QUAN TRỌNG khi thiết kế (không đoán): pooled output của
  // CLIP-bigG THẬT SỰ là hidden-state tại VỊ TRÍ TOKEN EOS (sau
  // final_layer_norm), rồi chiếu qua `text_projection` — vị trí EOS THAY
  // ĐỔI theo từng prompt (tuỳ độ dài câu), KHÔNG cố định — nên model
  // clip_g.mnn cần thêm 1 input `input_ids_2` (id token, dùng để dò đúng vị
  // trí EOS=49407 bên trong đồ thị ONNX) NGOÀI `input_embedding` — xem
  // tools/export_sdxl_base.py để biết cách trace chính xác logic này (dùng
  // lại đúng `text_projection`/pooling thật của `CLIPTextModelWithProjection`,
  // không tự viết lại pooling bằng tay).
  void encodeText(const ProcessedPromptPair &prompts, bool need_negative,
                  bool need_positive, Conditioning &cond) override {
    // ── Encoder 1: CLIP-L, 768-dim, KHÔNG có pooled (giống hệt SD1.5) ──
    MNN::Interpreter *interpL = createMnnInterpreterMmap(clip_l_path_.c_str());
    if (!interpL) throw std::runtime_error("Failed to create temporary MNN CLIP-L interpreter!");
    MnnSessionOptions optsL;  // CLIP luôn chạy CPU, giống mọi pipeline khác
    MNN::Session *sessL = createMnnSession(interpL, optsL);
    if (!sessL) { delete interpL; throw std::runtime_error("Failed to create temporary MNN CLIP-L session!"); }
    auto inputL = interpL->getSessionInput(sessL, "input_embedding");
    interpL->resizeTensor(inputL, {1, 77, text_embedding_size});
    interpL->resizeSession(sessL);
    interpL->releaseModel();

    // ── Encoder 2: CLIP-bigG, 1280-dim, CÓ pooled — thêm input "input_ids_2" ──
    MNN::Interpreter *interpG = createMnnInterpreterMmap(clip_g_path_.c_str());
    if (!interpG) { interpL->releaseSession(sessL); delete interpL; throw std::runtime_error("Failed to create temporary MNN CLIP-G interpreter!"); }
    MnnSessionOptions optsG;
    MNN::Session *sessG = createMnnSession(interpG, optsG);
    if (!sessG) {
      interpL->releaseSession(sessL); delete interpL; delete interpG;
      throw std::runtime_error("Failed to create temporary MNN CLIP-G session!");
    }
    auto inputG = interpG->getSessionInput(sessG, "input_embedding");
    auto inputG_ids = interpG->getSessionInput(sessG, "input_ids_2");
    if (!inputG_ids) {
      interpL->releaseSession(sessL); delete interpL;
      interpG->releaseSession(sessG); delete interpG;
      throw std::runtime_error("Model clip_g.mnn thieu input 'input_ids_2' - dung dung ban export_sdxl_base.py khong?");
    }
    interpG->resizeTensor(inputG, {1, 77, text_embedding_size_2});
    interpG->resizeTensor(inputG_ids, {1, 77});
    interpG->resizeSession(sessG);
    interpG->releaseModel();

    // ProcessedPromptPair chỉ có 1 bộ `ids` chung (KHÔNG có ids_2 riêng cho
    // từng vế âm/dương — xem struct thật trong TextEncoder.hpp: chỉ
    // `ids` 2*77 cho cả cặp, không phải `ids_2`). SDXL encoder 2 dùng pad=0
    // sau EOS đầu tiên thay vì 49407 (comment TextEncoder.hpp:
    // "SDXL encoder 2 uses pad id 0 instead of 49407 after the first EOS") —
    // NHƯNG vị trí EOS=49407 vẫn Y HỆT vị trí trong `ids` gốc (chỉ đổi phần
    // ĐUÔI sau EOS, không đổi vị trí EOS) — nên dò EOS trên `prompts.ids`
    // (đã có sẵn, đúng vị trí) là AN TOÀN, không cần bản `ids_2` riêng ở
    // tầng native (khác PromptProcessor nội bộ TextEncoder.hpp có `ids_2`
    // để tính embedding, nhưng vị trí EOS thì dùng chung được).
    auto find_eos_ids = [&](bool is_positive) -> std::vector<int> {
      // prompts.ids: [negative(77), positive(77)] nối liền — xem struct thật.
      size_t offset = is_positive ? 77 : 0;
      return std::vector<int>(prompts.ids.begin() + offset, prompts.ids.begin() + offset + 77);
    };

    auto run_side = [&](const std::vector<float> &emb1, const std::vector<float> &emb2,
                        const std::vector<int> &ids77, float *dst_hidden, float *dst_pooled) {
      memcpy(inputL->host<float>(), emb1.data(), 77 * text_embedding_size * sizeof(float));
      interpL->runSession(sessL);
      auto outL = interpL->getSessionOutput(sessL, "last_hidden_state");
      MNN::Tensor outL_host(outL, MNN::Tensor::CAFFE);
      outL->copyToHostTensor(&outL_host);

      memcpy(inputG->host<float>(), emb2.data(), 77 * text_embedding_size_2 * sizeof(float));
      MNN::Tensor inputG_ids_host(inputG_ids, MNN::Tensor::CAFFE);
      for (int i = 0; i < 77; i++) inputG_ids_host.host<int>()[i] = ids77[i];
      inputG_ids->copyFromHostTensor(&inputG_ids_host);
      interpG->runSession(sessG);
      auto outG_hidden = interpG->getSessionOutput(sessG, "last_hidden_state");
      auto outG_pooled = interpG->getSessionOutput(sessG, "pooled_output");
      MNN::Tensor outG_hidden_host(outG_hidden, MNN::Tensor::CAFFE);
      MNN::Tensor outG_pooled_host(outG_pooled, MNN::Tensor::CAFFE);
      outG_hidden->copyToHostTensor(&outG_hidden_host);
      outG_pooled->copyToHostTensor(&outG_pooled_host);

      const int dim1 = text_embedding_size;     // 768
      const int dim2 = text_embedding_size_2;   // 1280
      const int dimTotal = dim1 + dim2;          // 2048
      // Nối theo chiều FEATURE ở MỖI TOKEN (không phải nối khối theo chiều
      // token) — khớp đúng `torch.concat([hidden_1, hidden_2], dim=-1)`
      // thật của diffusers.
      for (int t = 0; t < 77; t++) {
        memcpy(dst_hidden + (size_t)t * dimTotal, outL_host.host<float>() + (size_t)t * dim1,
               dim1 * sizeof(float));
        memcpy(dst_hidden + (size_t)t * dimTotal + dim1, outG_hidden_host.host<float>() + (size_t)t * dim2,
               dim2 * sizeof(float));
      }
      memcpy(dst_pooled, outG_pooled_host.host<float>(), dim2 * sizeof(float));
    };

    if (need_negative) run_side(prompts.negative_embeddings, prompts.negative_embeddings_2, find_eos_ids(false), cond.negHidden(), cond.negPooled());
    if (need_positive) run_side(prompts.positive_embeddings, prompts.positive_embeddings_2, find_eos_ids(true), cond.posHidden(), cond.posPooled());

    interpL->releaseSession(sessL); delete interpL;
    interpG->releaseSession(sessG); delete interpG;
  }

  void vaeEncode(const GenerationRequest &req, const float *image, float *mean,
                 float *std_dev) override {
    MNN::Interpreter *interpreter = createMnnInterpreterMmap(vae_encoder_path_.c_str());
    if (!interpreter) throw std::runtime_error("Failed MNN VAE Enc (SDXL) create");
    MNN::Session *session = createMnnSession(interpreter, sessionOptions(req, "vae_enc_cache"));
    if (!session) { delete interpreter; throw std::runtime_error("Failed create temp MNN VAE Enc (SDXL) session!"); }

    auto input = interpreter->getSessionInput(session, "input");
    interpreter->resizeTensor(input, {1, 3, req.height, req.width});
    interpreter->resizeSession(session);
    if (req.use_opencl) interpreter->updateCacheFile(session);
    interpreter->releaseModel();

    auto input_h = new MNN::Tensor(input, MNN::Tensor::CAFFE);
    auto mean_t = interpreter->getSessionOutput(session, "mean");
    auto std_t = interpreter->getSessionOutput(session, "std");
    auto mean_h = new MNN::Tensor(mean_t, MNN::Tensor::CAFFE);
    auto std_h = new MNN::Tensor(std_t, MNN::Tensor::CAFFE);

    size_t image_count = (size_t)3 * req.height * req.width;
    size_t latent_count = (size_t)4 * (req.height / 8) * (req.width / 8);
    memcpy(input_h->host<float>(), image, image_count * sizeof(float));
    input->copyFromHostTensor(input_h);
    interpreter->runSession(session);

    mean_t->copyToHostTensor(mean_h);
    std_t->copyToHostTensor(std_h);
    memcpy(mean, mean_h->host<float>(), latent_count * sizeof(float));
    memcpy(std_dev, std_h->host<float>(), latent_count * sizeof(float));

    delete input_h; delete mean_h; delete std_h;
    interpreter->releaseSession(session);
    delete interpreter;
  }

  void vaeDecode(const GenerationRequest &req, const float *latents,
                float *pixels) override {
    MNN::Interpreter *interpreter = createMnnInterpreterMmap(vae_decoder_path_.c_str());
    if (!interpreter) throw std::runtime_error("Failed MNN VAE Dec (SDXL) create");
    MNN::Session *session = createMnnSession(interpreter, sessionOptions(req, "vae_dec_cache"));
    if (!session) { delete interpreter; throw std::runtime_error("Failed create temp MNN VAE Dec (SDXL) session!"); }

    auto input = interpreter->getSessionInput(session, "latent_sample");
    interpreter->resizeTensor(input, {1, 4, req.height / 8, req.width / 8});
    interpreter->resizeSession(session);
    if (req.use_opencl) interpreter->updateCacheFile(session);
    interpreter->releaseModel();

    auto input_h = new MNN::Tensor(input, MNN::Tensor::CAFFE);
    auto out = interpreter->getSessionOutput(session, "sample");
    auto out_h = new MNN::Tensor(out, MNN::Tensor::CAFFE);

    size_t latent_count = (size_t)4 * (req.height / 8) * (req.width / 8);
    size_t pixel_count = (size_t)3 * req.height * req.width;
    memcpy(input_h->host<float>(), latents, latent_count * sizeof(float));
    input->copyFromHostTensor(input_h);
    interpreter->runSession(session);
    out->copyToHostTensor(out_h);
    memcpy(pixels, out_h->host<float>(), pixel_count * sizeof(float));

    delete input_h; delete out_h;
    interpreter->releaseSession(session);
    delete interpreter;
  }

  void beginDenoise(const GenerationRequest &req) override {
    unet_interpreter_ = createMnnInterpreterMmap(unet_path_.c_str());
    if (!unet_interpreter_) throw std::runtime_error("Failed to create temporary MNN UNET (SDXL) interpreter!");
    unet_session_ = createMnnSession(unet_interpreter_, sessionOptions(req, "unet_sdxl_cache"));
    if (!unet_session_) throw std::runtime_error("Failed to create temporary MNN UNET (SDXL) session!");

    auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
    auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
    auto enc = unet_interpreter_->getSessionInput(unet_session_, "encoder_hidden_states");
    auto textEmb = unet_interpreter_->getSessionInput(unet_session_, "text_embeds");
    auto timeIds = unet_interpreter_->getSessionInput(unet_session_, "time_ids");
    if (!samp || !ts || !enc || !textEmb || !timeIds) {
      throw std::runtime_error(
          "Model unet_sdxl.mnn thieu 1 trong cac input bat buoc "
          "(sample/timestep/encoder_hidden_states/text_embeds/time_ids) - "
          "co dung file model SDXL khong?");
    }

    unet_interpreter_->resizeTensor(samp, {2, 4, req.height / 8, req.width / 8});
    unet_interpreter_->resizeTensor(ts, {1});
    unet_interpreter_->resizeTensor(enc, {2, 77, text_embedding_size + text_embedding_size_2});
    unet_interpreter_->resizeTensor(textEmb, {2, text_embedding_size_2});
    unet_interpreter_->resizeTensor(timeIds, {2, 6});
    unet_interpreter_->resizeSession(unet_session_);
    if (req.use_opencl) unet_interpreter_->updateCacheFile(unet_session_);
    unet_interpreter_->releaseModel();
  }

  void runUnetStep(const GenerationRequest &req, const float *latents_batch2,
                   float timestep_f, bool /*skip_uncond*/, Conditioning &cond,
                   float *out_batch2) override {
    const int timestep = static_cast<int>(timestep_f);
    auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
    auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
    auto enc = unet_interpreter_->getSessionInput(unet_session_, "encoder_hidden_states");
    auto textEmb = unet_interpreter_->getSessionInput(unet_session_, "text_embeds");
    auto timeIds = unet_interpreter_->getSessionInput(unet_session_, "time_ids");

    MNN::Tensor samp_h(samp, MNN::Tensor::CAFFE);
    MNN::Tensor ts_h(ts, MNN::Tensor::CAFFE);
    MNN::Tensor enc_h(enc, MNN::Tensor::CAFFE);
    MNN::Tensor textEmb_h(textEmb, MNN::Tensor::CAFFE);
    MNN::Tensor timeIds_h(timeIds, MNN::Tensor::CAFFE);

    size_t batch2_count = (size_t)2 * 4 * (req.height / 8) * (req.width / 8);
    memcpy(samp_h.host<float>(), latents_batch2, batch2_count * sizeof(float));
    memcpy(ts_h.host<int>(), &timestep, sizeof(int));
    memcpy(enc_h.host<float>(), cond.hidden.data(), cond.hidden.size() * sizeof(float));
    // cond.pooled / cond.time_ids đã được BASE CLASS (Pipeline::encodePrompts(),
    // xem Pipeline.hpp) tự cấp phát + điền sẵn khi sdxl_=true — chỉ đọc lại
    // ở đây, KHÔNG tự tính (time_ids đặc biệt: base class tự dùng
    // original_size=target_size=req.height/width, crop=(0,0), xem comment
    // đầu file này).
    memcpy(textEmb_h.host<float>(), cond.pooled.data(), cond.pooled.size() * sizeof(float));
    memcpy(timeIds_h.host<float>(), cond.time_ids.data(), cond.time_ids.size() * sizeof(float));

    samp->copyFromHostTensor(&samp_h);
    ts->copyFromHostTensor(&ts_h);
    enc->copyFromHostTensor(&enc_h);
    textEmb->copyFromHostTensor(&textEmb_h);
    timeIds->copyFromHostTensor(&timeIds_h);

    unet_interpreter_->runSession(unet_session_);

    auto output = unet_interpreter_->getSessionOutput(unet_session_, "out_sample");
    MNN::Tensor out_h(output, MNN::Tensor::CAFFE);
    output->copyToHostTensor(&out_h);
    memcpy(out_batch2, out_h.host<float>(), batch2_count * sizeof(float));
  }

  void endDenoise() override {
    if (unet_session_) unet_interpreter_->releaseSession(unet_session_);
    unet_session_ = nullptr;
    delete unet_interpreter_;
    unet_interpreter_ = nullptr;
  }

  void releaseTransientModels() override { endDenoise(); }

  MnnSessionOptions sessionOptions(const GenerationRequest &req, const char *stage) const {
    MnnSessionOptions opts;
    opts.use_opencl = req.use_opencl;
    opts.allow_npu = req.use_npu;  // mục 60 TECHNICAL_STATUS.md
    // mục 64 TECHNICAL_STATUS.md — vẫn thread require_npu xuống cho SDXL
    // để cơ chế nhất quán về code, NHƯNG resolveModel() trong
    // mnn_diffusion_pipeline.cpp chỉ đọc npu_required=true cho các entry
    // SD1.5 theo đúng yêu cầu ("SDXL vẫn phải chạy được GPU tối thiểu,
    // không bị khoá cứng NPU") — SDXL model bình thường sẽ luôn nhận
    // req.require_npu=false từ handle->requireNpu, giữ nguyên cascade
    // NPU->GPU->CPU cho SDXL.
    opts.require_npu = req.require_npu;
    if (req.use_opencl) {
      auto cache_dir = ensureCacheDir(model_dir_);
      opts.cache_file = (cache_dir.empty() ? model_dir_ : cache_dir) + "/" + stage + ".mnnc." + std::to_string(req.width);
    }
    return opts;
  }

  MNN::Interpreter *unet_interpreter_ = nullptr;
  MNN::Session *unet_session_ = nullptr;

 private:
  const std::string clip_l_path_;
  const std::string clip_g_path_;
  const std::string unet_path_;
  const std::string vae_decoder_path_;
  const std::string vae_encoder_path_;
};

#endif  // PIPELINESDXLCPU_HPP
