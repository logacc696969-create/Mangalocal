#pragma once
// mục 248 TECHNICAL_STATUS.md — DIFFERENTIAL DIFFUSION (Levin & Fried): phần LOGIC THUẦN, không phụ thuộc MNN/xtensor để
// biên dịch và chạy thử riêng bằng g++ (tools/test_differential_diffusion.py).
//
// Ý tưởng (theo cách hiểu của tôi từ mô tả phương pháp — CẦN đối chiếu mã tham chiếu exx8/differential-diffusion trước
// khi tin tuyệt đối): mask không còn là trọng số trộn CỐ ĐỊNH ở mọi bước mà là "độ thay đổi" c ∈ [0,1] của từng pixel. Ở mỗi
// bước, pixel chỉ được "thả tự do" (lấy latent đang sinh) khi c lớn hơn lượng nhiễu còn lại; ngược lại bị kéo về ảnh gốc đã
// thêm nhiễu. Pixel c=1 tự do cả quá trình; c=0.3 chỉ tự do ở ~30% số bước CUỐI (chỉ chỉnh chi tiết nhỏ); c=0 không bao giờ.
//
// Tính chất AN TOÀN dùng để kiểm thử: với mask NHỊ PHÂN (0/1) kết quả đúng bằng cách trộn cứng cũ ở mọi bước, nên bật cờ
// không đổi gì với mask nhị phân; chỉ khác ở vùng mask mềm (biên lông vũ).
//
// Cờ toàn cục như g_generation_interrupted (mục 142): một app chỉ chạy 1 lượt generate() tại một thời điểm.
#include <atomic>
#include <cstddef>

inline std::atomic<bool> g_differential_diffusion{false};

// Phần nhiễu còn lại SAU khi đã chạy done_steps/total_steps bước: 1 -> 0.
inline float ddRemaining(int done_steps, int total_steps) {
  if (total_steps <= 0) return 0.0f;
  const float r = 1.0f - (float)done_steps / (float)total_steps;
  return r < 0.0f ? 0.0f : r;
}

// 1 nếu pixel có độ thay đổi `strength` được thả tự do ở bước này, ngược lại 0.
inline float ddGate(float strength, float remaining) {
  return strength > remaining ? 1.0f : 0.0f;
}

inline void ddGateBuffer(const float *strength, float *out, std::size_t n, float remaining) {
  for (std::size_t k = 0; k < n; ++k) out[k] = ddGate(strength[k], remaining);
}
