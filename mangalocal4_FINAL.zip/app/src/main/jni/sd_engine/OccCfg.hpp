#pragma once
// mục 261 TECHNICAL_STATUS.md — OCCLUSION-AWARE CFG (OccCFG), phần LOGIC THUẦN (không phụ thuộc MNN/xtensor để biên dịch và
// chạy thử riêng bằng g++: tools/test_occ_cfg.py).
//
// Nguồn: PersonaCraft (Kim, Jeon, Lee, Chun — arXiv 2411.18068), công thức (4), đọc toàn văn:
//   eps_hat = eps_uncond + (k_occ * M_occ + k_base * (1 - M_occ)) * (eps_cond - eps_uncond)
// Bài quan sát: tăng CFG RIÊNG ở vùng bị che khuất/chạm nhau giúp giải mơ hồ cục bộ (giải phẫu đúng hơn), nhưng CFG cao ĐỒNG
// ĐỀU gây quá bão hoà ở vùng không che khuất — nên CFG phải biến thiên theo không gian. Đây là phép tính THUẦN trên 2 dự đoán
// nhiễu nên chạy được ngay trong vòng lấy mẫu C++ của đồ thị MNN cố định (không cần sửa đồ thị, không cần huấn luyện).
//
// KHÔNG làm theo bài (cần huấn luyện): SCNet (ControlNet depth+normal từ SMPL-X) và OccNet (ControlNet trên cạnh độ sâu). Ở đây
// "bản đồ che khuất" M_occ do Kotlin dựng từ khung xương 2D (ContactMap.kt), không phải đếm giao điểm mặt lưới 3D như bài.
// M_occ ở đây LIÊN TỤC trong [0,1] (bài dùng nhị phân sau khi giãn biên) -> k(x) nội suy tuyến tính giữa k_base và k_occ.
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <mutex>
#include <vector>

struct OccCfgState {
  bool active = false;
  int w = 0, h = 0;          // kích thước bản đồ (thường = latent: width/8 x height/8)
  float boost = 1.0f;        // k_occ = cfg * boost (kẹp ở occ_cfg::kMaxBoost)
  std::vector<float> map;    // w*h, [0,1]
};

inline std::mutex g_occ_cfg_mutex;
inline OccCfgState g_occ_cfg;

namespace occ_cfg {

constexpr float kMinBoost = 1.0f;
constexpr float kMaxBoost = 2.5f;

inline float clamp01(float v) {
  if (!(v == v)) return 0.0f;  // NaN -> 0
  return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
}

inline float clampBoost(float b) {
  if (!(b == b)) return 1.0f;
  return b < kMinBoost ? kMinBoost : (b > kMaxBoost ? kMaxBoost : b);
}

// CFG hiệu dụng tại 1 điểm: base*(1-m) + k_occ*m. m kẹp [0,1], NaN -> 0 (không đổi gì).
inline float scaleAt(float base, float k_occ, float m) {
  const float mm = clamp01(m);
  return base * (1.0f - mm) + k_occ * mm;
}

// Nội suy song tuyến bản đồ (w0 x h0) -> (w1 x h1). Giá trị kẹp [0,1]. Kích thước <= 0 hoặc src sai cỡ -> rỗng.
inline std::vector<float> resizeBilinear(const std::vector<float>& src, int w0, int h0, int w1, int h1) {
  if (w0 <= 0 || h0 <= 0 || w1 <= 0 || h1 <= 0) return {};
  if (src.size() != (std::size_t)w0 * (std::size_t)h0) return {};
  std::vector<float> out((std::size_t)w1 * h1);
  if (w0 == w1 && h0 == h1) {
    for (std::size_t k = 0; k < out.size(); ++k) out[k] = clamp01(src[k]);
    return out;
  }
  for (int y = 0; y < h1; ++y) {
    const float fy = ((float)y + 0.5f) * (float)h0 / (float)h1 - 0.5f;
    int y0 = (int)std::floor(fy);
    const float ty = fy - (float)y0;
    int y1 = y0 + 1;
    y0 = std::min(std::max(y0, 0), h0 - 1);
    y1 = std::min(std::max(y1, 0), h0 - 1);
    for (int x = 0; x < w1; ++x) {
      const float fx = ((float)x + 0.5f) * (float)w0 / (float)w1 - 0.5f;
      int x0 = (int)std::floor(fx);
      const float tx = fx - (float)x0;
      int x1 = x0 + 1;
      x0 = std::min(std::max(x0, 0), w0 - 1);
      x1 = std::min(std::max(x1, 0), w0 - 1);
      const float a = clamp01(src[(std::size_t)y0 * w0 + x0]);
      const float b = clamp01(src[(std::size_t)y0 * w0 + x1]);
      const float c = clamp01(src[(std::size_t)y1 * w0 + x0]);
      const float d = clamp01(src[(std::size_t)y1 * w0 + x1]);
      const float top = a + (b - a) * tx;
      const float bot = c + (d - c) * tx;
      out[(std::size_t)y * w1 + x] = clamp01(top + (bot - top) * ty);
    }
  }
  return out;
}

// out[c*hw + p] = uncond + k(p) * (txt - uncond), mọi kênh dùng chung 1 bản đồ hw điểm.
// map == nullptr -> CFG thường (k = base) để hàm luôn an toàn khi gọi.
inline void combine(const float* uncond, const float* txt, const float* map_hw, int channels, std::size_t hw,
                    float base, float k_occ, float* out) {
  for (int c = 0; c < channels; ++c) {
    const std::size_t off = (std::size_t)c * hw;
    for (std::size_t p = 0; p < hw; ++p) {
      const float k = map_hw ? scaleAt(base, k_occ, map_hw[p]) : base;
      out[off + p] = uncond[off + p] + k * (txt[off + p] - uncond[off + p]);
    }
  }
}

// Lấy bản đồ đã đổi về (lw x lh) từ trạng thái toàn cục. false nếu không bật/không hợp lệ.
// consume = true (mặc định): bản đồ chỉ áp cho ĐÚNG MỘT lượt generate() rồi tự tắt. Lý do: bản đồ gắn với khung toạ độ của ảnh gốc;
// các lượt vá cục bộ sau đó (inpaint vùng chạm, Cascade, vẽ lại mặt) chạy trên ảnh/crop có khung khác — áp nhầm bản đồ sẽ tăng CFG sai chỗ.
inline bool fieldFor(int lw, int lh, std::vector<float>& field, float& boost, bool consume = true) {
  std::lock_guard<std::mutex> lk(g_occ_cfg_mutex);
  if (!g_occ_cfg.active) return false;
  field = resizeBilinear(g_occ_cfg.map, g_occ_cfg.w, g_occ_cfg.h, lw, lh);
  if (field.empty()) return false;
  boost = clampBoost(g_occ_cfg.boost);
  if (consume) { g_occ_cfg.active = false; g_occ_cfg.map.clear(); }
  return true;
}

}  // namespace occ_cfg

inline void occCfgSet(const float* map, int w, int h, float boost) {
  std::lock_guard<std::mutex> lk(g_occ_cfg_mutex);
  g_occ_cfg.active = false;
  if (!map || w <= 0 || h <= 0 || (long long)w * h > 4096LL * 4096LL) {
    g_occ_cfg.map.clear();
    return;
  }
  g_occ_cfg.w = w;
  g_occ_cfg.h = h;
  g_occ_cfg.boost = occ_cfg::clampBoost(boost);
  g_occ_cfg.map.assign(map, map + (std::size_t)w * h);
  for (auto& v : g_occ_cfg.map) v = occ_cfg::clamp01(v);
  g_occ_cfg.active = true;
}

inline void occCfgClear() {
  std::lock_guard<std::mutex> lk(g_occ_cfg_mutex);
  g_occ_cfg.active = false;
  g_occ_cfg.map.clear();
}
