#pragma once
// mục 261 TECHNICAL_STATUS.md — COMPOSABLE LoRA lúc suy luận (LoRA Switch / LoRA Composite), phần LOGIC THUẦN (std-only; chạy thử
// riêng bằng g++: tools/test_lora_compose.py).
//
// Nguồn: Zhong và cộng sự, "Multi-LoRA Composition for Image Generation" (arXiv 2402.16843, TMLR 2024), ĐỌC TOÀN VĂN.
//   * LoRA Switch (công thức 4): với k LoRA và bước đổi tau, ở bước t (đếm từ 1) LoRA đang bật là
//       i = floor(((t-1) mod (k*tau)) / tau) + 1.   Chỉ MỘT LoRA hoạt động mỗi bước. Bài: tau = 5 tốt nhất; đổi LoRA MỖI bước
//       (tau = 1) làm méo ảnh; chiến lược giảm dần tau (đổi dày hơn ở cuối) kém hơn; LoRA NHÂN VẬT nên bật ĐẦU TIÊN.
//   * LoRA Composite (công thức 5): tính điểm (uncond + s*(cond - uncond)) của TỪNG LoRA rồi lấy trung bình
//       eps = (1/k) * sum_i w_i * [eps_i(z) + s*(eps_i(z,c) - eps_i(z))], bài đặt w_i = 1. Tốn k lần UNet mỗi bước.
//   * Mục 5.1.2 của bài đề xuất KẾT HỢP: mỗi bước chọn một TẬP CON LoRA (Switch) rồi dùng Composite trong tập con đó.
//     Ở đây tham số hoá bằng `active_count` m: m = 1 -> Switch thuần; m = k -> Composite thuần; 1 < m < k -> kết hợp.
//
// VÌ SAO phép trộn làm trên đầu ra UNet dạng batch [uncond, cond] là ĐÚNG công thức 5: CFG tuyến tính theo (uncond, cond), nên
// trung bình các cặp (uncond_i, cond_i) rồi mới áp CFG bằng trung bình các điểm đã áp CFG (cùng hệ số s).
//
// KHÔNG phải weight-merge: mỗi biến thể LÀ một UNet riêng (đã gộp sẵn đúng 1 LoRA lúc convert, `unet.mnn` của model nhân vật) —
// MNN gộp LoRA vào trọng số lúc nhập model nên không đổi được lúc chạy; xem mục 261 về cách thực hiện và GIỚI HẠN
// (text-encoder của LoRA phụ không được dùng).
#include <algorithm>
#include <cstddef>
#include <mutex>
#include <string>
#include <vector>

#include "OccCfg.hpp"  // resizeBilinear (std-only) cho mask theo vùng

struct LoraComposeState {
  bool active = false;
  int active_count = 1;                 // m (xem trên)
  int tau = 5;                          // bước đổi LoRA (Switch)
  std::vector<std::string> extra_unets; // đường dẫn unet.mnn của các biến thể PHỤ (biến thể 0 = UNet chính của pipeline)
  std::vector<float> weights;           // trọng số điểm w_i cho k biến thể (rỗng = toàn 1)
  // mục 261.11 — REGIONAL COMPOSITE (Latent Couple áp lên các UNet-mỗi-LoRA): mỗi biến thể i có mask vùng M_i (k mask liên tiếp, mỗi mask
  // mask_w x mask_h, [0,1]); mỗi bước chạy ĐỦ k UNet rồi trộn TỪNG PIXEL theo M_i thay vì trung bình toàn cục. Rỗng = tắt.
  int mask_k = 0, mask_w = 0, mask_h = 0;
  std::vector<float> masks;
  // mục 261.14 — CLIP RIÊNG của từng LoRA: extra_clips[i] = đường dẫn clip.mnn của biến thể PHỤ i ("" = dùng CLIP chính). LoRA nhân vật thường
  // huấn luyện cả text-encoder; mã hoá prompt cho UNet i bằng CLIP của chính LoRA i mới đúng cách dùng LoRA (diffusers set_adapters áp cho CẢ HAI).
  std::vector<std::string> extra_clips;
};

inline std::mutex g_lora_compose_mutex;
inline LoraComposeState g_lora_compose;

namespace lora_compose {

constexpr int kMaxExtras = 3;  // tối đa 4 UNet cùng nạp (1 chính + 3 phụ): mỗi UNet ~ vài trăm MB-GB RAM
constexpr int kMinTau = 1;
constexpr int kMaxTau = 20;

inline int clampTau(int tau) { return tau < kMinTau ? kMinTau : (tau > kMaxTau ? kMaxTau : tau); }

// Công thức 4 ở dạng đếm từ 0: step = 0 là bước khử nhiễu ĐẦU TIÊN. k >= 1, tau >= 1.
inline int switchIndex(int step, int k, int tau) {
  if (k <= 1) return 0;
  tau = clampTau(tau);
  if (step < 0) step = 0;
  return (step % (k * tau)) / tau;
}

// Tập chỉ số biến thể hoạt động ở bước `step`: m LoRA liên tiếp (vòng) bắt đầu từ switchIndex. m kẹp [1,k].
inline std::vector<int> activeSet(int step, int k, int tau, int m) {
  std::vector<int> out;
  if (k <= 1) { out.push_back(0); return out; }
  m = m < 1 ? 1 : (m > k ? k : m);
  const int first = switchIndex(step, k, tau);
  for (int j = 0; j < m; ++j) out.push_back((first + j) % k);
  return out;
}

// Hệ số trộn cho các biến thể trong `active`: trung bình có trọng số (= công thức 5 khi mọi w_i = 1).
// m = 1 -> {1}. Trọng số không hữu hạn/<= 0 coi như 1 để một giá trị hỏng không làm sụp nhiễu.
inline std::vector<float> factors(const std::vector<int>& active, const std::vector<float>& weights) {
  std::vector<float> f(active.size(), 1.0f);
  if (active.size() <= 1) return f;
  double sum = 0.0;
  for (std::size_t j = 0; j < active.size(); ++j) {
    float w = 1.0f;
    const int idx = active[j];
    if (idx >= 0 && (std::size_t)idx < weights.size()) {
      const float cand = weights[(std::size_t)idx];
      if (cand == cand && cand > 0.0f && cand < 1e6f) w = cand;
    }
    f[j] = w;
    sum += w;
  }
  for (auto& v : f) v = (float)(v / sum);
  return f;
}

// dst[i] = sum_j factors[j] * outs[j][i]
inline void blend(const std::vector<const float*>& outs, const std::vector<float>& fac, std::size_t n, float* dst) {
  for (std::size_t i = 0; i < n; ++i) {
    float acc = 0.0f;
    for (std::size_t j = 0; j < outs.size(); ++j) acc += fac[j] * outs[j][i];
    dst[i] = acc;
  }
}

// mục 261.11 — hệ số trộn TỪNG PIXEL cho k biến thể từ k mask vùng (mw x mh) đổi về latent (lw x lh). Trả k*lw*lh float (hàng i = biến thể i),
// rỗng nếu đầu vào không hợp lệ. Với s = tổng mask tại pixel và bg_i = w_i/Σw (nền, mặc định 1/k):
//     f_i = (m_i + bg_i * max(0, 1 - s)) / max(1, s)
// -> Σ_i f_i = 1 và f_i >= 0 ở MỌI pixel; s >= 1: chuẩn hoá thuần theo mask; s = 0 (ngoài mọi người): trung bình bg (= Composite thường);
//    0 < s < 1 (rìa mềm): nội suy trơn giữa "thuộc vùng" và "trung bình" — không có bước nhảy cứng khi mask chỉ vừa chạm.
inline std::vector<float> regionalFields(const std::vector<float>& masks, int k, int mw, int mh, int lw, int lh,
                                         const std::vector<float>& weights) {
  std::vector<float> out;
  if (k < 2 || mw <= 0 || mh <= 0 || lw <= 0 || lh <= 0) return out;
  if (masks.size() != (std::size_t)k * (std::size_t)mw * (std::size_t)mh) return out;
  const std::size_t hw = (std::size_t)lw * (std::size_t)lh;
  std::vector<std::vector<float>> m((std::size_t)k);
  for (int i = 0; i < k; ++i) {
    std::vector<float> src(masks.begin() + (std::size_t)i * mw * mh, masks.begin() + (std::size_t)(i + 1) * mw * mh);
    m[(std::size_t)i] = occ_cfg::resizeBilinear(src, mw, mh, lw, lh);
    if (m[(std::size_t)i].size() != hw) return {};
  }
  std::vector<float> bg((std::size_t)k, 1.0f);
  double bsum = 0.0;
  for (int i = 0; i < k; ++i) {
    float w = 1.0f;
    if ((std::size_t)i < weights.size()) {
      const float c = weights[(std::size_t)i];
      if (c == c && c > 0.0f && c < 1e6f) w = c;
    }
    bg[(std::size_t)i] = w;
    bsum += w;
  }
  for (auto& v : bg) v = (float)(v / bsum);
  out.assign((std::size_t)k * hw, 0.0f);
  for (std::size_t p = 0; p < hw; ++p) {
    float s = 0.0f;
    for (int i = 0; i < k; ++i) s += m[(std::size_t)i][p];
    const float rest = s < 1.0f ? 1.0f - s : 0.0f;
    const float denom = s > 1.0f ? s : 1.0f;
    for (int i = 0; i < k; ++i) out[(std::size_t)i * hw + p] = (m[(std::size_t)i][p] + bg[(std::size_t)i] * rest) / denom;
  }
  return out;
}

// dst[plane*hw + p] = Σ_j fields_j[p] * outs[j][plane*hw + p]; fields_j trỏ tới hàng của biến thể j (hw float). planes = batch(2) * kênh(4).
inline void blendRegional(const std::vector<const float*>& outs, const std::vector<const float*>& fields, std::size_t hw,
                          std::size_t planes, float* dst) {
  for (std::size_t pl = 0; pl < planes; ++pl) {
    const std::size_t off = pl * hw;
    for (std::size_t p = 0; p < hw; ++p) {
      float acc = 0.0f;
      for (std::size_t j = 0; j < outs.size(); ++j) acc += fields[j][p] * outs[j][off + p];
      dst[off + p] = acc;
    }
  }
}

// mục 261.14 — nguồn điều kiện văn bản cho biến thể `variant` (0 = UNet chính): -1 = dùng điều kiện CHÍNH; i >= 0 = dùng điều kiện phụ thứ i
// (variant-1). `usable[i]` = điều kiện phụ i đã mã hoá được bằng CLIP riêng. Biến thể phụ thiếu CLIP riêng/lỗi mã hoá -> -1 (rơi về CLIP chính).
inline int condSource(int variant, const std::vector<bool>& usable) {
  if (variant <= 0) return -1;
  const std::size_t i = (std::size_t)variant - 1;
  return (i < usable.size() && usable[i]) ? (int)i : -1;
}

// mục 270 — MODULE LoRA tách rời (UnetModule.hpp): đường dẫn biến thể có đuôi ".lora.mnn" là module LoRA gắn nhánh (lora_attach_branch
// --strip-base-weights), KHÔNG phải UNet đầy đủ — file đó không mang trọng số nền nên TUYỆT ĐỐI không được nạp bằng đường Interpreter
// (sẽ chạy bằng trọng số rác). Quy ước theo đuôi tên để không đổi JNI/Kotlin: native tự nhận ra từ extra_unets.
enum class ModuleMode { None, All, Mixed };

inline bool isModulePath(const std::string& p) {
  static const char kSuffix[] = ".lora.mnn";
  const std::size_t n = sizeof(kSuffix) - 1;
  return p.size() > n && p.compare(p.size() - n, n, kSuffix) == 0;
}

// None: không biến thể nào là module (đường cũ mục 261); All: mọi biến thể phụ là module; Mixed: lẫn lộn (KHÔNG hỗ trợ -> nơi gọi tắt compose).
inline ModuleMode moduleMode(const std::vector<std::string>& paths) {
  std::size_t m = 0;
  for (const auto& p : paths) m += isModulePath(p) ? 1 : 0;
  if (m == 0) return ModuleMode::None;
  return m == paths.size() ? ModuleMode::All : ModuleMode::Mixed;
}

inline bool snapshot(LoraComposeState& out) {
  std::lock_guard<std::mutex> lk(g_lora_compose_mutex);
  if (!g_lora_compose.active || g_lora_compose.extra_unets.empty()) return false;
  out = g_lora_compose;
  return true;
}

}  // namespace lora_compose

inline void loraComposeSet(int active_count, int tau, const std::vector<std::string>& extra_unets,
                           const std::vector<float>& weights) {
  std::lock_guard<std::mutex> lk(g_lora_compose_mutex);
  g_lora_compose = LoraComposeState();
  if (extra_unets.empty()) return;
  for (const auto& p : extra_unets) {
    if (p.empty()) return;  // đường dẫn rỗng = lời gọi hỏng -> không bật (an toàn)
  }
  g_lora_compose.extra_unets.assign(extra_unets.begin(),
                                    extra_unets.begin() + std::min<std::size_t>(extra_unets.size(), lora_compose::kMaxExtras));
  g_lora_compose.tau = lora_compose::clampTau(tau);
  const int k = (int)g_lora_compose.extra_unets.size() + 1;
  g_lora_compose.active_count = active_count < 1 ? 1 : (active_count > k ? k : active_count);
  g_lora_compose.weights = weights;
  g_lora_compose.active = true;
}

// mục 261.11 — đặt mask vùng cho lượt compose đang cấu hình (gọi SAU loraComposeSet vì Set xoá trạng thái). Sai cỡ/không hữu hạn -> bỏ mask (rơi về
// Switch/Composite thường), KHÔNG ném lỗi. k phải = số UNet (1 + số UNet phụ) — native kiểm lại khi nạp.
inline void loraComposeSetMasks(const float* masks, int k, int w, int h) {
  std::lock_guard<std::mutex> lk(g_lora_compose_mutex);
  g_lora_compose.mask_k = 0; g_lora_compose.mask_w = 0; g_lora_compose.mask_h = 0; g_lora_compose.masks.clear();
  if (!g_lora_compose.active || !masks || k < 2 || w <= 0 || h <= 0) return;
  if ((long long)k * w * h > 4LL * 4096LL * 4096LL) return;
  g_lora_compose.mask_k = k; g_lora_compose.mask_w = w; g_lora_compose.mask_h = h;
  g_lora_compose.masks.assign(masks, masks + (std::size_t)k * w * h);
  for (auto& v : g_lora_compose.masks) v = occ_cfg::clamp01(v);
}

// mục 261.14 — đặt CLIP riêng cho các biến thể phụ (gọi SAU loraComposeSet; Set xoá trạng thái). Số phần tử phải = số UNet phụ, đường dẫn rỗng
// nghĩa là biến thể đó dùng CLIP chính. Sai số lượng/compose chưa bật -> bỏ (không ném lỗi).
inline void loraComposeSetClips(const std::vector<std::string>& clips) {
  std::lock_guard<std::mutex> lk(g_lora_compose_mutex);
  g_lora_compose.extra_clips.clear();
  if (!g_lora_compose.active || clips.size() != g_lora_compose.extra_unets.size()) return;
  g_lora_compose.extra_clips = clips;
}

inline void loraComposeClear() {
  std::lock_guard<std::mutex> lk(g_lora_compose_mutex);
  g_lora_compose = LoraComposeState();
}
