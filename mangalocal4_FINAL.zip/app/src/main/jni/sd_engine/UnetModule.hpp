#pragma once
// mục 270 TECHNICAL_STATUS.md — UNet chạy bằng MNN::Express::Module + LoRA TÁCH RỜI qua Module::Config::base (bước (c) của 264.3).
//
// VÌ SAO có file này: composable LoRA hiện có (mục 261) mỗi biến thể là MỘT UNet đầy đủ (Interpreter/Session riêng, ~gần 1 GB mỗi cái nếu w8).
// Mục 264 đo trên MNN 3.6.1 THẬT: module LoRA nạp với `config.base = <module nền>` + `rearrange = true` CHIA SẺ trọng số nền, chi phí biên chỉ là
// trọng số nhánh LoRA (~1 MB trong thí nghiệm). Mục 265 làm công cụ gắn nhánh (lora_attach_branch), mục 268-269 làm công cụ safetensors -> spec và
// kiểm chứng chuỗi đầy đủ trên UNet MNN thật (thu nhỏ). File này là phần C++ chạy NHỮNG module đó trong app.
//
// CHỈ DÙNG NHỮNG LỜI GỌI MNN ĐÃ CHẠY THẬT trong tools/mnn_probe/lora_split_equivalence.cpp (MNN 3.6.1): Executor::RuntimeManager::createRuntimeManager,
// Module::Config{shapeMutable, rearrange, base}, Module::load(inputs, outputs, file, rt, &cfg), _Input, writeMap/readMap, onForward, _Convert.
// Hai lời gọi KHÔNG có trong probe — Variable::getInfo()->size (kiểm kích thước đầu ra) và VARP::get() (kiểm đầu ra rỗng) — ĐÃ ĐỐI CHIẾU với tài liệu/header
// công khai của MNN ở mục 272 (wiki Expr: `Variable* VARP::get() const`; `const Info* Variable::getInfo()` trả nullptr khi lỗi, `Info::size` dùng trong ví dụ chính thức;
// kiểu của `size` ghi `int` ở bản cũ, `size_t` ở bản mới -> mã ép sang size_t nên đúng cho cả hai). Vẫn CHƯA biên dịch với MNN 3.6.1 thật.
// Cả file nằm sau cờ MANGALOCAL_LORA_MODULE (mặc định TẮT) nên build mặc định không biên dịch nó.
//
// PHẠM VI / GIỚI HẠN (cố ý hẹp):
//  * CHỈ CPU (thiết lập giống nhánh CPU của createMnnSession: 4 luồng, Memory_Low, Power_High). OpenCL/NPU chưa kiểm cơ chế chia sẻ (264.3).
//  * CHỈ pipeline SD1.5 thường (3 input sample/timestep/encoder_hidden_states, 1 output out_sample). UNet "augmented" (IP-Adapter/ControlNet),
//    SDXL, Regional/GLIGEN/Triple-Combo có input khác -> KHÔNG dùng đường này.
//  * Chia sẻ chỉ TRỌNG SỐ (RAM). Mỗi biến thể vẫn chạy ĐỦ một lượt UNet mỗi bước -> thời gian tính toán KHÔNG giảm so với mục 261.
//  * Module LoRA phải do tools/lora_attach_branch --strip-base-weights tạo từ ĐÚNG file nền (cùng tên op), đặt tên *.lora.mnn.
//
// NGỮ NGHĨA BIẾN THỂ (đã sửa trước khi giao — xem 270.3): module LoRA = ĐẦU RA NỀN + NHÁNH LoRA. Nếu UNet "nền" đã gộp sẵn LoRA của nhân vật 1
// thì module LoRA nhân vật 2 gắn lên đó sẽ chịu CẢ HAI LoRA — sai với Switch/Composite (mỗi biến thể = nền + ĐÚNG MỘT LoRA). Vì vậy mặc định
// (base_is_variant = false): nền chỉ là nguồn CHIA SẺ trọng số (phải là checkpoint thuần, không LoRA nhân vật), mỗi module LoRA là MỘT biến thể,
// k = số module. base_is_variant = true: nền cũng là biến thể 0 (nền thuần tham gia trộn như một "không-LoRA") — chỉ dùng khi muốn vậy.
// KHỞI ĐỘNG NỀN (warm_start_base, MẶC ĐỊNH TẮT — sửa ở mục 272): mọi phép đo ở 264/265 đều chạy nền trước (probe: "như MNN-LLM"), nên bản đầu của file này
// luôn chạy nền một lần trước LoRA đầu tiên. Đọc StaticModule.cpp của MNN (bản vendor trong crate mnn-sys 0.1.2): khi nạp module có `config.rearrange`,
// preRearrangeWeights lấy `base_executions` từ session của nền (`getSession()->getPipelineInfo(0)...executionCache`), khớp theo TÊN op Convolution/ConvolutionDepthwise/
// ConvInt8 rồi `onClone` — và chính nền với rearrange=true đã dựng sẵn các execution đó NGAY LÚC TẠO (tài liệu: "tạo Module sẽ tạo trước toán tử conv, sắp xếp lại trọng
// số"). Tức là chia sẻ xảy ra lúc NẠP module LoRA, không cần nền đã chạy. Chạy nền thừa = 1 lượt UNet mỗi lượt sinh (~1/số bước) nên tắt mặc định; nếu trên máy thật
// ra ảnh rác ở LƯỢT ĐẦU thì bật lại (tham số warm_start_base) — đó là bằng chứng nguồn MNN bản mới khác bản đã đọc. Lưu ý: chia sẻ chỉ áp cho conv; LayerNorm/Attention của
// module LoRA đọc trọng số từ chính file module (nhỏ).
//
// Phần logic chọn nhóm biến thể/trộn dùng lại lora_compose::activeSet/factors/blend/blendRegional (std-only, đã có test từ mục 261) nên kết quả
// giống hệt đường Interpreter khi các UNet cho cùng đầu ra.
#include <algorithm>
#include <cstddef>
#include <cstring>
#include <fstream>
#include <memory>
#include <string>
#include <vector>

#include <MNN/Interpreter.hpp>
#include <MNN/expr/Executor.hpp>
#include <MNN/expr/Expr.hpp>
#include <MNN/expr/ExprCreator.hpp>
#include <MNN/expr/Module.hpp>
#include <MNN/expr/NeuralNetWorkOp.hpp>

#include "LoraCompose.hpp"

namespace unet_module {

constexpr int kSeqLen = 77;  // SD1.5: 77 token (giống {2, 77, text_embedding_size} ở đường Interpreter)

struct StepParams {
  int step = 0;            // chỉ số bước (đếm từ 0) — đưa vào công thức Switch
  int tau = 5;
  int active_count = 1;    // m (xem LoraCompose.hpp)
  const std::vector<float>* weights = nullptr;  // trọng số điểm w_i (nullptr/rỗng = toàn 1)
  const float* regional_fields = nullptr;       // k * (h8*w8) hệ số trộn từng pixel; nullptr = trộn toàn cục
  int h8 = 0, w8 = 0;      // kích thước latent
  int hidden_dim = 768;
  int timestep = 0;
};

class UnetModuleSet {
 public:
  UnetModuleSet() = default;
  UnetModuleSet(const UnetModuleSet &) = delete;
  UnetModuleSet &operator=(const UnetModuleSet &) = delete;
  ~UnetModuleSet() { release(); }

  // Nạp UNet nền + mỗi module LoRA (config.base = nền, rearrange = true — thiếu rearrange thì base KHÔNG chia sẻ trọng số, xem 264.2).
  // Hỏng ở BẤT KỲ bước nào -> dọn sạch mọi thứ đã nạp và trả false (nơi gọi chạy như không có LoRA). `err` (nếu không null) nhận lý do.
  bool load(const std::string &base_path, const std::vector<std::string> &lora_paths, int num_threads, std::string *err,
            bool base_is_variant = false, bool warm_start_base = false) {
    release();
    base_is_variant_ = base_is_variant;
    warm_start_base_ = warm_start_base;
    if (base_path.empty() || lora_paths.empty()) return fail(err, "thiếu đường dẫn UNet nền hoặc module LoRA");
    for (const auto &p : lora_paths) {
      if (p.empty()) return fail(err, "đường dẫn module LoRA rỗng");
    }
    if (!fileExists(base_path)) return fail(err, "thiếu file UNet nền " + base_path);
    for (const auto &p : lora_paths) {
      if (!fileExists(p)) return fail(err, "thiếu file module LoRA " + p);
    }
    backend_config_ = std::make_unique<MNN::BackendConfig>();
    backend_config_->memory = MNN::BackendConfig::Memory_Low;
    backend_config_->power = MNN::BackendConfig::Power_High;
    MNN::ScheduleConfig sc;
    sc.type = MNN_FORWARD_CPU;
    sc.numThread = num_threads < 1 ? 1 : num_threads;
    sc.backendConfig = backend_config_.get();
    rt_.reset(MNN::Express::Executor::RuntimeManager::createRuntimeManager(sc));
    if (!rt_) { release(); return fail(err, "không tạo được RuntimeManager CPU"); }

    MNN::Express::Module::Config mc;
    mc.shapeMutable = true;  // đúng cấu hình MNN-LLM dùng cho LoRA (đã đo cả 4 tổ hợp shapeMutable x rearrange ở mục 264)
    mc.rearrange = true;     // BẮT BUỘC để config.base chia sẻ trọng số nền (264.2)
    const std::vector<std::string> in_names = {"sample", "timestep", "encoder_hidden_states"};
    const std::vector<std::string> out_names = {"out_sample"};
    base_.reset(MNN::Express::Module::load(in_names, out_names, base_path.c_str(), rt_, &mc));
    if (!base_) { release(); return fail(err, "Module::load UNet nền thất bại: " + base_path); }
    for (const auto &p : lora_paths) {
      MNN::Express::Module::Config mb = mc;
      mb.base = base_.get();
      std::shared_ptr<MNN::Express::Module> m(MNN::Express::Module::load(in_names, out_names, p.c_str(), rt_, &mb));
      if (!m) { release(); return fail(err, "Module::load module LoRA thất bại: " + p); }
      loras_.push_back(std::move(m));
    }
    base_ran_ = false;
    return true;
  }

  // Giải phóng theo THỨ TỰ: module LoRA (tham chiếu nền) -> nền -> RuntimeManager. An toàn khi gọi nhiều lần.
  void release() {
    while (!loras_.empty()) loras_.pop_back();
    base_.reset();
    rt_.reset();
    backend_config_.reset();
    base_ran_ = false;
    base_is_variant_ = false;
    warm_start_base_ = false;
  }

  bool loaded() const { return base_ != nullptr; }
  // số biến thể: mặc định = số module LoRA (chỉ số i = module i); base_is_variant: 1 + số module (chỉ số 0 = nền thuần)
  std::size_t count() const { return base_ ? (base_is_variant_ ? 1 + loras_.size() : loras_.size()) : 0; }
  bool baseIsVariant() const { return base_is_variant_; }
  bool warmStartBase() const { return warm_start_base_; }
  bool baseRan() const { return base_ran_; }

  // Chạy biến thể `idx` trên batch [uncond, cond]: sample (2,4,h8,w8), timestep (int32, {1}), enc (2,77,hidden_dim) -> out (2,4,h8,w8).
  bool runOne(std::size_t idx, int h8, int w8, int hidden_dim, int timestep, const float *sample_b2, const float *enc_b2, float *out_b2,
              std::string *err) {
    if (!base_) return fail(err, "chưa nạp UNet");
    if (idx >= count()) return fail(err, "chỉ số biến thể ngoài phạm vi");
    if (!sample_b2 || !enc_b2 || !out_b2) return fail(err, "con trỏ đầu vào/đầu ra null");
    if (h8 <= 0 || w8 <= 0 || hidden_dim <= 0) return fail(err, "kích thước không hợp lệ");
    const bool is_base = base_is_variant_ && idx == 0;
    if (warm_start_base_ && !is_base && !base_ran_) {
      // khởi động nền MỘT LẦN trước module LoRA đầu tiên (đầu ra bỏ đi) — chỉ khi warm_start_base (xem ghi chú đầu file)
      std::vector<float> scratch((std::size_t)2 * 4 * (std::size_t)h8 * (std::size_t)w8);
      if (!runModule(base_.get(), h8, w8, hidden_dim, timestep, sample_b2, enc_b2, scratch.data(), err)) return false;
      base_ran_ = true;
    }
    Module *m = is_base ? base_.get() : loras_[base_is_variant_ ? idx - 1 : idx].get();
    if (!runModule(m, h8, w8, hidden_dim, timestep, sample_b2, enc_b2, out_b2, err)) return false;
    if (is_base) base_ran_ = true;
    return true;
  }

 private:
  using Module = MNN::Express::Module;
  bool runModule(Module *m, int h8, int w8, int hidden_dim, int timestep, const float *sample_b2, const float *enc_b2, float *out_b2,
                 std::string *err) {
    using namespace MNN::Express;
    const std::size_t n_sample = (std::size_t)2 * 4 * (std::size_t)h8 * (std::size_t)w8;
    const std::size_t n_enc = (std::size_t)2 * kSeqLen * (std::size_t)hidden_dim;
    auto in_s = _Input({2, 4, h8, w8}, NCHW, halide_type_of<float>());
    auto in_t = _Input({1}, NCHW, halide_type_of<int>());
    auto in_e = _Input({2, kSeqLen, hidden_dim}, NCHW, halide_type_of<float>());
    std::memcpy(in_s->writeMap<float>(), sample_b2, n_sample * sizeof(float));
    in_t->writeMap<int>()[0] = timestep;
    std::memcpy(in_e->writeMap<float>(), enc_b2, n_enc * sizeof(float));
    auto outs = m->onForward({in_s, in_t, in_e});
    if (outs.size() != 1 || outs[0].get() == nullptr) return fail(err, "UNet không trả đúng 1 đầu ra");
    auto y = _Convert(outs[0], NCHW);
    const auto *info = y->getInfo();
    if (!info || (std::size_t)info->size != n_sample) return fail(err, "kích thước đầu ra UNet không khớp (cần " + std::to_string(n_sample) + ")");
    const float *p = y->readMap<float>();
    if (!p) return fail(err, "readMap đầu ra null");
    std::memcpy(out_b2, p, n_sample * sizeof(float));
    return true;
  }

 public:

  // Một bước khử nhiễu theo mục 261: chọn nhóm biến thể hoạt động (công thức 4), chạy từng UNet, trộn (công thức 5 / vùng 261.11).
  // enc_per_variant[i] = điều kiện văn bản (2,77,hidden_dim) của biến thể i (CLIP riêng hoặc chính); size phải = count().
  // (mặc định biến thể i = module LoRA i; với base_is_variant biến thể 0 = nền thuần)
  bool step(const StepParams &p, const float *sample_b2, const std::vector<const float *> &enc_per_variant, float *out_b2, std::string *err) {
    if (!base_) return fail(err, "chưa nạp UNet");
    const std::size_t k = count();
    if (enc_per_variant.size() != k) return fail(err, "số điều kiện văn bản không khớp số biến thể");
    for (const float *e : enc_per_variant) {
      if (!e) return fail(err, "điều kiện văn bản null");
    }
    const std::vector<int> act = lora_compose::activeSet(p.step, (int)k, p.tau, p.active_count);
    if (act.size() == 1) {
      return runOne((std::size_t)act[0], p.h8, p.w8, p.hidden_dim, p.timestep, sample_b2, enc_per_variant[(std::size_t)act[0]], out_b2, err);
    }
    const std::size_t n = (std::size_t)2 * 4 * (std::size_t)p.h8 * (std::size_t)p.w8;
    std::vector<std::vector<float>> bufs(act.size(), std::vector<float>(n));
    std::vector<const float *> ptrs;
    for (std::size_t j = 0; j < act.size(); ++j) {
      if (!runOne((std::size_t)act[j], p.h8, p.w8, p.hidden_dim, p.timestep, sample_b2, enc_per_variant[(std::size_t)act[j]], bufs[j].data(), err)) return false;
      ptrs.push_back(bufs[j].data());
    }
    if (p.regional_fields) {
      const std::size_t hw = (std::size_t)p.h8 * (std::size_t)p.w8;
      std::vector<const float *> fp;
      for (std::size_t j = 0; j < act.size(); ++j) fp.push_back(p.regional_fields + (std::size_t)act[j] * hw);
      lora_compose::blendRegional(ptrs, fp, hw, (std::size_t)2 * 4, out_b2);
    } else {
      static const std::vector<float> kNoWeights;
      lora_compose::blend(ptrs, lora_compose::factors(act, p.weights ? *p.weights : kNoWeights), n, out_b2);
    }
    return true;
  }

 private:
  static bool fileExists(const std::string &p) {
    std::ifstream f(p);
    return f.good();
  }
  static bool fail(std::string *err, const std::string &msg) {
    if (err) *err = msg;
    return false;
  }

  std::unique_ptr<MNN::BackendConfig> backend_config_;  // phải sống lâu hơn rt_
  std::shared_ptr<MNN::Express::Executor::RuntimeManager> rt_;
  std::shared_ptr<MNN::Express::Module> base_;
  std::vector<std::shared_ptr<MNN::Express::Module>> loras_;
  bool base_ran_ = false;
  bool base_is_variant_ = false;
  bool warm_start_base_ = false;
};

}  // namespace unet_module
