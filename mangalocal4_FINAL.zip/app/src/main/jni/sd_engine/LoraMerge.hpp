// LoraMerge.hpp — gộp NHIỀU delta LoRA vào 1 trọng số theo kiểu TIES / DARE (mục 259 TECHNICAL_STATUS.md).
//
// Vì sao có file này: applyLoRA() (SafeTensor2MNN.hpp) chỉ biết CỘNG các delta (hoặc trực giao hoá Gram-Schmidt). Khi gộp nhiều LoRA
// nhân vật, các delta cùng dấu/ngược dấu ở cùng một phần tử cộng dồn hoặc triệt tiêu nhau => nhiễu giữa các LoRA. TIES-Merging
// (Yadav et al. 2023) xử lý đúng điều đó trên CHÍNH các delta đã train, không cần train lại:
//   1. TRIM : mỗi delta chỉ giữ top-`density` phần tử có |giá trị| lớn nhất, phần còn lại về 0 (bỏ nhiễu nhỏ);
//   2. ELECT: với mỗi phần tử, dấu thắng = dấu của TỔNG các delta đã trim;
//   3. DISJOINT MEAN: chỉ lấy trung bình các delta ĐỒNG DẤU với dấu thắng (delta ngược dấu bị loại thay vì kéo giảm).
// DARE (Yu et al. 2023) là bước tuỳ chọn TRƯỚC khi trim: bỏ ngẫu nhiên phần tử với xác suất p rồi nhân phần giữ với 1/(1-p).
//
// Hàm THUẦN (không phụ thuộc xtensor/MNN) nên biên dịch và chạy thử được riêng: tools/test_lora_merge.py so với bản tham chiếu numpy.
// GIỚI HẠN THẬT: đây là kỹ thuật gộp của bài báo cho TASK VECTOR; áp dụng cho delta LoRA (ΔW = up·down) là cách dùng phổ biến nhưng
// CHƯA đo trên ảnh truyện của dự án — mật độ/độ bỏ mặc định là ước lượng, hãy chỉnh theo ảnh bạn thấy.
#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <random>
#include <utility>
#include <vector>

namespace lora_merge {

// Giá trị khớp với Kotlin (NativeBridge.sdConvertModel mergeMode): 0 = cộng như cũ, 2 = TIES. (1 = trực giao hoá do cờ orthogonal xử lý riêng.)
enum Mode : int { SUM = 0, TIES = 2 };

struct Options {
  int mode = SUM;
  float density = 0.5f;   // TIES: giữ top-density phần tử theo |x|, 0..1 (1 = không trim)
  float dare_drop = 0.0f; // DARE: xác suất bỏ ngẫu nhiên, 0 = tắt; kẹp trên 0.99
  float lambda = 1.0f;    // hệ số nhân kết quả gộp
};

// Giữ top-`density` phần tử theo |x|, phần còn lại = 0. density >= 1 hoặc NaN: không đổi; density <= 0: toàn 0.
inline void trimTopK(std::vector<float> &d, float density) {
  const size_t n = d.size();
  if (n == 0 || !(density < 1.0f)) return;  // !(x<1) bắt cả NaN lẫn >=1
  if (!(density > 0.0f)) {
    std::fill(d.begin(), d.end(), 0.0f);
    return;
  }
  // k = ceil(density·n) NHƯNG có dung sai: density là float nên 0.4f·5 ra 2.0000000298 và ceil sẽ cho 3 thay vì 2. Sai số biểu diễn của float
  // tối đa ~6e-8·density·n < 1e-7·n nên trừ 1e-7·n trước khi ceil để các giá trị "tròn" (0.2, 0.4, 0.5...) cho đúng số phần tử.
  const double nd = static_cast<double>(n);
  size_t k = static_cast<size_t>(std::ceil(static_cast<double>(density) * nd - 1e-7 * nd));
  if (k >= n) return;
  if (k == 0) k = 1;
  std::vector<float> mag(n);
  for (size_t i = 0; i < n; ++i) mag[i] = std::fabs(d[i]);
  // ngưỡng = phần tử lớn thứ k: nth_element đặt phần tử thứ (n-k) của thứ tự tăng dần đúng chỗ
  std::nth_element(mag.begin(), mag.begin() + static_cast<std::ptrdiff_t>(n - k), mag.end());
  const float thr = mag[n - k];
  for (size_t i = 0; i < n; ++i)
    if (std::fabs(d[i]) < thr) d[i] = 0.0f;
}

// DARE: bỏ ngẫu nhiên với xác suất p rồi nhân phần giữ với 1/(1-p). Tất định theo `seed` (cùng seed -> cùng kết quả trên mọi máy).
inline void dareDrop(std::vector<float> &d, float p, uint64_t seed) {
  if (!(p > 0.0f) || d.empty()) return;  // bắt cả NaN
  if (p > 0.99f) p = 0.99f;
  std::mt19937_64 rng(seed);
  const float scale = 1.0f / (1.0f - p);
  for (float &x : d) {
    // 24 bit cao của mt19937_64 -> [0,1): không dùng uniform_real_distribution vì kết quả của nó phụ thuộc thư viện chuẩn
    const float u = static_cast<float>(rng() >> 40) / 16777216.0f;
    x = (u < p) ? 0.0f : x * scale;
  }
}

// Gộp các delta CÙNG KÍCH THƯỚC. 0 delta -> rỗng; 1 delta -> trả NGUYÊN (không có xung đột để giải nên không trim/DARE làm hỏng nó).
// Delta lệch kích thước so với delta đầu bị bỏ qua (không bao giờ ghi ngoài bộ nhớ).
inline std::vector<float> tiesMerge(std::vector<std::vector<float>> deltas, const Options &o, uint64_t seed) {
  if (deltas.empty()) return {};
  const size_t n = deltas[0].size();
  std::vector<std::vector<float>> use;
  for (auto &d : deltas)
    if (d.size() == n) use.push_back(std::move(d));
  if (use.size() == 1 || n == 0) return use.empty() ? std::vector<float>() : std::move(use[0]);

  for (size_t t = 0; t < use.size(); ++t) {
    dareDrop(use[t], o.dare_drop, seed + 0x9E3779B97F4A7C15ULL * (t + 1));
    trimTopK(use[t], o.density);
  }
  std::vector<float> out(n, 0.0f);
  for (size_t i = 0; i < n; ++i) {
    float sum = 0.0f;
    for (const auto &d : use) sum += d[i];
    if (sum == 0.0f) continue;  // dấu thắng không xác định -> 0 (đúng định nghĩa sgn(0)=0 của TIES)
    float acc = 0.0f;
    int cnt = 0;
    for (const auto &d : use) {
      const float v = d[i];
      if ((v > 0.0f) == (sum > 0.0f) && v != 0.0f) {  // cùng dấu với dấu thắng
        acc += v;
        ++cnt;
      }
    }
    if (cnt > 0) out[i] = o.lambda * acc / static_cast<float>(cnt);
  }
  return out;
}

}  // namespace lora_merge
