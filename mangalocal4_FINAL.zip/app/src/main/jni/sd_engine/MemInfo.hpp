#pragma once
// mục 262 TECHNICAL_STATUS.md — ĐO RAM/THỜI GIAN thật khi nạp UNet phụ (composable LoRA) để MỘT lần chạy trên bất kỳ máy nào trả về số liệu.
// Phần LOGIC THUẦN (parseKb) chạy thử được bằng g++ (tools/test_mask_blend_meminfo.py); phần đọc /proc chỉ là vỏ mỏng quanh nó.
//  - VmRSS (/proc/self/status): bộ nhớ vật lý tiến trình đang giữ (gồm cả trang file mmap đã chạm tới).
//  - Pss  (/proc/self/smaps_rollup): phần chia theo tỉ lệ — trang dùng chung giữa các tiến trình chỉ tính một phần. Không phải máy nào cũng cho đọc
//    (Android có thể chặn) -> trả -1 và log "n/a", KHÔNG phải lỗi.
// Lưu ý đọc số: trọng số UNet được mmap nên RSS chỉ tăng khi trang được CHẠM (lượt chạy UNet đầu tiên), không phải lúc nạp. Vì vậy log đặt cả hai
// mốc: sau khi nạp và sau lượt chạy đầu — chỉ số sau mới phản ánh RAM thật của một UNet.
#include <fstream>
#include <sstream>
#include <string>

namespace mem_info {

// Tìm dòng bắt đầu bằng "<key>:" (khớp CHÍNH XÁC khoá — "Pss" không khớp "Pss_Anon") trong văn bản kiểu /proc, trả giá trị theo kB.
// -1 nếu không có khoá, không có chữ số, hoặc giá trị tràn (> 2^40 kB).
inline long long parseKb(const std::string& text, const std::string& key) {
  std::size_t pos = 0;
  while (pos <= text.size()) {
    std::size_t eol = text.find('\n', pos);
    if (eol == std::string::npos) eol = text.size();
    if (eol - pos > key.size() && text.compare(pos, key.size(), key) == 0 && text[pos + key.size()] == ':') {
      std::size_t p = pos + key.size() + 1;
      while (p < eol && (text[p] == ' ' || text[p] == '\t')) ++p;
      long long v = 0;
      bool any = false;
      while (p < eol && text[p] >= '0' && text[p] <= '9') {
        v = v * 10 + (text[p] - '0');
        any = true;
        if (v > (1LL << 40)) return -1;
        ++p;
      }
      return any ? v : -1;
    }
    if (eol >= text.size()) break;
    pos = eol + 1;
  }
  return -1;
}

inline long long readSelfKb(const char* path, const char* key) {
  std::ifstream f(path);
  if (!f.good()) return -1;
  std::stringstream ss;
  ss << f.rdbuf();
  return parseKb(ss.str(), key);
}

inline long long rssKb() { return readSelfKb("/proc/self/status", "VmRSS"); }
inline long long pssKb() { return readSelfKb("/proc/self/smaps_rollup", "Pss"); }

inline std::string fmtMb(long long kb) {
  if (kb < 0) return "n/a";
  char buf[48];
  std::snprintf(buf, sizeof(buf), "%.1f MB", (double)kb / 1024.0);
  return buf;
}

// Chênh lệch an toàn: -1 nếu một trong hai mốc không đọc được.
inline long long deltaKb(long long before, long long after) { return (before < 0 || after < 0) ? -1 : after - before; }

}  // namespace mem_info
