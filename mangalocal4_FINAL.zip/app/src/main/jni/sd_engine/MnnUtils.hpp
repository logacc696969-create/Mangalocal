#ifndef MNNUTILS_HPP
#define MNNUTILS_HPP

#include <MNN/MNNDefine.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include <MNN/Interpreter.hpp>
#include <filesystem>
#include <string>
#include <system_error>

// Returns "{model_dir}/cache", creating it if needed. Returns "" when
// model_dir is empty or directory creation fails; callers must treat that
// as "caching disabled for this run".
inline std::string ensureCacheDir(const std::string &model_dir) {
  if (model_dir.empty()) return "";
  std::filesystem::path p = std::filesystem::path(model_dir) / "cache";
  std::error_code ec;
  std::filesystem::create_directories(p, ec);
  if (ec) return "";
  return p.string();
}

// Load an MNN model via mmap + createFromBuffer instead of createFromFile.
// createFromFile reads the whole .mnn in 4 KB chunks and then merges them into
// one contiguous buffer, transiently holding ~2x the model size in anonymous
// (non-reclaimable) memory. Mapping the file read-only keeps that source as
// clean, file-backed pages the kernel can reclaim under pressure, so the peak
// anonymous footprint during load drops to the single owned buffer MNN copies
// into. createFromBuffer copies the bytes, so the mapping can be released right
// away. Falls back to createFromFile on any mmap-path failure.
inline MNN::Interpreter *createMnnInterpreterMmap(const char *path) {
  int fd = open(path, O_RDONLY);
  if (fd < 0) {
    return MNN::Interpreter::createFromFile(path);
  }
  struct stat st{};
  if (0 != fstat(fd, &st) || st.st_size <= 0) {
    close(fd);
    return MNN::Interpreter::createFromFile(path);
  }
  size_t size = static_cast<size_t>(st.st_size);
  void *mapped = mmap(nullptr, size, PROT_READ, MAP_PRIVATE, fd, 0);
  // The mapping holds its own file reference, so the fd can be closed now.
  close(fd);
  if (MAP_FAILED == mapped) {
    return MNN::Interpreter::createFromFile(path);
  }
  // MNN copies the whole buffer once, sequentially; hint readahead to match.
  madvise(mapped, size, MADV_SEQUENTIAL);
  MNN::Interpreter *interpreter =
      MNN::Interpreter::createFromBuffer(mapped, size);
  munmap(mapped, size);
  if (interpreter) {
    // createFromFile sets a default external weight path; createFromBuffer does
    // not. Mirror it so models that store weights in a companion ".weight" file
    // still resolve them at session creation. Harmless when no such file
    // exists.
    interpreter->setExternalFile((std::string(path) + ".weight").c_str());
  }
  return interpreter;
}

// Session creation options shared by every MNN model in the pipeline.
// CPU: 4 threads, low-memory, high-power. OpenCL: fast tuning + buffer mode
// with low precision, plus an on-disk tuning cache when cache_file is set.
//
// allow_npu (mục 60 TECHNICAL_STATUS.md — "cơ chế fallback NPU->GPU->CPU
// thật cho diffusion, giống cơ chế đã có sẵn cho LLM"): mặc định FALSE,
// hoàn toàn tương thích ngược (không đổi hành vi bất kỳ ai chưa bật). BẬT
// -> createMnnSession() tự thử QNN (qua forward type dùng CHUNG với CoreML/
// NNAPI trong MNN — xem createMnnSession() bên dưới, ĐÃ TRA XÁC NHẬN THẬT,
// không đoán) TRƯỚC use_opencl/CPU.
struct MnnSessionOptions {
  bool use_opencl = false;
  bool allow_npu = false;
  // require_npu (mục 64 TECHNICAL_STATUS.md — "SD1.5 bắt buộc phải dùng
  // NPU, khác SDXL vẫn được fallback GPU"). Mặc định FALSE = giữ nguyên
  // cascade NPU->GPU->CPU cũ (mục 60), hoàn toàn tương thích ngược. Khi
  // TRUE và allow_npu cũng TRUE: nếu tạo session NPU thất bại,
  // createMnnSession() trả nullptr NGAY — KHÔNG rơi tiếp xuống
  // use_opencl/CPU, đúng tinh thần "bắt buộc NPU thật, không có NPU thì
  // không chạy" (giống cách local-dream phân phối RIÊNG gói model NPU-only
  // cho Snapdragon 8 Gen1+, không âm thầm chạy CPU thay thế). Vô nghĩa nếu
  // allow_npu=false (không có nhánh NPU nào để yêu cầu).
  bool require_npu = false;
  std::string cache_file;  // OpenCL tuning cache path ("" = no cache file)
  int num_threads = 4;
};

// Creates a session with the standard pipeline configuration. The interpreter
// keeps no reference to the local configs after createSession returns.
//
// FALLBACK NPU->GPU->CPU (mục 60 TECHNICAL_STATUS.md) — nguồn THẬT đã tra
// trước khi viết (KHÔNG đoán tên hằng số):
//   - Tài liệu chính thức MNN (github.com/alibaba/MNN/wiki/npu) xác nhận
//     nguyên văn: "由于QNN、CoreML与NNAPI在MNN中共用同一个Backend Type"
//     ("QNN, CoreML, NNAPI dùng CHUNG 1 Backend Type trong MNN") — cả 3
//     dùng CHUNG giá trị forward type, KHÔNG có `MNN_FORWARD_QNN` riêng.
//   - `include/MNN/MNNForwardType.h` (đọc trực tiếp source thật, không suy
//     diễn): `MNN_FORWARD_NN = 5 /*Android NNAPI or CoreML for ios*/` — đây
//     CHÍNH LÀ ô dùng chung đó (comment gốc chỉ nhắc NNAPI/CoreML vì file
//     header có TRƯỚC khi MNN thêm QNN, nhưng theo đúng tài liệu NPU chính
//     thức, QNN CŨNG dùng giá trị NÀY khi build với MNN_QNN=ON — 3 cờ CMake
//     MNN_QNN/MNN_COREML/MNN_NNAPI loại trừ lẫn nhau lúc build, xem
//     CMakeLists.txt, đúng với việc chúng chung 1 backend type).
//   - `MNN_CONVERT_QNN = 32` (cũng trong file header đó) là giá trị KHÁC
//     hẳn, dùng cho converter OFFLINE (chuyển đồ thị .mnn sang QNN lúc build
//     model, không phải forward type lúc RUNTIME) — KHÔNG dùng nhầm giá trị
//     này ở đây.
//   - `createSession()` của `MNN::Interpreter` trả `nullptr` khi backend
//     không tạo được (KHÔNG throw C++ exception — khác hẳn contract của
//     MNN-LLM's `Llm::load()` dùng try/catch trong jni_bridge.cpp) — cascade
//     ở đây dùng kiểm tra `nullptr`, ĐÚNG theo contract thật của API này,
//     không copy nhầm pattern try/catch từ LLM.
inline MNN::Session *createMnnSession(MNN::Interpreter *interpreter,
                                      const MnnSessionOptions &opts) {
  MNN::BackendConfig backendConfig;
  backendConfig.power = MNN::BackendConfig::Power_High;

  if (opts.allow_npu) {
    MNN::ScheduleConfig npuConfig;
    MNN::BackendConfig npuBackendConfig;
    npuBackendConfig.power = MNN::BackendConfig::Power_High;
    npuConfig.type = MNN_FORWARD_NN;  // ô dùng chung QNN/CoreML/NNAPI, xem chú thích trên
    npuConfig.backendConfig = &npuBackendConfig;
    MNN::Session *npuSession = interpreter->createSession(npuConfig);
    if (npuSession) {
      MNN_PRINT("[MangaLocal] NPU (QNN/backend chung) tao session THANH CONG\n");
      return npuSession;
    }
    if (opts.require_npu) {
      // mục 64 TECHNICAL_STATUS.md — model đánh dấu npu_required=true:
      // KHÔNG rơi xuống OpenCL/CPU. Trả nullptr thẳng, để lỗi nổi lên rõ
      // ràng ở tầng gọi (PipelineSd15Cpu/PipelineSdxlCpu đã throw
      // std::runtime_error khi session null — xem beginDenoise()), thay vì
      // âm thầm chạy CPU/GPU chậm mà người dùng tưởng nhầm là đang dùng NPU.
      MNN_PRINT("[MangaLocal] NPU BAT BUOC (require_npu=true) nhung khong kha dung -> TU CHOI, KHONG roi xuong OpenCL/CPU\n");
      return nullptr;
    }
    MNN_PRINT("[MangaLocal] NPU khong kha dung, roi xuong OpenCL/CPU\n");
    // KHÔNG return — rơi tiếp xuống nhánh use_opencl/CPU bên dưới, đúng
    // cascade NPU->GPU->CPU.
  }

  MNN::ScheduleConfig config;
  if (opts.use_opencl) {
    if (!opts.cache_file.empty()) {
      interpreter->setCacheFile(opts.cache_file.c_str());
    }
    config.type = MNN_FORWARD_OPENCL;
    config.mode = MNN_GPU_MEMORY_BUFFER | MNN_GPU_TUNING_FAST;
    backendConfig.precision = MNN::BackendConfig::Precision_Low;
    config.backendConfig = &backendConfig;
    MNN::Session *glSession = interpreter->createSession(config);
    if (glSession) return glSession;
    if (opts.allow_npu) MNN_PRINT("[MangaLocal] OpenCL cung khong kha dung, roi xuong CPU\n");
    // Rơi tiếp xuống CPU bên dưới — KHÔNG return nullptr ngay, giữ đúng
    // tinh thần cascade (trước đây use_opencl=true mà fail thì trả nullptr
    // luôn, giờ thử thêm CPU trước khi bỏ cuộc — thay đổi hành vi NHỎ so
    // với bản cũ, nhưng hợp lý hơn: "yêu cầu GPU nhưng máy không có" không
    // nên làm cả model không chạy được nếu CPU vẫn chạy được).
  }

  MNN::ScheduleConfig cpuConfig;
  cpuConfig.type = MNN_FORWARD_CPU;
  cpuConfig.numThread = opts.num_threads;
  MNN::BackendConfig cpuBackendConfig;
  cpuBackendConfig.memory = MNN::BackendConfig::Memory_Low;
  cpuBackendConfig.power = MNN::BackendConfig::Power_High;
  cpuConfig.backendConfig = &cpuBackendConfig;
  return interpreter->createSession(cpuConfig);
}

#endif  // MNNUTILS_HPP
