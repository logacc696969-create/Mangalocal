#ifndef PIPELINESD15CPU_HPP
#define PIPELINESD15CPU_HPP

#include <MNN/Interpreter.hpp>
#include <chrono>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "Config.hpp"
#include "LoraCompose.hpp"   // mục 261 — LoRA Switch/Composite
#include "MemInfo.hpp"       // mục 262 — đo RAM/thời gian khi nạp UNet phụ
#include "MnnUtils.hpp"
#include "Pipeline.hpp"
#ifdef MANGALOCAL_LORA_MODULE
#include "UnetModule.hpp"  // mục 270 — LoRA tách rời qua MNN Module (mặc định KHÔNG biên dịch)
#endif

// sd15cpu: the whole pipeline runs on MNN (CPU or OpenCL). Nothing stays
// resident between requests -- every stage creates its interpreter from the
// mmap'd model, runs, and releases, keeping idle memory minimal.
class PipelineSd15Cpu : public Pipeline {
 public:
  PipelineSd15Cpu(TextEncoder &text_encoder, const std::string &model_dir,
                  std::string clip_path, std::string unet_path,
                  std::string vae_decoder_path, std::string vae_encoder_path,
                  bool use_v_pred)
      : Pipeline(text_encoder, model_dir, /*sdxl=*/false, use_v_pred),
        clip_path_(std::move(clip_path)),
        unet_path_(std::move(unet_path)),
        vae_decoder_path_(std::move(vae_decoder_path)),
        vae_encoder_path_(std::move(vae_encoder_path)) {}

  bool initialize() override { return true; }

  bool supportsImg2Img() const override { return !vae_encoder_path_.empty(); }

  // mục 270 — cho phép đường MODULE LoRA (*.lora.mnn, xem UnetModule.hpp). Mặc định TẮT; CHỈ mnn_diffusion_pipeline.cpp bật cho pipeline SD1.5 THƯỜNG.
  // Lớp con (Augmented/Regional/GLIGEN/...) KHÔNG bật vì UNet của chúng có input phụ mà đường Module không nạp.
  void enableUnetModules(bool on) { unet_modules_allowed_ = on; }

 protected:
  bool canSkipUncond() const override { return false; }
  bool previewSupported() const override { return false; }

  void encodeText(const ProcessedPromptPair &prompts, bool need_negative,
                  bool need_positive, Conditioning &cond) override {
    encodeTextWith(clip_path_, prompts, need_negative, need_positive, cond);
  }

  // Thân cũ của encodeText, tham số hoá theo đường dẫn CLIP để dùng chung cho CLIP riêng của từng LoRA (mục 261.14).
  void encodeTextWith(const std::string &clip_path, const ProcessedPromptPair &prompts, bool need_negative,
                      bool need_positive, Conditioning &cond) {
    MNN::Interpreter *interpreter =
        createMnnInterpreterMmap(clip_path.c_str());
    if (!interpreter)
      throw std::runtime_error(
          "Failed to create temporary MNN CLIP interpreter!");

    MnnSessionOptions opts;  // CLIP always runs on CPU
    MNN::Session *session = createMnnSession(interpreter, opts);
    if (!session) {
      delete interpreter;
      throw std::runtime_error("Failed to create temporary MNN CLIP session!");
    }

    auto input = interpreter->getSessionInput(session, "input_embedding");
    interpreter->resizeTensor(input, {1, 77, text_embedding_size});
    interpreter->resizeSession(session);
    interpreter->releaseModel();

    auto run_side = [&](const std::vector<float> &embeddings, float *dst) {
      memcpy(input->host<float>(), embeddings.data(),
             77 * text_embedding_size * sizeof(float));
      interpreter->runSession(session);
      auto out = interpreter->getSessionOutput(session, "last_hidden_state");
      memcpy(dst, out->host<float>(), 77 * text_embedding_size * sizeof(float));
    };

    if (need_negative) run_side(prompts.negative_embeddings, cond.negHidden());
    if (need_positive) run_side(prompts.positive_embeddings, cond.posHidden());

    interpreter->releaseSession(session);
    delete interpreter;
  }

  void vaeEncode(const GenerationRequest &req, const float *image, float *mean,
                 float *std_dev) override {
    MNN::Interpreter *interpreter =
        createMnnInterpreterMmap(vae_encoder_path_.c_str());
    if (!interpreter) throw std::runtime_error("Failed MNN VAE Enc create");

    MNN::Session *session =
        createMnnSession(interpreter, sessionOptions(req, "vae_enc_cache"));
    if (!session) {
      delete interpreter;
      throw std::runtime_error("Failed create temp MNN VAE Enc session!");
    }

    auto input = interpreter->getSessionInput(session, "input");
    interpreter->resizeTensor(input, {1, 3, req.height, req.width});
    interpreter->resizeSession(session);
    if (req.use_opencl) interpreter->updateCacheFile(session);
    interpreter->releaseModel();

    auto input_nchw_tensor = new MNN::Tensor(input, MNN::Tensor::CAFFE);
    auto mean_t = interpreter->getSessionOutput(session, "mean");
    auto std_t = interpreter->getSessionOutput(session, "std");
    auto mean_nchw_tensor = new MNN::Tensor(mean_t, MNN::Tensor::CAFFE);
    auto std_nchw_tensor = new MNN::Tensor(std_t, MNN::Tensor::CAFFE);

    size_t image_count = (size_t)3 * req.height * req.width;
    size_t latent_count = (size_t)4 * (req.height / 8) * (req.width / 8);
    memcpy(input_nchw_tensor->host<float>(), image,
           image_count * sizeof(float));
    input->copyFromHostTensor(input_nchw_tensor);
    interpreter->runSession(session);

    mean_t->copyToHostTensor(mean_nchw_tensor);
    std_t->copyToHostTensor(std_nchw_tensor);
    memcpy(mean, mean_nchw_tensor->host<float>(), latent_count * sizeof(float));
    memcpy(std_dev, std_nchw_tensor->host<float>(),
           latent_count * sizeof(float));

    delete input_nchw_tensor;
    delete mean_nchw_tensor;
    delete std_nchw_tensor;

    interpreter->releaseSession(session);
    delete interpreter;
  }

  void beginDenoise(const GenerationRequest &req) override {
    // mục 270 — biến thể dạng MODULE LoRA (*.lora.mnn): UNet chính cũng chạy bằng Module (để làm `base`), KHÔNG tạo Interpreter/Session riêng.
    // Nếu không nạp được thì TUYỆT ĐỐI không rơi về đường UNet-đầy-đủ với các đường dẫn .lora.mnn (file đó không mang trọng số nền -> ảnh rác):
    // chạy UNet chính, không trộn LoRA.
    modules_active_ = false;
    {
      LoraComposeState st0;
      if (lora_compose::snapshot(st0) && lora_compose::moduleMode(st0.extra_unets) != lora_compose::ModuleMode::None) {
        if (beginDenoiseWithModules(req, st0)) return;
        std::cerr << "LoRA module: không dùng được module LoRA -> chạy UNet chính, KHÔNG trộn LoRA.\n";
      }
    }
    unet_interpreter_ = createMnnInterpreterMmap(unet_path_.c_str());
    if (!unet_interpreter_)
      throw std::runtime_error(
          "Failed to create temporary MNN UNET interpreter!");

    unet_session_ =
        createMnnSession(unet_interpreter_, sessionOptions(req, "unet_cache"));
    if (!unet_session_)
      throw std::runtime_error("Failed to create temporary MNN UNET session!");

    auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
    auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
    auto enc = unet_interpreter_->getSessionInput(unet_session_,
                                                  "encoder_hidden_states");

    unet_interpreter_->resizeTensor(samp,
                                    {2, 4, req.height / 8, req.width / 8});
    unet_interpreter_->resizeTensor(ts, {1});
    unet_interpreter_->resizeTensor(enc, {2, 77, text_embedding_size});
    unet_interpreter_->resizeSession(unet_session_);
    if (req.use_opencl) unet_interpreter_->updateCacheFile(unet_session_);

    unet_interpreter_->releaseModel();

    // mục 261 — nạp thêm các UNet biến thể (mỗi LoRA một UNet) nếu Kotlin đã bật LoRA Switch/Composite (loraComposeSet).
    // Hỏng ở BẤT KỲ biến thể nào -> giải phóng hết biến thể phụ và chạy như cũ với UNet chính (không làm hỏng lượt sinh ảnh).
    releaseComposeExtras();
    step_counter_ = 0;
    LoraComposeState st;
    if (lora_compose::snapshot(st) && lora_compose::moduleMode(st.extra_unets) == lora_compose::ModuleMode::None) setupComposeExtras(req, st);
  }

  // mục 261.14 — điều kiện văn bản RIÊNG cho từng UNet biến thể phụ, mã hoá bằng CLIP của chính LoRA đó. Chạy sau encodePrompts nên không dính cache CLIP
  // trên đĩa (cache khoá theo model chính). Thiếu CLIP/lỗi -> biến thể đó dùng điều kiện CHÍNH (không làm hỏng lượt sinh).
  void onConditioningReady(const GenerationRequest &req) override {
    compose_extra_conds_.clear();
    compose_conds_usable_.clear();
    LoraComposeState st;
    if (!lora_compose::snapshot(st) || st.extra_clips.empty()) return;
    if (lora_compose::moduleMode(st.extra_unets) != lora_compose::ModuleMode::None && !modules_active_) return;  // mục 270: module không nạp được -> không mã hoá CLIP riêng vô ích
    const auto clip_t0 = std::chrono::steady_clock::now();  // mục 262 — thời gian mã hoá CLIP riêng
    ProcessedPromptPair processed = text_encoder_.processPromptPair(req.prompt, req.negative_prompt, textSeqLen());
    for (size_t i = 0; i < st.extra_unets.size(); ++i) {
      Conditioning c;
      bool ok = false;
      const std::string &clip = i < st.extra_clips.size() ? st.extra_clips[i] : std::string();
      if (!clip.empty()) {
        try {
          { std::ifstream f(clip); if (!f.good()) throw std::runtime_error("thiếu file " + clip); }
          c.hidden_dim = textHiddenDim();
          c.pooled_dim = textPooledDim();
          c.seq_len = textSeqLen();
          c.hidden.assign((size_t)2 * c.seq_len * c.hidden_dim, 0.0f);
          encodeTextWith(clip, processed, true, true, c);
          ok = true;
        } catch (const std::exception &e) {
          std::cerr << "LoRA compose: mã hoá bằng CLIP riêng của biến thể " << (i + 1) << " lỗi (" << e.what()
                    << ") — dùng CLIP chính cho biến thể này.\n";
        }
      }
      compose_extra_conds_.push_back(std::move(c));
      compose_conds_usable_.push_back(ok);
    }
    int n = 0; for (bool u : compose_conds_usable_) n += u ? 1 : 0;
    std::cout << "LoRA compose: CLIP riêng cho " << n << "/" << compose_conds_usable_.size() << " biến thể phụ, mất "
              << std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - clip_t0).count() << " ms\n";
  }

  // Chạy 1 UNet (interp, sess) trên batch [uncond, cond] — thân hàm cũ của runUnetStep, tách ra để dùng cho từng biến thể.
  void runOneUnet(MNN::Interpreter *interp, MNN::Session *sess, const GenerationRequest &req,
                  const float *latents_batch2, int timestep, Conditioning &cond,
                  float *out_batch2) {
    auto samp = interp->getSessionInput(sess, "sample");
    auto ts = interp->getSessionInput(sess, "timestep");
    auto enc = interp->getSessionInput(sess, "encoder_hidden_states");

    auto samp_nchw_tensor = new MNN::Tensor(samp, MNN::Tensor::CAFFE);
    auto ts_nchw_tensor = new MNN::Tensor(ts, MNN::Tensor::CAFFE);
    auto enc_nchw_tensor = new MNN::Tensor(enc, MNN::Tensor::CAFFE);

    size_t batch2_count = (size_t)2 * 4 * (req.height / 8) * (req.width / 8);

    // Copy both batches (negative and positive) at once.
    memcpy(samp_nchw_tensor->host<float>(), latents_batch2,
           batch2_count * sizeof(float));
    memcpy(ts_nchw_tensor->host<int>(), &timestep, sizeof(int));
    memcpy(enc_nchw_tensor->host<float>(), cond.hidden.data(),
           cond.hidden.size() * sizeof(float));

    samp->copyFromHostTensor(samp_nchw_tensor);
    ts->copyFromHostTensor(ts_nchw_tensor);
    enc->copyFromHostTensor(enc_nchw_tensor);

    // Hook ảo (xem onBeforeUnetRun): nhận ĐÚNG session đang chạy, nên dùng được cho cả biến thể phụ.
    onBeforeUnetRun(interp, sess);

    // Single batch inference for both negative and positive conditions.
    interp->runSession(sess);

    auto output = interp->getSessionOutput(sess, "out_sample");
    output->copyToHostTensor(samp_nchw_tensor);
    memcpy(out_batch2, samp_nchw_tensor->host<float>(),
           batch2_count * sizeof(float));

    delete samp_nchw_tensor;
    delete ts_nchw_tensor;
    delete enc_nchw_tensor;
  }

  // mục 262 — RSS sau khi một nhóm UNet đã chạy (trang trọng số đã chạm). Chỉ ghi ở bước đầu và đầu chu kỳ Switch thứ hai để không spam log.
  void logMemAfterRun(bool on) {
    if (!on) return;
    const long long rss = mem_info::rssKb();
    std::cout << "LoRA compose [RAM] sau lượt chạy UNet (bước " << step_counter_ << "): RSS " << mem_info::fmtMb(rss) << ", PSS " << mem_info::fmtMb(mem_info::pssKb())
              << " (+" << mem_info::fmtMb(mem_info::deltaKb(compose_mem_rss_before_run_, rss)) << " so với trước lượt chạy đầu)\n";
  }

  void releaseComposeExtras() {
    for (auto &e : compose_extras_) {
      if (e.session && e.interp) e.interp->releaseSession(e.session);
      delete e.interp;
    }
    compose_extras_.clear();
    compose_active_count_ = 1;
    compose_tau_ = 5;
    compose_weights_.clear();
    compose_regional_ = false;
    compose_fields_.clear();
  }

  void setupComposeExtras(const GenerationRequest &req, const LoraComposeState &st) {
    // mục 262 — đo RAM/thời gian: RSS/PSS trước và sau mỗi UNet phụ. Nhớ: trọng số mmap chỉ vào RSS khi trang được CHẠM — con số đáng tin
    // nhất là dòng "sau lượt chạy đầu" (xem runUnetStep), dòng này chỉ cho chi phí nạp (session + bộ nhớ trung gian).
    const long long rss_start = mem_info::rssKb(), pss_start = mem_info::pssKb();
    const auto t_start = std::chrono::steady_clock::now();
    std::cout << "LoRA compose [RAM] trước khi nạp UNet phụ: RSS " << mem_info::fmtMb(rss_start) << ", PSS " << mem_info::fmtMb(pss_start) << "\n";
    compose_mem_rss_before_run_ = -1;
    int idx = 0;
    for (const auto &path : st.extra_unets) {
      ++idx;
      MNN::Interpreter *ip = nullptr;
      MNN::Session *se = nullptr;
      bool ok = false;
      do {
        { std::ifstream f(path); if (!f.good()) { std::cerr << "LoRA compose: thiếu file UNet biến thể " << path << "\n"; break; } }
        ip = createMnnInterpreterMmap(path.c_str());
        if (!ip) break;
        const std::string stage = "unet_cache_lora" + std::to_string(idx);
        se = createMnnSession(ip, sessionOptions(req, stage.c_str()));
        if (!se) break;
        auto samp = ip->getSessionInput(se, "sample");
        auto ts = ip->getSessionInput(se, "timestep");
        auto enc = ip->getSessionInput(se, "encoder_hidden_states");
        if (!samp || !ts || !enc) { std::cerr << "LoRA compose: UNet biến thể thiếu input chuẩn: " << path << "\n"; break; }
        ip->resizeTensor(samp, {2, 4, req.height / 8, req.width / 8});
        ip->resizeTensor(ts, {1});
        ip->resizeTensor(enc, {2, 77, text_embedding_size});
        ip->resizeSession(se);
        if (req.use_opencl) ip->updateCacheFile(se);
        ip->releaseModel();
        ok = true;
      } while (false);
      if (!ok) {
        if (ip && se) ip->releaseSession(se);
        delete ip;
        std::cerr << "LoRA compose: KHÔNG nạp được biến thể " << idx << " (" << path << ") — chạy với UNet chính, không trộn LoRA.\n";
        releaseComposeExtras();
        return;
      }
      compose_extras_.push_back({ip, se});
      const long long rss_now = mem_info::rssKb();
      std::cout << "LoRA compose [RAM] nạp xong UNet phụ " << idx << ": RSS " << mem_info::fmtMb(rss_now) << " (+" << mem_info::fmtMb(mem_info::deltaKb(rss_start, rss_now))
                << " so với trước khi nạp), tổng thời gian nạp " << std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t_start).count() << " ms\n";
    }
    compose_mem_rss_before_run_ = mem_info::rssKb();  // mốc để so sau lượt chạy UNet đầu tiên
    compose_active_count_ = st.active_count;
    compose_tau_ = st.tau;
    compose_weights_ = st.weights;
    // mục 261.11 — Regional Composite: cần mask cho ĐÚNG k UNet; sai/thiếu -> bỏ mask, chạy Switch/Composite thường (không làm hỏng lượt sinh).
    compose_regional_ = false;
    compose_fields_.clear();
    const int kk = (int)compose_extras_.size() + 1;
    if (!st.masks.empty()) {
      if (st.mask_k == kk) {
        compose_fields_ = lora_compose::regionalFields(st.masks, kk, st.mask_w, st.mask_h, req.width / 8, req.height / 8, st.weights);
      }
      if (!compose_fields_.empty()) {
        compose_regional_ = true;
        compose_active_count_ = kk;  // vùng = trộn ĐỦ k UNet mỗi bước
        std::cout << "LoRA compose: REGIONAL — trộn theo mask vùng từng nhân vật (" << kk << " UNet mỗi bước)\n";
      } else {
        std::cerr << "LoRA compose: mask vùng không hợp lệ (k=" << st.mask_k << " cần " << kk << ") — dùng Switch/Composite thường.\n";
      }
    }
    std::cout << "LoRA compose: bật — " << (compose_extras_.size() + 1) << " UNet, nhóm hoạt động mỗi bước = " << compose_active_count_
              << (compose_active_count_ == 1 ? " (Switch" : (compose_active_count_ >= (int)compose_extras_.size() + 1 ? " (Composite" : " (kết hợp"))
              << ", tau=" << compose_tau_ << ")\n";
  }

  // mục 270 — nạp UNet nền + các module LoRA bằng MNN Module (CPU). Trả false -> nơi gọi chạy UNet chính, không trộn LoRA.
  bool beginDenoiseWithModules(const GenerationRequest &req, const LoraComposeState &st) {
#ifdef MANGALOCAL_LORA_MODULE
    if (!unet_modules_allowed_) { std::cerr << "LoRA module: pipeline này không hỗ trợ module LoRA (chỉ SD1.5 thường).\n"; return false; }
    if (lora_compose::moduleMode(st.extra_unets) != lora_compose::ModuleMode::All) {
      std::cerr << "LoRA module: lẫn UNet đầy đủ và module .lora.mnn trong cùng một lượt — không hỗ trợ.\n";
      return false;
    }
    if (req.require_npu) { std::cerr << "LoRA module: model yêu cầu NPU bắt buộc, đường module chỉ chạy CPU.\n"; return false; }
    if (req.use_opencl || req.use_npu)
      std::cerr << "LoRA module: đường module chỉ chạy CPU (cơ chế chia sẻ trọng số chưa kiểm trên OpenCL/NPU) — bỏ qua GPU/NPU cho lượt này.\n";
    const long long rss_start = mem_info::rssKb();
    const auto t0 = std::chrono::steady_clock::now();
    auto set = std::make_unique<unet_module::UnetModuleSet>();
    std::string err;
    if (!set->load(unet_path_, st.extra_unets, 4, &err, /*base_is_variant=*/false)) { std::cerr << "LoRA module: " << err << "\n"; return false; }
    releaseComposeExtras();
    step_counter_ = 0;
    unet_modules_ = std::move(set);
    modules_active_ = true;
    const long long rss_now = mem_info::rssKb();
    std::cout << "LoRA module [RAM] nạp xong nền dùng chung + " << unet_modules_->count() << " module LoRA: RSS " << mem_info::fmtMb(rss_now) << " (+"
              << mem_info::fmtMb(mem_info::deltaKb(rss_start, rss_now)) << "), mất "
              << std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count() << " ms\n";
    compose_mem_rss_before_run_ = rss_now;
    compose_active_count_ = st.active_count;
    compose_tau_ = st.tau;
    compose_weights_ = st.weights;
    compose_regional_ = false;
    compose_fields_.clear();
    const int kk = (int)unet_modules_->count();
    if (!st.masks.empty()) {
      if (st.mask_k == kk) compose_fields_ = lora_compose::regionalFields(st.masks, kk, st.mask_w, st.mask_h, req.width / 8, req.height / 8, st.weights);
      if (!compose_fields_.empty()) {
        compose_regional_ = true;
        compose_active_count_ = kk;
        std::cout << "LoRA module: REGIONAL — trộn theo mask vùng (" << kk << " UNet mỗi bước)\n";
      } else {
        std::cerr << "LoRA module: mask vùng không hợp lệ (k=" << st.mask_k << " cần " << kk << ") — dùng Switch/Composite thường.\n";
      }
    }
    std::cout << "LoRA module: bật — " << kk << " biến thể (mỗi biến thể = nền + MỘT module LoRA; nền chỉ để chia sẻ trọng số), nhóm hoạt động mỗi bước = " << compose_active_count_
              << ", tau=" << compose_tau_ << "\n";
    return true;
#else
    (void)req; (void)st;
    std::cerr << "LoRA module: bản build này KHÔNG bật MANGALOCAL_LORA_MODULE (CMake -DMANGALOCAL_ENABLE_LORA_MODULE=ON).\n";
    return false;
#endif
  }

  void runUnetStepModules(const GenerationRequest &req, const float *latents_batch2, int timestep, Conditioning &cond, float *out_batch2) {
#ifdef MANGALOCAL_LORA_MODULE
    const size_t k = unet_modules_->count();
    std::vector<const float *> enc(k);
    for (size_t i = 0; i < k; ++i) {
      // biến thể i = module LoRA i = phần tử phụ thứ i của extra_unets/extra_clips -> condSource(i + 1) (quy ước cũ: 0 = UNet chính)
      const int src = lora_compose::condSource((int)i + 1, compose_conds_usable_);
      Conditioning &c = src >= 0 ? compose_extra_conds_[(size_t)src] : cond;
      if (c.hidden.size() != (size_t)2 * unet_module::kSeqLen * text_embedding_size)
        throw std::runtime_error("LoRA module: điều kiện văn bản sai kích thước");
      enc[i] = c.hidden.data();
    }
    unet_module::StepParams p;
    p.step = step_counter_;
    p.tau = compose_tau_;
    p.active_count = compose_active_count_;
    p.weights = &compose_weights_;
    p.regional_fields = compose_regional_ ? compose_fields_.data() : nullptr;
    p.h8 = req.height / 8;
    p.w8 = req.width / 8;
    p.hidden_dim = text_embedding_size;
    p.timestep = timestep;
    ++step_counter_;
    std::string err;
    if (!unet_modules_->step(p, latents_batch2, enc, out_batch2, &err)) throw std::runtime_error("LoRA module: " + err);
    logMemAfterRun(step_counter_ == 1 || step_counter_ == (int)compose_tau_ * (int)k + 1);
#else
    (void)req; (void)latents_batch2; (void)timestep; (void)cond; (void)out_batch2;
    throw std::runtime_error("LoRA module: bản build không bật MANGALOCAL_LORA_MODULE");
#endif
  }

  void runUnetStep(const GenerationRequest &req, const float *latents_batch2,
                   float timestep_f, bool /*skip_uncond*/, Conditioning &cond,
                   float *out_batch2) override {
    const int timestep = static_cast<int>(timestep_f);
    if (modules_active_) {  // mục 270 — đường Module (UNet nền + module LoRA dùng chung trọng số)
      runUnetStepModules(req, latents_batch2, timestep, cond, out_batch2);
      return;
    }
    if (compose_extras_.empty()) {  // đường cũ — không đổi hành vi khi không bật LoRA compose
      runOneUnet(unet_interpreter_, unet_session_, req, latents_batch2, timestep, cond, out_batch2);
      return;
    }
    // mục 261 — LoRA Switch/Composite: chọn nhóm biến thể hoạt động ở bước này (công thức 4 của bài), chạy từng UNet rồi trộn.
    const int k = 1 + (int)compose_extras_.size();
    const std::vector<int> act = lora_compose::activeSet(step_counter_, k, compose_tau_, compose_active_count_);
    ++step_counter_;
    // mục 262 — sau bước ĐẦU TIÊN chạy xong (mọi UNet trong nhóm đã chạm trọng số) ghi RSS thật. Switch chỉ chạm UNet của nhóm đầu; UNet còn lại chạm khi tới lượt.
    const bool log_mem_after = (step_counter_ == 1 || step_counter_ == (int)compose_tau_ * k + 1);
    auto pick = [&](int idx, MNN::Interpreter *&ip, MNN::Session *&se) {
      if (idx <= 0) { ip = unet_interpreter_; se = unet_session_; }
      else { ip = compose_extras_[(size_t)idx - 1].interp; se = compose_extras_[(size_t)idx - 1].session; }
    };
    // mục 261.14 — điều kiện văn bản của biến thể: CLIP riêng nếu có, không thì điều kiện chính
    auto condFor = [&](int idx) -> Conditioning & {
      const int src = lora_compose::condSource(idx, compose_conds_usable_);
      return src >= 0 ? compose_extra_conds_[(size_t)src] : cond;
    };
    if (act.size() == 1) {
      MNN::Interpreter *ip; MNN::Session *se; pick(act[0], ip, se);
      runOneUnet(ip, se, req, latents_batch2, timestep, condFor(act[0]), out_batch2);
      logMemAfterRun(log_mem_after);
      return;
    }
    const size_t batch2_count = (size_t)2 * 4 * (req.height / 8) * (req.width / 8);
    std::vector<std::vector<float>> bufs(act.size(), std::vector<float>(batch2_count));
    std::vector<const float *> ptrs;
    for (size_t j = 0; j < act.size(); ++j) {
      MNN::Interpreter *ip; MNN::Session *se; pick(act[j], ip, se);
      runOneUnet(ip, se, req, latents_batch2, timestep, condFor(act[j]), bufs[j].data());
      ptrs.push_back(bufs[j].data());
    }
    if (compose_regional_) {
      // mục 261.11 — mỗi pixel trộn theo mask vùng của từng biến thể (hàng act[j] của compose_fields_)
      const size_t hw = (size_t)(req.height / 8) * (size_t)(req.width / 8);
      std::vector<const float *> fp;
      for (size_t j = 0; j < act.size(); ++j) fp.push_back(compose_fields_.data() + (size_t)act[j] * hw);
      lora_compose::blendRegional(ptrs, fp, hw, (size_t)2 * 4, out_batch2);
    } else {
      lora_compose::blend(ptrs, lora_compose::factors(act, compose_weights_), batch2_count, out_batch2);
    }
    logMemAfterRun(log_mem_after);
  }

  void endDenoise() override {
    compose_extra_conds_.clear();
    compose_conds_usable_.clear();
    releaseComposeExtras();
    if (unet_session_) unet_interpreter_->releaseSession(unet_session_);
    unet_session_ = nullptr;
    delete unet_interpreter_;
    unet_interpreter_ = nullptr;
    // mục 270 — đường Module: hạ cờ rồi huỷ module (UnetModuleSet::release huỷ LoRA TRƯỚC nền). Đặt CUỐI để phần đầu hàm giữ nguyên như mục 261.
    modules_active_ = false;
#ifdef MANGALOCAL_LORA_MODULE
    unet_modules_.reset();
#endif
  }

  void releaseTransientModels() override { endDenoise(); }

  void vaeDecode(const GenerationRequest &req, const float *latents,
                 float *pixels) override {
    MNN::Interpreter *interpreter =
        createMnnInterpreterMmap(vae_decoder_path_.c_str());
    if (!interpreter)
      throw std::runtime_error(
          "Failed to create temporary MNN VAE Decoder interpreter!");

    MNN::Session *session =
        createMnnSession(interpreter, sessionOptions(req, "vae_dec_cache"));
    if (!session) {
      delete interpreter;
      throw std::runtime_error("Failed create temp MNN VAE Dec session!");
    }

    auto input = interpreter->getSessionInput(session, "latent_sample");
    interpreter->resizeTensor(input, {1, 4, req.height / 8, req.width / 8});
    interpreter->resizeSession(session);
    if (req.use_opencl) interpreter->updateCacheFile(session);
    interpreter->releaseModel();

    auto input_nchw_tensor = new MNN::Tensor(input, MNN::Tensor::CAFFE);
    auto output = interpreter->getSessionOutput(session, "sample");
    auto output_nchw_tensor = new MNN::Tensor(output, MNN::Tensor::CAFFE);

    size_t latent_count = (size_t)4 * (req.height / 8) * (req.width / 8);
    size_t pixel_count = (size_t)3 * req.height * req.width;
    memcpy(input_nchw_tensor->host<float>(), latents,
           latent_count * sizeof(float));
    input->copyFromHostTensor(input_nchw_tensor);

    interpreter->runSession(session);

    output->copyToHostTensor(output_nchw_tensor);
    memcpy(pixels, output_nchw_tensor->host<float>(),
           pixel_count * sizeof(float));

    delete input_nchw_tensor;
    delete output_nchw_tensor;

    interpreter->releaseSession(session);
    delete interpreter;
  }

 protected:
  // ===== THÊM MỚI SO VỚI BẢN GỐC (MangaLocal) =====
  // Hook rỗng mặc định — subclass override để nạp thêm tensor input phụ
  // (IP-Adapter/ControlNet) vào unet_session_ trước khi chạy. Không ảnh
  // hưởng gì nếu không override (đúng hành vi gốc).
  virtual void onBeforeUnetRun(MNN::Interpreter *unetInterp, MNN::Session *unetSess) {}

  // ===== ĐỔI private -> protected SO VỚI BẢN GỐC =====
  // Bản gốc để private, không cho lớp con truy cập. Cần protected để
  // PipelineSd15CpuAugmented (ip_adapter.cpp) lấy thêm input tensor bằng
  // tên qua unet_interpreter_->getSessionInputAll(unet_session_).
  MNN::Interpreter *unet_interpreter_ = nullptr;
  MNN::Session *unet_session_ = nullptr;

  // mục 261 — UNet biến thể (LoRA Switch/Composite). Rỗng = tắt = hành vi cũ 100%.
  struct ComposeExtra { MNN::Interpreter *interp; MNN::Session *session; };
  std::vector<ComposeExtra> compose_extras_;
  int compose_active_count_ = 1;
  int compose_tau_ = 5;
  std::vector<float> compose_weights_;
  std::vector<Conditioning> compose_extra_conds_;  // mục 261.14 — điều kiện CLIP riêng, song song extra_unets
  std::vector<bool> compose_conds_usable_;
  bool compose_regional_ = false;          // mục 261.11
  std::vector<float> compose_fields_;      // k * (H/8*W/8), hệ số trộn từng pixel
  long long compose_mem_rss_before_run_ = -1;  // mục 262
  int step_counter_ = 0;
  // mục 270 — đường Module (LoRA tách rời). unet_modules_allowed_ chỉ true khi mnn_diffusion_pipeline.cpp bật cho pipeline SD1.5 thường.
  bool unet_modules_allowed_ = false;
  bool modules_active_ = false;
#ifdef MANGALOCAL_LORA_MODULE
  std::unique_ptr<unet_module::UnetModuleSet> unet_modules_;
#endif

 protected:
  // ===== ĐỔI private -> protected SO VỚI BẢN GỐC (LẦN 2 — mục 56
  // TECHNICAL_STATUS.md) =====
  // sessionOptions() + 4 đường dẫn model: bản gốc (và bản đổi private-
  // >protected lần 1 ở trên, mục 51/52) chỉ cần unet_interpreter_/
  // unet_session_ vì PipelineSd15CpuAugmented CHỈ hook onBeforeUnetRun(),
  // KHÔNG override beginDenoise() (model augmented vẫn giữ nguyên tên input
  // "encoder_hidden_states" như base, chỉ THÊM input tuỳ chọn). Model
  // Regional Prompting (regional_prompting.cpp) có input HOÀN TOÀN KHÁC
  // tên ("uncond_encoder_hidden_states"/"region_encoder_hidden_states" thay
  // vì "encoder_hidden_states") nên PHẢI override THẲNG beginDenoise() —
  // cần truy cập unet_path_ (để tự mở interpreter) và sessionOptions() (để
  // tạo session cache đúng quy ước ".mnnc.<width>" như mọi pipeline khác,
  // không tự chế quy ước cache riêng).
  MnnSessionOptions sessionOptions(const GenerationRequest &req,
                                   const char *stage) const {
    MnnSessionOptions opts;
    opts.use_opencl = req.use_opencl;
    opts.allow_npu = req.use_npu;  // mục 60 TECHNICAL_STATUS.md
    opts.require_npu = req.require_npu;  // mục 64 TECHNICAL_STATUS.md
    if (req.use_opencl) {
      auto cache_dir = ensureCacheDir(model_dir_);
      opts.cache_file = (cache_dir.empty() ? model_dir_ : cache_dir) + "/" +
                        stage + ".mnnc." + std::to_string(req.width);
    }
    return opts;
  }

  const std::string clip_path_;
  const std::string unet_path_;
  const std::string vae_decoder_path_;
  const std::string vae_encoder_path_;
};

#endif  // PIPELINESD15CPU_HPP
