#ifndef PIPELINESD15CPU_HPP
#define PIPELINESD15CPU_HPP

#include <MNN/Interpreter.hpp>
#include <memory>
#include <stdexcept>
#include <string>

#include "Config.hpp"
#include "MnnUtils.hpp"
#include "Pipeline.hpp"

// sd15cpu: the whole pipeline runs on MNN (CPU or OpenCL). Nothing stays
// resident between requests -- every stage creates its interpreter from the
// mmap'd model, runs, and releases, keeping idle memory minimal.
class PipelineSd15Cpu : public Pipeline {
 public:
  PipelineSd15Cpu(TextEncoder &text_encoder, const std::string &model_dir,
                  std::string clip_path, std::string unet_path,
                  std::string vae_decoder_path, std::string vae_encoder_path,
                  bool use_v_pred)
      : Pipeline(text_encoder, model_dir, /*sdxl=*/false, use_v_pred),
        clip_path_(std::move(clip_path)),
        unet_path_(std::move(unet_path)),
        vae_decoder_path_(std::move(vae_decoder_path)),
        vae_encoder_path_(std::move(vae_encoder_path)) {}

  bool initialize() override { return true; }

  bool supportsImg2Img() const override { return !vae_encoder_path_.empty(); }

 protected:
  bool canSkipUncond() const override { return false; }
  bool previewSupported() const override { return false; }

  void encodeText(const ProcessedPromptPair &prompts, bool need_negative,
                  bool need_positive, Conditioning &cond) override {
    MNN::Interpreter *interpreter =
        createMnnInterpreterMmap(clip_path_.c_str());
    if (!interpreter)
      throw std::runtime_error(
          "Failed to create temporary MNN CLIP interpreter!");

    MnnSessionOptions opts;  // CLIP always runs on CPU
    MNN::Session *session = createMnnSession(interpreter, opts);
    if (!session) {
      delete interpreter;
      throw std::runtime_error("Failed to create temporary MNN CLIP session!");
    }

    auto input = interpreter->getSessionInput(session, "input_embedding");
    interpreter->resizeTensor(input, {1, 77, text_embedding_size});
    interpreter->resizeSession(session);
    interpreter->releaseModel();

    auto run_side = [&](const std::vector<float> &embeddings, float *dst) {
      memcpy(input->host<float>(), embeddings.data(),
             77 * text_embedding_size * sizeof(float));
      interpreter->runSession(session);
      auto out = interpreter->getSessionOutput(session, "last_hidden_state");
      memcpy(dst, out->host<float>(), 77 * text_embedding_size * sizeof(float));
    };

    if (need_negative) run_side(prompts.negative_embeddings, cond.negHidden());
    if (need_positive) run_side(prompts.positive_embeddings, cond.posHidden());

    interpreter->releaseSession(session);
    delete interpreter;
  }

  void vaeEncode(const GenerationRequest &req, const float *image, float *mean,
                 float *std_dev) override {
    MNN::Interpreter *interpreter =
        createMnnInterpreterMmap(vae_encoder_path_.c_str());
    if (!interpreter) throw std::runtime_error("Failed MNN VAE Enc create");

    MNN::Session *session =
        createMnnSession(interpreter, sessionOptions(req, "vae_enc_cache"));
    if (!session) {
      delete interpreter;
      throw std::runtime_error("Failed create temp MNN VAE Enc session!");
    }

    auto input = interpreter->getSessionInput(session, "input");
    interpreter->resizeTensor(input, {1, 3, req.height, req.width});
    interpreter->resizeSession(session);
    if (req.use_opencl) interpreter->updateCacheFile(session);
    interpreter->releaseModel();

    auto input_nchw_tensor = new MNN::Tensor(input, MNN::Tensor::CAFFE);
    auto mean_t = interpreter->getSessionOutput(session, "mean");
    auto std_t = interpreter->getSessionOutput(session, "std");
    auto mean_nchw_tensor = new MNN::Tensor(mean_t, MNN::Tensor::CAFFE);
    auto std_nchw_tensor = new MNN::Tensor(std_t, MNN::Tensor::CAFFE);

    size_t image_count = (size_t)3 * req.height * req.width;
    size_t latent_count = (size_t)4 * (req.height / 8) * (req.width / 8);
    memcpy(input_nchw_tensor->host<float>(), image,
           image_count * sizeof(float));
    input->copyFromHostTensor(input_nchw_tensor);
    interpreter->runSession(session);

    mean_t->copyToHostTensor(mean_nchw_tensor);
    std_t->copyToHostTensor(std_nchw_tensor);
    memcpy(mean, mean_nchw_tensor->host<float>(), latent_count * sizeof(float));
    memcpy(std_dev, std_nchw_tensor->host<float>(),
           latent_count * sizeof(float));

    delete input_nchw_tensor;
    delete mean_nchw_tensor;
    delete std_nchw_tensor;

    interpreter->releaseSession(session);
    delete interpreter;
  }

  void beginDenoise(const GenerationRequest &req) override {
    unet_interpreter_ = createMnnInterpreterMmap(unet_path_.c_str());
    if (!unet_interpreter_)
      throw std::runtime_error(
          "Failed to create temporary MNN UNET interpreter!");

    unet_session_ =
        createMnnSession(unet_interpreter_, sessionOptions(req, "unet_cache"));
    if (!unet_session_)
      throw std::runtime_error("Failed to create temporary MNN UNET session!");

    auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
    auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
    auto enc = unet_interpreter_->getSessionInput(unet_session_,
                                                  "encoder_hidden_states");

    unet_interpreter_->resizeTensor(samp,
                                    {2, 4, req.height / 8, req.width / 8});
    unet_interpreter_->resizeTensor(ts, {1});
    unet_interpreter_->resizeTensor(enc, {2, 77, text_embedding_size});
    unet_interpreter_->resizeSession(unet_session_);
    if (req.use_opencl) unet_interpreter_->updateCacheFile(unet_session_);

    unet_interpreter_->releaseModel();
  }

  void runUnetStep(const GenerationRequest &req, const float *latents_batch2,
                   float timestep_f, bool /*skip_uncond*/, Conditioning &cond,
                   float *out_batch2) override {
    const int timestep = static_cast<int>(timestep_f);
    auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
    auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
    auto enc = unet_interpreter_->getSessionInput(unet_session_,
                                                  "encoder_hidden_states");

    auto samp_nchw_tensor = new MNN::Tensor(samp, MNN::Tensor::CAFFE);
    auto ts_nchw_tensor = new MNN::Tensor(ts, MNN::Tensor::CAFFE);
    auto enc_nchw_tensor = new MNN::Tensor(enc, MNN::Tensor::CAFFE);

    size_t batch2_count = (size_t)2 * 4 * (req.height / 8) * (req.width / 8);

    // Copy both batches (negative and positive) at once.
    memcpy(samp_nchw_tensor->host<float>(), latents_batch2,
           batch2_count * sizeof(float));
    memcpy(ts_nchw_tensor->host<int>(), &timestep, sizeof(int));
    memcpy(enc_nchw_tensor->host<float>(), cond.hidden.data(),
           cond.hidden.size() * sizeof(float));

    samp->copyFromHostTensor(samp_nchw_tensor);
    ts->copyFromHostTensor(ts_nchw_tensor);
    enc->copyFromHostTensor(enc_nchw_tensor);

    // ===== SỬA SO VỚI BẢN GỐC (MangaLocal) =====
    // Thêm 1 dòng gọi hook ảo NGAY TRƯỚC runSession, để lớp con
    // (PipelineSd15CpuAugmented trong ip_adapter.cpp) có chỗ nạp thêm
    // tensor điều kiện phụ (IP-Adapter image_embeds, ControlNet pose) vào
    // ĐÚNG session này trước khi chạy — không đổi hành vi gốc khi hook
    // rỗng (mặc định no-op). Đây là thay đổi DUY NHẤT về logic so với bản
    // local-dream gốc trong toàn bộ file này.
    onBeforeUnetRun(unet_interpreter_, unet_session_);

    // Single batch inference for both negative and positive conditions.
    unet_interpreter_->runSession(unet_session_);

    auto output =
        unet_interpreter_->getSessionOutput(unet_session_, "out_sample");
    output->copyToHostTensor(samp_nchw_tensor);
    memcpy(out_batch2, samp_nchw_tensor->host<float>(),
           batch2_count * sizeof(float));

    delete samp_nchw_tensor;
    delete ts_nchw_tensor;
    delete enc_nchw_tensor;
  }

  void endDenoise() override {
    if (unet_session_) unet_interpreter_->releaseSession(unet_session_);
    unet_session_ = nullptr;
    delete unet_interpreter_;
    unet_interpreter_ = nullptr;
  }

  void releaseTransientModels() override { endDenoise(); }

  void vaeDecode(const GenerationRequest &req, const float *latents,
                 float *pixels) override {
    MNN::Interpreter *interpreter =
        createMnnInterpreterMmap(vae_decoder_path_.c_str());
    if (!interpreter)
      throw std::runtime_error(
          "Failed to create temporary MNN VAE Decoder interpreter!");

    MNN::Session *session =
        createMnnSession(interpreter, sessionOptions(req, "vae_dec_cache"));
    if (!session) {
      delete interpreter;
      throw std::runtime_error("Failed create temp MNN VAE Dec session!");
    }

    auto input = interpreter->getSessionInput(session, "latent_sample");
    interpreter->resizeTensor(input, {1, 4, req.height / 8, req.width / 8});
    interpreter->resizeSession(session);
    if (req.use_opencl) interpreter->updateCacheFile(session);
    interpreter->releaseModel();

    auto input_nchw_tensor = new MNN::Tensor(input, MNN::Tensor::CAFFE);
    auto output = interpreter->getSessionOutput(session, "sample");
    auto output_nchw_tensor = new MNN::Tensor(output, MNN::Tensor::CAFFE);

    size_t latent_count = (size_t)4 * (req.height / 8) * (req.width / 8);
    size_t pixel_count = (size_t)3 * req.height * req.width;
    memcpy(input_nchw_tensor->host<float>(), latents,
           latent_count * sizeof(float));
    input->copyFromHostTensor(input_nchw_tensor);

    interpreter->runSession(session);

    output->copyToHostTensor(output_nchw_tensor);
    memcpy(pixels, output_nchw_tensor->host<float>(),
           pixel_count * sizeof(float));

    delete input_nchw_tensor;
    delete output_nchw_tensor;

    interpreter->releaseSession(session);
    delete interpreter;
  }

 protected:
  // ===== THÊM MỚI SO VỚI BẢN GỐC (MangaLocal) =====
  // Hook rỗng mặc định — subclass override để nạp thêm tensor input phụ
  // (IP-Adapter/ControlNet) vào unet_session_ trước khi chạy. Không ảnh
  // hưởng gì nếu không override (đúng hành vi gốc).
  virtual void onBeforeUnetRun(MNN::Interpreter *unetInterp, MNN::Session *unetSess) {}

  // ===== ĐỔI private -> protected SO VỚI BẢN GỐC =====
  // Bản gốc để private, không cho lớp con truy cập. Cần protected để
  // PipelineSd15CpuAugmented (ip_adapter.cpp) lấy thêm input tensor bằng
  // tên qua unet_interpreter_->getSessionInputAll(unet_session_).
  MNN::Interpreter *unet_interpreter_ = nullptr;
  MNN::Session *unet_session_ = nullptr;

 protected:
  // ===== ĐỔI private -> protected SO VỚI BẢN GỐC (LẦN 2 — mục 56
  // TECHNICAL_STATUS.md) =====
  // sessionOptions() + 4 đường dẫn model: bản gốc (và bản đổi private-
  // >protected lần 1 ở trên, mục 51/52) chỉ cần unet_interpreter_/
  // unet_session_ vì PipelineSd15CpuAugmented CHỈ hook onBeforeUnetRun(),
  // KHÔNG override beginDenoise() (model augmented vẫn giữ nguyên tên input
  // "encoder_hidden_states" như base, chỉ THÊM input tuỳ chọn). Model
  // Regional Prompting (regional_prompting.cpp) có input HOÀN TOÀN KHÁC
  // tên ("uncond_encoder_hidden_states"/"region_encoder_hidden_states" thay
  // vì "encoder_hidden_states") nên PHẢI override THẲNG beginDenoise() —
  // cần truy cập unet_path_ (để tự mở interpreter) và sessionOptions() (để
  // tạo session cache đúng quy ước ".mnnc.<width>" như mọi pipeline khác,
  // không tự chế quy ước cache riêng).
  MnnSessionOptions sessionOptions(const GenerationRequest &req,
                                   const char *stage) const {
    MnnSessionOptions opts;
    opts.use_opencl = req.use_opencl;
    opts.allow_npu = req.use_npu;  // mục 60 TECHNICAL_STATUS.md
    opts.require_npu = req.require_npu;  // mục 64 TECHNICAL_STATUS.md
    if (req.use_opencl) {
      auto cache_dir = ensureCacheDir(model_dir_);
      opts.cache_file = (cache_dir.empty() ? model_dir_ : cache_dir) + "/" +
                        stage + ".mnnc." + std::to_string(req.width);
    }
    return opts;
  }

  const std::string clip_path_;
  const std::string unet_path_;
  const std::string vae_decoder_path_;
  const std::string vae_encoder_path_;
};

#endif  // PIPELINESD15CPU_HPP
