#pragma once
// mục 262 TECHNICAL_STATUS.md — cờ "khớp mức nhiễu khi trộn mask" (việc treo từ 260.4). Logic thuần: tools/test_mask_blend_meminfo.py.
//
// Vấn đề: ở nhánh mask của Pipeline::generate (vẽ lại mặt/tay/vùng chạm; cả trộn cứng lẫn Differential Diffusion) trộn diễn ra SAU scheduler->step.
// Lúc đó latent đã ở mức nhiễu của timesteps[i+1], nhưng mã cũ thêm nhiễu cho ảnh gốc ở timesteps[i] — nhiễu ảnh gốc cao hơn latent một bậc.
// Nguồn tham chiếu (tra cứu mục 261.15-A): pipeline inpaint hiện hành của diffusers dùng `noise_timestep = timesteps[i + 1]` khi `i < len(timesteps) - 1`
// (bước cuối: ảnh sạch); cách tham chiếu Differential Diffusion trộn hai bên CÙNG mức nhiễu. Các script inpaint đời đầu dùng t hiện tại — giống mã cũ.
// Mặc định TẮT (đổi hành vi mọi lần vẽ lại có mask, chưa so ảnh trên máy thật).
#include <atomic>

inline std::atomic<bool> g_mask_blend_matched{false};

// Chỉ số trong `timesteps` để thêm nhiễu cho ảnh gốc khi trộn sau bước i (0-based) của n bước.
//   matched = false -> i (hành vi cũ, y hệt).
//   matched = true  -> i + 1 (mức nhiễu đúng của latent sau bước); bước cuối -> -1 = dùng ảnh gốc SẠCH (không thêm nhiễu).
inline int maskBlendTimestepIndex(int i, int n, bool matched) {
  if (!matched) return i;
  return (i + 1 < n) ? i + 1 : -1;
}
