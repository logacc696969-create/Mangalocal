// regional_mask_prompting.cpp — mục 172 TECHNICAL_STATUS.md: Regional
// Prompting với MASK HÌNH DẠNG TUỲ Ý (kiểu "Attention Couple"/"Regional
// Prompter Mask mode" cộng đồng, xem mục 171) — đối tác native của
// tools/export_ipa_controlnet_regional_mask_unet.py. ĐỌC DOCSTRING FILE
// ĐÓ TRƯỚC (giải thích đầy đủ cơ chế argmax cứng + vùng nền).
//
// COPY CẤU TRÚC từ regional_prompting.cpp (bản CỘT, mục 56) — CHỦ Ý giữ
// y hệt khung sườn (không phát minh cách tổ chức mới) — CHỈ khác: thêm 2
// input model ("background_encoder_hidden_states", "region_masks") và
// setConditioning() nhận thêm mask thật + prompt nền. Cùng lý do KHÔNG
// include ip_adapter.cpp (tránh phụ thuộc chéo 2 file .cpp) nên KHÔNG
// tái dùng được renderCharacterMask() ở đó — region_masks nhận THẲNG
// buffer đã dựng sẵn từ Kotlin (mục 172 CHỦ Ý dùng
// MangaPipeline.buildCharacterBodyMaskFile() phía Kotlin — ĐÃ CÓ SAM từ
// mục 168 — thay vì gọi lại renderCharacterMask() bbox-thô phía C++,
// xem TECHNICAL_STATUS.md mục 172 phần "Việc còn lại" để biết đây là
// LỰA CHỌN CÓ CHỦ Ý, không phải chưa kịp nối).

#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <memory>
#include <fstream>
#include <cmath>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

#include "sd_engine/Config.hpp"
#include "sd_engine/MnnUtils.hpp"
#include "sd_engine/PipelineSd15Cpu.hpp"

#define TAG "MangaLocal_RegionalMask"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::string j2s_rmp(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c);
    e->ReleaseStringUTFChars(js, c);
    return s;
}

class PipelineSd15CpuRegionalMask : public PipelineSd15Cpu {
public:
    PipelineSd15CpuRegionalMask(TextEncoder &text_encoder, const std::string &model_dir,
                                 std::string clip_path, std::string unet_regional_mask_path,
                                 std::string vae_decoder_path, std::string vae_encoder_path,
                                 int num_regions)
        : PipelineSd15Cpu(text_encoder, model_dir, clip_path, unet_regional_mask_path,
                          vae_decoder_path, vae_encoder_path, /*use_v_pred=*/false),
          num_regions_(num_regions) {}

    // regionMasks: N khối liên tiếp, MỖI khối controlSize*controlSize byte
    // (0-255, KHÔNG phải RGB — 1 kênh xám/alpha), ĐÚNG THỨ TỰ với
    // regionEmbeds (vùng 0 trước). backgroundEmbed: 1×77×768, prompt cho
    // phần ảnh KHÔNG thuộc mask nào (xem docstring export script phần
    // "vùng nền"). Còn lại giống hệt bản cột (setConditioning của
    // PipelineSd15CpuRegional).
    void setConditioning(const std::vector<float>& uncondEmbed,
                          const std::vector<float>& backgroundEmbed,
                          const std::vector<float>& regionEmbeds,
                          const std::vector<uint8_t>& regionMasks,
                          const std::vector<uint8_t>& controlHintRgb, int controlSize) {
        uncondEmbed_ = uncondEmbed;
        backgroundEmbed_ = backgroundEmbed;
        regionEmbeds_ = regionEmbeds;
        regionMasks_ = regionMasks;
        controlHintRgb_ = controlHintRgb;
        controlSize_ = controlSize;
        hasConditioning_ = true;
    }

protected:
    void beginDenoise(const GenerationRequest &req) override {
        unet_interpreter_ = createMnnInterpreterMmap(unet_path_.c_str());
        if (!unet_interpreter_) throw std::runtime_error("Failed to create MNN UNET (regional-mask) interpreter!");

        unet_session_ = createMnnSession(unet_interpreter_, sessionOptions(req, "unet_regional_mask_cache"));
        if (!unet_session_) throw std::runtime_error("Failed to create MNN UNET (regional-mask) session!");

        auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
        auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
        auto uncondIn = unet_interpreter_->getSessionInput(unet_session_, "uncond_encoder_hidden_states");
        auto bgIn = unet_interpreter_->getSessionInput(unet_session_, "background_encoder_hidden_states");
        auto regionIn = unet_interpreter_->getSessionInput(unet_session_, "region_encoder_hidden_states");
        auto maskIn = unet_interpreter_->getSessionInput(unet_session_, "region_masks");
        auto hintIn = unet_interpreter_->getSessionInput(unet_session_, "control_hint");
        if (!samp || !ts || !uncondIn || !bgIn || !regionIn || !maskIn || !hintIn) {
            throw std::runtime_error(
                "Model unet_regional_mask_*.mnn thieu 1 trong cac input bat buoc "
                "(sample/timestep/uncond_encoder_hidden_states/background_encoder_hidden_states/"
                "region_encoder_hidden_states/region_masks/control_hint) - co dung dung file model khong?");
        }

        unet_interpreter_->resizeTensor(samp, {2, 4, req.height / 8, req.width / 8});
        unet_interpreter_->resizeTensor(ts, {1});
        unet_interpreter_->resizeTensor(uncondIn, {1, 77, text_embedding_size});
        unet_interpreter_->resizeTensor(bgIn, {1, 77, text_embedding_size});
        unet_interpreter_->resizeTensor(regionIn, {num_regions_, 77, text_embedding_size});
        unet_interpreter_->resizeTensor(maskIn, {num_regions_, req.height, req.width});
        unet_interpreter_->resizeTensor(hintIn, {2, 3, req.height, req.width});
        unet_interpreter_->resizeSession(unet_session_);
        if (req.use_opencl) unet_interpreter_->updateCacheFile(unet_session_);
        unet_interpreter_->releaseModel();
    }

    void runUnetStep(const GenerationRequest &req, const float *latents_batch2,
                     float timestep_f, bool /*skip_uncond*/, Conditioning & /*cond*/,
                     float *out_batch2) override {
        if (!hasConditioning_) {
            LOGE("runUnetStep (regional-mask) goi truoc setConditioning() - anh se sai/rac");
        }
        const int timestep = static_cast<int>(timestep_f);
        auto samp = unet_interpreter_->getSessionInput(unet_session_, "sample");
        auto ts = unet_interpreter_->getSessionInput(unet_session_, "timestep");
        auto uncondIn = unet_interpreter_->getSessionInput(unet_session_, "uncond_encoder_hidden_states");
        auto bgIn = unet_interpreter_->getSessionInput(unet_session_, "background_encoder_hidden_states");
        auto regionIn = unet_interpreter_->getSessionInput(unet_session_, "region_encoder_hidden_states");
        auto maskIn = unet_interpreter_->getSessionInput(unet_session_, "region_masks");
        auto hintIn = unet_interpreter_->getSessionInput(unet_session_, "control_hint");

        size_t batch2_count = (size_t)2 * 4 * (req.height / 8) * (req.width / 8);
        MNN::Tensor samp_h(samp, MNN::Tensor::CAFFE);
        MNN::Tensor ts_h(ts, MNN::Tensor::CAFFE);
        MNN::Tensor uncond_h(uncondIn, MNN::Tensor::CAFFE);
        MNN::Tensor bg_h(bgIn, MNN::Tensor::CAFFE);
        MNN::Tensor region_h(regionIn, MNN::Tensor::CAFFE);
        MNN::Tensor mask_h(maskIn, MNN::Tensor::CAFFE);
        MNN::Tensor hint_h(hintIn, MNN::Tensor::CAFFE);

        memcpy(samp_h.host<float>(), latents_batch2, batch2_count * sizeof(float));
        memcpy(ts_h.host<int>(), &timestep, sizeof(int));
        memcpy(uncond_h.host<float>(), uncondEmbed_.data(),
               std::min(uncondEmbed_.size(), (size_t)uncond_h.elementSize()) * sizeof(float));
        memcpy(bg_h.host<float>(), backgroundEmbed_.data(),
               std::min(backgroundEmbed_.size(), (size_t)bg_h.elementSize()) * sizeof(float));
        memcpy(region_h.host<float>(), regionEmbeds_.data(),
               std::min(regionEmbeds_.size(), (size_t)region_h.elementSize()) * sizeof(float));

        // region_masks: chuẩn hoá byte 0-255 -> float 0-1, ĐÚNG layout
        // [num_regions, H, W] khớp resizeTensor ở beginDenoise() — copy
        // TUẦN TỰ theo đúng thứ tự regionMasks_ đã nhận ở setConditioning()
        // (N khối liên tiếp, mỗi khối H*W byte).
        size_t plane_mask = (size_t)req.height * req.width;
        size_t mask_elems = std::min(regionMasks_.size(), (size_t)mask_h.elementSize());
        for (size_t i = 0; i < mask_elems; i++) {
            mask_h.host<float>()[i] = regionMasks_[i] / 255.f;
        }
        (void)plane_mask;

        // control_hint — ĐÚNG pattern regional_prompting.cpp (copy nguyên,
        // lặp cho cả 2 batch).
        int size = controlSize_;
        size_t plane = (size_t)3 * size * size;
        for (int b = 0; b < 2; b++) {
            for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
                const uint8_t *p = controlHintRgb_.data() + ((size_t)y * size + x) * 3;
                for (int ch = 0; ch < 3; ch++)
                    hint_h.host<float>()[b * plane + (size_t)ch * size * size + y * size + x] = p[ch] / 255.f;
            }
        }

        samp->copyFromHostTensor(&samp_h);
        ts->copyFromHostTensor(&ts_h);
        uncondIn->copyFromHostTensor(&uncond_h);
        bgIn->copyFromHostTensor(&bg_h);
        regionIn->copyFromHostTensor(&region_h);
        maskIn->copyFromHostTensor(&mask_h);
        hintIn->copyFromHostTensor(&hint_h);

        unet_interpreter_->runSession(unet_session_);

        auto output = unet_interpreter_->getSessionOutput(unet_session_, "out_sample");
        MNN::Tensor out_h(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&out_h);
        memcpy(out_batch2, out_h.host<float>(), batch2_count * sizeof(float));
    }

private:
    int num_regions_;
    bool hasConditioning_ = false;
    std::vector<float> uncondEmbed_;
    std::vector<float> backgroundEmbed_;
    std::vector<float> regionEmbeds_;
    std::vector<uint8_t> regionMasks_;      // N khối H*W byte, 0-255
    std::vector<uint8_t> controlHintRgb_;
    int controlSize_ = 512;
};

// Y HỆT encodeOnePrompt() trong regional_prompting.cpp (copy nguyên —
// KHÔNG include chéo file .cpp, xem comment đầu file).
static std::vector<float> encodeOnePromptRM(TextEncoder &textEncoder, MNN::Interpreter *clipInterp,
                                             MNN::Session *clipSession, int textEmbeddingSize,
                                             const std::string &prompt) {
    ProcessedPromptPair pair = textEncoder.processPromptPair(prompt, "");
    auto input = clipInterp->getSessionInput(clipSession, "input_embedding");
    memcpy(input->host<float>(), pair.positive_embeddings.data(),
           77 * textEmbeddingSize * sizeof(float));
    clipInterp->runSession(clipSession);
    auto out = clipInterp->getSessionOutput(clipSession, "last_hidden_state");
    std::vector<float> result(77 * textEmbeddingSize);
    memcpy(result.data(), out->host<float>(), result.size() * sizeof(float));
    return result;
}

struct SdRegionalMaskHandle {
    std::unique_ptr<TextEncoder> textEncoder;
    std::unique_ptr<PipelineSd15CpuRegionalMask> pipeline;
    std::string clipPath;
    bool useOpenCL = false;
    bool useNpu = false;
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdInitRegionalMask(JNIEnv* e, jobject,
    jstring jModelDir, jstring jClip, jstring jUnetRegionalMask, jstring jVaeDec,
    jstring jVaeEnc, jstring jTokenizer, jstring jEmbeddingsDir, jint jNumRegions,
    jboolean jUseOpenCL, jboolean jUseNpu) {

    std::string dir = j2s_rmp(e, jModelDir);
    try {
        auto handle = std::make_unique<SdRegionalMaskHandle>();
        handle->useOpenCL = jUseOpenCL;
        handle->useNpu = jUseNpu;
        handle->textEncoder = std::make_unique<TextEncoder>(false, false);
        handle->textEncoder->loadTokenizer(j2s_rmp(e, jTokenizer));
        handle->textEncoder->loadEmbeddingTables(dir);
        std::string embeddingsDir = j2s_rmp(e, jEmbeddingsDir);
        if (!embeddingsDir.empty()) handle->textEncoder->loadTextualInversions(embeddingsDir);

        handle->clipPath = j2s_rmp(e, jClip);
        handle->pipeline = std::make_unique<PipelineSd15CpuRegionalMask>(
            *handle->textEncoder, dir, handle->clipPath, j2s_rmp(e, jUnetRegionalMask),
            j2s_rmp(e, jVaeDec), j2s_rmp(e, jVaeEnc), (int)jNumRegions);
        if (!handle->pipeline->initialize()) { LOGE("PipelineSd15CpuRegionalMask initialize() fail"); return 0; }

        return reinterpret_cast<jlong>(handle.release());
    } catch (const std::exception &ex) {
        LOGE("sdInitRegionalMask loi: %s", ex.what());
        return 0;
    }
}

// jRegionPrompts: N string, ĐÚNG thứ tự với jRegionMasks (khối i của mask
// khớp prompt i). jBackgroundPrompt: 1 string, prompt cho vùng KHÔNG mask
// nào phủ (mục 172 — KHÁC bản cột, xem docstring export script). jRegionMasks:
// byte[] phẳng, N khối liên tiếp, mỗi khối controlSize*controlSize byte
// (0-255, 1 kênh) — Kotlin dựng bằng MangaPipeline.buildCharacterBodyMaskFile()
// (ĐÃ có SAM từ mục 168) rồi đọc byte kênh alpha/xám, KHÔNG dựng lại bằng
// C++ (xem comment đầu file). jControlHintRgb/controlSize: giống hệt bản cột.
extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgRegionalMask(JNIEnv* e, jobject,
    jlong ptr, jobjectArray jRegionPrompts, jstring jBackgroundPrompt, jstring jNegPrompt,
    jbyteArray jRegionMasks, jbyteArray jControlHintRgb, jint controlSize,
    jint w, jint h, jint steps, jfloat cfg, jlong seed, jstring jOut, jobject cb) {

    auto *handle = reinterpret_cast<SdRegionalMaskHandle *>(ptr);
    if (!handle || !handle->pipeline) { LOGE("sdTxt2ImgRegionalMask: chua init"); return JNI_FALSE; }

    jsize numRegions = jRegionPrompts ? e->GetArrayLength(jRegionPrompts) : 0;
    if (numRegions < 2) { LOGE("sdTxt2ImgRegionalMask: can it nhat 2 vung"); return JNI_FALSE; }

    MNN::Interpreter *clipInterp = createMnnInterpreterMmap(handle->clipPath.c_str());
    if (!clipInterp) { LOGE("Khong mo duoc clip_v2.mnn"); return JNI_FALSE; }
    MnnSessionOptions clipOpts;
    MNN::Session *clipSession = createMnnSession(clipInterp, clipOpts);
    if (!clipSession) { delete clipInterp; LOGE("Khong tao duoc clip session"); return JNI_FALSE; }
    auto clipInput = clipInterp->getSessionInput(clipSession, "input_embedding");
    clipInterp->resizeTensor(clipInput, {1, 77, text_embedding_size});
    clipInterp->resizeSession(clipSession);
    clipInterp->releaseModel();

    std::vector<float> uncondEmbed = encodeOnePromptRM(
        *handle->textEncoder, clipInterp, clipSession, text_embedding_size, j2s_rmp(e, jNegPrompt));
    std::vector<float> backgroundEmbed = encodeOnePromptRM(
        *handle->textEncoder, clipInterp, clipSession, text_embedding_size, j2s_rmp(e, jBackgroundPrompt));

    std::vector<float> regionEmbeds;
    regionEmbeds.reserve((size_t)numRegions * 77 * text_embedding_size);
    for (jsize i = 0; i < numRegions; i++) {
        auto jp = (jstring)e->GetObjectArrayElement(jRegionPrompts, i);
        std::vector<float> emb = encodeOnePromptRM(
            *handle->textEncoder, clipInterp, clipSession, text_embedding_size, j2s_rmp(e, jp));
        e->DeleteLocalRef(jp);
        regionEmbeds.insert(regionEmbeds.end(), emb.begin(), emb.end());
    }
    clipInterp->releaseSession(clipSession);
    delete clipInterp;

    std::vector<uint8_t> regionMasks;
    if (jRegionMasks) {
        jsize n = e->GetArrayLength(jRegionMasks);
        regionMasks.resize(n);
        jbyte *buf = e->GetByteArrayElements(jRegionMasks, nullptr);
        memcpy(regionMasks.data(), buf, n);
        e->ReleaseByteArrayElements(jRegionMasks, buf, JNI_ABORT);
    }
    size_t expectedMaskBytes = (size_t)numRegions * controlSize * controlSize;
    if (regionMasks.size() != expectedMaskBytes) {
        LOGE("sdTxt2ImgRegionalMask: region_masks kich thuoc sai (%zu byte, ky vong %zu = %d vung x %dx%d) "
             "- Kotlin co dung dung buildCharacterBodyMaskFile() cho DUNG controlSize khong?",
             regionMasks.size(), expectedMaskBytes, (int)numRegions, controlSize, controlSize);
        // KHÔNG return false ngay — vẫn thử chạy (mask sai kích thước sẽ bị
        // memcpy min() cắt bớt/thiếu ở runUnetStep(), ẢNH SẼ SAI nhưng
        // KHÔNG crash) — cùng triết lý "log rõ, không throw cứng" đã dùng
        // cho regionalColumnOrder lệch bộ ở nơi khác. Người dùng thấy ảnh
        // hỏng + log rõ ràng thay vì app crash không rõ lý do.
    }

    std::vector<uint8_t> controlHint;
    if (jControlHintRgb) {
        jsize n = e->GetArrayLength(jControlHintRgb);
        controlHint.resize(n);
        jbyte *buf = e->GetByteArrayElements(jControlHintRgb, nullptr);
        memcpy(controlHint.data(), buf, n);
        e->ReleaseByteArrayElements(jControlHintRgb, buf, JNI_ABORT);
    }

    handle->pipeline->setConditioning(uncondEmbed, backgroundEmbed, regionEmbeds, regionMasks, controlHint, controlSize);

    GenerationRequest req;
    req.prompt = ""; req.negative_prompt = "";
    req.width = w; req.height = h; req.steps = steps; req.cfg = cfg;
    req.seed = (unsigned)seed; req.use_opencl = handle->useOpenCL; req.use_npu = handle->useNpu; req.img2img = false;

    JavaVM* jvm = nullptr; e->GetJavaVM(&jvm);
    jobject cbGlobal = cb ? e->NewGlobalRef(cb) : nullptr;
    auto progress = [jvm, cbGlobal](int step, int total, const std::string&) {
        if (!cbGlobal || !jvm) return;
        JNIEnv* env; if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        jclass cls = env->GetObjectClass(cbGlobal);
        jmethodID mid = env->GetMethodID(cls, "onProgress", "(II)V");
        if (mid) env->CallVoidMethod(cbGlobal, mid, step, total);
        jvm->DetachCurrentThread();
    };

    bool ok = false;
    try {
        GenerationResult result = handle->pipeline->generate(req, progress);
        std::vector<uint8_t> png = encodePNG(result.image_data, result.width, result.height);
        std::ofstream out(j2s_rmp(e, jOut), std::ios::binary);
        if (out) {
            out.write(reinterpret_cast<const char *>(png.data()), (std::streamsize)png.size());
            ok = out.good();
        }
    } catch (const std::exception &ex) {
        LOGE("generate() (regional-mask) loi: %s", ex.what());
    }
    if (cbGlobal) e->DeleteGlobalRef(cbGlobal);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdFreeRegionalMask(JNIEnv *, jobject, jlong ptr) {
    delete reinterpret_cast<SdRegionalMaskHandle *>(ptr);
}
