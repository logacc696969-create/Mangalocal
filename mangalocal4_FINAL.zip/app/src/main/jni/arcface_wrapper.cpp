// ArcFace MobileFaceNet (w600k_mbf) — embedding khuôn mặt cho "cổng danh tính" (mục 246 TECHNICAL_STATUS.md).
// Bám SÁT khuôn midas_depth_wrapper.cpp / yolo_pose_wrapper.cpp (cùng MNN::Interpreter/Session/Tensor, cùng stbi_load, cùng fallback OpenCL -> CPU).
// Đầu vào: ảnh 112x112 RGB ĐÃ CĂN CHỈNH 5 điểm (việc căn chỉnh làm ở Kotlin: FaceIdentity). Chuẩn hoá (x-127.5)/127.5 (insightface ArcFaceONNX).
// Đầu ra: 512 float, L2-normalize ở đây. Không đoán tên tensor; kiểm số phần tử output == 512, sai thì trả mảng RỖNG + log.
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <cmath>
#include <cstring>
#include <memory>

#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

extern "C" {
unsigned char* stbi_load(const char*, int*, int*, int*, int);
void           stbi_image_free(void*);
}

#define TAG "ArcFace_MNN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

struct ArcFaceWrapper {
    std::shared_ptr<MNN::Interpreter> net;
    MNN::Session* session = nullptr;
    static const int kSize = 112;
    static const int kDim = 512;
    bool ok = false;

    explicit ArcFaceWrapper(const std::string& modelDir) {
        std::string modelPath = modelDir + "/arcface_mbf.mnn";
        net.reset(MNN::Interpreter::createFromFile(modelPath.c_str()));
        if (!net) { LOGE("khong doc duoc model: %s", modelPath.c_str()); return; }
        MNN::ScheduleConfig config;
        config.type = MNN_FORWARD_CPU;   // mô hình nhỏ (~13MB): CPU ổn định, tránh sai lệch số học OpenCL FP16 làm lệch embedding
        config.numThread = 4;
        session = net->createSession(config);
        if (!session) { LOGE("createSession CPU fail"); return; }
        ok = true;
        LOGI("ArcFace (MNN) nap OK: %s", modelPath.c_str());
    }

    std::vector<float> embed(const std::string& imagePath) {
        std::vector<float> result;
        if (!ok) { LOGE("embed goi khi chua init xong"); return result; }
        int w, h, c;
        unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("load fail: %s", imagePath.c_str()); return result; }
        if (w != kSize || h != kSize) {
            LOGE("anh khong phai %dx%d (la %dx%d) — can anh DA CAN CHINH", kSize, kSize, w, h);
            stbi_image_free(data);
            return result;
        }
        std::vector<float> chw((size_t)3 * kSize * kSize);
        for (int y = 0; y < kSize; y++)
            for (int x = 0; x < kSize; x++) {
                const unsigned char* sp = data + ((size_t)y * kSize + x) * 3; // stbi: RGB
                for (int ch = 0; ch < 3; ch++)
                    chw[(size_t)ch * kSize * kSize + (size_t)y * kSize + x] = (sp[ch] - 127.5f) / 127.5f;
            }
        stbi_image_free(data);

        auto inputs = net->getSessionInputAll(session);
        if (inputs.empty()) { LOGE("model khong co input tensor"); return result; }
        MNN::Tensor* input = inputs.begin()->second;
        net->resizeTensor(input, {1, 3, kSize, kSize});
        net->resizeSession(session);
        MNN::Tensor hostIn(input, MNN::Tensor::CAFFE);
        std::memcpy(hostIn.host<float>(), chw.data(), chw.size() * sizeof(float));
        input->copyFromHostTensor(&hostIn);
        net->runSession(session);

        auto outputs = net->getSessionOutputAll(session);
        if (outputs.empty()) { LOGE("model khong co output tensor"); return result; }
        MNN::Tensor* output = outputs.begin()->second;
        MNN::Tensor hostOut(output, MNN::Tensor::CAFFE);
        output->copyToHostTensor(&hostOut);
        long count = 1;
        for (int d : hostOut.shape()) count *= d;
        if (count != kDim) { LOGE("output co %ld phan tu, ky vong %d — model .mnn co dung ArcFace MobileFaceNet khong?", count, kDim); return result; }
        const float* raw = hostOut.host<float>();
        double norm = 0.0;
        for (int i = 0; i < kDim; i++) norm += (double)raw[i] * raw[i];
        norm = std::sqrt(norm);
        if (norm < 1e-9) { LOGE("embedding co chuan ~0"); return result; }
        result.resize(kDim);
        for (int i = 0; i < kDim; i++) result[i] = (float)(raw[i] / norm);
        return result;
    }

    ~ArcFaceWrapper() { if (session && net) net->releaseSession(session); }
};

static std::string j2s_af(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_arcfaceInit(JNIEnv* e, jobject, jstring jDir) {
    auto* w = new ArcFaceWrapper(j2s_af(e, jDir));
    if (!w->ok) { delete w; return 0; }
    return reinterpret_cast<jlong>(w);
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_mangalocal_pipeline_NativeBridge_arcfaceEmbed(JNIEnv* e, jobject, jlong ptr, jstring jImg) {
    if (!ptr) return e->NewFloatArray(0);
    auto emb = reinterpret_cast<ArcFaceWrapper*>(ptr)->embed(j2s_af(e, jImg));
    jfloatArray result = e->NewFloatArray((jsize)emb.size());
    if (!emb.empty()) e->SetFloatArrayRegion(result, 0, (jsize)emb.size(), emb.data());
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_arcfaceFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<ArcFaceWrapper*>(ptr);
}
