# MangaLocal — Full Edition

Chuyển truyện chữ → truyện tranh hoàn toàn local trên Android (Kotlin +
Jetpack Compose + C++ MNN Engine). Quản lý nhiều truyện, nhiều nhân vật,
giữ nhất quán diện mạo qua hàng trăm/nghìn chương, review trước khi
upscale, hội thoại tự động/thủ công, kiểm soát nhiệt độ.

> Tài liệu này là bản tóm tắt tổng quan. Hướng dẫn dùng chi tiết từng màn
> hình: `HUONG_DAN_SU_DUNG.md`. Toàn bộ lịch sử kỹ thuật/quyết định thiết
> kế/giới hạn thật của từng tính năng: `TECHNICAL_STATUS.md` (nguồn sự
> thật chính thức khi 2 tài liệu lệch nhau).

## Tính năng chính

- **Multi-story** — quản lý nhiều truyện độc lập, mỗi truyện có nhân vật/
  cấu hình riêng.
- **Giữ nhất quán nhân vật** — nhiều cơ chế độc lập, chọn theo nhu cầu:
  LoRA ghép cặp, IP-Adapter (ảnh tham chiếu), Textual Inversion, StoryDiffusion
  Consistent Self-Attention (không cần LoRA).
- **Sinh ảnh nhiều nhân vật trong 1 panel** — nhiều pipeline tuỳ tình
  huống: IP-Adapter+ControlNet-pose (1 người), ControlNet-depth (dựng lại
  thứ tự trước/sau khi 2+ người chồng lấn — thuật toán tự tổng quát theo
  N người, mục 169), Mask N-nhân-vật/Regional Prompting/Triple-combo
  (pose+depth+IP-Adapter) — về code không chặn N, nhưng dự án mới TỰ
  export/kiểm thử kỹ ở N=2-4; N lớn hơn (vd 6 người 1 cảnh hỗn chiến) cần
  tự export model đúng N qua `prepare_models.yml` rồi build lại, và CHƯA
  có ai xác nhận chất lượng ảnh/hiệu năng máy ở N đó. Dự án tự chọn pipeline
  phù hợp theo số nhân vật/loại tương tác trong scene.
- **Phiên bản ngoại hình theo chương** — nhân vật lớn lên/đổi trang
  phục/bị thương vĩnh viễn giữa truyện dài, áp dụng đúng từ chương chỉ
  định (ảnh + tỷ lệ cơ thể), không ảnh hưởng chương trước đó.
- **Auto character detection** — LLM on-device tự nhận diện nhân vật mới
  khi sinh chương, tự dịch khái niệm riêng (tên vũ khí, địa danh...) nhất
  quán qua Concept Dictionary.
- **Chế độ Công nghiệp** — sinh hàng loạt nhiều chương liên tiếp, 1
  chương lỗi không làm hỏng cả lô (error shunning), checkpoint tự resume
  nếu app bị hệ điều hành giết giữa chừng, cách ly bước sinh ảnh sang
  tiến trình riêng (giảm rủi ro 1 lỗi native kéo sập cả app — thay đổi
  mới, chưa xác nhận chạy đúng trên mọi máy).
- **Gallery Review** — duyệt/sửa/tạo lại từng panel trước khi upscale;
  sửa tay 1 vùng lỗi (mask thủ công); import ảnh ngoài thay hẳn panel.
- **Upscale 4 mức** — None / 2× / 4× / 4× Sharpen (ESRGAN), có thể chạy
  tách biệt khỏi SD để giảm RAM đỉnh (Industrial Batch Upscale Mode).
- **Bubble hội thoại kép** — Tự động (YOLOv8n detect vị trí) + Thủ công
  (kéo thả).
- **GPU thuê ngoài (tuỳ chọn)** — đẩy panel sang máy chủ Remote GPU nếu
  máy tại chỗ yếu/muốn nhanh hơn, mã hoá hybrid RSA-OAEP + AES-256-GCM.
- **NPU (tuỳ chọn, cần tự build bản riêng)** — chạy UNet trên Qualcomm
  Hexagon qua QNN nếu máy hỗ trợ — xem `HUONG_DAN_NPU_QNN.md`.
- **Thermal control** — đọc nhiệt độ trực tiếp từ kernel, tự dừng khi quá
  nhiệt, rung báo động, tự resume.
- **Chạy nền** — Foreground Service, tắt màn hình vẫn chạy.
- **100% offline** — không filter, không restrict, không gửi dữ liệu
  truyện ra ngoài (trừ khi tự bật GPU thuê ngoài).
- **SDXL (thử nghiệm, chưa build-test)** — đã có tầng dữ liệu, code
  Phase 2 (IP-Adapter/mask/regional/depth) VÀ dispatch/UI Phase 3
  (`TECHNICAL_STATUS.md` mục 171/177-184) — bật được thật qua Cài đặt
  ("SDXL (thử nghiệm)"), nhưng CHƯA chạy thử thật lần nào (không GPU/
  thiết bị lúc viết) — độ phân giải cố định 1024×1024, không có Quality
  Gate/auto-fix. SD1.5 (đã build-test qua CI) vẫn là pipeline chính.

## Build APK (chỉ dùng điện thoại, qua GitHub Actions)

1. github.com → New repository → Public
2. Upload toàn bộ source này (giải nén trước nếu là zip)
3. Tab Actions → tự chạy → khoảng 10-35 phút tuỳ cache
4. Download APK từ Artifacts → cài trên máy

## Setup model

Model dùng định dạng **MNN** (`.mnn`), quản lý qua `model_manifest.json`
(khai model nào có sẵn, pipeline nào, kích thước mặc định...) — KHÔNG
copy tay vào đường dẫn cố định như các bản rất cũ của dự án.

1. Chạy workflow `prepare_models.yml` (GitHub Actions, không cần PC —
   xem chú thích trong chính file đó) để convert checkpoint SD1.5/LLM
   HuggingFace sang `.mnn`.
2. Tải kết quả ở mục Artifacts, copy vào máy (qua Google Drive/Files
   app...).
3. Trong app, vào **Cài đặt** → import từng loại model (LLM/SD/LoRA/
   YOLO/ESRGAN) qua đúng nút tương ứng — app tự quét và khớp với
   `model_manifest.json`.

Chi tiết đầy đủ (bao gồm tính năng tải tự động tuỳ chọn nếu tự host model
ở GitHub Release riêng): `HUONG_DAN_SU_DUNG.md` mục 2.

## Pipeline đầy đủ

```
1. Viết/dán truyện chữ vào Story (hoặc dán JSON kịch bản đã chia scene
   sẵn từ LLM ngoài — ChatGPT/Gemini...)
2. LLM on-device chia scene + tự nhận diện nhân vật mới + dịch khái niệm
   riêng nhất quán
3. SD sinh panel — tự chọn pipeline theo số nhân vật/tương tác trong
   scene (xem "Tính năng chính" ở trên). Mặc định khung ảnh vuông; khác
   vuông NẾU checkpoint hỗ trợ (mới, CHƯA build-test)
   → Thermal monitor theo dõi liên tục, tự dừng nếu quá nóng
4. GALLERY REVIEW — duyệt từng panel, sửa prompt, tạo lại nếu cần, sửa
   tay vùng lỗi
5. Upscale panel đã duyệt (chọn độ phân giải) + sửa mặt/tay tự động
6. Đặt bong bóng thoại — tự động (YOLOv8n) hoặc thủ công kéo thả
7. Xuất PDF + CBZ (độc lập, chọn 1 hoặc cả 2) → tuỳ chọn dọn dẹp file
   ảnh gốc sau khi xuất để đỡ tốn bộ nhớ máy
```

Chế độ Công nghiệp (mục 5, `HUONG_DAN_SU_DUNG.md`) gộp bước 1-3 cho nhiều
chương liên tiếp, bỏ qua bước duyệt tay — vẫn cần vào Gallery Review sau
đó cho từng chương như luồng thủ công.

## Lưu ý nhiệt độ

App đọc nhiệt độ trực tiếp từ kernel thermal_zone, không cần root.
Ngưỡng dừng/tiếp tục chỉnh được trong Cài đặt (mặc định tham khảo ~42°C
dừng / ~39°C tiếp tục — số thật tuỳ cấu hình máy).
Khuyến nghị bật chế độ máy bay khi generate để tránh nhiễu nhiệt từ mạng
(trừ khi đang dùng GPU thuê ngoài, khi đó cần mạng).

## Hiệu năng

Không có bảng số liệu cố định ở đây — pipeline hiện có nhiều nhánh khác
nhau (1 người / nhiều người / regional / NPU / Remote GPU...) với thời
gian chênh lệch đáng kể tuỳ nhánh và cấu hình máy, số benchmark cũ (bản
pipeline đơn giản trước khi có IP-Adapter/ControlNet) không còn phản ánh
đúng thực tế. Xem log runtime trong app (`RuntimeOptimizer`) để biết thời
gian thật trên đúng máy đang dùng.
