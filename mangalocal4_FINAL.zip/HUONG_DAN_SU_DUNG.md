# MangaLocal — Hướng dẫn sử dụng & luồng quy trình hoạt động

> Tài liệu này mô tả **luồng thật trong code** (`MainActivity.kt` NavHost,
> `MainViewModel.kt`, các file `ui/*.kt`) — không phải mô tả lý tưởng hoá.
> Mọi tên hàm/route nhắc tới đều tồn tại thật trong source, đối chiếu
> trực tiếp lúc viết tài liệu này. Nhắc lại điều quan trọng nhất từ
> `TECHNICAL_STATUS.md` mục 0: **toàn bộ app CHƯA từng build-test/chạy
> thật lần nào** — tài liệu này mô tả app sẽ hoạt động NHƯ THẾ NÀO theo
> đúng thiết kế code, không phải xác nhận đã chạy đúng trên máy thật.

---

## 1. Tổng quan — MangaLocal là gì

Ứng dụng Android sinh truyện tranh (manga/manhwa) từ văn bản, chạy
**local-first** (mọi model AI chạy ngay trên điện thoại, không bắt buộc
mạng) — có tuỳ chọn định tuyến một phần công việc sang GPU thuê ngoài
(Colab/RunPod/Vast.ai) nếu muốn nhanh hơn hoặc máy yếu.

Input: văn bản truyện (dán tay hoặc dán JSON kịch bản đã chia scene sẵn
từ LLM ngoài app). Output: chuỗi ảnh panel truyện tranh có bubble thoại,
xuất ra PDF và/hoặc CBZ.

---

## 2. Chuẩn bị trước khi dùng lần đầu — model bắt buộc

App **không tự tải model qua mạng theo mặc định** (bảo mật offline) —
phải tự nạp model tĩnh vào máy trước. Vào màn **Cài đặt** (`settings`) để:

1. **LLM model** (bắt buộc) — dùng để đọc hiểu văn bản truyện, chia
   scene, viết prompt. Import qua nút trong Settings (`importLlmModels()`).
2. **SD model** (bắt buộc) — model sinh ảnh chính. **SD1.5** có đầy đủ
   tính năng (IP-Adapter/LoRA/ControlNet-Pose/mask/regional — xem mục
   3.5 dưới), ĐÃ build-test qua CI thật (build #97) — dùng cho luồng
   chính của app. **SDXL Local** (`TECHNICAL_STATUS.md` mục 171/177-184):
   đã xong tầng dữ liệu (Phase 1), đã viết xong ở tầng code cả 5 pipeline
   augmented/mask/regional/regional-mask/depth (Phase 2, mục 177-181), VÀ
   NAY ĐÃ NỐI dispatch thật + có UI bật (Phase 3, mục 184 — thẻ "SDXL
   (thử nghiệm)" trong Cài đặt: Switch chọn dùng SDXL + ô chọn thư mục
   model SDXL riêng — **mục 204**: giờ có dropdown quét sẵn thư mục nào
   trong `modelsDir` đã đủ file SDXL tối thiểu, kèm nút refresh; thư mục
   chưa đủ file (đang copy dở) không hiện ở dropdown — vẫn gõ tay được ở
   ô text ngay bên dưới, không mất lựa chọn nào). **NHƯNG TOÀN BỘ đường SDXL — cả Phase 2 lẫn
   Phase 3 — CHƯA build-test/CHƯA chạy thử thật lần nào** (không GPU/
   thiết bị thật lúc viết) — bật lên có thể sinh ảnh lỗi, rất chậm, hoặc
   crash, khác hẳn mức độ tin cậy của SD1.5. Dùng SD1.5 cho luồng chính —
   chỉ bật SDXL nếu chấp nhận rủi ro và muốn tự thử nghiệm (chọn được
   768×768 hoặc 1024×1024 ở Cài đặt — mục 189, KHÔNG có 512 vì lý do kỹ
   thuật; **(mục 205)** giờ ĐÃ có Quality Gate — badge cảnh báo hiện đúng
   cho panel SDXL trực tiếp, nhưng KHÔNG có phương án SDXL-thay-thế nào
   khác nếu chính panel SDXL đó không đạt (đã là SDXL rồi). **(mục 207)**
   giờ ĐÃ có auto-fix giao thoa (2 nhân vật đè/chạm nhau) — tự bật cùng
   Switch "Tự sửa giao thoa" (mục 7) như SD1.5, dùng model `unet_sdxl.mnn`
   có sẵn cùng thư mục augmented; vẫn CHƯA có Multi-Pass Cascade riêng cho
   nhánh này (tính năng khác, sâu hơn — xem GIỚI HẠN THẬT ở mục 184/189/
   205/207). **(Mới, mục 192/193)** App tự đọc file
   `sdxl_resolution.txt` do `prepare_models.yml` ghi lúc export để biết
   ĐÚNG độ phân giải thật — Cài đặt hiện dòng "Độ phân giải THẬT" báo
   khớp (✓) hay lệch (⚠). **Lưu ý nếu bạn giữ `prepare_models.yml` tách
   riêng ngoài thư mục dự án**: phải là bản có input `sdxl_image_size`
   (mở file tìm chữ `image_size` — 0 kết quả là bản cũ, tuỳ chọn 768 sẽ
   không dùng được dù Cài đặt cho chọn, xem `TECHNICAL_STATUS.md` mục
   203) — nên luôn lấy lại nguyên thư mục dự án thay vì giữ riêng 1 file
   `.yml` cũ để tránh lệch pha.
   `rescanModels()` tự quét thư mục model SD1.5 đã copy vào máy (qua
   Google Drive/Files app...), khớp với `model_manifest.json` — model
   SDXL augmented KHÔNG qua cơ chế này, gõ tay tên thư mục ở Cài đặt.
3. **LoRA** (tuỳ chọn, cho nhân vật cần giữ mặt) — import qua
   `importLoras()`.
4. **YOLO model** (bubble detect + pose) — `importYoloModels()`.
5. **ESRGAN model** (upscale) — `importEsrganModels()`.

`modelSetupGuide()`/`modelStatus()` trong ViewModel cho biết còn thiếu
model nào — Settings hiện trực tiếp trạng thái này.

**(Mới, TECHNICAL_STATUS.md mục 161 đợt 3) Tải model tự động — TUỲ
CHỌN, KHÔNG bắt buộc**: card "Tải model tự động" trong Settings hiện nút
tải trực tiếp CHO ĐÚNG file nào `model_manifest.json` có khai URL. Mặc
định KHÔNG có URL nào (không ai host sẵn model 6-8GB nào cả) — mọi model
vẫn phải tự copy tay như trước nếu chưa tự cấu hình URL. Đây là hạ tầng
CHO NGƯỜI TỰ HOST model của mình (VD tự tạo GitHub Release), không phải
tính năng "bấm nút là có model" cho người dùng thông thường — xem
`model_manifest.json` mục `_download_mau` để biết cách điền URL nếu tự
host.

**Máy yếu (dưới 8GB RAM)**: bật "Chế độ 4 Giai đoạn Công nghiệp"
(`industrialBatchUpscaleMode`) trong Settings — SD/ESRGAN/YOLO/SAM được
nạp và giải phóng tuần tự thay vì giữ tất cả cùng lúc trong RAM.

---

## 3. Luồng chính — từ văn bản tới ảnh truyện tranh

```
StoryListScreen ─▶ StoryDetailScreen ─▶ [CharacterSummaryReviewScreen] ─▶ [RoutingReviewScreen] ─▶ GeneratingScreen
   (stories)         (story_detail)      (chỉ khi có nhân vật mới)          (routing_review)        (generating)
                                                                                                            │
                                                                                                            ▼
   PostProcessingScreen ◀── proceedToUpscale() ◀── GalleryReviewScreen (gallery_review)
   (post_processing)                                    (duyệt từng panel)
          │
          ▼
   Export PDF/CBZ
```

### Bước 1 — Tạo truyện (`StoryListScreen` → `StoryDetailScreen`)

`createStory(title, description, style, worldRules, promptGuideNotes)` —
chọn phong cách ảnh (checkpoint anime/manga hay cinematic — quyết định
`PromptStyle` LLM dùng để viết prompt, xem `TECHNICAL_STATUS.md` mục 7).
`worldRules`/`promptGuideNotes` là ghi chú tự do user viết thêm, LLM đọc
kèm khi viết kịch bản.

### Bước 2 — Tạo nhân vật (`CharactersDetailScreen`)

`addCharacter(name, anchor, neg, role, loraPath, seed)` — mỗi nhân vật
chọn 1 **vai trò** (`CharacterRole`): `MAIN` (vai chính, xuất hiện nhiều
— nên dùng LoRA cho giống mặt nhất), `SUPPORTING` (vai phụ — gợi ý
IP-Adapter, nhẹ hơn LoRA), `ONETIME` (xuất hiện 1 lần — thường không cần
giữ nhất quán).

Chọn 1 trong 4 **phương pháp giữ nhất quán khuôn mặt**
(`ConsistencyMethod`): `LORA` (giống mặt nhất, cần convert trước —
`convertCharacterLora()`), `IP_ADAPTER` (dùng 1 ảnh neo, không cần
convert — `setCharacterAnchorImage()`), `TEXTUAL_INVERSION` (nhẹ nhất,
`setCharacterEmbeddingFromSource()`/`...FromUri()`), hoặc `NONE`.

2 nhân vật cùng xuất hiện chung nhiều panel? Cân nhắc convert GHÉP CẶP
(`convertCharacterPair()`) — 1 checkpoint chứa cả 2 LoRA, giảm rò rỉ đặc
điểm giữa 2 người (kỹ thuật Orthogonal LoRA, xem `TECHNICAL_STATUS.md`
mục 3).

Muốn xem trước ảnh neo/LoRA cho ra mặt nhân vật thế nào trước khi dùng
thật? `generateAnchorCandidates()` sinh vài ảnh ứng viên,
`approveAnchorCandidate()` chọn 1 ảnh làm chính thức.

**(Mới, TECHNICAL_STATUS.md mục 161 đợt 2) Nhân vật lớn lên/đổi trang
phục/bị thương vĩnh viễn giữa truyện?** Trong màn sửa nhân vật, nút "Tạo
phiên bản ngoại hình mới" — nhập mô tả thay đổi (VD "có sẹo trên má
trái") + chọn áp dụng từ chương số mấy + tuỳ chọn đổi tỷ lệ cơ thể (Trẻ
em/Thiếu niên/Người lớn, nếu là "lớn lên") → chọn 1 trong 4 ảnh nháp.
Panel từ chương đó trở đi TỰ ĐỘNG dùng ảnh + tỷ lệ mới, chương trước đó
không đổi gì. Kích hoạt THỦ CÔNG (không có tự động phát hiện "nhân vật
đổi trang phục" từ văn bản truyện).

(Tuỳ chọn) **Quan hệ gia đình** (`FamilyRelationshipScreen`, route
`family`) — khai báo quan hệ giữa các nhân vật (cha/mẹ/con/anh em...) để
LLM viết kịch bản nhất quán về xưng hô/tương tác.

**(Mục 248) Thư viện nhân vật dùng chung**: nút "📚 Thư viện nhân vật" trên màn hình này mở hộp thoại để (a) lưu một nhân vật của truyện hiện tại vào thư viện (hồ sơ, seed, LoRA/embedding, tỉ lệ xương và ảnh anchor/anchor rách/anchor biểu cảm được SAO CHÉP, xoá truyện gốc không mất) và (b) nhập nhân vật từ thư viện vào truyện đang mở (id mới; trùng tên thì thêm "(2)"). Phiên bản anchor theo chương KHÔNG đi theo; file LoRA/embedding chỉ ghi đường dẫn nên chỉ còn hiệu lực trên cùng thiết bị. Chưa build-test.

### Bước 3 — Dán văn bản truyện (`StoryDetailScreen`)

2 cách đưa nội dung vào:
- **Dán văn bản thô** — gõ/dán trực tiếp, `analyzeStoryText()` tự đếm số
  chương phát hiện được (theo `TextChunker.split()`). Nếu vượt ngưỡng
  (`TextChunker.INDUSTRIAL_SUGGEST_THRESHOLD`), app hỏi có muốn chạy
  **Chế độ Công nghiệp** không (xem mục 5 bên dưới) thay vì làm tay từng
  chương.
- **Dán JSON kịch bản ngoài** (`prepareChapterFromExternalScript()`) —
  nếu đã tự dùng LLM khác (ChatGPT/Gemini...) chia scene sẵn theo đúng
  format `ExternalScriptImport.kt` quy định. Vẫn cần LLM on-device (chỉ
  để dịch prompt sang tag SD, không parse lại kịch bản).

Cả 2 cách đều gọi `analyzeCharactersFirst()`/`prepareChapterFromExternalScript()`
— **KHÔNG viết kịch bản chi tiết ngay** (mục 154 TECHNICAL_STATUS.md,
"đảo pipeline nhân vật"). Xem Bước 3.5 ngay dưới.

**(Mục 249) Chỉ định bối cảnh ngay trong văn bản**: gõ `@Tên bối cảnh đã có` (không phân biệt hoa/thường/dấu; lấy tên dài nhất) hoặc `@[Tên bối cảnh mới]` để báo cảnh xảy ra ở đâu. Thẻ có hiệu lực **từ chỗ nhắc tới thẻ kế tiếp** (như dòng slug trong kịch bản). App bỏ ký hiệu `@` trước khi gửi LLM, thêm một dòng hướng dẫn, rồi hậu xử lý: cảnh LLM để trống nhận bối cảnh theo vị trí; LLM được chọn giữa các bối cảnh đã nhắc nhưng không được bịa nơi khác ở vị trí đã gắn thẻ. **Giới hạn**: ánh xạ cảnh ↔ vị trí trong văn bản chỉ là xấp xỉ theo tỉ lệ (cảnh sát chỗ đổi bối cảnh có thể bị gán sang bên kia); chỉ chỉ định bối cảnh, không chỉ định nhân vật; địa chỉ email hay `@tên_người` không khớp bối cảnh nào thì bị bỏ qua. Chưa thử với LLM thật.

### Bước 3.5 — Xác nhận nhân vật mới (`CharacterSummaryReviewScreen`, chỉ hiện khi cần)

`analyzeCharactersFirst()` chạy 1 lượt LLM RẺ (không chia panel, chỉ đọc
tên + đoán vai trò + tóm 1 câu) TRƯỚC khi viết kịch bản chi tiết. **Chỉ
dừng lại xin xác nhận nếu phát hiện nhân vật MỚI** (chưa có trong
`story.characters`) — chương 2 trở đi (mọi nhân vật đã biết) tự động bỏ
qua bước này, chảy thẳng sang Bước 4 như đường dán JSON.

Nếu có nhân vật mới, màn `CharacterSummaryReviewScreen` hiện ra (thiết kế
mobile: 1 card/nhân vật cuộn dọc, chip to cho vai trò, nút xác nhận ghim
cố định ở đáy màn hình):
- Sửa vai trò (Chính/Phụ/Một lần) nếu AI đoán sai.
- Đánh dấu **"Cần giữ mặt nhất quán qua nhiều khung ảnh?"** (Có/Không) —
  CHỈ dùng làm gợi ý TẠM cho LLM viết kịch bản né ghép chung panel những
  người cần tách riêng — KHÔNG tự động set LoRA/IP-Adapter thật (vẫn phải
  tự làm ở Bước 2 như bình thường, đây chỉ là gợi ý sớm giúp bố cục panel
  hợp lý hơn ngay từ đầu).
- Xoá (nút ✕) nếu AI nhận nhầm tên không phải nhân vật.
- **"Xác nhận → Viết kịch bản"** (chính) hoặc **"Dùng gợi ý mặc định,
  viết luôn"** (bỏ qua chỉnh sửa, chấp nhận nguyên văn AI đoán) hoặc
  **"Huỷ"** (quay lại ô dán văn bản, không tạo gì).

Sau khi xác nhận, `confirmCharacterSummaryAndProceed()` tạo `Character`
mới cho từng người (role đã chọn, mô tả AI tóm làm anchor prompt tạm —
nên vào Bước 2 viết lại chi tiết hơn sau) rồi MỚI gọi `prepareChapter()`
thật — kết quả vào `_pendingChapter` (CHƯA sinh ảnh, chỉ mới có kịch bản
+ prompt).

### Bước 4 — Duyệt định tuyến Local/Remote (`RoutingReviewScreen`, tuỳ chọn)

Chỉ có ý nghĩa nếu đã cấu hình GPU thuê ngoài (xem mục 6). Màn này cho
xem trước panel nào sẽ chạy Local (điện thoại), panel nào chạy Remote
(GPU cloud) — theo `RoutingMode.MANUAL` (rule tự đặt) hoặc `AUTO` (LLM tự
quyết theo mô tả tiếng Việt tự do user viết trong Settings). Có thể sửa
tay từng panel qua `setBatchBackend()` trước khi xác nhận. Không cấu hình
Remote → mọi panel mặc định Local, có thể bỏ qua màn này.

### Bước 5 — Sinh ảnh (`GeneratingScreen`)

`confirmRoutingAndGenerate()` → `pipeline.runGeneration()` — chạy UNet
thật cho từng panel (chọn đúng pipeline theo số nhân vật/có cần
Depth/Regional Prompting hay không, xem `TECHNICAL_STATUS.md` mục 3).
Có thể `cancelGeneration()` giữa chừng (cờ interrupt JNI dừng ở step kế
tiếp, xem mục 10 — không dừng ngay lập tức tuyệt đối).

### Bước 6 — Duyệt từng panel (`GalleryReviewScreen`)

Với mỗi panel đã sinh, chọn 1 trong các hành động:
- **Duyệt** (`approvePanel()`) — panel đạt yêu cầu, chuyển trạng thái
  `APPROVED`.
- **Sinh lại** (`regeneratePanel()`) — không ưng ý, chạy lại (có thể sửa
  prompt tay hoặc chỉnh override riêng panel đó).
- **Sửa tay 1 vùng lỗi** (`manualMaskFixPanel()`) — chấm tay vào điểm
  lỗi (vd tay biến dạng), app tự vẽ mask quanh đó rồi img2img sửa riêng
  vùng đó (không sinh lại cả panel).
- **Import ảnh ngoài thay hẳn panel này** (`importPanelImage()`) — có sẵn
  ảnh vẽ tay/lấy nguồn khác, bỏ qua AI sinh hoàn toàn cho panel đó (xem
  `TECHNICAL_STATUS.md` mục 12).
- **Sửa tư thế tay** (`pose_editor`) — mở `PoseEditorScreen`, kéo/chỉnh
  khớp xương panel đó trước khi sinh lại (pinch-to-zoom hỗ trợ chỉnh chi
  tiết trên màn nhỏ).

**(Mới, TECHNICAL_STATUS.md mục 185-197) Cảnh báo Quality Gate + 2 ô tuỳ
chỉnh thêm khi mở `EditPanelSheet`**: panel bị nghi khung xương đầu vào
có vấn đề (dựa trên khung xương, KHÔNG phải nhìn pixel ảnh đã sinh — mục
185) hiện badge **"⚠ Nên xem kỹ"** ở góc ảnh; mở sheet để xem chi tiết lý
do (chỉ là gợi ý xác suất, ảnh vẫn có thể đẹp dù bị đánh dấu và ngược
lại, cần tự nhìn ảnh để quyết định). Lúc sinh hàng loạt
(`generatePanels()`), nếu panel dùng SD1.5 mà không đạt Quality Gate, app
tự thử sinh lại 1 lần bằng SDXL làm phương án thay thế (cần đã cấu hình
`sdxlModelId` ở mục 2) — không có gì đảm bảo ảnh SDXL tốt hơn, chỉ là 1
lựa chọn khác để tự so sánh.

Trong sheet còn có:
- **Model tier riêng cho panel này** — chip "Tự động (Cài đặt)"/"SD1.5"/
  "SDXL (thử nghiệm)", ghi đè lựa chọn chung chỉ cho panel đang sửa, áp
  dụng khi bấm "Vẽ lại".
- **Biểu cảm riêng từng nhân vật** (chỉ hiện với panel ≥2 người) — mỗi
  người 1 hàng chip chọn 1 trong 12 biểu cảm, hoặc để "Theo LLM" (giữ
  nguyên LLM tự phân loại). Chỉ có tác dụng khi bật `enableMultiPassCascade`
  (mục 7) VÀ khi bấm "Vẽ lại" — muốn áp dụng lúc sinh hàng loạt, phải tự
  đặt trước khi chạy batch.

### Bước 7 — Hậu kỳ (`PostProcessingScreen`)

`proceedToUpscale()` — chạy ESRGAN nâng độ phân giải + Ultrafix (vẽ lại
nhẹ toàn ảnh) + auto-fix mặt/tay cho mọi panel đã `APPROVED`. Sau đó
`runAutoBubble()` — tự đặt bubble thoại (YOLO detect bóng thoại trống,
đặt chữ theo thoại đã sinh). Có thể sửa tay vị trí/nội dung bubble từng
panel (`updatePanelBubbles()`) trước khi xuất.

**(Mục 228 + 249) Bóng thoại theo người nói, đuôi và lớp**: khi panel có khung xương đầu vào, bubble được đặt né khuôn mặt, gần người đang nói, và khi XUẤT PDF/CBZ có đuôi trỏ về phía đầu người nói (lời thoại dài tự xuống dòng, không bị cắt bằng "…" nếu ≤ 8 dòng). **Mục 249**: trong màn sửa bubble, bubble nào có đuôi sẽ hiện một đường kèm **chấm cam** — kéo chấm để chỉ đích đuôi; nhấn bubble để mở hộp thoại: đổi **loại** (Thoại / Nghĩ / Dẫn / Hét), bật/tắt **đuôi** (bật mà chưa có thì đặt đuôi mặc định bên dưới bubble) và đổi **lớp** (Lên trên / Xuống dưới — bubble đứng sau trong danh sách được vẽ đè lên trên). Cùng lúc đó tôi sửa lỗi cũ: vị trí hiển thị và độ dời khi kéo trước đây dùng hằng 300 và chia pixel cho 300 nên bubble hiển thị lệch so với file xuất và di chuyển nhanh hơn ngón tay; nay dùng cạnh thật của khung và đổi px→dp. Chưa chọn được font/cỡ chữ (bộ vẽ tự co chữ). Chưa thử cảm ứng trên máy thật. Panel không có khung xương (vd nhánh GLIGEN/SDXL không dùng pose) thì bubble đặt theo cách cũ, không đuôi tự động (vẫn bật đuôi tay được).

### Bước 8 — Xuất file

`exportChapter(exportPdf, exportCbz, destUri)` — xuất PDF và/hoặc CBZ (2
định dạng độc lập, chọn 1 hoặc cả 2). Mặc định lưu vào thư mục nội bộ app
(`storyManager.outputDir()`); nếu chọn `destUri` (qua trình chọn thư mục
hệ thống), file được copy thêm ra vị trí đó (vd thư mục chia sẻ Google
Drive) — không thay thế bản nội bộ.

**(Mới, TECHNICAL_STATUS.md mục 161 đợt 4) Dọn dẹp file trung gian —
TUỲ CHỌN, hiện SAU KHI xuất `.cbz` thành công**: card "Dọn dẹp file
trung gian" — 2 lựa chọn: **Nén còn sửa được** (PNG panel gốc → JPEG
chất lượng cao, vẫn sửa lại được sau, giảm dung lượng đáng kể) hoặc
**Xoá hẳn** (giải phóng tối đa, MẤT khả năng sửa lại panel đó — "Tạo lại"
sẽ phải sinh mới hoàn toàn). File `.cbz`/`.pdf` đã xuất KHÔNG bị ảnh
hưởng dù chọn cách nào. Hữu ích khi chạy nhiều chương liên tiếp trên máy
ROM nhỏ (panel PNG gốc có thể tới ~1GB/chương sau upscale).

---

## 3.5. Nhiều nhân vật trong 1 khung ảnh (tuỳ chọn, cần model riêng)

**(Mới, TECHNICAL_STATUS.md mục 175 — mục này trước đây CHƯA từng được
viết vào tài liệu dù code đã có từ mục 51/52/56/69/143/151/152/172, đã vá
lại đúng gap đó ở đây.)**

Khi 1 panel có ≥2 nhân vật cần giữ mặt nhất quán, và cài đặt
`useStoryDiffusion` đang BẬT (mục 7 dưới, mặc định bật), app tự chọn 1
trong 5 cách sinh ảnh sau — đúng thứ tự ưu tiên này (đối chiếu trực tiếp
chuỗi if/else thật trong `MangaPipeline.kt`, không phải suy đoán):

1. **Triple-Combo** (Pose + Depth + IP-Adapter + Regional Prompting cùng
   lúc) — ưu tiên cao nhất, cần file `unet_triple_combo_{N}region.mnn`
   VÀ mọi nhân vật trong cảnh đã có ảnh neo. Cho kết quả tốt nhất ở cảnh
   nhiều người vật lộn/ôm nhau, nhưng cũng nặng nhất.
2. **Mask N-nhân-vật** (mỗi người 1 vùng mask + 1 ảnh neo IP-Adapter
   riêng) — dùng nếu có file `unet_ipa_mask_controlnet_{N}char.mnn`
   nhưng không có Triple-Combo. Giữ mặt tốt cho từng người.
3. **Regional-Mask / Attention Couple** (mask hình dạng tuỳ ý theo tư
   thế, KHÔNG dùng ảnh neo — chỉ chữ mô tả mỗi vùng) — dùng nếu có file
   `unet_regional_mask_controlnet_{N}char.mnn` nhưng không có 2 cái trên.
4. **Regional Prompting cột** (chia đều theo cột dọc, cũng chỉ dùng chữ
   mô tả mỗi vùng) — dùng nếu có file
   `unet_regional_controlnet_{N}col.mnn` nhưng không có 3 cái trên.
5. **Mặc định** (không có file nào ở trên) — dùng LoRA ghép cặp nếu đã
   convert (mục 3), hoặc chỉ neo 1 nhân vật chính bằng IP-Adapter/LoRA;
   người còn lại chỉ có tư thế (ControlNet-Pose), không giữ mặt.

**Cách lấy các file `.mnn` trên**: chạy workflow `prepare_models.yml`
(GitHub Actions, xem mục 2) với đúng input tương ứng bật lên
(`export_mask_variant`/`export_regional_variant`/
`export_regional_mask_variant`/`export_triple_combo_variant` — mỗi cái
có ô nhập số nhân vật N riêng; chạy lại workflow nếu cần nhiều N khác
nhau), rồi copy file `.mnn` tải về (mục Artifacts của lần chạy) vào đúng
thư mục model trên máy — KHÔNG cần đổi tên file, `StoryManager` tự dò
đúng tên.

**Depth ControlNet** (`export_depth_variant`) là 1 trường hợp RIÊNG —
KHÔNG phải 1 trong 5 pipeline trên, mà là bản THAY THẾ file
`unet_ipa_controlnet.mnn` gốc (TÊN GIỐNG HỆT — app tự dò input
`depth_hint` có tồn tại trong file hay không, không cần bật cờ gì khác)
— giúp app đoán đúng hơn ai đứng trước/sau khi 2 khung xương chồng lấn.
Workflow đóng gói file này vào thư mục con `depth_variant/` riêng để
không đè bản gốc — tự chọn copy-thay-thế nếu muốn dùng.

**Giới hạn thật**: cả 5 cách trên đều yêu cầu `useStoryDiffusion=true` VÀ
mỗi nhân vật phải có ảnh neo hợp lệ — thiếu 1 trong 2 điều kiện, app tự
rơi xuống cách sinh ảnh đơn giản hơn ở dưới, KHÔNG báo lỗi. Toàn bộ 5
file `.mnn` trên (khác với 3 file mặc định máy đã dùng: `clip`/`unet`/
`vae`) đều CHƯA được build-test bằng ảnh thật trên thiết bị — dùng thử và
báo lại nếu ảnh ra sai/lỗi (xem `TECHNICAL_STATUS.md` mục 175 cho chi
tiết kỹ thuật, bao gồm 1 bug đã vá: file `regional_mask_prompting.cpp`
từng thiếu 1 dòng biên dịch trong `CMakeLists.txt`, khiến pipeline #3
từng chắc chắn crash nếu dùng thử trước bản vá đó).

---

**(Mục 250) Hậu kỳ trên server cho cảnh tiếp xúc/nhiều người**: ba công tắc trong Cài đặt > Remote GPU chạy sau bước Phóng to theo thứ tự **Kontext → sửa tay → hoán đổi mặt**; kết quả ghi thành file mới `panel_NNN_srv.png` (ảnh gốc giữ nguyên). Lỗi một panel thì giữ ảnh cũ của panel đó; server cũ không hỗ trợ tác vụ thì dừng ngay (không phí các lượt còn lại). Xem cách dựng server và giấy phép ở `tools/remote_server/README.md`.

**(Mục 249) Gộp hai LoRA nhân vật bằng TIES/DARE (công cụ ngoại tuyến, cho nhánh Remote GPU)**: `python tools/lora_ties_merge.py a.safetensors b.safetensors -o merged.safetensors --method ties --density 0.5` gộp nhiều LoRA kohya thành MỘT file thay vì cộng thẳng (cắt bớt tham số nhỏ, bỏ phần tử trái dấu, rồi SVD về lại dạng LoRA). Đặt `merged.safetensors` vào `--loras-dir` của server và gửi như một `lora_id` cho cảnh nhiều người. **Đường on-device không đổi.** Chưa có bằng chứng trong dự án rằng nó giảm rò danh tính giữa hai nhân vật — phải thử: sinh cùng seed với LoRA gộp thường và LoRA gộp TIES rồi so.

## 4. Vòng lặp nhiều chương

`selectChapter()` chuyển qua lại giữa các chương đã lưu của cùng truyện.
Mỗi chương độc lập — lặp lại Bước 3→8 cho chương tiếp theo. Ảnh nhân vật
neo (LoRA/IP-Adapter/Textual Inversion) dùng CHUNG cho mọi chương của

cùng truyện, không cần cấu hình lại.

---

## 5. Chế độ Công nghiệp — sinh hàng loạt nhiều chương liên tiếp

Dùng khi có sẵn TOÀN BỘ truyện dài (hàng chục/hàng trăm chương) và muốn
chạy xuyên đêm không cần ngồi duyệt routing từng chương.

`analyzeStoryText()` tự gợi ý chế độ này nếu phát hiện đủ số chương.
`runIndustrialBatch(chapters)` chạy tuần tự: mỗi chương tự
`prepareChapter()` rồi `runGeneration()` NGAY (không dừng chờ duyệt
routing như luồng thủ công) — vẫn qua đúng `BackendRouter` tự động.

**An toàn cho batch dài**: mỗi chương lỗi (văn bản dị dạng, ảnh hỏng...)
CHỈ bị bỏ qua (ghi log), KHÔNG làm chết cả batch (error shunning, xem
`TECHNICAL_STATUS.md` mục 10). Nếu app bị hệ điều hành giết giữa batch
dài (RAM/pin/nhiệt), lần mở app sau `peekResumableBatch()` phát hiện có
batch dở dang của đúng truyện đang mở — dán lại ĐÚNG văn bản cũ,
`runIndustrialBatch()` tự nhận ra (so khớp hash) và resume đúng chỗ dở
dang, không sinh lại từ đầu. `cancelIndustrialBatch()` dừng tay giữa
chừng bất kỳ lúc nào.

**(Mới, TECHNICAL_STATUS.md mục 161 đợt 8-10) Cách ly lỗi native —
CHƯA build-test, đọc kỹ giới hạn**: bước SINH ẢNH (không phải bước phân
tích văn bản) giờ chạy trong 1 tiến trình Android RIÊNG
(`:inference`) — nếu có lỗi crash ở tầng native/thư viện AI trong lúc
sinh 1 chương, về LÝ THUYẾT chỉ chương đó bị đánh dấu lỗi (rơi vào đúng
cơ chế error shunning ở trên) và batch tiếp tục, thay vì kéo sập toàn bộ
app như trước. Đây là thay đổi kiến trúc LỚN, MỚI VIẾT, **CHƯA có xác
nhận chạy đúng trên thiết bị thật** — nếu gặp app vẫn tắt hẳn khi batch
dài, đó là dấu hiệu cần báo lại để kiểm tra, không phải "chưa đọc kỹ tài
liệu này".

Sau khi batch chạy xong, vẫn cần vào từng chương để duyệt panel (Bước
6-8) như luồng thủ công — Chế độ Công nghiệp chỉ tự động hoá bước SINH
ẢNH hàng loạt, không tự động hoá bước duyệt/hậu kỳ/xuất file.

---

## 6. GPU thuê ngoài (tuỳ chọn — máy yếu hoặc muốn nhanh hơn)

Không bắt buộc — bỏ qua mục này nếu chỉ chạy Local. Cần khi máy quá yếu
để chạy SD local ở tốc độ chấp nhận được, hoặc muốn dùng SDXL (nặng hơn
SD1.5 nhiều).

**Lưu ý riêng cho SDXL qua GPU thuê ngoài (khác hẳn SDXL chạy Local, xem
mục 2)**: `tools/remote_server/app.py` dùng thẳng thư viện `diffusers`
trên máy chủ, nên SDXL ở ĐÂY đã có sẵn ControlNet-Pose + IP-Adapter (1
nhân vật) — KHÔNG bị giới hạn "chỉ sinh ảnh cơ bản" như SDXL chạy Local.
Nhưng vẫn có 2 giới hạn thật, áp dụng NHƯ NHAU cho cả SD1.5 lẫn SDXL khi
chạy qua GPU thuê ngoài (không riêng gì SDXL): (1) KHÔNG nhận LoRA khi
đang ở SDXL (server tự bỏ qua + log cảnh báo nếu app gửi `lora_id`, do
kiến trúc UNet SDXL khác hẳn SD1.5), (2) KHÔNG có bất kỳ pipeline nào
trong 5 pipeline nhiều-nhân-vật ở mục 3.5 (mask/regional/regional-mask/
triple-combo/depth) — những pipeline đó là code C++ tuỳ biến riêng cho
máy chạy Local, server Python chưa từng cài đặt lại.

1. Chạy `tools/remote_server/app.py` trên máy có GPU (Colab miễn phí là
   lựa chọn dễ nhất — dùng notebook đính kèm, Cloudflare Tunnel tự lộ ra
   Internet không cần đăng ký).
2. Nhập địa chỉ server vào Settings — app tự xác thực bằng cặp khoá
   RSA-OAEP + fingerprint TOFU (tự sinh lúc đầu, cảnh báo nếu fingerprint
   đổi ở lần kết nối sau — dấu hiệu server đã đổi, không tự động tin).
3. Chọn `RoutingMode`: `MANUAL` (tự đặt rule — vd "panel có ≥3 nhân vật
   → Remote") hoặc `AUTO` (viết mô tả tiêu chí bằng tiếng Việt tự nhiên,
   LLM on-device tự áp dụng).
4. `RoutingReviewScreen` (Bước 4 ở trên) hiện ra để duyệt/sửa tay trước
   khi sinh — LUÔN có bước duyệt này khi có panel định tuyến Remote,
   không tự động chạy thẳng.

**Giới hạn bảo mật thật** (đọc kỹ trước khi dùng GPU thuê ngoài — không
phải chỉ cảnh báo hình thức): mã hoá RSA+AES chỉ chống người thứ 3 nghe
lén trên đường truyền mạng — **không chống được chính chủ máy chủ GPU**
(họ có quyền truy cập VM đang chạy prompt/ảnh của bạn dạng plaintext lúc
xử lý). Chỉ dùng Remote cho nội dung sẵn sàng để lộ cho chủ hạ tầng thuê
thấy. Xem `TECHNICAL_STATUS.md` mục 9/14 để hiểu đầy đủ.

### 6.5. API miễn phí (tuỳ chọn) — tạo ảnh nền địa điểm, ảnh phác nhân vật, LLM, giám khảo ảnh

Ngoài GPU thuê ngoài, một số việc có thể dùng **API miễn phí** của bên thứ ba. Chúng chỉ là lựa chọn thêm: không chọn thì app chạy đúng như trước.
**Tất cả đều gửi dữ liệu ra Internet** (khác tinh thần offline của app) và có **hạn mức theo ngày/phút** — hết hạn mức thì app báo rõ lý do chứ không đứng im.
Khoá API/token nhập ở đây mặc định **không được lưu** (đóng app là phải nhập lại); muốn app nhớ thì bật **Cài đặt > lưu cài đặt > Nhớ khoá API trên máy này** (xem mục 7.0).

- **Ảnh nền địa điểm không có người**: màn *Bối cảnh* → bấm **"Tạo ảnh nền bằng AI (chọn nguồn)"** trên từng bối cảnh → chọn nguồn trong hộp thoại.
- **Ảnh phác nhân vật** (4 bản nháp, bản ngoại hình mới): hộp thoại chọn nguồn hiện ngay khi bấm tạo; nút "Sinh lại 4 bản khác" dùng lại nguồn bạn đã chọn.
- Nguồn có sẵn: *Theo cấu hình hiện tại* (SD trên máy hoặc Remote GPU), *Cloudflare Workers AI* (cần Account ID + API Token, nhập ở **Cài đặt > API ảnh miễn phí**),
  *Pollinations* (không cần khoá, thử nghiệm — chậm, có thể có watermark). Nguồn chưa nhập đủ thông tin sẽ bị làm mờ kèm lý do.
- **Không dùng được cho panel**: panel cần ControlNet-pose, IP-Adapter, LoRA từng nhân vật — API ảnh miễn phí không có các điều khiển đó.
- **LLM chữ** (parse kịch bản, thoại, bố cục): vẫn ở **Cài đặt > LLM ngoài**; nay tự thử lại khi bị giới hạn tần suất (HTTP 429). Gemini có Base URL kiểu OpenAI
  `https://generativelanguage.googleapis.com/v1beta/openai/` (bậc miễn phí có thể dùng dữ liệu của bạn để cải thiện sản phẩm của Google).
- **Giám khảo ảnh qua API**: **Cài đặt > Kiểm tra ảnh SAU khi sinh** → tích "Giám khảo ảnh qua API" (ảnh panel được gửi đi, thu nhỏ tối đa 768 px).

> Mọi API trên **chưa được gọi thử với dịch vụ thật** khi viết (xem `TECHNICAL_STATUS.md` mục 266): nếu một nhà cung cấp đổi tham số, bạn sẽ thấy thông báo lỗi cụ thể.

---

## 7. Cài đặt quan trọng cần biết (Settings)

### 7.0. Cài đặt có được lưu không? (mục 267)

- **Có.** Mọi công tắc và thanh trượt trong Cài đặt tự được lưu (sau khoảng nửa giây không chỉnh nữa) và còn nguyên khi mở lại app. Trước mục 267 cài đặt chỉ nằm trong bộ nhớ nên đóng app là về mặc định.
- **Khoá API/token thì KHÔNG** được lưu, trừ khi bạn bật **Cài đặt > lưu cài đặt > Nhớ khoá API trên máy này**. Bật thì khoá được ghi (chữ thường, không mã hoá) vào một tệp riêng trong vùng riêng của app và không đi theo sao lưu tự động của Android; tắt công tắc thì tệp đó bị xoá.
- **Khôi phục cài đặt mặc định**: nút cùng thẻ, có hộp thoại xác nhận. Xoá toàn bộ cài đặt và khoá đã lưu; truyện, nhân vật và model không bị đụng.
- Nếu tệp cài đặt bị hỏng, app đổi tên nó thành `settings.json.bad`, dùng cài đặt mặc định và báo bạn một lần. Cài đặt lưu từ bản app cũ vẫn đọc được: trường mới lấy mặc định, giá trị sai kiểu hoặc tràn số bị bỏ qua.
- Chưa thử trên máy thật: việc ghi tệp và việc Android loại thư mục khoá khỏi sao lưu tự động chỉ CI/máy thật xác nhận được.

| Cài đặt | Ý nghĩa | Khi nào chỉnh |
|---|---|---|
| `useStoryDiffusion` | Bật giữ mặt nhân vật nhất quán (IP-Adapter/LoRA + toàn bộ 5 pipeline nhiều-nhân-vật, mục 3.5) | Mặc định BẬT — chỉ tắt nếu muốn tốc độ tối đa và chấp nhận không giữ mặt ai |
| `enableQualityGate` | YOLO tự đếm chi, auto-sinh lại nếu sai (chỉ nhánh 1-nhân-vật) | Bật nếu hay gặp lỗi giải phẫu tay/chân |
| `verifyOutputPose` | **(Mục 248) Kiểm tra ảnh SAU khi sinh**: dò lại tư thế bằng YOLOv8-pose trên ảnh ra rồi so với khung xương đưa vào — thiếu/thừa người, lệch tư thế, tỉ lệ giữa các người. Chỉ CẢNH BÁO thêm lý do vào badge Quality Gate của panel, không tự thử lại. Người bị che/dính nhau (cảnh vật lộn) có thể bị dò thiếu dù ảnh đúng | Tắt mặc định; ngưỡng chưa hiệu chỉnh; chưa build-test |
| `differentialInpaint` | **(Mục 248) Differential Diffusion** cho các lượt vẽ lại CÓ MASK (vùng chạm/mặt/tay): mask mềm trở thành "độ thay đổi" theo từng bước thay vì trọng số trộn cố định → chuyển tiếp mượt hơn ở biên. Mask cứng thì không khác gì cũ | Tắt mặc định; chưa build-test, nên so ảnh bật/tắt cùng seed |
| `occCfgEnabled` / `occCfgBoost` | **(Mục 261) CFG riêng cho vùng chồng/chạm nhau** (bài PersonaCraft, công thức OccCFG): panel từ 2 người mà thân chồng/chạm nhau → CFG ở vùng đó = CFG nền × hệ số (mặc định 1.4), nơi khác giữ nguyên. Vùng được tính từ khung xương 2D. Chỉ áp cho lượt sinh ảnh ĐẦU của panel, không áp cho lượt vá cục bộ | Tắt mặc định; chưa chạy thật. So ảnh bật/tắt cùng seed; nếu vùng chạm cháy màu thì giảm hệ số |
| `contactGradedMask` / `contactMaskFloor` | **(Mục 261) Mask vẽ lại theo cường độ tiếp xúc**: lõi chỗ hai người chạm nhau vẽ lại đầy đủ, vùng rìa chỉ chỉnh chi tiết (mức tối thiểu mặc định 0.45). **Chỉ có tác dụng khi bật cả `differentialInpaint`** | Tắt mặc định; chưa chạy thật |
| `loraCompose` / `loraComposeComposite` / `loraSwitchTau` | **(Mục 261) Trộn LoRA nhân vật lúc sinh ảnh** (bài Multi-LoRA Composition): panel từ 2 nhân vật, MỖI người có LoRA đã convert riêng → nạp mỗi LoRA một UNet, luân phiên (Switch, đổi mỗi τ=5 bước) hoặc lấy trung bình (Composite, chậm gấp số nhân vật) thay vì gộp mọi LoRA vào một UNet. **Chỉ đường sinh ảnh thường** (không IP-Adapter/ControlNet — UNet đó không mang LoRA nhân vật); tốn RAM gấp số nhân vật; không dùng LoRA của text-encoder phụ. Thiếu điều kiện thì tự dùng đường cũ và ghi log | Tắt mặc định; chưa chạy thật trên máy |
| `loraComposeRegional` | **(Mục 261.11) Trộn LoRA THEO VÙNG từng nhân vật**: thay vì trung bình toàn ảnh, mỗi pixel trộn dự đoán nhiễu của các UNet theo mask vùng của từng nhân vật (dựng từ khung xương); nền/vùng không thuộc ai thì trung bình. Chạy đủ mọi UNet mỗi bước (chậm như Composite). Cần khung xương đủ khớp thân của MỌI nhân vật, thiếu thì tự quay về Switch/Composite. Bật thì ẩn công tắc Composite và thanh trượt τ | Tắt mặc định; chưa chạy thật |
| `loraComposeOwnClip` | **(Mục 261.14) Mã hoá prompt bằng CLIP của từng LoRA**: mỗi UNet nhận điều kiện văn bản mã hoá bằng `clip.mnn` của chính nhân vật đó (đã gộp delta text-encoder của LoRA, nếu file LoRA có) thay vì dùng chung CLIP của nhân vật đầu. Chỉ có nghĩa khi bật `loraCompose`; nhân vật thiếu `clip.mnn` tự dùng CLIP chính | **Bật** mặc định (bên trong tính năng vốn tắt, để so A/B); chưa chạy thật |
| `inpaintMatchedNoise` | **(Mục 262) Khớp mức nhiễu khi vẽ lại vùng có mask**: khi trộn mask (mặt/tay/vùng chạm, cả trộn cứng lẫn Differential Diffusion), ảnh gốc được thêm nhiễu ở mức `timesteps[i+1]` — đúng mức của latent sau mỗi bước, theo cách pipeline inpaint hiện hành của diffusers — thay vì `timesteps[i]` như mã cũ; bước cuối dùng ảnh gốc sạch. Ảnh hưởng MỌI lượt vẽ lại có mask | Tắt mặc định; có tài liệu tham chiếu nhưng chưa so ảnh trên máy: so bật/tắt CÙNG seed, tìm viền vùng vẽ lại có hạt hoặc lệch tông |
| `objectDepthBlockout` | **(Mục 260, bổ sung 263) Khối độ sâu cho vật thể**: các hộp vật thể nền (`Scene.objectBoxes`, do LLM gán toạ độ) được vẽ thêm vào bản đồ độ sâu để ControlNet-Depth giữ đúng vị trí và kích thước vật. Mặc định mọi vật nằm SAU nhân vật. **Mục 263**: vật mà văn bản cảnh nói rõ đứng TRƯỚC nhân vật (bàn chắn phía trước...) có thể được LLM đánh dấu `"front": true`; khi đó vật được vẽ sáng hơn người trong hộp để che người (z-buffer). Có chốt: nếu hộp che quá 60% số pixel người của cả ảnh thì không che, hộp rơi về "sau người". Không có thang độ mạnh riêng cho từng vật (độ mạnh ControlNet là toàn cục) | Tắt mặc định; chưa thử trên ảnh thật; LLM nhỏ đánh dấu `front` có đúng không chưa đo |
| `visionCountDetectorFirst` | **(Mục 262) Ưu tiên bộ dò người khi đếm** (chỉ có nghĩa khi đã đặt thư mục model giám khảo VLM): bộ dò YOLOv8-pose đếm KHỚP kịch bản thì bỏ cảnh báo "đếm sai" của VLM (VLM đếm kém hơn nhiều; cảnh báo ấy từng có thể kéo cổng chất lượng sinh lại ảnh oan). Cảnh báo tiếp xúc thân thể của VLM vẫn giữ. Không cứu được ca detector đếm THIẾU (cảnh quần nhau, người che nhau) | **Bật** mặc định (bên trong tính năng VLM vốn tắt); tắt để về hành vi cũ |
| *(không có cờ)* log RAM/thời gian | **(Mục 262)** Khi bật `loraCompose`, log ghi RSS/PSS trước/sau khi nạp từng UNet phụ, sau lượt chạy UNet đầu (số đáng tin nhất — trọng số mmap chỉ vào RAM khi được chạm) và thời gian mã hoá CLIP riêng. Chạy MỘT lần trên máy bất kỳ rồi gửi các dòng `LoRA compose [RAM]` để đo RAM mỗi UNet | PSS có thể hiện `n/a` nếu Android chặn đọc — không phải lỗi |
| `consistencyStrength` (Smooth Timestep Decay) | Ảnh hưởng ảnh neo IP-Adapter giảm dần cuối quá trình sinh | Giảm nếu mặt quá cứng/không theo biểu cảm LLM viết |
| `useUltrafixRedraw` | Vẽ lại nhẹ toàn ảnh sau upscale trước khi auto-fix | Bật nếu ảnh sau upscale bị mờ/nhiễu |
| Multi-Pass Inpainting Cascade | 3-4 lượt sửa mặt/tay giảm dần cường độ | Mặc định bật — tắt nếu muốn nhanh hơn, chấp nhận kém chính xác hơn cảnh đông người |
| `autoFixLimbContacts` + `maxContactFixRegions` | Ngoài hông/tay-đè-thân, dò thêm khuỷu tay, đầu gối, bàn chân, đầu, tay khoá cổ rồi vẽ lại cục bộ từng chỗ (chỉ có tác dụng khi bật auto-fix giao thoa; mục 227) | Mặc định BẬT, tối đa 4 vùng/panel — tăng cho cảnh vật lộn đông người, giảm nếu máy chậm |
| `sdxlFinishPass` + `sdxlFinishDenoise` | Panel vẫn sinh bằng SD1.5, các vùng tiếp xúc được SDXL vẽ lại lần cuối (mục 229). Chỉ ảnh vuông, cần cấu hình model SDXL, nặng RAM | Mặc định TẮT — bật khi cảnh vật lộn bị lỗi giải phẫu vùng chạm mà SD1.5 không sửa nổi |
| Màn hình **Biểu cảm & diễn xuất** (biểu tượng khuôn mặt trên thanh Nhân vật) | Quản lý tập trung: (1) Thư viện — 12 nhãn gốc + 15 biểu cảm dựng sẵn cho cảnh hành động + tự tạo biểu cảm từ thành phần mày/mắt/miệng/chi tiết/hướng nhìn/cường độ; (2) Dàn diễn viên — bảng biểu cảm từng nhân vật làm ảnh tham chiếu; (3) Diễn biến — biểu cảm từng nhân vật theo từng panel (mục 240) | Bảng biểu cảm cần anchor có mặt nhìn rõ và model YOLOv8-pose; xem ảnh và xoá nếu lệch mặt |
| `inpaintColorMatch` | Khớp màu vùng vẽ lại (mặt/vùng chạm) theo ảnh gốc để chống trôi màu da/tóc do img2img; biểu cảm đỏ mặt/tái mặt chỉ khớp nhẹ (mục 241) | Mặc định BẬT |
| Bộ từ vựng biểu cảm theo **Phong cách ảnh** | "Siêu thực" → mô tả giải phẫu cơ mặt; Anime/Manga/Manhwa → tag danbooru đã đối chiếu wiki. Màn hình Biểu cảm hiển thị bộ đang dùng và xem trước cả hai (mục 242) | Câu mô tả ảnh thực chưa được kiểm chứng trên checkpoint nào — thử và chỉnh |
| `expressionVocabulary` (AUTO / ANATOMICAL / BOORU) | Chọn bộ từ vựng biểu cảm; AUTO theo Phong cách ảnh. Dùng nút so sánh trong tab "Dàn diễn viên" để xem checkpoint của bạn hiểu bộ nào tốt hơn (cùng seed) (mục 243) | Checkpoint hiểu tag booru hay không còn tuỳ cách huấn luyện, không chỉ ảnh thực/anime |
| `exportVideoPack` + `videoPackTarget` | ZIP "gói ảnh cho model video": khung đầu sạch (không bóng thoại) cắt/đổi cỡ theo khung đích, khung kết đổi biểu cảm, prompt chuyển động, thoại (mục 244). Tab "Làm video" trong màn hình Biểu cảm để kiểm tra và tạo khung kết | Ứng dụng KHÔNG chạy model video; prompt chưa thử trên model thật |
| `exportVideoSpeech` | **(Mục 248)** Kèm file giọng đọc `pPPP_lLL.wav` (TextToSpeech của máy) cho từng câu thoại trong gói video; độ dài từng câu ghi ở `info.json`. Cần giọng Tiếng Việt cài sẵn trên máy (không có thì bỏ qua, gói vẫn xuất). Các nhân vật chỉ khác cao độ; KHÔNG ghép vào video, KHÔNG đồng bộ khẩu hình | Mặc định tắt; chưa thử trên máy thật |
| `exportVideoRemote` | **(Mục 249)** Tạo `clip.mp4` cho từng panel trên server Remote GPU bằng Stable Video Diffusion (từ `start.png`) và đưa vào gói video. Cần Remote GPU bật và `tools/remote_server/app.py` bản mới (tham số `--svd-model-id`, `--keep-svd`; **tự kiểm tra giấy phép model**). Mỗi clip có thể mất vài phút (thời hạn đọc 15 phút); ảnh được đặt vào khung 1024×576 giữ tỉ lệ (có viền đen nếu khác 16:9); chuyển động do model tự nghĩ. Server cũ (chưa hỗ trợ video) bị phát hiện và dừng thử, gói vẫn xuất | Mặc định tắt; chưa chạy trên server thật |
| `expressionFaceIdentity` + `expressionIdentityScale` | Khi vẽ lại mặt/khung kết/ảnh bảng biểu cảm, dùng ảnh anchor (hoặc ảnh đúng biểu cảm) làm tham chiếu IP-Adapter để không lệch khuôn mặt; cần model SD1.5 augmented đang nạp, không có thì dùng img2img thường (mục 245) | Mặc định BẬT, độ bám 0.6; cao hơn dễ kéo biểu cảm về ảnh tham chiếu |
| `expressionIdentityMinSim` | Cổng danh tính: đo độ giống mặt trước/sau khi vẽ lại bằng ArcFace; dưới ngưỡng thì thử lại 1 lần rồi giữ mặt cũ. 0 = tắt. Cần `arcface_mbf.mnn` trong `yolo/` (thiếu thì tự bỏ qua) (mục 246) | Mặc định 0.4 (hạ từ 0.5 ở mục 247 vì 0.5 dễ loại oan), CHƯA hiệu chỉnh — xem điểm đo trong nhật ký rồi chỉnh. Chỉ phù hợp ảnh siêu thực |
| `autoFixRegionOnlyPrompt` | Ở chế độ vẽ vùng chạm kiểu cắt, chỉ dùng mô tả loại chạm + hai nhân vật liên quan thay vì prompt cả cảnh (mục 238) | Mặc định BẬT |
| `expressionFacePass` + `expressionFaceDenoise` + `maxExpressionFaces` | Sau khi sinh ảnh, vẽ lại riêng vùng mày–mắt–miệng của nhân vật có biểu cảm khác trung tính, cùng seed panel (mục 238) | Mặc định TẮT vì có thể lệch khuôn mặt; thử 1 panel với denoise 0.40–0.45 trước |
| `autoFixCropInpaint` + `autoFixPasteBack` | Vẽ lại vùng chạm ở độ phân giải đầy đủ của model (cắt vùng + lề, phóng lên, vẽ, thu nhỏ, dán lại) và dán pixel gốc ngoài vùng sửa (mục 237). Áp dụng cho mọi loại vùng auto-fix | Mặc định BẬT; lỗi tự quay về cách vẽ cũ. Tắt từng cái để so sánh ảnh cùng seed |
| `useDepthForContacts` | Lọc điểm chạm theo độ sâu thật đọc từ ảnh đã sinh (MiDaS). Cần `midas_small_depth.mnn` trong thư mục `yolo/`; thiếu file thì tự bỏ qua (mục 232) | Mặc định BẬT, vô hại khi chưa có model |
| `exportPageTemplate` + `exportPageProfile` | Bố cục trang PDF (2 dọc / lưới 2×2 / 1 rộng + 2 dưới / 4-koma / 1 panel mỗi trang / **Tự chọn theo cảnh — mục 248**) và khổ trang (A4 / KDP 6×9 / KDP 6×9 có bleed). Mặc định giữ nguyên PDF cũ (mục 233) | KDP: lề trong (gáy) tự theo bảng chính thức của KDP theo số trang PDF — 24–150: 0,375"; 151–300: 0,5"; 301–500: 0,625"; 501–700: 0,75"; 701–828: 0,875" (đã đối chiếu trang KDP, mục 247) |
| `exportPageTemplate` = Tự chọn theo cảnh | **(Mục 248)** Mỗi trang một bố cục theo nhịp truyện: cảnh hành động tiếp xúc (combat/ôm/hôn), cận cực độ hoặc toàn cảnh → trang "1 ô rộng + 2 ô dưới"; chuỗi cảnh có thoại, không hành động → lưới 2×2; còn lại → 2 panel dọc; panel hành động cuối cùng của truyện (≥ 6 panel) → 1 trang toàn khổ. Mọi panel xuất hiện đúng 1 lần, đúng thứ tự. Quy tắc dựa trên dữ liệu cảnh do LLM nhỏ gán nên chỉ là gợi ý bố cục | Chưa xem thử PDF thật; chưa build-test |
| `exportRightToLeft` | Manga đọc phải → trái trong PDF **và CBZ (mục 249: ghi `<Manga>YesAndRightToLeft</Manga>` vào `ComicInfo.xml` ở gốc file CBZ — mọi CBZ nay có `ComicInfo.xml` với tiêu đề, bộ truyện, số chương, số trang)**: lật thứ tự ô trong trang (ô đầu ở bên phải) và đổi phía gáy sách theo quy tắc KDP (trang 1 là trang trái, lề trong bên phải). Không đảo thứ tự trang. **Lưu ý**: KDP chỉ nhận in sách phải → trái cho tiếng Nhật, Hebrew, Yiddish — truyện tiếng Việt tải lên KDP sẽ không chọn được hướng này; dùng cho PDF tự in/đọc (mục 247) | Mặc định TẮT; chưa build-test |
| `remoteEndpoint.pagScale` | **(Mục 248) PAG (Perturbed-Attention Guidance)** trên server từ xa (diffusers): 0 = tắt; thử 3.0. Giúp cấu trúc/giải phẫu ổn định hơn nhưng thêm một nhánh tính toán mỗi bước. Không chạy được on-device (cần nhánh attention bị phá nhiễu mà MNN không có). Server không dựng được PAG hoặc lỗi cùng IP-Adapter → tự chạy lại KHÔNG PAG | Tắt mặc định; chưa chạy trên Colab thật |
| `remoteFaceSwap` | **(Mục 250) Hoán đổi mặt theo nhân vật trên server** (insightface `buffalo_l` + `inswapper_128`): ở bước Phóng to/Hậu kỳ, app tính hộp đầu từng người từ khung xương, server ghép với mặt dò được rồi dán danh tính từ ảnh neo. Cần Remote GPU bật, `app.py` bản mới và `--inswapper-path` (tự tải `inswapper_128.onnx`). **⚠ GIẤY PHÉP PHI THƯƠNG MẠI**: dùng cho dự án cá nhân thì được, không dùng kết quả cho sản phẩm thương mại khi chưa kiểm tra điều khoản. Chỉ dùng cho nhân vật hư cấu của bạn. **(Mục 251) Có bảo vệ biểu cảm/tỉ lệ**: server đo biểu cảm (mắt/miệng/lông mày) trước–sau bằng landmark; lệch thì khôi phục miệng/mắt gốc, vẫn lệch thì HOÀN NGUYÊN mặt đó; mặt quay > 55° bị bỏ qua; kích thước/vị trí mặt không được đổi; cảnh báo nếu tỉ lệ mặt/vai bất thường (đầu to/nhỏ so với thân). Kết quả hiện ở log và lý do của badge (hoàn nguyên → panel cần xem lại). Ngưỡng chưa hiệu chỉnh. Mặt nhỏ/bị che có thể không dò được (bỏ qua) | Mặc định tắt; chưa chạy với server thật |
| `remoteHandFix` | **(Mục 250) Sửa tay (HandRefiner) trên server**: MeshGraphormer tìm tay → vẽ lại vùng tay bằng SD1.5 + ControlNet depth-hand (`hr16/ControlNet-HandRefiner-pruned`, Apache-2.0), dán lại có làm mờ biên; không thấy tay thì giữ nguyên ảnh. Cần model nền SD1.5 trên server. Tay quá to/biến dạng nặng vẫn có thể hỏng | Mặc định tắt; chưa chạy với server thật |
| `remoteKontext` | **(Mục 250) Chỉnh danh tính bằng FLUX Kontext trên server (thử nghiệm)**: ghép ảnh cảnh + ảnh neo, yêu cầu giữ mặt/danh tính như ảnh neo; CHỈ panel có đúng 1 nhân vật có ảnh neo. **⚠ GIẤY PHÉP PHI THƯƠNG MẠI** (FLUX.1 Kontext [dev], cần chấp nhận điều khoản trên Hugging Face). Mô hình 12 tỷ tham số nạp 4-bit; rất nặng và chậm trên GPU nhỏ; chất lượng giữ danh tính theo kiểu ghép ảnh chưa được kiểm chứng | Mặc định tắt; chưa chạy với server thật |
| `remoteInteractLayout` | **(Mục 251) Bố cục tương tác (InteractDiffusion, thử nghiệm)** — chạy ở bước SINH ẢNH, panel đúng 2 nhân vật có hành động ôm/hôn/đánh: server dựng ảnh bố cục, app trích khung xương hai người (YOLOv8-pose) rồi vẽ ảnh cuối bằng checkpoint/LoRA/IP-Adapter của bạn (ảnh bố cục bị bỏ). Server nạp model bằng `trust_remote_code` (chạy mã tải về — nên ghim `--interact-revision`); giấy phép BSD theo trang Hugging Face. YOLO có thể không dò đủ 2 người khi ôm sát (khi đó dùng khung xương mẫu); khung xương dò được không có z và bỏ qua tỉ lệ cơ thể từng nhân vật; sinh lại 1 panel dùng layout đã lưu nhưng không tạo mới | Mặc định tắt; chưa chạy với server thật |
| `exportWebtoonZip` / `exportMetadataJson` | ZIP dải dọc Webtoon (rộng 800px, mỗi ảnh cao tối đa 1280px, ≤2MB) / file JSON metadata (mục 233) | Mặc định TẮT |
| `exportKenBurnsVideo` + `exportVideoSeconds` | Video MP4 zoom/trượt từng panel, không có tiếng (mục 234) | THỬ NGHIỆM, mặc định TẮT; chưa chạy trên máy thật |
| `checkObjectScale` | Ghi log khi tỉ lệ vật thể/người lệch hơn 20% giữa các panel cùng cảnh; chỉ có tác dụng với panel có khai hộp vật thể (mục 235) | Mặc định BẬT |
| `industrialBatchUpscaleMode` | 4 giai đoạn tuần tự, giải phóng RAM giữa mỗi giai đoạn | Bật cho máy 6-8GB RAM |
| `slidingWindowSize`/kế thừa seed | Panel gần nhau dùng chung ngữ cảnh sinh ảnh (thuật toán A-B-A) | Tăng nếu muốn phong cách nhất quán hơn giữa các panel liên tiếp |
| `nThreadsAutoDetect` | Tự dò số luồng CPU tối ưu theo chip | Tắt + tự chỉnh tay nếu máy có hành vi lạ với auto-detect |
| `enable_qnn`/NPU | Chạy UNet trên NPU thay CPU/GPU (nhanh hơn nhiều nếu có) | Chỉ có tác dụng nếu tự build bản QNN — xem `HUONG_DAN_NPU_QNN.md` |
| Kích thước ảnh gốc (chip 384/512/640/768, hoặc nút ★ riêng) | Tỷ lệ khung ảnh sinh ra | **(Mới, mục 161 đợt 5-7)** Nút ★ khác vuông (VD 768x512) CHỈ hiện nếu checkpoint đang chọn có khai `default_width≠default_height` trong `model_manifest.json` — nghĩa là PHẢI tự convert model theo đúng profile đó trước (xem `prepare_models.yml`), KHÔNG phải chọn xong là có ảnh khổ ngang ngay với model SD1.5 vuông mặc định. **CHƯA build-test** — đây là thay đổi native mới, cần build CI thật xác nhận trước khi tin cậy dùng thật (xem `TECHNICAL_STATUS.md` mục 161 đợt 7). |

---

## 8. Xử lý sự cố thường gặp

- **"Chưa chọn SD Model"/"Chưa chọn LLM Model"** — vào Settings kiểm tra
  `modelStatus()`, model chưa import hoặc chưa được `rescanModels()`
  nhận diện đúng.
- **Huỷ sinh ảnh mà lâu không phản hồi** — `cancelSafely()` đợi tối đa
  30 giây trước khi báo "có thể đang treo ở tầng native" — đây là giới
  hạn thật đã biết (không ép giải phóng bộ nhớ giữa chừng để tránh crash
  nguy hiểm hơn), xem `TECHNICAL_STATUS.md` mục 10.
- **2 nhân vật trong 1 panel bị lẫn mặt nhau** — app đã tự chọn 1 trong
  5 pipeline nhiều-nhân-vật nếu model tương ứng có sẵn (mục 3.5) hoặc
  convert LoRA ghép cặp (mục 3); nếu KHÔNG có model nào trong 5 loại đó,
  đây là hành vi mặc định đã biết (chỉ 1 người được giữ mặt/panel).
- **Panel bị dừng giữa batch dài** — mở lại đúng truyện, dán lại đúng
  văn bản gốc, app tự hỏi resume (mục 5 ở trên).
- **App bị Android tự tắt khi chạy nền lâu** — Chế độ Công nghiệp chạy
  Foreground Service + WakeLock, nhưng vẫn có thể bị hệ điều hành can
  thiệp trên 1 số dòng máy/bản Android — mở lại app, dùng checkpoint để
  tiếp tục thay vì lo mất tiến độ.

---

## 9. Về tính chính xác của tài liệu này

Viết bằng cách đọc trực tiếp `MainActivity.kt` (route thật),
`MainViewModel.kt` (tên hàm/tham số thật), và các file `ui/*.kt` tương
ứng — không suy đoán tên hàm/luồng. Tuy nhiên (nhắc lại mục 0 của
`TECHNICAL_STATUS.md`): **toàn bộ hành vi mô tả ở đây là hành vi THIẾT KẾ
theo code, chưa có xác nhận chạy đúng trên thiết bị thật** — một số chi
tiết (thời gian chờ thực tế, thông báo lỗi chính xác, độ mượt UI) có thể
khác khi build-test thật lần đầu.

**Cập nhật gần nhất (TECHNICAL_STATUS.md mục 161, đợt 1-12)**: đối chiếu
lại tài liệu với toàn bộ thay đổi lớn của đợt audit PDF ngoài (mục
146/161) — đã cập nhật: mục 2 (tải model tự động, tuỳ chọn), Bước 2
(phiên bản ngoại hình nhân vật theo chương), Bước 8 (dọn dẹp file trung
gian sau xuất bản), mục 5 (cách ly lỗi native cho bước sinh ảnh — CHƯA
build-test), mục 7 (chọn tỷ lệ khung ảnh không vuông — CHƯA build-test).
**Build CI (`build.yml`) đã pass lần đầu tiên với TOÀN BỘ 12 đợt thay đổi
này** (biên dịch sạch — Kotlin + native C++ + Python export scripts) —
nhưng đây CHỈ xác nhận cú pháp/kiểu dữ liệu đúng, KHÔNG xác nhận hành vi
lúc chạy thật (ảnh tỷ lệ không vuông có đúng không, cơ chế đa tiến trình
có hoạt động đúng không) — vẫn cần cài APK lên máy thật kiểm tra trước
khi tin cậy các mục đánh dấu "CHƯA build-test" ở trên.

Các bước KHÔNG đổi (Bước 1, 3-7 phần lõi, mục 3-4, 6, 8) vẫn khớp
nguyên trạng so với lần rà soát trước, không cần sửa gì thêm.

**Cập nhật tiếp theo (TECHNICAL_STATUS.md mục 175-176, đợt 21-22)**: mục
3.5 hoàn toàn MỚI (5 pipeline nhiều-nhân-vật mask/regional/regional-mask/
triple-combo + biến thể depth — trước đây CHƯA từng được viết vào tài
liệu này dù code đã có từ lâu, xem mục 176 để rõ vì sao gap này lọt qua
lần rà soát trước). Sửa lại câu SDXL ở mục 2 và mục 6 (thêm phân biệt rõ
SDXL chạy Local — chỉ cơ bản — với SDXL qua GPU thuê ngoài — có ControlNet
+ IP-Adapter nhưng không LoRA/không multi-character). Thêm dòng
`useStoryDiffusion` vào bảng mục 7. Mục Help rút gọn trong app
(`HelpScreen.kt`) cũng đã cập nhật tương ứng.

**Cập nhật tiếp theo (TECHNICAL_STATUS.md mục 177-183, đợt audit độc lập
mới)**: từ mục 177-181, SDXL đã được viết thêm 5 pipeline augmented/mask/
regional/regional-mask/depth ở TẦNG CODE (Phase 2). Mục 183: đợt audit
toàn diện, không tìm thêm lệch pha nào khác trong phạm vi đã rà (xem chi
tiết trong `TECHNICAL_STATUS.md`).

**Cập nhật tiếp theo nữa (mục 184)**: Phase 3 (dispatch thật + UI) NAY ĐÃ
NỐI — trước đó câu ở mục 2 nói "với người dùng, hành vi SDXL Local vẫn y
hệt trước đó (chỉ sinh ảnh cơ bản)" vì Phase 3 chưa làm; giờ KHÔNG còn
đúng — SDXL đã bật được thật qua Cài đặt (thẻ "SDXL (thử nghiệm)"). Đã
sửa lại câu ở mục 2 cho khớp. TOÀN BỘ đường SDXL (Phase 2 lẫn Phase 3)
vẫn CHƯA build-test lần nào — mức rủi ro khi bật thử cao hơn hẳn SD1.5.

**Cập nhật tiếp theo nữa (mục 185-202, cộng dồn nhiều đợt, đóng ở mục
203)**: tài liệu này từng dừng lại ở mục 184 suốt 18 mục sau đó — 1 đợt
audit độc lập mới (mục 203) phát hiện gap này rồi vá lại. Đã bổ sung vào
Bước 6 ở trên: badge cảnh báo Quality Gate + phương án SDXL thay thế khi
sinh hàng loạt (mục 185), ô chọn model tier riêng theo panel (mục 188),
ô sửa tay biểu cảm riêng từng nhân vật panel đông người (mục 196/197).
Đã bổ sung vào mục 2: cơ chế tự phát hiện marker độ phân giải SDXL thật
(mục 192/193) + cảnh báo về việc giữ `prepare_models.yml` lệch bản (mục
203 tìm thấy đúng lỗi này đang xảy ra thật ở lần upload đó). Các mục còn
lại trong khoảng 185-202 (thiết kế lại thứ tự Quality Gate — mục 187, 2
bug `regeneratePanel()` bỏ sót Cascade/auto-fix — mục 198/199, mask bao
lồi thay hình chữ nhật — mục 201/202) là thay đổi nội bộ không đổi luồng
thao tác của người dùng, không cần thêm mục riêng ở tài liệu này — xem
`TECHNICAL_STATUS.md` nếu cần chi tiết kỹ thuật.

**Cập nhật tiếp theo nữa (mục 204)**: ô chọn thư mục model SDXL ở mục 2
giờ có dropdown quét sẵn (trước đó chỉ gõ tay) — đã sửa câu mục 2 cho
khớp, chi tiết kỹ thuật xem `TECHNICAL_STATUS.md` mục 204. Đúng như mọi
thay đổi khác, phần này CHƯA build-test (sandbox không có
javac/kotlinc/gradle để compile-check thật) — chỉ tự rà bằng cách đếm
ngoặc + đọc lại tay, không thay được build thật.

**Cập nhật tiếp theo nữa (mục 205-207)**: SDXL giờ có Quality Gate (mục
205) VÀ auto-fix giao thoa (mục 207) — đã sửa câu mục 2 cho khớp. Mục
207 là thay đổi C++ thật (không chỉ Kotlin/text như các mục trước) —
CHƯA build-test, rủi ro cao hơn hẳn: sai sót có thể sinh ảnh sai mà
không crash, chỉ lộ ra khi tự xem ảnh thật. Multi-Pass Cascade riêng cho
SDXL (tính năng SÂU HƠN auto-fix giao thoa) vẫn chưa làm — chi tiết kỹ
thuật đầy đủ xem `TECHNICAL_STATUS.md` mục 205/207.

**Cập nhật tiếp theo nữa (mục 213/214 — SAU BUILD THÀNH CÔNG LẦN ĐẦU)**:
- **Sao lưu/khôi phục truyện (mục 213, mới)**: màn danh sách truyện có
  nút "Khôi phục từ file" (toolbar + màn trống) để nhập lại 1 truyện đã
  sao lưu — dùng khi cài lại app/đổi máy. Ở màn chi tiết 1 truyện, menu
  3 chấm có "Sao lưu truyện" (xuất ra 1 file `.zip` qua hộp thoại chia
  sẻ — chọn lưu Drive/Files tuỳ ý) và "Xoá truyện" (có xác nhận). Lưu ý:
  khôi phục 1 truyện TRÙNG với truyện đã có trên máy sẽ bị từ chối (an
  toàn, tránh ghi đè nhầm) — xoá truyện cũ trước nếu muốn khôi phục đè.
- **Mục "🦴 Pose" trong Cài đặt giờ bấm được** (mục 214) — bấm vào dòng
  đó (trong khối "stack kỹ thuật") mở thẳng màn vẽ/sửa/trích tư thế,
  tương đương nút "Vẽ / sửa khung xương tư thế" đã có. 9 dòng còn lại
  trong khối đó (LLM/SD 1.5/StoryDiffusion/Auto-fix/Mask thủ công/
  Upscale/Auto Bubble/Thermal/Export) vẫn CHỈ là mô tả kỹ thuật, không
  bấm được — không có màn riêng nào để trỏ tới.
- Cả 2 đều CHƯA build-test — chi tiết kỹ thuật đầy đủ xem
  `TECHNICAL_STATUS.md` mục 213/214.

**Cập nhật mục 275 (sau khi người dùng chụp màn hình thật)**:
- **Màn "Vẽ / sửa khung xương" giờ CUỘN được.** Trước đây các thẻ xếp chồng quá chiều cao màn hình, bị cắt và đè lên nhau; nút "Thêm người", ô nhãn và nút Lưu nằm ngoài màn hình nên có cảm giác "chỉ sửa được 1 người". Kéo ở vùng ngoài khung vẽ (hoặc chạm ngoài các khớp) để cuộn; chạm trúng khớp rồi kéo để sửa; hai ngón để phóng to.
- **Nhiều người**: "Thêm người" / "Người N" / "Xoá người N" giờ là nút có chữ.
- **Nhập tư thế từ ảnh / video / OpenPose**: có nút mở rõ ràng ("▸ Nhập tư thế từ ảnh / video / OpenPose"). Khi thiếu `yolov8_pose.mnn` (MangaLocal/yolo/), màn hình hiện cách tạo (workflow "Prepare models" → tải file → chép vào máy), nút chọn ảnh/video bị mờ và có nút "Kiểm tra lại model" (không phải thoát app). Chưa có model vẫn nhập được JSON OpenPose BODY_18 hoặc tự vẽ.
- **Lối tắt có chữ** (đầu màn Nhân vật và màn chi tiết truyện): "🏞 Bối cảnh", "🧍 Tư thế", "😀 Biểu cảm", "👪 Gia đình" — trước đây chỉ là icon trần trên thanh trên (hoặc chỉ mở được từ màn khác) nên không tìm thấy phần nhập bối cảnh.
- **API ảnh miễn phí → nút "Thử gọi"** (Cài đặt): gọi THẬT một ảnh 256×256 bằng khoá đang nhập, kết quả xanh/đỏ ngay dưới nút. Khi hết hạn mức ngày, màn đang tạo hiện một biểu ngữ cam (gộp mọi cảnh báo cùng loại).
- Các thay đổi này CHƯA build-test; chi tiết kỹ thuật đầy đủ xem `TECHNICAL_STATUS.md` mục 275.

**Cập nhật mục 276**: Trợ giúp trong app có thêm mục 11 (Bố cục trang PDF), 12 (Hoán đổi mặt), 13 (GLIGEN). API Cloudflare FLUX nay gửi `seed` nên khi bị timeout và tự thử lại sẽ ra đúng ảnh cũ (không tốn hạn mức hai lần); nếu "Thử gọi" báo lỗi liên quan `seed`, xem TECHNICAL_STATUS.md mục 276.2.

**Cập nhật mục 277 (sau ảnh chụp màn hình thứ hai)**:
- **Màn Nhân vật không còn trống**: nếu chưa chọn truyện, màn hiện danh sách truyện để chọn ngay (nhân vật thuộc từng truyện), có thanh điều hướng dưới. Khi đã có truyện: nút **"＋ Thêm nhân vật mới"** ở đầu danh sách, form mở ngay dưới nút (trước đây form mở ở CUỐI danh sách nên bấm "+" tưởng không có gì xảy ra).
- **Tỷ lệ cơ thể theo tuổi** (màn Vẽ / sửa khung xương, thẻ nằm NGAY DƯỚI khung vẽ): Từ / Sang không còn là chip "câm" — hiện dòng xem trước hệ số (đầu/thân/tay/chân/vai), đổi **cả cơ thể** chứ không chỉ chân, báo kết quả bằng chữ và có Hoàn tác. Giữ nguyên chiều cao tổng và vị trí hông; chỉ đổi tỷ lệ. Là tỷ lệ xấp xỉ (căn cứ ở TECHNICAL_STATUS.md mục 277).

**Cập nhật mục 278 (tỷ lệ cơ thể theo tuổi, TỪNG ĐOẠN chi)**:
- **Màn Vẽ / sửa khung xương**, thẻ "Tỷ lệ cơ thể theo tuổi": bảng ngay trên nút Áp dụng liệt kê 7 đoạn (đầu, thân, vai/hông, cánh tay trên, cẳng tay, đùi, cẳng chân) với % chiều cao ở hai nhóm tuổi và hệ số. Mỗi đoạn có hệ số RIÊNG (trước đây tay gộp một hệ số, chân gộp một hệ số). Trẻ em ≈ 8 tuổi, Thiếu niên ≈ 14, Người lớn = 18+.
- **Đừng mong thay đổi lớn**: khi giữ nguyên chiều cao tổng, trẻ ≈ 8 tuổi khác người lớn chủ yếu ở ĐẦU (to hơn ~19% so với thân), cánh tay trên ngắn hơn ~8%, thân ngắn hơn ~5%; đùi và cẳng chân chỉ ngắn hơn ~3% (số đo thật). Cái làm trẻ trông NHỎ là chiều cao thấp hơn — việc đó nằm ở tỷ lệ xương của nhân vật (dưới đây), không nằm ở nút này.
- **Màn Nhân vật → mở nhân vật → "Tỷ lệ xương"**: hàng chip mới "Theo tuổi: 6 · 8 · 10 · 12 · 14 · 16 · 18+" điền sẵn cả 6 thanh trượt (thân, cánh tay trên, cẳng tay, đùi, cẳng chân, đầu) theo số đo thật. Số là độ dài tuyệt đối so với người lớn (1,00), nên trẻ 8 tuổi ra khoảng 0,70–0,74 ở các đoạn chi và thân 0,72, đầu 0,91. Ba preset Trẻ em / Thiếu niên / Người lớn vẫn còn, nay lấy từ cùng bảng (Trẻ em = 8 tuổi, Thiếu niên = 14). **Nhân vật đã lưu giữ nguyên số cũ** — muốn dùng số mới thì bấm lại chip.
- **Nguồn và giới hạn**: tay, chân, thân lấy từ Schmid và cs. 2019 (J Biomech, tuổi 6–18, trung bình nam-nữ). ĐẦU và VAI là ước lượng. Dưới 6 tuổi không có số liệu (app kẹp về 6 tuổi). Chi tiết: TECHNICAL_STATUS.md mục 278.

**Cập nhật mục 279 (vị trí & góc nhìn; sửa nốt các màn trống)**:
- **Màn Vẽ / sửa khung xương, thẻ mới "Vị trí & góc nhìn"** (dưới khung vẽ, trên thẻ tỷ lệ theo tuổi): trước đây chỉ kéo được từng khớp. Nay có: **kéo cả người** (bật chip "Kéo cả người trên khung vẽ"), nút dời / về giữa / thu phóng / xoay phẳng / **lật trái-phải** (đổi cả nhãn tay trái-phải), chọn áp dụng cho **một người hoặc cả nhóm**, và **hoàn tác** tối đa 30 bước.
- **Xoay camera 3D (±90° ngang, ±45° dọc)**: hai thanh trượt xoay camera quanh hông. **Khung xương vẫn là 2D.** **MẶC ĐỊNH (chế độ an toàn)** chỉ xoay THÂN và ĐẦU bằng độ sâu đáng tin (vai hẹp khi nhìn ngang, mũi lệch); tay và chân xoay như người phẳng — chế độ này không bao giờ tệ hơn xoay phẳng trong các phép đo. Chip **"Đoán độ sâu tay/chân (thử nghiệm)"** đoán thêm độ sâu từ độ co ngắn của tay chân (phương pháp Taylor 2000), nhưng một ảnh 2D không cho biết tay/chân ra TRƯỚC hay SAU camera nên app chọn mặc định (tay và đùi ra trước, cẳng chân ra sau); chi nào ra sai chiều thì bật chip lật. Đo với nhiễu cỡ người gán nhãn COCO: đoán đúng dấu + tay chân co mạnh thì giảm lệch ~25–40% so với xoay phẳng; nhưng đứng thẳng thì tệ hơn phẳng tới ~55%, đoán sai dấu thì tệ hơn 10–40% — nên chỉ bật khi tay/chân vươn rõ về phía camera.
- **Chốt góc**: mặc định BỎ z đoán (z = 0) để lọc điểm chạm và ảnh độ sâu vẫn như trước; bật chip "Giữ z đoán khi chốt" nếu muốn dùng (có thể sai). Khung xương có z thật từ trước (do bạn chỉnh) thì luôn giữ.
- **Bốn màn trước đây trống trơn khi chưa có truyện/chương** (Gia đình, Bối cảnh, Bố cục trang, Hậu kỳ) nay hiện "Chưa mở truyện/chương nào" kèm nút Quay lại và Về danh sách truyện.
- Căn cứ, giới hạn và việc CHƯA kiểm: TECHNICAL_STATUS.md mục 279.

**Cập nhật mục 280 (độ sâu 3D THẬT bằng BlazePose; trả lời "đổi tên zip có build được không")**:
- **Cái gì mới**: khi trích tư thế từ ẢNH, nếu có model BlazePose thì mỗi người được thêm độ sâu `z` THẬT (toạ độ 3D theo mét của Google MediaPipe BlazePose GHUM 3D, giấy phép Apache-2.0), thay cho đoán độ sâu. Thanh trượt xoay camera ở thẻ "Vị trí & góc nhìn" tự dùng z có sẵn. Chưa có model thì mọi thứ chạy như bản 279 (chế độ an toàn).
- **Cách có model (mục 281: KHÔNG cần chép tay nữa)**: hai model `blazepose_lite.mnn` (2,8 MB) và `blazepose_full.mnn` (6,4 MB) được ĐÓNG SẴN trong APK (thư mục `app/src/main/assets/blazepose/`). Lần đầu mở màn Vẽ/sửa khung xương, app tự chép chúng ra `MangaLocal/yolo/` (cùng chỗ `yolov8_pose.mnn`) nếu thư mục chưa có model BlazePose nào; có sẵn rồi (bạn tự đặt) thì không làm gì, không ghi đè. Có cả hai thì app dùng full (chính xác hơn, chậm hơn); muốn dùng lite thì xoá `blazepose_full.mnn` khỏi thư mục đó. APK nặng thêm ~9,3 MB. Muốn thay model bằng bản mới: xoá hai tệp trong `MangaLocal/yolo/` rồi mở lại màn đó. Chỉ khi thấy dòng "chép chưa được" ở thẻ trích tư thế mới cần chép tay.
- **Đổi tên file zip có build được không**: **Được, tên zip không liên quan.** `build.yml` tìm BẤT KỲ `*.zip` trong repo, giải nén, tìm `settings.gradle` (sâu tối đa 3 cấp), chép vào workspace. Ba điều cần nhớ: (1) lấy file zip ĐẦU TIÊN tìm được (`find | head -n 1`, thứ tự không đảm bảo) — repo chỉ để MỘT zip, xoá zip cũ (không thì có thể build nhầm bản cũ); (2) bước chép dùng `rsync --exclude='.github'` nên **các file workflow nằm trong zip KHÔNG được áp dụng** — `export_blazepose.yml` phải tự đưa vào `.github/workflows/` của repo (bản này giao kèm riêng); (3) `export_gligen.yml`, `prepare_models.yml` không có bước giải nén, chạy thẳng `python tools/...` sau `checkout`, nên chúng chỉ chạy được nếu thư mục `tools/` nằm sẵn trong repo; `export_blazepose.yml` thì tự giải nén zip nếu thiếu `tools/`.
- **Căn cứ, số đo thật và việc CHƯA kiểm** (chưa build Android/NDK, chưa chạy trên máy, chưa đo độ chính xác so với 3D thật): TECHNICAL_STATUS.md mục 280.

**Cập nhật mục 281 (model 3D đóng trong APK, tự chép)**: không còn bước "chép `.mnn` lên điện thoại". Chỉ cần đưa zip vào repo và build; cài APK, mở màn Vẽ/sửa khung xương lần đầu là có model 3D. Các tệp `blazepose_*.mnn` rời và workflow `export_blazepose.yml` không còn cần thiết để dùng (workflow chỉ để tự tạo lại model nếu muốn).

**Cập nhật mục 282 (kiểm bản cuối bằng công cụ thật; sửa độ sâu 3D cho ảnh KHÔNG vuông)**:
- **Ảnh không vuông**: trước đây độ sâu `z` lấy từ ảnh dọc/ngang bị lệch tỷ lệ so với x, y (ảnh 810×1080 lệch khoảng 25%: tay vươn ra trước bị đánh giá nông hơn thật). Nay `z` cùng đơn vị với x nên xoay góc nhìn trái/phải đúng tỷ lệ. Ảnh vuông không đổi. **Khung xương đã lưu từ trước vẫn như cũ (z = 0 hoặc z cũ) — muốn z mới, hãy trích lại từ ảnh.** Giới hạn: khung vẽ ở màn Tư thế vẫn vuông nên xoay lên/xuống với ảnh rất dọc/ngang còn lệch nhẹ.
- **Tệp tải lên cần chú ý**: nếu bạn tự giữ riêng `CMakeLists.txt`, `build.yml`, `TECHNICAL_STATUS.md`, `HUONG_DAN_SU_DUNG.md`, hãy dùng bản đi kèm lượt này. Bản `CMakeLists.txt` cũ thiếu dòng `blazepose_wrapper.cpp` nên sẽ làm mất độ sâu 3D thật.
- **build.yml**: bước chép `stb_image_resize2.h` nay chịu được việc thư viện stb đã dời tệp này sang thư mục `deprecated/`. Lần build đầu sau khi đổi sẽ chậm hơn một chút (cache thư viện bên thứ ba được tạo lại).
- Căn cứ, số đo thật và việc CHƯA kiểm (CI mới, máy thật): TECHNICAL_STATUS.md mục 282.

**Cập nhật mục 283 (làm tiếp việc chưa xong bằng cách khác; chạy thật đường LoRA dạng module)**:
- **Tag "heads tall" của nhân vật** (màn Tỷ lệ cơ thể): số đầu nay tính cả kích thước đầu nên khớp bảng theo tuổi (trẻ 8 tuổi ≈ 6 đầu thay vì ≈ 5,5; trước đây thiếu khoảng 1 đầu). Nhóm theo tuổi giữ nguyên (6–8 tuổi "child", 9–13 "youthful", từ 14 không thêm tag); nhân vật tuỳ chỉnh đầu to nay được nhận ra là dạng chibi. Chỉ chữ trong prompt đổi; chưa đo chất lượng ảnh trên máy thật.
- **Tạo module LoRA trên máy tính (tính năng thử nghiệm, mặc định TẮT)**: dùng `lora_attach_branch ... --strip-all-conv-weights` (thay cho `--strip-base-weights`). Module chỉ còn vài trăm KB đến vài MB thay vì hàng chục–trăm MB, đúng cho cả UNet fp32, fp16 và w8, và **không làm đổi kết quả** (đã so với tệp đầy đủ: sai lệch 0). Module phải nạp cùng đúng UNet nền đã dùng để tạo ra nó; nạp module trực tiếp không kèm nền có thể làm MNN sập với UNet w8/fp16. Ứng dụng chưa có nút nối tính năng này; xem TECHNICAL_STATUS.md mục 283.8.
- **Muốn kiểm tra bản dựng thật (Compose, NDK) ngoài CI**: cần cho phép trong cài đặt mạng của môi trường kiểm các tên miền `dl.google.com`, `maven.google.com`, `repo.maven.apache.org`, `repo1.maven.org`, `plugins.gradle.org`, `services.gradle.org`, `downloads.gradle.org` (chi tiết ở mục 283.2).

**Cập nhật mục 284 (giải phẫu theo tuổi: bề ngang vai/hông bằng số đo thật)**:
- **Màn Nhân vật → Tỷ lệ cơ thể** có thêm thanh trượt **"Bề ngang vai / hông"** (0,5–1,3; mặc định 1,0). Chip tuổi nay điền cả hệ số này từ SỐ ĐO THẬT (CDC NHANES III và nghiên cứu 5.260 trẻ Croatia): trẻ 6 tuổi ≈ 0,69, 8 tuổi ≈ 0,75, 12 tuổi ≈ 0,88, từ 18 tuổi là 1,0. Trước đây trẻ em có tay chân ngắn nhưng vai và hông rộng như người lớn.
- **Nhân vật đã chọn chip tuổi từ trước** giữ bề ngang 1,0 (chip không sáng): bấm lại chip tuổi để lấy bề ngang mới. Nhân vật người lớn không bị đổi.
- Nút "đổi tuổi" ở màn Tư thế cũng dùng số đo thật: trẻ nhỏ nay rộng vai hơn khoảng 8–11% so với trước (6 tuổi), 6% (10 tuổi).
- Chưa làm: tách dáng vai/hông theo giới (số đo cho thấy khác biệt chỉ rõ từ ~14 tuổi), trẻ dưới 6 tuổi và người trên 18 tuổi (thiếu số đo đoạn thân/chi). OpenCL/NPU chưa kiểm được; chi tiết ở TECHNICAL_STATUS.md mục 284.

**Cập nhật mục 285 (giải phẫu theo giới nam/nữ; bề ngang hông tách riêng khỏi vai)**:
- **Màn Nhân vật → Tỷ lệ cơ thể** có hàng chip mới **"Giới (số đo nam / nữ)": Không rõ / Nam / Nữ**. Chọn giới rồi bấm chip tuổi (6–18) hoặc Trẻ em / Thiếu niên / Người lớn: các thanh trượt được điền theo số đo thật của riêng nam hoặc riêng nữ thay vì trung bình. **Mặc định là "Không rõ" = trung bình nam–nữ, kết quả giữ nguyên từng chữ số như trước** — nhân vật cũ không bị đổi gì.
- **Đổi giới khi số đo đang khớp đúng một tuổi** (bạn chưa chỉnh tay thanh nào) thì app áp lại đúng tuổi đó theo giới mới. **Nếu bạn đã chỉnh tay dù chỉ một thanh, app giữ nguyên số của bạn** — bấm lại chip tuổi nếu muốn lấy số mới.
- **Thanh "Bề ngang vai / hông" tách thành hai thanh: "Bề ngang vai" và "Bề ngang hông".** Lý do: khi tách nam/nữ thì vai và hông không còn lớn song song — từ 14 tuổi vai nam rộng hơn vai nữ rõ rệt (khoảng 12% lúc 18 tuổi), còn hông nữ rộng hơn hông nam ở 10–14 tuổi. Nếu bạn chưa chỉnh thanh hông, hông vẫn theo thanh vai như trước.
- Người lớn: nữ thấp hơn mốc trung bình khoảng 4%, nam cao hơn khoảng 4% (163,4 và 175,5 cm so với trung bình ≈169,5 cm). **Số đầu và nhóm mô tả tỷ lệ trong prompt (trẻ em / thiếu niên / không) không đổi theo giới ở bất kỳ tuổi nào** — chỉ theo tuổi.
- Giới ở đây **chỉ chọn số đo cơ thể**; app không tự thêm chữ nam hay nữ vào prompt. Hãy viết giới trong mô tả nhân vật như trước. Nút "đổi tuổi" ở màn Tư thế vẫn dùng số trung bình (không biết giới).
- **Sửa lỗi dữ liệu cũ**: danh sách nhân vật lưu bởi phiên bản cũ nay được nạp với giá trị mặc định cho các trường mới (trước đó trường thiếu có thể thành rỗng/0 vì `Character` không có hàm tạo mặc định).
- Chưa làm: trẻ dưới 6 tuổi và người trên 18 tuổi (chưa có đủ số đo đoạn thân/tay/chân theo tuổi từ một nguồn thống nhất; app vẫn kẹp về 6 hoặc 18 tuổi). Chưa đo trên ảnh sinh ra. Chi tiết: TECHNICAL_STATUS.md mục 285.

**Cập nhật mục 286 (sửa lỗi nền; không có nút hay màn hình mới)**:
- **Thanh tiến trình khi sinh ảnh (sửa lỗi native, 14 chỗ):** cách app báo tiến trình từ tầng native lên giao diện bị sai theo mã nguồn Android (ART) — luồng đang chạy hàm JNI bị "tách khỏi JVM" ở mỗi step, điều mà ART cấm bằng cách dừng tiến trình, và còn rò một tham chiếu mỗi step. Nay dùng hàm chung an toàn `jni_progress.hpp`. Nếu trước đây app đóng đột ngột ngay khi vừa bắt đầu sinh ảnh có thanh tiến trình, đây là nghi phạm hàng đầu — **nhưng chưa xác nhận trên điện thoại thật** (không có Android trong môi trường kiểm). Hãy thử và báo kết quả.
- **Truyện, chương, nhân vật, LoRA bổ sung lưu bởi phiên bản CŨ:** nay được nạp với giá trị mặc định cho mọi trường mới thêm sau này. Trước đó, tệp thiếu trường có thể khiến truyện **biến mất khỏi danh sách** (lỗi bị nuốt im lặng) hoặc nhân vật mất cấu hình (ví dụ trọng số LoRA về 0, bong bóng thoại về mép trái). Không cần làm gì; dữ liệu cũ vẫn nguyên trên máy.
- Vẫn **chưa làm** (có số đo thật nhưng chưa đủ để dựng đúng): trẻ dưới 6 tuổi (thiếu số đo thân/đùi/cẳng chân/cẳng tay cùng định nghĩa) và người trên 18 tuổi (số đo cho thấy chiều cao chỉ sụt rõ từ 60 tuổi, không phải từ 30–40 như mục 284 từng viết; cánh tay không đổi). Chi tiết ở TECHNICAL_STATUS.md mục 286.
