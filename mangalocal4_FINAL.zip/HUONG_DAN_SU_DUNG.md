# MangaLocal — Hướng dẫn sử dụng & luồng quy trình hoạt động

> Tài liệu này mô tả **luồng thật trong code** (`MainActivity.kt` NavHost,
> `MainViewModel.kt`, các file `ui/*.kt`) — không phải mô tả lý tưởng hoá.
> Mọi tên hàm/route nhắc tới đều tồn tại thật trong source, đối chiếu
> trực tiếp lúc viết tài liệu này. Nhắc lại điều quan trọng nhất từ
> `TECHNICAL_STATUS.md` mục 0: **toàn bộ app CHƯA từng build-test/chạy
> thật lần nào** — tài liệu này mô tả app sẽ hoạt động NHƯ THẾ NÀO theo
> đúng thiết kế code, không phải xác nhận đã chạy đúng trên máy thật.

---

## 1. Tổng quan — MangaLocal là gì

Ứng dụng Android sinh truyện tranh (manga/manhwa) từ văn bản, chạy
**local-first** (mọi model AI chạy ngay trên điện thoại, không bắt buộc
mạng) — có tuỳ chọn định tuyến một phần công việc sang GPU thuê ngoài
(Colab/RunPod/Vast.ai) nếu muốn nhanh hơn hoặc máy yếu.

Input: văn bản truyện (dán tay hoặc dán JSON kịch bản đã chia scene sẵn
từ LLM ngoài app). Output: chuỗi ảnh panel truyện tranh có bubble thoại,
xuất ra PDF và/hoặc CBZ.

---

## 2. Chuẩn bị trước khi dùng lần đầu — model bắt buộc

App **không tự tải model qua mạng theo mặc định** (bảo mật offline) —
phải tự nạp model tĩnh vào máy trước. Vào màn **Cài đặt** (`settings`) để:

1. **LLM model** (bắt buộc) — dùng để đọc hiểu văn bản truyện, chia
   scene, viết prompt. Import qua nút trong Settings (`importLlmModels()`).
2. **SD model** (bắt buộc) — model sinh ảnh chính. **SD1.5** có đầy đủ
   tính năng (IP-Adapter/LoRA/ControlNet-Pose/mask/regional — xem mục
   3.5 dưới), ĐÃ build-test qua CI thật (build #97) — dùng cho luồng
   chính của app. **SDXL Local** (`TECHNICAL_STATUS.md` mục 171/177-184):
   đã xong tầng dữ liệu (Phase 1), đã viết xong ở tầng code cả 5 pipeline
   augmented/mask/regional/regional-mask/depth (Phase 2, mục 177-181), VÀ
   NAY ĐÃ NỐI dispatch thật + có UI bật (Phase 3, mục 184 — thẻ "SDXL
   (thử nghiệm)" trong Cài đặt: Switch chọn dùng SDXL + ô chọn thư mục
   model SDXL riêng — **mục 204**: giờ có dropdown quét sẵn thư mục nào
   trong `modelsDir` đã đủ file SDXL tối thiểu, kèm nút refresh; thư mục
   chưa đủ file (đang copy dở) không hiện ở dropdown — vẫn gõ tay được ở
   ô text ngay bên dưới, không mất lựa chọn nào). **NHƯNG TOÀN BỘ đường SDXL — cả Phase 2 lẫn
   Phase 3 — CHƯA build-test/CHƯA chạy thử thật lần nào** (không GPU/
   thiết bị thật lúc viết) — bật lên có thể sinh ảnh lỗi, rất chậm, hoặc
   crash, khác hẳn mức độ tin cậy của SD1.5. Dùng SD1.5 cho luồng chính —
   chỉ bật SDXL nếu chấp nhận rủi ro và muốn tự thử nghiệm (chọn được
   768×768 hoặc 1024×1024 ở Cài đặt — mục 189, KHÔNG có 512 vì lý do kỹ
   thuật; **(mục 205)** giờ ĐÃ có Quality Gate — badge cảnh báo hiện đúng
   cho panel SDXL trực tiếp, nhưng KHÔNG có phương án SDXL-thay-thế nào
   khác nếu chính panel SDXL đó không đạt (đã là SDXL rồi). **(mục 207)**
   giờ ĐÃ có auto-fix giao thoa (2 nhân vật đè/chạm nhau) — tự bật cùng
   Switch "Tự sửa giao thoa" (mục 7) như SD1.5, dùng model `unet_sdxl.mnn`
   có sẵn cùng thư mục augmented; vẫn CHƯA có Multi-Pass Cascade riêng cho
   nhánh này (tính năng khác, sâu hơn — xem GIỚI HẠN THẬT ở mục 184/189/
   205/207). **(Mới, mục 192/193)** App tự đọc file
   `sdxl_resolution.txt` do `prepare_models.yml` ghi lúc export để biết
   ĐÚNG độ phân giải thật — Cài đặt hiện dòng "Độ phân giải THẬT" báo
   khớp (✓) hay lệch (⚠). **Lưu ý nếu bạn giữ `prepare_models.yml` tách
   riêng ngoài thư mục dự án**: phải là bản có input `sdxl_image_size`
   (mở file tìm chữ `image_size` — 0 kết quả là bản cũ, tuỳ chọn 768 sẽ
   không dùng được dù Cài đặt cho chọn, xem `TECHNICAL_STATUS.md` mục
   203) — nên luôn lấy lại nguyên thư mục dự án thay vì giữ riêng 1 file
   `.yml` cũ để tránh lệch pha.
   `rescanModels()` tự quét thư mục model SD1.5 đã copy vào máy (qua
   Google Drive/Files app...), khớp với `model_manifest.json` — model
   SDXL augmented KHÔNG qua cơ chế này, gõ tay tên thư mục ở Cài đặt.
3. **LoRA** (tuỳ chọn, cho nhân vật cần giữ mặt) — import qua
   `importLoras()`.
4. **YOLO model** (bubble detect + pose) — `importYoloModels()`.
5. **ESRGAN model** (upscale) — `importEsrganModels()`.

`modelSetupGuide()`/`modelStatus()` trong ViewModel cho biết còn thiếu
model nào — Settings hiện trực tiếp trạng thái này.

**(Mới, TECHNICAL_STATUS.md mục 161 đợt 3) Tải model tự động — TUỲ
CHỌN, KHÔNG bắt buộc**: card "Tải model tự động" trong Settings hiện nút
tải trực tiếp CHO ĐÚNG file nào `model_manifest.json` có khai URL. Mặc
định KHÔNG có URL nào (không ai host sẵn model 6-8GB nào cả) — mọi model
vẫn phải tự copy tay như trước nếu chưa tự cấu hình URL. Đây là hạ tầng
CHO NGƯỜI TỰ HOST model của mình (VD tự tạo GitHub Release), không phải
tính năng "bấm nút là có model" cho người dùng thông thường — xem
`model_manifest.json` mục `_download_mau` để biết cách điền URL nếu tự
host.

**Máy yếu (dưới 8GB RAM)**: bật "Chế độ 4 Giai đoạn Công nghiệp"
(`industrialBatchUpscaleMode`) trong Settings — SD/ESRGAN/YOLO/SAM được
nạp và giải phóng tuần tự thay vì giữ tất cả cùng lúc trong RAM.

---

## 3. Luồng chính — từ văn bản tới ảnh truyện tranh

```
StoryListScreen ─▶ StoryDetailScreen ─▶ [CharacterSummaryReviewScreen] ─▶ [RoutingReviewScreen] ─▶ GeneratingScreen
   (stories)         (story_detail)      (chỉ khi có nhân vật mới)          (routing_review)        (generating)
                                                                                                            │
                                                                                                            ▼
   PostProcessingScreen ◀── proceedToUpscale() ◀── GalleryReviewScreen (gallery_review)
   (post_processing)                                    (duyệt từng panel)
          │
          ▼
   Export PDF/CBZ
```

### Bước 1 — Tạo truyện (`StoryListScreen` → `StoryDetailScreen`)

`createStory(title, description, style, worldRules, promptGuideNotes)` —
chọn phong cách ảnh (checkpoint anime/manga hay cinematic — quyết định
`PromptStyle` LLM dùng để viết prompt, xem `TECHNICAL_STATUS.md` mục 7).
`worldRules`/`promptGuideNotes` là ghi chú tự do user viết thêm, LLM đọc
kèm khi viết kịch bản.

### Bước 2 — Tạo nhân vật (`CharactersDetailScreen`)

`addCharacter(name, anchor, neg, role, loraPath, seed)` — mỗi nhân vật
chọn 1 **vai trò** (`CharacterRole`): `MAIN` (vai chính, xuất hiện nhiều
— nên dùng LoRA cho giống mặt nhất), `SUPPORTING` (vai phụ — gợi ý
IP-Adapter, nhẹ hơn LoRA), `ONETIME` (xuất hiện 1 lần — thường không cần
giữ nhất quán).

Chọn 1 trong 4 **phương pháp giữ nhất quán khuôn mặt**
(`ConsistencyMethod`): `LORA` (giống mặt nhất, cần convert trước —
`convertCharacterLora()`), `IP_ADAPTER` (dùng 1 ảnh neo, không cần
convert — `setCharacterAnchorImage()`), `TEXTUAL_INVERSION` (nhẹ nhất,
`setCharacterEmbeddingFromSource()`/`...FromUri()`), hoặc `NONE`.

2 nhân vật cùng xuất hiện chung nhiều panel? Cân nhắc convert GHÉP CẶP
(`convertCharacterPair()`) — 1 checkpoint chứa cả 2 LoRA, giảm rò rỉ đặc
điểm giữa 2 người (kỹ thuật Orthogonal LoRA, xem `TECHNICAL_STATUS.md`
mục 3).

Muốn xem trước ảnh neo/LoRA cho ra mặt nhân vật thế nào trước khi dùng
thật? `generateAnchorCandidates()` sinh vài ảnh ứng viên,
`approveAnchorCandidate()` chọn 1 ảnh làm chính thức.

**(Mới, TECHNICAL_STATUS.md mục 161 đợt 2) Nhân vật lớn lên/đổi trang
phục/bị thương vĩnh viễn giữa truyện?** Trong màn sửa nhân vật, nút "Tạo
phiên bản ngoại hình mới" — nhập mô tả thay đổi (VD "có sẹo trên má
trái") + chọn áp dụng từ chương số mấy + tuỳ chọn đổi tỷ lệ cơ thể (Trẻ
em/Thiếu niên/Người lớn, nếu là "lớn lên") → chọn 1 trong 4 ảnh nháp.
Panel từ chương đó trở đi TỰ ĐỘNG dùng ảnh + tỷ lệ mới, chương trước đó
không đổi gì. Kích hoạt THỦ CÔNG (không có tự động phát hiện "nhân vật
đổi trang phục" từ văn bản truyện).

(Tuỳ chọn) **Quan hệ gia đình** (`FamilyRelationshipScreen`, route
`family`) — khai báo quan hệ giữa các nhân vật (cha/mẹ/con/anh em...) để
LLM viết kịch bản nhất quán về xưng hô/tương tác.

**(Mục 248) Thư viện nhân vật dùng chung**: nút "📚 Thư viện nhân vật" trên màn hình này mở hộp thoại để (a) lưu một nhân vật của truyện hiện tại vào thư viện (hồ sơ, seed, LoRA/embedding, tỉ lệ xương và ảnh anchor/anchor rách/anchor biểu cảm được SAO CHÉP, xoá truyện gốc không mất) và (b) nhập nhân vật từ thư viện vào truyện đang mở (id mới; trùng tên thì thêm "(2)"). Phiên bản anchor theo chương KHÔNG đi theo; file LoRA/embedding chỉ ghi đường dẫn nên chỉ còn hiệu lực trên cùng thiết bị. Chưa build-test.

### Bước 3 — Dán văn bản truyện (`StoryDetailScreen`)

2 cách đưa nội dung vào:
- **Dán văn bản thô** — gõ/dán trực tiếp, `analyzeStoryText()` tự đếm số
  chương phát hiện được (theo `TextChunker.split()`). Nếu vượt ngưỡng
  (`TextChunker.INDUSTRIAL_SUGGEST_THRESHOLD`), app hỏi có muốn chạy
  **Chế độ Công nghiệp** không (xem mục 5 bên dưới) thay vì làm tay từng
  chương.
- **Dán JSON kịch bản ngoài** (`prepareChapterFromExternalScript()`) —
  nếu đã tự dùng LLM khác (ChatGPT/Gemini...) chia scene sẵn theo đúng
  format `ExternalScriptImport.kt` quy định. Vẫn cần LLM on-device (chỉ
  để dịch prompt sang tag SD, không parse lại kịch bản).

Cả 2 cách đều gọi `analyzeCharactersFirst()`/`prepareChapterFromExternalScript()`
— **KHÔNG viết kịch bản chi tiết ngay** (mục 154 TECHNICAL_STATUS.md,
"đảo pipeline nhân vật"). Xem Bước 3.5 ngay dưới.

**(Mục 249) Chỉ định bối cảnh ngay trong văn bản**: gõ `@Tên bối cảnh đã có` (không phân biệt hoa/thường/dấu; lấy tên dài nhất) hoặc `@[Tên bối cảnh mới]` để báo cảnh xảy ra ở đâu. Thẻ có hiệu lực **từ chỗ nhắc tới thẻ kế tiếp** (như dòng slug trong kịch bản). App bỏ ký hiệu `@` trước khi gửi LLM, thêm một dòng hướng dẫn, rồi hậu xử lý: cảnh LLM để trống nhận bối cảnh theo vị trí; LLM được chọn giữa các bối cảnh đã nhắc nhưng không được bịa nơi khác ở vị trí đã gắn thẻ. **Giới hạn**: ánh xạ cảnh ↔ vị trí trong văn bản chỉ là xấp xỉ theo tỉ lệ (cảnh sát chỗ đổi bối cảnh có thể bị gán sang bên kia); chỉ chỉ định bối cảnh, không chỉ định nhân vật; địa chỉ email hay `@tên_người` không khớp bối cảnh nào thì bị bỏ qua. Chưa thử với LLM thật.

### Bước 3.5 — Xác nhận nhân vật mới (`CharacterSummaryReviewScreen`, chỉ hiện khi cần)

`analyzeCharactersFirst()` chạy 1 lượt LLM RẺ (không chia panel, chỉ đọc
tên + đoán vai trò + tóm 1 câu) TRƯỚC khi viết kịch bản chi tiết. **Chỉ
dừng lại xin xác nhận nếu phát hiện nhân vật MỚI** (chưa có trong
`story.characters`) — chương 2 trở đi (mọi nhân vật đã biết) tự động bỏ
qua bước này, chảy thẳng sang Bước 4 như đường dán JSON.

Nếu có nhân vật mới, màn `CharacterSummaryReviewScreen` hiện ra (thiết kế
mobile: 1 card/nhân vật cuộn dọc, chip to cho vai trò, nút xác nhận ghim
cố định ở đáy màn hình):
- Sửa vai trò (Chính/Phụ/Một lần) nếu AI đoán sai.
- Đánh dấu **"Cần giữ mặt nhất quán qua nhiều khung ảnh?"** (Có/Không) —
  CHỈ dùng làm gợi ý TẠM cho LLM viết kịch bản né ghép chung panel những
  người cần tách riêng — KHÔNG tự động set LoRA/IP-Adapter thật (vẫn phải
  tự làm ở Bước 2 như bình thường, đây chỉ là gợi ý sớm giúp bố cục panel
  hợp lý hơn ngay từ đầu).
- Xoá (nút ✕) nếu AI nhận nhầm tên không phải nhân vật.
- **"Xác nhận → Viết kịch bản"** (chính) hoặc **"Dùng gợi ý mặc định,
  viết luôn"** (bỏ qua chỉnh sửa, chấp nhận nguyên văn AI đoán) hoặc
  **"Huỷ"** (quay lại ô dán văn bản, không tạo gì).

Sau khi xác nhận, `confirmCharacterSummaryAndProceed()` tạo `Character`
mới cho từng người (role đã chọn, mô tả AI tóm làm anchor prompt tạm —
nên vào Bước 2 viết lại chi tiết hơn sau) rồi MỚI gọi `prepareChapter()`
thật — kết quả vào `_pendingChapter` (CHƯA sinh ảnh, chỉ mới có kịch bản
+ prompt).

### Bước 4 — Duyệt định tuyến Local/Remote (`RoutingReviewScreen`, tuỳ chọn)

Chỉ có ý nghĩa nếu đã cấu hình GPU thuê ngoài (xem mục 6). Màn này cho
xem trước panel nào sẽ chạy Local (điện thoại), panel nào chạy Remote
(GPU cloud) — theo `RoutingMode.MANUAL` (rule tự đặt) hoặc `AUTO` (LLM tự
quyết theo mô tả tiếng Việt tự do user viết trong Settings). Có thể sửa
tay từng panel qua `setBatchBackend()` trước khi xác nhận. Không cấu hình
Remote → mọi panel mặc định Local, có thể bỏ qua màn này.

### Bước 5 — Sinh ảnh (`GeneratingScreen`)

`confirmRoutingAndGenerate()` → `pipeline.runGeneration()` — chạy UNet
thật cho từng panel (chọn đúng pipeline theo số nhân vật/có cần
Depth/Regional Prompting hay không, xem `TECHNICAL_STATUS.md` mục 3).
Có thể `cancelGeneration()` giữa chừng (cờ interrupt JNI dừng ở step kế
tiếp, xem mục 10 — không dừng ngay lập tức tuyệt đối).

### Bước 6 — Duyệt từng panel (`GalleryReviewScreen`)

Với mỗi panel đã sinh, chọn 1 trong các hành động:
- **Duyệt** (`approvePanel()`) — panel đạt yêu cầu, chuyển trạng thái
  `APPROVED`.
- **Sinh lại** (`regeneratePanel()`) — không ưng ý, chạy lại (có thể sửa
  prompt tay hoặc chỉnh override riêng panel đó).
- **Sửa tay 1 vùng lỗi** (`manualMaskFixPanel()`) — chấm tay vào điểm
  lỗi (vd tay biến dạng), app tự vẽ mask quanh đó rồi img2img sửa riêng
  vùng đó (không sinh lại cả panel).
- **Import ảnh ngoài thay hẳn panel này** (`importPanelImage()`) — có sẵn
  ảnh vẽ tay/lấy nguồn khác, bỏ qua AI sinh hoàn toàn cho panel đó (xem
  `TECHNICAL_STATUS.md` mục 12).
- **Sửa tư thế tay** (`pose_editor`) — mở `PoseEditorScreen`, kéo/chỉnh
  khớp xương panel đó trước khi sinh lại (pinch-to-zoom hỗ trợ chỉnh chi
  tiết trên màn nhỏ).

**(Mới, TECHNICAL_STATUS.md mục 185-197) Cảnh báo Quality Gate + 2 ô tuỳ
chỉnh thêm khi mở `EditPanelSheet`**: panel bị nghi khung xương đầu vào
có vấn đề (dựa trên khung xương, KHÔNG phải nhìn pixel ảnh đã sinh — mục
185) hiện badge **"⚠ Nên xem kỹ"** ở góc ảnh; mở sheet để xem chi tiết lý
do (chỉ là gợi ý xác suất, ảnh vẫn có thể đẹp dù bị đánh dấu và ngược
lại, cần tự nhìn ảnh để quyết định). Lúc sinh hàng loạt
(`generatePanels()`), nếu panel dùng SD1.5 mà không đạt Quality Gate, app
tự thử sinh lại 1 lần bằng SDXL làm phương án thay thế (cần đã cấu hình
`sdxlModelId` ở mục 2) — không có gì đảm bảo ảnh SDXL tốt hơn, chỉ là 1
lựa chọn khác để tự so sánh.

Trong sheet còn có:
- **Model tier riêng cho panel này** — chip "Tự động (Cài đặt)"/"SD1.5"/
  "SDXL (thử nghiệm)", ghi đè lựa chọn chung chỉ cho panel đang sửa, áp
  dụng khi bấm "Vẽ lại".
- **Biểu cảm riêng từng nhân vật** (chỉ hiện với panel ≥2 người) — mỗi
  người 1 hàng chip chọn 1 trong 12 biểu cảm, hoặc để "Theo LLM" (giữ
  nguyên LLM tự phân loại). Chỉ có tác dụng khi bật `enableMultiPassCascade`
  (mục 7) VÀ khi bấm "Vẽ lại" — muốn áp dụng lúc sinh hàng loạt, phải tự
  đặt trước khi chạy batch.

### Bước 7 — Hậu kỳ (`PostProcessingScreen`)

`proceedToUpscale()` — chạy ESRGAN nâng độ phân giải + Ultrafix (vẽ lại
nhẹ toàn ảnh) + auto-fix mặt/tay cho mọi panel đã `APPROVED`. Sau đó
`runAutoBubble()` — tự đặt bubble thoại (YOLO detect bóng thoại trống,
đặt chữ theo thoại đã sinh). Có thể sửa tay vị trí/nội dung bubble từng
panel (`updatePanelBubbles()`) trước khi xuất.

**(Mục 228 + 249) Bóng thoại theo người nói, đuôi và lớp**: khi panel có khung xương đầu vào, bubble được đặt né khuôn mặt, gần người đang nói, và khi XUẤT PDF/CBZ có đuôi trỏ về phía đầu người nói (lời thoại dài tự xuống dòng, không bị cắt bằng "…" nếu ≤ 8 dòng). **Mục 249**: trong màn sửa bubble, bubble nào có đuôi sẽ hiện một đường kèm **chấm cam** — kéo chấm để chỉ đích đuôi; nhấn bubble để mở hộp thoại: đổi **loại** (Thoại / Nghĩ / Dẫn / Hét), bật/tắt **đuôi** (bật mà chưa có thì đặt đuôi mặc định bên dưới bubble) và đổi **lớp** (Lên trên / Xuống dưới — bubble đứng sau trong danh sách được vẽ đè lên trên). Cùng lúc đó tôi sửa lỗi cũ: vị trí hiển thị và độ dời khi kéo trước đây dùng hằng 300 và chia pixel cho 300 nên bubble hiển thị lệch so với file xuất và di chuyển nhanh hơn ngón tay; nay dùng cạnh thật của khung và đổi px→dp. Chưa chọn được font/cỡ chữ (bộ vẽ tự co chữ). Chưa thử cảm ứng trên máy thật. Panel không có khung xương (vd nhánh GLIGEN/SDXL không dùng pose) thì bubble đặt theo cách cũ, không đuôi tự động (vẫn bật đuôi tay được).

### Bước 8 — Xuất file

`exportChapter(exportPdf, exportCbz, destUri)` — xuất PDF và/hoặc CBZ (2
định dạng độc lập, chọn 1 hoặc cả 2). Mặc định lưu vào thư mục nội bộ app
(`storyManager.outputDir()`); nếu chọn `destUri` (qua trình chọn thư mục
hệ thống), file được copy thêm ra vị trí đó (vd thư mục chia sẻ Google
Drive) — không thay thế bản nội bộ.

**(Mới, TECHNICAL_STATUS.md mục 161 đợt 4) Dọn dẹp file trung gian —
TUỲ CHỌN, hiện SAU KHI xuất `.cbz` thành công**: card "Dọn dẹp file
trung gian" — 2 lựa chọn: **Nén còn sửa được** (PNG panel gốc → JPEG
chất lượng cao, vẫn sửa lại được sau, giảm dung lượng đáng kể) hoặc
**Xoá hẳn** (giải phóng tối đa, MẤT khả năng sửa lại panel đó — "Tạo lại"
sẽ phải sinh mới hoàn toàn). File `.cbz`/`.pdf` đã xuất KHÔNG bị ảnh
hưởng dù chọn cách nào. Hữu ích khi chạy nhiều chương liên tiếp trên máy
ROM nhỏ (panel PNG gốc có thể tới ~1GB/chương sau upscale).

---

## 3.5. Nhiều nhân vật trong 1 khung ảnh (tuỳ chọn, cần model riêng)

**(Mới, TECHNICAL_STATUS.md mục 175 — mục này trước đây CHƯA từng được
viết vào tài liệu dù code đã có từ mục 51/52/56/69/143/151/152/172, đã vá
lại đúng gap đó ở đây.)**

Khi 1 panel có ≥2 nhân vật cần giữ mặt nhất quán, và cài đặt
`useStoryDiffusion` đang BẬT (mục 7 dưới, mặc định bật), app tự chọn 1
trong 5 cách sinh ảnh sau — đúng thứ tự ưu tiên này (đối chiếu trực tiếp
chuỗi if/else thật trong `MangaPipeline.kt`, không phải suy đoán):

1. **Triple-Combo** (Pose + Depth + IP-Adapter + Regional Prompting cùng
   lúc) — ưu tiên cao nhất, cần file `unet_triple_combo_{N}region.mnn`
   VÀ mọi nhân vật trong cảnh đã có ảnh neo. Cho kết quả tốt nhất ở cảnh
   nhiều người vật lộn/ôm nhau, nhưng cũng nặng nhất.
2. **Mask N-nhân-vật** (mỗi người 1 vùng mask + 1 ảnh neo IP-Adapter
   riêng) — dùng nếu có file `unet_ipa_mask_controlnet_{N}char.mnn`
   nhưng không có Triple-Combo. Giữ mặt tốt cho từng người.
3. **Regional-Mask / Attention Couple** (mask hình dạng tuỳ ý theo tư
   thế, KHÔNG dùng ảnh neo — chỉ chữ mô tả mỗi vùng) — dùng nếu có file
   `unet_regional_mask_controlnet_{N}char.mnn` nhưng không có 2 cái trên.
4. **Regional Prompting cột** (chia đều theo cột dọc, cũng chỉ dùng chữ
   mô tả mỗi vùng) — dùng nếu có file
   `unet_regional_controlnet_{N}col.mnn` nhưng không có 3 cái trên.
5. **Mặc định** (không có file nào ở trên) — dùng LoRA ghép cặp nếu đã
   convert (mục 3), hoặc chỉ neo 1 nhân vật chính bằng IP-Adapter/LoRA;
   người còn lại chỉ có tư thế (ControlNet-Pose), không giữ mặt.

**Cách lấy các file `.mnn` trên**: chạy workflow `prepare_models.yml`
(GitHub Actions, xem mục 2) với đúng input tương ứng bật lên
(`export_mask_variant`/`export_regional_variant`/
`export_regional_mask_variant`/`export_triple_combo_variant` — mỗi cái
có ô nhập số nhân vật N riêng; chạy lại workflow nếu cần nhiều N khác
nhau), rồi copy file `.mnn` tải về (mục Artifacts của lần chạy) vào đúng
thư mục model trên máy — KHÔNG cần đổi tên file, `StoryManager` tự dò
đúng tên.

**Depth ControlNet** (`export_depth_variant`) là 1 trường hợp RIÊNG —
KHÔNG phải 1 trong 5 pipeline trên, mà là bản THAY THẾ file
`unet_ipa_controlnet.mnn` gốc (TÊN GIỐNG HỆT — app tự dò input
`depth_hint` có tồn tại trong file hay không, không cần bật cờ gì khác)
— giúp app đoán đúng hơn ai đứng trước/sau khi 2 khung xương chồng lấn.
Workflow đóng gói file này vào thư mục con `depth_variant/` riêng để
không đè bản gốc — tự chọn copy-thay-thế nếu muốn dùng.

**Giới hạn thật**: cả 5 cách trên đều yêu cầu `useStoryDiffusion=true` VÀ
mỗi nhân vật phải có ảnh neo hợp lệ — thiếu 1 trong 2 điều kiện, app tự
rơi xuống cách sinh ảnh đơn giản hơn ở dưới, KHÔNG báo lỗi. Toàn bộ 5
file `.mnn` trên (khác với 3 file mặc định máy đã dùng: `clip`/`unet`/
`vae`) đều CHƯA được build-test bằng ảnh thật trên thiết bị — dùng thử và
báo lại nếu ảnh ra sai/lỗi (xem `TECHNICAL_STATUS.md` mục 175 cho chi
tiết kỹ thuật, bao gồm 1 bug đã vá: file `regional_mask_prompting.cpp`
từng thiếu 1 dòng biên dịch trong `CMakeLists.txt`, khiến pipeline #3
từng chắc chắn crash nếu dùng thử trước bản vá đó).

---

**(Mục 250) Hậu kỳ trên server cho cảnh tiếp xúc/nhiều người**: ba công tắc trong Cài đặt > Remote GPU chạy sau bước Phóng to theo thứ tự **Kontext → sửa tay → hoán đổi mặt**; kết quả ghi thành file mới `panel_NNN_srv.png` (ảnh gốc giữ nguyên). Lỗi một panel thì giữ ảnh cũ của panel đó; server cũ không hỗ trợ tác vụ thì dừng ngay (không phí các lượt còn lại). Xem cách dựng server và giấy phép ở `tools/remote_server/README.md`.

**(Mục 249) Gộp hai LoRA nhân vật bằng TIES/DARE (công cụ ngoại tuyến, cho nhánh Remote GPU)**: `python tools/lora_ties_merge.py a.safetensors b.safetensors -o merged.safetensors --method ties --density 0.5` gộp nhiều LoRA kohya thành MỘT file thay vì cộng thẳng (cắt bớt tham số nhỏ, bỏ phần tử trái dấu, rồi SVD về lại dạng LoRA). Đặt `merged.safetensors` vào `--loras-dir` của server và gửi như một `lora_id` cho cảnh nhiều người. **Đường on-device không đổi.** Chưa có bằng chứng trong dự án rằng nó giảm rò danh tính giữa hai nhân vật — phải thử: sinh cùng seed với LoRA gộp thường và LoRA gộp TIES rồi so.

## 4. Vòng lặp nhiều chương

`selectChapter()` chuyển qua lại giữa các chương đã lưu của cùng truyện.
Mỗi chương độc lập — lặp lại Bước 3→8 cho chương tiếp theo. Ảnh nhân vật
neo (LoRA/IP-Adapter/Textual Inversion) dùng CHUNG cho mọi chương của

cùng truyện, không cần cấu hình lại.

---

## 5. Chế độ Công nghiệp — sinh hàng loạt nhiều chương liên tiếp

Dùng khi có sẵn TOÀN BỘ truyện dài (hàng chục/hàng trăm chương) và muốn
chạy xuyên đêm không cần ngồi duyệt routing từng chương.

`analyzeStoryText()` tự gợi ý chế độ này nếu phát hiện đủ số chương.
`runIndustrialBatch(chapters)` chạy tuần tự: mỗi chương tự
`prepareChapter()` rồi `runGeneration()` NGAY (không dừng chờ duyệt
routing như luồng thủ công) — vẫn qua đúng `BackendRouter` tự động.

**An toàn cho batch dài**: mỗi chương lỗi (văn bản dị dạng, ảnh hỏng...)
CHỈ bị bỏ qua (ghi log), KHÔNG làm chết cả batch (error shunning, xem
`TECHNICAL_STATUS.md` mục 10). Nếu app bị hệ điều hành giết giữa batch
dài (RAM/pin/nhiệt), lần mở app sau `peekResumableBatch()` phát hiện có
batch dở dang của đúng truyện đang mở — dán lại ĐÚNG văn bản cũ,
`runIndustrialBatch()` tự nhận ra (so khớp hash) và resume đúng chỗ dở
dang, không sinh lại từ đầu. `cancelIndustrialBatch()` dừng tay giữa
chừng bất kỳ lúc nào.

**(Mới, TECHNICAL_STATUS.md mục 161 đợt 8-10) Cách ly lỗi native —
CHƯA build-test, đọc kỹ giới hạn**: bước SINH ẢNH (không phải bước phân
tích văn bản) giờ chạy trong 1 tiến trình Android RIÊNG
(`:inference`) — nếu có lỗi crash ở tầng native/thư viện AI trong lúc
sinh 1 chương, về LÝ THUYẾT chỉ chương đó bị đánh dấu lỗi (rơi vào đúng
cơ chế error shunning ở trên) và batch tiếp tục, thay vì kéo sập toàn bộ
app như trước. Đây là thay đổi kiến trúc LỚN, MỚI VIẾT, **CHƯA có xác
nhận chạy đúng trên thiết bị thật** — nếu gặp app vẫn tắt hẳn khi batch
dài, đó là dấu hiệu cần báo lại để kiểm tra, không phải "chưa đọc kỹ tài
liệu này".

Sau khi batch chạy xong, vẫn cần vào từng chương để duyệt panel (Bước
6-8) như luồng thủ công — Chế độ Công nghiệp chỉ tự động hoá bước SINH
ẢNH hàng loạt, không tự động hoá bước duyệt/hậu kỳ/xuất file.

---

## 6. GPU thuê ngoài (tuỳ chọn — máy yếu hoặc muốn nhanh hơn)

Không bắt buộc — bỏ qua mục này nếu chỉ chạy Local. Cần khi máy quá yếu
để chạy SD local ở tốc độ chấp nhận được, hoặc muốn dùng SDXL (nặng hơn
SD1.5 nhiều).

**Lưu ý riêng cho SDXL qua GPU thuê ngoài (khác hẳn SDXL chạy Local, xem
mục 2)**: `tools/remote_server/app.py` dùng thẳng thư viện `diffusers`
trên máy chủ, nên SDXL ở ĐÂY đã có sẵn ControlNet-Pose + IP-Adapter (1
nhân vật) — KHÔNG bị giới hạn "chỉ sinh ảnh cơ bản" như SDXL chạy Local.
Nhưng vẫn có 2 giới hạn thật, áp dụng NHƯ NHAU cho cả SD1.5 lẫn SDXL khi
chạy qua GPU thuê ngoài (không riêng gì SDXL): (1) KHÔNG nhận LoRA khi
đang ở SDXL (server tự bỏ qua + log cảnh báo nếu app gửi `lora_id`, do
kiến trúc UNet SDXL khác hẳn SD1.5), (2) KHÔNG có bất kỳ pipeline nào
trong 5 pipeline nhiều-nhân-vật ở mục 3.5 (mask/regional/regional-mask/
triple-combo/depth) — những pipeline đó là code C++ tuỳ biến riêng cho
máy chạy Local, server Python chưa từng cài đặt lại.

1. Chạy `tools/remote_server/app.py` trên máy có GPU (Colab miễn phí là
   lựa chọn dễ nhất — dùng notebook đính kèm, Cloudflare Tunnel tự lộ ra
   Internet không cần đăng ký).
2. Nhập địa chỉ server vào Settings — app tự xác thực bằng cặp khoá
   RSA-OAEP + fingerprint TOFU (tự sinh lúc đầu, cảnh báo nếu fingerprint
   đổi ở lần kết nối sau — dấu hiệu server đã đổi, không tự động tin).
3. Chọn `RoutingMode`: `MANUAL` (tự đặt rule — vd "panel có ≥3 nhân vật
   → Remote") hoặc `AUTO` (viết mô tả tiêu chí bằng tiếng Việt tự nhiên,
   LLM on-device tự áp dụng).
4. `RoutingReviewScreen` (Bước 4 ở trên) hiện ra để duyệt/sửa tay trước
   khi sinh — LUÔN có bước duyệt này khi có panel định tuyến Remote,
   không tự động chạy thẳng.

**Giới hạn bảo mật thật** (đọc kỹ trước khi dùng GPU thuê ngoài — không
phải chỉ cảnh báo hình thức): mã hoá RSA+AES chỉ chống người thứ 3 nghe
lén trên đường truyền mạng — **không chống được chính chủ máy chủ GPU**
(họ có quyền truy cập VM đang chạy prompt/ảnh của bạn dạng plaintext lúc
xử lý). Chỉ dùng Remote cho nội dung sẵn sàng để lộ cho chủ hạ tầng thuê
thấy. Xem `TECHNICAL_STATUS.md` mục 9/14 để hiểu đầy đủ.

---

## 7. Cài đặt quan trọng cần biết (Settings)

| Cài đặt | Ý nghĩa | Khi nào chỉnh |
|---|---|---|
| `useStoryDiffusion` | Bật giữ mặt nhân vật nhất quán (IP-Adapter/LoRA + toàn bộ 5 pipeline nhiều-nhân-vật, mục 3.5) | Mặc định BẬT — chỉ tắt nếu muốn tốc độ tối đa và chấp nhận không giữ mặt ai |
| `enableQualityGate` | YOLO tự đếm chi, auto-sinh lại nếu sai (chỉ nhánh 1-nhân-vật) | Bật nếu hay gặp lỗi giải phẫu tay/chân |
| `verifyOutputPose` | **(Mục 248) Kiểm tra ảnh SAU khi sinh**: dò lại tư thế bằng YOLOv8-pose trên ảnh ra rồi so với khung xương đưa vào — thiếu/thừa người, lệch tư thế, tỉ lệ giữa các người. Chỉ CẢNH BÁO thêm lý do vào badge Quality Gate của panel, không tự thử lại. Người bị che/dính nhau (cảnh vật lộn) có thể bị dò thiếu dù ảnh đúng | Tắt mặc định; ngưỡng chưa hiệu chỉnh; chưa build-test |
| `differentialInpaint` | **(Mục 248) Differential Diffusion** cho các lượt vẽ lại CÓ MASK (vùng chạm/mặt/tay): mask mềm trở thành "độ thay đổi" theo từng bước thay vì trọng số trộn cố định → chuyển tiếp mượt hơn ở biên. Mask cứng thì không khác gì cũ | Tắt mặc định; chưa build-test, nên so ảnh bật/tắt cùng seed |
| `consistencyStrength` (Smooth Timestep Decay) | Ảnh hưởng ảnh neo IP-Adapter giảm dần cuối quá trình sinh | Giảm nếu mặt quá cứng/không theo biểu cảm LLM viết |
| `useUltrafixRedraw` | Vẽ lại nhẹ toàn ảnh sau upscale trước khi auto-fix | Bật nếu ảnh sau upscale bị mờ/nhiễu |
| Multi-Pass Inpainting Cascade | 3-4 lượt sửa mặt/tay giảm dần cường độ | Mặc định bật — tắt nếu muốn nhanh hơn, chấp nhận kém chính xác hơn cảnh đông người |
| `autoFixLimbContacts` + `maxContactFixRegions` | Ngoài hông/tay-đè-thân, dò thêm khuỷu tay, đầu gối, bàn chân, đầu, tay khoá cổ rồi vẽ lại cục bộ từng chỗ (chỉ có tác dụng khi bật auto-fix giao thoa; mục 227) | Mặc định BẬT, tối đa 4 vùng/panel — tăng cho cảnh vật lộn đông người, giảm nếu máy chậm |
| `sdxlFinishPass` + `sdxlFinishDenoise` | Panel vẫn sinh bằng SD1.5, các vùng tiếp xúc được SDXL vẽ lại lần cuối (mục 229). Chỉ ảnh vuông, cần cấu hình model SDXL, nặng RAM | Mặc định TẮT — bật khi cảnh vật lộn bị lỗi giải phẫu vùng chạm mà SD1.5 không sửa nổi |
| Màn hình **Biểu cảm & diễn xuất** (biểu tượng khuôn mặt trên thanh Nhân vật) | Quản lý tập trung: (1) Thư viện — 12 nhãn gốc + 15 biểu cảm dựng sẵn cho cảnh hành động + tự tạo biểu cảm từ thành phần mày/mắt/miệng/chi tiết/hướng nhìn/cường độ; (2) Dàn diễn viên — bảng biểu cảm từng nhân vật làm ảnh tham chiếu; (3) Diễn biến — biểu cảm từng nhân vật theo từng panel (mục 240) | Bảng biểu cảm cần anchor có mặt nhìn rõ và model YOLOv8-pose; xem ảnh và xoá nếu lệch mặt |
| `inpaintColorMatch` | Khớp màu vùng vẽ lại (mặt/vùng chạm) theo ảnh gốc để chống trôi màu da/tóc do img2img; biểu cảm đỏ mặt/tái mặt chỉ khớp nhẹ (mục 241) | Mặc định BẬT |
| Bộ từ vựng biểu cảm theo **Phong cách ảnh** | "Siêu thực" → mô tả giải phẫu cơ mặt; Anime/Manga/Manhwa → tag danbooru đã đối chiếu wiki. Màn hình Biểu cảm hiển thị bộ đang dùng và xem trước cả hai (mục 242) | Câu mô tả ảnh thực chưa được kiểm chứng trên checkpoint nào — thử và chỉnh |
| `expressionVocabulary` (AUTO / ANATOMICAL / BOORU) | Chọn bộ từ vựng biểu cảm; AUTO theo Phong cách ảnh. Dùng nút so sánh trong tab "Dàn diễn viên" để xem checkpoint của bạn hiểu bộ nào tốt hơn (cùng seed) (mục 243) | Checkpoint hiểu tag booru hay không còn tuỳ cách huấn luyện, không chỉ ảnh thực/anime |
| `exportVideoPack` + `videoPackTarget` | ZIP "gói ảnh cho model video": khung đầu sạch (không bóng thoại) cắt/đổi cỡ theo khung đích, khung kết đổi biểu cảm, prompt chuyển động, thoại (mục 244). Tab "Làm video" trong màn hình Biểu cảm để kiểm tra và tạo khung kết | Ứng dụng KHÔNG chạy model video; prompt chưa thử trên model thật |
| `exportVideoSpeech` | **(Mục 248)** Kèm file giọng đọc `pPPP_lLL.wav` (TextToSpeech của máy) cho từng câu thoại trong gói video; độ dài từng câu ghi ở `info.json`. Cần giọng Tiếng Việt cài sẵn trên máy (không có thì bỏ qua, gói vẫn xuất). Các nhân vật chỉ khác cao độ; KHÔNG ghép vào video, KHÔNG đồng bộ khẩu hình | Mặc định tắt; chưa thử trên máy thật |
| `exportVideoRemote` | **(Mục 249)** Tạo `clip.mp4` cho từng panel trên server Remote GPU bằng Stable Video Diffusion (từ `start.png`) và đưa vào gói video. Cần Remote GPU bật và `tools/remote_server/app.py` bản mới (tham số `--svd-model-id`, `--keep-svd`; **tự kiểm tra giấy phép model**). Mỗi clip có thể mất vài phút (thời hạn đọc 15 phút); ảnh được đặt vào khung 1024×576 giữ tỉ lệ (có viền đen nếu khác 16:9); chuyển động do model tự nghĩ. Server cũ (chưa hỗ trợ video) bị phát hiện và dừng thử, gói vẫn xuất | Mặc định tắt; chưa chạy trên server thật |
| `expressionFaceIdentity` + `expressionIdentityScale` | Khi vẽ lại mặt/khung kết/ảnh bảng biểu cảm, dùng ảnh anchor (hoặc ảnh đúng biểu cảm) làm tham chiếu IP-Adapter để không lệch khuôn mặt; cần model SD1.5 augmented đang nạp, không có thì dùng img2img thường (mục 245) | Mặc định BẬT, độ bám 0.6; cao hơn dễ kéo biểu cảm về ảnh tham chiếu |
| `expressionIdentityMinSim` | Cổng danh tính: đo độ giống mặt trước/sau khi vẽ lại bằng ArcFace; dưới ngưỡng thì thử lại 1 lần rồi giữ mặt cũ. 0 = tắt. Cần `arcface_mbf.mnn` trong `yolo/` (thiếu thì tự bỏ qua) (mục 246) | Mặc định 0.4 (hạ từ 0.5 ở mục 247 vì 0.5 dễ loại oan), CHƯA hiệu chỉnh — xem điểm đo trong nhật ký rồi chỉnh. Chỉ phù hợp ảnh siêu thực |
| `autoFixRegionOnlyPrompt` | Ở chế độ vẽ vùng chạm kiểu cắt, chỉ dùng mô tả loại chạm + hai nhân vật liên quan thay vì prompt cả cảnh (mục 238) | Mặc định BẬT |
| `expressionFacePass` + `expressionFaceDenoise` + `maxExpressionFaces` | Sau khi sinh ảnh, vẽ lại riêng vùng mày–mắt–miệng của nhân vật có biểu cảm khác trung tính, cùng seed panel (mục 238) | Mặc định TẮT vì có thể lệch khuôn mặt; thử 1 panel với denoise 0.40–0.45 trước |
| `autoFixCropInpaint` + `autoFixPasteBack` | Vẽ lại vùng chạm ở độ phân giải đầy đủ của model (cắt vùng + lề, phóng lên, vẽ, thu nhỏ, dán lại) và dán pixel gốc ngoài vùng sửa (mục 237). Áp dụng cho mọi loại vùng auto-fix | Mặc định BẬT; lỗi tự quay về cách vẽ cũ. Tắt từng cái để so sánh ảnh cùng seed |
| `useDepthForContacts` | Lọc điểm chạm theo độ sâu thật đọc từ ảnh đã sinh (MiDaS). Cần `midas_small_depth.mnn` trong thư mục `yolo/`; thiếu file thì tự bỏ qua (mục 232) | Mặc định BẬT, vô hại khi chưa có model |
| `exportPageTemplate` + `exportPageProfile` | Bố cục trang PDF (2 dọc / lưới 2×2 / 1 rộng + 2 dưới / 4-koma / 1 panel mỗi trang / **Tự chọn theo cảnh — mục 248**) và khổ trang (A4 / KDP 6×9 / KDP 6×9 có bleed). Mặc định giữ nguyên PDF cũ (mục 233) | KDP: lề trong (gáy) tự theo bảng chính thức của KDP theo số trang PDF — 24–150: 0,375"; 151–300: 0,5"; 301–500: 0,625"; 501–700: 0,75"; 701–828: 0,875" (đã đối chiếu trang KDP, mục 247) |
| `exportPageTemplate` = Tự chọn theo cảnh | **(Mục 248)** Mỗi trang một bố cục theo nhịp truyện: cảnh hành động tiếp xúc (combat/ôm/hôn), cận cực độ hoặc toàn cảnh → trang "1 ô rộng + 2 ô dưới"; chuỗi cảnh có thoại, không hành động → lưới 2×2; còn lại → 2 panel dọc; panel hành động cuối cùng của truyện (≥ 6 panel) → 1 trang toàn khổ. Mọi panel xuất hiện đúng 1 lần, đúng thứ tự. Quy tắc dựa trên dữ liệu cảnh do LLM nhỏ gán nên chỉ là gợi ý bố cục | Chưa xem thử PDF thật; chưa build-test |
| `exportRightToLeft` | Manga đọc phải → trái trong PDF **và CBZ (mục 249: ghi `<Manga>YesAndRightToLeft</Manga>` vào `ComicInfo.xml` ở gốc file CBZ — mọi CBZ nay có `ComicInfo.xml` với tiêu đề, bộ truyện, số chương, số trang)**: lật thứ tự ô trong trang (ô đầu ở bên phải) và đổi phía gáy sách theo quy tắc KDP (trang 1 là trang trái, lề trong bên phải). Không đảo thứ tự trang. **Lưu ý**: KDP chỉ nhận in sách phải → trái cho tiếng Nhật, Hebrew, Yiddish — truyện tiếng Việt tải lên KDP sẽ không chọn được hướng này; dùng cho PDF tự in/đọc (mục 247) | Mặc định TẮT; chưa build-test |
| `remoteEndpoint.pagScale` | **(Mục 248) PAG (Perturbed-Attention Guidance)** trên server từ xa (diffusers): 0 = tắt; thử 3.0. Giúp cấu trúc/giải phẫu ổn định hơn nhưng thêm một nhánh tính toán mỗi bước. Không chạy được on-device (cần nhánh attention bị phá nhiễu mà MNN không có). Server không dựng được PAG hoặc lỗi cùng IP-Adapter → tự chạy lại KHÔNG PAG | Tắt mặc định; chưa chạy trên Colab thật |
| `remoteFaceSwap` | **(Mục 250) Hoán đổi mặt theo nhân vật trên server** (insightface `buffalo_l` + `inswapper_128`): ở bước Phóng to/Hậu kỳ, app tính hộp đầu từng người từ khung xương, server ghép với mặt dò được rồi dán danh tính từ ảnh neo. Cần Remote GPU bật, `app.py` bản mới và `--inswapper-path` (tự tải `inswapper_128.onnx`). **⚠ GIẤY PHÉP PHI THƯƠNG MẠI**: dùng cho dự án cá nhân thì được, không dùng kết quả cho sản phẩm thương mại khi chưa kiểm tra điều khoản. Chỉ dùng cho nhân vật hư cấu của bạn. **(Mục 251) Có bảo vệ biểu cảm/tỉ lệ**: server đo biểu cảm (mắt/miệng/lông mày) trước–sau bằng landmark; lệch thì khôi phục miệng/mắt gốc, vẫn lệch thì HOÀN NGUYÊN mặt đó; mặt quay > 55° bị bỏ qua; kích thước/vị trí mặt không được đổi; cảnh báo nếu tỉ lệ mặt/vai bất thường (đầu to/nhỏ so với thân). Kết quả hiện ở log và lý do của badge (hoàn nguyên → panel cần xem lại). Ngưỡng chưa hiệu chỉnh. Mặt nhỏ/bị che có thể không dò được (bỏ qua) | Mặc định tắt; chưa chạy với server thật |
| `remoteHandFix` | **(Mục 250) Sửa tay (HandRefiner) trên server**: MeshGraphormer tìm tay → vẽ lại vùng tay bằng SD1.5 + ControlNet depth-hand (`hr16/ControlNet-HandRefiner-pruned`, Apache-2.0), dán lại có làm mờ biên; không thấy tay thì giữ nguyên ảnh. Cần model nền SD1.5 trên server. Tay quá to/biến dạng nặng vẫn có thể hỏng | Mặc định tắt; chưa chạy với server thật |
| `remoteKontext` | **(Mục 250) Chỉnh danh tính bằng FLUX Kontext trên server (thử nghiệm)**: ghép ảnh cảnh + ảnh neo, yêu cầu giữ mặt/danh tính như ảnh neo; CHỈ panel có đúng 1 nhân vật có ảnh neo. **⚠ GIẤY PHÉP PHI THƯƠNG MẠI** (FLUX.1 Kontext [dev], cần chấp nhận điều khoản trên Hugging Face). Mô hình 12 tỷ tham số nạp 4-bit; rất nặng và chậm trên GPU nhỏ; chất lượng giữ danh tính theo kiểu ghép ảnh chưa được kiểm chứng | Mặc định tắt; chưa chạy với server thật |
| `remoteInteractLayout` | **(Mục 251) Bố cục tương tác (InteractDiffusion, thử nghiệm)** — chạy ở bước SINH ẢNH, panel đúng 2 nhân vật có hành động ôm/hôn/đánh: server dựng ảnh bố cục, app trích khung xương hai người (YOLOv8-pose) rồi vẽ ảnh cuối bằng checkpoint/LoRA/IP-Adapter của bạn (ảnh bố cục bị bỏ). Server nạp model bằng `trust_remote_code` (chạy mã tải về — nên ghim `--interact-revision`); giấy phép BSD theo trang Hugging Face. YOLO có thể không dò đủ 2 người khi ôm sát (khi đó dùng khung xương mẫu); khung xương dò được không có z và bỏ qua tỉ lệ cơ thể từng nhân vật; sinh lại 1 panel dùng layout đã lưu nhưng không tạo mới | Mặc định tắt; chưa chạy với server thật |
| `exportWebtoonZip` / `exportMetadataJson` | ZIP dải dọc Webtoon (rộng 800px, mỗi ảnh cao tối đa 1280px, ≤2MB) / file JSON metadata (mục 233) | Mặc định TẮT |
| `exportKenBurnsVideo` + `exportVideoSeconds` | Video MP4 zoom/trượt từng panel, không có tiếng (mục 234) | THỬ NGHIỆM, mặc định TẮT; chưa chạy trên máy thật |
| `checkObjectScale` | Ghi log khi tỉ lệ vật thể/người lệch hơn 20% giữa các panel cùng cảnh; chỉ có tác dụng với panel có khai hộp vật thể (mục 235) | Mặc định BẬT |
| `industrialBatchUpscaleMode` | 4 giai đoạn tuần tự, giải phóng RAM giữa mỗi giai đoạn | Bật cho máy 6-8GB RAM |
| `slidingWindowSize`/kế thừa seed | Panel gần nhau dùng chung ngữ cảnh sinh ảnh (thuật toán A-B-A) | Tăng nếu muốn phong cách nhất quán hơn giữa các panel liên tiếp |
| `nThreadsAutoDetect` | Tự dò số luồng CPU tối ưu theo chip | Tắt + tự chỉnh tay nếu máy có hành vi lạ với auto-detect |
| `enable_qnn`/NPU | Chạy UNet trên NPU thay CPU/GPU (nhanh hơn nhiều nếu có) | Chỉ có tác dụng nếu tự build bản QNN — xem `HUONG_DAN_NPU_QNN.md` |
| Kích thước ảnh gốc (chip 384/512/640/768, hoặc nút ★ riêng) | Tỷ lệ khung ảnh sinh ra | **(Mới, mục 161 đợt 5-7)** Nút ★ khác vuông (VD 768x512) CHỈ hiện nếu checkpoint đang chọn có khai `default_width≠default_height` trong `model_manifest.json` — nghĩa là PHẢI tự convert model theo đúng profile đó trước (xem `prepare_models.yml`), KHÔNG phải chọn xong là có ảnh khổ ngang ngay với model SD1.5 vuông mặc định. **CHƯA build-test** — đây là thay đổi native mới, cần build CI thật xác nhận trước khi tin cậy dùng thật (xem `TECHNICAL_STATUS.md` mục 161 đợt 7). |

---

## 8. Xử lý sự cố thường gặp

- **"Chưa chọn SD Model"/"Chưa chọn LLM Model"** — vào Settings kiểm tra
  `modelStatus()`, model chưa import hoặc chưa được `rescanModels()`
  nhận diện đúng.
- **Huỷ sinh ảnh mà lâu không phản hồi** — `cancelSafely()` đợi tối đa
  30 giây trước khi báo "có thể đang treo ở tầng native" — đây là giới
  hạn thật đã biết (không ép giải phóng bộ nhớ giữa chừng để tránh crash
  nguy hiểm hơn), xem `TECHNICAL_STATUS.md` mục 10.
- **2 nhân vật trong 1 panel bị lẫn mặt nhau** — app đã tự chọn 1 trong
  5 pipeline nhiều-nhân-vật nếu model tương ứng có sẵn (mục 3.5) hoặc
  convert LoRA ghép cặp (mục 3); nếu KHÔNG có model nào trong 5 loại đó,
  đây là hành vi mặc định đã biết (chỉ 1 người được giữ mặt/panel).
- **Panel bị dừng giữa batch dài** — mở lại đúng truyện, dán lại đúng
  văn bản gốc, app tự hỏi resume (mục 5 ở trên).
- **App bị Android tự tắt khi chạy nền lâu** — Chế độ Công nghiệp chạy
  Foreground Service + WakeLock, nhưng vẫn có thể bị hệ điều hành can
  thiệp trên 1 số dòng máy/bản Android — mở lại app, dùng checkpoint để
  tiếp tục thay vì lo mất tiến độ.

---

## 9. Về tính chính xác của tài liệu này

Viết bằng cách đọc trực tiếp `MainActivity.kt` (route thật),
`MainViewModel.kt` (tên hàm/tham số thật), và các file `ui/*.kt` tương
ứng — không suy đoán tên hàm/luồng. Tuy nhiên (nhắc lại mục 0 của
`TECHNICAL_STATUS.md`): **toàn bộ hành vi mô tả ở đây là hành vi THIẾT KẾ
theo code, chưa có xác nhận chạy đúng trên thiết bị thật** — một số chi
tiết (thời gian chờ thực tế, thông báo lỗi chính xác, độ mượt UI) có thể
khác khi build-test thật lần đầu.

**Cập nhật gần nhất (TECHNICAL_STATUS.md mục 161, đợt 1-12)**: đối chiếu
lại tài liệu với toàn bộ thay đổi lớn của đợt audit PDF ngoài (mục
146/161) — đã cập nhật: mục 2 (tải model tự động, tuỳ chọn), Bước 2
(phiên bản ngoại hình nhân vật theo chương), Bước 8 (dọn dẹp file trung
gian sau xuất bản), mục 5 (cách ly lỗi native cho bước sinh ảnh — CHƯA
build-test), mục 7 (chọn tỷ lệ khung ảnh không vuông — CHƯA build-test).
**Build CI (`build.yml`) đã pass lần đầu tiên với TOÀN BỘ 12 đợt thay đổi
này** (biên dịch sạch — Kotlin + native C++ + Python export scripts) —
nhưng đây CHỈ xác nhận cú pháp/kiểu dữ liệu đúng, KHÔNG xác nhận hành vi
lúc chạy thật (ảnh tỷ lệ không vuông có đúng không, cơ chế đa tiến trình
có hoạt động đúng không) — vẫn cần cài APK lên máy thật kiểm tra trước
khi tin cậy các mục đánh dấu "CHƯA build-test" ở trên.

Các bước KHÔNG đổi (Bước 1, 3-7 phần lõi, mục 3-4, 6, 8) vẫn khớp
nguyên trạng so với lần rà soát trước, không cần sửa gì thêm.

**Cập nhật tiếp theo (TECHNICAL_STATUS.md mục 175-176, đợt 21-22)**: mục
3.5 hoàn toàn MỚI (5 pipeline nhiều-nhân-vật mask/regional/regional-mask/
triple-combo + biến thể depth — trước đây CHƯA từng được viết vào tài
liệu này dù code đã có từ lâu, xem mục 176 để rõ vì sao gap này lọt qua
lần rà soát trước). Sửa lại câu SDXL ở mục 2 và mục 6 (thêm phân biệt rõ
SDXL chạy Local — chỉ cơ bản — với SDXL qua GPU thuê ngoài — có ControlNet
+ IP-Adapter nhưng không LoRA/không multi-character). Thêm dòng
`useStoryDiffusion` vào bảng mục 7. Mục Help rút gọn trong app
(`HelpScreen.kt`) cũng đã cập nhật tương ứng.

**Cập nhật tiếp theo (TECHNICAL_STATUS.md mục 177-183, đợt audit độc lập
mới)**: từ mục 177-181, SDXL đã được viết thêm 5 pipeline augmented/mask/
regional/regional-mask/depth ở TẦNG CODE (Phase 2). Mục 183: đợt audit
toàn diện, không tìm thêm lệch pha nào khác trong phạm vi đã rà (xem chi
tiết trong `TECHNICAL_STATUS.md`).

**Cập nhật tiếp theo nữa (mục 184)**: Phase 3 (dispatch thật + UI) NAY ĐÃ
NỐI — trước đó câu ở mục 2 nói "với người dùng, hành vi SDXL Local vẫn y
hệt trước đó (chỉ sinh ảnh cơ bản)" vì Phase 3 chưa làm; giờ KHÔNG còn
đúng — SDXL đã bật được thật qua Cài đặt (thẻ "SDXL (thử nghiệm)"). Đã
sửa lại câu ở mục 2 cho khớp. TOÀN BỘ đường SDXL (Phase 2 lẫn Phase 3)
vẫn CHƯA build-test lần nào — mức rủi ro khi bật thử cao hơn hẳn SD1.5.

**Cập nhật tiếp theo nữa (mục 185-202, cộng dồn nhiều đợt, đóng ở mục
203)**: tài liệu này từng dừng lại ở mục 184 suốt 18 mục sau đó — 1 đợt
audit độc lập mới (mục 203) phát hiện gap này rồi vá lại. Đã bổ sung vào
Bước 6 ở trên: badge cảnh báo Quality Gate + phương án SDXL thay thế khi
sinh hàng loạt (mục 185), ô chọn model tier riêng theo panel (mục 188),
ô sửa tay biểu cảm riêng từng nhân vật panel đông người (mục 196/197).
Đã bổ sung vào mục 2: cơ chế tự phát hiện marker độ phân giải SDXL thật
(mục 192/193) + cảnh báo về việc giữ `prepare_models.yml` lệch bản (mục
203 tìm thấy đúng lỗi này đang xảy ra thật ở lần upload đó). Các mục còn
lại trong khoảng 185-202 (thiết kế lại thứ tự Quality Gate — mục 187, 2
bug `regeneratePanel()` bỏ sót Cascade/auto-fix — mục 198/199, mask bao
lồi thay hình chữ nhật — mục 201/202) là thay đổi nội bộ không đổi luồng
thao tác của người dùng, không cần thêm mục riêng ở tài liệu này — xem
`TECHNICAL_STATUS.md` nếu cần chi tiết kỹ thuật.

**Cập nhật tiếp theo nữa (mục 204)**: ô chọn thư mục model SDXL ở mục 2
giờ có dropdown quét sẵn (trước đó chỉ gõ tay) — đã sửa câu mục 2 cho
khớp, chi tiết kỹ thuật xem `TECHNICAL_STATUS.md` mục 204. Đúng như mọi
thay đổi khác, phần này CHƯA build-test (sandbox không có
javac/kotlinc/gradle để compile-check thật) — chỉ tự rà bằng cách đếm
ngoặc + đọc lại tay, không thay được build thật.

**Cập nhật tiếp theo nữa (mục 205-207)**: SDXL giờ có Quality Gate (mục
205) VÀ auto-fix giao thoa (mục 207) — đã sửa câu mục 2 cho khớp. Mục
207 là thay đổi C++ thật (không chỉ Kotlin/text như các mục trước) —
CHƯA build-test, rủi ro cao hơn hẳn: sai sót có thể sinh ảnh sai mà
không crash, chỉ lộ ra khi tự xem ảnh thật. Multi-Pass Cascade riêng cho
SDXL (tính năng SÂU HƠN auto-fix giao thoa) vẫn chưa làm — chi tiết kỹ
thuật đầy đủ xem `TECHNICAL_STATUS.md` mục 205/207.

**Cập nhật tiếp theo nữa (mục 213/214 — SAU BUILD THÀNH CÔNG LẦN ĐẦU)**:
- **Sao lưu/khôi phục truyện (mục 213, mới)**: màn danh sách truyện có
  nút "Khôi phục từ file" (toolbar + màn trống) để nhập lại 1 truyện đã
  sao lưu — dùng khi cài lại app/đổi máy. Ở màn chi tiết 1 truyện, menu
  3 chấm có "Sao lưu truyện" (xuất ra 1 file `.zip` qua hộp thoại chia
  sẻ — chọn lưu Drive/Files tuỳ ý) và "Xoá truyện" (có xác nhận). Lưu ý:
  khôi phục 1 truyện TRÙNG với truyện đã có trên máy sẽ bị từ chối (an
  toàn, tránh ghi đè nhầm) — xoá truyện cũ trước nếu muốn khôi phục đè.
- **Mục "🦴 Pose" trong Cài đặt giờ bấm được** (mục 214) — bấm vào dòng
  đó (trong khối "stack kỹ thuật") mở thẳng màn vẽ/sửa/trích tư thế,
  tương đương nút "Vẽ / sửa khung xương tư thế" đã có. 9 dòng còn lại
  trong khối đó (LLM/SD 1.5/StoryDiffusion/Auto-fix/Mask thủ công/
  Upscale/Auto Bubble/Thermal/Export) vẫn CHỈ là mô tả kỹ thuật, không
  bấm được — không có màn riêng nào để trỏ tới.
- Cả 2 đều CHƯA build-test — chi tiết kỹ thuật đầy đủ xem
  `TECHNICAL_STATUS.md` mục 213/214.
