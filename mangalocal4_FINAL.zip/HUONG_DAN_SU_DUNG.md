# MangaLocal — Hướng dẫn sử dụng & luồng quy trình hoạt động

> Tài liệu này mô tả **luồng thật trong code** (`MainActivity.kt` NavHost,
> `MainViewModel.kt`, các file `ui/*.kt`) — không phải mô tả lý tưởng hoá.
> Mọi tên hàm/route nhắc tới đều tồn tại thật trong source, đối chiếu
> trực tiếp lúc viết tài liệu này. Nhắc lại điều quan trọng nhất từ
> `TECHNICAL_STATUS.md` mục 0: **toàn bộ app CHƯA từng build-test/chạy
> thật lần nào** — tài liệu này mô tả app sẽ hoạt động NHƯ THẾ NÀO theo
> đúng thiết kế code, không phải xác nhận đã chạy đúng trên máy thật.

---

## 1. Tổng quan — MangaLocal là gì

Ứng dụng Android sinh truyện tranh (manga/manhwa) từ văn bản, chạy
**local-first** (mọi model AI chạy ngay trên điện thoại, không bắt buộc
mạng) — có tuỳ chọn định tuyến một phần công việc sang GPU thuê ngoài
(Colab/RunPod/Vast.ai) nếu muốn nhanh hơn hoặc máy yếu.

Input: văn bản truyện (dán tay hoặc dán JSON kịch bản đã chia scene sẵn
từ LLM ngoài app). Output: chuỗi ảnh panel truyện tranh có bubble thoại,
xuất ra PDF và/hoặc CBZ.

---

## 2. Chuẩn bị trước khi dùng lần đầu — model bắt buộc

App **không tự tải model qua mạng lúc chạy** (bảo mật offline) — phải tự
nạp model tĩnh vào máy trước. Vào màn **Cài đặt** (`settings`) để:

1. **LLM model** (bắt buộc) — dùng để đọc hiểu văn bản truyện, chia
   scene, viết prompt. Import qua nút trong Settings (`importLlmModels()`).
2. **SD model** (bắt buộc) — model sinh ảnh chính (SD1.5 hoặc SDXL).
   `rescanModels()` tự quét thư mục model đã copy vào máy (qua
   Google Drive/Files app...), khớp với `model_manifest.json`.
3. **LoRA** (tuỳ chọn, cho nhân vật cần giữ mặt) — import qua
   `importLoras()`.
4. **YOLO model** (bubble detect + pose) — `importYoloModels()`.
5. **ESRGAN model** (upscale) — `importEsrganModels()`.

`modelSetupGuide()`/`modelStatus()` trong ViewModel cho biết còn thiếu
model nào — Settings hiện trực tiếp trạng thái này.

**Máy yếu (dưới 8GB RAM)**: bật "Chế độ 4 Giai đoạn Công nghiệp"
(`industrialBatchUpscaleMode`) trong Settings — SD/ESRGAN/YOLO/SAM được
nạp và giải phóng tuần tự thay vì giữ tất cả cùng lúc trong RAM.

---

## 3. Luồng chính — từ văn bản tới ảnh truyện tranh

```
StoryListScreen ─▶ StoryDetailScreen ─▶ [CharacterSummaryReviewScreen] ─▶ [RoutingReviewScreen] ─▶ GeneratingScreen
   (stories)         (story_detail)      (chỉ khi có nhân vật mới)          (routing_review)        (generating)
                                                                                                            │
                                                                                                            ▼
   PostProcessingScreen ◀── proceedToUpscale() ◀── GalleryReviewScreen (gallery_review)
   (post_processing)                                    (duyệt từng panel)
          │
          ▼
   Export PDF/CBZ
```

### Bước 1 — Tạo truyện (`StoryListScreen` → `StoryDetailScreen`)

`createStory(title, description, style, worldRules, promptGuideNotes)` —
chọn phong cách ảnh (checkpoint anime/manga hay cinematic — quyết định
`PromptStyle` LLM dùng để viết prompt, xem `TECHNICAL_STATUS.md` mục 7).
`worldRules`/`promptGuideNotes` là ghi chú tự do user viết thêm, LLM đọc
kèm khi viết kịch bản.

### Bước 2 — Tạo nhân vật (`CharactersDetailScreen`)

`addCharacter(name, anchor, neg, role, loraPath, seed)` — mỗi nhân vật
chọn 1 **vai trò** (`CharacterRole`): `MAIN` (vai chính, xuất hiện nhiều
— nên dùng LoRA cho giống mặt nhất), `SUPPORTING` (vai phụ — gợi ý
IP-Adapter, nhẹ hơn LoRA), `ONETIME` (xuất hiện 1 lần — thường không cần
giữ nhất quán).

Chọn 1 trong 4 **phương pháp giữ nhất quán khuôn mặt**
(`ConsistencyMethod`): `LORA` (giống mặt nhất, cần convert trước —
`convertCharacterLora()`), `IP_ADAPTER` (dùng 1 ảnh neo, không cần
convert — `setCharacterAnchorImage()`), `TEXTUAL_INVERSION` (nhẹ nhất,
`setCharacterEmbeddingFromSource()`/`...FromUri()`), hoặc `NONE`.

2 nhân vật cùng xuất hiện chung nhiều panel? Cân nhắc convert GHÉP CẶP
(`convertCharacterPair()`) — 1 checkpoint chứa cả 2 LoRA, giảm rò rỉ đặc
điểm giữa 2 người (kỹ thuật Orthogonal LoRA, xem `TECHNICAL_STATUS.md`
mục 3).

Muốn xem trước ảnh neo/LoRA cho ra mặt nhân vật thế nào trước khi dùng
thật? `generateAnchorCandidates()` sinh vài ảnh ứng viên,
`approveAnchorCandidate()` chọn 1 ảnh làm chính thức.

(Tuỳ chọn) **Quan hệ gia đình** (`FamilyRelationshipScreen`, route
`family`) — khai báo quan hệ giữa các nhân vật (cha/mẹ/con/anh em...) để
LLM viết kịch bản nhất quán về xưng hô/tương tác.

### Bước 3 — Dán văn bản truyện (`StoryDetailScreen`)

2 cách đưa nội dung vào:
- **Dán văn bản thô** — gõ/dán trực tiếp, `analyzeStoryText()` tự đếm số
  chương phát hiện được (theo `TextChunker.split()`). Nếu vượt ngưỡng
  (`TextChunker.INDUSTRIAL_SUGGEST_THRESHOLD`), app hỏi có muốn chạy
  **Chế độ Công nghiệp** không (xem mục 5 bên dưới) thay vì làm tay từng
  chương.
- **Dán JSON kịch bản ngoài** (`prepareChapterFromExternalScript()`) —
  nếu đã tự dùng LLM khác (ChatGPT/Gemini...) chia scene sẵn theo đúng
  format `ExternalScriptImport.kt` quy định. Vẫn cần LLM on-device (chỉ
  để dịch prompt sang tag SD, không parse lại kịch bản).

Cả 2 cách đều gọi `analyzeCharactersFirst()`/`prepareChapterFromExternalScript()`
— **KHÔNG viết kịch bản chi tiết ngay** (mục 154 TECHNICAL_STATUS.md,
"đảo pipeline nhân vật"). Xem Bước 3.5 ngay dưới.

### Bước 3.5 — Xác nhận nhân vật mới (`CharacterSummaryReviewScreen`, chỉ hiện khi cần)

`analyzeCharactersFirst()` chạy 1 lượt LLM RẺ (không chia panel, chỉ đọc
tên + đoán vai trò + tóm 1 câu) TRƯỚC khi viết kịch bản chi tiết. **Chỉ
dừng lại xin xác nhận nếu phát hiện nhân vật MỚI** (chưa có trong
`story.characters`) — chương 2 trở đi (mọi nhân vật đã biết) tự động bỏ
qua bước này, chảy thẳng sang Bước 4 như đường dán JSON.

Nếu có nhân vật mới, màn `CharacterSummaryReviewScreen` hiện ra (thiết kế
mobile: 1 card/nhân vật cuộn dọc, chip to cho vai trò, nút xác nhận ghim
cố định ở đáy màn hình):
- Sửa vai trò (Chính/Phụ/Một lần) nếu AI đoán sai.
- Đánh dấu **"Cần giữ mặt nhất quán qua nhiều khung ảnh?"** (Có/Không) —
  CHỈ dùng làm gợi ý TẠM cho LLM viết kịch bản né ghép chung panel những
  người cần tách riêng — KHÔNG tự động set LoRA/IP-Adapter thật (vẫn phải
  tự làm ở Bước 2 như bình thường, đây chỉ là gợi ý sớm giúp bố cục panel
  hợp lý hơn ngay từ đầu).
- Xoá (nút ✕) nếu AI nhận nhầm tên không phải nhân vật.
- **"Xác nhận → Viết kịch bản"** (chính) hoặc **"Dùng gợi ý mặc định,
  viết luôn"** (bỏ qua chỉnh sửa, chấp nhận nguyên văn AI đoán) hoặc
  **"Huỷ"** (quay lại ô dán văn bản, không tạo gì).

Sau khi xác nhận, `confirmCharacterSummaryAndProceed()` tạo `Character`
mới cho từng người (role đã chọn, mô tả AI tóm làm anchor prompt tạm —
nên vào Bước 2 viết lại chi tiết hơn sau) rồi MỚI gọi `prepareChapter()`
thật — kết quả vào `_pendingChapter` (CHƯA sinh ảnh, chỉ mới có kịch bản
+ prompt).

### Bước 4 — Duyệt định tuyến Local/Remote (`RoutingReviewScreen`, tuỳ chọn)

Chỉ có ý nghĩa nếu đã cấu hình GPU thuê ngoài (xem mục 6). Màn này cho
xem trước panel nào sẽ chạy Local (điện thoại), panel nào chạy Remote
(GPU cloud) — theo `RoutingMode.MANUAL` (rule tự đặt) hoặc `AUTO` (LLM tự
quyết theo mô tả tiếng Việt tự do user viết trong Settings). Có thể sửa
tay từng panel qua `setBatchBackend()` trước khi xác nhận. Không cấu hình
Remote → mọi panel mặc định Local, có thể bỏ qua màn này.

### Bước 5 — Sinh ảnh (`GeneratingScreen`)

`confirmRoutingAndGenerate()` → `pipeline.runGeneration()` — chạy UNet
thật cho từng panel (chọn đúng pipeline theo số nhân vật/có cần
Depth/Regional Prompting hay không, xem `TECHNICAL_STATUS.md` mục 3).
Có thể `cancelGeneration()` giữa chừng (cờ interrupt JNI dừng ở step kế
tiếp, xem mục 10 — không dừng ngay lập tức tuyệt đối).

### Bước 6 — Duyệt từng panel (`GalleryReviewScreen`)

Với mỗi panel đã sinh, chọn 1 trong các hành động:
- **Duyệt** (`approvePanel()`) — panel đạt yêu cầu, chuyển trạng thái
  `APPROVED`.
- **Sinh lại** (`regeneratePanel()`) — không ưng ý, chạy lại (có thể sửa
  prompt tay hoặc chỉnh override riêng panel đó).
- **Sửa tay 1 vùng lỗi** (`manualMaskFixPanel()`) — chấm tay vào điểm
  lỗi (vd tay biến dạng), app tự vẽ mask quanh đó rồi img2img sửa riêng
  vùng đó (không sinh lại cả panel).
- **Import ảnh ngoài thay hẳn panel này** (`importPanelImage()`) — có sẵn
  ảnh vẽ tay/lấy nguồn khác, bỏ qua AI sinh hoàn toàn cho panel đó (xem
  `TECHNICAL_STATUS.md` mục 12).
- **Sửa tư thế tay** (`pose_editor`) — mở `PoseEditorScreen`, kéo/chỉnh
  khớp xương panel đó trước khi sinh lại (pinch-to-zoom hỗ trợ chỉnh chi
  tiết trên màn nhỏ).

### Bước 7 — Hậu kỳ (`PostProcessingScreen`)

`proceedToUpscale()` — chạy ESRGAN nâng độ phân giải + Ultrafix (vẽ lại
nhẹ toàn ảnh) + auto-fix mặt/tay cho mọi panel đã `APPROVED`. Sau đó
`runAutoBubble()` — tự đặt bubble thoại (YOLO detect bóng thoại trống,
đặt chữ theo thoại đã sinh). Có thể sửa tay vị trí/nội dung bubble từng
panel (`updatePanelBubbles()`) trước khi xuất.

### Bước 8 — Xuất file

`exportChapter(exportPdf, exportCbz, destUri)` — xuất PDF và/hoặc CBZ (2
định dạng độc lập, chọn 1 hoặc cả 2). Mặc định lưu vào thư mục nội bộ app
(`storyManager.outputDir()`); nếu chọn `destUri` (qua trình chọn thư mục
hệ thống), file được copy thêm ra vị trí đó (vd thư mục chia sẻ Google
Drive) — không thay thế bản nội bộ.

---

## 4. Vòng lặp nhiều chương

`selectChapter()` chuyển qua lại giữa các chương đã lưu của cùng truyện.
Mỗi chương độc lập — lặp lại Bước 3→8 cho chương tiếp theo. Ảnh nhân vật
neo (LoRA/IP-Adapter/Textual Inversion) dùng CHUNG cho mọi chương của
cùng truyện, không cần cấu hình lại.

---

## 5. Chế độ Công nghiệp — sinh hàng loạt nhiều chương liên tiếp

Dùng khi có sẵn TOÀN BỘ truyện dài (hàng chục/hàng trăm chương) và muốn
chạy xuyên đêm không cần ngồi duyệt routing từng chương.

`analyzeStoryText()` tự gợi ý chế độ này nếu phát hiện đủ số chương.
`runIndustrialBatch(chapters)` chạy tuần tự: mỗi chương tự
`prepareChapter()` rồi `runGeneration()` NGAY (không dừng chờ duyệt
routing như luồng thủ công) — vẫn qua đúng `BackendRouter` tự động.

**An toàn cho batch dài**: mỗi chương lỗi (văn bản dị dạng, ảnh hỏng...)
CHỈ bị bỏ qua (ghi log), KHÔNG làm chết cả batch (error shunning, xem
`TECHNICAL_STATUS.md` mục 10). Nếu app bị hệ điều hành giết giữa batch
dài (RAM/pin/nhiệt), lần mở app sau `peekResumableBatch()` phát hiện có
batch dở dang của đúng truyện đang mở — dán lại ĐÚNG văn bản cũ,
`runIndustrialBatch()` tự nhận ra (so khớp hash) và resume đúng chỗ dở
dang, không sinh lại từ đầu. `cancelIndustrialBatch()` dừng tay giữa
chừng bất kỳ lúc nào.

Sau khi batch chạy xong, vẫn cần vào từng chương để duyệt panel (Bước
6-8) như luồng thủ công — Chế độ Công nghiệp chỉ tự động hoá bước SINH
ẢNH hàng loạt, không tự động hoá bước duyệt/hậu kỳ/xuất file.

---

## 6. GPU thuê ngoài (tuỳ chọn — máy yếu hoặc muốn nhanh hơn)

Không bắt buộc — bỏ qua mục này nếu chỉ chạy Local. Cần khi máy quá yếu
để chạy SD local ở tốc độ chấp nhận được, hoặc muốn dùng SDXL (nặng hơn
SD1.5 nhiều).

1. Chạy `tools/remote_server/app.py` trên máy có GPU (Colab miễn phí là
   lựa chọn dễ nhất — dùng notebook đính kèm, Cloudflare Tunnel tự lộ ra
   Internet không cần đăng ký).
2. Nhập địa chỉ server vào Settings — app tự xác thực bằng cặp khoá
   RSA-OAEP + fingerprint TOFU (tự sinh lúc đầu, cảnh báo nếu fingerprint
   đổi ở lần kết nối sau — dấu hiệu server đã đổi, không tự động tin).
3. Chọn `RoutingMode`: `MANUAL` (tự đặt rule — vd "panel có ≥3 nhân vật
   → Remote") hoặc `AUTO` (viết mô tả tiêu chí bằng tiếng Việt tự nhiên,
   LLM on-device tự áp dụng).
4. `RoutingReviewScreen` (Bước 4 ở trên) hiện ra để duyệt/sửa tay trước
   khi sinh — LUÔN có bước duyệt này khi có panel định tuyến Remote,
   không tự động chạy thẳng.

**Giới hạn bảo mật thật** (đọc kỹ trước khi dùng GPU thuê ngoài — không
phải chỉ cảnh báo hình thức): mã hoá RSA+AES chỉ chống người thứ 3 nghe
lén trên đường truyền mạng — **không chống được chính chủ máy chủ GPU**
(họ có quyền truy cập VM đang chạy prompt/ảnh của bạn dạng plaintext lúc
xử lý). Chỉ dùng Remote cho nội dung sẵn sàng để lộ cho chủ hạ tầng thuê
thấy. Xem `TECHNICAL_STATUS.md` mục 9/14 để hiểu đầy đủ.

---

## 7. Cài đặt quan trọng cần biết (Settings)

| Cài đặt | Ý nghĩa | Khi nào chỉnh |
|---|---|---|
| `enableQualityGate` | YOLO tự đếm chi, auto-sinh lại nếu sai (chỉ nhánh 1-nhân-vật) | Bật nếu hay gặp lỗi giải phẫu tay/chân |
| `consistencyStrength` (Smooth Timestep Decay) | Ảnh hưởng ảnh neo IP-Adapter giảm dần cuối quá trình sinh | Giảm nếu mặt quá cứng/không theo biểu cảm LLM viết |
| `useUltrafixRedraw` | Vẽ lại nhẹ toàn ảnh sau upscale trước khi auto-fix | Bật nếu ảnh sau upscale bị mờ/nhiễu |
| Multi-Pass Inpainting Cascade | 3-4 lượt sửa mặt/tay giảm dần cường độ | Mặc định bật — tắt nếu muốn nhanh hơn, chấp nhận kém chính xác hơn cảnh đông người |
| `industrialBatchUpscaleMode` | 4 giai đoạn tuần tự, giải phóng RAM giữa mỗi giai đoạn | Bật cho máy 6-8GB RAM |
| `slidingWindowSize`/kế thừa seed | Panel gần nhau dùng chung ngữ cảnh sinh ảnh (thuật toán A-B-A) | Tăng nếu muốn phong cách nhất quán hơn giữa các panel liên tiếp |
| `nThreadsAutoDetect` | Tự dò số luồng CPU tối ưu theo chip | Tắt + tự chỉnh tay nếu máy có hành vi lạ với auto-detect |
| `enable_qnn`/NPU | Chạy UNet trên NPU thay CPU/GPU (nhanh hơn nhiều nếu có) | Chỉ có tác dụng nếu tự build bản QNN — xem `HUONG_DAN_NPU_QNN.md` |

---

## 8. Xử lý sự cố thường gặp

- **"Chưa chọn SD Model"/"Chưa chọn LLM Model"** — vào Settings kiểm tra
  `modelStatus()`, model chưa import hoặc chưa được `rescanModels()`
  nhận diện đúng.
- **Huỷ sinh ảnh mà lâu không phản hồi** — `cancelSafely()` đợi tối đa
  30 giây trước khi báo "có thể đang treo ở tầng native" — đây là giới
  hạn thật đã biết (không ép giải phóng bộ nhớ giữa chừng để tránh crash
  nguy hiểm hơn), xem `TECHNICAL_STATUS.md` mục 10.
- **2 nhân vật trong 1 panel bị lẫn mặt nhau** — dùng Regional Prompting
  hoặc convert LoRA ghép cặp (mục 3 ở trên) thay vì để 2 LoRA độc lập
  chồng lên nhau.
- **Panel bị dừng giữa batch dài** — mở lại đúng truyện, dán lại đúng
  văn bản gốc, app tự hỏi resume (mục 5 ở trên).
- **App bị Android tự tắt khi chạy nền lâu** — Chế độ Công nghiệp chạy
  Foreground Service + WakeLock, nhưng vẫn có thể bị hệ điều hành can
  thiệp trên 1 số dòng máy/bản Android — mở lại app, dùng checkpoint để
  tiếp tục thay vì lo mất tiến độ.

---

## 9. Về tính chính xác của tài liệu này

Viết bằng cách đọc trực tiếp `MainActivity.kt` (route thật),
`MainViewModel.kt` (tên hàm/tham số thật), và các file `ui/*.kt` tương
ứng — không suy đoán tên hàm/luồng. Tuy nhiên (nhắc lại mục 0 của
`TECHNICAL_STATUS.md`): **toàn bộ hành vi mô tả ở đây là hành vi THIẾT KẾ
theo code, chưa có xác nhận chạy đúng trên thiết bị thật** — một số chi
tiết (thời gian chờ thực tế, thông báo lỗi chính xác, độ mượt UI) có thể
khác khi build-test thật lần đầu.

**Cập nhật gần nhất**: đối chiếu lại toàn bộ tên hàm nhắc trong tài liệu
này với code hiện tại (grep từng hàm một) — chỉ có Bước 3 (nút "Sinh
panel" đổi sang gọi `analyzeCharactersFirst()` từ mục 154) bị lệch, đã
sửa + thêm Bước 3.5 mới. Mọi hàm khác (Bước 4-8, mục 4-8) vẫn khớp
nguyên trạng, không đổi.
