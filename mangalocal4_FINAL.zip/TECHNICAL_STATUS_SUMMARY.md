# MangaLocal — Trạng thái kỹ thuật (bản tóm tắt theo hệ thống con)

> **Bản NGẮN, đọc nhanh** — tổ chức theo hệ thống con, cắt lược phần
> tường thuật "lần 1 sai → lần 2 sửa" xuống còn trạng thái CUỐI CÙNG.
> **Nếu cần KHÔNG mất bất kỳ chi tiết nào (mọi quyết định, mọi bug, mọi
> nghiên cứu, đúng thứ tự thời gian) — đọc `TECHNICAL_STATUS.md` thay vì
> file này.** File đó giữ nguyên toàn bộ 145 mục gốc, chỉ dọn đúng phần
> chữ lặp lại y hệt (~0.3% dung lượng — số đo thật, xem ghi chú đầu file
> đó). File này là bản tóm tắt PHỤ, giúp đọc nhanh, không phải bản thay
> thế duy nhất.

> ✅ **CẬP NHẬT (mục 203 `TECHNICAL_STATUS.md`)** — bản này đã viết tiếp
> mục 41-67, phủ đến mục 203 của bản đầy đủ (2 file workflow ngoài zip
> từng lệch nghiêm trọng nay đã vá, SDXL Phase 2a-2f + Phase 3 nối
> dispatch/UI đầy đủ theo panel, quy trình SDXL-thay-thế khi SD1.5 không
> đạt Quality Gate, THIẾT KẾ LẠI Quality Gate đánh giá khung xương TRƯỚC
> khi sinh, tùy chọn độ phân giải SDXL 768/1024 kèm marker file + suy
> luận logic cho model cũ thiếu marker — chỉ còn đúng 1 trường hợp biên
> hiếm chưa giải quyết được, và vá 4 docstring lỗi thời còn sót; đợt audit
> độc lập mới nhất — mục 203 — tìm thêm 2 gap: `prepare_models.yml` sống
> ngoài zip LẠI lệch bản (tái diễn), và `HUONG_DAN_SU_DUNG.md`/
> `HelpScreen.kt` từng dừng ở mục 184, cả 2 đã vá). Từ mục
> 204 trở đi của bản đầy đủ (nếu có),
> nếu CHƯA thấy mục tương ứng ở đây, coi là CHƯA cập nhật — đọc bản đầy
> đủ cho phần mới nhất.

---

## 0. SỰ THẬT BAO TRÙM TOÀN BỘ DỰ ÁN — đọc mục này trước mọi mục khác

> **CẬP NHẬT (mục 174 bản đầy đủ)**: đoạn dưới đây viết ở giai đoạn build
> CHƯA từng pass — nay ĐÃ pass (Build APK #97, xem mục 26/28 file này).
> Giữ nguyên văn gốc bên dưới vì vẫn đúng tinh thần cho MỌI THỨ VIẾT SAU
> điểm pass đó (mục 162 trở đi bản đầy đủ — Multi-Process Isolation, tách
> lưu trữ, Per-Character Expression, mở khoá N>4, Regional-Mask...) — tất
> cả các thứ đó CHƯA build lại lần nào kể từ #97. Đổi "chưa từng pass"
> thành CHÍNH XÁC hơn: **"đã pass ĐÚNG 1 lần, tại 1 mốc code cũ hơn nhiều
> so với hiện tại — không có nghĩa code MỚI NHẤT cũng compile được."**

**Build CI mới pass đúng 1 lần trong lịch sử dự án (Build APK #97, ở mốc
code cũ) — mọi dòng code viết SAU mốc đó chưa được build lại lần nào**
(kể cả chỉ tính compile, chưa nói chạy sinh ảnh thật):
- 5 lần build CI thật đã chạy (build #34/#38/#41/#44/#47), sửa bug dựa
  trên log thật — nhưng chuỗi sửa DỪNG GIỮA CHỪNG ở build #47, chưa xác
  nhận lại.
- Sau đó, thêm 1 chuỗi build CI thật khác (#88→#91→#94→#97, mục 23/24/25/26
  file này) — build #97 PASS HOÀN TOÀN (compile) lần đầu tiên. Nhưng
  **mọi dòng code viết SAU build #97** (Multi-Process Isolation, tách lưu
  trữ, Per-Character Expression, mở khoá N>4, Regional Prompting bản
  mask, kế hoạch SDXL...) **CHƯA TỪNG qua compiler nào** — chỉ soát bằng
  đọc lại thủ công + đếm ngoặc bằng script.
- Compile pass (dù đã có 1 lần) cũng KHÁC HẲN "chạy đúng" — build #97
  CHƯA xác nhận chất lượng ảnh, shape tensor, hay hiệu năng thật trên
  máy. Không có dòng nào trong dự án từng được xác nhận bằng ẢNH THẬT
  sinh ra.

**Việc DUY NHẤT quan trọng hơn mọi tính năng khác**: build CI thật LẠI
LẦN NỮA (`build.yml`) để xác nhận toàn bộ code viết sau #97 vẫn compile
được, rồi chạy thật trên thiết bị (khuyến nghị: ASUS Zenfone 8, 16GB RAM
— máy dev chính đã xác định) để sinh ảnh thật lần đầu tiên. Đọc phần còn
lại với tinh thần: **"đã làm/đã triển khai" = "đã viết code + tra cứu API
thật, không đoán" — không phải "đã chạy đúng".**

---

## 1. Kiến trúc & stack tổng quan

| Thành phần | Engine | Trạng thái |
|---|---|---|
| LLM (parse truyện) | MNN-LLM | Port xong, fallback QNN→OpenCL→CPU runtime thật |
| SD1.5 (CPU/OpenCL) | MNN-Diffusion, port từ local-dream | Nhiều pipeline con, mục 3 |
| SDXL (CPU/OpenCL) | MNN-Diffusion, viết mới | Chỉ nền tảng txt2img, mục 3.5 |
| NPU (QNN) | MNN backend built-in (`MNN_FORWARD_NN`) | Cascade NPU→GPU→CPU đã code, mục 8 |
| Upscale | MNN (ESRGAN, 4x-UltraSharp) | Mục 4 |
| Bubble thoại | MNN (YOLOv8n) | Hoạt động |
| Nhất quán nhân vật | LoRA / IP-Adapter / Textual Inversion | Mục 5 |
| Tư thế | ControlNet-OpenPose, trích bằng YOLOv8-pose | Mục 6 |

**File jni/ chính**: `jni_bridge.cpp` (LLM), `mnn_diffusion_pipeline.cpp`
(SD1.5/SDXL cơ bản + img2img/ultrafix), `ip_adapter.cpp` (augmented:
IP-Adapter + ControlNet Pose/Depth + mask N-người), `regional_prompting.cpp`,
`esrgan_wrapper.cpp`, `yolo_wrapper.cpp`, `yolo_pose_wrapper.cpp`,
`mobile_sam_wrapper.cpp`, `sd_model_converter.cpp`, `sd_engine/` (port từ
local-dream, CC BY-NC 4.0, MangaLocal miễn phí 100%).

**2 chỗ sửa so với local-dream gốc** (bắt buộc ghi vì license):
`PipelineSd15Cpu.hpp` đổi 1 số field `private`→`protected` + hook ảo
`onBeforeUnetRun()`; `SDUtils.hpp` bỏ `STB_..._IMPLEMENTATION` (dồn vào
`stb_impl.cpp` riêng, tránh duplicate symbol).

---

## 2. Build system — lịch sử CI (rút gọn)

5 lần build CI thật, mỗi lần lộ 1 lớp lỗi mới:

1. **#29→#34**: CMake `[CXX1429]` (2 target `OBJECT` của MNN không được
   gắn `POST_BUILD`) — vá `sed` đổi `OBJECT`→`STATIC`, có `grep -q` tự
   báo lỗi nếu MNN đổi cấu trúc.
2. **#34→#38**: `xtensor/xadapt.hpp` not found (xtensor ≥0.26 đổi cấu
   trúc thư mục) — ghim cứng 4 version (`xtensor 0.25.0`/`xtl 0.7.7`/
   `xsimd 10.0.0`/`xtensor-blas 0.21.0`), verify từng header bằng
   `git show <tag>:<path>`. **MNN vẫn KHÔNG ghim version** — rủi ro
   tương tự có thể lặp lại.
3. **#38**: `SafeTensorReader.hpp` include `"json.hpp"` sai — sửa
   `#include <nlohmann/json.hpp>`.
4. **#41**: build C++ **PASS HOÀN TOÀN lần đầu** — lộ 12 lỗi Kotlin có
   sẵn: `Surface()` positional-param sai thứ tự (9 chỗ/3 file),
   `MlOutlineBtn` thiếu `enabled`, gọi nhầm hàm, dùng type đã xoá, thiếu
   `@OptIn(ExperimentalMaterial3Api)`.
5. **#44**: 7 lỗi Kotlin mới (3 file khác) — import sai vị trí, thiếu
   dấu cách gây hiểu nhầm literal suffix, thiếu `@OptIn` (không tự lan
   sang hàm `private` khác cùng file).
6. **#47**: sót 1 nửa lỗi #44 (2 khối `import` tách rời, chỉ dời 1 khối)
   — bài học: sửa 1 file phải liệt kê TOÀN BỘ vị trí liên quan trước khi
   khẳng định đã xong.

**Sau #47, chuỗi build-fix dừng lại** — mọi thay đổi từ đó tới giờ (đại
đa số dự án) chưa qua bước này lần nào.

---

## 3. Pipeline sinh ảnh SD1.5 — các biến thể

Mỗi UNet augmented là model `.mnn` RIÊNG BIỆT (không dynamic) — app chọn
đúng file theo tình huống panel.

| Model | Input đặc biệt | Dùng khi | Wiring |
|---|---|---|---|
| `unet.mnn` (base) | — | Không cần giữ nhân vật | Có |
| `unet_ipa_controlnet.mnn` | `ip_image_embeds`+`control_hint` | 1 nhân vật cần neo | Có |
| + Depth | + `depth_hint` (suy từ z-khớp xương, không cần model depth riêng) | 2+ người chồng lấn | Tự phát hiện input, tương thích ngược |
| `unet_ipa_mask_controlnet_{N}char.mnn` | N embeds + N masks (bounding-box, không phải segmentation) | N≥2 nhân vật đều cần neo | Có (`generatePanelMultiChar`) |
| Regional Prompting (`regional_prompting.cpp`, pipeline riêng) | N cột prompt CHỮ riêng (chỉ chia cột, chỉ ảnh vuông) | Tách PROMPT CHỮ theo vùng | Có (`generatePanelRegional`) |
| `unet_triple_combo_{N}region.mnn` (`triple_combo.cpp`, pipeline riêng, mục 151/152) | N prompt cột + N ảnh neo + pose_hint + depth_hint CÙNG LÚC | N≥2 nhân vật cần cả 3: giữ mặt + tách prompt + độ sâu | Có (`generatePanelTripleCombo`, ưu tiên cao nhất khi có đủ file model — mục 152), CHƯA build-test/chưa có model .mnn thật |

**Textual Inversion** — phương pháp thứ 3, nhẹ nhất, hoạt động ở CLIP
(không đụng UNet), nhiều trigger word/1 prompt không giới hạn số lượng.
Yếu hơn LoRA/IP-Adapter về giống mặt, hợp nhân vật phụ.

**LoRA (ảnh)** — merge chết vào `.mnn` (khác LoRA của LLM, runtime).
3 kỹ thuật giảm identity-bleeding: **LoRA Block Weight** (giảm hệ số
`down_blocks` còn 0.5, giữ `up_blocks`/`mid_block` ở 1.0 — kinh nghiệm,
không phải số đo khoa học); **Orthogonal LoRA stacking** (Gram-Schmidt
cổ điển lúc merge, mặc định BẬT khi ghép cặp — tra cứu học thuật 2025
xác nhận chỉ giảm 1 dạng nhiễu cụ thể, KHÔNG đảm bảo hết bleeding, phụ
thuộc thứ tự merge); **Regional Prompting + IP-Adapter mask** — mạnh
nhất, tách hẳn theo vùng không gian.

**Multi-ControlNet vs ControlNet-Union**: dùng Multi-ControlNet (nhiều
model cộng residual) cho Pose+Depth. ControlNet-Union CHỈ tồn tại cho
SDXL — không có gì để làm cho SD1.5, gap đã đóng dứt điểm.

**Smooth Timestep Decay cho IP-Adapter** (`tools/ip_adapter_decay.py`) —
scale ĐÚNG output attention, giảm dần theo timestep, kiểm chứng bằng
thực nghiệm ONNX export thật. Nối cả đường 1-người lẫn mask N-người — đây
là cách `consistencyStrength` slider (từng "không có tác dụng") có tác
dụng thật.

**img2img/inpaint/Ultrafix** (`sdImg2Img()`) — nền tảng có sẵn trong
local-dream nhưng chưa từng dùng, đã nối. Resize bilinear tự viết tay.
Dùng cho: Hires-fix (denoise 0.35–0.45), auto-fix mặt/tay, Multi-Pass
Inpainting Cascade (3-4 lượt 0.6→0.2, cảnh đông người).

---

## 3.5. SDXL — chỉ nền tảng, có chủ đích chưa mở rộng

`PipelineSdxlCpu.hpp` cắm vào extension point có sẵn trong
`Pipeline.hpp`/`TextEncoder.hpp` — không phải xây từ số 0.
`sdTxt2Img()`/`NativeBridge.kt` không đổi gì (đã đủ generic).

**CHƯA làm**: IP-Adapter/ControlNet SDXL (checkpoint khác hẳn), LoRA
SDXL (shape khác), Regional Prompting/mask/Orthogonal-LoRA cho SDXL,
`SDXL_PROMPT_GUIDE` riêng.

**ĐÃ làm**: UI đọc `default_width`/`default_height` theo model đang chọn
(`SettingsScreen.kt`, xác nhận qua grep code thật).

**Rủi ro hiệu năng CHƯA ĐO ĐƯỢC** — UNet SDXL ~2.6B tham số (gấp ~3
SD1.5) — CPU thuần có thể chậm tới mức không thực dụng. Đánh giá gốc coi
SDXL "bắt buộc QNN" — vẫn làm CPU-first (đúng nguyên tắc "không hardcode
1 phần cứng") nhưng không hứa tốc độ dùng được.

---

## 4. Post-processing: upscale, auto-fix, inpaint

**Thứ tự chuẩn**: ESRGAN upscale → Ultrafix vẽ lại nhẹ toàn ảnh → auto-fix
mặt/tay ở độ phân giải CUỐI (mask chính xác hơn).

**Phát hiện mặt/tay**: suy TRỰC TIẾP từ khung xương YOLOv8-pose (đã bỏ
hẳn MediaPipe Face/Hand) — đổi hiệu suất lấy độ chính xác, mask có
padding rộng bù lại.

**Mask**: ưu tiên MobileSAM (click tâm bounding-box suy từ pose); fallback
rectangle-có-feather (`BlurMaskFilter`). Nhiều vùng lỗi hợp nhất 1 mask
(PorterDuff LIGHTEN) — chỉ 1 lượt `img2imgFix`.

**Interaction mask riêng theo vùng** — 2 người chạm nhau: tách mask lỗi
giao thoa THEO TỪNG VÙNG kiểu ADetailer, feather 15px. `clothing_tear_point`
— mô tả trang phục rách TẠI ĐIỂM CHẠM (bootstrap ảnh tham chiếu qua
img2img).

**Multi-Pass Inpainting Cascade** — 3-4 lượt denoise giảm dần (0.6→0.2),
tuần tự, mặc định BẬT.

**Quality Gate** — YOLO tự đếm chi, auto-regenerate. CHỈ nhánh 1-nhân-vật
có retry; multi-char-anchors/regional KHÔNG có (quyết định phạm vi có
chủ đích, chi phí cao hơn).

**Seed Registry** — lưu seed "hoàn hảo" (qua Quality Gate) để tái dùng.
Chỉ đảm bảo không lỗi giải phẫu, không đảm bảo thẩm mỹ.

**Auto-Histogram Guard, Hand-Over-Body Fixer** — đã áp thật vào code.

**Bubble Protection Mask** — code có sẵn, xác nhận KHÔNG CẦN wiring vào
pipeline hiện tại — không phải TODO treo.

**Nén CBZ** — JPEG q92 chỉ ở điểm xuất cuối (không nén file trung gian).
Bug đã sửa: CBZ từng thiếu bubble hoàn toàn.

---

## 5. Nhất quán nhân vật — điều phối & giới hạn

**3 phương pháp** gộp vào `EditCharacterDialog`, gợi ý tự động theo vai
trò (MAIN→LoRA, SUPPORTING→IP-Adapter, ONETIME→Không dùng).

**"Đảo pipeline nhân vật" ĐÃ LÀM** (mục 154 archive — tự quyết định UX +
triển khai theo yêu cầu user): bước phân tích sơ bộ RẺ
(`LLMParser.extractCharacterSummary()`, ~500 token vs 1800+ của
`parseStory()` đầy đủ) chạy TRƯỚC khi viết kịch bản chi tiết, chỉ khi
phát hiện nhân vật MỚI — `CharacterSummaryReviewScreen` (mobile-first: 1
cột, chip to, CTA ghim đáy màn hình) cho user xác nhận vai trò + đánh dấu
"cần giữ mặt nhất quán". **KHÔNG** đảo hẳn state machine như đề xuất gốc
(set method đầy đủ cần ảnh/LoRA thật, chưa có ở bước này) — chỉ dùng làm
HINT TẠM cho đúng 1 lượt `parseStory()` kế tiếp, KHÔNG persist vào
Character (giữ nguyên tắc `currentConsistencyMethod()` luôn suy từ dữ
liệu thật). Chương 2 trở đi (không có nhân vật mới) tự bỏ qua màn này.

**Cache `loadSD()`/`loadSDAugmented()` ĐÃ đóng gap reload khi Textual
Inversion embeddings đổi giữa chừng** — `ImagePipeline.embeddingsSignature()`
fingerprint rẻ (tên+size+lastModified), reload nếu đổi dù `modelId`
không đổi.

**Model per-nhân-vật/ghép-cặp**: `StoryManager.convertAndRegisterModel()`
/`convertAndRegisterPairModel()` + UI `PairConvertDialog` đã đủ. Rủi ro
"rò rỉ đặc điểm" ghép LoRA — không có cách biết chắc ngoài build-test.

---

## 6. Hệ thống tư thế (pose)

**Trích xuất**: YOLOv8-pose (đã thay MediaPipe hoàn toàn). 3 cơ chế cảnh
báo tự động: điểm tự tin thấp <0.5, thiếu khớp <17/17, khoảng cách khớp
liền kề >3x tham chiếu vai-hông (kinh nghiệm, không phải số đo khoa học).

**Kiến trúc**: đọc thư viện + chọn variant + retarget đã chuyển từ NATIVE
sang KOTLIN — gán tường minh `variant.people[i]` ↔ `scene.characters[i]`,
gửi mảng float PHẲNG đã retarget cho native.

**PoseRetargeter** — FK giữ góc gập, lan truyền từ hip-center, đổi ĐỘ DÀI
theo `BoneProportions` riêng từng nhân vật (không phải Bio-IK đầy đủ —
quyết định có chủ đích, không có thư viện C++ nhẹ cho NDK). KHÔNG giải
"điểm chạm bắt buộc".

**CCD-IK** — chỉ áp dụng TAY (vai-khuỷu-cổ tay), không áp dụng chân.
Pinch-to-zoom cho `PoseEditorScreen` đã thêm.

**Bàn chân "lơ lửng"** — Ground Anchoring tịnh tiến trục Y CHỈ áp dụng
cảnh KHÔNG tiếp xúc (`isContactVariant()` heuristic) — cảnh ôm/vật KHÔNG
tịnh tiến cục bộ để giữ điểm chạm gốc.

**Import khung xương ngoài** — chỉ OpenPose BODY_18 chuẩn, từ chối rõ
ràng BODY_25 thay vì đoán map sai.

---

## 7. LLM & prompt engineering

**`SD15_PROMPT_GUIDE`** (đối chiếu thật `PromptProcessor.hpp` — cú pháp
`(tag)`/`(tag:1.3)`/`[tag]`, KHÔNG có `BREAK` A1111) + `Story.
promptGuideNotes` (user tự ghi theo checkpoint) — 2 lớp, không thay thế
nhau. SDXL cần `SDXL_PROMPT_GUIDE` riêng — chưa viết.

**`PromptStage`** (TXT2IMG/UPSCALE_REDRAW/INPAINT) — dịch mô tả tự nhiên
riêng theo giai đoạn.

**`PromptStyle`** — sửa gốc rễ việc LLMParser luôn ép tag-style bất kể
checkpoint.

**Biểu cảm nhân vật** — `EXPRESSION_TAGS` đối chiếu chuẩn học thuật
AffectNet 8-lớp (6 Ekman + neutral + contempt), 4 category còn lại theo
quy ước manga. Enum đóng → LLM bị ép chọn gần nhất, không bao phủ mọi
sắc thái — đánh đổi có chủ đích.

**Bố cục/Depth Scale/Anchor Prompting** (sau 2 lần tự đính chính nhầm
"bố cục" vs "tỷ lệ khung ảnh") — Depth Scale là công cụ TƯỜNG MINH, không
tự suy luận. "Attribute binding" — giải pháp cộng đồng có, không cần
UNet mới.

**Concept Dictionary** — nối dây thật vào LLMParser. LLM 1-2B có thể
quên dict khi >30 entry, chưa làm chiến lược TOP-N.

**LLM engine kế thừa** — bug thật: `nGpuLayers` hardcode ép CPU 6/7 nơi
khởi tạo (không cố ý) — đã sửa.

---

## 8. NPU / QNN

Dùng THẲNG backend QNN built-in của MNN (`MNN_FORWARD_NN` — QNN/CoreML/
NNAPI dùng chung 1 giá trị forward type) — khác local-dream (2 engine
riêng). Cascade NPU→OpenCL→CPU ở tầng session, dùng chung mọi pipeline.

**Chưa có tác dụng thật cho tới khi**: build với QNN SDK thật + đóng gói
4 file runtime QNN (`libQnnHtp*.so`) vào `jniLibs/` — **chưa làm**. SD1.5
bắt buộc NPU thật per-model; SDXL giữ cascade GPU tối thiểu.
`ip_adapter.cpp`/`regional_prompting.cpp` — ~~vẫn hardcode `use_opencl=false`~~
**ĐÃ SỬA từ mục 61 archive** (đọc `useOpenCL`/`useNpu` thật từ Kotlin
`settings`, xác nhận qua grep tất cả 4 call site `loadSDAugmented*`/
`loadSDRegional` trong `MangaPipeline.kt`) — sót lại trong bản tóm tắt
đầu tiên, tự phát hiện + sửa ở mục 18.

**Chế độ Offline** (đúng cách local-dream chạy) — đã làm, cùng
`mangalocal_qnn_convert.ipynb` (Kaggle 29-30GB RAM free) — xem
`HUONG_DAN_NPU_QNN.md`. Cú pháp convert tra chéo 6 nguồn nhưng UNet
augmented của MangaLocal chưa từng thử convert thật.

---

## 9. Remote GPU (Colab/GPU thuê ngoài)

**Bảo mật**: hybrid RSA-OAEP + AES-256-GCM — chống trung gian mạng,
KHÔNG chống được chính chủ hạ tầng GPU. Xác thực TOFU fingerprint. Đã
kiểm chứng bằng thực nghiệm: RSA-OAEP Kotlin↔Python ban đầu KHÔNG tương
thích (padding khác) — đã sửa + verify chạy thật Java+Python.
**Confidential Computing GPU (TEE)** — công nghệ DUY NHẤT chống được
chính chủ hạ tầng — cờ có sẵn trong model, chưa có nhánh server nào.

**Routing**: MANUAL (rule Kotlin thuần) và AUTO (LLM local tự quyết theo
prompt tiếng Việt user viết — không hardcode tiêu chí). Fail-safe: lỗi
bất kỳ → luôn LOCAL. `RoutingReviewScreen` duyệt tay hàng loạt trước khi
sinh — không lẫn thứ tự truyện (nội dung cố định trước, ảnh lưu theo
index gốc).

**Server** (FastAPI) — IP-Adapter + ControlNet-Pose/Depth + LoRA (nạp/gỡ
động), SD1.5+SDXL song song. Checkpoint gốc cố định lúc khởi động, chỉ
đổi khi model_id khác hẳn ("trước khi bắt đầu 1 chương", không phải mỗi
panel). Hàng đợi (429 khi quá tải) + rate-limit + dọn VRAM lúc rảnh + tự
đóng sau N giờ — quản lý tài nguyên hợp lệ, KHÔNG phải né bộ quét (đã từ
chối rõ: Base64 obfuscate lệnh cài, script Anti-AFK, mã hoá từng biến RAM
— lý do: không thu hẹp threat model thật, chỉ thêm bề mặt bug mới).
Zero-out bytearray + `gc.collect()` cho RAM nhạy cảm — giới hạn: `str`
Python immutable, không ghi đè tại chỗ được.

**Notebook Colab**: Cloudflare Tunnel (không cần đăng ký/token).

**CHƯA XÁC NHẬN CHẠY THẬT** toàn bộ mục này — chỉ kiểm tra cú pháp Python
hợp lệ + notebook nhúng khớp byte-for-byte, chưa chạy 1 lần trên
Colab/RunPod/Vast.ai thật.

---

## 10. Quản lý tài nguyên & vận hành quy mô lớn (Industrial Batch Mode)

**4 giai đoạn tuần tự** (ESRGAN→Ultrafix→YOLO+SAM detect→SD Inpaint),
giải phóng RAM chủ động giữa mỗi giai đoạn.

**Checkpoint cuốn chiếu + Error Shunning** (`BatchStateRegistry.kt`) —
lưu tiến độ theo chương sau mỗi chương, resume được nếu OS giết giữa
batch dài (khớp hash văn bản gốc). 1 chương lỗi không làm chết cả batch.

**Cờ interrupt JNI** — `g_generation_interrupted` (atomic, `Pipeline.hpp`)
kiểm tra THẬT giữa mỗi step denoise (khác đề xuất cờ placebo từng bị từ
chối trước đó vì thiếu hook thật) — bổ trợ `cancelSafely()` timeout 30s
đã có từ trước, không thay thế. Giới hạn: chỉ ngắt được giữa 2 step.

**4 chỗ rò bộ nhớ native đã vá.**

**Foreground Service + WakeLock** — dùng file có sẵn. Chưa xác nhận
`freeAll()`/`sdFree()` an toàn gọi GIỮA CHỪNG batch.

**ProGuard/R8 + jniLibs QNN** — hạ tầng `buildTypes.release` đã thêm,
**`minifyEnabled` CỐ TÌNH giữ `false`** (chưa build-test để xác nhận R8
không phá JNI). `proguard-rules.pro` giữ rule RỘNG có chủ đích.

---

## 11. Triple-Conditioning combo (Regional + IP-Adapter + Depth cùng lúc)

`tools/export_ipa_controlnet_triple_combo_unet.py` — gộp thủ công 2 khối
logic đã kiểm chứng riêng, KHÔNG ghép trực tiếp 2 script có sẵn (Regional
Prompting monkey-patch `forward()` sẽ làm `attn.processor` của IP-Adapter
không bao giờ được gọi — lỗi kiến trúc nếu ghép ngây thơ). Danh tính +
prompt chữ dùng CHUNG 1 ranh giới cột cứng — phù hợp N người đứng cạnh
nhau, KHÔNG phù hợp cảnh ôm/đan xen.

**Đã nối dây HOÀN CHỈNH** (mục 151/152 archive) — `triple_combo.cpp`
(C++/JNI mới) + wrapper Kotlin + nhánh chọn trong `MangaPipeline.kt`
(ưu tiên cao nhất khi có đủ anchor VÀ file `unet_triple_combo_{N}region.mnn`,
additive — không đổi hành vi story nào chưa export model này). Chưa áp
dụng Multi-Pass Cascade cho nhánh này (không tương thích thẳng, để dành).
Chưa chạy thử thật (cần GPU để export model + Android thật để chạy app).

---

## 12. UI/UX — trạng thái & audit lặp lại

Đã trải qua nhiều vòng audit UI theo 4 câu hỏi cố định: route thiếu
không / đã nối dây chưa / UI "vỏ rỗng" không / tài liệu đồng bộ không.
Kết quả cuối: **không còn field settings nào thiếu UI hoặc vỏ rỗng**
ngoài 3 field `@Deprecated` cố ý giữ. Đã xoá 2 field chết
(`sdModelDir`/`useVulkan`, an toàn vì Gson bỏ qua field lạ/thiếu).
`nThreads` → Auto/Manual switch thật. `slidingWindowSize` → `ArrayDeque`
cửa sổ N panel thật (A-B-A).

**3 bug ảnh preview nghiêm trọng đã sửa** — `PanelCard`/`EditPanelSheet`/
`BubbleEditCanvas` từng chỉ hiện placeholder CHỮ thay vì ảnh thật — ảnh
hưởng trực tiếp khả năng dùng được, đã sửa dùng `AsyncImage`/Coil.

**"Chen ngang" — import ảnh ngoài thay 1 panel** (đã làm): chọn 1 file
ảnh ngoài gán thẳng cho 1 panel — `MangaPipeline.importPanelImage()` +
nút trong `EditPanelSheet`. Center-crop đúng tỷ lệ rồi resize.
`resolvedBackend=null` + `routingReason="Ảnh nhập tay (import ngoài)"`
(phân biệt với "chưa sinh lần nào" bằng `routingReason` rỗng hay không),
`qualityGatePassed=true`. Upscale/auto-fix bước sau không cần đổi gì.

`ExternalScriptImportDialog` — đã dùng `ModalBottomSheet` (không còn
`AlertDialog`).

**`CharacterSummaryReviewScreen` mới** (mục 154 archive — "đảo pipeline
nhân vật") — màn xác nhận nhân vật trước khi viết kịch bản chi tiết,
CHỈ hiện khi có nhân vật mới. Thiết kế mobile-first: 1 cột, chip to,
CTA ghim đáy màn hình. Xem mục 5.

---

## 13. Danh sách tồn đọng (đối chiếu code hiện tại)

1. **SDXL**: IP-Adapter/ControlNet/LoRA/Regional/mask/Orthogonal riêng,
   `SDXL_PROMPT_GUIDE` riêng (mục 3.5, mục 7).
2. **QNN runtime thật**: chưa đóng gói 4 file `.so` vào `jniLibs/`
   (mục 8).
3. **`minifyEnabled`** vẫn `false` — hạ tầng sẵn sàng, chưa bật (mục 10).
4. **ControlNet-Union, SDXL local đầy đủ** — quy mô lớn, đã đánh giá kỹ
   thuật, chưa bắt tay (mục 3, 3.5).

Tất cả 4 mục còn lại đều KHÔNG làm được trong sandbox này — cần hạ tầng
thật không có (QNN SDK), hoặc quy mô ngang/lớn hơn hẳn 1 lượt an toàn.
Mọi mục "cần quyết định sản phẩm trước khi làm" trong dự án (đảo pipeline
nhân vật, import ảnh ngoài) đều đã được tự quyết định + triển khai.

**Việc lớn nhất, bao trùm mọi mục trên**: build CI thật lần đầu (mục 0).

---

## 14. Công nghệ đã nghiên cứu nhưng KHÔNG dùng, thực nghiệm quan trọng, bài học phương pháp

**Model nền thay SD1.5 — đã tra kỹ, không có lựa chọn khả thi hơn**:
Flux-schnell (12B, không nhỏ hơn), Flux.1-lite (8B, vẫn nặng), SD3.5
Medium (2.5B, không có bản CPU/MNN), Hunyuan-DiT (không tìm được bằng
chứng tối ưu MNN/ncnn). Không model nào có tiền lệ chạy MNN mobile.

**"BREAK" (A1111) — xác nhận KHÔNG hoạt động** trong engine này (grep
`TextEncoder.hpp`/`PromptProcessor.hpp`) — kể cả trên A1111 gốc, BREAK
đơn thuần không tương đương Regional Prompter.

**Bio-IK đầy đủ — đánh giá và KHÔNG chọn**, thay bằng FK nhẹ hơn — không
có thư viện C++ nhẹ cho NDK Android.

**2 kỹ thuật né tránh hệ thống chống lạm dụng — từ chối rõ ràng**: Base64
obfuscate lệnh cài + script Anti-AFK; mã hoá từng biến RAM (không thu hẹp
threat model thật, model AI bắt buộc nhận plaintext để inference).

**Confidential Computing GPU (TEE)** — công nghệ duy nhất chống được
chính chủ hạ tầng GPU thuê — biết hướng đúng, chưa triển khai.

**Orthogonal LoRA — 3 hướng học thuật 2025 cạnh tranh nhau** (OSRM
arXiv:2505.22934, Orthogonal MC Dropout arXiv:2510.03262, DO-Merging
arXiv:2505.15875) — cả 3 áp dụng lúc TRAIN, không dùng được cho merge
LoRA có sẵn — Gram-Schmidt cổ điển là lựa chọn khả thi duy nhất, ghi rõ
"giảm 1 dạng nhiễu cụ thể", không phải giải pháp triệt để.

**Thực nghiệm thật quan trọng nhất — MNNConvert 3.6.1 hỗ trợ đúng op
`Where`**: tự cài MNN+onnx+onnxruntime qua pip (đúng version CI dùng),
dựng đồ thị test, convert, so khớp SỐ HỌC với ONNX Runtime — 4/4 khớp
chính xác. 1 trong rất ít nơi có xác nhận thực nghiệm độc lập.

**Bài học phương pháp**:
1. Không tin tài liệu review ngoài dù văn phong tự tin — verify bằng
   grep/code thật trước khi hành động theo.
2. Sửa 1 file bằng chèn giữa chừng → liệt kê TOÀN BỘ vị trí liên quan
   trước khi khẳng định xong.
3. Kể cả khi chủ động đối chiếu code, đọc lướt tiêu đề mục thay vì đọc
   hết nội dung vẫn tạo ra lệch pha MỚI — không có cách tránh 100% ngoài
   double-check bằng code thật cho từng mục trước khi chốt.
4. 1 cờ boolean không hook thật ở đâu là placebo, không phải cơ chế.

---

## 15. Đợt "audit" thứ 2 từ nguồn ngoài (PDF, cùng mẫu Google AI Mode) — 2 việc thật đã làm, phần lớn còn lại không đáng tin

User dán vào PDF chứa 1 chuỗi hội thoại rất dài (nhiều lượt "còn nữa
không" liên tiếp) với ngày càng nhiều đề xuất "lỗ hổng kiến trúc" leo
thang tới mức phi lý — tới đoạn cuối cùng đưa ra các claim ở tầng
**vật lý bán dẫn** (Voltage Droop khiến "bit-flip ngẫu nhiên", LPDDR5
"Bandwidth Starvation", "512 slots JNI cố định" tuyệt đối, Hexagon HTP
"Subnormal Collapse") — đây là dấu hiệu rõ ràng của chuỗi ảo giác leo
thang (mỗi câu "còn nữa không" ép mô hình tạo ra vấn đề MỚI ngày càng cực
đoan hơn để có gì đó trả lời) — **KHÔNG kiểm tra những phần này**, không
đáng tin theo cùng lý do đã nêu ở mục 142/143.

Tuy nhiên, khác các lượt trước, đợt này có 1 vài claim SỚM (trong 2-3
tin nhắn đầu PDF) **kiểm chứng được bằng grep code thật và ĐÚNG**:

### 1. "Sốc toán học Timestep" ở Depth ControlNet — ĐÚNG, đã sửa

`export_ipa_controlnet_depth_unet.py` (mục 81 archive) dùng `torch.where`
làm cổng NHỊ PHÂN CỨNG cho `depth_scale` (bật 100%/tắt 0% đột ngột đúng 1
timestep) — xác nhận đúng bằng đọc code, không phải claim bịa. Residual
ControlNet cộng THẲNG vào latent mỗi step — 1 cổng nhảy đột ngột giữa 2
step liền kề LÀ rủi ro thật về mặt liên tục tín hiệu (không cần thực
nghiệm riêng để biết — nguyên lý cơ bản của bất kỳ hệ xử lý tín hiệu số
nào), khác hẳn các claim "vật lý silicon" vô căn cứ ở cuối PDF.

Đã sửa: thêm input mới `depth_ramp_width` (tuỳ chọn, tương thích ngược
— thiếu input này = hành vi cổng cứng cũ, không hồi quy) — cổng suy giảm
TUYẾN TÍNH MƯỢT trên 1 cửa sổ quanh ngưỡng thay vì nhảy bậc. File đổi:
`tools/export_ipa_controlnet_depth_unet.py` (forward() + export),
`app/src/main/jni/ip_adapter.cpp` (`setControlNetBalance()` thêm tham số
thứ 4 có default, đọc input mới theo đúng pattern tự-phát-hiện-input đã
có sẵn cho mọi input tuỳ chọn khác trong file này).

### 2. "Per-Instance Decay cho N-nhân vật" — ĐÚNG, XÁC NHẬN LÀ GAP THẬT (chưa sửa)

Đọc `tools/ip_adapter_decay.py` xác nhận: `decay_state.value` là **1
scalar DÙNG CHUNG** cho mọi nhân vật trong nhánh mask N-người (dòng
`static_scale[i] * self._decay_state.value * (...)` — `static_scale`
tách theo từng người [i], nhưng decay theo timestep thì KHÔNG). PDF nói
đúng: cảnh vật lộn nhiều người, hạ decay ở step cuối để biểu cảm phát
huy sẽ làm YẾU identity-lock của **CẢ HAI** người cùng lúc dù chỉ 1 người
đang biểu cảm mạnh.

**CHƯA sửa trong lượt này** — đây là thay đổi lớn hơn hẳn mục 1 (decay
phải trở thành mảng N-phần-tử xuyên suốt: Python export → ONNX input
shape đổi từ scalar sang vector → C++ đọc theo đúng N (không hardcode) →
Kotlin phải biết trạng thái "đang biểu cảm mạnh" của TỪNG nhân vật để
truyền đúng giá trị cho đúng index) — ghi nhận là gap THẬT, để dành việc
kế tiếp thay vì làm vội trong cùng lượt với mục 1.

### 3. Concept Dictionary TOP-N theo độ liên quan (không phải đề xuất từ PDF này — đóng gap ĐÃ GHI SẴN từ trước, mục 78 archive)

Nhân dịp làm việc trên `LLMParser.kt`/`MangaPipeline.kt`, đóng luôn gap
đã tự ghi nhận từ mục 78 archive ("chiến lược cắt TOP-N theo TF-IDF nhẹ —
CHƯA làm"). `ConceptDictionary.buildInjectionText()` trước đây LUÔN lấy
30 entry ĐẦU TIÊN theo thứ tự chèn — sai ở chỗ: truyện dài dần tích luỹ
>30 khái niệm, entry chèn SỚM (đầu truyện) mãi mãi chiếm hết suất dù
chương hiện tại không nhắc tới, trong khi khái niệm MỚI của chương này
bị cắt mất.

**Không dùng TF-IDF đúng nghĩa** (cần kho ngữ liệu nhiều văn bản để tính
IDF có ý nghĩa — 1 truyện đơn lẻ không đủ) — dùng bộ lọc rẻ hơn nhưng
giải quyết đúng vấn đề: đếm số lần khái niệm xuất hiện LITERAL trong văn
bản chương (ghép từ `description`/`action`/`setting`/thoại của mọi scene
— proxy hợp lý vì các trường này do LLM viết TỪ văn bản gốc), ưu tiên
entry có xuất hiện. File đổi: `ConceptDictionary.kt`
(`buildInjectionText(chapterText, maxEntries)`, tương thích ngược nếu
gọi không tham số), `MangaPipeline.kt` (truyền text ghép từ `scenes`).

### Việc KHÔNG làm từ PDF này, và lý do

- Toàn bộ các claim "tầng vật lý silicon" (Voltage Droop, Bandwidth
  Starvation, JNI 512 slots, Subnormal Collapse HTP...) — không kiểm tra,
  không đáng tin (chuỗi ảo giác leo thang, xem trên).
- 3D Human Mesh Recovery, Masked TEXT Cross-Attention (FastComposer/
  SPDiffusion), Dynamic Axes 3 profile, In-Memory Pipeline (bỏ hẳn ghi
  PNG ra đĩa), Multi-Process JNI Isolation, Dynamic Model Delivery,
  Native Crash Dump (Breakpad), Dynamic Identity Bootstrap (ảnh neo đổi
  theo cốt truyện) — đều là đề xuất tính năng THẬT SỰ có thể đáng làm,
  nhưng quy mô LỚN (đụng kiến trúc export/JNI/UI nhiều lớp cùng lúc),
  không làm vội chỉ vì 1 văn bản ngoài liệt kê hàng loạt trong 1 lượt.
- Claim pháp lý "cần Clean-room tách code khỏi CC BY-NC 4.0 để thương
  mại hoá" — **không tự ý hành động theo** vì đây là quyết định SẢN PHẨM/
  PHÁP LÝ (không phải kỹ thuật thuần), và bản thân `NOTICE_local-dream.md`
  đã ghi rõ điều kiện dùng (mục 10 archive: "MangaLocal miễn phí 100% —
  điều kiện bắt buộc để hợp lệ dùng code local-dream") — nếu user có ý
  định thương mại hoá thật, cần tự quyết định hướng đi (giữ miễn phí,
  hoặc tự viết lại phần đụng license) trước khi có thay đổi code nào theo
  hướng đó, không phải việc kỹ thuật tự làm liều.

**CHƯA build-test** (như mọi phần khác) — đã kiểm tra cân bằng ngoặc
`{}/()` (loại trừ comment) cho cả 3 file sửa.

## 16. Per-Instance Decay (đóng gap mục 15) + phát hiện phụ: bug compile thật tiền tồn tại

Làm nốt Per-Instance Decay đã xác nhận thật ở mục 15 (decay theo
timestep giờ tách RIÊNG từng nhân vật trong đường mask N-người, thay vì
1 scalar dùng chung — `IpDecayState.value` shape `[N]`, C++
`setIpAdapterDecayMultiCharacter()` mới, tuỳ chọn/tương thích ngược).
Kotlin chưa tự tính giá trị per-character thật từ `Scene.expression` —
hạ tầng đã sẵn sàng, việc tính giá trị để dành.

**Phát hiện phụ ngoài dự kiến — bug compile thật**: 2 call site trong
`MangaPipeline.kt` gọi `generatePanelMultiChar()` với 3 tham số
(`poseConditioningScale`/`depthConditioningScale`/`depthActiveMinTimestep`)
mà hàm KHÔNG hề khai báo (copy-paste từ call site `generatePanel()`
1-nhân-vật, nơi 3 tham số này thật) — lẽ ra Kotlin không compile được,
chưa bị bắt vì chưa build-test lần nào. Xác nhận không phải thiếu sót cần
thêm vào: model mask N-nhân-vật không có Depth ControlNet, residual Pose
cộng thẳng 1:1 không có input scale — khác biệt kiến trúc thật. Đã bỏ 3
dòng gọi sai ở cả 2 call site.

## 17. Quét đối chiếu chữ ký JNI thật — toàn bộ 33 hàm khớp, không bug thêm (số liệu tại thời điểm quét — nay đã 37, xem mục 19)

Mở rộng phương pháp mục 16 (đối chiếu tham số ↔ call site, tìm ra bug
compile thật) sang lớp rủi ro cao hơn: chữ ký JNI giữa `NativeBridge.kt`
(33 `external fun` tại thời điểm này) và triển khai C++ thật (9 file
`.cpp`). Sai lệch ở đây là crash runtime khó debug, không phải lỗi
compile bắt được ngay. Đối chiếu tay toàn bộ 33 hàm — **khớp chính xác,
không tìm thêm bug**. Giới hạn: chỉ xác nhận hình thức chữ ký, không
chạy thử JNI thật được (không có NDK trong sandbox).

## 18. Tự phát hiện thêm 1 drift trong bản tóm tắt (mục 8 sai) khi trả lời "còn gì chưa xong"

User hỏi thẳng "còn gì chưa xong" — trước khi trả lời từ danh sách có
sẵn, kiểm tra lại từng mục bằng grep thay vì tin theo chữ đã viết. Phát
hiện mục 8 (NPU/QNN) sai: viết "`ip_adapter.cpp`/`regional_prompting.cpp`
vẫn hardcode `use_opencl=false`" — thật ra đã sửa từ mục 61 archive (2
struct `SdAugmentedHandle`/`SdRegionalHandle` đọc `useOpenCL`/`useNpu`
thật từ tham số JNI, và cả 4 call site `loadSDAugmented*`/`loadSDRegional`
trong `MangaPipeline.kt` đều truyền `settings.useOpenCL, settings.useNpu`
thật, không hardcode). Đã sửa mục 8 + mục 13 (danh sách tồn đọng còn 5
mục, không phải 6).

## 19. Triple-Conditioning combo — lớp C++/JNI/Kotlin-wrapper hoàn chỉnh, còn 1 việc cuối

Nối dây phần lớn nhất còn lại của tính năng này: `triple_combo.cpp` (file
mới, ghép `PipelineSd15CpuRegional` + `IpImageEncoder` của
`PipelineSd15CpuAugmented`, đối chiếu API kỹ với khai báo thật trước khi
viết xong) + `renderDepthHintCanvas()` mới trong `ip_adapter.cpp` +
`NativeBridge.kt`/`ImagePipeline.kt`/`StoryManager.kt` wrapper đầy đủ.
Thêm vào `CMakeLists.txt`. Nhân tiện sửa trước 1 lỗi cùng loại mục 131
(ctx mới thêm vào `freeAll()` ngay từ đầu, không để sót như
`sdRegionalCtx` từng bị).

**Còn thiếu duy nhất**: `MangaPipeline.kt` chưa chọn khi nào gọi pipeline
này (đọc/sửa nhánh ưu tiên 4 tầng có sẵn — rủi ro cao nhất, để dành lượt
riêng). Dữ liệu đầu vào (prompt theo cột, ảnh neo) đã có sẵn, tái dùng
được ngay — chỉ cần đúng điều kiện chọn.

## 20. Hoàn thành Triple-Conditioning combo — nối nhánh chọn trong MangaPipeline.kt

Làm nốt việc cuối cùng để dành ở mục 19: thêm `tripleComboAnchors` +
nhánh chọn (additive, KHÔNG sửa `multiCharAnchors`/`useRegional` có sẵn
— chỉ đổi thứ tự if/else, đặt Triple Combo ưu tiên cao nhất) ở cả 2 nơi
chọn pipeline (`runGeneration()` có Quality Gate retry,
`regeneratePanel()` đơn giản hơn — đúng khác biệt đã có sẵn giữa 2 nhánh
cũ). Story nào chưa export model `unet_triple_combo_{N}region.mnn` thì
hành vi không đổi gì (tự rơi xuống 2 nhánh cũ). Ràng buộc quan trọng:
`regionOrderTc` dùng làm thứ tự DUY NHẤT cho cả prompt chữ lẫn ảnh neo
(bắt buộc khớp nhau, đúng thiết kế export script). Chưa áp dụng
Multi-Pass Cascade cho nhánh này. Tính năng coi như nối dây xong toàn bộ
— danh sách tồn đọng còn 5 mục, tất cả đều không làm được trong sandbox
này (cần QNN SDK/quyết định sản phẩm/quy mô quá lớn) hoặc chờ build CI
thật (mục 0).

## 21. Hoàn thành "đảo pipeline nhân vật" — tự quyết định UX mobile-first + triển khai

Gap cuối cùng trong nhóm "cần quyết định sản phẩm trước khi làm" — tự
quyết theo yêu cầu user, thiết kế mobile-first. Quyết định: KHÔNG đảo hẳn
state machine (set method thật cần ảnh/LoRA chưa có ở bước sớm này) — chỉ
thêm bước phân tích sơ bộ RẺ trước khi viết kịch bản chi tiết, hỏi đúng 1
câu quan trọng ("cần giữ mặt nhất quán?") làm hint TẠM cho lượt viết kịch
bản kế tiếp, không persist vào Character (giữ nguyên tắc method luôn suy
từ dữ liệu thật). Chỉ hiện khi có nhân vật MỚI — chương 2 trở đi tự bỏ
qua, không thêm ma sát.

`CharacterSummaryReviewScreen.kt` (màn mới): 1 cột, chip to dễ chạm, CTA
chính ghim cố định đáy màn hình (luôn trong tầm tay dù danh sách dài), có
đường tắt "Dùng gợi ý mặc định, viết luôn" cho ai không muốn chỉnh gì.

File đổi: `Models.kt` (`CharacterSummary`), `LLMParser.kt`
(`extractCharacterSummary()`, prompt riêng rẻ hơn), `MangaPipeline.kt`
(`analyzeCharacters()` mới + `prepareChapter()` thêm tham số
`extraIdentityHintNames` default rỗng — 0 đổi hành vi cũ), `MainViewModel.kt`
(`analyzeCharactersFirst()`/`confirmCharacterSummaryAndProceed()`),
`StoryScreens.kt`/`MainActivity.kt` (nối nút + route mới).

Danh sách tồn đọng còn 4 mục, tất cả thuộc loại không làm được trong
sandbox (cần hạ tầng thật hoặc quy mô quá lớn) — không còn mục nào "cần
quyết định sản phẩm" nữa.

## 22. Audit lệch pha + cập nhật hướng dẫn sử dụng + mục Help trong app (mới)

Grep đối chiếu toàn bộ `HUONG_DAN_SU_DUNG.md` với code — chỉ 1 chỗ lệch
(Bước 3, nút "Sinh panel" giờ gọi `analyzeCharactersFirst()` từ mục 154,
không phải `prepareChapter()` trực tiếp) — đã sửa + thêm Bước 3.5. Bản
tóm tắt này cũng có 2 chỗ lệch tự tìm ra: bảng pipeline SD1.5 (mục 3)
thiếu dòng Triple-Combo (đã code ở mục 19 nhưng quên cập nhật bảng), và
số "33 hàm JNI" ở mục 17 đã tăng lên 37 sau mục 19 — đã sửa/ghi chú cả 2.

Thêm **mục Help trong app** (chưa từng có trước đây) — `HelpScreen.kt`
mới, thiết kế mobile: card gập/mở, mặc định gập hết trừ mục đầu. 6 mục:
chuẩn bị model, luồng chính 9 bước, giữ mặt nhân vật, chế độ công nghiệp,
GPU thuê ngoài, xử lý sự cố. 3 lối vào (StoryListScreen + StoryDetailScreen
TopAppBar, SettingsScreen) — help cần dễ tìm trên mobile, không giấu sâu.

## 23. Build CI thật đầu tiên (Build APK #88) — FAILED, 6 lỗi, đã sửa — đọc mục 0 lại

Cột mốc: user chạy build CI thật lần đầu tiên trong lịch sử dự án — FAILED,
đúng như mục 0 luôn cảnh báo. 6 lỗi, TẤT CẢ cùng 1 nguyên nhân, TẤT CẢ ở
`ip_adapter.cpp` (KHÔNG phải `triple_combo.cpp` như suy đoán ban đầu từ
log tóm tắt — bài học: đừng suy luận file lỗi từ vị trí dòng log ninja,
cần dòng `error:` thật).

Nguyên nhân: `setControlNetBalance()`/`setIpAdapterDecay()`/
`setIpAdapterDecayMultiCharacter()` vô tình rơi vào vùng `protected:` (mở
bởi `onBeforeUnetRun()` phía trên, không có `public:` đóng lại) dù ý đồ
rõ ràng là public (gọi từ JNI tự do bên ngoài class) — bug THẬT có từ
trước mục 146/147 (gốc từ mục 81/97 archive), chỉ chưa từng lộ ra vì chưa
build-test lần nào. Sửa: thêm `public:` đúng chỗ — 1 sửa duy nhất khắc
phục cả 6 lỗi.

**Chưa biết 4 file khác** (đang build dở khi ninja dừng) có lỗi gì không
— cần chạy lại build để biết. Đây MỚI LÀ BẰNG CHỨNG THẬT ĐẦU TIÊN cho
thấy "chưa build-test" (mục 0) không phải lời cảnh báo suông — ngay lỗi
ĐẦU TIÊN gặp phải đã là thật, có từ lâu, không lộ ra vì chưa ai build.

## 24. Build APK #91 — compile PASS toàn bộ (1052/1052), lỗi mới ở LINK — đã sửa

Tiến bộ rõ rệt sau mục 23: mọi file compile sạch (kể cả `triple_combo.cpp`),
build đi tới bước link cuối cùng mới lỗi — 2 hàm `resizeToCHWFloat`/
`resizeMaskBoth` (dùng chung giữa `ip_adapter.cpp` và
`mnn_diffusion_pipeline.cpp`) bị "undefined symbol" vì định nghĩa thật
nằm trong `namespace { ... }` (vô danh) — có tác dụng y hệt `static`
(internal linkage) dù comment tại chỗ khai báo `extern` khẳng định
"không có `static`" (đúng nhưng không đủ — quên mất namespace vô danh
cho hiệu ứng giống hệt, 1 cạm bẫy C++ kinh điển đọc code tĩnh không bắt
được). Bug có từ trước (mục 16 archive), không phải do việc gần đây. Đã
xoá namespace vô danh đó (chỉ bao đúng 2 hàm này, không ảnh hưởng gì
khác) — trả external linkage tự nhiên.

Nếu lần build tiếp theo pass, đây sẽ là **lần build PASS HOÀN TOÀN ĐẦU
TIÊN** trong lịch sử dự án.

## 25. Build #94 — compile PASS C++/link, lỗi MỚI 100% ở `compileDebugKotlin`

`ip_adapter.cpp`/link không còn lỗi (mục 23/24 đã sửa đúng) — nhưng
`compileDebugKotlin` lỗi hàng loạt: `isInitialized()` gọi thừa `()` trên
2 property `by lazy`, trailing lambda lệch tham số ở 4 hàm
`generatePanel*`/`inpaintCharacterInCascade` (do `onProgress` KHÔNG phải
tham số cuối ở 4 hàm này), thiếu `import androidx.compose.ui.draw.clip`
ở 2 file, thiếu `import PoseRetargeter`, và code không-Composable gọi
`collectAsState()`/`remember{}` bên trong `LazyColumn{}`. Đã sửa cả 5
loại lỗi.

## 26. Build #97 — đính chính SAI ở mục 25 + lỗi thật thứ 2

Chẩn đoán `isInitialized()` ở mục 25 SAI: `maskFixer`/`poseExtractor` là
`by lazy`, không phải `lateinit` — bỏ `()` gây lỗi KHÁC ("cannot be
invoked as function" → giờ "only callable on lateinit"). Sửa ĐÚNG: tách
riêng object `Lazy<T>`, gọi `.isInitialized` trên chính object đó (không
phải qua property delegate). Lỗi thật thứ 2 (KHÁC mục 25, lộ ra sau khi
sửa lỗi trên): thiếu `@OptIn(ExperimentalMaterial3Api::class)` ở
`CharactersScreen.kt`/`RoutingReviewScreen.kt`.

## 27. Tổng kết retrospective build CI thật (mục 23-26)

Nhìn lại: lỗi build ĐẦU TIÊN (mục 23) là bug C++ có TỪ RẤT LÂU (archive
mục 81/97), không liên quan việc gần đây — bằng chứng "chưa build-test"
không phải lời cảnh báo suông. Bài học phương pháp: (1) đọc dòng `error:`
thật, đừng suy luận file lỗi từ vị trí log ninja; (2) 1 chẩn đoán sai (mục
25→26) vẫn tốt hơn không build thử — build thật luôn lộ đúng sự thật,
suy luận trên giấy thì không.

## 28. Build CI THẬT ĐÃ PASS — dò lại 8 đề xuất lớn bị hoãn

Cột mốc: sau mục 26, build APK **PASS HOÀN TOÀN lần đầu tiên**. Dò lại 8
đề xuất từ audit PDF ngoài (mục 15) theo độ ưu tiên: #5 Multi-Process
Isolation (mục 29-33), #3 Dynamic Axes/Aspect Ratio — làm bản THU HẸP (N
profile cố định 512x512/768x512/512x768 thay vì dynamic_axes thật, đúng
PDF gốc tự đề xuất làm phương án dự phòng) cho model base+augmented, xác
nhận native cần sửa `controlSize_` (1 số, ép vuông) thành
`controlWidth_`/`controlHeight_` riêng — đã sửa, CHƯA build-test. #1 3D
HMR, #4 Dynamic Model Delivery, #7 in-memory/WebP — để dành, không chạm.

## 29. #5 Multi-Process Isolation (đợt 8) — tra cứu giải quyết phần lớn bất định

User chỉ đúng: đừng lẫn "phạm vi lớn" (thật, cần làm) với "không thể biết
trước" (nhiều phần tra cứu được). Kết quả: `GenerationService` chạy
`android:process=":inference"` riêng (native crash không kéo sập UI),
giao tiếp qua `Messenger`/IPC thay gọi hàm trực tiếp.

## 30. #5 (đợt 9) — chuyển nốt `runIndustrialBatch()` qua IPC

Tận dụng ĐÚNG cơ chế Error Shunning (đã có, xử lý lỗi từng chapter) thay
vì viết message type IPC mới — `runIndustrialBatch()` (chạy hàng loạt
nhiều chapter) trước đó vẫn gọi trực tiếp, bỏ sót khỏi lớp cách ly tiến
trình mục 29 vừa làm cho panel đơn lẻ.

## 31. #5 (đợt 10) — tra cứu tìm được 2 lỗi thật, không chỉ ghi chú rủi ro

User hỏi lần 3 "rủi ro cao thì có tra cứu giải pháp tốt hơn không" — có,
và tìm ra 2 lỗi THẬT trong cách IPC mục 29/30 vừa làm (không chỉ dừng ở
mức "đã biết rủi ro"), đã sửa cả 2.

## 32. Đợt 11 — vấn đề Y HỆT ở tầng LƯU TRỮ ĐĨA (khác tầng IPC)

User hỏi đúng: sao không lưu cả quyển sách 1 lần mà phải thao tác từng
phần? Phát hiện: `characters.json`/pose templates từng lưu GỘP 1 file lớn
— máy yếu (RAM thấp) đọc/ghi cả file mỗi lần sửa 1 nhân vật là lãng phí
y hệt vấn đề IPC đã sửa, chỉ khác tầng (đĩa, không phải tiến trình). Đã
tách nhỏ theo từng nhân vật/từng pose.

## 33. Đợt 12 — quét toàn bộ chủ động thay vì đợi user chỉ tiếp

User chỉ thẳng: "máy yếu, cái gì tách nhỏ được thì tách, sao không tự tìm
mà bắt tôi tìm" — tự quét TOÀN BỘ codebase tìm pattern "đọc/ghi cả file
lớn cho 1 thay đổi nhỏ" tương tự mục 32, tìm thêm đúng 1 chỗ nữa và sửa,
kiểm tra hết các chỗ còn lại đều ổn.

## 34. Đợt 13 — đồng bộ tài liệu/hướng dẫn sử dụng/Help trong app

User hỏi: tài liệu kỹ thuật/HUONG_DAN_SU_DUNG.md/mục Help trong app đã
đồng bộ với code (sau cả loạt IPC/lưu trữ mục 29-33) chưa? Audit lại,
sửa các chỗ lệch tìm được (README, HUONG_DAN_SU_DUNG.md, comment code).

## 35. Per-Character Expression + SAM cho Multi-Pass Cascade (mục 168 bản đầy đủ)

User hỏi: cảnh 6+ người vật lộn, mỗi người biểu cảm khác nhau — kiến trúc
hiện tại đáp ứng được không? Trả lời KHÔNG (kiểm bằng code), chỉ ra 5
điểm chặn. Đã sửa 2 việc khả thi: (1) `Scene.characterExpressions:
Map<String,String>` — cho phép mỗi nhân vật 1 tag biểu cảm riêng, chỉ có
tác dụng khi bật Multi-Pass Cascade (nhánh 1-lượt-chung không đọc field
này). (2) Nối MobileSAM (đã có từ trước) vào mask cascade — trước đây
CHỈ vẽ bounding-box, 2 người chạm nhau bbox đè lên nhau phá đúng mục đích
"cô lập 1 người/lượt". Điểm chặn occlusion N>2 CHƯA làm, cố ý để lại.

## 36. Gap lớn nhất buổi làm việc: `prepare_models.yml` không export được pipeline nhiều-nhân-vật nào

Tra "occlusion N>2 có thật chưa có lời giải" — phát hiện thuật toán
z-ordering (`renderDepthHint()`) ĐÃ tổng quát cho N người từ lâu, KHÔNG
phải thiếu thuật toán. Cái thật sự chặn: `prepare_models.yml` (file
maintain ngoài zip) THIẾU HẲN bước export cho CẢ 4 pipeline nhiều-nhân-vật
(mask/depth/regional/triple-combo) dù Kotlin/C++ đã hoàn chỉnh từ lâu —
và Kotlin tự chặn cứng `sceneChars.size in 2..4` ở 6 chỗ, mâu thuẫn với
chính comment cạnh nó. Đã thêm 4 bước export + input N tuỳ chọn vào yml,
đổi 6 chỗ `2..4` → `>= 2`.

## 37. Depth-aware cascade ordering + tự bắt lệch pha do CHÍNH mục 36 gây ra

User hỏi tiếp: Cascade có giải quyết được combat/quần nhau không? Tìm gap
thật: vòng lặp cascade xử lý theo thứ tự TÊN (không phải "ai gần máy quay
hơn") — 2 mask chồng lấn thì người xử lý SAU luôn thắng, ngẫu nhiên. Đã
sửa: xử lý người XA trước, GẦN sau (theo `depthScale`). Rà lại toàn
codebase sau mục 36, tự bắt được 1 lỗi CHÍNH mục 36 gây ra:
`GalleryReviewScreen.kt` còn 1 điều kiện UI copy y hệt `in 2..4` cũ, ẩn
nhầm editor cho N=5,6+ mà mục 36 vừa mở khoá — đã sửa, và ghi bài học
"đổi hằng số nghiệp vụ phải grep toàn bộ codebase".

## 38. Tra cứu cộng đồng (TokForge) + kế hoạch Hybrid SD1.5/SDXL

User hỏi cộng đồng giải bài toán nhiều người thế nào, SDXL có giải quyết
được phần SD1.5 không làm được không. Tra ra: TokForge (app Android
tương tự) closed-source (không tham khảo được code, chỉ model đóng gói
lại từ nguồn mở đã dùng) nhưng dùng `stable-diffusion.cpp` (mở, có sẵn
IP-Adapter cho cả 2 kiến trúc) đáng tham khảo khi làm SDXL. SDXL benchmark
thật cho kết quả nhiều người tốt hơn SD1.5 rõ rệt (FID/IS, độ phân giải
gấp 4). Đã thêm tầng dữ liệu (`ImageModelTier` enum,
`modelTierOverride`) cho kiến trúc hybrid user đề xuất (SD1.5 mặc định,
batch chọn panel không ưng ý chạy lại SDXL) — CHƯA nối gì thật, Phase 2
(export/C++ SDXL) là việc lớn riêng, cần GPU thật.

## 39. Hướng A: Regional Prompting bản MASK tuỳ ý (kiểu Attention Couple cộng đồng)

Viết mới `export_ipa_controlnet_regional_mask_unet.py` — nhận mask THẬT
(hình dạng, có thể chồng lấn) làm input ONNX thay vì chia cột cứng như
bản cũ (mục 56/69), ghép bằng so sánh cứng theo pixel (vùng mạnh hơn
thắng hẳn, không trộn danh tính — đúng nguyên tắc cộng đồng đã tra), thêm
khái niệm "vùng nền" cho phần ảnh không ai claim. Viết `.cpp` native
tương ứng + khai báo JNI + hàm kiểm tra tồn tại model + bước export
`prepare_models.yml`. CHƯA nối dispatch vào MangaPipeline ở đợt này (cố
tình, cần đọc kỹ chuỗi ưu tiên hiện có trước).

## 40. Nối dispatch Regional-Mask + tự sửa 1 overclaim của chính mục 39

Hoàn thành việc mục 39 để lại: thêm `useRegionalMask` ưu tiên hơn
`useRegional` cũ khi cả 2 model cùng tồn tại, nối vào cả `generatePanels()`
và `regeneratePanel()`. Tự bắt lỗi CHÍNH mục 39: định dùng SAM (mục 35)
dựng mask cho pipeline mới, nhưng SAM cần ảnh THẬT ĐÃ TỒN TẠI để
click-segment — pipeline mới cần mask cho LƯỢT SINH ĐẦU TIÊN (chưa có ảnh
nào), khác Cascade. Đã sửa `buildCharacterBodyMaskFile()` nhận
`imagePath: String?` (null = bỏ qua SAM), mask Regional-Mask hiện dùng
rectangle+feather thô — KHÔNG tốt hơn nhánh mask N-người cũ như mục 39
lỡ nói. CHƯA build-test bất kỳ phần nào của mục 36-40 (cần GPU/Gradle/
device thật, không có trong sandbox viết code).

## 41. Viết lại bản tóm tắt này (mục 25-40) + 2 file workflow ngoài zip bị lệch nghiêm trọng + bug thiếu-nối-dây CMakeLists.txt

Đợt "bắt đầu lại phiên mới, không tin tài liệu cũ": tự đối chiếu lại từng
claim với code/file thật thay vì tin các dòng "đã làm" ở mục 12/28/40.
Phát hiện 3 việc:

1. **Bug thiếu-nối-dây thật**: `regional_mask_prompting.cpp` (mục 39, có
   đủ 3 hàm `JNIEXPORT` khớp `NativeBridge.kt`) CHƯA từng được thêm vào
   `add_library()` trong `CMakeLists.txt` — file không được compile/link,
   gọi tới sẽ `UnsatisfiedLinkError`. Đã vá, xác nhận lại 13/13 `.cpp`
   khớp `add_library()`, 41/41 JNI khớp tên.
2. **`prepare_models.yml` (sống NGOÀI zip) lệch hoàn toàn**: tài liệu ghi
   nhận đã thêm 5 bước export (mask/depth/regional/regional-mask/
   triple-combo) nhưng file thật KHÔNG có bước nào — vá bằng cách đọc
   trực tiếp argparse 5 script Python, thêm đủ 5 bước + 10 input.
3. **`build.yml` (cũng ngoài zip) lệch 2 chỗ**: vẫn trỏ tới
   `convert_qnn_offline.yml` (file chưa từng tồn tại, quyết định không
   viết từ lâu) và `qnn_hexagon_arch` default vẫn "75" thay vì "68"
   (Zenfone 8, máy dev chính) — đã sửa cả 2.

**Bài học rút ra**: 2 file `.yml` sống ngoài zip không tự đồng bộ theo
tài liệu — phiên sau phải luôn đối chiếu trực tiếp, không suy luận "đã
đúng ở mọi nơi khác thì chắc đúng luôn ở đây".

## 42. SỬA 1 OVERCLAIM THẬT (user chỉ ra) — SDXL còn dở nhưng lại kết luận "không còn gì tồn đọng"

User hỏi thẳng: nếu SDXL chưa xong sao lại kết luận hết việc? Đúng — dòng
kết ở mục 41 copy lại nguyên văn kết luận cũ mà không tự kiểm tra lại, dù
chính mục 38 (nằm ngay trong file) đã tự liệt kê rõ SDXL còn Phase 2/3.
Đã sửa: xác nhận lại SDXL mới có Phase 1 (tầng dữ liệu) bằng grep — 0 kết
quả `ImageModelTier`/`modelTierOverride` ngoài khai báo. Phát hiện thêm
1 bug: comment cạnh `modelTierOverride` hứa "chọn SDXL sẽ bị log cảnh báo
rồi rơi về SD1.5" nhưng KHÔNG có code nào làm việc đó — đã implement thật
(field `modelTier` trong `Effective`, tính ở `resolveEffective()`, log
cảnh báo nếu resolve ra SDXL — KHÔNG đổi hành vi sinh ảnh vì chưa có
nhánh dispatch nào đọc field này). Cũng cập nhật `HUONG_DAN_SU_DUNG.md`/
`HelpScreen.kt` cho đúng 5 pipeline nhiều-nhân-vật đã có (mask/regional/
regional-mask/triple-combo/depth) — 2 tài liệu này bị bỏ quên từ mục 34.

**Bài học**: 1 audit phạm vi hẹp không được kết luận thay cho toàn dự án
bằng câu "không còn gì tồn đọng" trừ khi thật sự quét lại TOÀN BỘ mục còn
mở, kể cả các mục Phase-based dở dang.

## 43. SDXL Phase 2a/2b — IP-Adapter + ControlNet-Pose cơ bản (1 nhân vật)

Tra cứu trước khi viết (đổi hẳn bức tranh rủi ro, tránh ít nhất 1 bug):
ControlNet SDXL cần `added_cond_kwargs` riêng (khác SD1.5); IP-Adapter
SDXL dùng OpenCLIP-ViT-bigG-14 nhưng API diffusers giống hệt SD1.5 (tái
dùng được `ImageEncoderForExport`); có tiền lệ THẬT export tổ hợp
SDXL+IP-Adapter+ControlNet lên HuggingFace (bác bỏ ghi chú cũ trong
`NOTICE_local-dream.md`); wiki chính chủ **local-dream** ghi rõ SDXL "chỉ
hỗ trợ từ Snapdragon 8 Gen 3" — bằng chứng thật củng cố rủi ro hiệu năng
CPU đã nêu từ mục 3 (tương ứng mục 59 bản đầy đủ).

Đã viết: `tools/export_ipa_controlnet_unet_sdxl.py`, `ip_adapter_sdxl.cpp`
(`IpImageEncoderSdxl` + `PipelineSdxlCpuAugmented` + 3 hàm JNI), thêm hook
`onBeforeUnetRun()` vào `PipelineSdxlCpu.hpp` (rỗng mặc định — không đổi
hành vi base SDXL cũ). Vá thêm 1 gap khác tìm thấy khi viết:
`export_sdxl_base.py` (mục 3/59) **chưa từng nối vào `prepare_models.yml`**
— cùng loại bug mục 41 vừa vá cho 5 script khác. Đóng gói riêng thư mục
`sdxl_augmented/` (SDXL dùng TRÙNG TÊN 5 file với SD1.5 — copy phẳng sẽ
âm thầm đè). **PHẠM VI CỐ Ý HẸP**: chỉ 1 nhân vật, KHÔNG depth/mask/
regional/decay — tránh nhồi hết rủi ro cùng lúc.

## 44. SDXL Phase 2c/2d/2e/2f — Mask N-người, Regional cột, Regional-Mask, Depth ControlNet

Theo yêu cầu "làm hết đừng hỏi lại" — viết tiếp 4 biến thể còn lại, mirror
đúng 4 file SD1.5 tương ứng:
- **Mask N-nhân-vật**: `export_ipa_controlnet_mask_unet_sdxl.py` +
  `setConditioningMultiCharacter()`/JNI mới trong `ip_adapter_sdxl.cpp`
  (tái dùng hook mục 43, không cần sửa `.hpp` lần nữa).
- **Regional cột**: phát hiện kiến trúc quan trọng TRƯỚC khi viết — bản
  Regional KHÔNG dùng hook nhẹ (input tên hoàn toàn khác), phải override
  thẳng `beginDenoise()`/`runUnetStep()` như bản SD1.5 — cần sửa
  `PipelineSdxlCpu.hpp` (`private`→`protected` cho các path field, thay
  đổi AN TOÀN chỉ mở rộng quyền truy cập) trước khi viết
  `regional_prompting_sdxl.cpp`.
- **Regional-Mask**: copy cấu trúc từ bản cột SDXL vừa viết (đúng cách
  bản SD1.5 cũng làm) — `regional_mask_prompting_sdxl.cpp`.
- **Depth ControlNet**: `export_ipa_controlnet_depth_unet_sdxl.py` + sửa
  THÊM tham số `depthHintRgb` (tuỳ chọn, default rỗng) vào hàm JNI ĐàCÓ
  từ Phase 2a — an toàn vì hàm đó chưa có caller nào khác.

**Tổng kết loạt 4**: 5 file Python export mới, 4 file C++ mới/sửa, 16 file
`.cpp` khớp `CMakeLists.txt`, 51 hàm JNI khớp `NativeBridge.kt`, 27 input
trong `prepare_models.yml`. TOÀN BỘ CHƯA BUILD-TEST. **KHÔNG nối dispatch
tự động (Phase 3)** — cố tình để dành, tránh thêm "vỏ rỗng" vào
`model_manifest.json` trước khi Phase 2 build-test được.

## 45. Rà soát đồng bộ tài liệu↔code cho loạt SDXL (mục 43/44)

Đối chiếu content-based (grep "mục 177"-"mục 181" trong toàn bộ cây
nguồn) xác nhận 14 file mang dấu vết sửa khớp đúng danh sách đã ghi,
không thiếu không thừa. Tìm được 1 chỗ lệch: comment cạnh
`ImageModelTier`/`modelTierOverride` (Models.kt, viết ở mục 38 TRƯỚC khi
Phase 2 tồn tại) vẫn nói "chưa có dòng code sinh ảnh SDXL nào" — SAI sau
khi mục 43/44 viết xong Phase 2. Đã sửa lại cho đúng: Phase 2 (mask/
regional/regional-mask/depth) đã viết xong ở TẦNG CODE nhưng CHƯA
build-test VÀ CHƯA dùng để dispatch (đó là Phase 3, vẫn chưa làm) — giữ
nguyên phần đúng (đặt SDXL vẫn chỉ log cảnh báo, không đổi hành vi sinh
ảnh thật).

## 46. Audit độc lập lại toàn bộ dự án theo yêu cầu "đọc kỹ tài liệu, hoàn thiện phần dang dở, kiểm tra UI/nối dây/đồng bộ" — phiên mới, không có ngữ cảnh liên tục

Phiên hoàn toàn mới (không nhớ các đợt 21-23 ở trên) — đọc lại TOÀN BỘ
`TECHNICAL_STATUS.md` (182 mục bản đầy đủ) từ đầu, rồi tự đối chiếu ĐỘC
LẬP với code thật (không tin lại các dòng "đã sửa"/"đã khớp" của chính
tài liệu) theo đúng phương pháp mục 41/45 đã áp dụng. Đã kiểm tra lại,
bằng script/grep trực tiếp (không suy đoán):

- **`add_library()` ↔ `.cpp` thật**: 16/16 khớp (không có file nào bị bỏ
  sót giống lỗi mục 41 đã tìm cho `regional_mask_prompting.cpp`).
- **`external fun` (NativeBridge.kt) ↔ `JNIEXPORT` (toàn bộ `.cpp`)**:
  51/51 khớp tên chính xác, đối chiếu 2 chiều bằng `comm`.
- **`torch.onnx.export()` ↔ `dynamo=False`**: đối chiếu lại cho cả 14
  script export (kể cả 5 script SDXL viết ở mục 43/44, ra đời SAU phát
  hiện `dynamo=False` ở mục 14/15 — kiểm tra riêng vì có khả năng bị bỏ
  sót cho script mới) — TẤT CẢ đều có `dynamo=False` đúng số lệnh gọi,
  không sót.
- **Nav routes** (`MainActivity.kt` `composable(...)`): không có route mồ
  côi, không có màn hình không route tới được.
- **`prepare_models.yml`/`build.yml`** (2 file sống ngoài zip, người dùng
  gửi kèm riêng lần này): đối chiếu nội dung thật với từng mục tài liệu
  liên quan (mục 41/43/44 trên) — khớp đầy đủ, không lệch (khác tình
  trạng mục 41 từng phát hiện — file lần này ĐÃ được cập nhật đúng).

**Bug thật duy nhất tìm được (đã sửa)**: mục 44 (Regional cột SDXL, ứng
mục 179 bản đầy đủ) tự nhận "Regional SD1.5 (`sdInitRegional`) CHÍNH NÓ
chưa từng có call site nào từ Kotlin (mục 61)" khi giải thích vì sao bản
SDXL kế thừa tình trạng "chưa nối dispatch" — **SAI**, đây là trạng thái
RẤT CŨ (mục 61 bản đầy đủ), đã được nối dispatch từ lâu (mục 69, qua
nhánh `useRegional` trong `MangaPipeline.generatePanels()`/
`regeneratePanel()`, xác nhận lại đúng mục 28 file này/mục 148 bản đầy
đủ: "generatePanelRegional() — 3 call site — khớp"). Grep thật xác nhận
≥5 call site `loadSDRegional()`/`generatePanelRegional()` trong
`MangaPipeline.kt`. Đã sửa lại đoạn đó trong `TECHNICAL_STATUS.md` (mục
179) — kết luận "bản SDXL vẫn chưa nối Phase 3" KHÔNG đổi, chỉ sai lý do
viện dẫn.

**Không tìm thêm được lỗ hổng "chưa nối dây"/"vỏ rỗng" nào khác** trong
phạm vi kiểm chứng tĩnh được (không cần GPU/build/thiết bị thật) — đã
spot-check thêm: UI `AsyncImage` cho `PanelCard`/`EditPanelSheet`/
`BubbleEditCanvas` vẫn đúng như mục 140 bản đầy đủ (không bị revert),
`useRegionalMask`/`useRegional` vẫn dùng `sceneChars.size >= 2` xuyên
suốt (không tái phát bug hardcode `2..4` của mục 36), `RegionalColumnEditor`
vẫn được gọi từ `GalleryReviewScreen.kt`, `useStoryDiffusion` có Switch
thật trong `SettingsScreen.kt`, `Scene.characterExpressions` (mục 35) VẪN
CHƯA có UI riêng để xem/sửa tay (chỉ có ở tầng dữ liệu/LLM — cùng loại
giới hạn đã ghi từ mục 12 cho field `expression` đơn, escape hatch vẫn là
ghi đè cả `promptOverride`) — ghi nhận là giới hạn ĐÃ BIẾT, không phải
phát hiện mới, không sửa (thêm UI mới cho field hẹp này là việc riêng,
ngoài phạm vi 1 lượt audit).

## 47. TECHNICAL_STATUS_SUMMARY.md (file này) viết lại đủ mục 41-46 — đóng gap tự cảnh báo từ mục 22/38/42

Chính file tóm tắt này đã tự nhận lệch (banner đầu file, đặt từ đợt viết
mục 37/174 bản đầy đủ) — "nếu chưa thấy mục tương ứng ở đây, coi là chưa
cập nhật". Đợt audit mục 46 (bản đầy đủ: mục 183) đã viết đủ mục 41-46
phủ tới mục 182 bản đầy đủ — banner đầu file cập nhật lại mốc mới.

**Trạng thái tồn đọng thật hiện tại (đối chiếu lại toàn bộ mục 13, không
chỉ copy)**: không đổi so với mục 45 — (1) SDXL Phase 3 (dispatch +
UI chọn tier) vẫn chưa làm, chờ Phase 2 build-test; (2) build CI thật
+ chạy `prepare_models.yml` thật (27 input SDXL + N-nhân-vật tuỳ ý) +
sinh ảnh thật trên thiết bị — vẫn là việc DUY NHẤT xác nhận được chất
lượng/hiệu năng, không có cách nào làm thay trong sandbox; (3)
`minifyEnabled` vẫn tắt (chờ build thật xác nhận R8 không phá JNI); (4)
QNN runtime `.so` thật — cần QNN SDK + thiết bị Snapdragon thật, ngoài
khả năng sandbox; (5) `Scene.characterExpressions` chưa có UI riêng
(mục 46) — ưu tiên thấp, có escape hatch. Không có việc thuần
code/tài liệu nào khác còn tồn đọng trong PHẠM VI đã audit ở mục 46 —
không khẳng định đây là danh sách tuyệt đối đầy đủ cho toàn bộ dự án
(đúng bài học mục 42 đã tự rút ra, tránh lặp lại chính lỗi đó).

## 48. SDXL Phase 3 — nối dispatch thật + UI (user chỉ ra đúng: "chưa nối dispatch" là code thuần, không phải hạ tầng)

Viết `MangaPipeline.dispatchSdxlPanel()` (hàm CHUNG cho cả 2 call site,
mirror ưu tiên SD1.5: mask N-người > regional-mask > regional cột >
augmented 1-người), thêm `GenerationSettings.sdxlModelId` + 4 hàm
`has*Sdxl*Unet()` (StoryManager.kt) + thẻ Cài đặt "SDXL (thử nghiệm)"
mới. Nối vào `generatePanels()`/`regeneratePanel()` với ưu tiên CAO NHẤT
khi `modelTier=SDXL`, tự rơi về SD1.5 nếu thiếu điều kiện (không throw).
Sửa 2 chỗ tài liệu SAI-vì-lỗi-thời (không sai logic lúc viết, chỉ chưa
cập nhật khi Phase 3 xong): comment `ImageModelTier`, field
`Effective.modelTier`/log `resolveEffective()`.

**GIỚI HẠN THẬT — CỐ Ý HẸP**: KHÔNG Quality Gate/FleshDeformationEngine/
autoFixInteractions/Multi-Pass Cascade cho SDXL; độ phân giải cố định
1024×1024; không đọc `characterOverride`; chưa có UI batch-chọn theo
panel (chỉ Switch GLOBAL); ô nhập `sdxlModelId` là text thuần không
validate. **CHƯA build-test** — rủi ro CHỒNG 2 tầng (Phase 2 chính nó
cũng chưa chạy thử thật + phần dispatch mới này) — cao hơn các thay đổi
"chưa build-test" khác trong dự án. Chi tiết đầy đủ: mục 184 bản đầy đủ.

## 49. Trả lời câu hỏi user về "yêu cầu chất lượng đầu ra" + phát hiện bug retry-loop lãng phí + vá UI Quality Gate chưa từng hiện

Đào sâu `QualityGateChecker` (mục 74) để trả lời đúng: yêu cầu chất
lượng = 2 tiêu chí (số người khớp kỳ vọng, tỷ lệ xương ≤3.0× tham chiếu)
— **chỉ đánh giá KHUNG XƯƠNG ĐẦU VÀO, không đọc pixel ảnh đã sinh**.
**Phát hiện quan trọng**: vì khung xương là hàm thuần (không phụ thuộc
seed), retry loop (MAX_RETRY=3) cho kết quả ĐÁNH GIÁ giống hệt ở cả 3
lần — 2 lần retry sau LÃNG PHÍ hoàn toàn (không bao giờ được chọn, do so
sánh `<` chặt với score y hệt). Bug thật, độc lập SDXL, CHƯA SỬA (cố ý —
chạm 5 vòng lặp gần giống hệt nhau, rủi ro cao hơn lợi ích lúc này).

**Quy trình thay thế ĐÃ LÀM THẬT**: sau khi SD1.5 chạy đủ (5 nhánh) mà
vẫn `!panelQualityGatePassed` (và không phải user đã tự chọn SDXL), thử
`dispatchSdxlPanel()` 1 lần làm thay thế. KHÔNG đánh giá lại bằng Quality
Gate (vô nghĩa — cùng khung xương, cùng score) — chỉ đánh cược có chủ
đích, giữ nguyên `passed=false` sau đó, chỉ thêm dòng lý do. Chỉ áp dụng
`generatePanels()` — `regeneratePanel()` không hề chạy Quality Gate nên
không có gì để thay.

**Vá thêm 1 "vỏ rỗng" thật**: `qualityGatePassed`/`qualityGateReasons` đã
tính từ mục 74 nhưng CHƯA từng hiện ở UI nào (0 kết quả grep) — thêm
badge ở `PanelCard()` + chi tiết đầy đủ ở `EditPanelSheet()`. Chi tiết
đầy đủ: mục 185 bản đầy đủ.

## 50. Sửa bug retry-loop lãng phí (mục 49 phát hiện) — cả 5 vị trí, user chọn làm luôn

Thêm `break` ngay sau log cảnh báo Quality Gate ở cả 5 vòng lặp
(triple-combo/multichar/regional-mask/regional/1-người) — dừng ngay lần
thử đầu thất bại thay vì lặp mù thêm 2 lần vô ích (kết quả không đổi vì
khung xương đánh giá lại y hệt). Hành vi CUỐI không đổi, chỉ tiết kiệm
compute. Chi tiết: mục 186 bản đầy đủ.

## 51. THIẾT KẾ LẠI Quality Gate — đánh giá khung xương TRƯỚC khi sinh ảnh (theo đúng góp ý user)

User chỉ ra: khung xương phải được duyệt TRƯỚC khi "đắp thịt" sinh ảnh,
không phải sinh ảnh RỒI mới đánh giá như thiết kế gốc (mục 74) và bản vá
mục 186. Đã thiết kế lại cả 5 nhánh (MangaPipeline.kt): bỏ hẳn vòng lặp
`for (attempt in 0 until MAX_RETRY)`, thay bằng đánh giá khung xương 1
LẦN TRƯỚC khi gọi hàm sinh ảnh, sinh ĐÚNG 1 lần (biết trước kết quả),
gán `panelQualityGatePassed` trực tiếp từ kết quả đánh giá trước đó. Kết
quả cuối không đổi so với sau mục 186 (vẫn sinh 1 lần), nhưng giờ KHÔNG
còn hiểu nhầm "chọn ảnh tốt nhất trong nhiều lần" (vô nghĩa — mục 185) —
thẳng thắn đánh giá trước, sinh sau. Cập nhật docstring
`QualityGateChecker.kt`/comment `enableQualityGate` (Models.kt) cho khớp
thiết kế mới; giữ hằng số `MAX_RETRY` (không xoá) nhưng ghi rõ không còn
dùng để lặp. Bỏ biến `firstPassPerfect` (dead code từ mục 74, chưa từng
được đọc). Chi tiết đầy đủ: mục 187 bản đầy đủ.

## 52. UI batch-chọn model tier THEO TỪNG PANEL (đóng gap mục 183/184/185 nhiều lần ghi nhận)

`PanelOverrideSettings.modelTierOverride` (Phase 1, mục 171) chưa từng
có nút bấm đặt giá trị — chỉ đọc được, chưa ghi được. Đã thêm 3
`FilterChip` (Tự động/SD1.5/SDXL) trong `EditPanelSheet`
(`GalleryReviewScreen.kt`), nối vào `PanelOverrideSettings(...)` khi
"Vẽ lại". Dùng chung luồng `regeneratePanel()` có sẵn, không sửa gì
tầng pipeline. Chi tiết: mục 188 bản đầy đủ.

## 53. Tùy chọn độ phân giải SDXL (768/1024), KHÔNG có 512 — trả lời câu hỏi user về hiệu năng

User hỏi sao không hạ SDXL xuống 512×512 cho nhẹ. Tra cứu: SDXL không có
bucket huấn luyện vuông nào dưới 1024² — cộng đồng ghi nhận 512×512 sinh
lỗi giải phẫu (nhân đôi người/chi thể), khuyến nghị không dưới 768. Đã
thêm `GenerationSettings.sdxlResolution` (768/1024, không cho 512) +
UI chọn trong Cài đặt. Chi tiết: mục 189 bản đầy đủ.

## 54. Rà soát chủ động sau loạt sửa 184-189 — vá 3 câu lỗi thời (comment mục 185, HUONG_DAN_SU_DUNG.md, README.md)

Tự rà lại (không đợi user chỉ ra) sau mục 189, tìm 3 chỗ còn nói "chạy
đủ MAX_RETRY lần"/"độ phân giải cố định 1024×1024" — lỗi thời do chính
mục 187/189 gây ra mà chưa cập nhật hết nơi tham chiếu. Đã sửa cả 3.
Chi tiết: mục 190 bản đầy đủ.

## 55. PHÁT HIỆN + VÁ LỖ HỔNG THẬT ở mục 189 — UI cho chọn 768 nhưng workflow không export ra được file 768

Tự rà lại chính tính năng mục 189 vừa làm, phát hiện lỗ hổng nghiêm
trọng: UI cho chọn "768×768" nhưng `prepare_models.yml` KHÔNG hề truyền
`--image_size` cho 5 script export SDXL — luôn ra file 1024 bất kể chọn
gì. Vì model `.mnn` SDXL export CỐ ĐỊNH 1 shape (không dynamic_axes, mục
52b), chọn sai sẽ lệch shape → lỗi/crash lúc infer thật. Đã thêm input
`sdxl_image_size` vào workflow (dùng chung cho cả 5 script), cảnh báo rõ
trong UI phải khớp đúng lúc export, và log rõ độ phân giải đang dùng để
dễ debug. Vẫn KHÔNG có cách app tự xác nhận file thật khớp — giới hạn
còn lại, không giấu. Chi tiết: mục 191 bản đầy đủ.

## 56. Giải quyết giới hạn thật mục 191 — model SDXL tự "khai báo" độ phân giải, app tự đọc thay vì tin trí nhớ user

User hỏi sao không giải quyết giới hạn còn lại. Đã làm: `prepare_models.yml`
ghi file marker `sdxl_resolution.txt` (độ phân giải thật) vào thư mục
export SDXL — tự phát hiện thêm 1 lỗ hổng ngay lúc viết (marker không
được copy vào bản `release/` cuối, đã vá luôn). `StoryManager.readSdxlExportedResolution()`
đọc marker, `dispatchSdxlPanel()` ƯU TIÊN giá trị thật này thay vì tin
Cài đặt — tự sửa + cảnh báo nếu lệch. UI hiện luôn độ phân giải thật.
Cân nhắc rồi KHÔNG chọn cách đọc shape qua JNI mới (rủi ro cao hơn) —
chọn marker file (rủi ro thấp, giải quyết đúng root cause cho model
export từ giờ trở đi). Model export TRƯỚC mục này vẫn không giải quyết
được (không hồi tố được). Chi tiết: mục 192 bản đầy đủ.

## 57. Tìm hướng khác giải quyết TIẾP giới hạn mục 192 — model thiếu marker suy luận chắc chắn là 1024

User hỏi đúng: nếu "không giải quyết được" thì tìm hướng khác. Insight:
`--image_size`/marker chỉ mới có từ mục 191/192 — TRƯỚC đó
`prepare_models.yml` không bao giờ truyền tham số này, nên MỌI model
thiếu marker CHẮC CHẮN là 1024 (giá trị mặc định DUY NHẤT từng có thể
export ra). Đã sửa `dispatchSdxlPanel()`: thiếu marker → mặc định THẲNG
1024 (không còn tin mù Cài đặt), có lối thoát cho trường hợp hiếm (tự
export tay ngoài workflow: tự tạo file marker để ghi đè). Trường hợp
phổ biến nay giải quyết HOÀN TOÀN; chỉ còn đúng 1 trường hợp biên thật
sự không giải quyết được (tự chạy tay + không đọc hướng dẫn). Chi tiết:
mục 193 bản đầy đủ.

## 58. Rà soát tiếp — vá 4 docstring còn sót "1024 cố định"/"Phase 3 chưa làm" trong ImagePipeline.kt + PipelineSdxlCpu.hpp

Tiếp tục tự rà (mở rộng sang ImagePipeline.kt, chưa rà ở mục 54). Vá 3
docstring hàm SDXL (còn nói "Phase 3 chưa làm" sai từ mục 184, "1024 cố
định" thiếu chính xác từ mục 189) + 1 comment PipelineSdxlCpu.hpp (bổ
sung 768 cũng dùng được, cẩn thận không nhầm với "768-dim" của CLIP-L
gần đó — khái niệm khác hẳn). Chi tiết: mục 194 bản đầy đủ.

## 59. Rà "1024" toàn repo — vá 1 chỗ thật, điều tra kỹ 2 chỗ tưởng liên quan nhưng KHÔNG phải (tránh sửa nhầm)

M�� rộng grep "1024" ra toàn repo. Vá 1 chỗ thật: `GalleryReviewScreen.kt`
(cảnh báo per-panel SDXL còn nói "cố định 1024"). Điều tra kỹ 2 chỗ
khác trước khi kết luận: `mobile_sam_wrapper.cpp` (1024 là kích thước
cố định của chính kiến trúc MobileSAM, không liên quan) và
`sd_engine/Pipeline.hpp` (base class thật của `PipelineSdxlCpu` — nhưng
"forced to 1024" ở đây thuộc field `ultrafix_tile`/nhánh NPU "sd15npu"
CHƯA TỪNG VIẾT theo chính tài liệu đã ghi nhận, khác hẳn field
`width`/`height` mà `dispatchSdxlPanel()` dùng) — KHÔNG sửa 2 file này.
Bài học: grep tìm ứng viên, không tự động là lỗi — phải đọc ngữ cảnh.
Chi tiết: mục 195 bản đầy đủ.

## 60. UI hiển thị (chỉ đọc) biểu cảm LLM tự phân loại — đóng gap cuối cùng còn treo từ mục 183

`Scene.characterExpressions`/`expression` chưa từng hiện ở UI nào (grep
xác nhận). Thêm khối chỉ đọc trong `EditPanelSheet`, cảnh báo nếu
`enableMultiPassCascade` tắt (field mất tác dụng). Không thêm ô sửa tay
riêng — escape hatch vẫn là ghi đè `promptOverride` như đã ghi từ mục
98/183 (phạm vi cố ý hẹp). Chi tiết: mục 196 bản đầy đủ.

## 61. Ô sửa tay THẬT cho biểu cảm riêng từng người — user chỉ ra: chỉ hiển thị (mục 60) chưa đủ

Thêm `PanelOverrideSettings.characterExpressionOverrides` (Models.kt),
merge vào call site `runMultiPassCascade()` (override thắng cho tên
trùng, người khác giữ nguyên LLM). UI: mỗi người trong panel ≥2 nhân
vật có 1 hàng FilterChip chọn biểu cảm (12 lựa chọn + "Theo LLM"), thay
hẳn khối chỉ-đọc cũ. Không cần ghi đè cả prompt nữa. Chi tiết: mục 197
bản đầy đủ.

## 62. BUG THẬT tự phát hiện — regeneratePanel() chưa từng chạy Multi-Pass Cascade (tồn tại từ mục 168, lộ ra khi mục 197 làm nó quan trọng)

Ngay sau khi xây UI sửa biểu cảm (mục 61/197), tự kiểm tra thì phát hiện
`regeneratePanel()` CHƯA TỪNG gọi `runMultiPassCascade()` — nghĩa là
biểu cảm chọn ở UI mới hoàn toàn KHÔNG có tác dụng khi bấm "Vẽ lại" (dù
lưu đúng, dù hiện đúng). Bug cũ từ mục 168, chỉ vô hại tới giờ vì trước
đó không ai chỉnh được field này để nhận ra. Đã thêm đúng khối cascade
(mirror `generatePanels()`) vào `regeneratePanel()`. Khác quyết định
"giữ đơn giản" của Quality Gate (mục 172, vô hại vì retry không đổi
được gì) — cascade CÓ tác dụng thật, bỏ nó là mất tính năng chứ không
phải tối ưu. Chi tiết: mục 198 bản đầy đủ.

## 63. BUG THẬT thứ 2 tự phát hiện — regeneratePanel() cũng chưa từng chạy tryAutoFixInteractions() ở BẤT KỲ nhánh nào

Ngay sau mục 62/198 (Cascade), rà tiếp thì phát hiện `tryAutoFixInteractions()`
(auto-sửa vùng tay/hông chồng lấn ≥2 người) CŨNG chưa từng chạy ở cả 5
nhánh của `regeneratePanel()` — bật tính năng này ở Cài đặt hoàn toàn vô
tác dụng khi dùng "Vẽ lại". Đã vá cả 5 nhánh, đúng thứ tự (autoFix trước
Cascade cho nhánh multiChar, khớp `generatePanels()`). Cùng bài học mục
62: quyết định "giữ regeneratePanel() đơn giản" chỉ đúng cho Quality
Gate (vô hại), bị áp dụng nhầm sang 2 tính năng có tác dụng thật khác.
Đã rà đủ 3 tính năng hậu-xử-lý đa nhân vật, không còn sót. Chi tiết: mục
199 bản đầy đủ.

## 64. Làm rõ + vá gap thật — badge Quality Gate không tự cập nhật sau "Vẽ lại"

User hỏi đúng: bỏ Quality Gate retry-loop ở regenerate KHÔNG có nghĩa
panel "hoàn hảo lần đầu" — làm rõ: chỉ vòng lặp tự động là vô ích (mục
185), user tự nhìn ảnh khi bấm Vẽ lại mới là bước kiểm tra thật. Đào sâu
tìm ra gap thật: badge Quality Gate không tự tính lại sau Vẽ lại — nếu
đổi pose lúc regenerate, badge cũ sai lệch với ảnh mới. Đã vá: tính lại
1 lần (không lặp) bằng khung xương mới trước khi trả về panel. Chi tiết:
mục 200 bản đầy đủ.

## 65. Bao lồi (convex hull) thay hình chữ nhật cho mask "trước-khi-có-ảnh" — cả C++ lẫn Kotlin

Làm rõ 2 loại mask khác nhau (SAM cho Cascade — có ảnh sẵn; hình học
thô cho mask N-người/Regional-Mask — tính TRƯỚC khi có ảnh, SAM không
dùng được về mặt logic). Đã nâng cấp loại (2) từ hình chữ nhật lên bao
lồi (convex hull, Andrew's monotone chain) — bám hướng dáng người thật
thay vì luôn thẳng trục. Làm ở CẢ 2 nơi: Kotlin (`MangaPipeline.kt`,
dùng `Canvas.drawPath()` có sẵn) và C++ (`ip_adapter.cpp`, phải tự viết
thêm `fillConvexPolygon()` scanline riêng — không có Canvas API ở
native). Vẫn không phải segmentation thật (không lõm được ở khoảng
trống giữa chi) — cải thiện hình học, không phải giải quyết triệt để.
Phần C++ CHƯA build-test — rủi ro cao nhất trong toàn bộ phiên vì là
thuật toán native hoàn toàn mới. Chi tiết: mục 201 bản đầy đủ.

## 66. KIỂM CHỨNG BẰNG THỰC NGHIỆM THẬT cho convex hull mask (mục 65/201) — dùng g++ có sẵn trong sandbox

Phát hiện sandbox có `g++`. Trích xuất Y NGUYÊN VĂN 3 hàm convex hull/
fillConvexPolygon/renderCharacterMask từ `ip_adapter.cpp`, biên dịch +
chạy 6 bài test thật (không phải suy luận): hull đúng cho hình vuông,
suy biến đúng cho điểm thẳng hàng, tư thế đứng cho silhouette hợp lý,
**tư thế nghiêng chỉ tô 7% diện tích so với hình chữ nhật cũ** (bằng
chứng thực nghiệm cho đúng lợi ích đã tuyên bố), 2 edge case an toàn.
Biên dịch sạch, cả 6 PASS. Đưa `tools/test_convex_hull_mask.cpp` vào dự
án làm công cụ tái sử dụng nếu sửa lại sau này. Vẫn KHÔNG thay thế được
build-test thật (không kiểm tra tích hợp MNN/JNI/thiết bị) nhưng giảm
rủi ro thật cho đúng phần thuật toán mới nhất, rủi ro cao nhất. Chi
tiết: mục 202 bản đầy đủ.

## 67. Audit độc lập mới (phiên mới hoàn toàn) — 2 gap THẬT, đã vá cả 2

Đọc lại toàn bộ 202 mục trước, tự đối chiếu độc lập với code thật (không
tin lại lời tài liệu tự nhận) — không tìm thêm sai lệch nào khác ngoài
đúng 2 gap sau, cả 2 đều xác nhận CÓ THẬT rồi vá ngay trong cùng phiên:

1. **`prepare_models.yml` sống ngoài zip LẠI lệch bản** (tái diễn đúng
   loại lỗi mục 62/63) — bản user giữ riêng thiếu toàn bộ phần vá SDXL
   resolution của mục 191/192 (0/12 chỗ `image_size` so với bản trong
   zip) → tuỳ chọn 768×768 không dùng được (nhưng không sinh ảnh lỗi, app
   tự ép 1024 khi thiếu marker). Đã đưa lại đúng file từ zip + thêm cách
   tự kiểm tra vào `HUONG_DAN_SU_DUNG.md`.
2. **`HUONG_DAN_SU_DUNG.md`/`HelpScreen.kt` dừng ở mục 184**, thiếu 18
   mục (185-202) — trong đó 3 việc là UI thật (badge Quality Gate + SDXL
   thay thế, model tier riêng panel, biểu cảm riêng từng nhân vật). Đã
   viết bổ sung vào Bước 6 + mục 2 của HDSD, và `HelpStep(7,...)` của
   Help trong app.

Thay đổi lần này thuần văn bản (trừ chuỗi text trong `HelpStep`, đã tự
đối chiếu cân bằng ngoặc, không đổi logic). Chi tiết đầy đủ: mục 203 bản
đầy đủ.
