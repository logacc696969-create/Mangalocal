# MangaLocal — Trạng thái kỹ thuật (bản tóm tắt theo hệ thống con)

> **Bản NGẮN, đọc nhanh** — tổ chức theo hệ thống con, cắt lược phần
> tường thuật "lần 1 sai → lần 2 sửa" xuống còn trạng thái CUỐI CÙNG.
> **Nếu cần KHÔNG mất bất kỳ chi tiết nào (mọi quyết định, mọi bug, mọi
> nghiên cứu, đúng thứ tự thời gian) — đọc `TECHNICAL_STATUS.md` thay vì
> file này.** File đó giữ nguyên toàn bộ 145 mục gốc, chỉ dọn đúng phần
> chữ lặp lại y hệt (~0.3% dung lượng — số đo thật, xem ghi chú đầu file
> đó). File này là bản tóm tắt PHỤ, giúp đọc nhanh, không phải bản thay
> thế duy nhất.

---

## 0. SỰ THẬT BAO TRÙM TOÀN BỘ DỰ ÁN — đọc mục này trước mọi mục khác

**Chưa từng có 1 lần build CI PASS HOÀN TOÀN từ đầu đến cuối trong lịch sử
dự án** (kể cả chỉ tính compile, chưa nói chạy sinh ảnh thật):
- 5 lần build CI thật đã chạy (build #34/#38/#41/#44/#47), sửa bug dựa
  trên log thật — nhưng chuỗi sửa DỪNG GIỮA CHỪNG ở build #47, chưa xác
  nhận lại.
- **Mọi dòng code viết SAU đó (tuyệt đại đa số dự án — Remote GPU, Depth
  ControlNet, IP-Adapter mask N-người, Regional Prompting, Industrial
  Batch Mode, toàn bộ pose retargeting...) CHƯA TỪNG qua compiler nào** —
  chỉ soát bằng đọc lại thủ công + đếm ngoặc bằng script, và 1 lần duy
  nhất cài `kotlinc` thật (dùng stub `kotlinx.coroutines`) để verify
  riêng `LLMParser.kt`.
- Compile pass (nếu có) cũng KHÁC HẲN "chạy đúng" — chưa xác nhận chất
  lượng ảnh, shape tensor, hay hiệu năng thật trên máy.

**Việc DUY NHẤT quan trọng hơn mọi tính năng khác**: build CI thật lần
đầu (`build.yml`), rồi chạy thật trên thiết bị (khuyến nghị: ASUS Zenfone
8, 16GB RAM — máy dev chính đã xác định). Đọc phần còn lại với tinh
thần: **"đã làm/đã triển khai" = "đã viết code + tra cứu API thật, không
đoán" — không phải "đã chạy đúng".**

---

## 1. Kiến trúc & stack tổng quan

| Thành phần | Engine | Trạng thái |
|---|---|---|
| LLM (parse truyện) | MNN-LLM | Port xong, fallback QNN→OpenCL→CPU runtime thật |
| SD1.5 (CPU/OpenCL) | MNN-Diffusion, port từ local-dream | Nhiều pipeline con, mục 3 |
| SDXL (CPU/OpenCL) | MNN-Diffusion, viết mới | Chỉ nền tảng txt2img, mục 3.5 |
| NPU (QNN) | MNN backend built-in (`MNN_FORWARD_NN`) | Cascade NPU→GPU→CPU đã code, mục 8 |
| Upscale | MNN (ESRGAN, 4x-UltraSharp) | Mục 4 |
| Bubble thoại | MNN (YOLOv8n) | Hoạt động |
| Nhất quán nhân vật | LoRA / IP-Adapter / Textual Inversion | Mục 5 |
| Tư thế | ControlNet-OpenPose, trích bằng YOLOv8-pose | Mục 6 |

**File jni/ chính**: `jni_bridge.cpp` (LLM), `mnn_diffusion_pipeline.cpp`
(SD1.5/SDXL cơ bản + img2img/ultrafix), `ip_adapter.cpp` (augmented:
IP-Adapter + ControlNet Pose/Depth + mask N-người), `regional_prompting.cpp`,
`esrgan_wrapper.cpp`, `yolo_wrapper.cpp`, `yolo_pose_wrapper.cpp`,
`mobile_sam_wrapper.cpp`, `sd_model_converter.cpp`, `sd_engine/` (port từ
local-dream, CC BY-NC 4.0, MangaLocal miễn phí 100%).

**2 chỗ sửa so với local-dream gốc** (bắt buộc ghi vì license):
`PipelineSd15Cpu.hpp` đổi 1 số field `private`→`protected` + hook ảo
`onBeforeUnetRun()`; `SDUtils.hpp` bỏ `STB_..._IMPLEMENTATION` (dồn vào
`stb_impl.cpp` riêng, tránh duplicate symbol).

---

## 2. Build system — lịch sử CI (rút gọn)

5 lần build CI thật, mỗi lần lộ 1 lớp lỗi mới:

1. **#29→#34**: CMake `[CXX1429]` (2 target `OBJECT` của MNN không được
   gắn `POST_BUILD`) — vá `sed` đổi `OBJECT`→`STATIC`, có `grep -q` tự
   báo lỗi nếu MNN đổi cấu trúc.
2. **#34→#38**: `xtensor/xadapt.hpp` not found (xtensor ≥0.26 đổi cấu
   trúc thư mục) — ghim cứng 4 version (`xtensor 0.25.0`/`xtl 0.7.7`/
   `xsimd 10.0.0`/`xtensor-blas 0.21.0`), verify từng header bằng
   `git show <tag>:<path>`. **MNN vẫn KHÔNG ghim version** — rủi ro
   tương tự có thể lặp lại.
3. **#38**: `SafeTensorReader.hpp` include `"json.hpp"` sai — sửa
   `#include <nlohmann/json.hpp>`.
4. **#41**: build C++ **PASS HOÀN TOÀN lần đầu** — lộ 12 lỗi Kotlin có
   sẵn: `Surface()` positional-param sai thứ tự (9 chỗ/3 file),
   `MlOutlineBtn` thiếu `enabled`, gọi nhầm hàm, dùng type đã xoá, thiếu
   `@OptIn(ExperimentalMaterial3Api)`.
5. **#44**: 7 lỗi Kotlin mới (3 file khác) — import sai vị trí, thiếu
   dấu cách gây hiểu nhầm literal suffix, thiếu `@OptIn` (không tự lan
   sang hàm `private` khác cùng file).
6. **#47**: sót 1 nửa lỗi #44 (2 khối `import` tách rời, chỉ dời 1 khối)
   — bài học: sửa 1 file phải liệt kê TOÀN BỘ vị trí liên quan trước khi
   khẳng định đã xong.

**Sau #47, chuỗi build-fix dừng lại** — mọi thay đổi từ đó tới giờ (đại
đa số dự án) chưa qua bước này lần nào.

---

## 3. Pipeline sinh ảnh SD1.5 — các biến thể

Mỗi UNet augmented là model `.mnn` RIÊNG BIỆT (không dynamic) — app chọn
đúng file theo tình huống panel.

| Model | Input đặc biệt | Dùng khi | Wiring |
|---|---|---|---|
| `unet.mnn` (base) | — | Không cần giữ nhân vật | Có |
| `unet_ipa_controlnet.mnn` | `ip_image_embeds`+`control_hint` | 1 nhân vật cần neo | Có |
| + Depth | + `depth_hint` (suy từ z-khớp xương, không cần model depth riêng) | 2+ người chồng lấn | Tự phát hiện input, tương thích ngược |
| `unet_ipa_mask_controlnet_{N}char.mnn` | N embeds + N masks (bounding-box, không phải segmentation) | N≥2 nhân vật đều cần neo | Có (`generatePanelMultiChar`) |
| Regional Prompting (`regional_prompting.cpp`, pipeline riêng) | N cột prompt CHỮ riêng (chỉ chia cột, chỉ ảnh vuông) | Tách PROMPT CHỮ theo vùng | Có (`generatePanelRegional`) |
| `unet_triple_combo_{N}region.mnn` (`triple_combo.cpp`, pipeline riêng, mục 151/152) | N prompt cột + N ảnh neo + pose_hint + depth_hint CÙNG LÚC | N≥2 nhân vật cần cả 3: giữ mặt + tách prompt + độ sâu | Có (`generatePanelTripleCombo`, ưu tiên cao nhất khi có đủ file model — mục 152), CHƯA build-test/chưa có model .mnn thật |

**Textual Inversion** — phương pháp thứ 3, nhẹ nhất, hoạt động ở CLIP
(không đụng UNet), nhiều trigger word/1 prompt không giới hạn số lượng.
Yếu hơn LoRA/IP-Adapter về giống mặt, hợp nhân vật phụ.

**LoRA (ảnh)** — merge chết vào `.mnn` (khác LoRA của LLM, runtime).
3 kỹ thuật giảm identity-bleeding: **LoRA Block Weight** (giảm hệ số
`down_blocks` còn 0.5, giữ `up_blocks`/`mid_block` ở 1.0 — kinh nghiệm,
không phải số đo khoa học); **Orthogonal LoRA stacking** (Gram-Schmidt
cổ điển lúc merge, mặc định BẬT khi ghép cặp — tra cứu học thuật 2025
xác nhận chỉ giảm 1 dạng nhiễu cụ thể, KHÔNG đảm bảo hết bleeding, phụ
thuộc thứ tự merge); **Regional Prompting + IP-Adapter mask** — mạnh
nhất, tách hẳn theo vùng không gian.

**Multi-ControlNet vs ControlNet-Union**: dùng Multi-ControlNet (nhiều
model cộng residual) cho Pose+Depth. ControlNet-Union CHỈ tồn tại cho
SDXL — không có gì để làm cho SD1.5, gap đã đóng dứt điểm.

**Smooth Timestep Decay cho IP-Adapter** (`tools/ip_adapter_decay.py`) —
scale ĐÚNG output attention, giảm dần theo timestep, kiểm chứng bằng
thực nghiệm ONNX export thật. Nối cả đường 1-người lẫn mask N-người — đây
là cách `consistencyStrength` slider (từng "không có tác dụng") có tác
dụng thật.

**img2img/inpaint/Ultrafix** (`sdImg2Img()`) — nền tảng có sẵn trong
local-dream nhưng chưa từng dùng, đã nối. Resize bilinear tự viết tay.
Dùng cho: Hires-fix (denoise 0.35–0.45), auto-fix mặt/tay, Multi-Pass
Inpainting Cascade (3-4 lượt 0.6→0.2, cảnh đông người).

---

## 3.5. SDXL — chỉ nền tảng, có chủ đích chưa mở rộng

`PipelineSdxlCpu.hpp` cắm vào extension point có sẵn trong
`Pipeline.hpp`/`TextEncoder.hpp` — không phải xây từ số 0.
`sdTxt2Img()`/`NativeBridge.kt` không đổi gì (đã đủ generic).

**CHƯA làm**: IP-Adapter/ControlNet SDXL (checkpoint khác hẳn), LoRA
SDXL (shape khác), Regional Prompting/mask/Orthogonal-LoRA cho SDXL,
`SDXL_PROMPT_GUIDE` riêng.

**ĐÃ làm**: UI đọc `default_width`/`default_height` theo model đang chọn
(`SettingsScreen.kt`, xác nhận qua grep code thật).

**Rủi ro hiệu năng CHƯA ĐO ĐƯỢC** — UNet SDXL ~2.6B tham số (gấp ~3
SD1.5) — CPU thuần có thể chậm tới mức không thực dụng. Đánh giá gốc coi
SDXL "bắt buộc QNN" — vẫn làm CPU-first (đúng nguyên tắc "không hardcode
1 phần cứng") nhưng không hứa tốc độ dùng được.

---

## 4. Post-processing: upscale, auto-fix, inpaint

**Thứ tự chuẩn**: ESRGAN upscale → Ultrafix vẽ lại nhẹ toàn ảnh → auto-fix
mặt/tay ở độ phân giải CUỐI (mask chính xác hơn).

**Phát hiện mặt/tay**: suy TRỰC TIẾP từ khung xương YOLOv8-pose (đã bỏ
hẳn MediaPipe Face/Hand) — đổi hiệu suất lấy độ chính xác, mask có
padding rộng bù lại.

**Mask**: ưu tiên MobileSAM (click tâm bounding-box suy từ pose); fallback
rectangle-có-feather (`BlurMaskFilter`). Nhiều vùng lỗi hợp nhất 1 mask
(PorterDuff LIGHTEN) — chỉ 1 lượt `img2imgFix`.

**Interaction mask riêng theo vùng** — 2 người chạm nhau: tách mask lỗi
giao thoa THEO TỪNG VÙNG kiểu ADetailer, feather 15px. `clothing_tear_point`
— mô tả trang phục rách TẠI ĐIỂM CHẠM (bootstrap ảnh tham chiếu qua
img2img).

**Multi-Pass Inpainting Cascade** — 3-4 lượt denoise giảm dần (0.6→0.2),
tuần tự, mặc định BẬT.

**Quality Gate** — YOLO tự đếm chi, auto-regenerate. CHỈ nhánh 1-nhân-vật
có retry; multi-char-anchors/regional KHÔNG có (quyết định phạm vi có
chủ đích, chi phí cao hơn).

**Seed Registry** — lưu seed "hoàn hảo" (qua Quality Gate) để tái dùng.
Chỉ đảm bảo không lỗi giải phẫu, không đảm bảo thẩm mỹ.

**Auto-Histogram Guard, Hand-Over-Body Fixer** — đã áp thật vào code.

**Bubble Protection Mask** — code có sẵn, xác nhận KHÔNG CẦN wiring vào
pipeline hiện tại — không phải TODO treo.

**Nén CBZ** — JPEG q92 chỉ ở điểm xuất cuối (không nén file trung gian).
Bug đã sửa: CBZ từng thiếu bubble hoàn toàn.

---

## 5. Nhất quán nhân vật — điều phối & giới hạn

**3 phương pháp** gộp vào `EditCharacterDialog`, gợi ý tự động theo vai
trò (MAIN→LoRA, SUPPORTING→IP-Adapter, ONETIME→Không dùng).

**"Đảo pipeline nhân vật" ĐÃ LÀM** (mục 154 archive — tự quyết định UX +
triển khai theo yêu cầu user): bước phân tích sơ bộ RẺ
(`LLMParser.extractCharacterSummary()`, ~500 token vs 1800+ của
`parseStory()` đầy đủ) chạy TRƯỚC khi viết kịch bản chi tiết, chỉ khi
phát hiện nhân vật MỚI — `CharacterSummaryReviewScreen` (mobile-first: 1
cột, chip to, CTA ghim đáy màn hình) cho user xác nhận vai trò + đánh dấu
"cần giữ mặt nhất quán". **KHÔNG** đảo hẳn state machine như đề xuất gốc
(set method đầy đủ cần ảnh/LoRA thật, chưa có ở bước này) — chỉ dùng làm
HINT TẠM cho đúng 1 lượt `parseStory()` kế tiếp, KHÔNG persist vào
Character (giữ nguyên tắc `currentConsistencyMethod()` luôn suy từ dữ
liệu thật). Chương 2 trở đi (không có nhân vật mới) tự bỏ qua màn này.

**Cache `loadSD()`/`loadSDAugmented()` ĐÃ đóng gap reload khi Textual
Inversion embeddings đổi giữa chừng** — `ImagePipeline.embeddingsSignature()`
fingerprint rẻ (tên+size+lastModified), reload nếu đổi dù `modelId`
không đổi.

**Model per-nhân-vật/ghép-cặp**: `StoryManager.convertAndRegisterModel()`
/`convertAndRegisterPairModel()` + UI `PairConvertDialog` đã đủ. Rủi ro
"rò rỉ đặc điểm" ghép LoRA — không có cách biết chắc ngoài build-test.

---

## 6. Hệ thống tư thế (pose)

**Trích xuất**: YOLOv8-pose (đã thay MediaPipe hoàn toàn). 3 cơ chế cảnh
báo tự động: điểm tự tin thấp <0.5, thiếu khớp <17/17, khoảng cách khớp
liền kề >3x tham chiếu vai-hông (kinh nghiệm, không phải số đo khoa học).

**Kiến trúc**: đọc thư viện + chọn variant + retarget đã chuyển từ NATIVE
sang KOTLIN — gán tường minh `variant.people[i]` ↔ `scene.characters[i]`,
gửi mảng float PHẲNG đã retarget cho native.

**PoseRetargeter** — FK giữ góc gập, lan truyền từ hip-center, đổi ĐỘ DÀI
theo `BoneProportions` riêng từng nhân vật (không phải Bio-IK đầy đủ —
quyết định có chủ đích, không có thư viện C++ nhẹ cho NDK). KHÔNG giải
"điểm chạm bắt buộc".

**CCD-IK** — chỉ áp dụng TAY (vai-khuỷu-cổ tay), không áp dụng chân.
Pinch-to-zoom cho `PoseEditorScreen` đã thêm.

**Bàn chân "lơ lửng"** — Ground Anchoring tịnh tiến trục Y CHỈ áp dụng
cảnh KHÔNG tiếp xúc (`isContactVariant()` heuristic) — cảnh ôm/vật KHÔNG
tịnh tiến cục bộ để giữ điểm chạm gốc.

**Import khung xương ngoài** — chỉ OpenPose BODY_18 chuẩn, từ chối rõ
ràng BODY_25 thay vì đoán map sai.

---

## 7. LLM & prompt engineering

**`SD15_PROMPT_GUIDE`** (đối chiếu thật `PromptProcessor.hpp` — cú pháp
`(tag)`/`(tag:1.3)`/`[tag]`, KHÔNG có `BREAK` A1111) + `Story.
promptGuideNotes` (user tự ghi theo checkpoint) — 2 lớp, không thay thế
nhau. SDXL cần `SDXL_PROMPT_GUIDE` riêng — chưa viết.

**`PromptStage`** (TXT2IMG/UPSCALE_REDRAW/INPAINT) — dịch mô tả tự nhiên
riêng theo giai đoạn.

**`PromptStyle`** — sửa gốc rễ việc LLMParser luôn ép tag-style bất kể
checkpoint.

**Biểu cảm nhân vật** — `EXPRESSION_TAGS` đối chiếu chuẩn học thuật
AffectNet 8-lớp (6 Ekman + neutral + contempt), 4 category còn lại theo
quy ước manga. Enum đóng → LLM bị ép chọn gần nhất, không bao phủ mọi
sắc thái — đánh đổi có chủ đích.

**Bố cục/Depth Scale/Anchor Prompting** (sau 2 lần tự đính chính nhầm
"bố cục" vs "tỷ lệ khung ảnh") — Depth Scale là công cụ TƯỜNG MINH, không
tự suy luận. "Attribute binding" — giải pháp cộng đồng có, không cần
UNet mới.

**Concept Dictionary** — nối dây thật vào LLMParser. LLM 1-2B có thể
quên dict khi >30 entry, chưa làm chiến lược TOP-N.

**LLM engine kế thừa** — bug thật: `nGpuLayers` hardcode ép CPU 6/7 nơi
khởi tạo (không cố ý) — đã sửa.

---

## 8. NPU / QNN

Dùng THẲNG backend QNN built-in của MNN (`MNN_FORWARD_NN` — QNN/CoreML/
NNAPI dùng chung 1 giá trị forward type) — khác local-dream (2 engine
riêng). Cascade NPU→OpenCL→CPU ở tầng session, dùng chung mọi pipeline.

**Chưa có tác dụng thật cho tới khi**: build với QNN SDK thật + đóng gói
4 file runtime QNN (`libQnnHtp*.so`) vào `jniLibs/` — **chưa làm**. SD1.5
bắt buộc NPU thật per-model; SDXL giữ cascade GPU tối thiểu.
`ip_adapter.cpp`/`regional_prompting.cpp` — ~~vẫn hardcode `use_opencl=false`~~
**ĐÃ SỬA từ mục 61 archive** (đọc `useOpenCL`/`useNpu` thật từ Kotlin
`settings`, xác nhận qua grep tất cả 4 call site `loadSDAugmented*`/
`loadSDRegional` trong `MangaPipeline.kt`) — sót lại trong bản tóm tắt
đầu tiên, tự phát hiện + sửa ở mục 18.

**Chế độ Offline** (đúng cách local-dream chạy) — đã làm, cùng
`mangalocal_qnn_convert.ipynb` (Kaggle 29-30GB RAM free) — xem
`HUONG_DAN_NPU_QNN.md`. Cú pháp convert tra chéo 6 nguồn nhưng UNet
augmented của MangaLocal chưa từng thử convert thật.

---

## 9. Remote GPU (Colab/GPU thuê ngoài)

**Bảo mật**: hybrid RSA-OAEP + AES-256-GCM — chống trung gian mạng,
KHÔNG chống được chính chủ hạ tầng GPU. Xác thực TOFU fingerprint. Đã
kiểm chứng bằng thực nghiệm: RSA-OAEP Kotlin↔Python ban đầu KHÔNG tương
thích (padding khác) — đã sửa + verify chạy thật Java+Python.
**Confidential Computing GPU (TEE)** — công nghệ DUY NHẤT chống được
chính chủ hạ tầng — cờ có sẵn trong model, chưa có nhánh server nào.

**Routing**: MANUAL (rule Kotlin thuần) và AUTO (LLM local tự quyết theo
prompt tiếng Việt user viết — không hardcode tiêu chí). Fail-safe: lỗi
bất kỳ → luôn LOCAL. `RoutingReviewScreen` duyệt tay hàng loạt trước khi
sinh — không lẫn thứ tự truyện (nội dung cố định trước, ảnh lưu theo
index gốc).

**Server** (FastAPI) — IP-Adapter + ControlNet-Pose/Depth + LoRA (nạp/gỡ
động), SD1.5+SDXL song song. Checkpoint gốc cố định lúc khởi động, chỉ
đổi khi model_id khác hẳn ("trước khi bắt đầu 1 chương", không phải mỗi
panel). Hàng đợi (429 khi quá tải) + rate-limit + dọn VRAM lúc rảnh + tự
đóng sau N giờ — quản lý tài nguyên hợp lệ, KHÔNG phải né bộ quét (đã từ
chối rõ: Base64 obfuscate lệnh cài, script Anti-AFK, mã hoá từng biến RAM
— lý do: không thu hẹp threat model thật, chỉ thêm bề mặt bug mới).
Zero-out bytearray + `gc.collect()` cho RAM nhạy cảm — giới hạn: `str`
Python immutable, không ghi đè tại chỗ được.

**Notebook Colab**: Cloudflare Tunnel (không cần đăng ký/token).

**CHƯA XÁC NHẬN CHẠY THẬT** toàn bộ mục này — chỉ kiểm tra cú pháp Python
hợp lệ + notebook nhúng khớp byte-for-byte, chưa chạy 1 lần trên
Colab/RunPod/Vast.ai thật.

---

## 10. Quản lý tài nguyên & vận hành quy mô lớn (Industrial Batch Mode)

**4 giai đoạn tuần tự** (ESRGAN→Ultrafix→YOLO+SAM detect→SD Inpaint),
giải phóng RAM chủ động giữa mỗi giai đoạn.

**Checkpoint cuốn chiếu + Error Shunning** (`BatchStateRegistry.kt`) —
lưu tiến độ theo chương sau mỗi chương, resume được nếu OS giết giữa
batch dài (khớp hash văn bản gốc). 1 chương lỗi không làm chết cả batch.

**Cờ interrupt JNI** — `g_generation_interrupted` (atomic, `Pipeline.hpp`)
kiểm tra THẬT giữa mỗi step denoise (khác đề xuất cờ placebo từng bị từ
chối trước đó vì thiếu hook thật) — bổ trợ `cancelSafely()` timeout 30s
đã có từ trước, không thay thế. Giới hạn: chỉ ngắt được giữa 2 step.

**4 chỗ rò bộ nhớ native đã vá.**

**Foreground Service + WakeLock** — dùng file có sẵn. Chưa xác nhận
`freeAll()`/`sdFree()` an toàn gọi GIỮA CHỪNG batch.

**ProGuard/R8 + jniLibs QNN** — hạ tầng `buildTypes.release` đã thêm,
**`minifyEnabled` CỐ TÌNH giữ `false`** (chưa build-test để xác nhận R8
không phá JNI). `proguard-rules.pro` giữ rule RỘNG có chủ đích.

---

## 11. Triple-Conditioning combo (Regional + IP-Adapter + Depth cùng lúc)

`tools/export_ipa_controlnet_triple_combo_unet.py` — gộp thủ công 2 khối
logic đã kiểm chứng riêng, KHÔNG ghép trực tiếp 2 script có sẵn (Regional
Prompting monkey-patch `forward()` sẽ làm `attn.processor` của IP-Adapter
không bao giờ được gọi — lỗi kiến trúc nếu ghép ngây thơ). Danh tính +
prompt chữ dùng CHUNG 1 ranh giới cột cứng — phù hợp N người đứng cạnh
nhau, KHÔNG phù hợp cảnh ôm/đan xen.

**Đã nối dây HOÀN CHỈNH** (mục 151/152 archive) — `triple_combo.cpp`
(C++/JNI mới) + wrapper Kotlin + nhánh chọn trong `MangaPipeline.kt`
(ưu tiên cao nhất khi có đủ anchor VÀ file `unet_triple_combo_{N}region.mnn`,
additive — không đổi hành vi story nào chưa export model này). Chưa áp
dụng Multi-Pass Cascade cho nhánh này (không tương thích thẳng, để dành).
Chưa chạy thử thật (cần GPU để export model + Android thật để chạy app).

---

## 12. UI/UX — trạng thái & audit lặp lại

Đã trải qua nhiều vòng audit UI theo 4 câu hỏi cố định: route thiếu
không / đã nối dây chưa / UI "vỏ rỗng" không / tài liệu đồng bộ không.
Kết quả cuối: **không còn field settings nào thiếu UI hoặc vỏ rỗng**
ngoài 3 field `@Deprecated` cố ý giữ. Đã xoá 2 field chết
(`sdModelDir`/`useVulkan`, an toàn vì Gson bỏ qua field lạ/thiếu).
`nThreads` → Auto/Manual switch thật. `slidingWindowSize` → `ArrayDeque`
cửa sổ N panel thật (A-B-A).

**3 bug ảnh preview nghiêm trọng đã sửa** — `PanelCard`/`EditPanelSheet`/
`BubbleEditCanvas` từng chỉ hiện placeholder CHỮ thay vì ảnh thật — ảnh
hưởng trực tiếp khả năng dùng được, đã sửa dùng `AsyncImage`/Coil.

**"Chen ngang" — import ảnh ngoài thay 1 panel** (đã làm): chọn 1 file
ảnh ngoài gán thẳng cho 1 panel — `MangaPipeline.importPanelImage()` +
nút trong `EditPanelSheet`. Center-crop đúng tỷ lệ rồi resize.
`resolvedBackend=null` + `routingReason="Ảnh nhập tay (import ngoài)"`
(phân biệt với "chưa sinh lần nào" bằng `routingReason` rỗng hay không),
`qualityGatePassed=true`. Upscale/auto-fix bước sau không cần đổi gì.

`ExternalScriptImportDialog` — đã dùng `ModalBottomSheet` (không còn
`AlertDialog`).

**`CharacterSummaryReviewScreen` mới** (mục 154 archive — "đảo pipeline
nhân vật") — màn xác nhận nhân vật trước khi viết kịch bản chi tiết,
CHỈ hiện khi có nhân vật mới. Thiết kế mobile-first: 1 cột, chip to,
CTA ghim đáy màn hình. Xem mục 5.

---

## 13. Danh sách tồn đọng (đối chiếu code hiện tại)

1. **SDXL**: IP-Adapter/ControlNet/LoRA/Regional/mask/Orthogonal riêng,
   `SDXL_PROMPT_GUIDE` riêng (mục 3.5, mục 7).
2. **QNN runtime thật**: chưa đóng gói 4 file `.so` vào `jniLibs/`
   (mục 8).
3. **`minifyEnabled`** vẫn `false` — hạ tầng sẵn sàng, chưa bật (mục 10).
4. **ControlNet-Union, SDXL local đầy đủ** — quy mô lớn, đã đánh giá kỹ
   thuật, chưa bắt tay (mục 3, 3.5).

Tất cả 4 mục còn lại đều KHÔNG làm được trong sandbox này — cần hạ tầng
thật không có (QNN SDK), hoặc quy mô ngang/lớn hơn hẳn 1 lượt an toàn.
Mọi mục "cần quyết định sản phẩm trước khi làm" trong dự án (đảo pipeline
nhân vật, import ảnh ngoài) đều đã được tự quyết định + triển khai.

**Việc lớn nhất, bao trùm mọi mục trên**: build CI thật lần đầu (mục 0).

---

## 14. Công nghệ đã nghiên cứu nhưng KHÔNG dùng, thực nghiệm quan trọng, bài học phương pháp

**Model nền thay SD1.5 — đã tra kỹ, không có lựa chọn khả thi hơn**:
Flux-schnell (12B, không nhỏ hơn), Flux.1-lite (8B, vẫn nặng), SD3.5
Medium (2.5B, không có bản CPU/MNN), Hunyuan-DiT (không tìm được bằng
chứng tối ưu MNN/ncnn). Không model nào có tiền lệ chạy MNN mobile.

**"BREAK" (A1111) — xác nhận KHÔNG hoạt động** trong engine này (grep
`TextEncoder.hpp`/`PromptProcessor.hpp`) — kể cả trên A1111 gốc, BREAK
đơn thuần không tương đương Regional Prompter.

**Bio-IK đầy đủ — đánh giá và KHÔNG chọn**, thay bằng FK nhẹ hơn — không
có thư viện C++ nhẹ cho NDK Android.

**2 kỹ thuật né tránh hệ thống chống lạm dụng — từ chối rõ ràng**: Base64
obfuscate lệnh cài + script Anti-AFK; mã hoá từng biến RAM (không thu hẹp
threat model thật, model AI bắt buộc nhận plaintext để inference).

**Confidential Computing GPU (TEE)** — công nghệ duy nhất chống được
chính chủ hạ tầng GPU thuê — biết hướng đúng, chưa triển khai.

**Orthogonal LoRA — 3 hướng học thuật 2025 cạnh tranh nhau** (OSRM
arXiv:2505.22934, Orthogonal MC Dropout arXiv:2510.03262, DO-Merging
arXiv:2505.15875) — cả 3 áp dụng lúc TRAIN, không dùng được cho merge
LoRA có sẵn — Gram-Schmidt cổ điển là lựa chọn khả thi duy nhất, ghi rõ
"giảm 1 dạng nhiễu cụ thể", không phải giải pháp triệt để.

**Thực nghiệm thật quan trọng nhất — MNNConvert 3.6.1 hỗ trợ đúng op
`Where`**: tự cài MNN+onnx+onnxruntime qua pip (đúng version CI dùng),
dựng đồ thị test, convert, so khớp SỐ HỌC với ONNX Runtime — 4/4 khớp
chính xác. 1 trong rất ít nơi có xác nhận thực nghiệm độc lập.

**Bài học phương pháp**:
1. Không tin tài liệu review ngoài dù văn phong tự tin — verify bằng
   grep/code thật trước khi hành động theo.
2. Sửa 1 file bằng chèn giữa chừng → liệt kê TOÀN BỘ vị trí liên quan
   trước khi khẳng định xong.
3. Kể cả khi chủ động đối chiếu code, đọc lướt tiêu đề mục thay vì đọc
   hết nội dung vẫn tạo ra lệch pha MỚI — không có cách tránh 100% ngoài
   double-check bằng code thật cho từng mục trước khi chốt.
4. 1 cờ boolean không hook thật ở đâu là placebo, không phải cơ chế.

---

## 15. Đợt "audit" thứ 2 từ nguồn ngoài (PDF, cùng mẫu Google AI Mode) — 2 việc thật đã làm, phần lớn còn lại không đáng tin

User dán vào PDF chứa 1 chuỗi hội thoại rất dài (nhiều lượt "còn nữa
không" liên tiếp) với ngày càng nhiều đề xuất "lỗ hổng kiến trúc" leo
thang tới mức phi lý — tới đoạn cuối cùng đưa ra các claim ở tầng
**vật lý bán dẫn** (Voltage Droop khiến "bit-flip ngẫu nhiên", LPDDR5
"Bandwidth Starvation", "512 slots JNI cố định" tuyệt đối, Hexagon HTP
"Subnormal Collapse") — đây là dấu hiệu rõ ràng của chuỗi ảo giác leo
thang (mỗi câu "còn nữa không" ép mô hình tạo ra vấn đề MỚI ngày càng cực
đoan hơn để có gì đó trả lời) — **KHÔNG kiểm tra những phần này**, không
đáng tin theo cùng lý do đã nêu ở mục 142/143.

Tuy nhiên, khác các lượt trước, đợt này có 1 vài claim SỚM (trong 2-3
tin nhắn đầu PDF) **kiểm chứng được bằng grep code thật và ĐÚNG**:

### 1. "Sốc toán học Timestep" ở Depth ControlNet — ĐÚNG, đã sửa

`export_ipa_controlnet_depth_unet.py` (mục 81 archive) dùng `torch.where`
làm cổng NHỊ PHÂN CỨNG cho `depth_scale` (bật 100%/tắt 0% đột ngột đúng 1
timestep) — xác nhận đúng bằng đọc code, không phải claim bịa. Residual
ControlNet cộng THẲNG vào latent mỗi step — 1 cổng nhảy đột ngột giữa 2
step liền kề LÀ rủi ro thật về mặt liên tục tín hiệu (không cần thực
nghiệm riêng để biết — nguyên lý cơ bản của bất kỳ hệ xử lý tín hiệu số
nào), khác hẳn các claim "vật lý silicon" vô căn cứ ở cuối PDF.

Đã sửa: thêm input mới `depth_ramp_width` (tuỳ chọn, tương thích ngược
— thiếu input này = hành vi cổng cứng cũ, không hồi quy) — cổng suy giảm
TUYẾN TÍNH MƯỢT trên 1 cửa sổ quanh ngưỡng thay vì nhảy bậc. File đổi:
`tools/export_ipa_controlnet_depth_unet.py` (forward() + export),
`app/src/main/jni/ip_adapter.cpp` (`setControlNetBalance()` thêm tham số
thứ 4 có default, đọc input mới theo đúng pattern tự-phát-hiện-input đã
có sẵn cho mọi input tuỳ chọn khác trong file này).

### 2. "Per-Instance Decay cho N-nhân vật" — ĐÚNG, XÁC NHẬN LÀ GAP THẬT (chưa sửa)

Đọc `tools/ip_adapter_decay.py` xác nhận: `decay_state.value` là **1
scalar DÙNG CHUNG** cho mọi nhân vật trong nhánh mask N-người (dòng
`static_scale[i] * self._decay_state.value * (...)` — `static_scale`
tách theo từng người [i], nhưng decay theo timestep thì KHÔNG). PDF nói
đúng: cảnh vật lộn nhiều người, hạ decay ở step cuối để biểu cảm phát
huy sẽ làm YẾU identity-lock của **CẢ HAI** người cùng lúc dù chỉ 1 người
đang biểu cảm mạnh.

**CHƯA sửa trong lượt này** — đây là thay đổi lớn hơn hẳn mục 1 (decay
phải trở thành mảng N-phần-tử xuyên suốt: Python export → ONNX input
shape đổi từ scalar sang vector → C++ đọc theo đúng N (không hardcode) →
Kotlin phải biết trạng thái "đang biểu cảm mạnh" của TỪNG nhân vật để
truyền đúng giá trị cho đúng index) — ghi nhận là gap THẬT, để dành việc
kế tiếp thay vì làm vội trong cùng lượt với mục 1.

### 3. Concept Dictionary TOP-N theo độ liên quan (không phải đề xuất từ PDF này — đóng gap ĐÃ GHI SẴN từ trước, mục 78 archive)

Nhân dịp làm việc trên `LLMParser.kt`/`MangaPipeline.kt`, đóng luôn gap
đã tự ghi nhận từ mục 78 archive ("chiến lược cắt TOP-N theo TF-IDF nhẹ —
CHƯA làm"). `ConceptDictionary.buildInjectionText()` trước đây LUÔN lấy
30 entry ĐẦU TIÊN theo thứ tự chèn — sai ở chỗ: truyện dài dần tích luỹ
>30 khái niệm, entry chèn SỚM (đầu truyện) mãi mãi chiếm hết suất dù
chương hiện tại không nhắc tới, trong khi khái niệm MỚI của chương này
bị cắt mất.

**Không dùng TF-IDF đúng nghĩa** (cần kho ngữ liệu nhiều văn bản để tính
IDF có ý nghĩa — 1 truyện đơn lẻ không đủ) — dùng bộ lọc rẻ hơn nhưng
giải quyết đúng vấn đề: đếm số lần khái niệm xuất hiện LITERAL trong văn
bản chương (ghép từ `description`/`action`/`setting`/thoại của mọi scene
— proxy hợp lý vì các trường này do LLM viết TỪ văn bản gốc), ưu tiên
entry có xuất hiện. File đổi: `ConceptDictionary.kt`
(`buildInjectionText(chapterText, maxEntries)`, tương thích ngược nếu
gọi không tham số), `MangaPipeline.kt` (truyền text ghép từ `scenes`).

### Việc KHÔNG làm từ PDF này, và lý do

- Toàn bộ các claim "tầng vật lý silicon" (Voltage Droop, Bandwidth
  Starvation, JNI 512 slots, Subnormal Collapse HTP...) — không kiểm tra,
  không đáng tin (chuỗi ảo giác leo thang, xem trên).
- 3D Human Mesh Recovery, Masked TEXT Cross-Attention (FastComposer/
  SPDiffusion), Dynamic Axes 3 profile, In-Memory Pipeline (bỏ hẳn ghi
  PNG ra đĩa), Multi-Process JNI Isolation, Dynamic Model Delivery,
  Native Crash Dump (Breakpad), Dynamic Identity Bootstrap (ảnh neo đổi
  theo cốt truyện) — đều là đề xuất tính năng THẬT SỰ có thể đáng làm,
  nhưng quy mô LỚN (đụng kiến trúc export/JNI/UI nhiều lớp cùng lúc),
  không làm vội chỉ vì 1 văn bản ngoài liệt kê hàng loạt trong 1 lượt.
- Claim pháp lý "cần Clean-room tách code khỏi CC BY-NC 4.0 để thương
  mại hoá" — **không tự ý hành động theo** vì đây là quyết định SẢN PHẨM/
  PHÁP LÝ (không phải kỹ thuật thuần), và bản thân `NOTICE_local-dream.md`
  đã ghi rõ điều kiện dùng (mục 10 archive: "MangaLocal miễn phí 100% —
  điều kiện bắt buộc để hợp lệ dùng code local-dream") — nếu user có ý
  định thương mại hoá thật, cần tự quyết định hướng đi (giữ miễn phí,
  hoặc tự viết lại phần đụng license) trước khi có thay đổi code nào theo
  hướng đó, không phải việc kỹ thuật tự làm liều.

**CHƯA build-test** (như mọi phần khác) — đã kiểm tra cân bằng ngoặc
`{}/()` (loại trừ comment) cho cả 3 file sửa.

## 16. Per-Instance Decay (đóng gap mục 15) + phát hiện phụ: bug compile thật tiền tồn tại

Làm nốt Per-Instance Decay đã xác nhận thật ở mục 15 (decay theo
timestep giờ tách RIÊNG từng nhân vật trong đường mask N-người, thay vì
1 scalar dùng chung — `IpDecayState.value` shape `[N]`, C++
`setIpAdapterDecayMultiCharacter()` mới, tuỳ chọn/tương thích ngược).
Kotlin chưa tự tính giá trị per-character thật từ `Scene.expression` —
hạ tầng đã sẵn sàng, việc tính giá trị để dành.

**Phát hiện phụ ngoài dự kiến — bug compile thật**: 2 call site trong
`MangaPipeline.kt` gọi `generatePanelMultiChar()` với 3 tham số
(`poseConditioningScale`/`depthConditioningScale`/`depthActiveMinTimestep`)
mà hàm KHÔNG hề khai báo (copy-paste từ call site `generatePanel()`
1-nhân-vật, nơi 3 tham số này thật) — lẽ ra Kotlin không compile được,
chưa bị bắt vì chưa build-test lần nào. Xác nhận không phải thiếu sót cần
thêm vào: model mask N-nhân-vật không có Depth ControlNet, residual Pose
cộng thẳng 1:1 không có input scale — khác biệt kiến trúc thật. Đã bỏ 3
dòng gọi sai ở cả 2 call site.

## 17. Quét đối chiếu chữ ký JNI thật — toàn bộ 33 hàm khớp, không bug thêm (số liệu tại thời điểm quét — nay đã 37, xem mục 19)

Mở rộng phương pháp mục 16 (đối chiếu tham số ↔ call site, tìm ra bug
compile thật) sang lớp rủi ro cao hơn: chữ ký JNI giữa `NativeBridge.kt`
(33 `external fun` tại thời điểm này) và triển khai C++ thật (9 file
`.cpp`). Sai lệch ở đây là crash runtime khó debug, không phải lỗi
compile bắt được ngay. Đối chiếu tay toàn bộ 33 hàm — **khớp chính xác,
không tìm thêm bug**. Giới hạn: chỉ xác nhận hình thức chữ ký, không
chạy thử JNI thật được (không có NDK trong sandbox).

## 18. Tự phát hiện thêm 1 drift trong bản tóm tắt (mục 8 sai) khi trả lời "còn gì chưa xong"

User hỏi thẳng "còn gì chưa xong" — trước khi trả lời từ danh sách có
sẵn, kiểm tra lại từng mục bằng grep thay vì tin theo chữ đã viết. Phát
hiện mục 8 (NPU/QNN) sai: viết "`ip_adapter.cpp`/`regional_prompting.cpp`
vẫn hardcode `use_opencl=false`" — thật ra đã sửa từ mục 61 archive (2
struct `SdAugmentedHandle`/`SdRegionalHandle` đọc `useOpenCL`/`useNpu`
thật từ tham số JNI, và cả 4 call site `loadSDAugmented*`/`loadSDRegional`
trong `MangaPipeline.kt` đều truyền `settings.useOpenCL, settings.useNpu`
thật, không hardcode). Đã sửa mục 8 + mục 13 (danh sách tồn đọng còn 5
mục, không phải 6).

## 19. Triple-Conditioning combo — lớp C++/JNI/Kotlin-wrapper hoàn chỉnh, còn 1 việc cuối

Nối dây phần lớn nhất còn lại của tính năng này: `triple_combo.cpp` (file
mới, ghép `PipelineSd15CpuRegional` + `IpImageEncoder` của
`PipelineSd15CpuAugmented`, đối chiếu API kỹ với khai báo thật trước khi
viết xong) + `renderDepthHintCanvas()` mới trong `ip_adapter.cpp` +
`NativeBridge.kt`/`ImagePipeline.kt`/`StoryManager.kt` wrapper đầy đủ.
Thêm vào `CMakeLists.txt`. Nhân tiện sửa trước 1 lỗi cùng loại mục 131
(ctx mới thêm vào `freeAll()` ngay từ đầu, không để sót như
`sdRegionalCtx` từng bị).

**Còn thiếu duy nhất**: `MangaPipeline.kt` chưa chọn khi nào gọi pipeline
này (đọc/sửa nhánh ưu tiên 4 tầng có sẵn — rủi ro cao nhất, để dành lượt
riêng). Dữ liệu đầu vào (prompt theo cột, ảnh neo) đã có sẵn, tái dùng
được ngay — chỉ cần đúng điều kiện chọn.

## 20. Hoàn thành Triple-Conditioning combo — nối nhánh chọn trong MangaPipeline.kt

Làm nốt việc cuối cùng để dành ở mục 19: thêm `tripleComboAnchors` +
nhánh chọn (additive, KHÔNG sửa `multiCharAnchors`/`useRegional` có sẵn
— chỉ đổi thứ tự if/else, đặt Triple Combo ưu tiên cao nhất) ở cả 2 nơi
chọn pipeline (`runGeneration()` có Quality Gate retry,
`regeneratePanel()` đơn giản hơn — đúng khác biệt đã có sẵn giữa 2 nhánh
cũ). Story nào chưa export model `unet_triple_combo_{N}region.mnn` thì
hành vi không đổi gì (tự rơi xuống 2 nhánh cũ). Ràng buộc quan trọng:
`regionOrderTc` dùng làm thứ tự DUY NHẤT cho cả prompt chữ lẫn ảnh neo
(bắt buộc khớp nhau, đúng thiết kế export script). Chưa áp dụng
Multi-Pass Cascade cho nhánh này. Tính năng coi như nối dây xong toàn bộ
— danh sách tồn đọng còn 5 mục, tất cả đều không làm được trong sandbox
này (cần QNN SDK/quyết định sản phẩm/quy mô quá lớn) hoặc chờ build CI
thật (mục 0).

## 21. Hoàn thành "đảo pipeline nhân vật" — tự quyết định UX mobile-first + triển khai

Gap cuối cùng trong nhóm "cần quyết định sản phẩm trước khi làm" — tự
quyết theo yêu cầu user, thiết kế mobile-first. Quyết định: KHÔNG đảo hẳn
state machine (set method thật cần ảnh/LoRA chưa có ở bước sớm này) — chỉ
thêm bước phân tích sơ bộ RẺ trước khi viết kịch bản chi tiết, hỏi đúng 1
câu quan trọng ("cần giữ mặt nhất quán?") làm hint TẠM cho lượt viết kịch
bản kế tiếp, không persist vào Character (giữ nguyên tắc method luôn suy
từ dữ liệu thật). Chỉ hiện khi có nhân vật MỚI — chương 2 trở đi tự bỏ
qua, không thêm ma sát.

`CharacterSummaryReviewScreen.kt` (màn mới): 1 cột, chip to dễ chạm, CTA
chính ghim cố định đáy màn hình (luôn trong tầm tay dù danh sách dài), có
đường tắt "Dùng gợi ý mặc định, viết luôn" cho ai không muốn chỉnh gì.

File đổi: `Models.kt` (`CharacterSummary`), `LLMParser.kt`
(`extractCharacterSummary()`, prompt riêng rẻ hơn), `MangaPipeline.kt`
(`analyzeCharacters()` mới + `prepareChapter()` thêm tham số
`extraIdentityHintNames` default rỗng — 0 đổi hành vi cũ), `MainViewModel.kt`
(`analyzeCharactersFirst()`/`confirmCharacterSummaryAndProceed()`),
`StoryScreens.kt`/`MainActivity.kt` (nối nút + route mới).

Danh sách tồn đọng còn 4 mục, tất cả thuộc loại không làm được trong
sandbox (cần hạ tầng thật hoặc quy mô quá lớn) — không còn mục nào "cần
quyết định sản phẩm" nữa.

## 22. Audit lệch pha + cập nhật hướng dẫn sử dụng + mục Help trong app (mới)

Grep đối chiếu toàn bộ `HUONG_DAN_SU_DUNG.md` với code — chỉ 1 chỗ lệch
(Bước 3, nút "Sinh panel" giờ gọi `analyzeCharactersFirst()` từ mục 154,
không phải `prepareChapter()` trực tiếp) — đã sửa + thêm Bước 3.5. Bản
tóm tắt này cũng có 2 chỗ lệch tự tìm ra: bảng pipeline SD1.5 (mục 3)
thiếu dòng Triple-Combo (đã code ở mục 19 nhưng quên cập nhật bảng), và
số "33 hàm JNI" ở mục 17 đã tăng lên 37 sau mục 19 — đã sửa/ghi chú cả 2.

Thêm **mục Help trong app** (chưa từng có trước đây) — `HelpScreen.kt`
mới, thiết kế mobile: card gập/mở, mặc định gập hết trừ mục đầu. 6 mục:
chuẩn bị model, luồng chính 9 bước, giữ mặt nhân vật, chế độ công nghiệp,
GPU thuê ngoài, xử lý sự cố. 3 lối vào (StoryListScreen + StoryDetailScreen
TopAppBar, SettingsScreen) — help cần dễ tìm trên mobile, không giấu sâu.

## 23. Build CI thật đầu tiên (Build APK #88) — FAILED, 6 lỗi, đã sửa — đọc mục 0 lại

Cột mốc: user chạy build CI thật lần đầu tiên trong lịch sử dự án — FAILED,
đúng như mục 0 luôn cảnh báo. 6 lỗi, TẤT CẢ cùng 1 nguyên nhân, TẤT CẢ ở
`ip_adapter.cpp` (KHÔNG phải `triple_combo.cpp` như suy đoán ban đầu từ
log tóm tắt — bài học: đừng suy luận file lỗi từ vị trí dòng log ninja,
cần dòng `error:` thật).

Nguyên nhân: `setControlNetBalance()`/`setIpAdapterDecay()`/
`setIpAdapterDecayMultiCharacter()` vô tình rơi vào vùng `protected:` (mở
bởi `onBeforeUnetRun()` phía trên, không có `public:` đóng lại) dù ý đồ
rõ ràng là public (gọi từ JNI tự do bên ngoài class) — bug THẬT có từ
trước mục 146/147 (gốc từ mục 81/97 archive), chỉ chưa từng lộ ra vì chưa
build-test lần nào. Sửa: thêm `public:` đúng chỗ — 1 sửa duy nhất khắc
phục cả 6 lỗi.

**Chưa biết 4 file khác** (đang build dở khi ninja dừng) có lỗi gì không
— cần chạy lại build để biết. Đây MỚI LÀ BẰNG CHỨNG THẬT ĐẦU TIÊN cho
thấy "chưa build-test" (mục 0) không phải lời cảnh báo suông — ngay lỗi
ĐẦU TIÊN gặp phải đã là thật, có từ lâu, không lộ ra vì chưa ai build.
