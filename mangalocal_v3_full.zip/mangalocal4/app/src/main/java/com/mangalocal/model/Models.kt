package com.mangalocal.model

import java.io.File

// ── Nhân vật ──────────────────────────────────────────────────────────────
enum class CharacterRole { MAIN, SUPPORTING, ONETIME }

data class Character(
    val id: String,
    val name: String,
    val anchorPrompt: String,
    val negativePrompt: String = "bad anatomy, deformed, ugly, blurry",
    val seed: Long,
    val role: CharacterRole = CharacterRole.MAIN,
    val loraPath: String? = null,
    val loraWeight: Float = 0.75f,
    val anchorImagePath: String? = null,    // ảnh preview
    val anchorEmbeddingPath: String? = null // embedding cố định
)

// ── Truyện ────────────────────────────────────────────────────────────────
data class Story(
    val id: String,
    val title: String,
    val description: String = "",
    val style: ImageStyle = ImageStyle.REALISTIC,
    val characters: List<Character> = emptyList(),
    val chapterIds: List<String> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

// ── Model file ────────────────────────────────────────────────────────────
data class ModelInfo(
    val path: String,
    val name: String,
    val type: ModelType,
    val sizeBytes: Long
) {
    val displaySize: String get() {
        val gb = sizeBytes / 1_073_741_824.0
        val mb = sizeBytes / 1_048_576.0
        return if (gb >= 1.0) "%.1fGB".format(gb) else "%.0fMB".format(mb)
    }
}
enum class ModelType { SD15, LLM, LORA, ESRGAN, YOLO }

// ── Cài đặt ───────────────────────────────────────────────────────────────
data class GenerationSettings(
    val sdModelPath: String = "",
    val llmModelPath: String = "",
    val loraPath: String = "",
    val loraWeight: Float = 0.75f,
    val imageStyle: ImageStyle = ImageStyle.REALISTIC,
    val panelCount: Int = 6,
    val width: Int = 512,
    val height: Int = 512,
    val steps: Int = 20,
    val cfgScale: Float = 7f,
    val upscaleOption: UpscaleOption = UpscaleOption.X4,
    val nThreads: Int = 4,
    val useVulkan: Boolean = true,
    val useStoryDiffusion: Boolean = true,
    val consistencyStrength: Float = 0.8f,
    val slidingWindowSize: Int = 3,
    // Nhiệt độ
    val thermalThreshold: Int = 42,       // °C dừng lại
    val thermalResumeOffset: Int = 3,     // resume khi xuống threshold - offset
    val autoResume: Boolean = true
)

enum class UpscaleOption(val label: String, val factor: Int, val sharpen: Boolean) {
    NONE("Không upscale", 1, false),
    X2("2× · 1024px", 2, false),
    X4("4× · 2048px", 4, false),
    X4_SHARP("4× · 2048px · Nét hơn", 4, true)
}

enum class ImageStyle(val label: String, val emoji: String, val stylePrompt: String, val negPrompt: String) {
    REALISTIC("Siêu thực", "📷",
        "RAW photo, 8k uhd, dslr, soft lighting, high quality, film grain, photorealistic, sharp focus",
        "cartoon, anime, illustration, 3d render, cgi, lowres, bad quality, watermark, blurry, deformed"),
    ANIME("Anime / Moe", "✨",
        "masterpiece, best quality, ultra-detailed, illustration, vibrant colors, sharp lines, anime style",
        "lowres, bad anatomy, bad hands, text, error, worst quality, jpeg artifacts, watermark, blurry, 3d"),
    MANHWA("Manhwa / Webtoon", "📱",
        "manhwa style, webtoon, clean lineart, flat colors, high contrast, korean comic, professional",
        "blurry, lowres, bad anatomy, photorealistic, 3d render, rough sketch"),
    MANGA("Manga", "📖",
        "manga style, black and white, high contrast, detailed lineart, japanese comic, professional manga",
        "colored, blurry, lowres, bad anatomy, photorealistic"),
    COMIC("Comic / Western", "💥",
        "comic book style, bold lines, vibrant colors, american comic, professional illustration, dynamic",
        "blurry, lowres, bad anatomy, photorealistic, 3d render"),
    CINEMATIC("Điện ảnh", "🎬",
        "cinematic lighting, epic composition, dramatic shadows, movie still, 35mm film, anamorphic lens",
        "cartoon, anime, illustration, amateur, blurry, lowres")
}

// ── Scene & Panel ─────────────────────────────────────────────────────────
data class Scene(
    val index: Int,
    val description: String,
    val characters: List<String>,
    val mood: String,
    val cameraAngle: String,
    val action: String = "",
    val setting: String = "",
    val dialogue: List<DialogueLine> = emptyList()
)

data class DialogueLine(
    val characterName: String,
    val text: String,
    val type: BubbleType = BubbleType.SPEECH
)

// ── Bubble hội thoại ──────────────────────────────────────────────────────
enum class BubbleType { SPEECH, THOUGHT, NARRATION, SHOUT }

data class Bubble(
    val id: String,
    val characterName: String,
    val text: String,
    val type: BubbleType = BubbleType.SPEECH,
    // Vị trí trên ảnh (normalized 0.0-1.0)
    val xNorm: Float = 0.1f,
    val yNorm: Float = 0.05f,
    val widthNorm: Float = 0.4f,
    val isAutoPlaced: Boolean = false  // true = YOLOv8 đặt, false = người dùng đặt
)

// ── Panel ─────────────────────────────────────────────────────────────────
enum class PanelStatus { PENDING, GENERATING, DONE, FAILED, APPROVED, REJECTED }
enum class PanelReviewAction { APPROVE, REJECT, REGENERATE, EDIT_PROMPT }

data class Panel(
    val index: Int,
    val scene: Scene,
    val prompt: String,
    val negativePrompt: String,
    val imagePath: String? = null,           // 512px raw
    val upscaledPath: String? = null,        // sau upscale
    val bubbles: List<Bubble> = emptyList(), // hội thoại
    val status: PanelStatus = PanelStatus.PENDING,
    val generationTimeMs: Long = 0,
    val latentEmbeddingPath: String? = null,
    val userNote: String = ""                // ghi chú của người dùng khi edit
)

// ── Chapter ───────────────────────────────────────────────────────────────
data class Chapter(
    val id: String,
    val storyId: String,
    val title: String,
    val chapterNumber: Int,
    val storyText: String,
    val style: ImageStyle,
    val panels: List<Panel>,
    val pdfPath: String? = null,
    val cbzPath: String? = null,
    val status: ChapterStatus = ChapterStatus.DRAFT,
    val createdAt: Long = System.currentTimeMillis()
) {
    val doneCount get() = panels.count { it.status == PanelStatus.DONE || it.status == PanelStatus.APPROVED }
    val approvedCount get() = panels.count { it.status == PanelStatus.APPROVED }
    val allApproved get() = panels.isNotEmpty() && panels.all { it.status == PanelStatus.APPROVED }
}

enum class ChapterStatus { DRAFT, GENERATING, REVIEW, UPSCALING, DONE }

// ── Pipeline state ────────────────────────────────────────────────────────
data class PipelineState(
    val stage: PipelineStage = PipelineStage.IDLE,
    val currentPanel: Int = 0,
    val totalPanels: Int = 0,
    val currentStep: Int = 0,
    val totalSteps: Int = 20,
    val log: List<LogEntry> = emptyList(),
    val error: String? = null,
    val startTimeMs: Long = 0L,
    val isPaused: Boolean = false,
    val pauseReason: PauseReason? = null,
    val currentTempC: Int = 0
) {
    val elapsedMs get() = if (startTimeMs == 0L) 0L else System.currentTimeMillis() - startTimeMs
    val progressFraction get() = if (totalPanels == 0) 0f else currentPanel.toFloat() / totalPanels
}

enum class PipelineStage {
    IDLE, LLM_PARSING, PROMPT_BUILDING,
    SD_GENERATING, REVIEW,
    UPSCALING, BUBBLE_AUTO,
    LAYOUT_EXPORT, DONE, ERROR
}

enum class PauseReason { THERMAL, USER }

data class LogEntry(val time: String, val message: String, val level: LogLevel = LogLevel.INFO)
enum class LogLevel { INFO, OK, WARN, ERROR }

// ── Thermal state ─────────────────────────────────────────────────────────
data class ThermalState(
    val currentTempC: Int = 0,
    val thresholdC: Int = 42,
    val isOverheating: Boolean = false,
    val history: List<Int> = emptyList() // lịch sử nhiệt độ để vẽ chart
)
