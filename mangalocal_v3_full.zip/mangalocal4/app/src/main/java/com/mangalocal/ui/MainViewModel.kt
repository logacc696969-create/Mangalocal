package com.mangalocal.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangalocal.model.*
import com.mangalocal.pipeline.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val storyManager = StoryManager(app)
    val thermalMonitor = ThermalMonitor(app)
    val runtimeOptimizer = RuntimeOptimizer(app)
    private val pipeline = MangaPipeline(storyManager, thermalMonitor, runtimeOptimizer)

    val pipelineState = pipeline.state
    val thermalState = thermalMonitor.state

    private val _stories = MutableStateFlow(storyManager.loadAllStories())
    val stories: StateFlow<List<Story>> = _stories

    private val _currentStory = MutableStateFlow<Story?>(null)
    val currentStory: StateFlow<Story?> = _currentStory

    private val _currentChapter = MutableStateFlow<Chapter?>(null)
    val currentChapter: StateFlow<Chapter?> = _currentChapter

    private val _settings = MutableStateFlow(GenerationSettings())
    val settings: StateFlow<GenerationSettings> = _settings

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating

    private val _sdModels  = MutableStateFlow<List<ModelInfo>>(emptyList())
    private val _llmModels = MutableStateFlow<List<ModelInfo>>(emptyList())
    private val _loras     = MutableStateFlow<List<ModelInfo>>(emptyList())
    val sdModels:  StateFlow<List<ModelInfo>> = _sdModels
    val llmModels: StateFlow<List<ModelInfo>> = _llmModels
    val loras:     StateFlow<List<ModelInfo>> = _loras

    init { rescanModels() }

    fun rescanModels() {
        _sdModels.value  = storyManager.scanSdModels()
        _llmModels.value = storyManager.scanLlmModels()
        _loras.value     = storyManager.scanLoras()
    }

    fun updateSettings(block: GenerationSettings.() -> GenerationSettings) {
        _settings.update { it.block() }
        thermalMonitor.updateThreshold(_settings.value.thermalThreshold)
    }

    // ── Story management ──────────────────────────────────────────────────
    fun createStory(title: String, description: String, style: ImageStyle) {
        val story = Story(id = UUID.randomUUID().toString(), title = title,
            description = description, style = style)
        storyManager.saveStory(story)
        _stories.value = storyManager.loadAllStories()
        _currentStory.value = story
    }

    fun selectStory(story: Story) {
        _currentStory.value = storyManager.loadStory(story.id) ?: story
    }

    fun deleteStory(storyId: String) {
        storyManager.deleteStory(storyId)
        _stories.value = storyManager.loadAllStories()
        if (_currentStory.value?.id == storyId) _currentStory.value = null
    }

    fun refreshCurrentStory() {
        _currentStory.value?.let { _currentStory.value = storyManager.loadStory(it.id) }
    }

    // ── Character management ──────────────────────────────────────────────
    fun addCharacter(name: String, anchor: String, neg: String, role: CharacterRole, loraPath: String?, seed: Long?) {
        val story = _currentStory.value ?: return
        val char = Character(
            id = UUID.randomUUID().toString(), name = name.trim(), anchorPrompt = anchor.trim(),
            negativePrompt = neg.ifBlank { "bad anatomy, bad hands, extra fingers" },
            seed = seed ?: (10000L..99999L).random(), role = role,
            loraPath = loraPath?.ifBlank { null }
        )
        storyManager.saveCharacter(story.id, char)
        refreshCurrentStory()
    }

    fun updateCharacter(character: Character) {
        val story = _currentStory.value ?: return
        storyManager.saveCharacter(story.id, character)
        refreshCurrentStory()
    }

    fun deleteCharacter(characterId: String) {
        val story = _currentStory.value ?: return
        storyManager.deleteCharacter(story.id, characterId)
        refreshCurrentStory()
    }

    fun regenerateAnchor(character: Character) {
        viewModelScope.launch {
            // Tạo lại ảnh anchor từ prompt hiện tại (đã sửa nếu có)
            // Implementation thực tế cần gọi imagePipeline, đơn giản hóa qua pipeline
        }
    }

    // ── Generation flow ──────────────────────────────────────────────────
    fun generatePanels(storyText: String) {
        val story = _currentStory.value ?: run { _error.value = "Chưa chọn truyện"; return }
        val s = _settings.value
        if (s.sdModelPath.isEmpty())  { _error.value = "Chưa chọn SD Model"; return }
        if (s.llmModelPath.isEmpty()) { _error.value = "Chưa chọn LLM Model"; return }
        if (_isGenerating.value) return

        _isGenerating.value = true
        viewModelScope.launch {
            try {
                val chapterId = UUID.randomUUID().toString()
                val chapterNum = (storyManager.loadAllChapters(story.id).maxOfOrNull { it.chapterNumber } ?: 0) + 1
                val chapter = pipeline.generatePanels(story, storyText, s, chapterId, chapterNum)
                storyManager.saveChapter(chapter)
                _currentChapter.value = chapter
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi không xác định"
            } finally {
                _isGenerating.value = false
            }
        }
    }

    fun approvePanel(panelIndex: Int) {
        val ch = _currentChapter.value ?: return
        val updated = ch.panels.map { if (it.index == panelIndex) it.copy(status = PanelStatus.APPROVED) else it }
        _currentChapter.value = ch.copy(panels = updated)
        storyManager.saveChapter(ch.copy(panels = updated))
    }

    fun regeneratePanel(panelIndex: Int, newPrompt: String? = null) {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        val panel = ch.panels.find { it.index == panelIndex } ?: return
        val updatedPanel = if (newPrompt != null) panel.copy(prompt = newPrompt, userNote = newPrompt) else panel

        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                val regenerated = pipeline.regeneratePanel(updatedPanel, story, _settings.value, outDir)
                val updated = ch.panels.map { if (it.index == panelIndex) regenerated else it }
                _currentChapter.value = ch.copy(panels = updated)
                storyManager.saveChapter(ch.copy(panels = updated))
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi regenerate panel"
            }
        }
    }

    fun updatePanelBubbles(panelIndex: Int, bubbles: List<Bubble>) {
        val ch = _currentChapter.value ?: return
        val updated = ch.panels.map { if (it.index == panelIndex) it.copy(bubbles = bubbles) else it }
        _currentChapter.value = ch.copy(panels = updated)
        storyManager.saveChapter(ch.copy(panels = updated))
    }

    fun proceedToUpscale() {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        _isGenerating.value = true
        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                val upscaled = pipeline.upscaleApprovedPanels(ch, _settings.value, outDir)
                storyManager.saveChapter(upscaled)
                _currentChapter.value = upscaled
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi upscale"
            } finally { _isGenerating.value = false }
        }
    }

    fun runAutoBubble() {
        val ch = _currentChapter.value ?: return
        _isGenerating.value = true
        viewModelScope.launch {
            try {
                val updated = pipeline.autoPlaceBubbles(ch)
                storyManager.saveChapter(updated)
                _currentChapter.value = updated
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi auto bubble"
            } finally { _isGenerating.value = false }
        }
    }

    fun exportChapter() {
        val ch = _currentChapter.value ?: return
        val story = _currentStory.value ?: return
        viewModelScope.launch {
            try {
                val outDir = storyManager.outputDir(story.id, ch.id)
                val exported = pipeline.exportChapter(ch, outDir)
                storyManager.saveChapter(exported)
                _currentChapter.value = exported
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi export"
            }
        }
    }

    fun selectChapter(chapter: Chapter) { _currentChapter.value = chapter }
    fun cancelGeneration() { pipeline.cancel(); _isGenerating.value = false }
    fun clearError() { _error.value = null }
    fun modelSetupGuide() = storyManager.setupGuide()
    fun modelStatus() = storyManager.modelStatus()
    fun hardwareSummary() = runtimeOptimizer.getHardwareSummary()

    override fun onCleared() { super.onCleared(); pipeline.cancel() }
}
