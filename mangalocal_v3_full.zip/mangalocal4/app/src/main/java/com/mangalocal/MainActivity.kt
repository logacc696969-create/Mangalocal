package com.mangalocal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.mangalocal.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MangaLocalApp() }
    }
}

@Composable
fun MangaLocalApp(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val error by vm.error.collectAsState()

    MaterialTheme(colorScheme = C.scheme) {
        Surface(color = C.Bg) {
            NavHost(nav, startDestination = "stories") {
                composable("stories")          { StoryListScreen(nav, vm) }
                composable("story_detail")     { StoryDetailScreen(nav, vm) }
                composable("generating")       { GeneratingScreen(nav, vm) }
                composable("gallery_review")   { GalleryReviewScreen(nav, vm) }
                composable("post_processing")  { PostProcessingScreen(nav, vm) }
                composable("characters_detail"){ CharactersDetailScreen(nav, vm) }
                composable("characters")       { CharactersDetailScreen(nav, vm) }
                composable("settings")         { SettingsScreen(nav, vm) }
            }
        }

        error?.let { msg ->
            AlertDialog(
                onDismissRequest = { vm.clearError() },
                title = { Text("⚠️ Thông báo", color = C.Orange) },
                text = { Text(msg, color = C.T2) },
                confirmButton = { TextButton(onClick = { vm.clearError() }) { Text("OK") } },
                containerColor = C.S1
            )
        }
    }
}
