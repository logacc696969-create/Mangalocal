package com.mangalocal.pipeline

import com.mangalocal.model.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class FamilyManager(private val storyManager: StoryManager) {

    /**
     * Tạo nhân vật con dựa trên quan hệ huyết thống.
     *
     * Quá trình:
     * 1. Trích xuất traits di truyền từ cha/mẹ
     * 2. Blend traits theo tỷ lệ sinh học thực tế
     * 3. Tạo anchor prompt cho nhân vật con
     * 4. [Nếu có embedding] Blend embedding file
     */
    fun createChildCharacter(
        storyId: String,
        childName: String,
        childBaseDesc: String,     // "young girl, 16 years old, high school student"
        childOwnTraits: Map<String, String> = emptyMap(), // trait riêng: màu tóc khác,...
        parentAId: String,
        parentBId: String? = null, // null = không có cha/mẹ B (đơn thân, tìm thấy...)
        relationshipType: RelationshipType,
        childSeed: Long = (10000L..99999L).random(),
        childRole: CharacterRole = CharacterRole.MAIN
    ): Character? {
        val story = storyManager.loadStory(storyId) ?: return null
        val parentA = story.characters.find { it.id == parentAId } ?: return null
        val parentB = parentBId?.let { story.characters.find { c -> c.id == it } }

        // 1. Trích xuất traits
        val traitsA = GeneticTraits.extractTraits(parentA.anchorPrompt)
        val traitsB = parentB?.let { GeneticTraits.extractTraits(it.anchorPrompt) }

        // 2. Blend traits theo tỷ lệ di truyền
        val blended = GeneticTraits.blendTraits(
            parentATraits = traitsA,
            parentBTraits = traitsB,
            childSeed = childSeed,
            inheritanceRatio = relationshipType.blendRatio
        )

        // 3. Tạo anchor prompt
        val childPrompt = GeneticTraits.buildChildPrompt(childBaseDesc, blended, childOwnTraits)

        // 4. Tạo Character
        val childChar = Character(
            id = java.util.UUID.randomUUID().toString(),
            name = childName,
            anchorPrompt = childPrompt,
            negativePrompt = parentA.negativePrompt, // kế thừa negative prompt
            seed = childSeed,
            role = childRole
        )

        storyManager.saveCharacter(storyId, childChar)

        // 5. Blend embedding nếu cha/mẹ đã có anchor
        tryBlendEmbeddings(storyId, childChar, parentA, parentB, relationshipType)

        return childChar
    }

    /**
     * Blend embedding files của cha/mẹ để tạo embedding cho nhân vật con.
     * Nếu cha/mẹ chưa có anchor embedding → bỏ qua, embedding sẽ được tạo khi sinh panel đầu tiên.
     */
    private fun tryBlendEmbeddings(
        storyId: String,
        child: Character,
        parentA: Character,
        parentB: Character?,
        relationship: RelationshipType
    ) {
        val embA = parentA.anchorEmbeddingPath?.takeIf { File(it).exists() } ?: return

        val anchorsDir = storyManager.anchorsDir(storyId)
        val childEmbPath = File(anchorsDir, "anchor_${child.id}.bin").absolutePath

        if (parentB == null) {
            // Chỉ có 1 cha/mẹ → blend với ratio
            blendSingleParent(embA, childEmbPath, relationship.blendRatio, child.seed)
        } else {
            val embB = parentB.anchorEmbeddingPath?.takeIf { File(it).exists() }
            if (embB != null) {
                // Có cả 2 cha/mẹ → blend 50/50 (chuẩn sinh học)
                blendTwoParents(embA, embB, childEmbPath, child.seed)
            } else {
                blendSingleParent(embA, childEmbPath, relationship.blendRatio, child.seed)
            }
        }

        // Cập nhật embedding path vào character
        storyManager.saveCharacterAnchor(storyId, child.id, "", childEmbPath)
    }

    /**
     * Blend embedding của 1 cha/mẹ: giữ ratio% và thêm noise ngẫu nhiên
     * để nhân vật con không giống hoàn toàn cha/mẹ
     */
    private fun blendSingleParent(
        parentEmbPath: String,
        outputPath: String,
        inheritRatio: Float,
        seed: Long
    ) {
        val parentEmb = loadEmbedding(parentEmbPath) ?: return
        val rng = java.util.Random(seed)
        val result = FloatArray(parentEmb.size) { i ->
            val inherited = parentEmb[i] * inheritRatio
            val noise = (rng.nextFloat() * 2f - 1f) * 0.1f * (1f - inheritRatio)
            (inherited + noise).coerceIn(0f, 1f)
        }
        saveEmbedding(result, outputPath)
    }

    /**
     * Blend embedding của 2 cha/mẹ:
     * - Mỗi chiều được chọn ngẫu nhiên từ A hoặc B (giống cách gene hoạt động thực tế)
     * - Không lấy trung bình đơn giản → kết quả trông giống người thật hơn
     */
    private fun blendTwoParents(
        parentAEmbPath: String,
        parentBEmbPath: String,
        outputPath: String,
        seed: Long
    ) {
        val embA = loadEmbedding(parentAEmbPath) ?: return
        val embB = loadEmbedding(parentBEmbPath) ?: return
        if (embA.size != embB.size) return

        val rng = java.util.Random(seed)
        val result = FloatArray(embA.size) { i ->
            // Mỗi "gene" (dimension) chọn từ A hoặc B theo xác suất 50/50
            // Thêm nhỏ noise để tránh giống hoàn toàn
            val base = if (rng.nextFloat() < 0.5f) embA[i] else embB[i]
            val noise = (rng.nextFloat() * 2f - 1f) * 0.05f
            (base + noise).coerceIn(0f, 1f)
        }
        saveEmbedding(result, outputPath)
    }

    // ── Embedding I/O ─────────────────────────────────────────────────────

    private fun loadEmbedding(path: String): FloatArray? {
        return try {
            FileInputStream(path).use { fis ->
                val dimBytes = ByteArray(4)
                fis.read(dimBytes)
                val dim = ByteBuffer.wrap(dimBytes).order(ByteOrder.LITTLE_ENDIAN).int
                if (dim <= 0 || dim > 100000) return null
                val floatBytes = ByteArray(dim * 4)
                fis.read(floatBytes)
                val buf = ByteBuffer.wrap(floatBytes).order(ByteOrder.LITTLE_ENDIAN)
                FloatArray(dim) { buf.float }
            }
        } catch (e: Exception) { null }
    }

    private fun saveEmbedding(data: FloatArray, path: String) {
        try {
            FileOutputStream(path).use { fos ->
                val buf = ByteBuffer.allocate(4 + data.size * 4).order(ByteOrder.LITTLE_ENDIAN)
                buf.putInt(data.size)
                data.forEach { buf.putFloat(it) }
                fos.write(buf.array())
            }
        } catch (e: Exception) { /* ignore */ }
    }

    /**
     * Preview anchor prompt sẽ được tạo — dùng trong UI trước khi lưu
     */
    fun previewChildPrompt(
        storyId: String,
        parentAId: String,
        parentBId: String?,
        childBaseDesc: String,
        childSeed: Long,
        relationship: RelationshipType
    ): String {
        val story = storyManager.loadStory(storyId) ?: return "Không tìm thấy truyện"
        val parentA = story.characters.find { it.id == parentAId } ?: return "Không tìm thấy nhân vật cha/mẹ"
        val parentB = parentBId?.let { story.characters.find { c -> c.id == it } }

        val traitsA = GeneticTraits.extractTraits(parentA.anchorPrompt)
        val traitsB = parentB?.let { GeneticTraits.extractTraits(it.anchorPrompt) }
        val blended = GeneticTraits.blendTraits(traitsA, traitsB, childSeed, relationship.blendRatio)
        return GeneticTraits.buildChildPrompt(childBaseDesc, blended)
    }

    /**
     * Lấy danh sách traits di truyền để hiển thị trong UI
     */
    fun explainInheritance(
        storyId: String,
        parentAId: String,
        parentBId: String?,
        childSeed: Long,
        relationship: RelationshipType
    ): List<TraitInheritanceInfo> {
        val story = storyManager.loadStory(storyId) ?: return emptyList()
        val parentA = story.characters.find { it.id == parentAId } ?: return emptyList()
        val parentB = parentBId?.let { story.characters.find { c -> c.id == it } }

        val traitsA = GeneticTraits.extractTraits(parentA.anchorPrompt)
        val traitsB = parentB?.let { GeneticTraits.extractTraits(it.anchorPrompt) }
        val rng = java.util.Random(childSeed)

        val allGroups = (traitsA.keys + (traitsB?.keys ?: emptySet())).toSet()
        return allGroups.mapNotNull { group ->
            val tA = traitsA[group]; val tB = traitsB?.get(group)
            val inherited = when {
                tA == tB && tA != null -> tA
                tA != null && tB != null -> if (rng.nextFloat() < 0.5f) tA else tB
                tA != null -> if (rng.nextFloat() < relationship.blendRatio) tA else null
                tB != null -> if (rng.nextFloat() < relationship.blendRatio) tB else null
                else -> null
            }
            if (inherited != null) TraitInheritanceInfo(
                traitGroup = group,
                parentAValue = tA,
                parentBValue = tB,
                inheritedValue = inherited,
                fromParent = when {
                    tA == tB -> "Cả hai"
                    inherited == tA -> parentA.name
                    else -> parentB?.name ?: "Ngẫu nhiên"
                }
            ) else null
        }
    }
}

data class TraitInheritanceInfo(
    val traitGroup: String,
    val parentAValue: String?,
    val parentBValue: String?,
    val inheritedValue: String,
    val fromParent: String
)
