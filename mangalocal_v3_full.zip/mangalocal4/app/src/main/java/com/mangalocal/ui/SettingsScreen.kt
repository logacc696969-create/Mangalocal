package com.mangalocal.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(nav: NavController, vm: MainViewModel) {
    val settings by vm.settings.collectAsState()
    val sdModels by vm.sdModels.collectAsState()
    val llmModels by vm.llmModels.collectAsState()
    val loras by vm.loras.collectAsState()
    var showGuide by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Cài đặt & Model") },
                actions = { IconButton(onClick = { vm.rescanModels() }) { Icon(Icons.Default.Refresh, null, tint = C.Blue) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        bottomBar = { AppNavBar(nav, "settings") },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                Surface(onClick = { showGuide = !showGuide }, color = C.PurpleDim, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Purple.copy(0.4f))) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.FolderOpen, null, tint = C.Purple, modifier = Modifier.size(18.dp))
                            Text("📁 Hướng dẫn đặt model", color = C.Purple, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Icon(if (showGuide) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = C.Purple)
                        }
                        if (showGuide) {
                            Spacer(Modifier.height(8.dp))
                            Text(vm.modelSetupGuide(), color = C.T2, fontSize = 11.sp, fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                        }
                    }
                }
            }

            item {
                var showHw by remember { mutableStateOf(false) }
                Surface(onClick = { showHw = !showHw }, color = C.GreenDim, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Green.copy(0.4f))) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Speed, null, tint = C.Green, modifier = Modifier.size(18.dp))
                            Text("⚙️ Tối ưu phần cứng (tự động)", color = C.Green, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Icon(if (showHw) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = C.Green)
                        }
                        Text("Không hardcode cho máy cụ thể — tự phát hiện chipset, GPU, RAM mỗi lần chạy.",
                            color = C.T2, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 4.dp))
                        if (showHw) {
                            Spacer(Modifier.height(8.dp))
                            Text(vm.hardwareSummary(), color = C.T2, fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("trạng thái model")
                    vm.modelStatus().forEach { (name, ok) ->
                        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (ok) Icons.Default.CheckCircle else Icons.Default.Cancel, null,
                                tint = if (ok) C.Green else C.Red, modifier = Modifier.size(16.dp))
                            Text(name, color = C.T1, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Text(if (ok) "sẵn sàng" else "thiếu", color = if (ok) C.Green else C.Red, fontSize = 11.sp)
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("chọn model")
                    ModelDropdown("SD Model", settings.sdModelPath, sdModels,
                        onSelect = { vm.updateSettings { copy(sdModelPath = it.path) } }, onRescan = { vm.rescanModels() })
                    Spacer(Modifier.height(14.dp))
                    ModelDropdown("LLM Model", settings.llmModelPath, llmModels,
                        onSelect = { vm.updateSettings { copy(llmModelPath = it.path) } }, onRescan = { vm.rescanModels() })
                    Spacer(Modifier.height(14.dp))
                    ModelDropdown("LoRA mặc định", settings.loraPath, loras,
                        onSelect = { vm.updateSettings { copy(loraPath = it.path) } }, onRescan = { vm.rescanModels() })
                }
            }

            item {
                MlCard {
                    MlLabel("upscale")
                    UpscaleOption.values().forEach { opt ->
                        val sel = settings.upscaleOption == opt
                        Row(Modifier.fillMaxWidth().clickable { vm.updateSettings { copy(upscaleOption = opt) } }
                            .padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = sel, onClick = { vm.updateSettings { copy(upscaleOption = opt) } },
                                colors = RadioButtonDefaults.colors(selectedColor = C.Blue, unselectedColor = C.T3))
                            Text(opt.label, color = if (sel) C.T1 else C.T2, fontSize = 13.sp)
                        }
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("🌡️ kiểm soát nhiệt độ")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Ngưỡng dừng", color = C.T2, fontSize = 12.sp)
                        Text("${settings.thermalThreshold}°C", color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = settings.thermalThreshold.toFloat(),
                        onValueChange = { vm.updateSettings { copy(thermalThreshold = it.toInt()) } },
                        valueRange = 35f..55f,
                        colors = SliderDefaults.colors(thumbColor = C.Red, activeTrackColor = C.Red, inactiveTrackColor = C.Border))
                    Text("Khi vượt ngưỡng, pipeline tự tạm dừng + rung báo động",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Tự động tiếp tục", color = C.T1, fontSize = 13.sp)
                            Text("Khi nguội xuống ngưỡng - 3°C", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.autoResume, onCheckedChange = { vm.updateSettings { copy(autoResume = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("tham số sinh ảnh")
                    @Composable
                    fun SlRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, fmt: String = "%.0f", onChange: (Float) -> Unit) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label, color = C.T2, fontSize = 12.sp)
                            Text(fmt.format(value), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(value = value, onValueChange = onChange, valueRange = range,
                            colors = SliderDefaults.colors(thumbColor = C.Blue, activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                        Spacer(Modifier.height(4.dp))
                    }
                    SlRow("Steps", settings.steps.toFloat(), 10f..30f) { vm.updateSettings { copy(steps = it.toInt()) } }
                    SlRow("CFG Scale", settings.cfgScale, 3f..15f, "%.1f") { vm.updateSettings { copy(cfgScale = it) } }
                    SlRow("Threads", settings.nThreads.toFloat(), 1f..8f) { vm.updateSettings { copy(nThreads = it.toInt()) } }
                    Divider(color = C.Border, modifier = Modifier.padding(vertical = 8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Vulkan GPU", color = C.T1, fontSize = 13.sp)
                            Text("Tăng tốc Adreno GPU", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.useVulkan, onCheckedChange = { vm.updateSettings { copy(useVulkan = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("storydiffusion")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Consistent Self-Attention", color = C.T1, fontSize = 13.sp)
                            Text("Nhất quán mặt + trang phục + vóc dáng", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.useStoryDiffusion, onCheckedChange = { vm.updateSettings { copy(useStoryDiffusion = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                    if (settings.useStoryDiffusion) {
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Mức độ nhất quán", color = C.T2, fontSize = 12.sp)
                            Text("%.0f%%".format(settings.consistencyStrength * 100), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(value = settings.consistencyStrength, onValueChange = { vm.updateSettings { copy(consistencyStrength = it) } },
                            valueRange = 0.3f..1.0f,
                            colors = SliderDefaults.colors(thumbColor = C.Purple, activeTrackColor = C.Purple, inactiveTrackColor = C.Border))
                    }
                }
            }

            item {
                MlCard {
                    MlLabel("stack kỹ thuật · 100% local")
                    listOf(
                        "🧠 LLM" to "llama.cpp · chia scene + character detection",
                        "🎨 SD 1.5" to "sd.cpp · bất kỳ checkpoint",
                        "🔄 StoryDiffusion" to "Consistent Self-Attention",
                        "🔍 Upscale" to "Real-ESRGAN · 4 mức độ",
                        "💬 Auto Bubble" to "YOLOv8n ncnn · object detection",
                        "🌡️ Thermal" to "Kernel thermal_zone · auto pause",
                        "📄 Export" to "PDF + CBZ"
                    ).forEachIndexed { i, (t, d) ->
                        Column(Modifier.padding(vertical = 7.dp)) {
                            Text(t, color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(d, color = C.T3, fontSize = 11.sp)
                        }
                        if (i < 6) Divider(color = C.Border)
                    }
                }
            }
        }
    }
}
