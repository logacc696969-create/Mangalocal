package com.mangalocal.pipeline

import com.mangalocal.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MangaPipeline(
    private val storyManager: StoryManager,
    private val thermalMonitor: ThermalMonitor,
    private val runtimeOptimizer: RuntimeOptimizer
) {
    private val _state = MutableStateFlow(PipelineState())
    val state: StateFlow<PipelineState> = _state.asStateFlow()

    private val imagePipeline = ImagePipeline(storyManager)
    private val exportEngine  = ExportEngine()
    private val bubbleEngine  = BubbleEngine(storyManager)
    private var llmParser: LLMParser? = null
    private var job: Job? = null

    // Cache hardware profile — chỉ detect 1 lần, dùng lại cho mọi chương
    private val hwProfile by lazy { runtimeOptimizer.detectHardware() }
    private val optimalConfig by lazy { runtimeOptimizer.computeOptimalConfig(hwProfile) }

    // ── Giai đoạn 1: Sinh panel (dừng lại ở REVIEW) ───────────────────────
    suspend fun generatePanels(
        story: Story,
        storyText: String,
        settings: GenerationSettings,
        chapterId: String,
        chapterNumber: Int
    ): Chapter = coroutineScope {
        val outDir = storyManager.outputDir(story.id, chapterId)
        val startMs = System.currentTimeMillis()
        _state.update { PipelineState(startTimeMs = startMs) }
        thermalMonitor.start(settings.thermalThreshold)

        try {
            // LLM parse — dùng config tự động tối ưu theo phần cứng thực tế,
            // không hardcode. Nếu người dùng đổi máy, config này tự thay đổi
            // theo vì hwProfile detect lại chipset/GPU/RAM mỗi lần cài app mới.
            emit(PipelineStage.LLM_PARSING, "Khởi động LLM...")
            log("⚙️ Phần cứng: ${hwProfile.chipset} · Adreno~${hwProfile.adrenoGen} · ${hwProfile.bigCores} big core")
            log("⚙️ LLM dùng ${optimalConfig.nThreads} thread" +
                if (optimalConfig.useGpuForLlm) " + GPU offload (${optimalConfig.nGpuLayers} layer, ${optimalConfig.gpuBackend.name})"
                else " (CPU-only, không có GPU backend khả dụng)")
            val parser = LLMParser(settings.llmModelPath, optimalConfig.nThreads, optimalConfig.nGpuLayers)
            llmParser = parser
            parser.init()
            log("✓ LLM sẵn sàng")
            log("Đang phân tích truyện, chia ${settings.panelCount} scene...")
            val scenes = parser.parseStory(storyText, settings.panelCount)
            log("✓ Chia được ${scenes.size} scene")

            // Auto character detection
            val freq = parser.extractCharacterFrequency(scenes)
            val newChars = freq.keys.filter { name ->
                story.characters.none { it.name.equals(name, ignoreCase = true) }
            }
            if (newChars.isNotEmpty()) {
                log("✓ Phát hiện ${newChars.size} nhân vật mới: ${newChars.joinToString(", ")}")
                newChars.forEach { name ->
                    val role = storyManager.autoClassifyCharacter(name, freq[name] ?: 0, scenes.size)
                    val char = Character(
                        id = UUID.randomUUID().toString(), name = name,
                        anchorPrompt = "$name character",
                        seed = (10000L..99999L).random(), role = role
                    )
                    storyManager.saveCharacter(story.id, char)
                    log("  → $name: ${role.name.lowercase()}")
                }
            }

            // Build prompts
            emit(PipelineStage.PROMPT_BUILDING, "Sinh prompt từng panel...")
            val allChars = storyManager.loadStory(story.id)?.characters ?: story.characters
            val charMap = allChars.associate { it.name to it.anchorPrompt }
            val panels = scenes.mapIndexed { i, scene ->
                log("  Prompt panel ${i+1}: ${scene.description.take(45)}...")
                val (pos, neg) = parser.buildPrompt(scene, charMap, settings.imageStyle.stylePrompt)
                Panel(index = i, scene = scene, prompt = pos, negativePrompt = neg)
            }
            parser.free(); llmParser = null
            log("✓ ${panels.size} prompt sẵn sàng")

            // Load SD model
            emit(PipelineStage.SD_GENERATING, totalPanels = panels.size)
            log("Load SD model (${optimalConfig.sdNThreads} thread" +
                if (optimalConfig.sdUseVulkan) " + Vulkan)" else ", CPU-only)")
            val primaryChar = allChars.firstOrNull()
            imagePipeline.loadSD(settings.sdModelPath,
                primaryChar?.loraPath ?: settings.loraPath,
                primaryChar?.loraWeight ?: settings.loraWeight,
                optimalConfig.sdNThreads, optimalConfig.sdUseVulkan && settings.useVulkan)
            log("✓ SD model loaded")
            if (settings.useStoryDiffusion) log("✓ StoryDiffusion: BẬT")

            // Generate panels với thermal check
            val completedPanels = mutableListOf<Panel>()

            panels.forEach { panel ->
                // Thermal gate
                waitForThermalSafe(settings)

                _state.update { it.copy(currentPanel = panel.index + 1) }
                val charId = panel.scene.characters.firstOrNull()

                // Lấy reference embeddings: anchor nhân vật (nếu MAIN/SUPPORTING)
                val refs = mutableListOf<String>()
                charId?.let { name ->
                    storyManager.getCharacterAnchor(story.id, name)?.let { refs.add(it) }
                }

                log("SD panel ${panel.index + 1}/${panels.size}" + if (refs.isNotEmpty()) " [anchor ✓]" else "")

                val rawPath = imagePipeline.generatePanel(
                    panel, settings, refs.toTypedArray(), outDir
                ) { step, total -> _state.update { it.copy(currentStep = step, totalSteps = total) } }

                // Lưu anchor nếu là lần đầu nhân vật MAIN/SUPPORTING xuất hiện
                charId?.let { name ->
                    val char = storyManager.loadStory(story.id)?.characters?.find { it.name == name }
                    if (char != null && char.role != CharacterRole.ONETIME && char.anchorEmbeddingPath == null) {
                        val embPath = File(storyManager.anchorsDir(story.id), "anchor_${char.id}.bin").absolutePath
                        if (imagePipeline.saveEmbedding(rawPath, embPath)) {
                            storyManager.saveCharacterAnchor(story.id, char.id, rawPath, embPath)
                            log("  → Lưu anchor cho $name")
                        }
                    }
                }

                val elapsed = (System.currentTimeMillis() - startMs) / 1000
                log("✓ Panel ${panel.index + 1} xong (${elapsed}s tổng)")

                completedPanels.add(panel.copy(
                    imagePath = rawPath, status = PanelStatus.DONE,
                    generationTimeMs = System.currentTimeMillis() - startMs
                ))
                emit(PipelineStage.SD_GENERATING)
            }

            imagePipeline.freeAll()
            thermalMonitor.stop()

            // Dừng ở REVIEW - người dùng duyệt panel trước khi upscale
            emit(PipelineStage.REVIEW, "✓ Sinh xong! Hãy duyệt từng panel trước khi upscale")
            _state.update { it.copy(stage = PipelineStage.REVIEW) }

            Chapter(
                id = chapterId, storyId = story.id, title = "Chương $chapterNumber",
                chapterNumber = chapterNumber, storyText = storyText, style = settings.imageStyle,
                panels = completedPanels, status = ChapterStatus.REVIEW
            )
        } catch (e: Exception) {
            _state.update { it.copy(stage = PipelineStage.ERROR, error = e.message) }
            llmParser?.free(); imagePipeline.freeAll(); thermalMonitor.stop()
            throw e
        }
    }

    // ── Regenerate 1 panel (từ Gallery Review) ─────────────────────────────
    suspend fun regeneratePanel(
        panel: Panel,
        story: Story,
        settings: GenerationSettings,
        outDir: File
    ): Panel = withContext(Dispatchers.IO) {
        if (!imagePipeline.isSdLoaded()) {
            imagePipeline.loadSD(settings.sdModelPath, settings.loraPath, settings.loraWeight,
                optimalConfig.sdNThreads, optimalConfig.sdUseVulkan && settings.useVulkan)
        }
        val charId = panel.scene.characters.firstOrNull()
        val refs = mutableListOf<String>()
        charId?.let { name -> storyManager.getCharacterAnchor(story.id, name)?.let { refs.add(it) } }

        val rawPath = imagePipeline.generatePanel(panel, settings, refs.toTypedArray(), outDir) { _, _ -> }
        panel.copy(imagePath = rawPath, status = PanelStatus.DONE, upscaledPath = null)
    }

    // ── Giai đoạn 2: Upscale (sau khi user đã duyệt hết panel) ─────────────
    suspend fun upscaleApprovedPanels(
        chapter: Chapter,
        settings: GenerationSettings,
        outDir: File
    ): Chapter = coroutineScope {
        emit(PipelineStage.UPSCALING, "Upscale ${chapter.panels.size} panel đã duyệt...")
        thermalMonitor.start(settings.thermalThreshold)

        if (settings.upscaleOption != UpscaleOption.NONE) {
            imagePipeline.loadEsrgan(settings.upscaleOption.factor)
        }

        val updated = chapter.panels.map { panel ->
            waitForThermalSafe(settings)
            val path = panel.imagePath ?: return@map panel
            val hd = imagePipeline.upscale(path, panel.index, outDir, settings.upscaleOption)
            log("✓ Panel ${panel.index + 1} upscale xong")
            panel.copy(upscaledPath = hd)
        }
        imagePipeline.freeEsrganOnly()
        thermalMonitor.stop()
        chapter.copy(panels = updated, status = ChapterStatus.DONE)
    }

    // ── Giai đoạn 3 (tùy chọn): Auto bubble bằng YOLOv8 ────────────────────
    suspend fun autoPlaceBubbles(chapter: Chapter): Chapter = withContext(Dispatchers.IO) {
        emit(PipelineStage.BUBBLE_AUTO, "Tải YOLOv8n để detect vị trí nhân vật...")
        val loaded = bubbleEngine.loadYolo()
        if (!loaded) {
            log("⚠ Không có YOLOv8n, dùng vị trí mặc định")
        }

        val updated = chapter.panels.map { panel ->
            val imgPath = panel.upscaledPath ?: panel.imagePath ?: return@map panel
            val bubbles = if (loaded) {
                bubbleEngine.autoPplaceBubbles(imgPath, panel.scene.dialogue)
            } else {
                bubbleEngine.defaultBubbles(panel.scene.dialogue)
            }
            log("✓ Panel ${panel.index + 1}: ${bubbles.size} bubble")
            panel.copy(bubbles = bubbles)
        }
        bubbleEngine.freeYolo()
        chapter.copy(panels = updated)
    }

    // ── Giai đoạn 4: Export ─────────────────────────────────────────────────
    suspend fun exportChapter(chapter: Chapter, outDir: File): Chapter = withContext(Dispatchers.IO) {
        emit(PipelineStage.LAYOUT_EXPORT, "Xuất PDF và CBZ...")
        val pdfPath = exportEngine.exportPdf(chapter.panels, outDir, chapter.title)
        val cbzPath = exportEngine.exportCbz(chapter.panels, outDir)
        log("✅ Hoàn thành!")
        _state.update { it.copy(stage = PipelineStage.DONE) }
        chapter.copy(pdfPath = pdfPath, cbzPath = cbzPath)
    }

    // ── Thermal gate ─────────────────────────────────────────────────────
    private suspend fun waitForThermalSafe(settings: GenerationSettings) {
        while (thermalMonitor.state.value.isOverheating) {
            _state.update { it.copy(
                isPaused = true, pauseReason = PauseReason.THERMAL,
                currentTempC = thermalMonitor.state.value.currentTempC
            )}
            log("🔥 Máy đang nóng ${thermalMonitor.state.value.currentTempC}°C — tạm dừng", LogLevel.WARN)
            delay(2000)
            if (!settings.autoResume) {
                // Chờ người dùng resume thủ công - check lại mỗi 2s
                continue
            }
        }
        if (_state.value.isPaused) {
            log("✓ Máy đã nguội, tiếp tục...", LogLevel.OK)
            _state.update { it.copy(isPaused = false, pauseReason = null) }
        }
    }

    fun cancel() {
        job?.cancel()
        llmParser?.free()
        imagePipeline.freeAll()
        bubbleEngine.freeYolo()
        thermalMonitor.stop()
        _state.value = PipelineState()
    }

    private fun emit(stage: PipelineStage, msg: String? = null, totalPanels: Int? = null) {
        _state.update { prev -> prev.copy(
            stage = stage, totalPanels = totalPanels ?: prev.totalPanels,
            log = if (msg != null) prev.log + LogEntry(time(), msg) else prev.log
        )}
    }

    private fun log(msg: String, level: LogLevel = LogLevel.INFO) {
        val lvl = when {
            msg.startsWith("✓") || msg.startsWith("✅") -> LogLevel.OK
            msg.startsWith("⚠") || msg.startsWith("🔥") -> LogLevel.WARN
            msg.startsWith("❌") -> LogLevel.ERROR
            else -> level
        }
        _state.update { it.copy(log = it.log + LogEntry(time(), msg, lvl)) }
    }

    private fun time() = SimpleDateFormat("mm:ss", Locale.getDefault()).format(Date())
}
