package com.mangalocal.pipeline

import com.mangalocal.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ImagePipeline(private val storyManager: StoryManager) {

    private var sdCtx: Long = 0
    private var esrganCtx: Long = 0
    private var loadedSdPath = ""

    suspend fun loadSD(modelPath: String, loraPath: String, loraWeight: Float, nThreads: Int, useVulkan: Boolean) =
        withContext(Dispatchers.IO) {
            if (modelPath == loadedSdPath) return@withContext
            if (sdCtx != 0L) { NativeBridge.sdFree(sdCtx); sdCtx = 0 }
            sdCtx = NativeBridge.sdInit(modelPath, loraPath, loraWeight, nThreads, useVulkan)
            if (sdCtx == 0L) throw RuntimeException("Không load được SD model:\n${modelPath.substringAfterLast('/')}")
            loadedSdPath = modelPath
        }

    suspend fun loadEsrgan(scale: Int) = withContext(Dispatchers.IO) {
        if (esrganCtx != 0L || scale <= 1) return@withContext
        if (!storyManager.hasEsrgan()) throw RuntimeException(
            "Thiếu ESRGAN model.\nĐặt vào: ${storyManager.esrganDir.absolutePath}")
        esrganCtx = NativeBridge.esrganInit(scale, storyManager.esrganDir.absolutePath)
        if (esrganCtx == 0L) throw RuntimeException("ESRGAN init thất bại")
    }

    suspend fun generatePanel(
        panel: Panel,
        settings: GenerationSettings,
        refEmbeddings: Array<String>,
        outDir: File,
        onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panel.index))
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        val seed = panel.scene.characters.firstOrNull()?.hashCode()?.toLong()
            ?.let { if (it < 0) it + Long.MAX_VALUE else it } ?: 42L

        val fullPrompt = panel.prompt + ", " + settings.imageStyle.stylePrompt
        val fullNeg    = panel.negativePrompt + ", " + settings.imageStyle.negPrompt

        val ok = if (settings.useStoryDiffusion && refEmbeddings.isNotEmpty()) {
            NativeBridge.sdTxt2ImgWithReference(
                sdCtx, fullPrompt, fullNeg, refEmbeddings, settings.consistencyStrength,
                settings.width, settings.height, settings.steps, settings.cfgScale, seed,
                outFile.absolutePath, cb
            )
        } else {
            NativeBridge.sdTxt2Img(
                sdCtx, fullPrompt, fullNeg,
                settings.width, settings.height, settings.steps, settings.cfgScale, seed,
                outFile.absolutePath, cb
            )
        }
        if (!ok) throw RuntimeException("SD generate thất bại tại panel ${panel.index + 1}")
        outFile.absolutePath
    }

    fun saveEmbedding(imagePath: String, embeddingPath: String): Boolean =
        NativeBridge.sdSaveLatentEmbedding(sdCtx, imagePath, embeddingPath)

    suspend fun upscale(inputPath: String, panelIndex: Int, outDir: File, option: UpscaleOption): String =
        withContext(Dispatchers.IO) {
            if (option == UpscaleOption.NONE) return@withContext inputPath
            val outFile = File(outDir, "panel_%03d_hd.png".format(panelIndex))
            val ok = NativeBridge.esrganUpscale(esrganCtx, inputPath, outFile.absolutePath, option.sharpen)
            if (!ok) throw RuntimeException("Upscale thất bại tại panel ${panelIndex + 1}")
            outFile.absolutePath
        }

    fun isSdLoaded() = sdCtx != 0L

    fun freeAll() {
        if (sdCtx != 0L) { NativeBridge.sdFree(sdCtx); sdCtx = 0; loadedSdPath = "" }
        if (esrganCtx != 0L) { NativeBridge.esrganFree(esrganCtx); esrganCtx = 0 }
    }

    fun freeEsrganOnly() {
        if (esrganCtx != 0L) { NativeBridge.esrganFree(esrganCtx); esrganCtx = 0 }
    }
}
