package com.mangalocal.pipeline

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.mangalocal.model.*
import java.io.File

class StoryManager(context: Context) {

    private val rootDir = File(
        android.os.Environment.getExternalStorageDirectory(), "MangaLocal"
    ).also { it.mkdirs() }

    private val storiesDir  = File(rootDir, "stories").also  { it.mkdirs() }
    val modelsDir   = File(rootDir, "models").also   { it.mkdirs() }
    val lorasDir    = File(rootDir, "loras").also    { it.mkdirs() }
    val esrganDir   = File(rootDir, "esrgan").also   { it.mkdirs() }
    val yoloDir     = File(rootDir, "yolo").also     { it.mkdirs() }

    private val gson = Gson()

    // ── Story CRUD ────────────────────────────────────────────────────────

    fun saveStory(story: Story) {
        val dir = storyDir(story.id).also { it.mkdirs() }
        File(dir, "story.json").writeText(gson.toJson(story))
    }

    fun loadStory(storyId: String): Story? = try {
        val f = File(storyDir(storyId), "story.json")
        if (f.exists()) gson.fromJson(f.readText(), Story::class.java) else null
    } catch (e: Exception) { null }

    fun loadAllStories(): List<Story> = storiesDir.listFiles()
        ?.filter { it.isDirectory }
        ?.mapNotNull { loadStory(it.name) }
        ?.sortedByDescending { it.updatedAt }
        ?: emptyList()

    fun deleteStory(storyId: String) {
        storyDir(storyId).deleteRecursively()
    }

    // ── Character management ──────────────────────────────────────────────

    fun saveCharacter(storyId: String, character: Character) {
        val story = loadStory(storyId) ?: return
        val updated = story.copy(
            characters = story.characters.filter { it.id != character.id } + character,
            updatedAt = System.currentTimeMillis()
        )
        saveStory(updated)
    }

    fun deleteCharacter(storyId: String, characterId: String) {
        val story = loadStory(storyId) ?: return
        val char = story.characters.find { it.id == characterId }

        // Xóa anchor files nếu có
        char?.anchorEmbeddingPath?.let { File(it).delete() }
        char?.anchorImagePath?.let { File(it).delete() }

        saveStory(story.copy(
            characters = story.characters.filter { it.id != characterId },
            updatedAt = System.currentTimeMillis()
        ))
    }

    // Lưu anchor embedding của nhân vật (vĩnh viễn)
    fun saveCharacterAnchor(
        storyId: String,
        characterId: String,
        imagePath: String,
        embeddingPath: String
    ) {
        val story = loadStory(storyId) ?: return
        val char = story.characters.find { it.id == characterId } ?: return
        val updated = char.copy(
            anchorImagePath = imagePath,
            anchorEmbeddingPath = embeddingPath
        )
        saveCharacter(storyId, updated)
    }

    // Lấy anchor embedding của nhân vật theo tên
    fun getCharacterAnchor(storyId: String, name: String): String? {
        val story = loadStory(storyId) ?: return null
        return story.characters
            .find { it.name.equals(name, ignoreCase = true) }
            ?.anchorEmbeddingPath
            ?.takeIf { File(it).exists() }
    }

    // Tự động phân loại nhân vật mới từ LLM output
    fun autoClassifyCharacter(name: String, appearances: Int, totalPanels: Int): CharacterRole {
        val ratio = appearances.toFloat() / totalPanels
        return when {
            ratio >= 0.5f -> CharacterRole.MAIN        // xuất hiện > 50% panel
            ratio >= 0.15f -> CharacterRole.SUPPORTING // xuất hiện 15-50%
            else -> CharacterRole.ONETIME              // xuất hiện < 15%
        }
    }

    // ── Chapter management ────────────────────────────────────────────────

    fun saveChapter(chapter: Chapter) {
        val dir = chapterDir(chapter.storyId, chapter.id).also { it.mkdirs() }
        File(dir, "chapter.json").writeText(gson.toJson(chapter))

        // Update story chapterIds
        val story = loadStory(chapter.storyId) ?: return
        if (chapter.id !in story.chapterIds) {
            saveStory(story.copy(
                chapterIds = story.chapterIds + chapter.id,
                updatedAt = System.currentTimeMillis()
            ))
        }
    }

    fun loadChapter(storyId: String, chapterId: String): Chapter? = try {
        val f = File(chapterDir(storyId, chapterId), "chapter.json")
        if (f.exists()) gson.fromJson(f.readText(), Chapter::class.java) else null
    } catch (e: Exception) { null }

    fun loadAllChapters(storyId: String): List<Chapter> {
        val story = loadStory(storyId) ?: return emptyList()
        return story.chapterIds.mapNotNull { loadChapter(storyId, it) }
            .sortedBy { it.chapterNumber }
    }

    // ── Directories ───────────────────────────────────────────────────────

    fun storyDir(storyId: String) = File(storiesDir, storyId)
    fun chapterDir(storyId: String, chapterId: String) = File(storyDir(storyId), "chapters/$chapterId")
    fun anchorsDir(storyId: String) = File(storyDir(storyId), "anchors").also { it.mkdirs() }
    fun outputDir(storyId: String, chapterId: String) = File(chapterDir(storyId, chapterId), "output").also { it.mkdirs() }

    // ── Model scanning ────────────────────────────────────────────────────

    fun scanSdModels() = modelsDir.listFiles()
        ?.filter { it.extension in listOf("safetensors", "ckpt") }
        ?.map { ModelInfo(it.absolutePath, it.nameWithoutExtension, ModelType.SD15, it.length()) }
        ?.sortedBy { it.name } ?: emptyList()

    fun scanLlmModels() = modelsDir.listFiles()
        ?.filter { it.extension == "gguf" }
        ?.map { ModelInfo(it.absolutePath, it.nameWithoutExtension, ModelType.LLM, it.length()) }
        ?.sortedBy { it.name } ?: emptyList()

    fun scanLoras() = lorasDir.listFiles()
        ?.filter { it.extension == "safetensors" }
        ?.map { ModelInfo(it.absolutePath, it.nameWithoutExtension, ModelType.LORA, it.length()) }
        ?.sortedBy { it.name } ?: emptyList()

    fun hasEsrgan() = File(esrganDir, "realesrgan-x4plus.param").exists() &&
                      File(esrganDir, "realesrgan-x4plus.bin").exists()

    fun hasYolo() = File(yoloDir, "yolov8n.param").exists() &&
                    File(yoloDir, "yolov8n.bin").exists()

    fun modelStatus() = mapOf(
        "SD Model"  to scanSdModels().isNotEmpty(),
        "LLM Model" to scanLlmModels().isNotEmpty(),
        "ESRGAN"    to hasEsrgan(),
        "YOLOv8n (auto bubble)" to hasYolo()
    )

    fun setupGuide() = """
📁 /sdcard/MangaLocal/

models/
  ├── *.gguf          (LLM model)
  └── *.safetensors   (SD model)

loras/
  └── *.safetensors   (LoRA nhân vật)

esrgan/
  ├── realesrgan-x4plus.param
  └── realesrgan-x4plus.bin

yolo/ (tùy chọn, cho auto bubble)
  ├── yolov8n.param
  └── yolov8n.bin

Download:
· LLM: huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF
· SD: civitai.com
· ESRGAN: github.com/xinntao/Real-ESRGAN/releases
· YOLOv8n ncnn: github.com/ultralytics/assets/releases
    """.trimIndent()
}
