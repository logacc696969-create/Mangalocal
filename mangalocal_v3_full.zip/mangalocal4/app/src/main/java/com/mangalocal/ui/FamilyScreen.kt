package com.mangalocal.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*
import com.mangalocal.pipeline.FamilyManager
import com.mangalocal.pipeline.TraitInheritanceInfo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamilyRelationshipScreen(nav: NavController, vm: MainViewModel) {
    val story by vm.currentStory.collectAsState()
    if (story == null) { Box(Modifier.fillMaxSize()) { Text("...", color = C.T3) }; return }

    val chars = story!!.characters.filter { it.role == CharacterRole.MAIN || it.role == CharacterRole.SUPPORTING }
    val familyManager = remember { FamilyManager(vm.storyManager) }

    var childName       by remember { mutableStateOf("") }
    var childBaseDesc   by remember { mutableStateOf("") }
    var selectedParentA by remember { mutableStateOf<Character?>(null) }
    var selectedParentB by remember { mutableStateOf<Character?>(null) }
    var selectedRel     by remember { mutableStateOf(RelationshipType.PARENT_CHILD) }
    var childRole       by remember { mutableStateOf(CharacterRole.MAIN) }
    var childSeed       by remember { mutableStateOf((10000L..99999L).random()) }

    // Preview traits
    var previewPrompt  by remember { mutableStateOf("") }
    var traitList      by remember { mutableStateOf<List<TraitInheritanceInfo>>(emptyList()) }
    var showPreview    by remember { mutableStateOf(false) }

    fun updatePreview() {
        val pa = selectedParentA ?: return
        previewPrompt = familyManager.previewChildPrompt(
            story!!.id, pa.id, selectedParentB?.id,
            childBaseDesc, childSeed, selectedRel
        )
        traitList = familyManager.explainInheritance(
            story!!.id, pa.id, selectedParentB?.id,
            childSeed, selectedRel
        )
        showPreview = true
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Quan hệ huyết thống", fontWeight = FontWeight.Bold)
                        Text("Tạo nhân vật dựa trên di truyền", color = C.T3, fontSize = 10.sp)
                    }
                },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // Header giải thích
            item {
                Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("🧬 Di truyền thực tế", color = C.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Traits ngoại hình (màu mắt, hình mặt, màu tóc...) được kế thừa ngẫu nhiên " +
                            "từ cha/mẹ theo tỷ lệ sinh học thực tế. " +
                            "Con cái giống một phần — đây là hành vi đúng, không phải lỗi.",
                            color = C.T2, fontSize = 12.sp, lineHeight = 17.sp
                        )
                    }
                }
            }

            // Loại quan hệ
            item {
                MlCard {
                    MlLabel("loại quan hệ huyết thống")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(RelationshipType.values()) { rel ->
                            val sel = selectedRel == rel
                            Surface(
                                onClick = { selectedRel = rel; showPreview = false },
                                color = if (sel) C.BlueDim else C.S0,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (sel) C.Blue else C.Border)
                            ) {
                                Column(Modifier.padding(10.dp, 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(rel.label, color = if (sel) C.Blue else C.T2,
                                        fontSize = 11.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal)
                                    Text("≈%.0f%% gene chung".format(rel.blendRatio * 100),
                                        color = C.T3, fontSize = 9.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Chọn cha/mẹ
            item {
                MlCard {
                    MlLabel("chọn cha / mẹ")

                    if (chars.isEmpty()) {
                        Text("Cần có ít nhất 1 nhân vật đã tạo để chọn làm cha/mẹ.",
                            color = C.Orange, fontSize = 12.sp)
                    } else {
                        Text("Cha/Mẹ A *", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                        ParentPicker(
                            selected = selectedParentA,
                            characters = chars.filter { it.id != selectedParentB?.id },
                            onSelect = { selectedParentA = it; showPreview = false },
                            label = "Chọn cha hoặc mẹ"
                        )

                        Spacer(Modifier.height(12.dp))

                        Text("Cha/Mẹ B (tùy chọn — để trống nếu đơn thân)",
                            color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                        ParentPicker(
                            selected = selectedParentB,
                            characters = chars.filter { it.id != selectedParentA?.id },
                            onSelect = { selectedParentB = it; showPreview = false },
                            label = "Không chọn",
                            allowNone = true
                        )

                        // Hiển thị tóm tắt cha/mẹ đã chọn
                        if (selectedParentA != null) {
                            Spacer(Modifier.height(10.dp))
                            Divider(color = C.Border)
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text("Cha/Mẹ A", color = C.T3, fontSize = 10.sp)
                                    Row(verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        CharAvatar(selectedParentA!!.name, 28.dp)
                                        Text(selectedParentA!!.name, color = C.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                                if (selectedParentB != null) Column(Modifier.weight(1f)) {
                                    Text("Cha/Mẹ B", color = C.T3, fontSize = 10.sp)
                                    Row(verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        CharAvatar(selectedParentB!!.name, 28.dp)
                                        Text(selectedParentB!!.name, color = C.Purple, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Thông tin nhân vật con
            item {
                MlCard {
                    MlLabel("thông tin nhân vật con")

                    @Composable
                    fun Field(label: String, value: String, hint: String, lines: Int = 1, onChange: (String) -> Unit) {
                        Text(label, color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
                        OutlinedTextField(
                            value = value, onValueChange = { onChange(it); showPreview = false },
                            modifier = Modifier.fillMaxWidth().let { if (lines > 1) it.height((lines*26+24).dp) else it },
                            placeholder = { Text(hint, color = C.T3, fontSize = 12.sp) },
                            singleLine = lines == 1,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                                focusedContainerColor = C.S0, unfocusedContainerColor = C.S0,
                                focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                        )
                        Spacer(Modifier.height(10.dp))
                    }

                    Field("Tên *", childName, "vd: Aria") { childName = it }
                    Field(
                        "Mô tả riêng (tuổi, giới tính, đặc điểm không di truyền)",
                        childBaseDesc,
                        "vd: young girl, 16 years old, high school student, shy personality",
                        lines = 2
                    ) { childBaseDesc = it }

                    Text("Vai trò", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                        CharacterRole.values().forEach { role ->
                            val sel = childRole == role
                            Surface(
                                onClick = { childRole = role },
                                color = if (sel) C.BlueDim else C.S0,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (sel) C.Blue else C.Border)
                            ) {
                                Text(
                                    when (role) { CharacterRole.MAIN -> "Chính"; CharacterRole.SUPPORTING -> "Phụ"; CharacterRole.ONETIME -> "Một lần" },
                                    color = if (sel) C.Blue else C.T2, fontSize = 12.sp,
                                    modifier = Modifier.padding(10.dp, 7.dp)
                                )
                            }
                        }
                    }

                    // Seed với nút randomize
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("Seed di truyền", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
                            Text("$childSeed", color = C.T2, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text("Seed xác định CHÍNH XÁC traits nào được kế thừa", color = C.T3, fontSize = 10.sp)
                        }
                        IconButton(onClick = { childSeed = (10000L..99999L).random(); showPreview = false }) {
                            Icon(Icons.Default.Refresh, null, tint = C.Blue)
                        }
                    }
                }
            }

            // Preview di truyền
            item {
                MlOutlineBtn(
                    "🔬 Xem trước traits di truyền",
                    onClick = { if (selectedParentA != null) updatePreview() },
                    icon = Icons.Default.Visibility,
                    color = if (selectedParentA != null) C.Blue else C.T3
                )
            }

            if (showPreview && traitList.isNotEmpty()) item {
                MlCard {
                    MlLabel("traits sẽ được kế thừa · seed $childSeed")

                    // Bảng traits
                    traitList.forEach { trait ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Tên nhóm trait
                            Text(
                                trait.traitGroup.replace("_", " ").replaceFirstChar { it.uppercase() },
                                color = C.T2, fontSize = 11.sp, modifier = Modifier.width(80.dp)
                            )
                            // Parent A value
                            trait.parentAValue?.let {
                                Surface(C.BlueDim.copy(0.5f), RoundedCornerShape(5.dp)) {
                                    Text(it, color = C.Blue, fontSize = 10.sp, modifier = Modifier.padding(5.dp, 2.dp))
                                }
                            }
                            if (trait.parentBValue != null) {
                                Text(" + ", color = C.T3, fontSize = 11.sp)
                                Surface(C.PurpleDim.copy(0.5f), RoundedCornerShape(5.dp)) {
                                    Text(trait.parentBValue, color = C.Purple, fontSize = 10.sp, modifier = Modifier.padding(5.dp, 2.dp))
                                }
                            }
                            Text(" → ", color = C.T3, fontSize = 11.sp)
                            Surface(C.GreenDim, RoundedCornerShape(5.dp)) {
                                Text(trait.inheritedValue, color = C.Green, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(5.dp, 2.dp))
                            }
                            Spacer(Modifier.width(4.dp))
                            Text("(từ ${trait.fromParent})", color = C.T3, fontSize = 9.sp)
                        }
                        if (trait != traitList.last()) Divider(color = C.Border.copy(0.5f))
                    }

                    Spacer(Modifier.height(10.dp))
                    Divider(color = C.Border)
                    Spacer(Modifier.height(10.dp))

                    Text("Anchor prompt sẽ tạo:", color = C.T3, fontSize = 11.sp)
                    Surface(C.S0, RoundedCornerShape(8.dp)) {
                        Text(previewPrompt, color = C.T1, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                            lineHeight = 17.sp, modifier = Modifier.padding(10.dp))
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        "💡 Nhấn Refresh seed để thử kết quả di truyền khác — mỗi seed cho kết quả traits khác nhau.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp
                    )
                }
            }

            // Nút tạo
            item {
                MlBtn(
                    text = "🧬 Tạo nhân vật từ huyết thống",
                    onClick = {
                        if (childName.isNotBlank() && selectedParentA != null) {
                            vm.createChildCharacter(
                                childName = childName,
                                childBaseDesc = childBaseDesc,
                                parentAId = selectedParentA!!.id,
                                parentBId = selectedParentB?.id,
                                relationship = selectedRel,
                                childSeed = childSeed,
                                childRole = childRole
                            )
                            nav.popBackStack()
                        }
                    },
                    enabled = childName.isNotBlank() && selectedParentA != null,
                    icon = Icons.Default.FamilyRestroom
                )
            }
        }
    }
}

@Composable
private fun ParentPicker(
    selected: Character?,
    characters: List<Character>,
    onSelect: (Character) -> Unit,
    label: String,
    allowNone: Boolean = false
) {
    var expanded by remember { mutableStateOf(false) }

    Surface(
        onClick = { expanded = true },
        color = C.S0, shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (selected != null) C.Blue else C.Border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (selected != null) {
                CharAvatar(selected.name, 26.dp)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(selected.name, color = C.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(selected.anchorPrompt.take(40) + "…", color = C.T3, fontSize = 10.sp)
                }
            } else {
                Text(label, color = C.T3, fontSize = 12.sp, modifier = Modifier.weight(1f))
            }
            Icon(Icons.Default.ArrowDropDown, null, tint = C.T3)
        }
    }

    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
        if (allowNone) {
            DropdownMenuItem(
                text = { Text("Không chọn (đơn thân)", color = C.T3) },
                onClick = { onSelect(Character("", "", "", seed = 0L)); expanded = false },
                leadingIcon = { Icon(Icons.Default.Close, null, tint = C.T3, modifier = Modifier.size(16.dp)) }
            )
            Divider()
        }
        if (characters.isEmpty()) {
            DropdownMenuItem(text = { Text("Không có nhân vật phù hợp", color = C.T3) }, onClick = { expanded = false })
        }
        characters.forEach { char ->
            DropdownMenuItem(
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CharAvatar(char.name, 28.dp)
                        Column {
                            Text(char.name, color = C.T1, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text(char.anchorPrompt.take(45) + "…", color = C.T3, fontSize = 10.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                RoleChip(char.role)
                                if (char.anchorEmbeddingPath != null) MlChip("anchor ✓", C.Green, C.GreenDim)
                            }
                        }
                    }
                },
                onClick = { onSelect(char); expanded = false }
            )
        }
    }
}
