package com.mangalocal.pipeline

object NativeBridge {
    init { System.loadLibrary("mangalocal_native") }

    // ── LLM ──────────────────────────────────────────────────────────────
    external fun llamaInit(modelPath: String, nThreads: Int, nCtx: Int, nGpuLayers: Int): Long
    external fun llamaGenerate(ctx: Long, prompt: String, maxTokens: Int, temperature: Float): String
    external fun llamaFree(ctx: Long)

    // ── Stable Diffusion ─────────────────────────────────────────────────
    external fun sdInit(modelPath: String, loraPath: String, loraWeight: Float, nThreads: Int, useVulkan: Boolean): Long
    external fun sdTxt2Img(ctx: Long, prompt: String, negPrompt: String, width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long, outputPath: String, callback: SDProgressCallback): Boolean
    external fun sdTxt2ImgWithReference(ctx: Long, prompt: String, negPrompt: String, referenceEmbeddingPaths: Array<String>, consistencyStrength: Float, width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long, outputPath: String, callback: SDProgressCallback): Boolean
    external fun sdSaveLatentEmbedding(ctx: Long, imagePath: String, embeddingOutputPath: String): Boolean
    external fun sdFree(ctx: Long)

    // ── ESRGAN ───────────────────────────────────────────────────────────
    external fun esrganInit(scale: Int, modelDir: String): Long
    external fun esrganUpscale(ctx: Long, inputPath: String, outputPath: String, sharpen: Boolean): Boolean
    external fun esrganFree(ctx: Long)

    // ── YOLOv8n (object/face detection cho auto bubble) ──────────────────
    external fun yoloInit(modelDir: String): Long
    external fun yoloDetect(ctx: Long, imagePath: String): FloatArray // [x1,y1,x2,y2,conf, ...] normalized
    external fun yoloFree(ctx: Long)

    interface SDProgressCallback {
        fun onProgress(step: Int, totalSteps: Int)
    }
}
