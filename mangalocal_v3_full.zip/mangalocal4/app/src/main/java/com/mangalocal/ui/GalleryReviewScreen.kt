package com.mangalocal.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryReviewScreen(nav: NavController, vm: MainViewModel) {
    val chapter by vm.currentChapter.collectAsState()
    val isGenerating by vm.isGenerating.collectAsState()
    var selectedPanelIndex by remember { mutableStateOf<Int?>(null) }

    if (chapter == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Không có chapter", color = C.T3) }
        return
    }
    val ch = chapter!!
    val allApproved = ch.panels.all { it.status == PanelStatus.APPROVED }
    val isReviewStage = ch.status == ChapterStatus.REVIEW

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(ch.title) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        },
        containerColor = C.Bg
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(span = { GridItemSpan(2) }) {
                if (isReviewStage) {
                    Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                        Column(Modifier.padding(12.dp)) {
                            Text("📋 Duyệt panel trước khi upscale", color = C.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Đã duyệt: ${ch.approvedCount}/${ch.panels.size}. Nhấn vào panel để xem chi tiết, sửa, hoặc tạo lại.",
                                color = C.T2, fontSize = 12.sp, lineHeight = 16.sp)
                        }
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("${ch.panels.size}", "panel", Modifier.weight(1f))
                        StatCard(ch.status.name, "trạng thái", Modifier.weight(1f))
                    }
                }
            }

            items(ch.panels) { panel ->
                PanelCard(panel, onClick = { selectedPanelIndex = panel.index })
            }

            if (isReviewStage) item(span = { GridItemSpan(2) }) {
                Spacer(Modifier.height(4.dp))
                MlBtn(
                    text = if (allApproved) "➡️ Tiếp tục Upscale" else "Duyệt tất cả còn lại trước",
                    onClick = {
                        if (allApproved) { vm.proceedToUpscale(); nav.navigate("post_processing") }
                    },
                    enabled = allApproved && !isGenerating,
                    icon = Icons.Default.ArrowForward
                )
            }

            if (ch.status == ChapterStatus.DONE) item(span = { GridItemSpan(2) }) {
                Spacer(Modifier.height(4.dp))
                MlBtn("➡️ Tiếp theo: Hội thoại & Xuất file",
                    onClick = { nav.navigate("post_processing") }, icon = Icons.Default.ArrowForward)
            }
        }
    }

    selectedPanelIndex?.let { idx ->
        val panel = ch.panels.find { it.index == idx }
        if (panel != null) {
            EditPanelSheet(panel = panel, vm = vm, onDismiss = { selectedPanelIndex = null })
        }
    }
}

@Composable
private fun PanelCard(panel: Panel, onClick: () -> Unit) {
    Surface(onClick = onClick, color = C.S0, shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.5.dp, when (panel.status) {
            PanelStatus.APPROVED -> C.Green
            PanelStatus.REJECTED -> C.Red
            else -> C.Border
        }), modifier = Modifier.aspectRatio(3f/4f)) {
        Box {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("🖼️", fontSize = 30.sp)
                Text("Panel ${panel.index + 1}", color = C.T2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(panel.scene.description.take(30), color = C.T3, fontSize = 9.sp,
                    modifier = Modifier.padding(horizontal = 8.dp), maxLines = 2)
            }
            if (panel.status == PanelStatus.APPROVED) {
                Surface(Modifier.align(Alignment.TopEnd).padding(6.dp), C.GreenDim, RoundedCornerShape(6.dp)) {
                    Icon(Icons.Default.Check, null, tint = C.Green, modifier = Modifier.padding(4.dp).size(14.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditPanelSheet(panel: Panel, vm: MainViewModel, onDismiss: () -> Unit) {
    var editedPrompt by remember(panel.index) { mutableStateOf(panel.prompt) }
    var showPromptEdit by remember { mutableStateOf(false) }
    val isGenerating by vm.isGenerating.collectAsState()

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = C.S1) {
        Column(Modifier.fillMaxWidth().padding(16.dp).verticalScroll(rememberScrollState())) {
            Text("Panel ${panel.index + 1}", color = C.T1, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Text(panel.scene.description, color = C.T2, fontSize = 13.sp, lineHeight = 18.sp)

            Spacer(Modifier.height(14.dp))
            Surface(Modifier.fillMaxWidth().aspectRatio(1f), C.S0, RoundedCornerShape(12.dp)) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("🖼️ [preview ảnh 512px]", color = C.T3, fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(14.dp))

            if (showPromptEdit) {
                MlLabel("sửa prompt")
                OutlinedTextField(value = editedPrompt, onValueChange = { editedPrompt = it },
                    modifier = Modifier.fillMaxWidth().height(100.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                        focusedContainerColor = C.S0, unfocusedContainerColor = C.S0,
                        focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                    textStyle = LocalTextStyle.current.copy(fontSize = 12.sp))
                Spacer(Modifier.height(10.dp))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MlBtn("✓ Duyệt", onClick = { vm.approvePanel(panel.index); onDismiss() },
                    icon = Icons.Default.Check, modifier = Modifier.weight(1f))
                MlOutlineBtn(if (showPromptEdit) "Hủy sửa" else "✏️ Sửa prompt",
                    onClick = { showPromptEdit = !showPromptEdit }, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            MlOutlineBtn(
                text = if (showPromptEdit) "🔄 Tạo lại với prompt mới" else "🔄 Tạo lại (cùng prompt)",
                onClick = {
                    vm.regeneratePanel(panel.index, if (showPromptEdit) editedPrompt else null)
                    showPromptEdit = false
                },
                icon = Icons.Default.Refresh, color = C.Orange
            )

            Spacer(Modifier.height(14.dp))
            Divider(color = C.Border)
            Spacer(Modifier.height(14.dp))

            MlLabel("hội thoại trong panel này")
            if (panel.scene.dialogue.isEmpty()) {
                Text("Không có hội thoại được trích xuất", color = C.T3, fontSize = 12.sp)
            } else {
                panel.scene.dialogue.forEach { d ->
                    Row(Modifier.padding(vertical = 4.dp)) {
                        Text("${d.characterName}: ", color = C.Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(d.text, color = C.T2, fontSize = 12.sp)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
        }
    }
}
