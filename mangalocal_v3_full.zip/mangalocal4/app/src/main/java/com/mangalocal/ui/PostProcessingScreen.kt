package com.mangalocal.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostProcessingScreen(nav: NavController, vm: MainViewModel) {
    val chapter by vm.currentChapter.collectAsState()
    val isGenerating by vm.isGenerating.collectAsState()
    var selectedPanelIdx by remember { mutableStateOf(0) }

    if (chapter == null) { Box(Modifier.fillMaxSize()) { Text("...", color = C.T3) }; return }
    val ch = chapter!!
    val panel = ch.panels.getOrNull(selectedPanelIdx) ?: ch.panels.firstOrNull()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Hội thoại & Xuất file") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                MlCard {
                    MlLabel("hội thoại tự động (yolov8n)")
                    Text("Tải model nhận diện vị trí nhân vật → đặt bubble không che mặt.\nLoad xong sẽ được giải phóng RAM ngay.",
                        color = C.T2, fontSize = 12.sp, lineHeight = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    MlBtn("🤖 Tự động đặt hội thoại", onClick = { vm.runAutoBubble() },
                        enabled = !isGenerating, icon = Icons.Default.AutoFixHigh)
                }
            }

            item {
                MlCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        MlLabel("chỉnh thủ công · panel ${selectedPanelIdx + 1}")
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                        items(ch.panels) { p ->
                            Surface(onClick = { selectedPanelIdx = p.index },
                                color = if (p.index == selectedPanelIdx) C.BlueDim else C.S0,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (p.index == selectedPanelIdx) C.Blue else C.Border)) {
                                Text("${p.index + 1}", color = if (p.index == selectedPanelIdx) C.Blue else C.T2,
                                    fontSize = 12.sp, modifier = Modifier.padding(10.dp, 6.dp))
                            }
                        }
                    }

                    if (panel != null) {
                        BubbleEditCanvas(panel = panel,
                            onBubblesChanged = { vm.updatePanelBubbles(panel.index, it) })
                    }
                }
            }

            item {
                MlOutlineBtn("➕ Thêm hội thoại mới", icon = Icons.Default.Add, onClick = {
                    panel?.let { p ->
                        val newBubble = Bubble(UUID.randomUUID().toString(), "Nhân vật", "Nhập lời thoại...",
                            BubbleType.SPEECH, 0.3f, 0.3f, 0.4f, false)
                        vm.updatePanelBubbles(p.index, p.bubbles + newBubble)
                    }
                })
            }

            item {
                Divider(color = C.Border)
                Spacer(Modifier.height(4.dp))
                MlLabel("xuất file")
                MlBtn("📄 Xuất PDF + CBZ", onClick = { vm.exportChapter() }, icon = Icons.Default.Download)
            }

            if (ch.pdfPath != null) item {
                Surface(color = C.GreenDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Green.copy(0.4f))) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("✅", fontSize = 24.sp)
                        Column {
                            Text("Hoàn thành!", color = C.Green, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("PDF và CBZ đã sẵn sàng trong thư viện", color = C.T2, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BubbleEditCanvas(panel: Panel, onBubblesChanged: (List<Bubble>) -> Unit) {
    var bubbles by remember(panel.index) { mutableStateOf(panel.bubbles) }
    var editingBubble by remember { mutableStateOf<Bubble?>(null) }

    Box(Modifier.fillMaxWidth().aspectRatio(1f).background(C.S0, RoundedCornerShape(12.dp))
        .clip(RoundedCornerShape(12.dp))) {

        Text("🖼️ [ảnh panel ${panel.index + 1}]", color = C.T3, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.Center))

        bubbles.forEach { bubble ->
            var offset by remember(bubble.id) { mutableStateOf(Offset(bubble.xNorm, bubble.yNorm)) }
            Surface(
                color = Color.White.copy(0.92f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Color.Black),
                modifier = Modifier
                    .fillMaxWidth(bubble.widthNorm)
                    .offset(x = (offset.x * 300).dp, y = (offset.y * 300).dp)
                    .pointerInput(bubble.id) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            val newX = (offset.x + drag.x / 300f).coerceIn(0f, 1f - bubble.widthNorm)
                            val newY = (offset.y + drag.y / 300f).coerceIn(0f, 0.85f)
                            offset = Offset(newX, newY)
                            bubbles = bubbles.map {
                                if (it.id == bubble.id) it.copy(xNorm = newX, yNorm = newY) else it
                            }
                            onBubblesChanged(bubbles)
                        }
                    }
                    .clickable { editingBubble = bubble }
            ) {
                Column(Modifier.padding(6.dp)) {
                    Text(bubble.characterName, color = Color.DarkGray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(bubble.text.take(30), color = Color.Black, fontSize = 10.sp, maxLines = 2)
                }
            }
        }
    }
    Text("Kéo bubble để di chuyển · nhấn để sửa text", color = C.T3, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))

    editingBubble?.let { b ->
        BubbleTextEditDialog(bubble = b,
            onSave = { updated ->
                bubbles = bubbles.map { if (it.id == updated.id) updated else it }
                onBubblesChanged(bubbles)
                editingBubble = null
            },
            onDelete = {
                bubbles = bubbles.filter { it.id != b.id }
                onBubblesChanged(bubbles)
                editingBubble = null
            },
            onDismiss = { editingBubble = null })
    }
}

@Composable
private fun BubbleTextEditDialog(bubble: Bubble, onSave: (Bubble) -> Unit, onDelete: () -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(bubble.characterName) }
    var text by remember { mutableStateOf(bubble.text) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = C.S1,
        title = { Text("Sửa hội thoại", color = C.T1) },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it },
                    label = { Text("Tên nhân vật") }, modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = text, onValueChange = { text = it },
                    label = { Text("Lời thoại") }, modifier = Modifier.fillMaxWidth().height(80.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(bubble.copy(characterName = name, text = text)) }) { Text("Lưu", color = C.Blue) }
        },
        dismissButton = {
            TextButton(onClick = onDelete) { Text("Xóa", color = C.Red) }
        }
    )
}
