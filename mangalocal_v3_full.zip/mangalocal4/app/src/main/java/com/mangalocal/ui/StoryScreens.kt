package com.mangalocal.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*

// ── STORY LIST ────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryListScreen(nav: NavController, vm: MainViewModel) {
    val stories by vm.stories.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newDesc by remember { mutableStateOf("") }
    var newStyle by remember { mutableStateOf(ImageStyle.REALISTIC) }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("MangaLocal", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("v3 · Multi-story", color = C.T3, fontSize = 10.sp)
                }
            }, actions = {
                IconButton(onClick = { showNew = !showNew }) {
                    Icon(if (showNew) Icons.Default.Close else Icons.Default.Add, null, tint = C.Blue)
                }
            }, colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        bottomBar = { AppNavBar(nav, "stories") },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            if (showNew) item {
                MlCard {
                    MlLabel("tạo truyện mới")
                    OutlinedTextField(value = newTitle, onValueChange = { newTitle = it },
                        label = { Text("Tên truyện", fontSize = 12.sp) }, modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                            focusedTextColor = C.T1, unfocusedTextColor = C.T1), singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newDesc, onValueChange = { newDesc = it },
                        label = { Text("Mô tả (tùy chọn)", fontSize = 12.sp) }, modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                            focusedTextColor = C.T1, unfocusedTextColor = C.T1))
                    Spacer(Modifier.height(8.dp))
                    Text("Style mặc định", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(ImageStyle.values()) { style ->
                            val sel = newStyle == style
                            Surface(onClick = { newStyle = style },
                                color = if (sel) C.BlueDim else C.S0, shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (sel) C.Blue else C.Border)) {
                                Text("${style.emoji} ${style.label}", color = if (sel) C.Blue else C.T2,
                                    fontSize = 11.sp, modifier = Modifier.padding(10.dp, 7.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    MlBtn("Tạo truyện", icon = Icons.Default.Add, enabled = newTitle.isNotBlank(),
                        onClick = {
                            vm.createStory(newTitle, newDesc, newStyle)
                            newTitle = ""; newDesc = ""; showNew = false
                            nav.navigate("story_detail")
                        })
                }
            }

            if (stories.isEmpty() && !showNew) item {
                Box(Modifier.fillMaxWidth().padding(top = 60.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("📚", fontSize = 48.sp)
                        Text("Chưa có truyện nào", color = C.T3, fontSize = 15.sp)
                        MlBtn("Tạo truyện đầu tiên", onClick = { showNew = true }, modifier = Modifier.width(200.dp))
                    }
                }
            }

            items(stories) { story ->
                MlCard(modifier = Modifier.clickable {
                    vm.selectStory(story); nav.navigate("story_detail")
                }) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(story.style.emoji, fontSize = 28.sp)
                        Column(Modifier.weight(1f)) {
                            Text(story.title, color = C.T1, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("${story.chapterIds.size} chương · ${story.characters.size} nhân vật",
                                color = C.T3, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = C.T3)
                    }
                }
            }
        }
    }
}

// ── STORY DETAIL ──────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryDetailScreen(nav: NavController, vm: MainViewModel) {
    val story by vm.currentStory.collectAsState()
    val chapters = remember(story) { story?.let { vm.storyManager.loadAllChapters(it.id) } ?: emptyList() }
    var storyText by remember { mutableStateOf("") }
    val isGenerating by vm.isGenerating.collectAsState()

    LaunchedEffect(isGenerating) { if (isGenerating) nav.navigate("generating") }

    if (story == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Đang tải...", color = C.T3) }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(story!!.title, fontSize = 16.sp) },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { nav.navigate("characters_detail") }) {
                        Icon(Icons.Default.People, null, tint = C.Blue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("${chapters.size}", "chương", Modifier.weight(1f))
                    StatCard("${story!!.characters.size}", "nhân vật", Modifier.weight(1f))
                    StatCard(story!!.style.emoji, "style", Modifier.weight(1f))
                }
            }

            item {
                MlCard {
                    MlLabel("viết chương mới")
                    OutlinedTextField(value = storyText, onValueChange = { storyText = it },
                        modifier = Modifier.fillMaxWidth().height(140.dp),
                        placeholder = { Text("Dán nội dung chương vào đây...", color = C.T3, fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                            focusedContainerColor = C.S0, unfocusedContainerColor = C.S0,
                            focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp))
                    Spacer(Modifier.height(10.dp))
                    MlBtn("✨ Sinh panel", onClick = { vm.generatePanels(storyText) },
                        enabled = storyText.isNotBlank())
                }
            }

            if (chapters.isNotEmpty()) item {
                MlCard {
                    MlLabel("các chương (${chapters.size})")
                    chapters.forEach { ch ->
                        Row(Modifier.fillMaxWidth().clickable {
                            vm.selectChapter(ch); nav.navigate("gallery_review")
                        }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(ch.title, color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("${ch.panels.size} panel · ${ch.status.name.lowercase()}", color = C.T3, fontSize = 11.sp)
                            }
                            MlChip(ch.status.name, when (ch.status) {
                                ChapterStatus.DONE -> C.Green; ChapterStatus.REVIEW -> C.Orange
                                else -> C.T2
                            }, when (ch.status) {
                                ChapterStatus.DONE -> C.GreenDim; ChapterStatus.REVIEW -> C.OrangeDim
                                else -> C.S0
                            })
                        }
                        if (ch != chapters.last()) Divider(color = C.Border)
                    }
                }
            }
        }
    }
}
