package com.mangalocal.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.mangalocal.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharactersDetailScreen(nav: NavController, vm: MainViewModel) {
    val story by vm.currentStory.collectAsState()
    val loras by vm.loras.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var editingChar by remember { mutableStateOf<Character?>(null) }

    var newName by remember { mutableStateOf("") }
    var newAnchor by remember { mutableStateOf("") }
    var newNeg by remember { mutableStateOf("") }
    var newRole by remember { mutableStateOf(CharacterRole.MAIN) }
    var newSeed by remember { mutableStateOf("") }
    var selLora by remember { mutableStateOf<String?>(null) }

    if (story == null) { Box(Modifier.fillMaxSize()) { Text("...", color = C.T3) }; return }
    val chars = story!!.characters

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Nhân vật · ${story!!.title}") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                actions = { IconButton(onClick = { showAdd = !showAdd }) {
                    Icon(if (showAdd) Icons.Default.ExpandLess else Icons.Default.Add, null, tint = C.Blue)
                }}, colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0))
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("🎯 Phân loại nhân vật", color = C.Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("Chính: lưu anchor vĩnh viễn · Phụ: lưu tạm trong chương · Một lần: không lưu",
                            color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                }
            }

            listOf(CharacterRole.MAIN to "Nhân vật chính", CharacterRole.SUPPORTING to "Nhân vật phụ",
                CharacterRole.ONETIME to "Xuất hiện một lần").forEach { (role, label) ->
                val list = chars.filter { it.role == role }
                if (list.isNotEmpty()) {
                    item { MlLabel(label + " (${list.size})") }
                    items(list) { c -> CharacterCard(c, onClick = { editingChar = c }, onDelete = { vm.deleteCharacter(c.id) }) }
                }
            }

            if (chars.isEmpty()) item {
                Box(Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                    Text("Chưa có nhân vật. LLM sẽ tự phát hiện khi sinh chương,\nhoặc bạn thêm thủ công.",
                        color = C.T3, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }

            if (showAdd) item {
                MlCard {
                    MlLabel("thêm nhân vật mới")
                    @Composable
                    fun Field(label: String, value: String, hint: String, lines: Int = 1, onChange: (String) -> Unit) {
                        Text(label, color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
                        OutlinedTextField(value = value, onValueChange = onChange,
                            modifier = Modifier.fillMaxWidth().let { if (lines > 1) it.height((lines*26+24).dp) else it },
                            placeholder = { Text(hint, color = C.T3, fontSize = 12.sp) }, singleLine = lines == 1,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                                focusedContainerColor = C.S0, unfocusedContainerColor = C.S0, focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp))
                        Spacer(Modifier.height(10.dp))
                    }
                    Field("Tên *", newName, "vd: Aria") { newName = it }
                    Field("Anchor prompt * (mô tả ngoại hình)", newAnchor,
                        "vd: young woman, long black hair, brown eyes, red jacket", lines = 3) { newAnchor = it }
                    Field("Negative prompt", newNeg, "tùy chọn") { newNeg = it }
                    Field("Seed", newSeed, "để trống = ngẫu nhiên") { newSeed = it }

                    Text("Vai trò", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                        CharacterRole.values().forEach { role ->
                            val sel = newRole == role
                            Surface(onClick = { newRole = role }, color = if (sel) C.BlueDim else C.S0,
                                shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (sel) C.Blue else C.Border)) {
                                Text(when(role) { CharacterRole.MAIN -> "Chính"; CharacterRole.SUPPORTING -> "Phụ"; CharacterRole.ONETIME -> "Một lần" },
                                    color = if (sel) C.Blue else C.T2, fontSize = 12.sp, modifier = Modifier.padding(10.dp, 7.dp))
                            }
                        }
                    }

                    if (loras.isNotEmpty()) {
                        Text("LoRA (tùy chọn)", color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                            item {
                                Surface(onClick = { selLora = null }, color = if (selLora == null) C.BlueDim else C.S0,
                                    shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (selLora == null) C.Blue else C.Border)) {
                                    Text("Không", color = if (selLora == null) C.Blue else C.T2, fontSize = 12.sp, modifier = Modifier.padding(10.dp, 7.dp))
                                }
                            }
                            items(loras) { lora ->
                                Surface(onClick = { selLora = lora.path }, color = if (selLora == lora.path) C.BlueDim else C.S0,
                                    shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (selLora == lora.path) C.Blue else C.Border)) {
                                    Text(lora.name.take(18), color = if (selLora == lora.path) C.Blue else C.T2, fontSize = 12.sp, modifier = Modifier.padding(10.dp, 7.dp))
                                }
                            }
                        }
                    }

                    MlBtn("Lưu nhân vật", icon = Icons.Default.PersonAdd,
                        enabled = newName.isNotBlank() && newAnchor.isNotBlank(),
                        onClick = {
                            vm.addCharacter(newName, newAnchor, newNeg, newRole, selLora, newSeed.toLongOrNull())
                            newName = ""; newAnchor = ""; newNeg = ""; newSeed = ""; selLora = null; showAdd = false
                        })
                }
            }
        }
    }

    editingChar?.let { char ->
        EditCharacterDialog(character = char, vm = vm, onDismiss = { editingChar = null })
    }
}

@Composable
private fun CharacterCard(c: Character, onClick: () -> Unit, onDelete: () -> Unit) {
    MlCard(modifier = Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CharAvatar(c.name, 42.dp)
            Column(Modifier.weight(1f)) {
                Text(c.name, color = C.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("seed ${c.seed}", color = C.T3, fontSize = 11.sp)
                Text(c.anchorPrompt.take(50) + if (c.anchorPrompt.length > 50) "…" else "",
                    color = C.T2, fontSize = 11.sp, lineHeight = 15.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                RoleChip(c.role)
                Spacer(Modifier.height(6.dp))
                if (c.anchorEmbeddingPath != null) MlChip("anchor ✓", C.Green, C.GreenDim)
                Spacer(Modifier.height(6.dp))
                Icon(Icons.Default.Delete, null, tint = C.T3, modifier = Modifier.size(16.dp).clickable(onClick = onDelete))
            }
        }
    }
}

@Composable
private fun EditCharacterDialog(character: Character, vm: MainViewModel, onDismiss: () -> Unit) {
    var anchor by remember { mutableStateOf(character.anchorPrompt) }
    var seed by remember { mutableStateOf(character.seed.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.S1,
        title = { Text("Sửa: ${character.name}", color = C.T1) },
        text = {
            Column {
                OutlinedTextField(value = anchor, onValueChange = { anchor = it },
                    label = { Text("Anchor prompt") }, modifier = Modifier.fillMaxWidth().height(90.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = seed, onValueChange = { seed = it },
                    label = { Text("Seed") }, modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = C.T1, unfocusedTextColor = C.T1,
                        focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border))
                Spacer(Modifier.height(10.dp))
                if (character.anchorImagePath != null) {
                    Text("Ảnh anchor hiện tại đã lưu", color = C.Green, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                MlOutlineBtn("🔄 Tạo lại ảnh anchor từ prompt này", icon = Icons.Default.Refresh,
                    onClick = { vm.regenerateAnchor(character.copy(anchorPrompt = anchor)) })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.updateCharacter(character.copy(anchorPrompt = anchor, seed = seed.toLongOrNull() ?: character.seed))
                onDismiss()
            }) { Text("Lưu", color = C.Blue) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy", color = C.T3) } }
    )
}
