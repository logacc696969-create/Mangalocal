#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <algorithm>
#include "net.h"

extern unsigned char* stbi_load(const char*, int*, int*, int*, int);
extern void           stbi_image_free(void*);

#define TAG "YOLOv8n"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

struct Detection {
    float x1, y1, x2, y2, conf;
};

struct YoloWrapper {
    ncnn::Net net;
    int inputSize = 320; // input nhỏ cho nhanh trên SD888

    YoloWrapper(const std::string& modelDir) {
        net.opt.use_vulkan_compute = true;
        net.opt.num_threads = 4;
        std::string param = modelDir + "/yolov8n.param";
        std::string bin   = modelDir + "/yolov8n.bin";
        if (net.load_param(param.c_str()) != 0) { LOGE("param fail"); return; }
        if (net.load_model(bin.c_str())   != 0) { LOGE("bin fail"); return; }
        LOGI("YOLOv8n loaded");
    }

    std::vector<Detection> detect(const std::string& imagePath, float confThresh = 0.4f) {
        std::vector<Detection> results;
        int w, h, c;
        unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("load fail: %s", imagePath.c_str()); return results; }

        // Resize letterbox về inputSize x inputSize
        float scale = std::min((float)inputSize / w, (float)inputSize / h);
        int newW = (int)(w * scale), newH = (int)(h * scale);

        ncnn::Mat in = ncnn::Mat::from_pixels_resize(
            data, ncnn::Mat::PIXEL_RGB, w, h, newW, newH);

        ncnn::Mat inPad;
        int padW = inputSize - newW, padH = inputSize - newH;
        ncnn::copy_make_border(in, inPad, padH/2, padH - padH/2, padW/2, padW - padW/2,
            ncnn::BORDER_CONSTANT, 114.f);

        const float meanVals[3] = {0,0,0};
        const float normVals[3] = {1/255.f, 1/255.f, 1/255.f};
        inPad.substract_mean_normalize(meanVals, normVals);

        auto ex = net.create_extractor();
        ex.input("images", inPad);
        ncnn::Mat out;
        ex.extract("output0", out);

        // YOLOv8 output: [1, 84, 8400] -> chỉ lấy class "person" (index 0 trong COCO)
        // out có shape (8400, 84) sau permute trong ncnn thường là (84, 8400) hoặc dùng w/h trực tiếp
        int numBoxes = out.h;
        for (int i = 0; i < numBoxes; i++) {
            const float* row = out.row(i);
            float cx = row[0], cy = row[1], bw = row[2], bh = row[3];
            float personConf = row[4]; // class 0 = person

            if (personConf < confThresh) continue;

            float x1 = (cx - bw/2 - padW/2) / scale;
            float y1 = (cy - bh/2 - padH/2) / scale;
            float x2 = (cx + bw/2 - padW/2) / scale;
            float y2 = (cy + bh/2 - padH/2) / scale;

            // Normalize về 0-1
            results.push_back({
                std::clamp(x1/w, 0.f, 1.f), std::clamp(y1/h, 0.f, 1.f),
                std::clamp(x2/w, 0.f, 1.f), std::clamp(y2/h, 0.f, 1.f),
                personConf
            });
        }

        stbi_image_free(data);

        // NMS đơn giản
        std::sort(results.begin(), results.end(), [](auto& a, auto& b) { return a.conf > b.conf; });
        std::vector<Detection> filtered;
        for (auto& d : results) {
            bool overlap = false;
            for (auto& f : filtered) {
                float ox = std::max(0.f, std::min(d.x2,f.x2) - std::max(d.x1,f.x1));
                float oy = std::max(0.f, std::min(d.y2,f.y2) - std::max(d.y1,f.y1));
                if (ox * oy > 0.3f * (d.x2-d.x1)*(d.y2-d.y1)) { overlap = true; break; }
            }
            if (!overlap) filtered.push_back(d);
            if (filtered.size() >= 10) break;
        }

        LOGI("detected %zu boxes", filtered.size());
        return filtered;
    }
};

static std::string j2s_y(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_yoloInit(JNIEnv* e, jobject, jstring jDir) {
    return reinterpret_cast<jlong>(new YoloWrapper(j2s_y(e, jDir)));
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_mangalocal_pipeline_NativeBridge_yoloDetect(JNIEnv* e, jobject, jlong ptr, jstring jImg) {
    auto* yolo = reinterpret_cast<YoloWrapper*>(ptr);
    auto dets = yolo->detect(j2s_y(e, jImg));

    jfloatArray result = e->NewFloatArray(dets.size() * 5);
    std::vector<float> flat;
    for (auto& d : dets) {
        flat.push_back(d.x1); flat.push_back(d.y1);
        flat.push_back(d.x2); flat.push_back(d.y2);
        flat.push_back(d.conf);
    }
    e->SetFloatArrayRegion(result, 0, flat.size(), flat.data());
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_yoloFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<YoloWrapper*>(ptr);
}
