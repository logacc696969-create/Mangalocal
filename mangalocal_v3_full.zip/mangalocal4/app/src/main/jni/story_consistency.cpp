#include "story_consistency.h"
#include <android/log.h>
#include <fstream>

#define TAG "StoryConsistency"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

bool saveLatentEmbedding(sd_ctx_t* ctx, const std::string& imagePath, const std::string& outputPath) {
    int w, h, c;
    unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
    if (!data) { LOGE("cannot load %s", imagePath.c_str()); return false; }

    sd_image_t img{(uint32_t)w, (uint32_t)h, 3, data};
    float* embedding = nullptr;
    int embDim = 0;
    bool ok = sd_get_image_embedding(ctx, img, &embedding, &embDim);
    stbi_image_free(data);

    if (!ok || !embedding || embDim == 0) { LOGE("embedding extraction failed"); return false; }

    std::ofstream f(outputPath, std::ios::binary);
    if (!f.is_open()) { free(embedding); return false; }
    f.write(reinterpret_cast<const char*>(&embDim), sizeof(int32_t));
    f.write(reinterpret_cast<const char*>(embedding), embDim * sizeof(float));
    f.close();
    free(embedding);
    LOGI("saved %d dims -> %s", embDim, outputPath.c_str());
    return true;
}

bool loadEmbeddings(const std::vector<std::string>& paths, std::vector<std::vector<float>>& outEmbeddings) {
    outEmbeddings.clear();
    for (auto& path : paths) {
        std::ifstream f(path, std::ios::binary);
        if (!f.is_open()) continue;
        int32_t dim = 0;
        f.read(reinterpret_cast<char*>(&dim), sizeof(int32_t));
        if (dim <= 0 || dim > 100000) continue;
        std::vector<float> emb(dim);
        f.read(reinterpret_cast<char*>(emb.data()), dim * sizeof(float));
        outEmbeddings.push_back(std::move(emb));
    }
    return !outEmbeddings.empty();
}

std::vector<float> mergeEmbeddings(const std::vector<std::vector<float>>& embeddings, float anchorWeight) {
    if (embeddings.empty()) return {};
    size_t dim = embeddings[0].size();
    std::vector<float> merged(dim, 0.0f);
    float totalWeight = 0.0f;
    for (size_t i = 0; i < embeddings.size(); i++) {
        if (embeddings[i].size() != dim) continue;
        float w = (embeddings.size() == 1) ? 1.0f :
                  (i == 0 ? anchorWeight : (1.0f - anchorWeight) / (embeddings.size() - 1));
        for (size_t j = 0; j < dim; j++) merged[j] += embeddings[i][j] * w;
        totalWeight += w;
    }
    if (totalWeight > 0) for (auto& v : merged) v /= totalWeight;
    return merged;
}

bool generateWithConsistency(
    sd_ctx_t* ctx, const std::string& prompt, const std::string& negPrompt,
    const std::vector<std::string>& refEmbeddingPaths, float consistencyStrength,
    int width, int height, int steps, float cfgScale, int64_t seed,
    const std::string& outputPath, sd_progress_callback progressCb, void* cbData
) {
    std::vector<std::vector<float>> embeddings;
    bool hasRefs = loadEmbeddings(refEmbeddingPaths, embeddings);

    if (hasRefs) {
        auto merged = mergeEmbeddings(embeddings);
        sd_set_reference_embedding(ctx, merged.data(), (int)merged.size(), consistencyStrength);
        LOGI("injected %zu refs, strength=%.2f", embeddings.size(), consistencyStrength);
    }

    sd_image_t* imgs = txt2img(ctx, prompt.c_str(), negPrompt.c_str(),
        0, cfgScale, width, height, EULER_A, steps, seed, 1, nullptr, 0.f, 0.f, false, "");

    if (hasRefs) sd_clear_reference_embedding(ctx);

    bool ok = false;
    if (imgs && imgs[0].data) {
        ok = stbi_write_png(outputPath.c_str(), width, height, imgs[0].channel, imgs[0].data, 0) != 0;
        free(imgs[0].data);
    }
    if (imgs) free(imgs);
    return ok;
}
