#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <algorithm>
#include "net.h"

extern unsigned char* stbi_load(const char*, int*, int*, int*, int);
extern void           stbi_image_free(void*);
extern int            stbi_write_png(const char*, int, int, int, const void*, int);

#define TAG "ESRGAN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

struct EsrganWrapper {
    ncnn::Net net;
    int scale;
    int tileSize = 128;

    EsrganWrapper(int s, const std::string& modelDir) : scale(s) {
        net.opt.use_vulkan_compute = true;
        net.opt.num_threads = 4;
        std::string param = modelDir + "/realesrgan-x4plus.param";
        std::string bin   = modelDir + "/realesrgan-x4plus.bin";
        if (net.load_param(param.c_str()) != 0) { LOGE("param fail"); return; }
        if (net.load_model(bin.c_str())   != 0) { LOGE("bin fail"); return; }
        LOGI("ESRGAN x%d OK", scale);
    }

    void sharpenInPlace(std::vector<unsigned char>& buf, int w, int h) {
        // Unsharp mask đơn giản: 3x3 kernel
        std::vector<unsigned char> orig = buf;
        const float kernel[9] = {0,-0.5f,0, -0.5f,3.0f,-0.5f, 0,-0.5f,0};
        for (int y = 1; y < h-1; y++) {
            for (int x = 1; x < w-1; x++) {
                for (int c = 0; c < 3; c++) {
                    float sum = 0;
                    int k = 0;
                    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                        sum += orig[((y+dy)*w + (x+dx))*3 + c] * kernel[k++];
                    }
                    buf[(y*w+x)*3+c] = (unsigned char)std::clamp((int)sum, 0, 255);
                }
            }
        }
    }

    bool upscale(const std::string& in, const std::string& out, bool sharpen) {
        int w, h, c;
        unsigned char* data = stbi_load(in.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("load fail: %s", in.c_str()); return false; }

        int ow = w * scale, oh = h * scale;
        std::vector<unsigned char> outBuf(ow * oh * 3);

        for (int ty = 0; ty < h; ty += tileSize) {
            for (int tx = 0; tx < w; tx += tileSize) {
                int tw = std::min(tileSize, w - tx);
                int th = std::min(tileSize, h - ty);
                ncnn::Mat inp(tw, th, 3);
                for (int y = 0; y < th; y++) for (int x = 0; x < tw; x++) {
                    auto* p = data + ((ty+y)*w + (tx+x)) * 3;
                    inp.channel(0)[y*tw+x] = p[0]/255.f;
                    inp.channel(1)[y*tw+x] = p[1]/255.f;
                    inp.channel(2)[y*tw+x] = p[2]/255.f;
                }
                auto ex = net.create_extractor();
                ex.input("input", inp);
                ncnn::Mat outTile;
                ex.extract("output", outTile);
                int otw = tw*scale, oth = th*scale, otx = tx*scale, oty = ty*scale;
                for (int y = 0; y < oth; y++) for (int x = 0; x < otw; x++) {
                    auto* p = outBuf.data() + ((oty+y)*ow + (otx+x)) * 3;
                    p[0] = (unsigned char)std::clamp((int)(outTile.channel(0)[y*otw+x]*255), 0, 255);
                    p[1] = (unsigned char)std::clamp((int)(outTile.channel(1)[y*otw+x]*255), 0, 255);
                    p[2] = (unsigned char)std::clamp((int)(outTile.channel(2)[y*otw+x]*255), 0, 255);
                }
            }
        }
        stbi_image_free(data);
        if (sharpen) sharpenInPlace(outBuf, ow, oh);
        bool ok = stbi_write_png(out.c_str(), ow, oh, 3, outBuf.data(), ow*3) != 0;
        LOGI("upscale %dx%d -> %dx%d sharpen=%d: %s", w, h, ow, oh, sharpen, ok?"OK":"FAIL");
        return ok;
    }
};

static std::string j2s_e(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_esrganInit(JNIEnv* e, jobject, jint scale, jstring jDir) {
    return reinterpret_cast<jlong>(new EsrganWrapper(scale, j2s_e(e, jDir)));
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_esrganUpscale(JNIEnv* e, jobject, jlong ptr, jstring jin, jstring jout, jboolean sharpen) {
    return reinterpret_cast<EsrganWrapper*>(ptr)->upscale(j2s_e(e,jin), j2s_e(e,jout), sharpen) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_esrganFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<EsrganWrapper*>(ptr);
}
