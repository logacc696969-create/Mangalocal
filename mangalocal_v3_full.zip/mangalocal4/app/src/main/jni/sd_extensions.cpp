#include "stable-diffusion.h"
#include <cstring>
#include <cstdlib>

// StoryDiffusion extension: extract compact image embedding cho consistency
// Implementation post-process: downsample ảnh thành vector nhỏ gọn
// dùng để so sánh & inject vào conditioning (không sửa attention bên trong UNet)
extern "C" bool sd_get_image_embedding(sd_ctx_t* ctx, sd_image_t img, float** out_emb, int* out_dim) {
    if (!ctx || !img.data || !out_emb || !out_dim) return false;
    int dim = 16 * 16 * 3; // 768 floats - đủ chi tiết để encode đặc điểm khuôn mặt + trang phục
    float* emb = (float*)malloc(dim * sizeof(float));
    if (!emb) return false;

    for (int y = 0; y < 16; y++) {
        for (int x = 0; x < 16; x++) {
            int px = (x * (int)img.width) / 16;
            int py = (y * (int)img.height) / 16;
            px = px < (int)img.width  ? px : (int)img.width  - 1;
            py = py < (int)img.height ? py : (int)img.height - 1;
            auto* p = img.data + (py * img.width + px) * img.channel;
            emb[(y*16+x)*3+0] = p[0] / 255.f;
            emb[(y*16+x)*3+1] = p[1] / 255.f;
            emb[(y*16+x)*3+2] = p[2] / 255.f;
        }
    }
    *out_emb = emb; *out_dim = dim;
    return true;
}

// Lưu reference embedding global cho ctx hiện tại (đơn giản hóa, không thread-safe đa ctx)
static float* g_ref_embedding = nullptr;
static int g_ref_dim = 0;
static float g_ref_strength = 0.0f;

extern "C" bool sd_set_reference_embedding(sd_ctx_t* ctx, float* emb, int dim, float strength) {
    if (g_ref_embedding) { free(g_ref_embedding); g_ref_embedding = nullptr; }
    if (emb && dim > 0) {
        g_ref_embedding = (float*)malloc(dim * sizeof(float));
        memcpy(g_ref_embedding, emb, dim * sizeof(float));
        g_ref_dim = dim;
        g_ref_strength = strength;
    }
    return true;
}

extern "C" bool sd_clear_reference_embedding(sd_ctx_t* ctx) {
    if (g_ref_embedding) { free(g_ref_embedding); g_ref_embedding = nullptr; }
    g_ref_dim = 0; g_ref_strength = 0.0f;
    return true;
}
