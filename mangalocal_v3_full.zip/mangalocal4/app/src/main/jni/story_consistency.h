#pragma once
#include <string>
#include <vector>
#include "stable-diffusion.h"

#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image.h"
#include "stb_image_write.h"

bool saveLatentEmbedding(sd_ctx_t* ctx, const std::string& imagePath, const std::string& outputPath);
bool loadEmbeddings(const std::vector<std::string>& paths, std::vector<std::vector<float>>& out);
std::vector<float> mergeEmbeddings(const std::vector<std::vector<float>>& embeddings, float anchorWeight = 0.6f);
bool generateWithConsistency(
    sd_ctx_t* ctx,
    const std::string& prompt, const std::string& negPrompt,
    const std::vector<std::string>& refEmbeddingPaths,
    float consistencyStrength,
    int width, int height, int steps, float cfgScale, int64_t seed,
    const std::string& outputPath,
    sd_progress_callback progressCb, void* cbData
);
