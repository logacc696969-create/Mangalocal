#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>

#include "llama.h"
#include "stable-diffusion.h"
#include "story_consistency.h"

#define TAG "MangaLocal"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::string j2s(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

// ── LLM ───────────────────────────────────────────────────────────────────

struct LlamaHandle { llama_model* model; llama_context* ctx; };

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_llamaInit(JNIEnv* e, jobject, jstring jPath, jint nT, jint nCtx, jint nGpuLayers) {
    llama_backend_init();
    auto mp = llama_model_default_params();
    // nGpuLayers do RuntimeOptimizer tính từ hardware profile thực tế
    // (0 = CPU-only nếu OpenCL/Vulkan không khả dụng, tự fallback an toàn
    //  bên trong llama.cpp nếu backend GPU không init được dù layers > 0)
    mp.n_gpu_layers = nGpuLayers;
    auto* model = llama_load_model_from_file(j2s(e, jPath).c_str(), mp);
    if (!model) { LOGE("llama model failed"); return 0; }
    auto cp = llama_context_default_params();
    cp.n_ctx = (uint32_t)nCtx; cp.n_threads = cp.n_threads_batch = (uint32_t)nT;
    auto* ctx = llama_new_context_with_model(model, cp);
    if (!ctx) { llama_free_model(model); return 0; }
    LOGI("LLM init: threads=%d ctx=%d gpu_layers=%d", nT, nCtx, nGpuLayers);
    return reinterpret_cast<jlong>(new LlamaHandle{model, ctx});
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_mangalocal_pipeline_NativeBridge_llamaGenerate(JNIEnv* e, jobject, jlong ptr, jstring jp, jint maxTok, jfloat temp) {
    auto* h = reinterpret_cast<LlamaHandle*>(ptr);
    auto tokens = llama_tokenize(h->ctx, j2s(e, jp), true, true);
    auto batch = llama_batch_init((int)tokens.size(), 0, 1);
    for (int i = 0; i < (int)tokens.size(); i++) llama_batch_add(batch, tokens[i], i, {0}, false);
    batch.logits[batch.n_tokens - 1] = true;
    llama_decode(h->ctx, batch);
    auto* sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(temp));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(42));
    std::string result; int n = batch.n_tokens;
    while (n < (int)tokens.size() + maxTok) {
        auto tok = llama_sampler_sample(sampler, h->ctx, -1);
        if (llama_token_is_eog(h->model, tok)) break;
        char buf[128]; int len = llama_token_to_piece(h->model, tok, buf, sizeof(buf), 0, true);
        if (len > 0) result.append(buf, len);
        auto single = llama_batch_get_one(&tok, 1); llama_decode(h->ctx, single); n++;
    }
    llama_sampler_free(sampler); llama_batch_free(batch);
    return e->NewStringUTF(result.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_llamaFree(JNIEnv*, jobject, jlong ptr) {
    auto* h = reinterpret_cast<LlamaHandle*>(ptr);
    if (h) { llama_free(h->ctx); llama_free_model(h->model); delete h; }
    llama_backend_free();
}

// ── SD Progress callback ───────────────────────────────────────────────────

static JavaVM* g_jvm = nullptr;
static jobject g_cb  = nullptr;

static void sd_progress(int step, int steps, float, void*) {
    if (!g_cb || !g_jvm) return;
    JNIEnv* e; if (g_jvm->AttachCurrentThread(&e, nullptr) != JNI_OK) return;
    auto cls = e->GetObjectClass(g_cb);
    auto mid = e->GetMethodID(cls, "onProgress", "(II)V");
    if (mid) e->CallVoidMethod(g_cb, mid, step, steps);
    g_jvm->DetachCurrentThread();
}

// ── Stable Diffusion ───────────────────────────────────────────────────────

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdInit(JNIEnv* e, jobject,
    jstring jModel, jstring jLora, jfloat loraW, jint nT, jboolean useVk) {
    auto* ctx = new_sd_ctx(j2s(e,jModel).c_str(), "", "", "",
        j2s(e,jLora).c_str(), "", "", false, false, true,
        (int)nT, SD_TYPE_Q4_K, STD_DEFAULT_RNG, DEFAULT, false, false, false);
    if (!ctx) { LOGE("sd_ctx failed"); return 0; }
    e->GetJavaVM(&g_jvm);
    LOGI("SD init OK");
    return reinterpret_cast<jlong>(ctx);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2Img(JNIEnv* e, jobject,
    jlong ptr, jstring jp, jstring jn, jint w, jint h, jint steps,
    jfloat cfg, jlong seed, jstring jout, jobject cb) {
    auto* ctx = reinterpret_cast<sd_ctx_t*>(ptr);
    g_cb = e->NewGlobalRef(cb);
    auto* imgs = txt2img(ctx, j2s(e,jp).c_str(), j2s(e,jn).c_str(),
        0, cfg, w, h, EULER_A, steps, seed, 1, nullptr, 0.f, 0.f, false, "");
    bool ok = false;
    if (imgs && imgs[0].data) { ok = stbi_write_png(j2s(e,jout).c_str(), w, h, imgs[0].channel, imgs[0].data, 0) != 0; free(imgs[0].data); }
    if (imgs) free(imgs);
    e->DeleteGlobalRef(g_cb); g_cb = nullptr;
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdTxt2ImgWithReference(JNIEnv* e, jobject,
    jlong ptr, jstring jp, jstring jn, jobjectArray jRefs,
    jfloat strength, jint w, jint h, jint steps,
    jfloat cfg, jlong seed, jstring jout, jobject cb) {

    auto* ctx = reinterpret_cast<sd_ctx_t*>(ptr);
    g_cb = e->NewGlobalRef(cb);

    std::vector<std::string> refs;
    int refCount = e->GetArrayLength(jRefs);
    for (int i = 0; i < refCount; i++) {
        auto jstr = (jstring)e->GetObjectArrayElement(jRefs, i);
        refs.push_back(j2s(e, jstr));
        e->DeleteLocalRef(jstr);
    }

    bool ok = generateWithConsistency(ctx, j2s(e,jp), j2s(e,jn),
        refs, strength, w, h, steps, cfg, seed, j2s(e,jout), sd_progress, nullptr);

    e->DeleteGlobalRef(g_cb); g_cb = nullptr;
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdSaveLatentEmbedding(JNIEnv* e, jobject,
    jlong ptr, jstring jImg, jstring jOut) {
    auto* ctx = reinterpret_cast<sd_ctx_t*>(ptr);
    bool ok = saveLatentEmbedding(ctx, j2s(e,jImg), j2s(e,jOut));
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_sdFree(JNIEnv*, jobject, jlong ptr) {
    if (ptr) free_sd_ctx(reinterpret_cast<sd_ctx_t*>(ptr));
}
