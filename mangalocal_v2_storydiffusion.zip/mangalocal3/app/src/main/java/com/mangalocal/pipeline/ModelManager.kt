package com.mangalocal.pipeline

import android.content.Context
import com.mangalocal.model.ModelInfo
import com.mangalocal.model.ModelType
import java.io.File

class ModelManager(context: Context) {
    val rootDir    = File(android.os.Environment.getExternalStorageDirectory(), "MangaLocal").also { it.mkdirs() }
    val modelsDir  = File(rootDir, "models").also  { it.mkdirs() }
    val lorasDir   = File(rootDir, "loras").also   { it.mkdirs() }
    val outputsDir = File(rootDir, "outputs").also { it.mkdirs() }
    val esrganDir  = File(rootDir, "esrgan").also  { it.mkdirs() }

    fun scanSdModels() = modelsDir.listFiles()
        ?.filter { it.extension in listOf("safetensors", "ckpt") }
        ?.map { ModelInfo(it.absolutePath, it.nameWithoutExtension, ModelType.SD15, it.length()) }
        ?.sortedBy { it.name } ?: emptyList()

    fun scanLlmModels() = modelsDir.listFiles()
        ?.filter { it.extension == "gguf" }
        ?.map { ModelInfo(it.absolutePath, it.nameWithoutExtension, ModelType.LLM, it.length()) }
        ?.sortedBy { it.name } ?: emptyList()

    fun scanLoras() = lorasDir.listFiles()
        ?.filter { it.extension == "safetensors" }
        ?.map { ModelInfo(it.absolutePath, it.nameWithoutExtension, ModelType.LORA, it.length()) }
        ?.sortedBy { it.name } ?: emptyList()

    fun hasEsrgan() = File(esrganDir, "realesrgan-x4plus.param").exists() &&
                      File(esrganDir, "realesrgan-x4plus.bin").exists()

    fun newChapterDir(id: String) = File(outputsDir, id).also { it.mkdirs() }

    fun modelStatus() = mapOf(
        "SD Model"  to scanSdModels().isNotEmpty(),
        "LLM Model" to scanLlmModels().isNotEmpty(),
        "ESRGAN"    to hasEsrgan()
    )

    fun setupGuide() = """
📁 Đặt file vào thư mục trên bộ nhớ ngoài:

SD Model (.safetensors / .ckpt):
  ${modelsDir.absolutePath}/

LLM (.gguf):
  ${modelsDir.absolutePath}/

LoRA (.safetensors):
  ${lorasDir.absolutePath}/

ESRGAN (2 file):
  ${esrganDir.absolutePath}/
  → realesrgan-x4plus.param
  → realesrgan-x4plus.bin

Download ESRGAN:
github.com/xinntao/Real-ESRGAN/releases
    """.trimIndent()
}
