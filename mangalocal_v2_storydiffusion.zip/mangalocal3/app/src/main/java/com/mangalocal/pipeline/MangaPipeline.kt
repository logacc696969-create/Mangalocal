package com.mangalocal.pipeline

import com.mangalocal.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.text.SimpleDateFormat
import java.util.*

class MangaPipeline(val modelManager: ModelManager) {

    private val _state = MutableStateFlow(PipelineState())
    val state: StateFlow<PipelineState> = _state.asStateFlow()

    private val imagePipeline = ImagePipeline(modelManager)
    private val exportEngine  = ExportEngine()
    private var llmParser: LLMParser? = null
    private var job: Job? = null

    suspend fun generate(
        storyText: String,
        settings: GenerationSettings,
        characters: List<Character>,
        chapterId: String
    ): Chapter = coroutineScope {
        val chapterDir = modelManager.newChapterDir(chapterId)
        val consistencyManager = ConsistencyManager(chapterDir, settings.slidingWindowSize)
        val startMs = System.currentTimeMillis()

        _state.update { PipelineState(startTimeMs = startMs) }

        try {
            // ── 1: LLM parse ─────────────────────────────────────────────
            emit(PipelineStage.LLM_PARSING, "Khởi động LLM...")
            val parser = LLMParser(settings.llmModelPath, settings.nThreads)
            llmParser = parser
            parser.init()
            log("✓ LLM sẵn sàng")
            log("Đang phân tích truyện, chia ${settings.panelCount} scene...")
            val scenes = parser.parseStory(storyText, settings.panelCount)
            log("✓ Chia được ${scenes.size} scene")

            // ── 2: Build prompts ──────────────────────────────────────────
            emit(PipelineStage.PROMPT_BUILDING, "Sinh prompt từng panel...")
            val charMap = characters.associate { it.name to it.anchorPrompt }
            val panels = scenes.mapIndexed { i, scene ->
                log("  Prompt panel ${i+1}: ${scene.description.take(50)}...")
                val (pos, neg) = parser.buildPrompt(scene, charMap, settings.imageStyle.stylePrompt)
                Panel(index = i, scene = scene,
                    prompt = pos, negativePrompt = neg)
            }
            parser.free(); llmParser = null
            log("✓ ${panels.size} prompt sẵn sàng")

            // ── 3: Load models ────────────────────────────────────────────
            emit(PipelineStage.SD_GENERATING, totalPanels = panels.size)
            val primaryChar = characters.firstOrNull()
            log("Load SD model: ${settings.sdModelPath.substringAfterLast('/')}")
            imagePipeline.loadSD(
                settings.sdModelPath,
                primaryChar?.loraPath ?: settings.loraPath,
                primaryChar?.loraWeight ?: settings.loraWeight,
                settings.nThreads, settings.useVulkan
            )
            log("Load ESRGAN upscaler...")
            imagePipeline.loadEsrgan(settings.upscaleFactor)
            log("✓ Models loaded")

            if (settings.useStoryDiffusion)
                log("✓ StoryDiffusion Consistent Self-Attention: BẬT")
            else
                log("⚠ StoryDiffusion: TẮT (seed lock mode)")

            // ── 4: Generate panels ────────────────────────────────────────
            val completedPanels = mutableListOf<Panel>()

            panels.forEach { panel ->
                _state.update { it.copy(currentPanel = panel.index + 1) }
                val charId = panel.scene.characters.firstOrNull()

                val hasRef = consistencyManager.hasReference(charId)
                log("SD panel ${panel.index + 1}/${panels.size}" +
                    if (hasRef && settings.useStoryDiffusion) " [consistency ✓]" else " [first frame]")

                val rawPath = imagePipeline.generatePanel(
                    panel, settings, consistencyManager, chapterDir
                ) { step, total ->
                    _state.update { it.copy(currentStep = step, totalSteps = total) }
                }

                // Lưu embedding vào ConsistencyManager sau khi sinh xong
                if (settings.useStoryDiffusion) {
                    val embPath = File(chapterDir, "embed_%03d.bin".format(panel.index)).absolutePath
                    val saved = imagePipeline.saveEmbedding(rawPath, embPath)
                    if (saved) {
                        consistencyManager.onPanelGenerated(
                            NativeBridge, sdCtx = 0L, // ctx managed internally
                            panel.index, rawPath, charId
                        )
                        log("  → Embedding lưu cho window tiếp theo")
                    }
                }

                val elapsed = (System.currentTimeMillis() - startMs) / 1000
                log("✓ Panel ${panel.index + 1} xong (${elapsed}s tổng)")

                // ── 5: Upscale ────────────────────────────────────────────
                emit(PipelineStage.UPSCALING)
                log("Upscale ${settings.upscaleFactor}× → ${settings.width * settings.upscaleFactor}px...")
                val hdPath = imagePipeline.upscale(rawPath, panel.index, chapterDir)
                log("✓ ${settings.width * settings.upscaleFactor}×${settings.height * settings.upscaleFactor}px")

                completedPanels.add(panel.copy(
                    imagePath = rawPath, upscaledPath = hdPath,
                    status = PanelStatus.DONE,
                    generationTimeMs = System.currentTimeMillis() - startMs
                ))

                emit(PipelineStage.SD_GENERATING)
            }

            imagePipeline.freeAll()

            // ── 6: Export ─────────────────────────────────────────────────
            emit(PipelineStage.LAYOUT_EXPORT, "Xuất PDF và CBZ...")
            val pdfPath = exportEngine.exportPdf(completedPanels, chapterDir, "Chương mới")
            val cbzPath = exportEngine.exportCbz(completedPanels, chapterDir)
            log("✓ Xuất xong: PDF + CBZ")

            val totalSec = (System.currentTimeMillis() - startMs) / 1000
            log("✅ Hoàn thành! ${completedPanels.size} panel · ${totalSec/60}m${totalSec%60}s")

            val chapter = Chapter(
                id = chapterId, title = "Chương mới",
                storyText = storyText, style = settings.imageStyle,
                panels = completedPanels, pdfPath = pdfPath, cbzPath = cbzPath
            )
            _state.update { it.copy(stage = PipelineStage.DONE) }
            chapter

        } catch (e: Exception) {
            _state.update { it.copy(stage = PipelineStage.ERROR, error = e.message) }
            llmParser?.free(); imagePipeline.freeAll()
            throw e
        }
    }

    fun cancel() {
        job?.cancel()
        llmParser?.free()
        imagePipeline.freeAll()
        _state.value = PipelineState()
    }

    private fun emit(stage: PipelineStage, msg: String? = null, totalPanels: Int? = null) {
        _state.update { prev ->
            prev.copy(
                stage = stage,
                totalPanels = totalPanels ?: prev.totalPanels,
                log = if (msg != null) prev.log + LogEntry(time(), msg) else prev.log
            )
        }
    }

    private fun log(msg: String, level: LogLevel = LogLevel.INFO) {
        val lvl = when {
            msg.startsWith("✓") || msg.startsWith("✅") -> LogLevel.OK
            msg.startsWith("⚠") -> LogLevel.WARN
            msg.startsWith("❌") -> LogLevel.ERROR
            else -> level
        }
        _state.update { it.copy(log = it.log + LogEntry(time(), msg, lvl)) }
    }

    private fun time() = SimpleDateFormat("mm:ss", Locale.getDefault()).format(Date())
}
