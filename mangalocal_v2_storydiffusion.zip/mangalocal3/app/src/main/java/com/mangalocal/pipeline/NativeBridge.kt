package com.mangalocal.pipeline

object NativeBridge {
    init { System.loadLibrary("mangalocal_native") }

    // ── LLM ──────────────────────────────────────────────────────────────
    external fun llamaInit(modelPath: String, nThreads: Int, nCtx: Int): Long
    external fun llamaGenerate(ctx: Long, prompt: String, maxTokens: Int, temperature: Float): String
    external fun llamaFree(ctx: Long)

    // ── Stable Diffusion core ────────────────────────────────────────────
    external fun sdInit(
        modelPath: String, loraPath: String, loraWeight: Float,
        nThreads: Int, useVulkan: Boolean
    ): Long

    external fun sdTxt2Img(
        ctx: Long, prompt: String, negPrompt: String,
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outputPath: String, callback: SDProgressCallback
    ): Boolean

    external fun sdImg2Img(
        ctx: Long, inputPath: String,
        prompt: String, negPrompt: String,
        strength: Float, steps: Int, cfgScale: Float, seed: Long,
        outputPath: String, callback: SDProgressCallback
    ): Boolean

    external fun sdFree(ctx: Long)

    // ── StoryDiffusion: Consistent Self-Attention (post-process level) ───
    // Lưu latent embedding của ảnh đã sinh để dùng làm reference
    external fun sdSaveLatentEmbedding(
        ctx: Long,
        imagePath: String,
        embeddingOutputPath: String
    ): Boolean

    // Sinh ảnh với reference embedding từ panel trước (sliding window)
    external fun sdTxt2ImgWithReference(
        ctx: Long,
        prompt: String, negPrompt: String,
        referenceEmbeddingPaths: Array<String>,  // array embeddings từ window
        consistencyStrength: Float,               // 0.0 - 1.0
        width: Int, height: Int, steps: Int, cfgScale: Float, seed: Long,
        outputPath: String, callback: SDProgressCallback
    ): Boolean

    // ── ESRGAN ───────────────────────────────────────────────────────────
    external fun esrganInit(scale: Int, modelDir: String): Long
    external fun esrganUpscale(ctx: Long, inputPath: String, outputPath: String): Boolean
    external fun esrganFree(ctx: Long)

    interface SDProgressCallback {
        fun onProgress(step: Int, totalSteps: Int)
    }
}
