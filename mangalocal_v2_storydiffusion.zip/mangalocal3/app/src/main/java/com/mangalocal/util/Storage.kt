package com.mangalocal.util

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.mangalocal.model.*

class Storage(context: Context) {
    private val prefs = context.getSharedPreferences("ml_v2", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun saveCharacters(list: List<Character>) = prefs.edit().putString("chars", gson.toJson(list)).apply()
    fun loadCharacters(): List<Character> = try {
        gson.fromJson(prefs.getString("chars", null) ?: return defaultChars(),
            object : TypeToken<List<Character>>() {}.type)
    } catch (e: Exception) { defaultChars() }

    fun saveSettings(s: GenerationSettings) = prefs.edit().putString("settings", gson.toJson(s)).apply()
    fun loadSettings(): GenerationSettings = try {
        gson.fromJson(prefs.getString("settings", null) ?: return GenerationSettings(), GenerationSettings::class.java)
    } catch (e: Exception) { GenerationSettings() }

    fun saveChapters(list: List<Chapter>) = prefs.edit().putString("chapters", gson.toJson(list)).apply()
    fun loadChapters(): List<Chapter> = try {
        gson.fromJson(prefs.getString("chapters", null) ?: return emptyList(),
            object : TypeToken<List<Chapter>>() {}.type)
    } catch (e: Exception) { emptyList() }

    private fun defaultChars() = listOf(
        Character("default", "Nhân vật 1",
            "young woman, long black hair, brown eyes, red jacket, slender build, pale skin",
            seed = 42891L)
    )
}
