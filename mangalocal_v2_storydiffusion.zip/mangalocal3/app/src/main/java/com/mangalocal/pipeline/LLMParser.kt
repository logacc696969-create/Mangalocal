package com.mangalocal.pipeline

import com.mangalocal.model.DialogueBubble
import com.mangalocal.model.Scene
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class LLMParser(private val modelPath: String, private val nThreads: Int = 4) {

    private var ctx: Long = 0

    suspend fun init() = withContext(Dispatchers.IO) {
        ctx = NativeBridge.llamaInit(modelPath, nThreads, 2048)
        if (ctx == 0L) throw RuntimeException("LLM init thất bại: $modelPath")
    }

    suspend fun parseStory(text: String, panelCount: Int): List<Scene> =
        withContext(Dispatchers.IO) {
            val raw = NativeBridge.llamaGenerate(ctx, scenePrompt(text, panelCount), 1500, 0.1f)
            parseScenes(raw, panelCount)
        }

    suspend fun buildPrompt(
        scene: Scene,
        charPrompts: Map<String, String>,
        stylePrompt: String
    ): Pair<String, String> = withContext(Dispatchers.IO) {
        val charDesc = scene.characters.mapNotNull { charPrompts[it] }.joinToString(", ")
        val raw = NativeBridge.llamaGenerate(ctx, promptTemplate(scene, charDesc, stylePrompt), 400, 0.2f)
        extractPrompts(raw, scene, stylePrompt)
    }

    fun free() {
        if (ctx != 0L) { NativeBridge.llamaFree(ctx); ctx = 0 }
    }

    // ── Templates ─────────────────────────────────────────────────────────

    private fun scenePrompt(text: String, count: Int) = """
Split this story into exactly $count visual panels for a comic book.
Return ONLY a JSON array, no markdown, no explanation.

[{"index":0,"description":"visual scene description","characters":["name"],"mood":"dark","cameraAngle":"medium-shot","action":"what character does","setting":"location description","dialogue":[{"character":"name","text":"spoken words","type":"SPEECH"}]}]

Mood: dark|bright|tense|calm|dramatic|romantic|comedic|mysterious
Camera: extreme-close-up|close-up|medium-shot|wide-shot|overhead|low-angle|dutch-angle
Dialogue type: SPEECH|THOUGHT|NARRATION|SHOUT

Story:
$text
""".trimIndent()

    private fun promptTemplate(scene: Scene, charDesc: String, styleHint: String) = """
Write a Stable Diffusion prompt for this comic panel.
Return ONLY JSON, no markdown: {"positive":"...","negative":"..."}

Scene: ${scene.description}
Action: ${scene.action}
Setting: ${scene.setting}
Mood: ${scene.mood}
Camera: ${scene.cameraAngle}
Characters: $charDesc
Style: $styleHint

Rules: positive = camera angle, characters appearance, scene, mood, lighting, quality tags. negative = anatomy errors, quality issues.
""".trimIndent()

    // ── Parsers ───────────────────────────────────────────────────────────

    private fun parseScenes(raw: String, count: Int): List<Scene> {
        return try {
            val s = raw.indexOf('['); val e = raw.lastIndexOf(']')
            val arr = JSONArray(if (s != -1 && e > s) raw.substring(s, e + 1) else raw.trim())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val chars = o.optJSONArray("characters")
                    ?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
                val dialogue = o.optJSONArray("dialogue")
                    ?.let { a -> (0 until a.length()).mapNotNull { j ->
                        val d = a.getJSONObject(j)
                        try { DialogueBubble(d.getString("character"), d.getString("text"),
                            enumValueOf(d.optString("type", "SPEECH"))) } catch (ex: Exception) { null }
                    }} ?: emptyList()
                Scene(i, o.optString("description","Scene ${i+1}"), chars,
                    o.optString("mood","neutral"), o.optString("cameraAngle","medium-shot"),
                    o.optString("action",""), o.optString("setting",""), dialogue)
            }
        } catch (e: Exception) {
            // Fallback: chia đều văn bản
            val chunk = (raw.length / count).coerceAtLeast(1)
            raw.chunked(chunk).take(count).mapIndexed { i, s ->
                Scene(i, s.take(120), emptyList(), "neutral", "medium-shot")
            }
        }
    }

    private fun extractPrompts(raw: String, scene: Scene, style: String): Pair<String, String> {
        return try {
            val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
            val o = JSONObject(if (s != -1 && e > s) raw.substring(s, e + 1) else raw.trim())
            Pair(o.getString("positive"), o.getString("negative"))
        } catch (ex: Exception) {
            Pair("${scene.description}, ${scene.mood} mood, ${scene.cameraAngle}, $style",
                "bad quality, blurry, deformed")
        }
    }
}
