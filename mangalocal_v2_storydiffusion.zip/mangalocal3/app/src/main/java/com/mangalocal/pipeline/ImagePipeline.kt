package com.mangalocal.pipeline

import com.mangalocal.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ImagePipeline(private val modelManager: ModelManager) {

    private var sdCtx: Long = 0
    private var esrganCtx: Long = 0
    private var loadedSdPath = ""

    suspend fun loadSD(
        modelPath: String, loraPath: String, loraWeight: Float,
        nThreads: Int, useVulkan: Boolean
    ) = withContext(Dispatchers.IO) {
        if (modelPath == loadedSdPath) return@withContext
        if (sdCtx != 0L) { NativeBridge.sdFree(sdCtx); sdCtx = 0 }
        sdCtx = NativeBridge.sdInit(modelPath, loraPath, loraWeight, nThreads, useVulkan)
        if (sdCtx == 0L) throw RuntimeException("Không load được SD model:\n${modelPath.substringAfterLast('/')}")
        loadedSdPath = modelPath
    }

    suspend fun loadEsrgan(scale: Int) = withContext(Dispatchers.IO) {
        if (esrganCtx != 0L) return@withContext
        if (!modelManager.hasEsrgan()) throw RuntimeException(
            "Thiếu ESRGAN model.\nĐặt file vào: ${modelManager.esrganDir.absolutePath}"
        )
        esrganCtx = NativeBridge.esrganInit(scale, modelManager.esrganDir.absolutePath)
        if (esrganCtx == 0L) throw RuntimeException("ESRGAN init thất bại")
    }

    /**
     * Sinh ảnh với StoryDiffusion Consistent Self-Attention.
     *
     * Logic:
     * - Panel đầu tiên → txt2img thường
     * - Các panel tiếp → txt2img với reference embeddings từ sliding window
     *   → nhất quán mặt + trang phục + vóc dáng
     */
    suspend fun generatePanel(
        panel: Panel,
        settings: GenerationSettings,
        consistencyManager: ConsistencyManager,
        outDir: File,
        onProgress: (Int, Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val outFile = File(outDir, "panel_%03d_raw.png".format(panel.index))
        val cb = object : NativeBridge.SDProgressCallback {
            override fun onProgress(step: Int, total: Int) = onProgress(step, total)
        }
        val seed = panel.scene.characters.firstOrNull()?.hashCode()?.toLong()
            ?.let { if (it < 0) it + Long.MAX_VALUE else it } ?: 42L

        val fullPrompt = panel.prompt + ", " + settings.imageStyle.stylePrompt
        val fullNeg    = panel.negativePrompt + ", " + settings.imageStyle.negPrompt

        val refs = consistencyManager.getReferenceEmbeddings(
            panel.scene.characters.firstOrNull()
        )

        val ok = if (settings.useStoryDiffusion && refs.isNotEmpty()) {
            // StoryDiffusion mode: inject reference embeddings
            NativeBridge.sdTxt2ImgWithReference(
                ctx = sdCtx,
                prompt = fullPrompt, negPrompt = fullNeg,
                referenceEmbeddingPaths = refs,
                consistencyStrength = settings.consistencyStrength,
                width = settings.width, height = settings.height,
                steps = settings.steps, cfgScale = settings.cfgScale,
                seed = seed,
                outputPath = outFile.absolutePath,
                callback = cb
            )
        } else {
            // Panel đầu tiên hoặc StoryDiffusion tắt → txt2img thường
            NativeBridge.sdTxt2Img(
                ctx = sdCtx,
                prompt = fullPrompt, negPrompt = fullNeg,
                width = settings.width, height = settings.height,
                steps = settings.steps, cfgScale = settings.cfgScale,
                seed = seed,
                outputPath = outFile.absolutePath,
                callback = cb
            )
        }

        if (!ok) throw RuntimeException("SD generate thất bại tại panel ${panel.index + 1}")
        outFile.absolutePath
    }

    /**
     * Lưu embedding sau khi sinh xong — dùng cho window tiếp theo
     */
    fun saveEmbedding(imagePath: String, embeddingPath: String): Boolean =
        NativeBridge.sdSaveLatentEmbedding(sdCtx, imagePath, embeddingPath)

    suspend fun upscale(inputPath: String, panelIndex: Int, outDir: File): String =
        withContext(Dispatchers.IO) {
            val outFile = File(outDir, "panel_%03d_hd.png".format(panelIndex))
            val ok = NativeBridge.esrganUpscale(esrganCtx, inputPath, outFile.absolutePath)
            if (!ok) throw RuntimeException("Upscale thất bại tại panel ${panelIndex + 1}")
            outFile.absolutePath
        }

    fun freeAll() {
        if (sdCtx != 0L) { NativeBridge.sdFree(sdCtx); sdCtx = 0; loadedSdPath = "" }
        if (esrganCtx != 0L) { NativeBridge.esrganFree(esrganCtx); esrganCtx = 0 }
    }
}
