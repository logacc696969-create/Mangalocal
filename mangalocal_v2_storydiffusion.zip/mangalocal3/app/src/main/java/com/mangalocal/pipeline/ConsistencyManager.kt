package com.mangalocal.pipeline

import java.io.File

/**
 * Quản lý Consistent Self-Attention theo kiểu sliding window.
 *
 * Cơ chế hoạt động:
 * - Panel đầu tiên của nhân vật → sinh bình thường → lưu embedding làm ANCHOR cố định
 * - Các panel tiếp theo → inject anchor embedding + N panel gần nhất vào attention
 * - Sliding window size = N → RAM không tăng theo số chương
 * - Kết quả: mặt, trang phục, vóc dáng nhất quán xuyên suốt 100 chương
 */
class ConsistencyManager(
    private val workDir: File,
    private val windowSize: Int = 3
) {
    // Anchor cố định từ panel đầu tiên - không bao giờ thay đổi
    private val anchorEmbeddings = mutableMapOf<String, String>() // characterId → embeddingPath

    // Sliding window: N embedding gần nhất
    private val recentEmbeddings = ArrayDeque<String>(windowSize)

    // Đường dẫn lưu embedding
    private fun embeddingPath(panelIndex: Int) =
        File(workDir, "embed_panel_${"%03d".format(panelIndex)}.bin").absolutePath

    private fun anchorPath(characterId: String) =
        File(workDir, "embed_anchor_$characterId.bin").absolutePath

    /**
     * Sau khi sinh panel xong, lưu embedding làm reference
     */
    fun onPanelGenerated(
        nativeBridge: NativeBridge,
        sdCtx: Long,
        panelIndex: Int,
        imagePath: String,
        characterId: String?
    ) {
        val embPath = embeddingPath(panelIndex)

        // Lưu embedding của panel vừa sinh
        val saved = NativeBridge.sdSaveLatentEmbedding(sdCtx, imagePath, embPath)
        if (!saved) return

        // Panel đầu tiên → làm anchor cố định cho nhân vật này
        if (characterId != null && !anchorEmbeddings.containsKey(characterId)) {
            val aPath = anchorPath(characterId)
            File(embPath).copyTo(File(aPath), overwrite = true)
            anchorEmbeddings[characterId] = aPath
        }

        // Thêm vào sliding window
        if (recentEmbeddings.size >= windowSize) {
            recentEmbeddings.removeFirst()
        }
        recentEmbeddings.addLast(embPath)
    }

    /**
     * Lấy danh sách reference embeddings cho panel tiếp theo.
     * Thứ tự: [anchor cố định] + [N panel gần nhất]
     * Anchor luôn ở đầu để có trọng số cao nhất.
     */
    fun getReferenceEmbeddings(characterId: String?): Array<String> {
        val refs = mutableListOf<String>()

        // Anchor cố định của nhân vật (ưu tiên cao nhất)
        characterId?.let { anchorEmbeddings[it] }?.let { refs.add(it) }

        // Sliding window (N panel gần nhất, không trùng anchor)
        recentEmbeddings.forEach { path ->
            if (path !in refs) refs.add(path)
        }

        return refs.filter { File(it).exists() }.toTypedArray()
    }

    fun hasReference(characterId: String?) =
        characterId != null && anchorEmbeddings.containsKey(characterId)
            || recentEmbeddings.isNotEmpty()

    fun reset() {
        recentEmbeddings.clear()
        // Không xóa anchor — giữ cho toàn bộ truyện
    }

    fun resetAll() {
        recentEmbeddings.clear()
        anchorEmbeddings.clear()
    }
}
