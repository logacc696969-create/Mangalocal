package com.mangalocal.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangalocal.model.*
import com.mangalocal.pipeline.*
import com.mangalocal.util.Storage
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val modelManager = ModelManager(app)
    private val storage = Storage(app)
    private val pipeline = MangaPipeline(modelManager)

    val pipelineState = pipeline.state

    private val _characters = MutableStateFlow(storage.loadCharacters())
    val characters: StateFlow<List<Character>> = _characters

    private val _settings = MutableStateFlow(storage.loadSettings())
    val settings: StateFlow<GenerationSettings> = _settings

    private val _chapters = MutableStateFlow(storage.loadChapters())
    val chapters: StateFlow<List<Chapter>> = _chapters

    private val _currentChapter = MutableStateFlow<Chapter?>(null)
    val currentChapter: StateFlow<Chapter?> = _currentChapter

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating

    private val _sdModels  = MutableStateFlow<List<ModelInfo>>(emptyList())
    private val _llmModels = MutableStateFlow<List<ModelInfo>>(emptyList())
    private val _loras     = MutableStateFlow<List<ModelInfo>>(emptyList())
    val sdModels:  StateFlow<List<ModelInfo>> = _sdModels
    val llmModels: StateFlow<List<ModelInfo>> = _llmModels
    val loras:     StateFlow<List<ModelInfo>> = _loras

    init { rescanModels() }

    fun rescanModels() {
        _sdModels.value  = modelManager.scanSdModels()
        _llmModels.value = modelManager.scanLlmModels()
        _loras.value     = modelManager.scanLoras()
    }

    fun updateSettings(block: GenerationSettings.() -> GenerationSettings) {
        _settings.update { it.block() }
        storage.saveSettings(_settings.value)
    }

    fun generate(storyText: String) {
        if (_isGenerating.value) return
        val s = _settings.value
        if (s.sdModelPath.isEmpty())  { _error.value = "Chưa chọn SD Model.\nVào Cài đặt → chọn model."; return }
        if (s.llmModelPath.isEmpty()) { _error.value = "Chưa chọn LLM Model.\nVào Cài đặt → chọn model."; return }

        _isGenerating.value = true
        viewModelScope.launch {
            try {
                val id = UUID.randomUUID().toString()
                val ch = pipeline.generate(storyText, s, _characters.value, id)
                _currentChapter.value = ch
                _chapters.update { (listOf(ch) + it).take(50) }
                storage.saveChapters(_chapters.value)
            } catch (e: Exception) {
                _error.value = e.message ?: "Lỗi không xác định"
            } finally {
                _isGenerating.value = false
            }
        }
    }

    fun cancelGeneration() { pipeline.cancel(); _isGenerating.value = false }

    // Characters CRUD
    fun addCharacter(name: String, anchor: String, neg: String, loraPath: String?, seed: Long?) {
        _characters.update { it + Character(
            id = UUID.randomUUID().toString(),
            name = name.trim(), anchorPrompt = anchor.trim(),
            negativePrompt = neg.ifBlank { "bad anatomy, bad hands, extra fingers" },
            seed = seed ?: (10000L..99999L).random(),
            loraPath = loraPath?.ifBlank { null }
        )}
        storage.saveCharacters(_characters.value)
    }

    fun deleteCharacter(id: String) {
        _characters.update { it.filter { c -> c.id != id } }
        storage.saveCharacters(_characters.value)
    }

    fun selectChapter(ch: Chapter) { _currentChapter.value = ch }
    fun clearError() { _error.value = null }
    fun modelSetupGuide() = modelManager.setupGuide()
    fun modelStatus() = modelManager.modelStatus()

    override fun onCleared() { super.onCleared(); pipeline.cancel() }
}
