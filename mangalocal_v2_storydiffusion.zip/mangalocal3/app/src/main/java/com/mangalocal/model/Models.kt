package com.mangalocal.model

// ── Nhân vật ──────────────────────────────────────────────────────────────
data class Character(
    val id: String,
    val name: String,
    val anchorPrompt: String,       // mô tả ngoại hình cố định
    val negativePrompt: String = "bad anatomy, deformed, ugly, blurry",
    val seed: Long,
    val loraPath: String? = null,
    val loraWeight: Float = 0.75f,
    // StoryDiffusion: embedding của ảnh reference đầu tiên, lưu dạng float array
    val referenceEmbeddingPath: String? = null
)

// ── Model file ────────────────────────────────────────────────────────────
data class ModelInfo(
    val path: String,
    val name: String,
    val type: ModelType,
    val sizeBytes: Long
) {
    val displaySize: String get() {
        val gb = sizeBytes / 1_073_741_824.0
        val mb = sizeBytes / 1_048_576.0
        return if (gb >= 1.0) "%.1fGB".format(gb) else "%.0fMB".format(mb)
    }
}

enum class ModelType { SD15, LLM, LORA, ESRGAN }

// ── Cài đặt sinh ảnh ──────────────────────────────────────────────────────
data class GenerationSettings(
    val sdModelPath: String = "",
    val llmModelPath: String = "",
    val loraPath: String = "",
    val loraWeight: Float = 0.75f,
    val imageStyle: ImageStyle = ImageStyle.REALISTIC,
    val panelCount: Int = 6,
    val width: Int = 512,
    val height: Int = 512,
    val steps: Int = 20,
    val cfgScale: Float = 7f,
    val upscaleFactor: Int = 4,
    val nThreads: Int = 4,
    val useVulkan: Boolean = true,
    // StoryDiffusion settings
    val consistencyStrength: Float = 0.8f,  // mức độ inject reference embedding
    val slidingWindowSize: Int = 3,          // số panel trong 1 window
    val useStoryDiffusion: Boolean = true
)

enum class ImageStyle(val label: String, val emoji: String, val stylePrompt: String, val negPrompt: String) {
    REALISTIC(
        "Siêu thực", "📷",
        "RAW photo, 8k uhd, dslr, soft lighting, high quality, film grain, Fujifilm XT3, photorealistic, sharp focus",
        "cartoon, anime, illustration, painting, drawing, art, sketch, 3d render, cgi, lowres, bad quality, watermark, blurry, deformed"
    ),
    ANIME(
        "Anime / Moe", "✨",
        "masterpiece, best quality, ultra-detailed, illustration, vibrant colors, sharp lines, anime style",
        "lowres, bad anatomy, bad hands, text, error, missing fingers, worst quality, jpeg artifacts, signature, watermark, blurry, 3d, photorealistic"
    ),
    COMIC(
        "Comic / Manhwa", "💥",
        "comic book style, manhwa, webtoon, high contrast, bold lines, flat colors, professional illustration",
        "blurry, lowres, bad anatomy, photorealistic, 3d render, amateur"
    ),
    CINEMATIC(
        "Điện ảnh", "🎬",
        "cinematic lighting, epic composition, dramatic shadows, movie still, 35mm film, anamorphic lens, depth of field, professional photography",
        "cartoon, anime, illustration, amateur, blurry, lowres, overexposed"
    )
}

// ── Scene & Panel ─────────────────────────────────────────────────────────
data class Scene(
    val index: Int,
    val description: String,
    val characters: List<String>,
    val mood: String,
    val cameraAngle: String,
    val action: String = "",
    val setting: String = "",
    val dialogue: List<DialogueBubble> = emptyList()
)

data class Panel(
    val index: Int,
    val scene: Scene,
    val prompt: String,
    val negativePrompt: String,
    val imagePath: String? = null,
    val upscaledPath: String? = null,
    val status: PanelStatus = PanelStatus.PENDING,
    val generationTimeMs: Long = 0,
    // StoryDiffusion: latent embedding được lưu sau khi sinh
    val latentEmbeddingPath: String? = null
)

data class DialogueBubble(
    val characterName: String,
    val text: String,
    val type: BubbleType = BubbleType.SPEECH
)

enum class BubbleType { SPEECH, THOUGHT, NARRATION, SHOUT }
enum class PanelStatus { PENDING, GENERATING, UPSCALING, DONE, FAILED }

// ── Chapter ───────────────────────────────────────────────────────────────
data class Chapter(
    val id: String,
    val title: String,
    val storyText: String,
    val style: ImageStyle,
    val panels: List<Panel>,
    val pdfPath: String? = null,
    val cbzPath: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    val doneCount get() = panels.count { it.status == PanelStatus.DONE }
    val consistencyScore get() = if (panels.isEmpty()) 0f else doneCount.toFloat() / panels.size
}

// ── Pipeline state ────────────────────────────────────────────────────────
data class PipelineState(
    val stage: PipelineStage = PipelineStage.IDLE,
    val currentPanel: Int = 0,
    val totalPanels: Int = 0,
    val currentStep: Int = 0,
    val totalSteps: Int = 20,
    val log: List<LogEntry> = emptyList(),
    val error: String? = null,
    val startTimeMs: Long = 0L
) {
    val elapsedMs get() = if (startTimeMs == 0L) 0L else System.currentTimeMillis() - startTimeMs
    val progressFraction get() = if (totalPanels == 0) 0f else currentPanel.toFloat() / totalPanels
}

data class LogEntry(val time: String, val message: String, val level: LogLevel = LogLevel.INFO)
enum class LogLevel { INFO, OK, WARN, ERROR }

enum class PipelineStage {
    IDLE, LLM_PARSING, PROMPT_BUILDING,
    SD_GENERATING, UPSCALING, LAYOUT_EXPORT,
    DONE, ERROR
}
