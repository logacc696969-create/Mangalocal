package com.mangalocal.pipeline

import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.mangalocal.model.*
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ExportEngine {

    fun exportPdf(panels: List<Panel>, outDir: File, title: String): String {
        val doc = PdfDocument()
        val pw = 595; val ph = 842

        panels.chunked(2).forEachIndexed { pageIdx, chunk ->
            val info = PdfDocument.PageInfo.Builder(pw, ph, pageIdx + 1).create()
            val page = doc.startPage(info)
            val c = page.canvas
            c.drawColor(Color.WHITE)

            // Title trên trang đầu
            if (pageIdx == 0) {
                val tp = Paint().apply {
                    color = Color.BLACK; textSize = 16f
                    typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true
                }
                c.drawText(title, 20f, 28f, tp)
            }

            val topPad = if (pageIdx == 0) 42f else 12f
            val halfH = (ph - topPad - 20f) / 2f

            chunk.forEachIndexed { i, panel ->
                val imgPath = panel.upscaledPath ?: panel.imagePath ?: return@forEachIndexed
                val bmp = BitmapFactory.decodeFile(imgPath) ?: return@forEachIndexed
                val top = topPad + if (i == 0) 0f else halfH + 8f
                val dst = RectF(12f, top, pw - 12f, top + halfH - 4f)

                // Border
                c.drawRect(dst, Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f })
                c.drawBitmap(bmp, null, dst, null)
                bmp.recycle()

                // Dialogue bubbles
                panel.scene.dialogue.forEachIndexed { bi, bubble ->
                    drawBubble(c, bubble, dst, bi)
                }

                // Panel number
                c.drawText("#${panel.index + 1}", dst.left + 4f, dst.bottom - 4f,
                    Paint().apply { color = Color.DKGRAY; textSize = 8f; isAntiAlias = true })
            }
            doc.finishPage(page)
        }

        val out = File(outDir, "chapter.pdf")
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
        return out.absolutePath
    }

    fun exportCbz(panels: List<Panel>, outDir: File): String {
        val out = File(outDir, "chapter.cbz")
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            panels.forEach { panel ->
                val path = panel.upscaledPath ?: panel.imagePath ?: return@forEach
                val file = File(path)
                if (!file.exists()) return@forEach
                zip.putNextEntry(ZipEntry("panel_%03d.png".format(panel.index + 1)))
                file.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
        return out.absolutePath
    }

    private fun drawBubble(canvas: Canvas, bubble: DialogueBubble, panelRect: RectF, index: Int) {
        val bw = panelRect.width() * 0.44f
        val bh = 38f
        val mg = 7f
        val left = panelRect.left + mg + (index % 2) * (panelRect.width() / 2f)
        val top  = panelRect.top + mg + index * (bh + 4f)
        if (top + bh > panelRect.bottom - mg) return

        val rect = RectF(left, top, left + bw, top + bh)
        canvas.drawRoundRect(rect, 7f, 7f, Paint().apply { color = Color.WHITE; style = Paint.Style.FILL; isAntiAlias = true })
        canvas.drawRoundRect(rect, 7f, 7f, Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.2f; isAntiAlias = true })

        val name = bubble.characterName
        canvas.drawText(name, rect.left + 4f, rect.top + 8f,
            Paint().apply { color = Color.DKGRAY; textSize = 6f; typeface = Typeface.DEFAULT_BOLD; isAntiAlias = true })

        val text = if (bubble.text.length > 42) bubble.text.take(41) + "…" else bubble.text
        canvas.drawText(text, rect.left + 4f, rect.top + 16f,
            Paint().apply { color = Color.BLACK; textSize = 8f; isAntiAlias = true })
    }
}
