package com.mangalocal.ui

import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.content.FileProvider
import androidx.navigation.NavController
import com.mangalocal.model.*
import java.io.File

// ── HOME ──────────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(nav: NavController, vm: MainViewModel) {
    var storyText by remember { mutableStateOf("") }
    val settings by vm.settings.collectAsState()
    val chars by vm.characters.collectAsState()
    val isGenerating by vm.isGenerating.collectAsState()
    val modelStatus by remember { derivedStateOf { vm.modelStatus() } }
    val ready = modelStatus.all { it.value }

    LaunchedEffect(isGenerating) {
        if (isGenerating) nav.navigate("generating")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("MangaLocal", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("v2 · StoryDiffusion", color = C.T3, fontSize = 10.sp)
                    }
                },
                actions = {
                    MlChip(
                        if (ready) "ready ✓" else "setup cần thiết",
                        if (ready) C.Green else C.Orange,
                        if (ready) C.GreenDim else C.OrangeDim,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        },
        bottomBar = { AppNavBar(nav, "home") },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // ── Cảnh báo setup ─────────────────────────────────────────────
            if (!ready) item {
                Surface(color = C.OrangeDim, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Orange.copy(0.4f))) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Warning, null, tint = C.Orange, modifier = Modifier.size(18.dp))
                            Text("Cần setup model trước khi sử dụng", color = C.Orange,
                                fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        modelStatus.filter { !it.value }.forEach {
                            Text("• ${it.key}: chưa có", color = C.T2, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Nhấn vào đây để xem hướng dẫn →", color = C.Blue,
                            fontSize = 12.sp,
                            modifier = Modifier.clickable { nav.navigate("settings") })
                    }
                }
            }

            // ── Nhập truyện ────────────────────────────────────────────────
            item {
                MlCard {
                    MlLabel("nội dung truyện")
                    OutlinedTextField(
                        value = storyText, onValueChange = { storyText = it },
                        modifier = Modifier.fillMaxWidth().height(140.dp),
                        placeholder = {
                            Text("Dán truyện chữ vào đây...\n\nLLM sẽ tự chia scene, sinh prompt.\nStoryDiffusion giữ nhất quán mặt + trang phục + vóc dáng.",
                                color = C.T3, fontSize = 12.sp)
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                            focusedContainerColor = C.S0, unfocusedContainerColor = C.S0,
                            focusedTextColor = C.T1, unfocusedTextColor = C.T1
                        ),
                        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${storyText.length} ký tự", color = C.T3, fontSize = 11.sp)
                        Text("·", color = C.T3, fontSize = 11.sp)
                        Text("~${(storyText.split(" ").size / 130).coerceAtLeast(1)} phút đọc",
                            color = C.T3, fontSize = 11.sp)
                    }
                }
            }

            // ── Style ──────────────────────────────────────────────────────
            item {
                MlCard {
                    MlLabel("phong cách hình ảnh")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ImageStyle.values()) { style ->
                            val sel = settings.imageStyle == style
                            Surface(
                                onClick = { vm.updateSettings { copy(imageStyle = style) } },
                                color = if (sel) C.BlueDim else C.S0,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, if (sel) C.Blue else C.Border),
                                modifier = Modifier.width(100.dp)
                            ) {
                                Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(style.emoji, fontSize = 22.sp)
                                    Spacer(Modifier.height(5.dp))
                                    Text(style.label, color = if (sel) C.Blue else C.T1,
                                        fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            // ── Nhân vật ───────────────────────────────────────────────────
            item {
                MlCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        MlLabel("nhân vật (${chars.size})")
                        Text("quản lý →", color = C.Blue, fontSize = 12.sp,
                            modifier = Modifier.clickable { nav.navigate("characters") })
                    }
                    if (chars.isEmpty()) {
                        Text("Chưa có nhân vật nào.\nThêm nhân vật để StoryDiffusion hoạt động tốt hơn.",
                            color = C.T3, fontSize = 12.sp, lineHeight = 17.sp)
                    } else {
                        chars.take(3).forEach { c ->
                            Row(Modifier.padding(vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                CharAvatar(c.name)
                                Column(Modifier.weight(1f)) {
                                    Text(c.name, color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(c.anchorPrompt.take(45) + "…", color = C.T3, fontSize = 10.sp)
                                }
                                MlChip(
                                    if (c.loraPath != null) "LoRA" else "anchor",
                                    if (c.loraPath != null) C.Green else C.Blue,
                                    if (c.loraPath != null) C.GreenDim else C.BlueDim
                                )
                            }
                        }
                        if (chars.size > 3)
                            Text("+${chars.size - 3} nhân vật khác...", color = C.T3, fontSize = 11.sp)
                    }
                }
            }

            // ── Số panel + StoryDiffusion toggle ──────────────────────────
            item {
                MlCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MlLabel("số panel")
                        Text("${settings.panelCount} panel · ~${settings.panelCount * 50 / 60} phút",
                            color = C.T3, fontSize = 11.sp)
                    }
                    Slider(
                        value = settings.panelCount.toFloat(),
                        onValueChange = { vm.updateSettings { copy(panelCount = it.toInt()) } },
                        valueRange = 2f..16f, steps = 13,
                        colors = SliderDefaults.colors(thumbColor = C.Blue,
                            activeTrackColor = C.Blue, inactiveTrackColor = C.Border)
                    )
                    Spacer(Modifier.height(8.dp))
                    Divider(color = C.Border)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("StoryDiffusion Consistency", color = C.T1,
                                fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("Giữ nhất quán mặt + trang phục + vóc dáng\nkhông cần train LoRA",
                                color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                        }
                        Switch(
                            checked = settings.useStoryDiffusion,
                            onCheckedChange = { vm.updateSettings { copy(useStoryDiffusion = it) } },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim)
                        )
                    }
                    if (settings.useStoryDiffusion) {
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Mức độ nhất quán", color = C.T2, fontSize = 12.sp)
                            Text("%.0f%%".format(settings.consistencyStrength * 100),
                                color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = settings.consistencyStrength,
                            onValueChange = { vm.updateSettings { copy(consistencyStrength = it) } },
                            valueRange = 0.3f..1.0f,
                            colors = SliderDefaults.colors(thumbColor = C.Purple,
                                activeTrackColor = C.Purple, inactiveTrackColor = C.Border)
                        )
                        Text("Cao hơn = nhất quán hơn nhưng ít sáng tạo hơn",
                            color = C.T3, fontSize = 10.sp)
                    }
                }
            }

            // ── Generate button ────────────────────────────────────────────
            item {
                MlBtn(
                    text = when {
                        !ready -> "Cần setup model trước"
                        isGenerating -> "Đang tạo..."
                        else -> "✨ Sinh truyện tranh"
                    },
                    onClick = { vm.generate(storyText) },
                    enabled = storyText.isNotBlank() && ready && !isGenerating,
                    icon = Icons.Default.AutoAwesome
                )
            }
        }
    }
}

// ── GENERATING ────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeneratingScreen(nav: NavController, vm: MainViewModel) {
    val state by vm.pipelineState.collectAsState()

    LaunchedEffect(state.stage) {
        if (state.stage == PipelineStage.DONE) nav.navigate("gallery") { popUpTo("home") }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Đang tạo truyện tranh") },
                navigationIcon = {
                    IconButton(onClick = { vm.cancelGeneration(); nav.popBackStack() }) {
                        Icon(Icons.Default.Close, null)
                    }
                },
                actions = {
                    MlChip(
                        when (state.stage) {
                            PipelineStage.DONE  -> "xong ✓"
                            PipelineStage.ERROR -> "lỗi"
                            else -> state.stage.name.lowercase().replace("_", " ")
                        },
                        when (state.stage) {
                            PipelineStage.DONE  -> C.Green
                            PipelineStage.ERROR -> C.Red
                            else -> C.Orange
                        },
                        when (state.stage) {
                            PipelineStage.DONE  -> C.GreenDim
                            PipelineStage.ERROR -> C.RedDim
                            else -> C.OrangeDim
                        },
                        modifier = Modifier.padding(end = 12.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                MlCard {
                    MlLabel("pipeline")
                    PipelineIndicator(state.stage)
                }
            }

            item {
                MlCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Panel ${state.currentPanel} / ${state.totalPanels}",
                            color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        val e = state.elapsedMs / 1000
                        Text("${e / 60}m ${e % 60}s", color = C.T3, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = state.progressFraction,
                        modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
                        color = C.Blue, trackColor = C.Border
                    )
                    Spacer(Modifier.height(4.dp))
                    Text("Step ${state.currentStep}/${state.totalSteps}",
                        color = C.T3, fontSize = 11.sp)
                }
            }

            item {
                MlCard {
                    MlLabel("log")
                    Column(
                        modifier = Modifier.fillMaxWidth()
                            .background(C.S0, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                            .heightIn(max = 220.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        state.log.takeLast(25).forEach { entry ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(vertical = 1.dp)) {
                                Text(entry.time, color = C.T3, fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace)
                                Text(entry.message, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                                    color = when (entry.level) {
                                        LogLevel.OK    -> C.Green
                                        LogLevel.WARN  -> C.Orange
                                        LogLevel.ERROR -> C.Red
                                        else           -> C.T2
                                    })
                            }
                        }
                    }
                }
            }

            item {
                MlOutlineBtn("Hủy", onClick = { vm.cancelGeneration(); nav.navigate("home") { popUpTo("home") } },
                    icon = Icons.Default.Stop, color = C.Red)
            }
        }
    }
}

// ── GALLERY ───────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryScreen(nav: NavController, vm: MainViewModel) {
    val chapters by vm.chapters.collectAsState()
    val current by vm.currentChapter.collectAsState()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(current?.title ?: "Thư viện") },
                actions = {
                    current?.pdfPath?.let { path ->
                        IconButton(onClick = {
                            val file = File(path)
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                            context.startActivity(Intent.createChooser(
                                Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }, "Chia sẻ PDF"))
                        }) { Icon(Icons.Default.Share, null, tint = C.Blue) }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        },
        bottomBar = { AppNavBar(nav, "gallery") },
        containerColor = C.Bg
    ) { pad ->
        if (chapters.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("📚", fontSize = 52.sp)
                    Text("Chưa có truyện nào", color = C.T3, fontSize = 16.sp)
                    MlBtn("Tạo truyện ngay", onClick = { nav.navigate("home") },
                        modifier = Modifier.width(180.dp))
                }
            }
            return@Scaffold
        }

        val chapter = current ?: chapters.first()

        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Chapter list
            if (chapters.size > 1) item {
                MlCard {
                    MlLabel("chương (${chapters.size})")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(chapters) { ch ->
                            val sel = ch.id == chapter.id
                            Surface(onClick = { vm.selectChapter(ch) },
                                color = if (sel) C.BlueDim else C.S0,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (sel) C.Blue else C.Border)) {
                                Column(Modifier.padding(10.dp, 7.dp)) {
                                    Text(ch.title, color = if (sel) C.Blue else C.T2,
                                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("${ch.panels.size} panel · ${ch.style.emoji}",
                                        color = C.T3, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("${chapter.panels.size}", "panel", Modifier.weight(1f))
                    StatCard("2048px", "resolusi", Modifier.weight(1f))
                    StatCard(chapter.style.emoji, "style", Modifier.weight(1f))
                    StatCard("${(chapter.consistencyScore * 100).toInt()}%", "selesai", Modifier.weight(1f))
                }
            }

            item {
                MlCard {
                    MlLabel("${chapter.panels.size} panel")
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.height(
                            ((chapter.panels.size + 1) / 2 * 140).dp.coerceAtMost(540.dp)),
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        items(chapter.panels) { panel ->
                            Surface(color = C.S0, shape = RoundedCornerShape(9.dp),
                                border = BorderStroke(1.dp, C.Border),
                                modifier = Modifier.aspectRatio(3f / 4f)) {
                                Box {
                                    Column(Modifier.fillMaxSize(),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center) {
                                        Text(if (panel.status == PanelStatus.DONE) "🖼️" else "⏳",
                                            fontSize = 26.sp)
                                        Text("panel ${panel.index + 1}", color = C.T3, fontSize = 11.sp)
                                        Text(panel.status.name, fontSize = 9.sp,
                                            color = when (panel.status) {
                                                PanelStatus.DONE   -> C.Green
                                                PanelStatus.FAILED -> C.Red
                                                else               -> C.Orange
                                            })
                                    }
                                    Surface(Modifier.align(Alignment.TopStart).padding(4.dp),
                                        Color.Black.copy(0.7f), RoundedCornerShape(4.dp)) {
                                        Text(if (panel.upscaledPath != null) "✓ 2048" else "512px",
                                            color = if (panel.upscaledPath != null) C.Green else C.T3,
                                            fontSize = 8.sp, fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(4.dp, 2.dp))
                                    }
                                    if (panel.latentEmbeddingPath != null) {
                                        Surface(Modifier.align(Alignment.TopEnd).padding(4.dp),
                                            C.BlueDim, RoundedCornerShape(4.dp)) {
                                            Text("SD✓", color = C.Blue, fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(4.dp, 2.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { MlBtn("📄 Xuất PDF", onClick = { /* share */ }, icon = Icons.Default.PictureAsPdf) }

            item {
                chapter.cbzPath?.let {
                    MlOutlineBtn("📦 Xuất CBZ (comic reader)", onClick = {
                        val file = File(it)
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                        context.startActivity(Intent.createChooser(
                            Intent(Intent.ACTION_SEND).apply {
                                type = "application/zip"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }, "Chia sẻ CBZ"))
                    }, icon = Icons.Default.FolderZip)
                }
            }

            item {
                MlOutlineBtn("➕ Tạo chương mới",
                    onClick = { nav.navigate("home") { launchSingleTop = true } },
                    icon = Icons.Default.Add)
            }
        }
    }
}

// ── CHARACTERS ────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharactersScreen(nav: NavController, vm: MainViewModel) {
    val chars by vm.characters.collectAsState()
    val loras by vm.loras.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var newName   by remember { mutableStateOf("") }
    var newAnchor by remember { mutableStateOf("") }
    var newNeg    by remember { mutableStateOf("") }
    var newSeed   by remember { mutableStateOf("") }
    var selLora   by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nhân vật") },
                navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { showAdd = !showAdd }) {
                        Icon(if (showAdd) Icons.Default.ExpandLess else Icons.Default.Add, null, tint = C.Blue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        },
        bottomBar = { AppNavBar(nav, "characters") },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Surface(color = C.BlueDim, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Blue.copy(0.3f))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("🎯 StoryDiffusion Consistency", color = C.Blue,
                            fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("Anchor prompt mô tả ngoại hình → StoryDiffusion inject vào mọi panel.\n" +
                             "Không cần train LoRA. Mặt + trang phục + vóc dáng nhất quán xuyên suốt truyện.",
                            color = C.T2, fontSize = 12.sp, lineHeight = 17.sp)
                    }
                }
            }

            items(chars) { c ->
                MlCard {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CharAvatar(c.name, 44.dp)
                        Column(Modifier.weight(1f)) {
                            Text(c.name, color = C.T1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("seed ${c.seed}", color = C.T3, fontSize = 11.sp)
                            Text(c.anchorPrompt.take(60) + "…", color = C.T2, fontSize = 11.sp,
                                lineHeight = 15.sp)
                            c.loraPath?.let {
                                Text("LoRA: ${it.substringAfterLast('/')}", color = C.Green, fontSize = 10.sp)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            MlChip(
                                if (c.loraPath != null) "LoRA ✓" else "anchor",
                                if (c.loraPath != null) C.Green else C.Blue,
                                if (c.loraPath != null) C.GreenDim else C.BlueDim
                            )
                            Spacer(Modifier.height(8.dp))
                            Icon(Icons.Default.Delete, null, tint = C.T3,
                                modifier = Modifier.size(18.dp).clickable { vm.deleteCharacter(c.id) })
                        }
                    }
                }
            }

            if (showAdd) item {
                MlCard {
                    MlLabel("thêm nhân vật mới")

                    @Composable
                    fun Field(label: String, value: String, hint: String, lines: Int = 1, onChange: (String) -> Unit) {
                        Text(label, color = C.T3, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
                        OutlinedTextField(
                            value = value, onValueChange = onChange,
                            modifier = Modifier.fillMaxWidth().let { if (lines > 1) it.height((lines * 26 + 24).dp) else it },
                            placeholder = { Text(hint, color = C.T3, fontSize = 12.sp) },
                            singleLine = lines == 1,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = C.Blue, unfocusedBorderColor = C.Border,
                                focusedContainerColor = C.S0, unfocusedContainerColor = C.S0,
                                focusedTextColor = C.T1, unfocusedTextColor = C.T1),
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                        )
                        Spacer(Modifier.height(10.dp))
                    }

                    Field("Tên *", newName, "vd: Aria") { newName = it }
                    Field("Anchor prompt * (mô tả ngoại hình cố định)", newAnchor,
                        "vd: young woman, long black hair, brown eyes, red leather jacket, slender, pale skin",
                        lines = 3) { newAnchor = it }
                    Field("Negative prompt (để trống = dùng mặc định)", newNeg,
                        "vd: fat, overweight, masculine") { newNeg = it }
                    Field("Seed (để trống = ngẫu nhiên)", newSeed, "vd: 42891") { newSeed = it }

                    if (loras.isNotEmpty()) {
                        Text("LoRA tùy chọn (tăng consistency thêm)", color = C.T3,
                            fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp),
                            modifier = Modifier.padding(bottom = 12.dp)) {
                            item {
                                Surface(onClick = { selLora = null },
                                    color = if (selLora == null) C.BlueDim else C.S0,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, if (selLora == null) C.Blue else C.Border)) {
                                    Text("Không", color = if (selLora == null) C.Blue else C.T2,
                                        fontSize = 12.sp, modifier = Modifier.padding(10.dp, 7.dp))
                                }
                            }
                            items(loras) { lora ->
                                Surface(onClick = { selLora = lora.path },
                                    color = if (selLora == lora.path) C.BlueDim else C.S0,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, if (selLora == lora.path) C.Blue else C.Border)) {
                                    Text(lora.name.take(20), color = if (selLora == lora.path) C.Blue else C.T2,
                                        fontSize = 12.sp, modifier = Modifier.padding(10.dp, 7.dp))
                                }
                            }
                        }
                    }

                    MlBtn("Lưu nhân vật", icon = Icons.Default.PersonAdd,
                        enabled = newName.isNotBlank() && newAnchor.isNotBlank(),
                        onClick = {
                            vm.addCharacter(newName, newAnchor, newNeg, selLora, newSeed.toLongOrNull())
                            newName = ""; newAnchor = ""; newNeg = ""; newSeed = ""; selLora = null
                            showAdd = false
                        })
                }
            }
        }
    }
}

// ── SETTINGS ──────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(nav: NavController, vm: MainViewModel) {
    val settings  by vm.settings.collectAsState()
    val sdModels  by vm.sdModels.collectAsState()
    val llmModels by vm.llmModels.collectAsState()
    val loras     by vm.loras.collectAsState()
    var showGuide by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Cài đặt & Model") },
                actions = {
                    IconButton(onClick = { vm.rescanModels() }) {
                        Icon(Icons.Default.Refresh, null, tint = C.Blue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.S0)
            )
        },
        bottomBar = { AppNavBar(nav, "settings") },
        containerColor = C.Bg
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Setup guide
            item {
                Surface(onClick = { showGuide = !showGuide }, color = C.PurpleDim,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, C.Purple.copy(0.4f))) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.FolderOpen, null, tint = C.Purple, modifier = Modifier.size(18.dp))
                            Text("📁 Hướng dẫn đặt model file", color = C.Purple,
                                fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Icon(if (showGuide) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                null, tint = C.Purple)
                        }
                        if (showGuide) {
                            Spacer(Modifier.height(8.dp))
                            Text(vm.modelSetupGuide(), color = C.T2, fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                        }
                    }
                }
            }

            // Model status
            item {
                MlCard {
                    MlLabel("trạng thái model")
                    vm.modelStatus().forEach { (name, ok) ->
                        Row(Modifier.padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (ok) Icons.Default.CheckCircle else Icons.Default.Cancel,
                                null, tint = if (ok) C.Green else C.Red,
                                modifier = Modifier.size(16.dp))
                            Text(name, color = C.T1, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Text(if (ok) "sẵn sàng" else "thiếu",
                                color = if (ok) C.Green else C.Red, fontSize = 11.sp)
                        }
                    }
                }
            }

            // Model pickers
            item {
                MlCard {
                    MlLabel("chọn model")
                    ModelDropdown("SD Model (.safetensors / .ckpt)", settings.sdModelPath, sdModels,
                        onSelect = { vm.updateSettings { copy(sdModelPath = it.path) } },
                        onRescan = { vm.rescanModels() })
                    Spacer(Modifier.height(14.dp))
                    ModelDropdown("LLM Model (.gguf)", settings.llmModelPath, llmModels,
                        onSelect = { vm.updateSettings { copy(llmModelPath = it.path) } },
                        onRescan = { vm.rescanModels() })
                    Spacer(Modifier.height(14.dp))
                    ModelDropdown("LoRA mặc định (tùy chọn)", settings.loraPath, loras,
                        onSelect = { vm.updateSettings { copy(loraPath = it.path) } },
                        onRescan = { vm.rescanModels() })
                }
            }

            // Generation params
            item {
                MlCard {
                    MlLabel("tham số sinh ảnh")

                    @Composable
                    fun SlRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>,
                              fmt: String = "%.0f", onChange: (Float) -> Unit) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label, color = C.T2, fontSize = 12.sp)
                            Text(fmt.format(value), color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(value = value, onValueChange = onChange, valueRange = range,
                            colors = SliderDefaults.colors(thumbColor = C.Blue,
                                activeTrackColor = C.Blue, inactiveTrackColor = C.Border))
                        Spacer(Modifier.height(4.dp))
                    }

                    SlRow("Steps (cao hơn = chi tiết hơn, chậm hơn)",
                        settings.steps.toFloat(), 10f..30f) { vm.updateSettings { copy(steps = it.toInt()) } }
                    SlRow("CFG Scale", settings.cfgScale, 3f..15f, "%.1f") { vm.updateSettings { copy(cfgScale = it) } }
                    SlRow("Threads", settings.nThreads.toFloat(), 1f..8f) { vm.updateSettings { copy(nThreads = it.toInt()) } }

                    Divider(color = C.Border, modifier = Modifier.padding(vertical = 8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Vulkan GPU (Adreno)", color = C.T1, fontSize = 13.sp)
                            Text("Tăng tốc độ upscale ESRGAN", color = C.T3, fontSize = 11.sp)
                        }
                        Switch(checked = settings.useVulkan,
                            onCheckedChange = { vm.updateSettings { copy(useVulkan = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = C.Blue, checkedTrackColor = C.BlueDim))
                    }
                }
            }

            // StoryDiffusion params
            item {
                MlCard {
                    MlLabel("storydiffusion settings")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Sliding window size", color = C.T2, fontSize = 12.sp)
                        Text("${settings.slidingWindowSize} panel", color = C.T1, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = settings.slidingWindowSize.toFloat(),
                        onValueChange = { vm.updateSettings { copy(slidingWindowSize = it.toInt()) } },
                        valueRange = 1f..6f, steps = 4,
                        colors = SliderDefaults.colors(thumbColor = C.Purple,
                            activeTrackColor = C.Purple, inactiveTrackColor = C.Border)
                    )
                    Text("Window lớn hơn = consistency tốt hơn nhưng tốn RAM hơn.\nKhuyến nghị: 2-3 cho SD888.",
                        color = C.T3, fontSize = 11.sp, lineHeight = 15.sp)
                }
            }

            // Stack info
            item {
                MlCard {
                    MlLabel("stack kỹ thuật · 100% local")
                    listOf(
                        "🧠 LLM" to "llama.cpp · chia scene + sinh prompt",
                        "🎨 SD 1.5" to "sd.cpp · bất kỳ checkpoint nào",
                        "🔄 StoryDiffusion" to "Consistent Self-Attention · sliding window",
                        "🔍 Upscale" to "Real-ESRGAN ncnn-vulkan · 4× → 2048px",
                        "📄 Export" to "PDF + CBZ · dialogue bubble"
                    ).forEachIndexed { i, (title, desc) ->
                        Column(Modifier.padding(vertical = 7.dp)) {
                            Text(title, color = C.T1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(desc, color = C.T3, fontSize = 11.sp)
                        }
                        if (i < 4) Divider(color = C.Border)
                    }
                }
            }
        }
    }
}
