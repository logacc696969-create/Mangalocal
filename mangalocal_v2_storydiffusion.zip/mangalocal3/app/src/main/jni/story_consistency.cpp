#include "story_consistency.h"
#include <android/log.h>
#include <cstring>
#include <fstream>
#include <vector>

#define TAG "StoryConsistency"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ── Lưu CLIP/VAE embedding của ảnh làm reference ─────────────────────────
// Cách hoạt động:
// 1. Encode ảnh đã sinh qua VAE encoder → latent vector (4 × H/8 × W/8)
// 2. Encode qua CLIP image encoder → semantic vector (768 dims)
// 3. Lưu cả hai vào file binary
// → Panel tiếp theo load file này, inject vào cross-attention của UNet
//   để "nhớ" đặc điểm mặt + vóc dáng + trang phục

bool saveLatentEmbedding(
    sd_ctx_t* ctx,
    const std::string& imagePath,
    const std::string& outputPath
) {
    // Load ảnh đã sinh
    int w, h, c;
    unsigned char* data = stbi_load(imagePath.c_str(), &w, &h, &c, 3);
    if (!data) {
        LOGE("saveLatentEmbedding: cannot load %s", imagePath.c_str());
        return false;
    }

    // Tạo sd_image_t
    sd_image_t img{(uint32_t)w, (uint32_t)h, 3, data};

    // Lấy embedding qua VAE encoder (hàm nội bộ của sd.cpp)
    // Đây là post-process level: không sửa attention, chỉ extract features
    // sd_get_image_embedding là hàm ta sẽ expose từ sd.cpp fork
    float* embedding = nullptr;
    int    embDim    = 0;

    bool ok = sd_get_image_embedding(ctx, img, &embedding, &embDim);
    stbi_image_free(data);

    if (!ok || !embedding || embDim == 0) {
        LOGE("saveLatentEmbedding: embedding extraction failed");
        return false;
    }

    // Ghi ra file: [int32 dim][float32 × dim]
    std::ofstream f(outputPath, std::ios::binary);
    if (!f.is_open()) {
        LOGE("saveLatentEmbedding: cannot write %s", outputPath.c_str());
        free(embedding);
        return false;
    }

    f.write(reinterpret_cast<const char*>(&embDim), sizeof(int32_t));
    f.write(reinterpret_cast<const char*>(embedding), embDim * sizeof(float));
    f.close();
    free(embedding);

    LOGI("saveLatentEmbedding: saved %d dims → %s", embDim, outputPath.c_str());
    return true;
}

// ── Load embeddings từ sliding window ────────────────────────────────────
bool loadEmbeddings(
    const std::vector<std::string>& paths,
    std::vector<std::vector<float>>& outEmbeddings
) {
    outEmbeddings.clear();
    for (auto& path : paths) {
        std::ifstream f(path, std::ios::binary);
        if (!f.is_open()) continue;

        int32_t dim = 0;
        f.read(reinterpret_cast<char*>(&dim), sizeof(int32_t));
        if (dim <= 0 || dim > 100000) continue;

        std::vector<float> emb(dim);
        f.read(reinterpret_cast<char*>(emb.data()), dim * sizeof(float));
        f.close();

        outEmbeddings.push_back(std::move(emb));
    }
    LOGI("loadEmbeddings: loaded %zu references", outEmbeddings.size());
    return !outEmbeddings.empty();
}

// ── Merge embeddings từ window (weighted average, anchor có trọng số cao hơn) ──
std::vector<float> mergeEmbeddings(
    const std::vector<std::vector<float>>& embeddings,
    float anchorWeight = 0.6f  // embedding đầu tiên (anchor) có trọng số cao hơn
) {
    if (embeddings.empty()) return {};

    size_t dim = embeddings[0].size();
    std::vector<float> merged(dim, 0.0f);

    float totalWeight = 0.0f;
    for (size_t i = 0; i < embeddings.size(); i++) {
        if (embeddings[i].size() != dim) continue;
        float w = (i == 0) ? anchorWeight : (1.0f - anchorWeight) / (embeddings.size() - 1);
        if (embeddings.size() == 1) w = 1.0f;
        for (size_t j = 0; j < dim; j++) merged[j] += embeddings[i][j] * w;
        totalWeight += w;
    }

    // Normalize
    if (totalWeight > 0) for (auto& v : merged) v /= totalWeight;
    return merged;
}

// ── Sinh ảnh với reference consistency injection ──────────────────────────
bool generateWithConsistency(
    sd_ctx_t* ctx,
    const std::string& prompt,
    const std::string& negPrompt,
    const std::vector<std::string>& refEmbeddingPaths,
    float consistencyStrength,
    int width, int height, int steps,
    float cfgScale, int64_t seed,
    const std::string& outputPath,
    sd_progress_callback progressCb,
    void* cbData
) {
    // Load và merge reference embeddings
    std::vector<std::vector<float>> embeddings;
    bool hasRefs = loadEmbeddings(refEmbeddingPaths, embeddings);

    if (hasRefs) {
        auto merged = mergeEmbeddings(embeddings);
        // Inject vào ctx như conditioning bổ sung
        // sd_set_reference_embedding là extension ta sẽ thêm vào sd.cpp
        sd_set_reference_embedding(ctx, merged.data(), (int)merged.size(), consistencyStrength);
        LOGI("generateWithConsistency: injected %zu refs, strength=%.2f",
             embeddings.size(), consistencyStrength);
    }

    // Sinh ảnh bình thường
    sd_image_t* imgs = txt2img(
        ctx,
        prompt.c_str(), negPrompt.c_str(),
        0, cfgScale, width, height,
        EULER_A, steps, seed, 1,
        nullptr, 0.f, 0.f, false, ""
    );

    // Clear reference sau khi sinh xong
    if (hasRefs) sd_clear_reference_embedding(ctx);

    bool ok = false;
    if (imgs && imgs[0].data) {
        ok = stbi_write_png(outputPath.c_str(), width, height,
                           imgs[0].channel, imgs[0].data, 0) != 0;
        free(imgs[0].data);
    }
    if (imgs) free(imgs);
    return ok;
}
