#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <algorithm>
#include "net.h"

// stb đã được define trong story_consistency.h - chỉ declare extern
extern unsigned char* stbi_load(const char*, int*, int*, int*, int);
extern void           stbi_image_free(void*);
extern int            stbi_write_png(const char*, int, int, int, const void*, int);

#define TAG "ESRGAN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

struct EsrganWrapper {
    ncnn::Net net;
    int scale;
    int tileSize = 128; // nhỏ để tiết kiệm RAM trên SD888

    EsrganWrapper(int s, const std::string& modelDir) : scale(s) {
        net.opt.use_vulkan_compute = true;
        net.opt.num_threads = 4;
        std::string param = modelDir + "/realesrgan-x4plus.param";
        std::string bin   = modelDir + "/realesrgan-x4plus.bin";
        if (net.load_param(param.c_str()) != 0) { LOGE("param fail: %s", param.c_str()); return; }
        if (net.load_model(bin.c_str())   != 0) { LOGE("bin fail: %s",   bin.c_str());   return; }
        LOGI("ESRGAN x%d OK", scale);
    }

    bool upscale(const std::string& in, const std::string& out) {
        int w, h, c;
        unsigned char* data = stbi_load(in.c_str(), &w, &h, &c, 3);
        if (!data) { LOGE("load fail: %s", in.c_str()); return false; }

        int ow = w * scale, oh = h * scale;
        std::vector<unsigned char> outBuf(ow * oh * 3);

        for (int ty = 0; ty < h; ty += tileSize) {
            for (int tx = 0; tx < w; tx += tileSize) {
                int tw = std::min(tileSize, w - tx);
                int th = std::min(tileSize, h - ty);

                ncnn::Mat inp(tw, th, 3);
                for (int y = 0; y < th; y++) for (int x = 0; x < tw; x++) {
                    auto* p = data + ((ty+y)*w + (tx+x)) * 3;
                    inp.channel(0)[y*tw+x] = p[0]/255.f;
                    inp.channel(1)[y*tw+x] = p[1]/255.f;
                    inp.channel(2)[y*tw+x] = p[2]/255.f;
                }

                auto ex = net.create_extractor();
                ex.input("input", inp);
                ncnn::Mat outTile;
                ex.extract("output", outTile);

                int otw = tw*scale, oth = th*scale;
                int otx = tx*scale, oty = ty*scale;
                for (int y = 0; y < oth; y++) for (int x = 0; x < otw; x++) {
                    auto* p = outBuf.data() + ((oty+y)*ow + (otx+x)) * 3;
                    p[0] = (unsigned char)std::clamp((int)(outTile.channel(0)[y*otw+x]*255), 0, 255);
                    p[1] = (unsigned char)std::clamp((int)(outTile.channel(1)[y*otw+x]*255), 0, 255);
                    p[2] = (unsigned char)std::clamp((int)(outTile.channel(2)[y*otw+x]*255), 0, 255);
                }
            }
        }
        stbi_image_free(data);
        bool ok = stbi_write_png(out.c_str(), ow, oh, 3, outBuf.data(), ow*3) != 0;
        LOGI("upscale %dx%d → %dx%d: %s", w, h, ow, oh, ok?"OK":"FAIL");
        return ok;
    }
};

static std::string j2s_esrgan(JNIEnv* e, jstring js) {
    if (!js) return "";
    auto* c = e->GetStringUTFChars(js, nullptr);
    std::string s(c); e->ReleaseStringUTFChars(js, c); return s;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_mangalocal_pipeline_NativeBridge_esrganInit(JNIEnv* e, jobject, jint scale, jstring jDir) {
    return reinterpret_cast<jlong>(new EsrganWrapper(scale, j2s_esrgan(e, jDir)));
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mangalocal_pipeline_NativeBridge_esrganUpscale(JNIEnv* e, jobject, jlong ptr, jstring jin, jstring jout) {
    return reinterpret_cast<EsrganWrapper*>(ptr)->upscale(j2s_esrgan(e,jin), j2s_esrgan(e,jout)) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mangalocal_pipeline_NativeBridge_esrganFree(JNIEnv*, jobject, jlong ptr) {
    delete reinterpret_cast<EsrganWrapper*>(ptr);
}
