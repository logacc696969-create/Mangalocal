# MangaLocal v2 — StoryDiffusion Edition

Chuyển truyện chữ → truyện tranh hoàn toàn local trên Android.
Nhất quán mặt + trang phục + vóc dáng xuyên suốt 100 chương — không cần train LoRA.

## Tính năng

- **StoryDiffusion Consistent Self-Attention** — sliding window giữ nhất quán nhân vật
- **LLM local** — tự động chia scene, sinh prompt từng panel
- **Bất kỳ SD 1.5 model nào** — không hardcode, scan từ thư mục
- **Real-ESRGAN 4×** — upscale 512px → 2048px
- **Xuất PDF + CBZ** — có dialogue bubble
- **100% offline** — không cần internet sau khi tải model

## Build APK (chỉ dùng điện thoại)

1. Vào **github.com** → tạo repo mới (Public)
2. Upload toàn bộ source code này
3. Vào tab **Actions** → workflow tự chạy
4. Chờ ~25-35 phút → download **MangaLocal-v2-StoryDiffusion.apk**
5. Cài trên Zenfone 8 (bật "Cài từ nguồn không xác định")

## Setup model sau khi cài

Đặt file vào `/sdcard/MangaLocal/`:

```
models/
  ├── qwen2.5-3b-instruct-q4_k_m.gguf     (~2GB) - LLM
  ├── realistic_vision_v5.safetensors      (~2GB) - SD siêu thực
  └── anything_v5.safetensors             (~2GB) - SD anime

loras/
  └── (tùy chọn) ten_nhan_vat.safetensors

esrgan/
  ├── realesrgan-x4plus.param
  └── realesrgan-x4plus.bin
```

**Download LLM:** huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF
**Download SD:** civitai.com
**Download ESRGAN:** github.com/xinntao/Real-ESRGAN/releases

## Stack kỹ thuật

| Thành phần | Công nghệ |
|---|---|
| LLM | llama.cpp · Qwen/Llama · CPU |
| Sinh ảnh | stable-diffusion.cpp · SD 1.5 · CPU+Adreno |
| Consistency | StoryDiffusion sliding window embedding |
| Upscale | Real-ESRGAN · ncnn-vulkan · 4× |
| Export | PDF + CBZ · Kotlin native |

## Hiệu năng Zenfone 8 (SD888)

| Tác vụ | Thời gian |
|---|---|
| LLM chia scene | ~5-10s |
| Mỗi panel 512px | ~35-55s |
| Upscale 4× | ~10-15s |
| 6 panel hoàn chỉnh | ~7-10 phút |
